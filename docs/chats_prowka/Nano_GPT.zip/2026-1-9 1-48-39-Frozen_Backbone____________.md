# Frozen-Backbone эксперимент

https://chat.openai.com/c/695ffc02-da78-832b-8355-a8128be02c35

## USER
Завершился 44-часовой Frozen-Backbone Grokking эксперимент. Вот результаты:

## USER
Завершился 44-часовой Frozen-Backbone Grokking эксперимент. Вот результаты:

**Данные:**
- Flash модель (SpacingMDN) генерила rollouts: std=0.8059
- True данные (реальные Riemann zeros): std=3.2200
- CorrectionNet учился предсказывать δ* = True - Flash

**Результаты:**
- CorrectionNet correlation: 0.8838
- Gap closed: 50-76% (в зависимости от α)
- Grokking НЕ случился - correlation 0.8838 достигнута на epoch 20 и не улучшилась за 44 часа
- Loss падал (0.17 → 0.06), но correlation НЕ росла (0.88 → 0.85)

**Вопросы:**
1. Почему Flash модель занижает std в 4 раза (0.8 vs 3.2)? Это проблема архитектуры MDN или данных?
2. Почему MLP-коррекция имеет потолок ~88%? Что в оставшихся 12%?
3. Какой подход попробовать дальше - attention-based коррекция, модель для хвостов распределения, или что-то другое?
4. Есть ли смысл продолжать grokking эксперименты или это тупиковый путь?

## ASSISTANT
0) **Frozen‑Backbone Grokking (POSTFIX, slot_id_mode=permute_per_batch, use_aux_loss=True, seeds={7,42,1337}): EMPIRICAL**

1) **Контекст**:  
Ты гонял “Frozen‑Backbone→unfreeze” как попытку **заставить Memory стать причинной**, а не декорацией (это прямо описано как режим “Memory forced”: сначала freeze backbone, потом unfreeze). **HYPOTHESIS** (потому что по твоим pasted‑логам я вижу итоговые метрики, но не вижу самой кривой “заморозка→разморозка”).【29:1†2026-1-1 6-4-18-__________________________.md†L11-L16】

Что у тебя по “сухим” итогам E4/POSTFIX (это и есть ближайший документированный слепок результата):  
- Лучший seed **s7**: **val NLL=0.1942**, при этом s42=0.3294, s1337=0.3431 → **жёсткая seed‑variance**. **EMPIRICAL (NLL)**【37:0†PROJECT_MAP.md†L10-L45】  
- Диагностика s7 (POSTFIX): **base NLL=0.1721**, **Perm Inc=1.0%**, **Grad Corr=0.296**, **Ablation Δ max=0.0058**, **rollout error growth=0.076**, **cross‑block CV=0.644**. **EMPIRICAL (NLL, Perm Inc, Grad Corr, Ablation Δ, rollout‑drift slope, block‑CV)**【37:1†PROJECT_MAP.md†L1-L10】  
- По “правилам E4”: Perm Inc≤5% и Grad Corr<0.7 — ты проходишь; **Ablation Δ≥0.02/slot** и **block‑CV<0.1** — ты проваливаешь; **PIT/CRPS** у тебя вообще не репортятся (в eval прямо написано, что ещё не сделано). **EMPIRICAL (Perm Inc, Grad Corr, Ablation Δ, block‑CV; PIT/CRPS missing)**【37:2†PROJECT_MAP.md†L26-L29】【37:2†PROJECT_MAP.md†L54-L62】  

Главная странность/важность:  
- **ID‑detox реально сработал** (Perm Inc≈1%) — это огромный сдвиг относительно “Perm Inc 93–117%” до фикса. **EMPIRICAL (Perm Inc)**【37:2†PROJECT_MAP.md†L1-L24】  
- Но “победа” по Perm Inc + низкий Grad Corr **не конвертируется в причинность**: Ablation Δ max=0.0058 — это уровень “удали слот, почти ничего не случится”. **EMPIRICAL (Ablation Δ, Grad Corr)**【37:1†PROJECT_MAP.md†L1-L10】  
- И плюс переносимость ломается: cross‑block CV=0.644 = сильный сдвиг распределения между блоками (по высотам/чанкам). **EMPIRICAL (block‑CV)**【37:1†PROJECT_MAP.md†L1-L10】  

2) **Определения**:  
**Frozen‑Backbone** — режим обучения, где ты на старте “замораживаешь” backbone (трансформерные блоки/основу), учишь только memory+голову, потом размораживаешь. **PROVEN (definition)**【29:1†2026-1-1 6-4-18-__________________________.md†L11-L16】  
**Grokking** — поздняя смена режима обобщения (val резко улучшается после долгой “платы”), часто при сильных ограничениях/регуляризации. **PROVEN (definition)**  
**POSTFIX memory** — раскладка токенов **[data…, memory…]** при причинной маске: memory может видеть data (слева), data не видит memory (справа). **PROVEN (definition)**【57:5†diagnose_memory_postfix.py†L5-L10】  
**Bottleneck readout** — голова предсказывает только из выходов memory‑позиций (нет прямого readout из data‑позиций). **PROVEN (definition)**【57:5†diagnose_memory_postfix.py†L5-L10】【57:14†2026-1-1 6-4-18-__________________________.md†L44-L53】  
**slot_id_mode=permute_per_batch** — ID‑detox режим, где индексы слотов постоянно перетасованы между батчами, чтобы модель не “учила номер слота”. **PROVEN (definition)**【37:2†PROJECT_MAP.md†L1-L24】  
**Perm Inc** — относительный рост **NLL** при случайной перестановке slot‑id эмбеддингов (в коде это `relative_increase`). **PROVEN (definition)**【53:8†diagnose_memory_postfix.py†L31-L41】  
**NLL** — средний negative log-likelihood смеси (MDN), т.е. `-logsumexp(log π + log N(y|μ,σ))`. **PROVEN (definition)**【53:2†2026-1-1 6-4-18-__________________________.md†L12-L31】  
**CRPS** — скоринговая функция для вероятностного прогноза (калибровка + точность). **PROVEN (definition)**  
**PIT** — Probability Integral Transform; по нему проверяют калибровку (должен быть ~Uniform[0,1]). **PROVEN (definition)**  
**Grad Corr** — средняя корреляция градиентов memory‑слотов; низкая = слоты не учатся одним и тем же. **PROVEN (definition)**【53:15†diagnose_memory_postfix.py†L52-L58】  
**Ablation Δ** — ΔNLL при отключении слота (`abl_nll - base_nll`); большой = слот причинно важен. **PROVEN (definition)**【53:1†diagnose_memory_postfix.py†L34-L57】  
**rollout‑drift slope** — скорость роста ошибки при авто‑regressive rollout (в JSONL это `error_growth_slope`). **PROVEN (definition)**【57:15†diagnose_memory_postfix.py†L24-L29】  
**block‑CV / cross‑block CV** — CV по NLL между блоками (высотами/чанками); низкий = переносимость. **PROVEN (definition)**【57:15†diagnose_memory_postfix.py†L28-L31】  
**rank_ratio** — доля эффективного ранга градиентов слотов (PCA/SVD); высокий = независимая ёмкость. **PROVEN (definition)**【53:8†diagnose_memory_postfix.py†L48-L56】【57:15†diagnose_memory_postfix.py†L40-L45】  
**ρ_n=1/2+iγ_n** — нули дзета на критической прямой (стандарт/известно). **PROVEN**  
**s_n** — spacing; в 2M‑пайплайне используется unfold‑нормировка через \(u(\gamma)\) и \(s_n=u(\gamma_{n+1})-u(\gamma_n)\). **PROVEN (definition)**【53:6†prepare_continuous_2M.py†L1-L9】  

3) **Зависимости**:  
Данные/нормировка:  
- Датасет `continuous_2M`: spacings получены через unfold‑формулу \(u(\gamma)=\frac{\gamma}{2\pi}\log\frac{\gamma}{2\pi e}\), затем `np.diff(u_vals)`. **EMPIRICAL (pipeline)**【53:6†prepare_continuous_2M.py†L1-L9】

Тренировка/конфиг:  
- POSTFIX‑тренер: `train_mdn_postfix.py` (есть ветка `use_aux_loss`, early stopping, лог `val_nll`). **EMPIRICAL (implementation)**【53:5†train_mdn_postfix.py†L24-L72】  
- Валидация в train: `entropy_reg=0` на eval (важно для сравнения). **EMPIRICAL (implementation)**【53:5†train_mdn_postfix.py†L60-L70】  
- Диагностика: `diagnose_memory_postfix.py` считает ablation, similarity, grad corr, permutation test, rollout drift, cross‑block, gradient rank, и пишет JSONL. **EMPIRICAL (implementation)**【57:15†diagnose_memory_postfix.py†L9-L45】

Сиды/режимы:  
- E4 явно гоняли seeds 7/42/1337, и только seed7 дал хороший NLL. **EMPIRICAL (NLL)**【37:0†PROJECT_MAP.md†L10-L45】

Operator Extraction (для spacing):  
- **Оператор \(O_k\)**: Domain = последние **k** spacings (контекст длины T=256) + (опц.) block/height‑id; Codomain = \(q(s_{n+1}\mid context)\) через **MDN(K=8)** (π,μ,σ). **HYPOTHESIS (formalization; согласуется с кодом train/eval)**【53:5†train_mdn_postfix.py†L24-L36】  
- Нормировка: у тебя уже **unfolded spacings** (не raw gaps), значит “density” стабильнее по γ, но block‑CV всё равно может ловить остаточный drift. **HYPOTHESIS (block‑shift diagnosis)**【53:6†prepare_continuous_2M.py†L1-L9】【37:1†PROJECT_MAP.md†L1-L10】

Если информации не хватает — минимальные тесты/логи (только самое дешёвое):  
1) **Свести NLL‑скейл в одну метрику**: в одном и том же скрипте посчитать `eval_nll()` на одном и том же `val.pt` для best.pt каждого сида. Иначе ты сравниваешь разные определения. **HYPOTHESIS (risk); метрика NLL**【53:0†2026-1-1 6-4-18-__________________________.md†L21-L31】【37:0†PROJECT_MAP.md†L10-L45】  
2) **Включить CRPS+PIT** в eval (сейчас “TODO”). Без этого у тебя нет калибровки, а значит “оператор” может быть фейк‑точным. **HYPOTHESIS (need); метрики CRPS/PIT**【37:2†PROJECT_MAP.md†L26-L29】  
3) **Репортнуть rank_ratio** из JSONL (оно уже предусмотрено полями `gradient_rank_ratio`, но в сводке ты его не показал). **HYPOTHESIS (missing); метрика rank_ratio**【57:15†diagnose_memory_postfix.py†L40-L45】

4) **Roadmap (2–6 шагов)**:  
1) **Lock‑in инварианты POSTFIX**: проверка маски + bottleneck “head читает только memory”. **PROVEN (цель); метрики Perm Inc, Ablation Δ (как индикатор обхода)**【57:5†diagnose_memory_postfix.py†L5-L10】【53:1†diagnose_memory_postfix.py†L11-L16】  
2) **ID‑DETOX как неизменяемое правило**: slot_id_mode=permute_per_batch, и прогон Perm Inc на best.pt (цель ≤5%, лучше ~1%). **EMPIRICAL (критерий); метрика Perm Inc**【37:1†PROJECT_MAP.md†L1-L10】【37:2†PROJECT_MAP.md†L1-L24】  
3) **Вытащить причинность слотов**: поднять Ablation Δ (цель ≥0.02/слот) без роста Perm Inc и без деградации NLL/CRPS. **HYPOTHESIS (цель‑фикс); метрики Ablation Δ, Perm Inc, NLL, CRPS**【37:2†PROJECT_MAP.md†L54-L62】【37:1†PROJECT_MAP.md†L1-L10】  
4) **Убить block‑shift**: снизить cross‑block CV (цель <0.1), иначе “оператор” не переносится по высоте. **HYPOTHESIS (цель‑фикс); метрика block‑CV**【37:2†PROJECT_MAP.md†L54-L62】【37:1†PROJECT_MAP.md†L1-L10】  
5) **Калибровка/переносимость**: добавить PIT/CRPS, block‑CV и rollout‑drift slope в единый отчёт; без этого ты оптимизируешь не то. **HYPOTHESIS (need); метрики PIT/CRPS/block‑CV/rollout‑drift slope**【37:2†PROJECT_MAP.md†L26-L29】【57:15†diagnose_memory_postfix.py†L24-L31】

5) **Леммы‑проверки**:  
A) **No‑leakage**:  
- Допущения: **Bottleneck readout** реализован (head получает только memory_outputs). **HYPOTHESIS**【57:5†diagnose_memory_postfix.py†L5-L10】【57:14†2026-1-1 6-4-18-__________________________.md†L44-L53】  
- Что меряется: NLL при “обнулить все memory слоты” vs base NLL (и/или проверить градиент в data‑позициях на readout‑пути). **HYPOTHESIS; метрика NLL**  
- Как: добавить ablation‑режим “all_slots_off” (аналог slot_off, но для всех), пересчитать ΔNLL. **SPECULATION; метрика Ablation Δ (тотальная)**  
- Вывод: пока **Ablation Δ max=0.0058** сам по себе не доказывает утечку, но доказывает, что слоты **не нужны** для NLL в текущем решении. **EMPIRICAL (Ablation Δ, NLL)**【37:1†PROJECT_MAP.md†L1-L10】 ∎  

B) **Mask‑invariant (POSTFIX: memory видит data, data не видит memory)**:  
- Допущения: вход реально склеен как `[x, memory]` и используется причинная маска. **HYPOTHESIS**【57:14†2026-1-1 6-4-18-__________________________.md†L17-L24】  
- Что меряется: внимание из data‑позиций на memory‑позиции должно быть ~0 (строго запрещено маской). **HYPOTHESIS**  
- Как: снять attention‑матрицы (return_attention=True) и проверить нули в запрещённом квадранте. **SPECULATION**  
- Вывод: логически это обязано быть true при корректной маске; без явного теста — не считаю доказанным. **HYPOTHESIS** ∎  

C) **No‑shortcut (голова читает только memory‑выходы)**:  
- Допущения: readout берётся только из последних M позиций (`x[:, -M:, :]`), потом pooling, потом MDN. **HYPOTHESIS**【57:14†2026-1-1 6-4-18-__________________________.md†L44-L53】  
- Что меряется: если заменить `memory_outputs` на нули, NLL должен резко вырасти; если нет — есть shortcut. **HYPOTHESIS; метрика NLL**  
- Как: “readout‑null test” (форсировать readout=0) и сравнить NLL. **SPECULATION**  
- Вывод: текущие цифры (Ablation Δ очень маленький) совместимы с “memory бесполезна” даже без shortcut; нужен именно readout‑null тест. **HYPOTHESIS (Ablation Δ, NLL)**【37:1†PROJECT_MAP.md†L1-L10】 ∎  

D) **Causality (Ablation Δ интерпретируется)**:  
- Допущения: выполнены A+B+C. **HYPOTHESIS**  
- Что меряется: per‑slot Ablation Δ (ожидаем ≥0.02/слот) + rank_ratio>0.5 (слоты не низкоранговые копии). **HYPOTHESIS; метрики Ablation Δ, rank_ratio**【37:2†PROJECT_MAP.md†L54-L62】  
- Как: `diagnose_memory_postfix.py` уже считает `delta_nll=abl_nll-base_nll` и пишет `gradient_rank_ratio`. **EMPIRICAL (implementation)**【53:1†diagnose_memory_postfix.py†L34-L57】【57:15†diagnose_memory_postfix.py†L40-L45】  
- Вывод: по s7 **Ablation Δ max=0.0058 < 0.02** → причинность слотов не достигнута (даже если независимость ок). **EMPIRICAL (Ablation Δ)**【37:1†PROJECT_MAP.md†L1-L10】 ∎  

6) **Разбор феномена** (“Феномен = сигнал”):  
**Симптом**: “слоты перестали палиться по ID” и “градиенты развязаны”, но “слоты не причинны” и “переносимость плохая”. **EMPIRICAL (Perm Inc, Grad Corr, Ablation Δ, block‑CV)**【37:1†PROJECT_MAP.md†L1-L10】  

**Измерение**:  
- ID‑зависимость: **Perm Inc=1.0%** (цель ≤5%) → PASS. **EMPIRICAL (Perm Inc)**【37:1†PROJECT_MAP.md†L1-L10】  
- Независимость обучения: **Grad Corr=0.296** (цель <0.7) → PASS. **EMPIRICAL (Grad Corr)**【37:1†PROJECT_MAP.md†L1-L10】  
- Причинность: **Ablation Δ max=0.0058** (цель ≥0.02) → FAIL. **EMPIRICAL (Ablation Δ)**【37:1†PROJECT_MAP.md†L1-L10】  
- Переносимость: **cross‑block CV=0.644** (цель <0.1) → FAIL. **EMPIRICAL (block‑CV)**【37:1†PROJECT_MAP.md†L1-L10】  
- Rollout: **error_growth_slope=0.076** (цель <0.5) → PASS. **EMPIRICAL (rollout‑drift slope)**【37:1†PROJECT_MAP.md†L1-L10】  

**2–3 гипотезы‑диагноза**:  
1) Слоты стали “независимыми”, но **информационно дублируют друг друга** (низкий Ablation Δ при низком Grad Corr = разные траектории градиента, но одинаковый функционал). **HYPOTHESIS (Grad Corr низкий, Ablation Δ низкий)**【37:1†PROJECT_MAP.md†L1-L10】  
2) Backbone всё равно тащит задачу, а memory — “регуляризатор/буфер”, полезный для стабильности/rollout, но не для one‑step NLL; поэтому **Ablation Δ низкий**, а rollout‑slope ок. **HYPOTHESIS (Ablation Δ низкий, rollout‑drift slope низкий)**【37:1†PROJECT_MAP.md†L1-L10】  
3) Cross‑block CV=0.644: модель ловит локальную статистику блока (остаточный drift плотности/корреляций), и memory не помогает переносить, потому что не вынужден кодировать переносимые инварианты. **HYPOTHESIS (block‑CV высокий, Ablation Δ низкий)**【37:1†PROJECT_MAP.md†L1-L10】  

**Самый дешёвый тест**:  
- “All‑slots‑off test” + “readout‑null test” на одном и том же batch → если NLL почти не растёт, значит memory действительно декоративна (а не “тонко важна”). **HYPOTHESIS; метрика NLL/Ablation Δ_total**  
- Пересчитать cross‑block CV с тем же sampler’ом `sample_xy` (важно: раньше у тебя был риск битых (x,y) пар; это могло ломать диагностику). **HYPOTHESIS (audit); метрики block‑CV/Ablation Δ/rollout‑drift slope**【53:7†2026-1-1 6-4-18-__________________________.md†L1-L16】【57:5†diagnose_memory_postfix.py†L44-L60】

**Фикс/применение (E5‑пакет)** — цель: **Ablation Δ↑, similarity↓, rank_ratio↑, block‑CV↓**, при этом **NLL/CRPS не хуже**, **Perm Inc не растёт**. **HYPOTHESIS (target metrics)**【37:2†PROJECT_MAP.md†L54-L62】  
- **Slot‑dropout (структурный)**: в training случайно “гасить” 1–2 слота (но не нарушая POSTFIX и bottleneck). Ожидание: Ablation Δ max вырастет (слоты перестанут быть взаимозаменяемыми), rank_ratio↑, mean_similarity↓; риск: NLL слегка ↑ на ранней фазе, но Perm Inc должен остаться ≤5% при пермутациях. **SPECULATION (expected metric shifts: Ablation Δ↑, rank_ratio↑, similarity↓, NLL≈, Perm Inc≤5%)**  
- **Orthogonality / repulsion loss** на memory (у тебя это уже в “constraints” дорожке как must‑have): ожидание mean_similarity↓ и Grad Corr↓/≈; вторичный эффект: Ablation Δ↑ (слоты вынуждены не дублировать). **HYPOTHESIS (expected: similarity↓, Grad Corr↓, Ablation Δ↑)**【57:8†2026-1-1 6-4-18-__________________________.md†L14-L19】  
- **Readout‑entropy reg / attention‑spread**: поднять “эффективную энтропию” использования слотов так, чтобы ни один слот не доминировал, но и не было полного равномерного шума (у тебя already `effect_entropy=1.97`, это неплохо; проблема не в доминации, а в причинности). Ожидание: Ablation Δ станет более концентрированной, но больше по величине (появятся 2–3 реально важных слота). **HYPOTHESIS (effect_entropy, Ablation Δ)**【37:1†PROJECT_MAP.md†L1-L10】  
- **Block‑aware training**: добавь block‑id/height‑proxy как aux‑feature или сделай stratified batches по блокам; цель — block‑CV<0.1. Ожидание: block‑CV↓, NLL на вал не хуже, PIT/CRPS улучшатся при переносе. **SPECULATION (expected: block‑CV↓, CRPS/PIT↑, NLL≈)**  

7) **Audit/Edge‑check**:  
- **Sampling bug**: если (x,y) пары иногда битые (off‑by‑one / flatten‑stride), то Ablation Δ/Grad Corr/rollout/block‑CV становятся мусором. Это у тебя уже ловили как “главный баг” — проверь, что в прод‑запуске диагностики стоит unified `sample_xy`. **HYPOTHESIS (risk); метрики Ablation Δ, Grad Corr, rollout‑drift slope, block‑CV**【53:7†2026-1-1 6-4-18-__________________________.md†L1-L16】【57:5†diagnose_memory_postfix.py†L44-L83】  
- **Perm Inc тест корректен?** В коде perm‑test перетасовывает веса `slot_id` и смотрит relative_increase. Это валидно только если slot_id embeddings реально используются; иначе будет skipped. Проверь, что `perm_test_skipped=False`, и что относительный рост считается от base_nll (а base_nll положительный). **HYPOTHESIS (audit); метрика Perm Inc**【53:8†diagnose_memory_postfix.py†L1-L41】  
- **NLL‑скейл/сравнимость**: у тебя в истории встречаются отрицательные “NLL” (похоже на loglik), а текущие E3/E4 NLL положительные. Это либо смена определения, либо другой датасет/нормировка/entropy_reg. Пока не сведёшь в один eval — сравнения “+36%” могут быть иллюзией. **HYPOTHESIS (risk); метрика NLL**【37:0†PROJECT_MAP.md†L10-L45】【53:0†2026-1-1 6-4-18-__________________________.md†L21-L31】  
- **Train/eval mismatch**: train считает loss с `entropy_reg=args.entropy_reg`, а eval валидации в train делает `entropy_reg=0`. Это ок, но ты должен сравнивать одинаковые режимы между экспериментами. **PROVEN (code fact); метрика NLL**【53:5†train_mdn_postfix.py†L24-L72】  
- **Shortcut‑пути**: даже при bottleneck readout возможны “скрытые шорткаты” через то, что backbone научился делать предсказание почти без опоры на memory. Это не архитектурный leak, это функциональная деградация: ловится readout‑null тестом + all‑slots‑off тестом. **HYPOTHESIS (diagnosis); метрики NLL/Ablation Δ_total**  
- **Seed‑variance**: “1/3 seeds good” — это красный флаг на переносимость протокола. Здесь поможет successive‑halving (ранние индикаторы: Ablation Δ, Grad Corr, err slope). **HYPOTHESIS (process fix); метрики Ablation Δ, Grad Corr, rollout‑drift slope**【37:0†PROJECT_MAP.md†L10-L45】【57:11†2026-1-1 6-4-18-__________________________.md†L1-L13】  
- **Калибровка отсутствует**: без PIT/CRPS ты не знаешь, насколько “оператор” честен вероятностно. **EMPIRICAL (missing); метрики PIT/CRPS**【37:2†PROJECT_MAP.md†L26-L29】

8) **Вывод + Next Actions**:  
**Action**: Свести единый eval‑скрипт для NLL/CRPS/PIT (один датасет, один sampler, один режим entropy_reg).  
**Why**: сейчас ты можешь оптимизировать разные определения “качества”.  
**Acceptance**: NLL сравним между seed/экспами; PIT близок к uniform, CRPS коррелирует с NLL; block‑CV считается тем же кодом. **HYPOTHESIS (targets); метрики NLL/CRPS/PIT/block‑CV**【37:2†PROJECT_MAP.md†L26-L29】  
**Failure mode**: NLL “улучшается”, но PIT разваливается или block‑CV остаётся высоким.

**Action**: Readout‑null + all‑slots‑off тесты на best.pt(s7).  
**Why**: отделить “memory декоративна” от “memory тонко важна, но Δ по слотам распылён”.  
**Acceptance**: NLL при all‑slots‑off ↑ существенно; целевой признак — суммарный ΔNLL большой и/или хотя бы 2 слота дают Ablation Δ≥0.02. **HYPOTHESIS; метрики NLL, Ablation Δ**【37:2†PROJECT_MAP.md†L54-L62】【37:1†PROJECT_MAP.md†L1-L10】  
**Failure mode**: NLL почти не меняется → тогда Frozen‑Backbone не достиг цели (memory не стала причинной).

**Action**: E5‑регуляризация против дублирования: slot‑dropout + orthogonality/repulsion + readout‑entropy tuning.  
**Why**: поднять причинность (Ablation Δ) и эффективный ранг (rank_ratio) без возврата ID‑костыля (Perm Inc).  
**Acceptance**: Ablation Δ max ≥0.02; mean_similarity↓; rank_ratio>0.5; Grad Corr остаётся <0.7; Perm Inc ≤5%; NLL/CRPS не хуже. **SPECULATION (expected shifts); метрики Ablation Δ/mean_similarity/rank_ratio/Grad Corr/Perm Inc/NLL/CRPS**【37:2†PROJECT_MAP.md†L54-L62】【37:1†PROJECT_MAP.md†L1-L10】  
**Failure mode**: Perm Inc растёт или Grad Corr растёт (слоты снова “сговариваются”).

**Action**: Убить block‑shift: stratified batches по блокам + явный block/height‑proxy в контекст или aux.  
**Why**: cross‑block CV=0.644 — переносимость провалена, “оператор” не будет инвариантен по высоте.  
**Acceptance**: cross‑block CV <0.1, rollout‑drift slope <0.5 сохраняется, NLL/CRPS не хуже. **HYPOTHESIS; метрики block‑CV/rollout‑drift slope/NLL/CRPS**【37:1†PROJECT_MAP.md†L1-L10】【37:2†PROJECT_MAP.md†L54-L62】  
**Failure mode**: block‑CV падает ценой деградации NLL/CRPS (модель стала “усреднялкой”).

9) **"Язык линзы"** (5–10 строк):  
Фон = поток unfolded‑spacing \(s_n\), где плотность по γ уже частично выровнена. **PROVEN**【53:6†prepare_continuous_2M.py†L1-L9】  
Фокус = memory‑слоты как “регистр решета”: они должны держать переносимые инварианты, а не номер слота. **HYPOTHESIS (цель); метрики Perm Inc, block‑CV**【37:1†PROJECT_MAP.md†L1-L10】  
Сито работает по ID (Perm Inc≈1%) — значит, ты выбил самый дешёвый костыль. **EMPIRICAL (Perm Inc)**【37:1†PROJECT_MAP.md†L1-L10】  
Но сито пока не держит нагрузку: Ablation Δ слишком мал, значит регистр не “несёт” прогноз. **EMPIRICAL (Ablation Δ)**【37:1†PROJECT_MAP.md†L1-L10】  
Bias/drift живут между блоками (block‑CV=0.644): оператор не переносится по высоте, даже если rollout локально стабилен (slope=0.076). **EMPIRICAL (block‑CV, rollout‑drift slope)**【37:1†PROJECT_MAP.md†L1-L10】  
Следующий шаг — заставить регистры стать незаменимыми (Ablation Δ↑) и переносимыми (block‑CV↓), не возвращая ID‑костыль (Perm Inc≤5%). **HYPOTHESIS (target metrics)**【37:2†PROJECT_MAP.md†L54-L62】

## ASSISTANT
0) **Frozen-Backbone δ*-корректор для spacing’ов (44h; std_Flash=0.8059 vs std_True=3.2200; corr=0.8838): EMPIRICAL**

1) **Контекст**:  
Ты сделал двухэтажную схему: базовая модель (“Flash”) генерит последовательность spacing’ов, затем отдельная сеть (“CorrectionNet”) учится предсказывать поправку \(\delta^\*=\text{True}-\text{Flash}\). Два сигнала одновременно:  
- **Разброс (std)** у Flash в ~4 раза меньше, чем у True: \(3.2200/0.8059 \approx 3.996\). (EMPIRICAL, метрика: std)  
- Коррекция закрывает “variance gap” на **50–76%** в зависимости от масштаба \(\alpha\). (EMPIRICAL, метрика: gap closed %)  
- “Grokking” не проявился: **corr=0.8838** достигнут к epoch~20 и дальше не растёт за 44 часа. (EMPIRICAL, метрика: corr vs epoch)  
- Парадокс: loss падает **0.17→0.06**, а corr не растёт и даже деградирует **0.88→0.85**. (EMPIRICAL, метрики: loss, corr)  

Ключевое: у тебя сейчас есть **один измеренный успех** (corr≈0.88 на \(\delta^\*\)) и **два красных флага**: (i) дисперсия/хвосты/rollout-динамика расходятся, (ii) оптимизируемая loss плохо согласована с целевой метрикой качества (корреляция/калибровка/перенос). (HYPOTHESIS, метрики для проверки: NLL, CRPS, PIT, rollout-drift slope, block-CV)

2) **Определения**:  
**\(\rho_n=1/2+i\gamma_n\)** — нули дзета-функции, \(\gamma_n\) — мнимая часть. (стандарт/известно, PROVEN)  
**\(s_n=\gamma_{n+1}-\gamma_n\)** — “raw gap” между соседними нулями. (стандарт/известно, PROVEN)  
**\(m(T)=2\pi/\log(T/2\pi)\)** — средний raw-gap на высоте \(T\approx\gamma_n\) (нормировка для “unfolding”). (стандарт/известно, PROVEN)  
**Unfolded gap** — нормированный gap, обычно порядка 1 (через \(u(\gamma)\) или через деление на \(m(T)\)). (стандарт/известно, PROVEN)  
**Flash** — базовая модель, генерирующая следующий gap (у тебя: SpacingMDN). (EMPIRICAL: по описанию)  
**MDN** — Mixture Density Network: выдаёт параметры смеси распределений \(q(s_{n+1}\mid \text{context})\). (стандарт/известно, PROVEN)  
**CorrectionNet** — отдельная сеть, обучаемая предсказывать \(\delta^\*\). (EMPIRICAL: по описанию)  
**\(\delta^\*=\text{True}-\text{Flash}\)** — целевая поправка (резидуал) к выходу Flash. (EMPIRICAL: по постановке)  
**\(\alpha\)** — коэффициент применения коррекции: \(\hat{s}=\text{Flash}+\alpha\hat{\delta}\). (EMPIRICAL: по описанию)  
**corr** — корреляция предсказанной \(\hat{\delta}\) с истинной \(\delta^\*\) (твой KPI сейчас). (EMPIRICAL: corr=0.8838)  
**NLL** — \(-\log q(y\mid x)\), основной one-step скор для вероятностной модели. (стандарт/известно, PROVEN)  
**CRPS** — скор для вероятностного прогноза, чувствителен к форме и хвостам, часто стабильнее NLL. (стандарт/известно, PROVEN)  
**PIT** — \(u=\mathrm{CDF}(y_{\text{true}})\); при калибровке \(u\sim U[0,1]\). (стандарт/известно, PROVEN)  
**block‑CV** — валидация “блоками по высоте” (train/val по диапазонам \(\gamma\)), тест на перенос и shift. (стандарт/известно, PROVEN)  
**rollout** — автогенерация на горизонте \(h\): модель кормится своими предсказаниями. (стандарт/известно, PROVEN)  
**rollout‑drift slope** — скорость роста ошибки/расхождения при увеличении \(h\). (стандарт/известно, PROVEN)  
**хвосты распределения** — редкие большие значения \(s\) (или \(\delta^\*\)), сильно влияющие на std и CRPS. (стандарт/известно, PROVEN)  
**exposure bias** — расхождение режимов train (teacher forcing) и rollout (самокормление). (стандарт/известно, PROVEN)  
**POSTFIX memory** — расклад \([data..., memory...]\) + причинная маска; “memory видит data, data не видит memory”. (PROVEN: архитектурное требование проекта)  
**ID‑DETOX / slot_id_mode=permute_per_batch** — пермутация ID слотов на батч, чтобы убить “ID‑костыль”. (PROVEN: протокол проекта)  
**Perm Inc** — % рост NLL при случайной перестановке слотов; цель ≤5% (E4≈1%). (PROVEN: определение метрики)  
**Grad Corr** — средняя корреляция градиентов между слотами; цель <0.7 (E4≈0.296). (PROVEN: определение метрики)  
**Ablation Δ** — изменение метрики (обычно NLL/Err@h) при выключении слота/фичи; цель ≥0.02/слот. (PROVEN: определение метрики)  
**rank_ratio** — эффективная размерность/ранг (например r90/n_slots); цель >0.5. (PROVEN: определение метрики)  
**Оператор \(O_k\)** — отображение “контекст → распределение следующего шага”. (HYPOTHESIS: как линза проекта)  
**Domain \(O_k\)** — \(k\) последних \(s\) + опционально \(T\) и Q3‑aux признаки. (HYPOTHESIS)  
**Codomain \(O_k\)** — \(q(s_{n+1}\mid \cdot)\) через MDN или значение \(s_{n+1}\). (HYPOTHESIS)

3) **Зависимости**:  
Что критично знать/зафиксировать, иначе ты лечишь призрак:  
- Какая именно величина имеет std=0.8059 и std=3.2200: это **unfolded gap**, **raw gap**, **кумулятивная сумма**, **ошибка rollout**, или **ensemble spread**? (HYPOTHESIS; тест: сверить распределение/квантили; метрики: std + PIT/CRPS)  
- Как устроен input CorrectionNet: видит ли он **контекст \(s_{n-k:n}\)**, параметры MDN (\(\pi,\mu,\sigma\)), скрытое состояние, высоту \(T\)? (HYPOTHESIS; тест: ablation Δ по группам фич)  
- Какая loss у корректора: MSE по \(\delta^\*\) или что-то ещё? (EMPIRICAL: у тебя loss 0.17→0.06, но тип не указан)  
- Где меряется corr: train/val, и вал — это **val_tail** или случайный сплит? (HYPOTHESIS; метрика: block‑CV)  
- Режим генерации Flash: mean‑rollout vs sample‑rollout (температура/клип/рефлю). (HYPOTHESIS; метрики: rollout-drift slope, PIT)  

Если инфы нет — вот **3 минимальных лога**, которые дадут диагноз без “перепиши всё”:  
1) **One‑step калибровка Flash** на вал: NLL, CRPS, PIT(mean,std,KS), плюс квантили (p90/p99) для хвостов. (HYPOTHESIS→проверка; метрики: NLL/CRPS/PIT)  
2) **Rollout отчёт** (h=10/25/50/100/200): Err@h (MAE или CRPS@h), spread@h, и rollout‑drift slope. (HYPOTHESIS→проверка; метрики: rollout-drift slope)  
3) **Срез корреляции корректора по квантилям** \(\delta^\*\) или \(s\): corr в body (≤p90) vs tail (≥p99), + block‑CV по высоте. (HYPOTHESIS→проверка; метрики: corr, block‑CV)  

Operator Extraction (обязательный минимум для spacing):  
- Явно пометь: работаешь с **raw** \(s_n\) или **unfolded** \(s_n/m(T)\) (или через \(u(\gamma)\)). (HYPOTHESIS; метрика: std_true ожидаемо меняется радикально)  
- Определи \(O_k^{flash}\): Domain = \(k\) последних \(s\) (и опц. \(T\)), Codomain = MDN \(q(s_{n+1}\mid\cdot)\). (HYPOTHESIS)  
- Для переноса: train/val по height‑блокам и репорт block‑CV (pass если <0.1). (HYPOTHESIS; метрика: block‑CV)  

4) **Roadmap (2–6 шагов)**:  
1) **Нормировка и объект std**: зафиксируй “raw vs unfolded” и что именно ты называешь std. (HYPOTHESIS; acceptance: std_true попадает в ожидаемый диапазон для выбранной нормировки; метрики: std, PIT)  
2) **Развести one‑step и rollout**: отдельно померяй NLL/CRPS/PIT one‑step и rollout‑drift slope. (PROVEN: эти режимы не эквивалентны; метрики: NLL, CRPS, PIT, rollout-drift slope)  
3) **Поймать хвосты**: посчитать p95/p99/p99.9 и exceedance‑rate (доля “больших” событий) для True vs Flash, плюс PIT по хвостовым бинам. (HYPOTHESIS; метрики: PIT, CRPS)  
4) **Переформулировать коррекцию как вероятностную**: вместо MSE‑корректора — \(\delta\)-MDN (или Student‑t) и оценка NLL/CRPS/PIT по \(\delta^\*\). (HYPOTHESIS; acceptance: PIT ближе к uniform, CRPS↓, NLL не хуже)  
5) **Мульти‑шаговый loss**: добавь 10–20‑шаговый drift‑term (или scheduled sampling) именно для стабилизации std/хвостов в rollout. (HYPOTHESIS; acceptance: rollout-drift slope↓, Err@h↓, std_rollout ближе к True)  
6) **Если хочешь “операторные регистры”**: перенос корректора в POSTFIX‑memory схему + ID‑DETOX. (HYPOTHESIS; acceptance: Perm Inc≤5%, Grad Corr<0.7, rank_ratio>0.5, Ablation Δ≥0.02 без ухудшения NLL/CRPS)

5) **Леммы-проверки**:  
A) **No-leakage**:  
Допущения: train/val разнесены по высоте (block split), корректор не видит будущие истинные значения. (HYPOTHESIS) → Что меряется: block‑CV и разница train vs val по NLL/CRPS/corr. (HYPOTHESIS) → Как: block‑CV по 5–10 height‑блокам; репорт (mean±std). (HYPOTHESIS) → Вывод: если block‑CV>0.1 и val‑corr стоит на ~0.88 при падающем train‑loss — у тебя либо shift, либо leakage‑косвенный через подготовку данных. (HYPOTHESIS; метрики: block‑CV, NLL/CRPS, corr) ∎  

B) **Mask-invariant (POSTFIX: memory видит data, data не видит memory)**:  
Допущения: если внедряешь память/attention‑корректор, то вход = \([data..., memory...]\) и causal mask запрещает “data→memory назад”. (PROVEN: требование протокола) → Что меряется: Perm Inc и тест “memory-only readout” (shortcut‑запрет). (HYPOTHESIS) → Как: slot_id_mode=permute_per_batch; сравнить NLL до/после permute; плюс проверка что голова читает только memory‑выходы. (HYPOTHESIS; метрики: Perm Inc, NLL) → Вывод: Perm Inc≤5% + стабильный NLL значит модель не держится на ID/утечке; иначе любая “коррекция” может быть читом. (HYPOTHESIS) ∎  

C) **No-shortcut (голова читает только memory-выходы)**:  
Допущения: при memory‑корректоре запрещён прямой путь “data→head”, иначе слоты декоративны. (PROVEN: принцип бутылочного горлышка) → Что меряется: Ablation Δ по слотам и Grad Corr. (HYPOTHESIS) → Как: занулить слот i и смотреть ΔNLL/ΔErr@h; посчитать Grad Corr между слот‑параметрами. (HYPOTHESIS; метрики: Ablation Δ, Grad Corr, NLL, Err@h) → Вывод: Ablation Δ≥0.02 и Grad Corr<0.7 означает слоты каузально нужны и не дублируются; иначе “корректор” не держит операторное состояние. (HYPOTHESIS) ∎  

D) **Causality (Ablation Δ интерпретируется)**:  
Допущения: Ablation делается на вал, без пересчёта статистик нормировки, и сравнение честное. (PROVEN: иначе Δ бессмысленна) → Что меряется: Δ метрик (NLL/CRPS/Err@h) при точечной абляции фич/слота, плюс rank_ratio. (HYPOTHESIS) → Как: (i) вырубить группы входов (последние 1/4/16 gap’ов; \(T\); параметры \(\sigma\)); (ii) PCA/ранг по градиентам. (HYPOTHESIS; метрики: Ablation Δ, rank_ratio, NLL/CRPS) → Вывод: если Ablation Δ маленькая, а rank_ratio низкий — остаточные 12% не “магия”, а недостающий сигнал/длина памяти/хвосты. (HYPOTHESIS) ∎  

6) **Разбор феномена** ("Феномен = сигнал"):  

**Феномен 1: Flash занижает std в ~4 раза** (EMPIRICAL: std_Flash=0.8059, std_True=3.2200).  
- Симптом: rollout у Flash слишком “узкий” по std. (EMPIRICAL, метрика: std)  
- Измерение, которого не хватает: one‑step PIT/CRPS/NLL и tail‑квантили True vs Flash. (HYPOTHESIS; метрики: PIT, CRPS, NLL)  
- Диагноз‑гипотеза #1 — **ты сравниваешь разные шкалы/объекты** (raw vs unfolded, или std по разным величинам). (HYPOTHESIS; тест: пересчитать std на одном и том же \(s\), плюс показать mean/p50/p90/p99)  
- Диагноз‑гипотеза #2 — **хвосты убиты**: Flash хорошо в “body”, но почти не генерит редкие большие события; std падает, хотя NLL может быть норм. (HYPOTHESIS; тест: PIT по квантилям + exceedance‑rate для порога p99 True; метрики: PIT, CRPS)  
- Диагноз‑гипотеза #3 — **динамическая контракция в rollout**: даже если one‑step ок, при самокормлении модель уходит в “аттрактор”, spread/вариация схлопываются. (HYPOTHESIS; тест: сравнить one‑step std_pred vs rollout std(h); метрика: rollout-drift slope + std(h))  
- Самый дешёвый тест:  
  1) NLL/CRPS/PIT one‑step на вал;  
  2) Err@h и rollout‑drift slope;  
  3) p99‑срез: доля больших gaps в True и Flash. (HYPOTHESIS; метрики: NLL, CRPS, PIT, rollout-drift slope)  
- Фикс/применение:  
  - Если это шкала — просто фиксируешь нормировку и все выводы про “std×4” пересчитываешь. (HYPOTHESIS; acceptance: std становится сравнимым)  
  - Если хвосты — добавляешь tail‑aware обучение: (i) веса для больших \(\delta^\*\) / больших \(s\), (ii) более тяжёлый хвост (Student‑t / log‑space), (iii) оптимизация CRPS вместе с NLL. (HYPOTHESIS; acceptance: CRPS↓, PIT хвостов ближе к uniform, std_rollout↑ без взрыва drift slope)  
  - Если rollout‑контракция — добавляешь multi‑step drift loss / scheduled sampling / rollout‑regularization. (HYPOTHESIS; acceptance: rollout-drift slope↓, Err@h↓, std(h) ближе к True)

**Феномен 2: потолок коррекции corr≈0.88 и “анти‑grokking” (loss↓, corr↔/↓)** (EMPIRICAL: corr=0.8838 early, потом ~0.85; loss 0.17→0.06).  
- Симптом: корректор быстро выжимает максимум линейно доступного сигнала и дальше “доламывает” loss ценой ухудшения corr на валидации. (HYPOTHESIS; метрики: train/val corr, block‑CV)  
- Что реально может сидеть в оставшихся 12%:  
  1) **Алеаторика / многозначность**: \(\delta^\*\) не детерминирована твоими входами, нужна вероятностная голова; потолок по corr закономерен. (HYPOTHESIS; тест: \(\delta\)-MDN + PIT/CRPS по \(\delta^\*\))  
  2) **Хвосты**: корректор попадает в основную массу, но промахивается по редким большим поправкам; corr “упирается”. (HYPOTHESIS; тест: corr по квантилям \(|\delta^\*|\), метрика: corr_tail + CRPS_tail)  
  3) **Недостающий контекст/высота**: \(\delta^\*\) зависит от долгой памяти и/или от \(T\) (shift по высоте), а MLP это не видит. (HYPOTHESIS; тест: добавить \(T\), увеличить k, или attention; мерить block‑CV и Ablation Δ по “дальним лагам”)  
  4) **Лейбл‑шум от стохастики Flash**: если Flash сэмплируется, часть \(\delta^\*\) — чисто шум выбора компоненты, предсказуемость ограничена. (HYPOTHESIS; тест: учить на mean‑Flash vs sample‑Flash; метрика: corr и NLL по \(\delta\))  
- Самый дешёвый тест: разложи качество на 2 оси:  
  - (i) **body vs tail** (квантили),  
  - (ii) **низкая vs высокая высота** (block‑CV). (HYPOTHESIS; метрики: corr, block‑CV, CRPS)  
- Фикс/применение:  
  - Перейти от “точечного \(\hat{\delta}\)” к “распределению \(\delta\)” (NLL/CRPS/PIT для \(\delta\)), и уже потом собирать итоговый прогноз. (HYPOTHESIS; acceptance: PIT ближе к uniform, CRPS↓, corr может остаться ~0.88 — и это нормально)  
  - Если реально нужен рост corr: добавить attention/память и тестировать причинность через Ablation Δ и устойчивость через rollout‑drift slope. (HYPOTHESIS; метрики: Ablation Δ, rollout-drift slope, rank_ratio)

7) **Audit/Edge-check**:  
- Индексация: \(\delta^\*_t\) точно соответствует тому же шагу/контексту, что и Flash? (HYPOTHESIS; тест: sanity “если подставить True вместо Flash → \(\delta^\*=0\)” на кусках; метрика: NLL/MAE sanity)  
- Train/eval mismatch: ты меряешь corr на вал, а loss на train? (HYPOTHESIS; метрика: train/val corr + block‑CV)  
- Нормировка: raw/unfolded, лог‑скейл, клипы/relus (особенно если есть принудительная положительность). (HYPOTHESIS; метрики: PIT, tail exceedance)  
- Shortcut‑пути (если используешь attention/память): readout не должен видеть data напрямую. (PROVEN: требование POSTFIX)  
- Seed‑variance: один прогон 44h без сидов — это слабая статистика. (PROVEN: дисперсия оптимизации) → минимум 3 seed и mean±std по NLL/CRPS/PIT/rollout‑drift slope. (HYPOTHESIS acceptance)  
- Метрика corr: корреляция не видит калибровку и хвосты; легко “выиграть” MSE и проиграть corr. (PROVEN; метрики для замены: NLL/CRPS/PIT)  
- Переносимость: block‑CV по height‑блокам обязателен, иначе ты можешь учить локальный режим. (PROVEN; метрика: block‑CV)  
- Для slot‑архитектур: Perm Inc/Grad Corr/Ablation Δ/rank_ratio, иначе ты не отличишь “оператор” от “ID‑костыля”. (PROVEN)

8) **Вывод + Next Actions**:  

**Action 1 — Сначала убей неопределённость “что такое std=3.22”** (HYPOTHESIS)  
- Why: пока ты не зафиксировал нормировку и объект std, вопрос (1) “MDN vs data” не имеет смысла. (PROVEN)  
- Acceptance: лог с mean/std/p50/p90/p99 для True и Flash на одном и том же \(s\); плюс one‑step PIT/CRPS/NLL. (HYPOTHESIS; метрики: std, PIT, CRPS, NLL)  
- Failure mode: окажется, что std сравнивался между разными шкалами — и вся история про “×4” была артефактом. (HYPOTHESIS)

**Action 2 — Диагностика: one‑step vs rollout** (HYPOTHESIS)  
- Why: underdispersion может быть не в модели распределения, а в динамике rollout (exposure bias). (HYPOTHESIS)  
- Acceptance: отчёт Err@h и rollout‑drift slope, отдельно для mean‑rollout и sample‑rollout; цель — slope <0.5 (или хотя бы заметно ниже текущего). (HYPOTHESIS; метрики: rollout-drift slope, Err@h)  
- Failure mode: slope низкий, но std всё равно мал → значит проблема в хвостах/нормировке, а не в drift. (HYPOTHESIS)

**Action 3 — Сменить “MLP‑точку” на “вероятностную коррекцию”** (HYPOTHESIS)  
- Why: потолок corr≈0.88 часто означает, что остаток — стохастика/многомодальность; тогда нужно оптимизировать NLL/CRPS/PIT, а не corr. (HYPOTHESIS)  
- Acceptance: \(\delta\)-MDN (или Student‑t) даёт PIT ближе к uniform, CRPS по \(\delta^\*\) падает, итоговый std_rollout поднимается без взрыва drift slope. (HYPOTHESIS; метрики: NLL, CRPS, PIT, rollout-drift slope)  
- Failure mode: NLL улучшается, но tails всё равно мимо → нужен tail‑weighting / log‑space. (HYPOTHESIS)

**Action 4 — Если хочешь добить оставшиеся 12%: attention/память, но по протоколу** (HYPOTHESIS)  
- Why: если ablation по “дальним лагам” показывает вклад (Ablation Δ растёт с увеличением окна), MLP упирается в выразительность/длину памяти. (HYPOTHESIS; метрика: Ablation Δ по лагам)  
- Acceptance: переход в POSTFIX memory + ID‑DETOX: Perm Inc≤5%, Grad Corr<0.7, rank_ratio>0.5, Ablation Δ≥0.02/слот, при этом NLL/CRPS не хуже и rollout‑drift slope не растёт. (HYPOTHESIS; метрики: Perm Inc, Grad Corr, rank_ratio, Ablation Δ, NLL, CRPS, rollout-drift slope)  
- Failure mode: Perm Inc высокий или Ablation Δ≈0 → ты снова построил декоративный/читерский корректор. (HYPOTHESIS)

**Action 5 — Про grokking: не продолжай “в лоб”, если не меняешь режим** (HYPOTHESIS)  
- Why: у тебя “быстрый выход на плато corr (epoch~20) + долгий прогон без роста” — это не профиль grokking, это профиль “всё извлекаемое уже извлечено данным представлением”. (HYPOTHESIS; метрики: corr vs epoch, block‑CV)  
- Acceptance (если всё-таки хочешь проверить grokking как феномен):  
  - маленький train‑set, жёсткий weight decay, явный монитор block‑CV и NLL/CRPS/PIT, и критерий “резкий перелом на val, не на train”. (HYPOTHESIS; метрики: block‑CV, NLL/CRPS/PIT)  
- Failure mode: снова 40 часов ради того же плато — это чистая трата compute. (HYPOTHESIS)

Ответы на твои 4 вопроса в одну строку (без лирики):  
1) std×4 почти наверняка либо **артефакт нормировки/метрики**, либо **убитые хвосты + rollout‑контракция**; отличишь по one‑step PIT/CRPS и rollout‑drift slope. (HYPOTHESIS; метрики: PIT/CRPS, rollout-drift slope, std)  
2) потолок 0.88 — это либо **алеаторика/многомодальность \(\delta^\*\)**, либо **хвосты/shift по высоте**, либо **недостаток контекста**; режь по квантилям и по block‑CV. (HYPOTHESIS; метрики: CRPS/PIT, block‑CV, Ablation Δ)  
3) дальше: **вероятностная коррекция + tail‑aware loss + multi‑step drift**, и только потом attention/memory (с Perm Inc/Grad Corr/Ablation Δ/rank_ratio). (HYPOTHESIS; метрики: NLL/CRPS/PIT, rollout-drift slope, Perm Inc, Grad Corr, Ablation Δ, rank_ratio)  
4) grokking как “метод улучшения” — почти тупик в твоём сетапе; как “диагностический эксперимент” — ок, но только при правильном режиме и с block‑CV. (HYPOTHESIS; метрики: block‑CV, NLL/CRPS/PIT)

9) **"Язык линзы"** (5–10 строк):  
Flash сейчас — это сито, которое просеивает “тело” распределения и теряет крупные зёрна. (HYPOTHESIS; метрики: tail‑PIT/CRPS, std)  
CorrectionNet показал, что часть структуры доступна из контекста: corr≈0.88 — это реальный сигнал, не шум. (EMPIRICAL; метрика: corr)  
Оставшееся — либо тень хвостов, либо дрейф самокормления, либо зависимость от высоты/длинной памяти. (HYPOTHESIS; метрики: rollout-drift slope, block‑CV)  
Если хочешь “оператор”, делай регистры: POSTFIX memory, readout только через память, ID‑DETOX. (PROVEN: протокол)  
Живучесть rollout — главный судья: slope↓, PIT ровнее, CRPS лучше, std ближе к True — тогда линза держит фокус. (HYPOTHESIS; метрики: rollout-drift slope, PIT, CRPS, std)

## USER
## Follow-up Questions - Connected to the MAIN GOAL

Our **main goal** is: **Prove/validate Riemann Hypothesis by extracting the underlying operator from a neural network trained on zeta zeros statistics.**

The hypothesis: If we can train a model that **perfectly captures** the pair-correlation and spacing distribution of Riemann zeros, the model's learned weights/attention patterns should encode the **spectral structure** of the unknown Hamiltonian H (whose eigenvalues are the zeros).

Given our experimental results (88% correlation ceiling, 4x std mismatch), I have 3 deep questions:

---

### Question 1: What does the 4x std mismatch tell us about the GUE hypothesis?

Montgomery's pair-correlation conjecture says zeta zeros follow GUE statistics (Gaussian Unitary Ensemble from random matrix theory). 

The fact that our Flash model predicts std=0.8059 while true std=3.2200 means:
- Is the model capturing GUE "shape" but missing the **scale**?
- Or is this a fundamental failure to capture the **long-range correlations** in the spectrum?

**What would perfectly calibrated GUE behavior look like?** And what does our 4x mismatch imply about which aspect of GUE our model is missing?

---

### Question 2: Operator Extraction Strategy

The endgame is: attention_weights → linear operator → spectral decomposition → validate against RH.

Given that our current model has:
- Perm Inc = 1% (good - not cheating on position)
- Ablation Δ = 0.0058 (bad - memory is decorative)
- 88% correlation ceiling

**What architecture changes would force the model to learn an operator that IS the spectral structure?**

Options I'm considering:
a) Force attention to be symmetric (Hermitian constraint)
b) Add spectral loss: minimize ||attention - theoretical_GUE_kernel||
c) Train on raw zeros instead of spacings (capture absolute positions)

Which approach has best chance of yielding extractable operator?

---

### Question 3: Is the 12% residual error fundamental or solvable?

The CorrectionNet achieves 88% correlation but not higher. Two interpretations:
1. **Solvable**: We're missing some learnable structure (long memory, global context)
2. **Fundamental**: The remaining 12% is truly random (quantum chaos limit)

The Berry-Tabor conjecture says integrable systems have Poisson statistics, chaotic systems have GUE. Zeta zeros are GUE-like because the "Riemann dynamics" is chaotic.

**Is there a theoretical ceiling on how well ANY model can predict zeta zeros?** What does random matrix theory say about the "predictable" vs "irreducible chaos" components?

---

Please think deeply about these from the RH perspective. I'm not debugging code - I'm trying to design the next experiment that advances our understanding of the spectral structure of zeta zeros.

## ASSISTANT
0) **Frozen‑Backbone CorrectionNet (δ\*=True−Flash; std_flash=0.8059 vs std_true=3.2200; corr=0.8838; Perm Inc=1%; Ablation Δ=0.0058): EMPIRICAL**

1) **Контекст**  
Ты сделал связку “Flash‑генератор → CorrectionNet учит δ\*=True−Flash” и увидел два сигнала:  
- **Flash rollouts** сильно **недодисперсные**: std=0.8059 против std_true=3.2200 (≈×4). (EMPIRICAL; std)  
- **CorrectionNet упёрся в потолок**: corr≈0.8838 уже к epoch~20 и дальше 44 часа без роста, при этом loss падает 0.17→0.06, а corr даже проседает 0.88→0.85. (EMPIRICAL; corr+loss)

Ключевой якорь: в твоём же пайплайне “2M continuous spacings” после **unfolding** ожидаются **mean≈1.0** и **std≈0.41–0.43** (и autocorr lag‑1 < 0). (PROVEN; sanity target)【66:3†prepare_continuous_2M.py†L10-L15】【66:0†prepare_continuous_2M.py†L45-L66】  
Отсюда жёсткий вывод: число **std_true=3.2200 почти наверняка не про unfolded spacings** (и/или ты сравниваешь разные величины/шкалы: raw gaps, кумулятивы γ, либо δ\* в другой нормировке). (HYPOTHESIS; std mismatch ↔ нормировка)  

Теперь про “RH‑перспективу”: даже если бы ты идеально поймал **GUE‑статистики**, это само по себе **не равно RH** — это максимум эмпирика про распределение тех нулей, которые ты скормил модели (и оно не фиксирует отсутствие “плохих” нулей вне линии). (PROVEN; логика задачи)

И ещё: ты сам дал критичные метрики по “операторности” памяти: **Perm Inc=1%** (ID‑детокс ок), но **Ablation Δ=0.0058** (память декоративна). (EMPIRICAL; Perm Inc/Ablation Δ) Это означает: “attention_weights → оператор” сейчас не вывозит по причинности — оператор не обязателен для loss. (EMPIRICAL→HYPOTHESIS; Ablation Δ низкий ⇒ неоператорно)

2) **Определения**  
**ρ_n=1/2+iγ_n** — нетривиальные нули ζ, параметризованные высотами γ_n.  
**s_n=γ_{n+1}−γ_n** — raw gap в координате γ.  
**Unfolding** — переход в координату u(γ), где локальная плотность выровнена и mean spacing≈1. (стандарт)  
**Variant B unfolding** — u(γ)=(γ/2π)·log(γ/(2πe)), s̃_n=u(γ_{n+1})−u(γ_n). (PROVEN; формула в пайплайне)【66:3†prepare_continuous_2M.py†L40-L52】  
**m(T)=2π/log(T/2π)** — асимптотическая средняя дистанция в raw γ‑шкале при T≈γ_n; для unfolded обычно умножают raw gap на 1/m(T). (PROVEN; стандарт)  
**Flash (SpacingMDN)** — базовый вероятностный предиктор следующего spacing через смесь (MDN).  
**Rollout** — автогенерация многошаговой траектории из one‑step модели (экспозиционный сдвиг/дрейф возможны).  
**δ\*** — целевая поправка: True−Flash.  
**corr** — корреляция предсказания с таргетом (обычно Pearson); не меряет калибровку распределения.  
**NLL** — negative log‑likelihood вероятностного предиктора; ключевая метрика для MDN.  
**CRPS** — score калибровки/качества предсказанного распределения (лучше, чем MSE для вероятностных задач).  
**PIT** — probability integral transform; по нему видно under/over‑confidence (идеал: mean≈0.5, std≈0.289).  
**KS p‑value** — тест на равномерность PIT/калибровку.  
**Perm Inc** — рост NLL (%) при случайной перестановке memory‑слотов; тест на “не читит ли по ID”.  
**Ablation Δ** — ΔNLL при выключении слота: NLL(slot_off)−NLL(base); причинность слота.  
**Grad Corr** — корреляция градиентов между слотами; высокая ⇒ co‑adaptation. (PROVEN; договорённость)【66:13†2026-1-1 6-4-18-__________________________.md†L1-L4】  
**rollout‑drift slope** — рост ошибки по горизонту (в diagnose: error_growth_slope по log‑fit). (PROVEN; реализация)【66:16†diagnose_memory_postfix.py†L9-L16】  
**block‑CV** — вариация качества по height‑блокам; если >0.1 — сдвиг/читинг по позиции. (PROVEN; порог в диагностике)【66:16†diagnose_memory_postfix.py†L67-L77】  
**rank_ratio** — доля “сигнала” в топ‑рангах (твой внутренний критерий переносимости/операторности).  
**POSTFIX memory** — порядок [data…, memory…] с причинной маской; memory видит data, data не видит memory; readout только из memory. (PROVEN; в коде/диффе)【62:4†train_mdn_postfix.py†L11-L20】【66:10†2026-1-1 6-4-18-__________________________.md†L17-L54】  
**ID‑DETOX** — slot_id_mode=permute_per_batch, чтобы Perm Inc ≤5%. (PROVEN; протокол)【62:0†2026-1-1 6-4-18-__________________________.md†L13-L20】  
**GUE (unitary)** — класс статистик спектра случайных эрмитовых матриц; для unfolded spacings mean=1, std≈0.422 (Wigner surmise). (PROVEN; стандарт)  
**Sine‑kernel** — ядро K(s)=sin(πs)/(πs), задаёт 2‑point корреляции в пределе GUE. (PROVEN; стандарт)  
**Operator extraction** — попытка восстановить “ядро/оператор” из attention/logits (например K(d)=sin(πd)/(πd)+…). (HYPOTHESIS; как цель)【66:13†2026-1-1 6-4-18-__________________________.md†L19-L22】

3) **Зависимости**  
Что у тебя точно есть / что подразумевается твоими файлами:  
- Датасет “continuous_2M”: делается из zeros/zeros2M.txt, **unfolding Variant B**, затем режется в окна **seq_len=256** и вал — “val_tail” (последние 10% по высоте). (PROVEN; пайплайн)【66:1†prepare_continuous_2M.py†L46-L63】  
- Санити‑таргеты по unfolded spacings: mean≈1, std≈0.41–0.43, autocorr(1)<0. (PROVEN)【66:3†prepare_continuous_2M.py†L10-L14】【66:1†prepare_continuous_2M.py†L36-L38】  
- POSTFIX‑архитектура и bottleneck readout только из памяти в train_mdn_postfix.py. (PROVEN)【62:4†train_mdn_postfix.py†L15-L26】

Чего НЕ хватает для твоего конкретного 44‑часового прогона (и это реально блокирует интерпретацию “4× std” и “88% потолок”):  
1) Что именно такое std=3.2200: **std чего** (raw gaps? unfolded s̃? δ\*? γ‑инкременты?) и на каком окне/сэмплинге. (HYPOTHESIS; нужен лог)  
2) Как Flash генерил rollouts: **семплинг из MDN** или берёшь mean/mode, какая temperature/entropy_reg. (HYPOTHESIS; нужен лог)  
3) Метрики калибровки на one‑step: **NLL/CRPS/PIT/KS** (а не только loss/corr). В протоколе это прямо прописано как “на каждом eval”. (PROVEN; чеклист)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】

Минимальные 3 теста/лога, которые дадут тебе 80% ответа без “перепиши всё”:  
- **T1 (Нормировка):** напечатай mean/std для (a) train target, (b) val target, (c) Flash one‑step samples, (d) Flash rollouts — *в одной и той же шкале* (raw vs unfolded явно). Сверь с sanity std≈0.41–0.43 для unfolded. (PROVEN; sanity)【66:0†prepare_continuous_2M.py†L60-L66】  
- **T2 (Калибровка):** PIT mean/std + KS p‑value + CRPS на one‑step для Flash и для corrected. (PROVEN; чеклист)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】  
- **T3 (Переносимость по высоте):** block‑CV / cross_block_test (если nll_cv>0.1 — у тебя сдвиг/читинг/нестационарность). (PROVEN; диагностика)【66:16†diagnose_memory_postfix.py†L22-L77】

(Отдельно: для “RH‑ветки” у тебя есть базовый операторный каркас Weil criterion → RH в PROSHKA_REQUEST_3.md. fileciteturn0file11)

4) **Roadmap (2–6 шагов)**  
1) **Зафиксируй шкалу**: raw s_n или unfolded s̃_n (Variant B) и перестань мешать. (HYPOTHESIS; сейчас мешаешь из‑за std=3.22)【66:3†prepare_continuous_2M.py†L40-L52】  
2) **Раздели one‑step и rollout**: меряй NLL/CRPS/PIT на one‑step и отдельно rollout‑drift slope / error_growth_slope + multi‑horizon MAE/bias. (PROVEN; инструменты есть)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】【66:16†diagnose_memory_postfix.py†L9-L16】  
3) **Сделай memory причинной** (иначе “operator extraction” — театр): POSTFIX уже задан, но тебе нужно forced‑use: FiLM/gating или aux‑proxy с ramp. (HYPOTHESIS→план; целевые метрики ниже)【62:3†2026-1-1 6-4-18-__________________________.md†L3-L15】【66:6†2026-1-1 6-4-18-__________________________.md†L7-L19】  
4) **Смести цель с “corr” на “операторные инварианты”**: Perm Inc≤5%, Ablation Δ≥0.02/slot, Grad Corr≤0.6, block‑CV<0.1, rollout‑drift slope<0.5, rank_ratio>0.5. (HYPOTHESIS; это твой критерий извлекаемости)  
5) **Только после этого**: экстракция ядра K(d) из attention/logits и попытка символической регрессии K(d)=sin(πd)/(πd)+коррекции. (HYPOTHESIS; но это хотя бы честно)【66:13†2026-1-1 6-4-18-__________________________.md†L19-L22】

**Operator Extraction (zeta spacing)**  
- Нули: ρ_n=1/2+iγ_n; gaps: s_n=γ_{n+1}−γ_n. (PROVEN; определение)  
- Нормировка (фиксируешь явно в логе):  
  - raw: s_n;  
  - или unfolded: s̃_n=u(γ_{n+1})−u(γ_n), u(γ)=(γ/2π)log(γ/(2πe)). (PROVEN; пайплайн)【66:3†prepare_continuous_2M.py†L40-L52】  
  - или через m(T)=2π/log(T/2π), T≈γ_n (стандарт). (PROVEN)  
- Оператор O_k: Domain = (последние k spacings + опц. T + опц. M0–M7‑прокси), Codomain = q(s_{n+1}|context) через **MDN** или point‑estimate. (HYPOTHESIS; твой дизайн)  
- Инварианты/аудит: Perm Inc, PIT/coverage, block‑CV по height‑блокам, rollout‑drift slope, Grad Corr, Ablation Δ_i, readout‑entropy, slot‑similarity, CRPS/NLL, rank_ratio. (HYPOTHESIS; протокол)  
- Тесты pass/fail: Perm Inc≤5%, block‑CV<0.1, rollout‑drift slope<0.5, Grad Corr<0.7, Ablation Δ_i≥0.02/slot, rank_ratio>0.5. (HYPOTHESIS; целевые пороги)  
- При провале: феномен→измерь→диагноз→дешёвый тест→фикс→ожидаемый эффект (Ablation Δ↑, similarity↓, rank_ratio↑, NLL/CRPS не хуже, Perm Inc не растёт). (HYPOTHESIS)

5) **Леммы-проверки**  
A) **No‑leakage**  
Допущения: ID‑детокс включён (slot_id_mode=permute_per_batch) и модель не держится за имена слотов. (HYPOTHESIS)  
Что меряется: **Perm Inc** = % роста NLL при случайной перестановке слотов. (PROVEN; определение)  
Как: прогон eval дважды (base vs permute), считаешь ΔNLL%. (PROVEN; протокол E4)【62:0†2026-1-1 6-4-18-__________________________.md†L13-L20】  
Вывод: Perm Inc=1% ⇒ утечки по slot‑ID почти нет, инвариантность к перестановке есть. (EMPIRICAL; Perm Inc=1%) ∎

B) **Mask‑invariant** (POSTFIX: memory видит data, data не видит memory)  
Допущения: вход [data…, memory…], причинная маска, и memory стоит справа. (PROVEN; POSTFIX)【62:4†train_mdn_postfix.py†L15-L19】  
Что меряется: (i) отсутствие влияния memory на data‑states, (ii) наличие влияния data на memory‑states. (HYPOTHESIS; измеряемо)  
Как: в POSTFIX диффе явно: memory конкатенится после data, а readout берётся только из memory_outputs справа. (PROVEN; кодовая гарантия формы)【66:10†2026-1-1 6-4-18-__________________________.md†L17-L54】  
Вывод: по архитектуре PASS, но формально проверь градиенты “head→data tokens” = 0 (иначе маска/выбор readout сломан). (HYPOTHESIS; нужен тест) ∎

C) **No‑shortcut** (голова читает только memory‑выходы)  
Допущения: bottleneck реально bottleneck: head не имеет прямого пути к data‑hidden. (PROVEN; задумка)【62:4†train_mdn_postfix.py†L19-L25】  
Что меряется: при обнулении memory (content_mode=zeroed) качество должно падать; при чтении только memory — нельзя восстановить качество без memory. (HYPOTHESIS; критерий)  
Как: ID‑only/content‑only тесты должны логироваться как ΔNLL_id_only и ΔNLL_content_only. (PROVEN; требование диагностики)【66:6†2026-1-1 6-4-18-__________________________.md†L1-L4】  
Вывод: без этих двух чисел ты не знаешь, shortcut есть или нет. (PROVEN; методологически) ∎

D) **Causality** (Ablation Δ интерпретируется)  
Допущения: слот реально влияет на предсказание, иначе “оператор” не идентифицирован. (PROVEN; смысл Ablation)  
Что меряется: **Ablation Δ_i** по слотам (ΔNLL на выключении) и связь с ростом ошибки/дрейфа. (PROVEN; метрика)  
Как: ablation по одному слоту, считаешь ΔNLL. Целевой режим E4: Ablation Δ≥0.02 хотя бы у части сидов. (PROVEN; критерий в доке)【62:0†2026-1-1 6-4-18-__________________________.md†L17-L20】  
Вывод: Ablation Δ=0.0058 ⇒ причинность слабая; “attention=оператор” сейчас не вытягивается, это декоративная память. (EMPIRICAL; Ablation Δ) ∎

6) **Разбор феномена** ("Феномен = сигнал")  

### Феномен 1: “4× std mismatch”  
Симптом: std_flash=0.8059, std_true=3.2200 (×3.996), и это пытаешься интерпретировать как “модель не ловит GUE”. (EMPIRICAL; std)  
Измерение: одна цифра std без фиксации шкалы/нормировки и без PIT/CRPS/NLL на one‑step. (EMPIRICAL; чего нет)  

Гипотезы‑диагноза:  
1) **Смешаны шкалы** (unfolded vs raw vs δ\*). (HYPOTHESIS)  
   Причина: в твоём “правильном” unfolding‑пайплайне std unfolded spacings должен быть ~0.41–0.43, т.е. ни 0.8, ни 3.22 туда не ложатся. (PROVEN; sanity target)【66:0†prepare_continuous_2M.py†L60-L66】  
2) **Rollout коллапсирует дисперсию** (one‑step может быть ок, но автогенерация сжимает). (HYPOTHESIS; rollout‑drift)  
   Это лечится только измерением drift slope / error_growth_slope и сравнением train vs rollout. (PROVEN; метрика/код)【66:16†diagnose_memory_postfix.py†L9-L16】【66:13†2026-1-1 6-4-18-__________________________.md†L5-L7】  
3) **Сэмплинг из MDN не случайный** (берёшь mean/mode, низкая temperature, или entropy_reg давит σ). (HYPOTHESIS; underdispersion)  

Самый дешёвый тест:  
- Лог “std(train spacings)” и “std(val spacings)” из того же массива, который ты называешь True, и сверка с unfolding Variant B. (PROVEN; формула)【66:3†prepare_continuous_2M.py†L40-L52】  
- One‑step PIT/KS/CRPS для Flash и corrected. (PROVEN; чеклист)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】  
- Multi‑rollout ансамблем, и error_growth_slope. (PROVEN; код)【66:16†diagnose_memory_postfix.py†L9-L16】  

Фикс/применение:  
- Если это **ошибка шкалы** → фиксируешь нормировку (raw vs unfolded), и весь “GUE‑вывод” переоцениваешь. (HYPOTHESIS; ожидаемый эффект: std_true≈0.42 если unfolded)  
- Если это **rollout‑collapse** → добавляешь rollout‑aware training (scheduled sampling / multi‑step loss), и меряешь rollout‑drift slope<0.5. (HYPOTHESIS; acceptance через drift+CRPS)  
- Если это **temperature/entropy** → калибруешь PIT (mean→0.5, std→0.289) и добиваешься совпадения std на rollout. (HYPOTHESIS; acceptance PIT/CRPS)

### Феномен 2: “Потолок 0.88 corr и отсутствие grokking”  
Симптом: corr не растёт после epoch~20, loss падает, corr даже падает. (EMPIRICAL; corr+loss)  
Измерение: ты оптимизируешь loss (скорее MSE), но отслеживаешь corr — эти цели могут конфликтовать при шуме/тяжёлых хвостах. (PROVEN; несовпадение целей)

Гипотезы‑диагноза:  
1) **12% — условно “энтропия процесса” при твоём conditioning**: ты предсказываешь условное среднее, а остаток — случайность (в терминах DPP/GUE это норм). (HYPOTHESIS для ζ; PROVEN для случайных матриц)  
   Перевод на метрики: corr может упереться, но NLL/CRPS/PIT ещё улучшаемы, если ты начнёшь моделировать распределение, а не точку. (HYPOTHESIS; нужно NLL/CRPS/PIT)  
2) **Оставшиеся 12% — хвосты/экстремальные gaps** (редкие события). MLP учит “bulk”, а хвосты режет → corr стоит. (HYPOTHESIS; проверяется PIT хвостов/quantile coverage/CRPS)  
3) **Не хватает глобального контекста/высоты T**: corrections зависят от T и медленных мод (rigidity), а у тебя memory “декоративна” (Ablation Δ=0.0058). (EMPIRICAL→HYPOTHESIS; Ablation Δ)  
   Это сразу бьётся с твоим же протоколом: без forced‑memory у тебя нет “координат состояния”. (PROVEN; смысл E4)【62:0†2026-1-1 6-4-18-__________________________.md†L17-L20】  

Самый дешёвый тест:  
- **block‑CV по высоте**: cross_block_test и смотри nll_cv>0.1? (PROVEN; диагностика)【66:16†diagnose_memory_postfix.py†L67-L77】  
- Перформанс по квантилям таргета: corr отдельно на bulk и на top‑1% |δ\*|; плюс PIT/CRPS. (HYPOTHESIS; нужно залогировать)  

Фикс/применение:  
- Переведи CorrectionNet в **вероятностную коррекцию** (микро‑MDN или хотя бы μ,logσ) и оптимизируй NLL+CRPS; смотри PIT. (HYPOTHESIS; acceptance: NLL↓, CRPS↓, PIT ближе к равномерному)  
- Если хочешь “оператор”: **форсируй память** через FiLM/gating — это прямо рекомендовано как способ поднять Ablation Δ ×10–×100 и опустить Grad Corr. (HYPOTHESIS; ожидание метрик)【62:3†2026-1-1 6-4-18-__________________________.md†L3-L15】  
- Если хочешь “регистры решета”: включай aux‑proxy M0–M7 с ramp (иначе memory останется театром). (HYPOTHESIS; стабилизирует Ablation Δ)【66:6†2026-1-1 6-4-18-__________________________.md†L7-L19】【66:6†2026-1-1 6-4-18-__________________________.md†L25-L38】

### Феномен 3: “Что 4× mismatch говорит о GUE гипотезе?”  
Симптом: ты пытаешься интерпретировать std mismatch как “GUE провал”. (EMPIRICAL; твоё чтение)  
Измерение: GUE‑сравнение корректно только в **unfolded** шкале. В твоём пайплайне unfolding фиксирован (Variant B) и sanity‑std целится в 0.41–0.43. (PROVEN; пайплайн)【66:3†prepare_continuous_2M.py†L37-L46】【66:0†prepare_continuous_2M.py†L60-L66】  

2–3 гипотезы‑диагноза (про “что именно ты промазал”):  
1) **Ты промазал не GUE, а шкалу** (unfolding/смесь высот/сравнение разных величин). (HYPOTHESIS; см. Феномен 1)  
2) **Ты ловишь short‑range repulsion, но теряешь long‑range rigidity**: по GUE короткая форма может совпадать, а глобальные метрики (number variance/Δ3/SFF) уедут — и rollout‑std тоже уедет. (HYPOTHESIS; проверка: Σ²(L), Δ3(L), SFF и rollout‑drift slope)  
3) **Flash учит маргинал, а не процесс**: one‑step NLL может быть норм, но rollout уходит (exposure bias). (HYPOTHESIS; проверка PIT/CRPS vs rollout)

Что выглядит как “идеально откалиброванный GUE” в твоих терминах:  
- unfolded mean≈1.0 и std≈0.41–0.43 (как sanity). (PROVEN; твой таргет)【66:0†prepare_continuous_2M.py†L60-L66】  
- отрицательная autocorr(1)<0 (level repulsion). (PROVEN; sanity)【66:1†prepare_continuous_2M.py†L36-L38】  
- для модели: one‑step PIT близок к равномерному + CRPS падает + block‑CV<0.1 + rollout‑drift slope низкий. (HYPOTHESIS; критерий корректной генерации)

### Феномен 4: “Оператор‑экстракция: как заставить модель учить именно оператор?”  
Симптом: ты хочешь attention_weights → оператор → спектр → RH‑валидировать. (HYPOTHESIS; цель)  
Измерение: текущая “операторность” провалена по Ablation Δ (0.0058) ⇒ attention может быть не причинным. (EMPIRICAL; Ablation Δ)

2–3 гипотезы‑диагноза:  
1) **Идентифицируемость убита универсальностью**: даже идеальные GUE‑статистики не фиксируют уникальный Hamiltonian — слишком много операторов дают тот же класс статистик. (PROVEN; логика + universality)  
2) **Ты учишь не Hamiltonian, а трансфер‑оператор процесса spacings**: это другой объект; он может быть извлекаем (kernel), но не обязан вести к Hilbert–Pólya. (HYPOTHESIS; зависит от дизайна)  
3) **Архитектура не заставляет “оператор” быть единственным решением**: раз Ablation Δ мал, сеть решает задачу без operator‑structure. (EMPIRICAL→HYPOTHESIS)

Самый дешёвый тест:  
- Форс‑memory (FiLM/gating) и смотри, растёт ли Ablation Δ и падает ли Grad Corr. (HYPOTHESIS; acceptance: Ablation Δ≥0.02, Grad Corr≤0.6)【62:3†2026-1-1 6-4-18-__________________________.md†L3-L15】  
- После этого уже есть смысл пытаться извлекать K(d) из attention logits как функцию расстояния. (HYPOTHESIS)【66:13†2026-1-1 6-4-18-__________________________.md†L19-L22】

Фиксы (оценка твоих вариантов a/b/c):  
a) **Hermitian constraint на attention** — полезно как структурное ограничение (самосопряжённость), но само по себе не решает идентифицируемость. (HYPOTHESIS; acceptance через rank_ratio↑, Ablation Δ↑, block‑CV не хуже)  
b) **Spectral loss к GUE kernel** — годится как sanity‑регуляризатор “не уезжай от sine‑kernel”, но как endgame почти гарантирует, что ты просто восстановишь универсальный K(d) (и это не RH). (PROVEN; неуникальность)  
c) **Тренировка на raw zeros** — ближе к Hilbert–Pólya, но риск читинга по индексу/высоте огромный; это лечится только жёстким block‑CV и инвариантностями + явной формой оператора. (HYPOTHESIS; acceptance block‑CV<0.1)【66:16†diagnose_memory_postfix.py†L67-L77】

Мой выбор по шансам “экстрактнуть оператор”:  
- **Не “attention‑based correction” поверх всего**, а **явный операторный слой**: параметризуешь K(d) (или Toeplitz‑символ) и заставляешь модель объяснять данные через него; attention тогда становится не “внутренним артефактом”, а самим объектом. (HYPOTHESIS; acceptance: Ablation Δ≥0.02, rank_ratio>0.5, Perm Inc≤5%)  
- И второй слой: добавляешь **arithmetic supervision** (хотя бы прокси M0–M7 типа rigidity/Toeplitz‑stability) как “якоря” против чистой GUE‑универсальности. (HYPOTHESIS; acceptance: block‑CV падает, переносимость по height растёт)【66:6†2026-1-1 6-4-18-__________________________.md†L25-L38】

### Феномен 5: “Есть ли смысл продолжать grokking?”  
Симптом: “grokking не случился”, корреляция вышла на плато рано. (EMPIRICAL; corr plateau)  
Диагноз: grokking полезен, когда есть **алгоритмическая структура + режим переобучение→поздняя генерализация**. Здесь ты видишь “loss↓ без corr↑” — это чаще режим “подгонка дисперсии/шумового компонента”, а не открытие новой структуры. (HYPOTHESIS; нужно подтвердить NLL/CRPS/PIT)  
Дешёвый тест: включи early stopping по val_nll и смотри, есть ли поздний “перелом” в block‑CV/rollout‑drift slope. (HYPOTHESIS; acceptance: block‑CV<0.1 и drift slope падает)【66:16†diagnose_memory_postfix.py†L67-L77】  
Фикс: grokking как “бесконечно долго гонять” — низкий ROI; лучше короткие прогоны + структурные ограничения (оператор/память/калибровка). (HYPOTHESIS)

7) **Audit/Edge-check**  
- **Unfolding sanity**: сверяй mean≈1 и std≈0.41–0.43 на том массиве, который называешь True. (PROVEN; target)【66:0†prepare_continuous_2M.py†L60-L66】  
- **Формула unfolding**: Variant B u(γ)=(γ/2π)log(γ/(2πe)) — если ты где-то используешь m(T) наоборот, получишь “магический” ×4 масштаб. (HYPOTHESIS; типовая ошибка)【66:3†prepare_continuous_2M.py†L40-L52】  
- **GOE/GUE путаница**: в пайплайне на графике “GUE Wigner surmise” стоит формула (π/2)s exp(−πs²/4) — это GOE‑сюрмайз, а не GUE. (EMPIRICAL; по коду)【66:12†prepare_continuous_2M.py†L58-L63】  
  Если ты на это ориентировался при выводах — ты сам себе подложил мину. (HYPOTHESIS)  
- **One‑step vs rollout mismatch**: без PIT/CRPS/KS на one‑step и без ансамбля rollouts ты не знаешь, где ломается дисперсия. (PROVEN; чеклист)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】  
- **Height‑shift**: block‑CV / cross_block_test; порог nll_cv>0.1 — красный флаг. (PROVEN)【66:16†diagnose_memory_postfix.py†L67-L77】  
- **Mask/readout shortcut**: POSTFIX + readout only from memory должно выполняться буквально, как в диффе. (PROVEN; схема)【66:10†2026-1-1 6-4-18-__________________________.md†L17-L54】  
- **Slot co‑adaptation**: Grad Corr; если стабильно >0.8 — слоты не независимы. (PROVEN; договорённость)【66:13†2026-1-1 6-4-18-__________________________.md†L1-L4】  
- **ID‑читинг**: ΔNLL_id_only и ΔNLL_content_only должны логироваться. (PROVEN)【66:6†2026-1-1 6-4-18-__________________________.md†L1-L4】

8) **Вывод + Next Actions**  

**Action 1: Зафиксировать нормировку и пересчитать std на правильной величине**  
- Why: сейчас твой “4× mismatch” не интерпретируем без шкалы; в unfolded мире std должен быть ~0.42. (PROVEN; target)【66:0†prepare_continuous_2M.py†L60-L66】  
- Acceptance: в логах явно написано “raw vs unfolded”, и для unfolded True: mean≈1, std≈0.41–0.43. (PROVEN)【66:0†prepare_continuous_2M.py†L60-L66】  
- Failure mode: после фикса всё равно std_true≈3.2 ⇒ ты на самом деле меряешь не spacings, а что-то другое (δ\*/γ‑инкременты). (HYPOTHESIS)

**Action 2: Перевести оценку с corr на NLL/CRPS/PIT + KS (one‑step) и добавить ансамбль rollouts**  
- Why: corr не видит калибровку и легко “замораживается”; NLL/CRPS/PIT покажут underdispersion и хвосты. (PROVEN; методология)  
- Acceptance: на eval всегда есть PIT mean/std, KS p‑value, CRPS и γ‑rollout до h=1000. (PROVEN; чеклист)【66:15†2025-12-29 23-31-56-__________________.md†L1-L5】  
- Failure mode: one‑step калиброван, но rollout разваливается ⇒ это exposure bias, нужна multi‑step training. (HYPOTHESIS)

**Action 3: Диагностика переносимости по высоте (block‑CV) и отсечение читинга**  
- Why: если модель “подучила индекс/высоту”, operator extraction бессмысленен. (PROVEN; логика)  
- Acceptance: cross_block_test даёт nll_cv<0.1 и has_distribution_shift=False. (PROVEN; критерий)【66:16†diagnose_memory_postfix.py†L67-L77】  
- Failure mode: nll_cv>0.1 ⇒ добавляй conditioning на T явно или жёстче режь датасет/маскируй позиционку. (HYPOTHESIS)

**Action 4: Форсировать причинную память (иначе “оператор” не учится)**  
- Why: Ablation Δ=0.0058 — это “memory декоративна”. (EMPIRICAL)  
- Что делать:  
  - FiLM/gating так, чтобы слоты **модулировали backbone**. (HYPOTHESIS; recommended)【62:3†2026-1-1 6-4-18-__________________________.md†L3-L15】  
  - + aux‑proxy M0–M7 с ramp schedule (иначе убьёшь обучение). (HYPOTHESIS; протокол)【66:6†2026-1-1 6-4-18-__________________________.md†L7-L19】【66:6†2026-1-1 6-4-18-__________________________.md†L25-L38】  
  - + ID‑only/content‑only тесты (ΔNLL_id_only/ΔNLL_content_only). (PROVEN)【66:6†2026-1-1 6-4-18-__________________________.md†L1-L4】  
- Acceptance (метрики): Ablation Δ_i ≥0.02 хотя бы у части сидов; Grad Corr mean ≤0.6; Perm Inc ≤5% не растёт. (HYPOTHESIS; E4‑целевые)【62:0†2026-1-1 6-4-18-__________________________.md†L17-L20】  
- Failure mode: Ablation Δ не растёт ⇒ backbone всё “съедает”, и operator‑слой надо делать явным (не через implicit attention). (HYPOTHESIS)

**Action 5: Следующий эксперимент “под RH”: явный kernel‑operator вместо “выковыривать attention постфактум”**  
- Why: иначе ты снова получишь универсальный “почти‑sine” без идентифицируемости и без причинности. (PROVEN; universality)  
- План: параметризуешь K(d) напрямую (симметричный/Hermitian), обучаешь на (i) one‑step NLL/CRPS/PIT, (ii) multi‑scale статистики (rigidity/Δ3‑proxy), (iii) переносимость block‑CV. (HYPOTHESIS)  
- Acceptance: rank_ratio>0.5, block‑CV<0.1, rollout‑drift slope<0.5, Ablation Δ≥0.02. (HYPOTHESIS)  
- Failure mode: K(d) схлопывается в тривиал ⇒ твои лоссы не заставляют его быть оператором; усиливай спектральный/rigidity‑loss. (HYPOTHESIS)

**Action 6: Grokking — оставить как инструмент, но не как “путь”**  
- Why: 44 часа без роста corr — это не “ещё чуть‑чуть и прозреет”, это “объектив/лосс не туда смотрит”. (EMPIRICAL→HYPOTHESIS)  
- Acceptance: grokking имеет смысл только если ты видишь поздний перелом в block‑CV/rollout‑drift slope при фиксированных условиях. (HYPOTHESIS)  
- Failure mode: перелома нет ⇒ закрываешь тему и переходишь на operator‑layer + явные ограничения. (HYPOTHESIS)

9) **"Язык линзы"**  
Фон у тебя сейчас плавает: шкала/калибровка не зафиксированы — поэтому линза “сжимает” дисперсию (rollout‑drift). (HYPOTHESIS; нужен PIT/CRPS)  
Фокус не держится: Ablation Δ маленький ⇒ регистры решета не несут причинной массы, operator не проявляется. (EMPIRICAL; Ablation Δ)  
Сито должно работать так: окно → memory‑регистры (M0–M7) → следующий шаг, и каждый регистр незаменим (Ablation Δ↑) при низком слипания (Grad Corr↓). (HYPOTHESIS; целевые метрики)  
Когда это случится, attention/logits можно трактовать как ядро K(d) и уже пытаться вытащить формулу “sin(πd)/(πd)+…” без самообмана. (HYPOTHESIS)【66:13†2026-1-1 6-4-18-__________________________.md†L19-L22】

