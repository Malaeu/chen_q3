# Proof audit plan

https://chat.openai.com/c/69818c72-62b4-8389-b99e-b59375f8e457

## ASSISTANT
To make a Clay‑level RH proof survive real peer scrutiny, treat it like a safety‑critical system: every definition is frozen early, every lemma is a contract with explicit dependencies, and every “bridge” (normalization ↔ operator form ↔ compact limit ↔ Weil criterion) is independently audited. The fastest path to confidence is a dual pipeline: (1) rigorous human line‑by‑line proof audit with a revision log, and (2) machine verification (Lean) that forces all hidden assumptions to surface.

Your ERS/critical‑path pilot is exactly the right steering wheel: use it to *sequence* work so that the highest‑impact blockers (the ones that gate the rest of the graph) are verified first, not last. fileciteturn0file24

## Actionable step‑by‑step plan

1. **Freeze the exact theorem statement, normalization, and hypothesis stack.**  
   **Action:** Create a single source of truth: [STATEMENT_SHEET] (formal RH target), [ASSUMPTION_STACK] (e.g., T0 + A1′ + A2 + A3 + RKHS), and [NOTATION_GLOSSARY] (every symbol defined once, with domain/codomain).  
   **Verify:** Two independent readers can trace every later lemma back to this sheet with *no* “implicit convention” patches; all changes afterward require an entry in [REVISION_LOG] with “why/impact.”

2. **Build (and commit) the dependency graph + risk register as the project’s control plane.**  
   **Action:** From the pilot graph, produce [DEPENDENCY_GRAPH] (nodes/edges), [CRITICAL_PATH] (minimal blocking set for the main theorem), and [RISK_REGISTER] (top ERS nodes with failure modes, required artifacts, owners).  
   **Verify:** (i) Every manuscript theorem/lemma appears as a node; (ii) graph is acyclic; (iii) each high‑ERS node has a written “attack plan” and acceptance criteria, not just a title.

3. **Write a proof skeleton that mirrors the dependency graph, not the narrative order.**  
   **Action:** Draft [PROOF_DRAFT] as a sequence of lemmas in *topological order* (dependencies first). For each lemma: statement, inputs, a 5–10 line proof sketch, and a list of “nontrivial facts used.”  
   **Verify:** For each lemma, you can point to (a) where each input is proved, and (b) where each nontrivial fact is established or cited; no lemma depends on anything “later.”

4. **Create a Lean “spec skeleton” that matches [PROOF_DRAFT] one‑to‑one.**  
   **Action:** Produce [LEAN_SKELETON] with theorem/lemma statements only (placeholders allowed initially), named identically to [PROOF_DRAFT] items, plus a mapping table [PAPER↔LEAN MAP].  
   **Verify:** `lake build` succeeds; every placeholder is tagged with a semantic identifier and linked back to exactly one line item in [PROOF_DRAFT]; there are **zero** “mystery sorries.”

5. **Audit the highest‑risk nodes first (the ones that gate everything).**  
   **Action:** For each top ERS node on the critical path, create a dedicated packet: [LEMMA_AUDIT/<id>.md] containing (i) restatement, (ii) proof rewritten in smallest accepted “community” steps, (iii) edge cases, (iv) explicit constants/budgets, (v) a Lean strategy (which library facts, which reductions).  
   **Verify:** A second checker can reproduce the lemma from the packet alone; all constants are justified symbolically (no “numerical plausibility”); the packet lists *exactly* what would falsify the lemma.

6. **Formalize the “primitive facts” library before attempting global assembly.**  
   **Action:** Build [PRIMITIVES_LIBRARY] (Lean + prose index) for the irreducible analytic tools your chain uses (e.g., special‑function bounds, Toeplitz eigenvalue stability, RKHS norm/trace caps, basic inequalities).  
   **Verify:** Each primitive is (a) formally proved in Lean or (b) imported from a well‑accepted library result with a stable citation; nothing in the main chain depends on ad‑hoc “handwaving primitives.”

7. **Lock down all bridge equivalences (where normalization errors usually hide).**  
   **Action:** Produce [BRIDGE_LEMMAS] covering: Guinand–Weil crosswalk, variable changes/Jacobians, weight conventions (doubled vs symmetric placement), and Rayleigh/operator identifications.  
   **Verify:** In Lean, the *two* formulations (functional vs operator form) are definitionally connected by explicit lemmas; reviewers can follow the bridge without “interpretation.”

8. **Prove the compact‑level transfer with explicit continuity/density criteria.**  
   **Action:** Create [COMPACT_MODULES] that contains the compact window definitions, the generator cone, the density argument, and the continuity/Lipschitz modulus argument—each with explicit quantifiers and norms.  
   **Verify:** For each compact parameter K, you can certify: (i) the generator cone is dense in the intended topology, and (ii) Q is continuous w.r.t. that topology. In Lean: both statements compile with the same topology/norm choices used later (no mismatch of spaces).

9. **Assemble the main positivity theorem as “budget algebra,” not prose.**  
   **Action:** Write [MAIN_ASSEMBLY] as a short sequence: “symbol floor” − “discretization loss” − “prime cap” ≥ margin, then “positivity on generators ⇒ positivity on compact,” then “union over K.”  
   **Verify:** Every inequality in the margin chain has a lemma name and a dependency pointer; in Lean the final theorem has **no** remaining placeholders; arithmetic on constants is machine‑checked (no hand arithmetic).

10. **Finalize the RH linkage and produce a submission‑ready verification pack.**  
   **Action:** Prepare [WEIL_LINKAGE] (Weil criterion statement in your normalization + its use), and a [FINAL_VERIFICATION_PACK] containing: [MANUSCRIPT], [LEAN_REPO], [PAPER↔LEAN MAP], [REVISION_LOG], and a clearly separated [SANITY_CHECKS] section for any numerics that are *non‑premises*.  
   **Verify:** A fresh third party can (i) build the Lean project from a clean checkout, (ii) read the manuscript end‑to‑end without needing private notes, and (iii) confirm the logical chain uses no computational step as an axiom.

If you want to push this into “industrial strength,” the next move is to turn the risk register into *gates*: nothing downstream merges until the upstream high‑ERS node has (a) a completed audit packet, (b) a Lean proof (or explicitly accepted imported theorem), and (c) a second‑review sign‑off recorded in [REVIEW_LOG].

