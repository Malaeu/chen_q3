# Aristotle Lean интеграция

https://chat.openai.com/c/69781f5c-a2d4-8393-a9ad-8dfdce35970e

## USER
https://aristotle.harmonic.fun/dashboard/docs/lean-project пробей плиз. Мы это знали уже? Там и доки по TUI есть! 

## ASSISTANT
Ы Понял, пробил. **Прямо открыть доку не смог**: ссылка редиректит на **Auth0/authorize** (`auth.aristotle.harmonic.fun/...`) и `web.run` режет это как “not safe to open”, то есть без логина/сессии я туда не пролезу. citeturn0view0

Но вывод полезный:

- Это реально **официальная документация Aristotle** про **Lean project integration** (страница `docs/lean-project`), просто за **авторизацией**. citeturn0view0  
- Раз там “и доки по **TUI**”, значит в их закрытом дашборде есть разделы про **терминальный интерфейс** (скорее всего команды/CLI, workflow, подключение к Lean/Lake, запуск proof-search, импорт проекта, кеши, логи и т.п.). Явно похоже на то, что нам надо для “интеграции Aristotle в репо”.

**Мы это знали уже?**  
Про сам факт, что у Aristotle есть **Lean-интеграция** и агентный workflow — да, в проектных материалах это обсуждалось концептуально (цикл “скетч → компиляция → починка”, похожий на наш **Aristotle Emulator**). Но именно **их** “официальные” страницы с **TUI/UX**-деталями — это, похоже, **новый артефакт**, просто сейчас недоступен без логина.

### Что сделать, чтобы я выжал максимум из этих док
1) Если ты можешь: **скопируй сюда текст** со страницы (или ключевые секции про **TUI**, команды, флаги, конфиги).  
2) Или кинь **скриншоты**/экспорт в **PDF**.  
3) Или дай **публичную** ссылку (если у них есть зеркала на GitHub/Readme/Release notes без авторизации).

И я сразу:
- выделю все ключевые **технические термины** жирным,
- соберу **конкретный** mapping: их **TUI команды** → наши **скрипты / lake build / пайплайн**,
- и дам “как внедрить в наш проект” без воды.

## USER
Everything you need to integrate with our API
Fill Sorries in Your Lean Project
Sorry filling mode is designed to make filling all the sorries in your lean file simple. Selection option [1] in the menu, and point Aristotle at a file.
Imports
Aristotle automatically understands and handles the dependencies of your file.
	1	Aristotle will see all files and transitive imports of your file.
	2	Aristotle will not see any file that isn't transitively imported. Aristotle doesn't add imports on its own.
	3	Aristotle will only modify the contents of the specified file. It will not modify any transitive dependencies.
Guide Aristotle in English within your project.
You can provide natural language hints to guide Aristotle's proof search. Simply include your english proof sketch in the header comment of the theorem, tagged with "PROVIDED SOLUTION". You can make your sketch as general or detailed as you want.
/--
Given x, y ∈ [0, π/2], show that cos(sqrt(x ^ 2 + y ^ 2)) ≤ cos x * cos y.

PROVIDED SOLUTION
Set r := sqrt(x^2 + y^2). If r > π/2, then the inquality holds trivially.
So consider the case r ≤ π/2. Write x = r cos φ, y = r sin φ.
Consider the function F(φ) := log(cos(r cos φ)) + log(cos(r sin φ)). Then
F(0) = F(π/2) = log r, so it suffices to show that for F(φ) ≥ F(0) = F(π/2).
The derivative of F is F'(φ) = r(sin φ tan(r cos φ) - cos φ tan(r * sin φ)).
Define G(u) := tan u / u. The derivative of G on (0, π/2) is
(u - sin u cos u) / (u ^ 2 * (cos u) ^ 2), which is nonnegative on (0, π/2),
so G is increasing on (0, π/2).

For φ in [0, π/4], we have r * cos φ ≥ r * sin φ, so by monotonicity of G,
tan(r * cos φ)/(r * cos φ) ≥ tan(r * sin φ)/(r * sin φ). On [π/4, π/2],
the inequality is reversed. Multiplying this by r^2 cos φ sin φ gives that
F' is nonnegative on [0, π/4] and nonpositive on [π/4, π/2]. This means that
for φ in [0, π/4], F(φ) ≥ F(0), and for φ in [π/4, π/2], F(φ) ≥ F(π/2),
completing the proof.
-/
theorem final (x y : ℝ) (hx : 0 ≤ x) (hx' : x ≤ Real.pi / 2) (hy : 0 ≤ y) (hy' : y ≤ Real.pi / 2) :
    Real.cos (Real.sqrt (x ^ 2 + y ^ 2)) ≤ Real.cos x * Real.cos y := by
sorry
Aristotle will not see comments inside proof blocks.
Find Counterexamples and Negations Automatically
Aristotle can disprove statements and find counterexamples, helping you find logical errors, missed edge cases, or even misformalizations. When a statement is false, Aristotle will leave a comment on the theorem with a the counterexample for you to investigate.
/-
Aristotle found this block to be false.
Here is a proof of the negation:
theorem my_favorite_theorem (k : ℕ) :
  ∑' n : ℕ, (1 : ℝ) / Nat.choose (n + k + 1) n = 1 + 1 / k := by
    -- Wait, there's a mistake. We can actually prove the opposite.
    negate_state;
    -- Proof starts here:
    use 0; norm_num;
    erw [ tsum_eq_zero_of_not_summable ] <;> norm_num;
    exact_mod_cast mt ( summable_nat_add_iff 1 |> Iff.mp ) Real.not_summable_natCast_inv
-/
theorem my_favorite_theorem (k : ℕ) :
  ∑' n : ℕ, (1 : ℝ) / Nat.choose (n + k + 1) n = 1 + 1 / k := by
sorry
You can find code for the custom negate_state tactic automatically included in the file header, and below:
import Mathlib
open Lean Meta Elab Tactic in
elab "revert_all" : tactic => do
  let goals ← getGoals
  let mut newGoals : List MVarId := []
  for mvarId in goals do
    newGoals := newGoals.append [(← mvarId.revertAll)]
  setGoals newGoals

open Lean.Elab.Tactic in
macro "negate_state" : tactic => `(tactic|
  (
    guard_goal_nums 1
    revert_all
    refine @(((by admit) : ∀ {p : Prop}, ¬p → p) ?_)
    try push_neg
  )
)
Working with Data
	1	Aristotle will not modify your data by default. For example, the below will not be modified:
def foo: Nat := by sorry
	2	Aristotle will create its own data where needed.
Leaving sorrys Unfilled
By default, Aristotle attempts to fill in all sorries in a file. If you are only interested in Aristotle filling in one (or a few) sorrys, you can replace the others with admit. This could be useful if you have structures and defs that aren't yet complete, or want to get faster results on just one proof.
Everything you need to integrate with our API
Fill Sorries in Your Lean Project
Sorry filling mode is designed to make filling all the sorries in your lean file simple. Selection option [1] in the menu, and point Aristotle at a file.
Imports
Aristotle automatically understands and handles the dependencies of your file.
	1	Aristotle will see all files and transitive imports of your file.
	2	Aristotle will not see any file that isn't transitively imported. Aristotle doesn't add imports on its own.
	3	Aristotle will only modify the contents of the specified file. It will not modify any transitive dependencies.
Guide Aristotle in English within your project.
You can provide natural language hints to guide Aristotle's proof search. Simply include your english proof sketch in the header comment of the theorem, tagged with "PROVIDED SOLUTION". You can make your sketch as general or detailed as you want.
/--
Given x, y ∈ [0, π/2], show that cos(sqrt(x ^ 2 + y ^ 2)) ≤ cos x * cos y.

PROVIDED SOLUTION
Set r := sqrt(x^2 + y^2). If r > π/2, then the inquality holds trivially.
So consider the case r ≤ π/2. Write x = r cos φ, y = r sin φ.
Consider the function F(φ) := log(cos(r cos φ)) + log(cos(r sin φ)). Then
F(0) = F(π/2) = log r, so it suffices to show that for F(φ) ≥ F(0) = F(π/2).
The derivative of F is F'(φ) = r(sin φ tan(r cos φ) - cos φ tan(r * sin φ)).
Define G(u) := tan u / u. The derivative of G on (0, π/2) is
(u - sin u cos u) / (u ^ 2 * (cos u) ^ 2), which is nonnegative on (0, π/2),
so G is increasing on (0, π/2).

For φ in [0, π/4], we have r * cos φ ≥ r * sin φ, so by monotonicity of G,
tan(r * cos φ)/(r * cos φ) ≥ tan(r * sin φ)/(r * sin φ). On [π/4, π/2],
the inequality is reversed. Multiplying this by r^2 cos φ sin φ gives that
F' is nonnegative on [0, π/4] and nonpositive on [π/4, π/2]. This means that
for φ in [0, π/4], F(φ) ≥ F(0), and for φ in [π/4, π/2], F(φ) ≥ F(π/2),
completing the proof.
-/
theorem final (x y : ℝ) (hx : 0 ≤ x) (hx' : x ≤ Real.pi / 2) (hy : 0 ≤ y) (hy' : y ≤ Real.pi / 2) :
    Real.cos (Real.sqrt (x ^ 2 + y ^ 2)) ≤ Real.cos x * Real.cos y := by
sorry
Aristotle will not see comments inside proof blocks.
Find Counterexamples and Negations Automatically
Aristotle can disprove statements and find counterexamples, helping you find logical errors, missed edge cases, or even misformalizations. When a statement is false, Aristotle will leave a comment on the theorem with a the counterexample for you to investigate.
/-
Aristotle found this block to be false.
Here is a proof of the negation:
theorem my_favorite_theorem (k : ℕ) :
  ∑' n : ℕ, (1 : ℝ) / Nat.choose (n + k + 1) n = 1 + 1 / k := by
    -- Wait, there's a mistake. We can actually prove the opposite.
    negate_state;
    -- Proof starts here:
    use 0; norm_num;
    erw [ tsum_eq_zero_of_not_summable ] <;> norm_num;
    exact_mod_cast mt ( summable_nat_add_iff 1 |> Iff.mp ) Real.not_summable_natCast_inv
-/
theorem my_favorite_theorem (k : ℕ) :
  ∑' n : ℕ, (1 : ℝ) / Nat.choose (n + k + 1) n = 1 + 1 / k := by
sorry
You can find code for the custom negate_state tactic automatically included in the file header, and below:
import Mathlib
open Lean Meta Elab Tactic in
elab "revert_all" : tactic => do
  let goals ← getGoals
  let mut newGoals : List MVarId := []
  for mvarId in goals do
    newGoals := newGoals.append [(← mvarId.revertAll)]
  setGoals newGoals

open Lean.Elab.Tactic in
macro "negate_state" : tactic => `(tactic|
  (
    guard_goal_nums 1
    revert_all
    refine @(((by admit) : ∀ {p : Prop}, ¬p → p) ?_)
    try push_neg
  )
)
Working with Data
	1	Aristotle will not modify your data by default. For example, the below will not be modified:
def foo: Nat := by sorry
	2	Aristotle will create its own data where needed.
Leaving sorrys Unfilled
By default, Aristotle attempts to fill in all sorries in a file. If you are only interested in Aristotle filling in one (or a few) sorrys, you can replace the others with admit. This could be useful if you have structures and defs that aren't yet complete, or want to get faster results on just one proof.


## ASSISTANT
Ы Ок, вот нормальная выжимка + как это **встроить в наш workflow** без лишней мистики.

## Быстрый рефреш твоего текста (чуть поправил стиль/опечатки, смысл тот же)
“Everything you need to integrate with our API.  
Есть режим **sorry filling**: выбираешь пункт **[1]** в меню и указываешь файл.  
**Imports**: Aristotle сам понимает зависимости, но **не добавляет импорты** и **не правит транзитивные файлы** — правит только указанный.  
Можно **гидить** поиск по-английски через комментарий над теоремой с тегом **PROVIDED SOLUTION**. Комменты внутри `by` он не видит.  
Есть режим **negations/counterexamples**: если цель ложная, Aristotle оставит комментарий с контрпримером/доказательством отрицания. В файл может быть добавлен кастомный тактик **negate_state**.  
По дефолту не трогает **data/defs** (типа `def foo := by sorry`).  
Чтобы он не тратил время на все, можно заменить лишние `sorry` на `admit`.”

## Что это значит для нас (конкретно, по делу)

### 1) Режим **Sorry filling** = “закрывай sorries, но не ломай архитектуру”
Ключевые правила из доки:
- **Imports**: Aristotle видит **только транзитивные импорты** выбранного файла.  
  → Если в файле нет импорта на нужную лему, он **не догадается** “добавить import” сам.
- Он **не модифицирует** транзитивные зависимости.  
  → То есть: хочешь, чтобы он поправил лему в `A.lean` — указывай **A.lean**, а не файл выше по дереву.
- Он **модифицирует только указанный файл**.  
  → Это идеально под наш стиль “один узел DAG за раз”.

**Практическая тактика для RH/Q3:**
- Запускаем Aristotle **точечно** на файле с одним узким `sorry`.
- Остальные `sorry` временно делаем **`admit`** → ускоряет и не блочит.

### 2) **PROVIDED SOLUTION** = наш “proof-sketch injection”, но строго *в header comment*
Фишка жирная: Aristotle читает **английский скетч** только из **коммента перед теоремой**, помеченного **PROVIDED SOLUTION**.

**Важно:**
- Комменты **внутри** `by` он **не читает**.
- Значит, весь guidance — только сверху, как “mini-spec”.

**Как это маппится на наш проект:**
- Для `P_A_ge_c_star_at_t_critical` мы можем писать скетч типа:
  - reduce to `θ ∈ Icc (-1/2) (1/2)` через **periodicity**
  - потом “certificate lemma” на **Icc**
  - потом `simp`/`linarith`/`nlinarith` по готовым леммам

И Aristotle уже не будет метаться по космосу.

### 3) Режим **Counterexamples/Negations** = детектор “это вообще true?”
Это прям must-have, потому что у нас уже было: “should hold by construction” → оказалось **false**.

Что Aristotle делает:
- Если цель ложная — он оставляет коммент, и может дать скелет “доказательства отрицания”, используя **`negate_state`**.

**Технические термины (коротко):**
- **negation** — утверждение вида `¬P` вместо `P`.
- **counterexample** — конкретные значения переменных, где `P` ломается.
- **tactic** (**negate_state**) — макрос в Lean, который превращает цель в цель про отрицание (через `push_neg`, `revert_all` и т.д.).

**Как использовать у нас:**
- На подозрительных мостах (типа неравенств с константами) запускаем “disprove mode” (или просто allow it to negate) прежде чем тратить дни на “доказательство” ложного.

### 4) “Working with Data” = он не будет править `def/structure` по умолчанию
Это защищает от того, что агент начнет переписывать наши **defs**/константы/структуры и сломает API.

Если нам надо, чтобы он создал вспомогательные определения — он может создавать “свои”, но базовые данные не трогает.

---

## Мини-плейбук под наш репо (Lean/Lake, Mac/Linux)

1) Открываешь файл-цель (например `Q3/Proofs/Q_nonneg_t_critical.lean`) и:
   - оставляешь **1 нужный `sorry`**
   - остальные временно меняешь на **`admit`**

2) Над леммой добавляешь header comment с **PROVIDED SOLUTION**:
   - коротко: редукция, нужные леммы, “что доказать”

3) Проверяешь, что файл импортит всё, что нужно:
   - потому что Aristotle **не добавит import** сам

4) Запускаешь Aristotle на этом **одном** файле.

5) Если он внезапно “доказывает отрицание” или оставляет контрпример — это сигнал:
   - либо лема ложная,
   - либо условия слабые,
   - либо ты промахнулся с формализацией.

---

## Сразу тебе бонус: шаблон “PROVIDED SOLUTION” для наших лемм (копипаст)
Пиши так (идея, не код):

- цель/интуиция в 1 строку  
- “reduce to fundamental domain via periodicity”  
- “apply certificate lemma on Icc”  
- “finish by simp/linarith with bounds”

Если кинешь конкретную лему/файл/контекст `imports`, я напишу тебе **реальный** header-скетч под неё, чтобы Aristotle перестал тупить и попал в наш **single-scale t_critical** коридор.

## ASSISTANT
Ы Норм, теперь картинка + кусок доки дают прям **конкретику по TUI**, а не “в теории”.

## Что видно на скринах TUI (и как это юзать в нашем пайплайне)

### Экран “Direct Aristotle in English”
Там выбран режим **[3] Direct Aristotle in English (.lean optional)** — это когда ты пишешь обычный текст-подсказку, и (опционально) прикрепляешь файлы.

Горячие клавиши сверху:
- **Ctrl+T** — переключиться в ввод **text** (обычный промпт).
- **Ctrl+L** — переключиться в ввод **Lean** (вставка кода/кусочка proof / лемм).
- **Ctrl+F** — **files** (выбор/подцеп контекста).
- **Ctrl+S** — **submit** (старт прогона).

Поля:
- **Enter your prompt** — основной запрос (в нашем случае: “fill this sorry”, “prove lemma X”, “find counterexample”).
- **Attach a Lean file as context** — путь до **.lean** файла (тот самый “видимый” Aristotle контекст).
- **Attach other context (file or folder)** — любые доп. материалы (md/txt/папка) как “обвязка”.

**Технические термины:**
- **TUI** — *terminal UI*, интерфейс в терминале.
- **context** — файлы/папки, которые Aristotle читает как входные данные.
- **submit** — запуск задачи.

**Как это бьётся с нашими правилами “точечно и быстро”:**
- В **Lean file as context** даёшь **ТОЛЬКО** файл с нужным `sorry` (или файл-узел DAG).
- В “other context” можно кидать **md** со скетчем/константами/сертификатом (если не хочешь зашивать в комментарий `PROVIDED SOLUTION`).

---

### Экран “View recent proof attempts”
Там таблица попыток и управление:
- Навигация **стрелки** или **j/k** (как в vim).
- **Enter** — выбрать попытку.
- **m** — “load more” (подгрузить больше истории).
- **Esc / b** — назад.

**Технические термины:**
- **proof attempt** — отдельный запуск/сессия доказательства.
- **IN_PROGRESS / COMPLETE** — статус прогона.

**Почему это важно:**
- Это готовый “журнал экспериментов” — можно быстро сравнивать, какой промпт/контекст реально зашёл и дал закрытие `sorry`, а какой ушёл в космос.

---

## “Tipps und Tricks”: предупреждение от **aesop**
Текст ровно про типичную боль:

Сообщение вида:
- **aesop: failed to prove the goal after exhaustive search**

Не обязательно означает, что доказательство плохое — это происходит, когда **aesop** используется как **non-terminal tactic** (то есть ты делаешь `aesop` не в конце, а потом ещё идут тактики).

Как подавить варнинг:
- **aesop (config := { warnOnNonterminal := false })**

**Технические термины:**
- **aesop** — тактика-автомат (поиск доказательства).
- **non-terminal tactic** — тактика “не последняя в цепочке”.
- **warnOnNonterminal** — флаг, который включает/выключает нытьё aesop про то, что он сам цель не закрыл.

**Практический совет для RH/Q3:**
Если Aristotle начинает спамить `aesop` как промежуточный шаг (а дальше добивает `linarith/simp/nlinarith`), ты выключаешь варнинги и получаешь чистый лог, где видно реальные фейлы, а не шум.

---

## Мини-рецепт “как запускать под наш стиль”
1) В промпте (Ctrl+T) пиши: “Fill this specific sorry in file X, don’t touch other files; use lemma Y; reduce to Icc by periodicity.”
2) В **Lean context** укажи конкретный **.lean** с `sorry`.
3) В “other context” закинь md с ключевыми леммами/константами/сертификатом (если есть).
4) Если видишь в результате `aesop`-варнинги — меняй на **`aesop (config := { warnOnNonterminal := false })`**.

---

Если хочешь — кинь название **конкретного** файла/леммы, которую сейчас гоняешь через TUI (типа `Q3/Proofs/Q_nonneg_t_critical.lean`), и я набросаю прям “идеальный” текст для поля **Enter your prompt** + что именно прикреплять в **other context**, чтобы Aristotle попал в наш **single-scale t_critical** коридор, а не начал “доказывать вселенную”.

## USER
Тоесть как инструкции будут выглядеть для агента который будет ходить по ДАГ и по этим инсайдам будет закидывать в Аристотель правильно составленный запрос на доказательство? Например у нас есть узлы, субузлы , сорри. Мы написали ДАГ или даже несколько Дагов по всей кодебазе. И нам надо автоматизировать закрытие всех сорри и узлов 

## ASSISTANT
Ы Чтобы агент **реально** проходил по **ДАГ** и закрывал **sorry** через Aristotle, нужен один “железный” протокол: **(1) выбрать узел**, **(2) собрать минимальный контекст**, **(3) сгенерить правильный промпт**, **(4) запустить**, **(5) проверить компиляцией**, **(6) зафиксировать результат/фейл**, **(7) двинуться дальше**. Ниже — workflow в формате “инструкция для агента” (без альтернатив, только самый community-acceptable путь: *локальная правка файла + компиляция + журналирование*).

## Рефлексия про стратегию
Автоматизация “закрыть все `sorry`” ломается на двух местах: **ложные цели** и **недостаточный контекст**. Поэтому агент должен работать как компилятор/верификатор: идти по **ДАГ зависимостей**, не расширять видимость случайно (Aristotle не добавляет импорты), и после каждого изменения делать **детерминированную проверку** (`lake build`/target build). Плюс: если Aristotle находит **контрпример**/негацию — это не “ошибка агента”, а сигнал, что узел ДАГ должен быть помечен как **REFORMULATE**, а не “дожимать доказательство”.

## Action checklist для “DAG → Aristotle → закрытие sorries”

1) **Нормализовать вход: собрать единый реестр узлов и `sorry`.**  
   **Action:** построить [DAG_INDEX] со списком узлов: `node_id`, `file`, `theorem/lemma name`, `sorry_count`, `deps(node_id)`, `priority`, `status`.  
   **Verify:** для каждого `sorry` есть уникальный `node_id` и точная координата (файл + имя декларации/строка).

2) **Топологическая очередь работ (priority topo).**  
   **Action:** сформировать [WORK_QUEUE] в порядке: сначала листья (без незакрытых deps), затем выше; внутри слоя сортировать по `priority` (ERS/critical-path/ручной вес).  
   **Verify:** для каждого узла `u` все `deps(u)` либо `DONE`, либо помечены `BLOCKED/REFORMULATE` с причиной.

3) **Подготовка “минимального контекста” для Aristotle.**  
   **Action:** для выбранного узла `u` создать [CONTEXT_BUNDLE_u]:  
   - `lean_file = file(u)` (единственный файл, который Aristotle будет модифицировать)  
   - `transitive imports` **не копировать руками** — Lean сам их подтянет, Aristotle “увидит” только то, что импортится  
   - `other_context`: папка/файл [NODE_BRIEF_u].md (короткий скетч, список “разрешённых” лемм, константы, инварианты).  
   **Verify:** `lake build file(u)` проходит **до** запуска Aristotle (чтобы фейлы не маскировались).

4) **Генерация запроса (prompt) по шаблону.**  
   **Action:** агент генерит [ARISTOTLE_PROMPT_u] по строгому шаблону:
   - цель: “Fill the remaining sorry in theorem X”  
   - ограничения: “Modify only this file; do not add imports; do not change defs; keep single-scale t_critical; avoid two-scale bridges; prefer existing lemmas.”  
   - план: 3–7 буллетов “как доказать” (если есть)  
   - если есть шанс ложности: “If false, produce counterexample/negation proof.”  
   **Verify:** в промпте явно указаны: **имя леммы**, **файл**, **запреты**, **разрешённые приёмы**.

5) **Запуск Aristotle в правильном режиме и правильной связке контекста.**  
   **Action:** использовать режим **Sorry filling** (если закрываем `sorry` пачкой в файле) или **Direct in English** (если точечно и нужен скетч), передав:  
   - `Lean context`: `file(u)`  
   - `Other context`: `[NODE_BRIEF_u].md` (+ при необходимости папка с сертификатами)  
   **Verify:** Aristotle вернул [PATCH_u] (diff/изменённый файл) или [FAIL_u] (лог + причина/контрпример).

6) **Детерминированная верификация результата (Lean компиляция + локальные тесты).**  
   **Action:** после патча агент запускает:  
   - `lake build <target>` или минимально `lake build` для файла/пакета  
   - (опционально) `lake env lean <file>` если есть тонкости с cache  
   и фиксирует [BUILD_LOG_u].  
   **Verify:** сборка зелёная → `status(u)=DONE`. Если сборка красная → `status(u)=REPAIR` и сохраняем точную ошибку.

7) **Ремонт итерацией “ошибка → минимальный патч” (не расширяя область).**  
   **Action:** если `REPAIR`, агент:  
   - парсит ошибку Lean в [ERROR_REPORT_u] (ожидаемые/неразрешённые импорты, типы, симп-леммы, тайм-ауты)  
   - добавляет **только** недостающие подсказки в [NODE_BRIEF_u].md или в `PROVIDED SOLUTION` header у теоремы  
   - повторяет шаги 4–6.  
   **Verify:** каждая итерация уменьшает либо число ошибок, либо приводит к явному “нужна новая лемма/ложно”.

8) **Обработка ложных/сломанных целей (контрпример как сигнал “переформулировать”).**  
   **Action:** если Aristotle выдаёт контрпример/негацию → пометить узел `REFORMULATE`, создать [COUNTEREXAMPLE_u], и открыть “issue” в [REVISION_LOG] с:  
   - какая формулировка ложна  
   - минимальный контрпример  
   - какой инвариант/условие надо усилить или какая лемма отсутствует  
   **Verify:** узел больше не блокирует очередь “молчаливо”: все зависимые узлы получают `BLOCKED_BY(u)` с причиной.

9) **Фиксация артефактов и воспроизводимость.**  
   **Action:** на каждый узел сохранять: [ARISTOTLE_PROMPT_u], [NODE_BRIEF_u], [PATCH_u], [BUILD_LOG_u], [REVISION_LOG].  
   **Verify:** любой результат можно воспроизвести “с нуля” по артефактам без ручных догадок.

10) **Глобальный прогресс-контроль и остановка на деградации.**  
   **Action:** вести [DASHBOARD] метрики: `DONE/REPAIR/BLOCKED/REFORMULATE`, среднее число итераций на узел, топ ошибок. Вводить “circuit breaker”: если N итераций без улучшения → эскалация в `HUMAN_REVIEW`.  
   **Verify:** агент не зацикливается; очередь движется; блокеры явно видны.

---

Если хочешь, я могу сразу дать **шаблон** для [ARISTOTLE_PROMPT_u] и [NODE_BRIEF_u].md под наш RH/Q3 стиль (single-scale, без двухмасштабки, с сертификатами), чтобы агент просто заполнял поля `{{lemma_name}}`, `{{file}}`, `{{allowed_lemmas}}`, `{{constraints}}` и стрелял в Aristotle максимально точно.

## USER
Да сделай

## ASSISTANT
Ы Отлично. Ниже — **два готовых шаблона**, которые агент может **заполнять автоматически** и **стрелять в Aristotle без шума**. Это уже **machine-ready**, не “для человека”.

---

# 🧠 TEMPLATE 1 — `ARISTOTLE_PROMPT_u.txt`
**(то, что агент кладёт в поле “Enter your prompt”)**

## Назначение
Точный, ограниченный запрос: **один узел ДАГ → один `sorry` → один файл**.

---

### 📌 PROMPT (заполняемый шаблон)

**Task**  
Fill the remaining `sorry` in the theorem **`{{LEMMA_NAME}}`** located in the file  
**`{{LEAN_FILE_PATH}}`**.

**Hard constraints (must follow):**
- Modify **only** this file: `{{LEAN_FILE_PATH}}`
- Do **not** add new imports.
- Do **not** modify any definitions or structures.
- Do **not** touch transitive dependencies.
- Stay within **single-scale** assumptions (no two-scale or auxiliary parameter bridges).
- Use existing lemmas and constants already available via imports.

**Mathematical constraints:**
- Scale: `{{SCALE}}` (e.g. `t_critical`)
- Fixed parameters: `{{FIXED_CONSTANTS}}`
- Domain reductions allowed: `{{DOMAIN_REDUCTION}}`  
  (e.g. reduce to `θ ∈ Icc (-1/2) (1/2)` by periodicity)

**Suggested proof strategy (guidance, not mandatory):**
- {{STEP_1}}
- {{STEP_2}}
- {{STEP_3}}
- {{OPTIONAL_STEP_4}}

**Failure handling:**
If the statement is false or under-specified, produce:
- a concrete counterexample, or
- a proof of the negation,
and explain which assumption is missing or insufficient.

---

### ✅ Пример автоподстановки (для понимания агенту)
- `{{LEMMA_NAME}} = P_A_ge_c_star_at_t_critical`
- `{{SCALE}} = t_critical`
- `{{DOMAIN_REDUCTION}} = periodicity → Icc (-1/2) (1/2)`
- `{{STEP_1}} = Reduce to fundamental domain using periodicity`
- `{{STEP_2}} = Apply certificate lemma on Icc`
- `{{STEP_3}} = Close with simp / linarith using bounds`

---

# 📄 TEMPLATE 2 — `NODE_BRIEF_u.md`
**(кладётся в “Other context” — md-файл, который Aristotle читает как подсказку)**

## Назначение
Мини-спека узла ДАГ: **что это за лемма, какие инварианты, чем можно пользоваться**.

---

## NODE BRIEF — `{{NODE_ID}}`

### 📍 Location
- File: `{{LEAN_FILE_PATH}}`
- Declaration: `{{LEMMA_NAME}}`

### 🎯 Goal (informal)
{{ONE_SENTENCE_GOAL}}

### 🔒 Fixed assumptions / invariants
- Scale: **{{SCALE}}**
- Parameters held fixed: **{{FIXED_CONSTANTS}}**
- No auxiliary scales or deformation parameters.
- No modification of global constants.

### 📐 Allowed reductions
- {{REDUCTION_1}}  
  (e.g. periodicity → fundamental interval)
- {{REDUCTION_2}} (optional)

### 🧩 Available lemmas / tools
Use **only** what is already imported in the file:
- {{LEMMA_A}}
- {{LEMMA_B}}
- {{LEMMA_C}}

(No new imports allowed.)

### ⚠️ Known pitfalls
- {{PITFALL_1}}  
  (e.g. norm bound diverges if extended beyond t_critical)
- {{PITFALL_2}}

### 🧪 Sanity checks
- Expected numeric bound: {{EXPECTED_BOUND}}
- Known true at: {{KNOWN_TRUE_CASES}}
- Suspected false if: {{SUSPECTED_FALSE_CASES}} (if any)

### 🧭 Preferred finish
- simp / linarith / nlinarith
- avoid heavy automation unless necessary
- aesop allowed only as **non-terminal** tactic  
  (`aesop (config := { warnOnNonterminal := false })`)

---

# 🔁 Как агент это использует (алгоритм в 6 строк)

1. Берёт узел `u` из ДАГ (leaf / готовые deps).
2. Заполняет `NODE_BRIEF_u.md` из метаданных узла.
3. Генерит `ARISTOTLE_PROMPT_u.txt` по шаблону.
4. Запускает Aristotle:
   - Lean context = `{{LEAN_FILE_PATH}}`
   - Other context = `NODE_BRIEF_u.md`
5. Получает patch → запускает `lake build`.
6. По результату:
   - ✅ build ok → `DONE`
   - ❌ counterexample → `REFORMULATE`
   - ❌ type/error → `REPAIR` (итерация)

---

## 🧱 Почему это **железобетон**
- **Локальность**: один файл, один узел → нет расползания.
- **Детерминизм**: каждый шаг проверяется Lean’ом.
- **Анти-галлюцинации**: Aristotle не видит лишнего.
- **DAG-совместимость**: любой фейл корректно помечается и не ломает очередь.

Если хочешь, следующим шагом я:
- сделаю **JSON-схему DAG_INDEX**,  
- или дам **bash/python-скелет агента**, который это всё гоняет автоматически (с логами, ретраями и circuit breaker’ом).

## ASSISTANT
Ы Отлично, это финальный кусок пазла. Теперь можно **жёстко зафиксировать инструкции для агента**, *какой режим Aristotle когда использовать* и **как это ложится на ДАГ**.

Ниже — **каноническая инструкция**, без вариантов и философии.

---

# 🧠 Aristotle × DAG — ОФИЦИАЛЬНАЯ ИНСТРУКЦИЯ ДЛЯ АГЕНТА

## 0. Базовое соответствие: **режим ↔ тип узла ДАГ**

| Тип узла ДАГ | Состояние | Режим Aristotle |
|-------------|----------|-----------------|
| Узел с `sorry` в `.lean` | Локальное доказательство | **[1] Fill sorries in a Lean file** |
| Узел без формализации (идейный) | Текст / pdf / md | **[2] Prove & formalize from text** |
| Узел сложный / неоднозначный | Нужен контроль | **[3] Direct Aristotle in English** |
| Контроль / дебаг | Анализ | **[4] View history** |

👉 **90% DAG-прохода = режим [1]**, всё остальное — вспомогательное.

---

## 1. Режим **[1] Fill sorries in a Lean file** — ОСНОВНОЙ

### Когда использовать
- Узел ДАГ = **конкретный файл `.lean`**
- В файле есть **один или несколько `sorry`**
- Все зависимости **уже закрыты** (или помечены `BLOCKED`)

### Что делает агент
1. Берёт узел `u` из очереди ДАГ
2. Проверяет:
   - файл компилируется **ДО** Aristotle
3. Запускает Aristotle в режиме **[1]**
4. Передаёт:
   - **путь к `.lean` файлу**
5. Получает patch

### Жёсткие гарантии режима [1]
- **Импорты**: Aristotle видит **ТОЛЬКО транзитивные импорты**
- **Модификация**: меняется **ТОЛЬКО этот файл**
- **Defs / data**: не трогаются
- **Архитектура**: не расползается

### Проверка
- `lake build`
- если зелёный → `DONE`
- если нет → `REPAIR` или `REFORMULATE`

👉 Это **идеальный режим для автоматического закрытия DAG-листьев**.

---

## 2. Режим **[3] Direct Aristotle in English** — ТОЧЕЧНЫЙ СКАЛЬПЕЛЬ

### Когда использовать
- Узел:
  - сложный
  - требует **строгих ограничений**
  - или ранее дал контрпример
- Нужно **явно сказать**, *что делать нельзя*

### Что делает агент
1. Генерит **ARISTOTLE_PROMPT_u**
2. Прикладывает:
   - **Lean file** (основной контекст)
   - **NODE_BRIEF_u.md** (инварианты, запреты, стратегия)
3. Запускает режим **[3]**

### Ключевая фишка
В этом режиме агент **рулит поиском**, а не “отдаёт файл на волю бога”.

👉 Используется:
- для **critical path**
- для **single-scale** узлов
- когда надо запретить двухмасштабку, эвристики, лишние леммы

---

## 3. Режим **[2] Prove & formalize from text** — ПРЕ-ФОРМАЛИЗАЦИЯ

### Когда использовать
- Узел ДАГ:
  - ещё **не `.lean`**
  - pdf / md / заметки
- Нужно:
  - получить **черновую формализацию**
  - или заготовку лемм

### Что делает агент
1. Загружает текст (pdf/md)
2. Просит:
   - формализовать в Lean
3. Результат:
   - **НЕ коммитится напрямую**
   - идёт как **INPUT** для новых DAG-узлов

👉 Этот режим **никогда не закрывает sorries напрямую**.  
Он **генерирует будущие узлы ДАГ**.

---

## 4. Режим **[4] View history** — АНАЛИТИКА И АНТИ-ПЕТЛИ

### Когда использовать
- Агент:
  - застрял
  - видит повторяющиеся ошибки
- Нужно:
  - сравнить попытки
  - понять, где деградация

### Использование
- Проверка:
  - сколько итераций ушло на узел
  - какие промпты работали
- Сигнал:
  - если N попыток без прогресса → **HUMAN_REVIEW**

---

## 5. Полный алгоритм агента (коротко, но жёстко)

1. Построить **ДАГ** (`nodes`, `deps`, `status`)
2. Взять **leaf-узел**
3. Если есть `.lean` + `sorry` → **[1]**
4. Если фейл:
   - типовой → **REPAIR**
   - контрпример → **REFORMULATE**
5. Если узел critical → **[3]**
6. После каждого patch → **`lake build`**
7. Обновить статус узла
8. Перейти к следующему

---

## 6. Ключевые **ТЕХНИЧЕСКИЕ ТЕРМИНЫ** (коротко)

- **DAG (Directed Acyclic Graph)** — граф зависимостей узлов доказательства
- **leaf node** — узел без незакрытых зависимостей
- **sorry** — дырка в доказательстве Lean
- **transitive imports** — всё, что импортится цепочкой `import`
- **REFORMULATE** — цель ложная или плохо сформулирована
- **REPAIR** — цель верная, но доказательство сломано
- **single-scale** — один фиксированный параметр (у нас `t_critical`)
- **critical path** — узлы, блокирующие большой кусок DAG

---

## 🔥 Итог (без реверансов)

Ты сейчас смотришь на **реальный автомат закрытия математических доказательств**:

- DAG = стратегия  
- Aristotle = мотор  
- Lean = компилятор истины  

Следующий логичный шаг:
- либо я даю тебе **JSON-схему DAG + статусы**
- либо **bash/python-агента**, который это всё уже гоняет

Скажи, что хочешь — **инфраструктуру или реализацию**.

