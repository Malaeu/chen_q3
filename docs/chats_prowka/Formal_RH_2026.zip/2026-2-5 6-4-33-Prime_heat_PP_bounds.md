# Prime-heat PP bounds

https://chat.openai.com/c/6983d081-1730-838d-a05a-df92ed5c733c

## USER
# Proshka request: prime-heat PP bounds (pilot, buckets 0 & 99)

## Цель
Закрыть пилотный набор точечных неравенств для prime‑power термов (пилотные бакеты 0 и 99):

```
prime_heat_weight_term n ≤ Pilot.prime_heat_pp_term_ub n
```

Это пилот для закрытия аксиомы
`prime_heat_weight_term_le_pp_ub_of_prime_pow_pilot` в
`Q3/Proofs/PrimeCert/BrangeHeatCert_2026_01_28_Pilot.lean`.

## Контекст
Определение терма (из `BrangeHeatCert_2026_01_28_Data.lean`):

```
def prime_heat_weight_term (n : ℕ) : ℝ :=
  (w_Q n * (Real.exp (-4 * Real.pi ^ 2 * t_critical * (xi_n n) ^ 2) * |xi_n n|)) *
    (if |xi_n n| ≤ prime_cert_B_max then (1 : ℝ) else 0)
```

Фиксированные параметры:
- `t_critical = 3/20`
- `prime_cert_B_max = 4.9`
- `Pilot.prime_heat_pp_term_ub_den` (из `BrangeHeatCert_2026_01_28_PrimePowPilotBase.lean`)

Пилотные источники верхних оценок:
- `Q3/Proofs/PrimeCert/BrangeHeatCert_2026_01_28_PrimePowPilot.lean`
- `Q3/Proofs/PrimeCert/BrangeHeatCert_2026_01_28_PrimePowPilotBucket0*.lean`
- `Q3/Proofs/PrimeCert/BrangeHeatCert_2026_01_28_PrimePowPilotBucket99*.lean`

Файл‑связка (пилотные обязанности):
`Q3/Proofs/PrimeCert/BrangeHeatCert_2026_01_28_PrimePowPilot.lean`

## Ограничения
- В Mathlib **нет** тактики `interval` (проверено).
- `ComputableReal` не даёт `log`, поэтому не годится как прямой путь.
- Хотим Lean‑совместимую стратегию (монотонность, рациональные ограждения,
  `simp`/`ring`/`nlinarith`/`gcongr`), без `sorry`/`exact?`.

## Что нужно от Прошки
1) Реалистичная Lean‑стратегия для численных неравенств с `exp/log/sqrt` на
   фиксированных числах.
2) Минимальный proof‑skeleton (1‑2 примера на конкретном `n`, например `n=2`
   и `n=999983`), который можно масштабировать на список.
3) Как лучше “упаковать” эти доказательства: по‑леммно на каждый `n`, либо
   через общую лемму с монотонностью + таблица значений.

Формат ответа:
- 3–7 шагов стратегии
- 1‑2 коротких Lean‑фрагмента для конкретных чисел
- Указание, где и как автоматизировать список

## ASSISTANT
## Стратегия (6 шагов)

1) **Снести индикатор `if |xi_n n| ≤ B_max then 1 else 0`.**  
   Делайте `by_cases hcut : |xi_n n| ≤ prime_cert_B_max`.  
   - В ветке `hcut = false` цель почти всегда закрывается так:
     `simp [prime_heat_weight_term, hcut]` даёт `0 ≤ RHS`, остаётся **только** `0 ≤ Pilot.prime_heat_pp_term_ub n` (лучше иметь лемму `ub_nonneg`).  
   - В ветке `hcut = true` `simp [prime_heat_weight_term, hcut]` убирает `if` и оставляет чистый продукт.

2) **Очистить общий знаменатель `Pilot.prime_heat_pp_term_ub_den`.**  
   Если `Pilot.prime_heat_pp_term_ub n` реально определён как `num n / den` (с фиксированным `den`), то сразу переводите цель в вид  
   `prime_heat_weight_term n * den ≤ num n` через `le_div_iff` / `div_le_iff` (нужна `den_pos : (0:ℝ) < (den:ℝ)`).  
   Это резко упрощает финал: остаётся неравенство без деления → `ring_nf`/`nlinarith`.

3) **Разбить продукт на три “кусочных” оценки и собирать `mul_le_mul`/`gcongr`.**  
   После `simp` цель имеет форму
   ```
   w_Q n * (Real.exp (…)*|xi_n n|) ≤ ub
   ```
   Заводите отдельные оценки:
   - `hw : w_Q n ≤ Wn` (рациональная/десятичная константа в ℚ → приводите к ℝ через `norm_cast`).
     Если совсем без тонкости, можно использовать грубую глобальную оценку на вес: в тексте Q3 отмечено, что  
     `w(n)=Λ(n)/√n ≤ log n/√n ≤ 2/e < 1` (а значит `w_Q(n)=2Λ(n)/√n ≤ 4/e < 1.5`). fileciteturn1file2  
     Это спасает bucket 0 (где экспонента не убивает), но **для bucket 99 обычно нужно точнее**, иначе bound слишком рыхлый.
   - `hxi : |xi_n n| ≤ Xn` (обычно это прямо “bucket upper edge”, рациональная константа).
   - `hexp : Real.exp (…negative…) ≤ En` (самый важный шаг; ниже даю реально Lean‑совместимые варианты).

4) **Для `exp` избегать `log` полностью: используйте “обратный ряд” через `exp(u) ≥ Σ u^k/k!`.**  
   Для `u ≥ 0`:
   - `Real.exp (-u) = 1 / Real.exp u`
   - `Real.exp u ≥ S_m(u) := ∑_{k=0}^m u^k/k!`  (частичная сумма степенного ряда)
   - значит `Real.exp (-u) ≤ 1 / S_m(u)`.

   Для bucket 99 это золото: выбираете **рациональную нижнюю оценку** `u0 ≤ u` (из bucket‑интервала на `|xi|`), берёте `m ≈ 18..30` — и `1/S_m(u0)` становится микроскопическим рациональным числом.  
   На bucket 0 чаще достаточно `Real.exp (… ) ≤ 1` (т.к. показатель ≤ 0).

5) **Комбинация факторов: `gcongr` + `nlinarith`.**  
   После того как есть `hw`, `hxi`, `hexp` и неотрицательность факторов, делайте:
   - `have : w_Q n * (Real.exp (…) * |xi_n n|) ≤ Wn * (En * Xn) := by gcongr`
   - затем покажите `Wn * (En * Xn) ≤ ub` уже чисто рационально (`norm_num`/`nlinarith`).

6) **Упаковка: одна общая “комбайн‑лемма” + табличные леммы на `n`.**  
   Лучше всего (и масштабируется на список без боли):
   - в `…PrimePowPilotBase.lean` держите 1–2 общие леммы для `exp(-u)` и для сборки продукта;
   - в bucket‑файлах держите **только таблицу** вида  
     `hw_n : w_Q n ≤ (Wn : ℝ)`, `hxi_n : |xi_n n| ≤ (Xn : ℝ)`, `hu_n : (u0n : ℝ) ≤ u(n)`  
     и финал “в одну строчку” через комбайн.

---

## Мини‑skeleton 1: `n = 2` (bucket 0‑стиль, “дёшево и сердито”)

```lean
-- Импорты подстрой под твой проект
-- import Q3.Proofs.PrimeCert.BrangeHeatCert_2026_01_28_Data
-- import Q3.Proofs.PrimeCert.BrangeHeatCert_2026_01_28_PrimePowPilotBase
-- import Q3.Proofs.PrimeCert.BrangeHeatCert_2026_01_28_PrimePowPilot

open Real

namespace Pilot

-- Идея: bucket 0 обычно можно закрыть exp ≤ 1 и табличными bounds на w_Q и |xi|.
lemma prime_heat_weight_term_le_pp_ub_n2 :
  prime_heat_weight_term 2 ≤ Pilot.prime_heat_pp_term_ub 2 := by
  by_cases hcut : |xi_n 2| ≤ prime_cert_B_max
  · -- индикатор = 1
    simp [prime_heat_weight_term, hcut]
    -- теперь цель: w_Q 2 * (exp(...) * |xi_n 2|) ≤ ub

    -- (1) exp ≤ 1, т.к. показатель ≤ 0 (здесь покажи неотрицательность квадрата)
    have hexp : Real.exp (-4 * Real.pi^2 * t_critical * (xi_n 2)^2) ≤ (1 : ℝ) := by
      -- стандартный путь: `have hle : (-4*π^2*t*xi^2) ≤ 0 := by nlinarith [sq_nonneg (xi_n 2)]`
      -- затем `simpa` через монотонность exp
      have hle : (-4 * Real.pi^2 * t_critical * (xi_n 2)^2) ≤ 0 := by
        -- t_critical>0, pi^2>0, sq≥0
        nlinarith [sq_nonneg (xi_n 2), Real.pi_pos, Pilot.t_critical_pos]
      simpa using (Real.exp_le_one_iff.mpr hle)  -- если имя другое: замени на стандартную лемму exp ≤ 1 ↔ x ≤ 0

    -- (2) табличные bounds (лучше хранить их в bucket0-файле):
    have hw  : w_Q 2 ≤ (Pilot.wQ_ub_2 : ℝ) := by simpa using Pilot.wQ_ub_2_spec
    have hxi : |xi_n 2| ≤ (Pilot.xi_ub_2 : ℝ) := by simpa using Pilot.xi_ub_2_spec

    -- (3) собрать через gcongr/nlinarith
    have hprod :
      w_Q 2 * (Real.exp (-4 * Real.pi^2 * t_critical * (xi_n 2)^2) * |xi_n 2|)
        ≤ (Pilot.wQ_ub_2 : ℝ) * ((1:ℝ) * (Pilot.xi_ub_2 : ℝ)) := by
      gcongr
    -- осталось показать RHS ≤ Pilot.prime_heat_pp_term_ub 2 (обычно просто `norm_num`/`nlinarith` после unfold)
    -- здесь удобно сразу чистить знаменатель Pilot.prime_heat_pp_term_ub_den
    -- (скелет; подстрой под определение ub)
    nlinarith [hprod, Pilot.pp_ub_majorizes_piece_2]
  · -- индикатор = 0, LHS = 0
    simp [prime_heat_weight_term, hcut, Pilot.prime_heat_pp_term_ub_nonneg (n := 2)]

end Pilot
```

**Что тут важно:** этот шаблон почти всегда работает на bucket 0, если `Pilot.wQ_ub_2_spec`, `Pilot.xi_ub_2_spec`, `Pilot.pp_ub_majorizes_piece_2` — короткие табличные леммы.

---

## Мини‑skeleton 2: `n = 999983` (bucket 99‑стиль, “экспонента решает всё”)

### Ключ: один раз в Base‑файле завести лемму `exp_neg_le_inv_taylor`

```lean
namespace Pilot

-- Частичная сумма ряда exp(u): S_m(u) = ∑_{k=0}^m u^k / k!
def expSeries (u : ℝ) (m : ℕ) : ℝ :=
  ∑ k in Finset.range (m+1), u^k / (Nat.factorial k)

-- Идея: exp(-u) ≤ 1 / S_m(u), u≥0.
lemma exp_neg_le_inv_expSeries (u : ℝ) (m : ℕ) (hu : 0 ≤ u) :
    Real.exp (-u) ≤ 1 / expSeries u m := by
  -- exp(-u) = 1/exp(u)
  have hexp_pos : 0 < Real.exp u := Real.exp_pos u
  -- нужен факт: expSeries u m ≤ exp u
  have hS_le : expSeries u m ≤ Real.exp u := by
    -- либо есть готовая лемма в Mathlib, либо докажи один раз через
    -- `Real.exp_eq_tsum` и монотонность частичных сумм (все слагаемые ≥0 при hu)
    exact Pilot.expSeries_le_exp u m hu
  -- инвертируем (положительные числа)
  have hinv : (1 / Real.exp u) ≤ (1 / expSeries u m) := by
    -- обычно подходит `one_div_le_one_div_of_le` / `inv_le_inv_of_le`
    -- с условиями `0 < expSeries u m` и `expSeries u m ≤ exp u`
    have hS_pos : 0 < expSeries u m := by
      -- S_m(u) ≥ 1
      -- (терм k=0 равен 1)
      have : (1:ℝ) ≤ expSeries u m := by
        -- simp [expSeries] даёт, что сумма по range(m+1) содержит k=0
        -- и все остальные термы ≥0
        exact Pilot.one_le_expSeries u m hu
      exact lt_of_lt_of_le (by norm_num) this
    -- теперь инверсия
    -- (названия лемм могут отличаться; логика стандартная)
    exact one_div_le_one_div_of_le hS_pos hS_le
  -- финал
  simpa [Real.exp_neg] using hinv

end Pilot
```

### Теперь сам `n = 999983`

```lean
open Real

namespace Pilot

lemma prime_heat_weight_term_le_pp_ub_n999983 :
  prime_heat_weight_term 999983 ≤ Pilot.prime_heat_pp_term_ub 999983 := by
  by_cases hcut : |xi_n 999983| ≤ prime_cert_B_max
  · simp [prime_heat_weight_term, hcut]

    -- Определяем u = 4π² t ξ² (неотрицателен)
    set u : ℝ := 4 * Real.pi^2 * t_critical * (xi_n 999983)^2
    have hu : 0 ≤ u := by
      -- t_critical>0, pi_pos, sq≥0
      dsimp [u]
      nlinarith [sq_nonneg (xi_n 999983), Real.pi_pos, Pilot.t_critical_pos]

    -- Нижняя рациональная оценка u0 ≤ u из bucket99-таблицы (самое важное место!)
    -- Например: |xi| ≥ a99 ⇒ u ≥ 4π² t a99² := u0
    have hu0 : (Pilot.u0_999983 : ℝ) ≤ u := by
      -- типично: из табличного `hxi_lb : (a99:ℝ) ≤ |xi_n 999983|`
      -- затем nlinarith
      exact Pilot.u0_999983_spec

    -- Экспонента: exp(-u) ≤ 1 / S_m(u0)
    have hexp : Real.exp (-u) ≤ 1 / Pilot.expSeries (Pilot.u0_999983 : ℝ) 30 := by
      -- (1) exp(-u) ≤ exp(-u0) по монотонности (если хочешь)
      -- (2) exp(-u0) ≤ 1/S_m(u0) через лемму выше
      -- Я обычно делаю сразу (2) и потом “ослабляю”, используя u ≥ u0 и монотонность S_m.
      have h0 : 0 ≤ (Pilot.u0_999983 : ℝ) := by nlinarith [hu0, hu]
      exact Pilot.exp_neg_le_inv_expSeries (u := (Pilot.u0_999983 : ℝ)) (m := 30) h0

    -- Bounds на w_Q и |xi| (табличные, из bucket99 файла)
    have hw  : w_Q 999983 ≤ (Pilot.wQ_ub_999983 : ℝ) := by simpa using Pilot.wQ_ub_999983_spec
    have hxi : |xi_n 999983| ≤ (Pilot.xi_ub_999983 : ℝ) := by simpa using Pilot.xi_ub_999983_spec

    -- Собираем:
    have hprod :
      w_Q 999983 * (Real.exp (-u) * |xi_n 999983|)
        ≤ (Pilot.wQ_ub_999983 : ℝ) * ((1 / Pilot.expSeries (Pilot.u0_999983 : ℝ) 30) * (Pilot.xi_ub_999983 : ℝ)) := by
      gcongr

    -- Осталось показать RHS ≤ Pilot.prime_heat_pp_term_ub 999983 (после очистки den — чистый `nlinarith`)
    nlinarith [hprod, Pilot.pp_ub_majorizes_piece_999983]
  · simp [prime_heat_weight_term, hcut, Pilot.prime_heat_pp_term_ub_nonneg (n := 999983)]

end Pilot
```

**Комментарий:** здесь “магия” в том, что `u0_999983_spec` берётся из bucket‑таблицы, а `expSeries` — чистая алгебра (с факториалами), которую Lean переваривает через `ring_nf`/`nlinarith` намного лучше, чем через попытки напрямую оценивать `exp`.

---

## Где и как автоматизировать список

**Лучший компромисс (я бы сделал так):**

- **(A) Один комбайн‑лемма** (в Base‑файле):  
  `prime_heat_weight_term_le_of_bounds`  
  принимает `hcut`, `hw`, `hxi`, `hexp` и делает “склейку” (`simp` + `gcongr` + очистка `den`).

- **(B) Табличные леммы по каждому `n`** в bucket‑файлах (bucket0 и bucket99):  
  - `wQ_ub_<n>_spec : w_Q n ≤ (Wn : ℝ)`
  - `xi_ub_<n>_spec : |xi_n n| ≤ (Xn : ℝ)`
  - `u0_<n>_spec : (u0n : ℝ) ≤ (4*π²*t*(xi_n n)^2)`  *(или эквивалент с уже упрощённым `u`)*  
  - `pp_ub_majorizes_piece_<n> : (Wn * (En * Xn)) ≤ Pilot.prime_heat_pp_term_ub n`

- **(C) В связке `PrimePowPilot.lean`**:  
  вы делаете “dispatch по списку” и просто `simp`:
  ```lean
  theorem prime_heat_weight_term_le_pp_ub_of_prime_pow_pilot
    (n : ℕ) (hn : n ∈ Pilot.pp_pilot_set) :
    prime_heat_weight_term n ≤ Pilot.prime_heat_pp_term_ub n := by
    -- классика: превращаем mem finset в дизъюнкции
    classical
    simp [Pilot.pp_pilot_set] at hn
    rcases hn with rfl | rfl | hn
    · simpa using Pilot.prime_heat_weight_term_le_pp_ub_n2
    · simpa using Pilot.prime_heat_weight_term_le_pp_ub_n999983
    -- ...
  ```
  Это механически расширяется: просто добавляете `| rfl`‑ветки.  
  Если список длинный, лучше генерировать этот блок автоматически (скриптом), но Lean‑ядро остаётся тем же.

---

## Две проектные подсказки по процессу (не про математику, а про скорость)

- Для таких “табличных” участков очень хорошо работает подход **“вынести ошибку в отдельную семантическую лемму и закрывать по одной”** (идея автогенерации/сегментации sorries) — см. план по автоматизации именования/парсинга ошибок. fileciteturn0file27  
- И для подбора рациональных констант (Wn, Xn, u0n, степень `m`) полезны ваши внутренние подходы к “балансировке” и оценке критических мест в цепочке констант. fileciteturn0file26

