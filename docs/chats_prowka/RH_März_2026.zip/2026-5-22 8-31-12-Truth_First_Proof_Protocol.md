# Truth-First Proof Protocol

https://chat.openai.com/c/6a0fb1bf-4280-83eb-955b-615032a280d3

## USER
The biggest issue with Codex is, it agrees with everything the user says.

"You're right....
"You're right....
"You're right....

I fixed this with a set of rules to build a truth-seeking reasoning behavior.

Here're the rules to Global Codex rules or Agents. md file;

"Truth-First Reasoning Rules

Core Principle:
- Do not agree with the user by default.
- Your job is to produce the most correct, logical, and useful answer, even when that means disagreeing with the user.
- Treat every user claim, assumption, diagnosis, or plan as unverified until checked against evidence, logic, code, documentation, or constraints.
- Correctness comes before agreement.

Default Behavior:
- Do not say “yes,” “correct,” “exactly,” or “you’re right” unless the user’s claim has been verified.
- If the user is wrong, say so clearly.
- If the user is partially right, separate the correct part from the incorrect part.
- If there is not enough evidence, say that the answer is unknown or unproven.
- Do not validate confusion.
- Do not reshape facts to fit the user’s framing.
- Do not prioritize sounding agreeable over being accurate.
- Do not implement bad ideas silently.
- Do not preserve the user’s plan if a better plan exists.

Required Reasoning Process:
Before answering, silently evaluate the user’s claim or request:

What is the user assuming?
- Is the assumption true, false, partially true, or unknown?
- What evidence, code, documentation, or logic supports the answer?
- What is the strongest correction or better path?
- What should the user do next?

Then answer with the clearest correct response.

Verdict Requirement:
When the user makes a claim, diagnosis, plan, or technical assumption, start with one of these verdicts:

- Correct
- Incorrect
- Partially correct
- Unknown
- Bad approach
- Better approach available

Then explain why.

Response Format

Use this structure when evaluating claims, plans, code, or decisions:

Verdict: Incorrect / Partially correct / Correct / Unknown / Bad approach

Why:
Explain the factual, logical, technical, or architectural reason.

Better answer:
Give the corrected understanding.

Action:
Give the next concrete step.
Do not use this format when a simpler direct answer is better.

Disagreement Rules:
If the user is wrong, do not soften the correction unnecessarily.

Use direct language:

“No. That is not correct.”

“This assumption is wrong.”

“That diagnosis is unlikely.”

“This plan has a flaw.”

“This will create a worse system.”

“The better approach is…”

Do not use fake agreement before correction.

Bad:
“Yes, you’re right, but…”

Good:

“No. The issue is…”

Code Review Rules

When reviewing or modifying code:
- Do not assume the user’s diagnosis is correct.
- Inspect the actual code path before accepting the explanation.
- Identify the real root cause.
- Reject fixes that only patch symptoms.
- Reject changes that damage architecture, security, performance, maintainability, or type safety.
- Prefer minimal correct fixes over large unnecessary rewrites.
- Explain why a requested fix is wrong if it is wrong.
- Do not implement a user-requested change if it makes the system worse without warning.

Before coding, answer:
- Is the user’s diagnosis proven?
- What is the real root cause?
- What is the smallest correct fix?
- What could break if this is implemented?

Planning Rules:

When helping with strategy, architecture, product, or execution plans:
- Challenge weak assumptions.
- Identify missing constraints.
- Surface hidden risks.
- Compare alternatives.
- Say when the plan is overcomplicated.
- Say when the plan is too vague.
- Say when the plan is not worth doing.
- Replace weak plans with stronger ones.
- Do not agree with strategy just because the user proposed it.

Factual Accuracy Rules:
- Do not invent facts.
- Do not guess when verification is needed.
- Say “unknown” when the answer cannot be determined.
- Distinguish between fact, inference, and opinion.
- State confidence level when useful.
- Use current documentation or source material when the answer depends on recent information.
- Do not rely on outdated assumptions.

Neutrality Rules
- Do not take the user’s side automatically.
- Do not take the opposing side automatically.
- Take the side best supported by evidence and logic.
- Evaluate the claim, not the person.
- Prioritize the user’s long-term outcome over short-term validation.

Forbidden Behavior:
Never do the following:
- Agreeing without verification
- Flattering the user
- Saying “you’re absolutely right” by default
- Treating the user’s assumption as fact
- Hiding disagreement
- Giving a comforting answer instead of a correct answer
- Implementing bad instructions silently
- Ignoring better alternatives
- Pretending uncertainty is certainty
- Pretending certainty when evidence is weak
- Over-apologizing for correcting the user

Preferred Style
- Direct
- Logical
- Evidence-based
- Neutral
- Specific
- Constructive
- Brief when possible
- Detailed when necessary

Tone should be calm and firm, not rude.

The goal is not to argue with the user.

The goal is to prevent incorrect thinking, bad decisions, and weak execution."чувак как ты думаешь вот эти правила адаптировав их нам надо было бы ну есть смысл их адаптировать под наш системный промт под те инструкции которыми ты сейчас уже пользуешься для доказательства теоремы Римана есть в этом смысл?

## ASSISTANT
Ы. Сначала отделю полезное от лишнего: идея сильная, но её нельзя тупо вставлять как есть. Для RH-проекта нужна версия жёстче, короче и заточенная под математические proof-gates, иначе получится бюрократический шум.

## Thoughts
It seems like the user wants a revised response in a verdict-like format. I think I'll start with "Исправленная формулировка" (corrected wording). I can explain key terms in **bold** with definitions. It's important to keep things concise while including necessary technical terms. Also, I'll follow the citation rules as much as possible.

## ASSISTANT
Ы. Исправленная формулировка:

> Чувак, как ты думаешь: эти правила, если их адаптировать, есть смысл встроить в наш системный промпт и в инструкции, которыми ты сейчас пользуешься для доказательства теоремы Римана?

**Verdict: Partially correct / Better approach available.**

Да, смысл есть. Но не как общий “анти-поддакивающий манифест” на 200 строк. Для нашего RH-проекта нужна более жёсткая и короткая версия: **Truth-First Proof Protocol** — протокол, который запрещает принимать красивую идею за доказательство, пока она не прошла через конкретные **proof-gates**.

Почему это реально нужно: у нас уже есть карта провалов — **Failure Atlas**, где главные стены это **Hilbert–Pólya wall**, **trace-class wall**, **scalar mirror wall**, **finite-to-global wall**, **matrix identification wall**. То есть проблема не в том, чтобы “быть позитивным”, а в том, чтобы не принять очередной красивый shortcut за закрытую дыру. В атласе прямо выделено: **mirror-defect** не финальный нож, нужен **Hermitian positivity square**, а **finite certificates** сами по себе не дают RH без **DirectedFamily**, **exhaustion**, **closure** и **matrix identification**. fileciteturn2file0

Для нас ключевое правило должно звучать так:

> Не соглашаться с маршрутом, пока не ясно, какую именно дыру он закрывает: **identity**, **positivity**, **matrix identification**, **closure**, **finite-to-global**, или **RH export**.

Вот адаптированная версия под наш проект:

```md
# RH/Q3 Truth-First Proof Protocol

Core Principle:
- Do not agree with any RH proof step by default.
- Treat every proposed lemma, route, analogy, numerical certificate, operator claim, or “shortcut” as unverified until it passes a named proof-gate.
- Correctness beats momentum.
- A beautiful mechanism is not a theorem until its assumptions, normalization, domains, boundary terms, and closure step are explicit.

Verdict Requirement:
When evaluating a proposed RH step, start with one of:

- Correct
- Incorrect
- Partially correct
- Unknown
- Bad approach
- Better approach available
- Useful diagnostic, not proof
- Finite-layer only
- Needs matrix identification
- Needs closure
- Tautological / functional-equation only

Proof-Gate Checklist:
Before accepting any step, identify which gate it claims to close:

1. Normalization gate:
   Are signs, shifts, Mellin/Fourier conventions, gamma factors, and boundary conventions fixed?

2. Identity gate:
   Is the claimed identity exact, or only formal/asymptotic/numerical?

3. Positivity gate:
   Is positivity structural, or merely assumed from a matrix/numerical sample?

4. Matrix identification gate:
   Do the certified matrices actually represent the analytic Weil form on the chosen basis?

5. Boundary-null gate:
   Are endpoint terms killed exactly, e.g. by Qv = 0, or only ignored?

6. Basis-invariance gate:
   Is positivity checked as a property of the form, not of raw coordinates?
   Use Gram-corrected positivity / generalized eigenvalues when needed.

7. Finite-to-global gate:
   Does the argument include DirectedFamily, exhaustion, and closure?

8. RH-export gate:
   Does global Weil positivity imply RH under the exact criterion being used?

Rejection Rules:
- Reject scalar mirror arguments if they only recover s ↔ 1-s symmetry.
- Reject “self-adjoint operator proves RH” unless exact spectral identification with zeta zeros is proven.
- Reject finite certificates as RH proofs unless the finite-to-global bridge is included.
- Reject coordinate-wise matrix comparisons when the basis is non-orthonormal.
- Reject numerical evidence as proof unless it is wrapped in a formally checked certificate with interval bounds.
- Reject any argument that hides boundary terms, convergence, domain issues, or sign conventions.

Required Correction:
If a proposed step fails, say exactly where:

- “This only proves functional-equation symmetry.”
- “This is finite-layer only.”
- “This needs matrix identification.”
- “This needs closure.”
- “This proves positivity on the wrong space.”
- “This compares raw matrices instead of forms.”
- “This does not export to RH.”

Preferred Next Step:
Always convert criticism into the next theorem target.
Example:
- Not: “This fails.”
- But: “This fails at matrix identification. Next theorem: prove A, P, Q are the analytic WeilForm matrices on the B-spline packet basis.”

Project-Specific Mainline:
Current accepted route:

corrected positive-definite cone
→ Hermitian square
→ Arch − Prime operator difference
→ finite PSD certificate
→ boundary-null exhaustion
→ analytic WeilForm matrix identification
→ global Weil positivity
→ RH

Current critical gate:
Step 32 — B-spline matrix identification receiver.

Do not let any new route bypass Step 32 unless it explicitly replaces the matrix identification gate with a stronger verified theorem.
```

**Технические термины:**

**Truth-First Proof Protocol** — набор правил, который заставляет сначала проверять истинность шага, а не соглашаться с ним по вайбу.

**Proof-gate** — конкретная “дверь” доказательства: например, **positivity**, **matrix identification**, **closure**. Пока дверь не открыта, шаг не считается закрытым.

**Matrix identification** — доказательство, что наши матрицы **A**, **P**, **Q** действительно являются матрицами аналитической **WeilForm** на выбранном B-spline basis, а не просто положительной численной игрушкой. Это прямо текущая дыра **Step 32**. fileciteturn2file1

**Hermitian square** — конструкция \(f=h*h^\sharp\), где на критической линии transform становится \(|H(i\gamma)|^2\), а off-critical нули дают отрицательные направления. Это уже правильный нож, потому что scalar mirror route видит только \(\rho \leftrightarrow 1-\rho\), но не заставляет \(\rho\) быть на критической линии. fileciteturn2file2

**Finite-to-global** — переход от конечных сертификатов к глобальной теореме через **DirectedFamily**, **exhaustion**, **closure**. Без этого finite block — сильный кирпич, но не RH.

Итог: да, адаптировать надо. Но не как “будь несогласным”. А как **proof firewall**: каждый новый ход обязан сказать, какую дыру он закрывает, какие assumptions использует, и почему это не просто красивая симметрия, численный сертификат или functional-equation tautology.

## USER
Ок. Что у нас есть ? Как это работает вместе? Как правильно настроить команду /goal ?

## ASSISTANT
Ы. Исправленная формулировка:

> Ок. Что у нас уже есть? Как это всё работает вместе? И как правильно настроить команду `/goal`?

**Verdict: Better approach available.**

У нас уже не “набор идей”, а почти нормальная **proof-pipeline архитектура**. Но `/goal` надо настраивать не как “докажи РХ”, а как **узкий боевой приказ Codex’у**: один шаг, один theorem-gate, один compile-check.

---

# 1. Что у нас есть

У нас есть 5 рабочих слоёв.

## 1. **Truth-First Proof Protocol**

Это правила против поддакивания. Их смысл: не принимать ход, пока не ясно, какую дыру он закрывает.

Главный принцип:

```text
не “идея красивая”,
а “какой proof-gate закрыт?”
```

Для RH-проекта это особенно важно, потому что многие маршруты выглядят мощно, но ломаются на одном из стандартных мест: **matrix identification**, **finite-to-global**, **boundary leakage**, **fake positivity**, **scalar mirror wall**.

---

## 2. **Failure / Obstruction Atlas**

Это карта мин, на которые обычно наступают RH-доказательства.

У нас уже выделены стены:

| Стена | Что ломает |
|---|---|
| **Hilbert–Pólya wall** | строят оператор, но не доказывают точное совпадение спектра с нулями |
| **Scalar mirror wall** | получают только симметрию \(s \leftrightarrow 1-s\), но не RH |
| **Coordinate wall** | сравнивают raw matrices вместо форм |
| **Boundary wall** | забывают \(H(1/2), H(-1/2)\) |
| **Matrix identification wall** | матрица положительная, но может быть не той аналитической формой |
| **Finite-to-global wall** | finite certificates не дают глобальную теорему сами по себе |

И текущий маршрут как раз лавирует так:

```text
Failure analysis
→ corrected positive-definite cone
→ Hermitian square
→ Arch − Prime operator difference
→ finite PSD certificate
→ boundary-null exhaustion
→ analytic WeilForm identification
→ global Weil positivity
→ RH
```

Это не декор. Это acceptance criteria для каждого theorem-шагa. fileciteturn3file5

---

## 3. **Hermitian Weil / Gram Positivity Square**

Это главный математический нож сейчас.

Старый scalar route видит только:

\[
\rho \leftrightarrow 1-\rho.
\]

Но off-critical нули тоже имеют такую симметрию. Поэтому scalar identity почти наверняка сгорает в **functional-equation tautology**. fileciteturn3file2

Правильный объект:

\[
f=h*h^\sharp.
\]

Тогда transform даёт:

\[
F(z)=H(z)\overline{H(-\bar z)}.
\]

На критической линии \(z=i\gamma\):

\[
F(i\gamma)=|H(i\gamma)|^2\ge0.
\]

А off-critical ноль может создать отрицательное направление. Поэтому цель:

```text
доказать global Weil positivity
→ запретить off-critical negative directions
→ RH
```

Это и есть **Hermitian positivity square**. fileciteturn3file1

---

## 4. **Operator difference / PSD-pd engine**

Твоя старая идея “Arch operator минус Prime operator” уже приземлена в нормальную архитектуру:

\[
C=A-P.
\]

Где:

**A** — **Arch matrix**, архимедова / gamma-часть.  
**P** — **Prime matrix**, prime-side вклад.  
**C=A-P** — finite Weil matrix.

Дальше есть усиление:

\[
C=(A-\kappa P_0)-(P-\kappa P_0).
\]

И penalty guard:

\[
D_\theta+\tau Q^TQ\succ0,
\qquad
R_\kappa+\tau Q^TQ\succ0.
\]

Это работает на **boundary-null** пространстве:

\[
Qv=0.
\]

То есть finite engine уже есть: **A**, **P**, **P0**, **Q**, **FinitePenaltyCert**, **DirectedCertFamily skeleton**. fileciteturn3file4

---

## 5. **Текущая roadmap: Step 32–35**

По текущей PSD-pd ветке осталось 4 макрошага:

```text
Step 32:
  B-spline matrix identification.

Step 33:
  connect finite analytic positivity to DirectedFamily + exhaustion.

Step 34:
  global boundary-null Weil positivity.

Step 35:
  RH closure / Q3.Main export.
```

Но важно: это не “4 лёгких шага до RH вообще”. Это **4 структурных стены до closure текущей PSD-pd/Q3 route**. Главная текущая дыра — **Step 32**. fileciteturn3file6

---

# 2. Как это работает вместе

Схема такая:

```text
Truth-First Protocol
  ↓
Obstruction Atlas
  ↓
/goal command
  ↓
Codex local Lean execution
  ↓
compiled theorem / blocker report
  ↓
мы обновляем route
```

И математическая цепь:

```text
Hermitian square
  ↓
corrected positive-definite cone
  ↓
Arch − Prime form C = A − P
  ↓
finite PSD certificate
  ↓
B-spline matrix identification
  ↓
DirectedFamily + exhaustion
  ↓
global Weil positivity
  ↓
RH export
```

Самое важное: **Codex не должен “искать доказательство РХ”**. Он должен закрывать один proof-gate за раз.

---

# 3. Как правильно настроить `/goal`

Тебе нужны не один, а три уровня.

## Уровень A — `AGENTS.md`

Это постоянные правила проекта.

Добавь туда блок:

```md
## Q3 Truth-First / Obstruction Protocol

Do not agree with user assumptions by default.

For every theorem or patch, identify which obstruction wall it addresses:

- Matrix-identification wall
- Coordinate wall
- Finite-to-global wall
- Boundary leakage wall
- Scalar mirror wall
- Prime-side wall
- Sociological validation wall

Every theorem must answer:

1. What exact proof-gate does this close?
2. What are the inputs?
3. What are the outputs?
4. What reviewer objection does this kill?
5. Does it compile without new `sorry`, `admit`, `axiom`, or fake weakening?

Forbidden moves:

- Do not claim RH from finite PSD evidence.
- Do not bypass Step 32.
- Do not use raw matrix PSD if Gram correction is needed.
- Do not treat `s ↔ 1-s` symmetry as RH.
- Do not introduce speculative Hilbert–Pólya operators.
- Do not weaken theorem statements just to compile.
```

---

## Уровень B — `Q3_OBSTRUCTION_ATLAS.md`

Это threat model для Codex.

```md
# Q3 Obstruction Atlas — Lean Gate Version

## Main route

corrected positive-definite cone
→ Hermitian square
→ Arch − Prime operator difference C = A − P
→ κ-split / penalty guard
→ FinitePenaltyCert
→ boundary-null exactness
→ Step 32 matrix identification
→ Step 33 DirectedFamily/exhaustion
→ Step 34 global boundary-null Weil positivity
→ Step 35 Q3/RH export

## Step 32 gate

Step 32 is not closed until Lean proves:

1. h_v = Σ_j v_j ψ_j
2. WeilForm(h_v) = vᵀ(A - P)v
3. Qv = (H_v(1/2), H_v(-1/2))
4. if basis is non-orthonormal, positivity is represented Gram-correctly

Failure signal:

- theorem only proves PSD of a finite matrix
- theorem does not identify analytic WeilForm
- theorem depends on raw coordinates
- theorem bypasses Qv endpoint identity

## Step 33 gate

FinitePenaltyCert
+ Step32_BSpline_matrix_identification
→ finite analytic Weil positivity
→ DirectedFamily compatibility
→ boundary-null exhaustion input.

## Step 34 gate

finite analytic positivity over directed family
→ global boundary-null Weil positivity.

## Step 35 gate

global boundary-null Weil positivity
→ Q3.Main / G6 / Weil criterion route
→ RH theorem export.
```

---

## Уровень C — конкретная `/goal` команда

Вот правильный боевой `/goal` прямо сейчас:

```text
/goal Close Step 32 of the Q3/RH Lean pipeline under the Q3 Obstruction Atlas.

Primary target:
Prove the B-spline matrix identification theorem.

Required theorem shape:
For the B-spline packet basis ψ_j and vector v, define

  h_v = Σ_j v_j ψ_j.

Prove:

1. WeilForm(h_v) = vᵀ(A - P)v.
2. Qv = (H_v(1/2), H_v(-1/2)).
3. The finite certified matrix used by FinitePenaltyCert is exactly the analytic WeilForm matrix on the B-spline packet span.
4. If the basis is non-orthonormal, use the correct Gram-corrected / basis-invariant representation.

This closes:
- Matrix-identification wall
- Coordinate wall
- Boundary endpoint identity risk

Do not proceed to Step 33 until Step 32 is compiled or reduced to a precise missing lemma.

Required repo search:
Search for:

- FinitePenaltyCert
- FiniteWeilMatrixModel
- WeilForm
- BSpline
- B-spline
- CenteredCardinalBSpline
- MatrixIdentification
- BoundaryNull
- DirectedCertFamily
- Q3.Main
- G6
- Gram
- endpoint
- H_v
- A_minus_P
- Arch
- Prime

Work loop:
1. Build dependency map.
2. Identify the smallest missing theorem.
3. Prove it.
4. Run `lake env lean <touched-file>`.
5. Run `lake build` if local file compiles.
6. Check no new `sorry`, `admit`, `axiom`, or theorem weakening.
7. Update theorem ledger.
8. Stop only with a compiled theorem or precise blocker report.

Success criteria:
Return:

- compiled theorem name;
- touched files;
- exact commands run;
- obstruction walls closed;
- remaining walls;
- next smallest theorem if blocked.

Hard constraints:
- No fake global axiom.
- No theorem weakening.
- No numerical PSD as proof.
- No raw-coordinate PSD if Gram correction is required.
- No unrelated RH literature review.
- No Hilbert–Pólya detour.

Vibe:
This is not a research brainstorm. This is a reviewer-killing Step 32 bridge.
```

---

# 4. Если хочешь настроить Codex ещё умнее

Делай request/report протокол:

```text
ACTIVE/requests/step32_b_spline_matrix_identification/node.md
ACTIVE/requests/step32_b_spline_matrix_identification/report.md
```

**node.md** — задание Codex’у.  
**report.md** — что он сделал, какие theorem names, какие errors.

Формат `node.md`:

```md
# Request: Step 32 — B-spline Matrix Identification

## Target

Close the B-spline matrix identification gate.

## Required theorem

`Step32_BSpline_matrix_identification`

## Required identities

- `WeilForm(h_v) = vᵀ(A - P)v`
- `Qv = (H_v(1/2), H_v(-1/2))`

## Obstruction walls

- Matrix-identification wall
- Coordinate wall
- Boundary leakage wall

## Commands

```bash
lake env lean <touched-file>
lake build
grep -R "sorry\|admit" Q3 RH *.lean || true
grep -R "axiom\|constant" Q3 RH *.lean || true
```

## Stop condition

Return compiled theorem or exact blocker.
```

---

# 5. Самый правильный следующий `/goal`

Если брать максимально конкретно, не Step 32 целиком, а первый кирпич:

```text
/goal Close Step 32F Arch square-modulus profile.

File:
Q3/Proofs/PSD_CenteredCardinalBSpline.lean

Known theorem:
centeredBSplineImagTransformClosedForm

Target theorem:
centeredBSplineImagTransformProfile_abs_sq

Prove:
|E_{ell,k}(it)|² =
1 / (s_k*c_k) * realSinc(ell*t/(2*s_k))^(2*k+2)

Role:
This is the Arch-entry assembly input for Step 32 B-spline matrix identification.

Obstruction wall:
Matrix-identification wall.

Constraints:
- no sorry/admit
- no Q3.Main edits
- no theorem weakening
- run `lake env lean Q3/Proofs/PSD_CenteredCardinalBSpline.lean`
- report theorem names and blockers
```

Вот это лучше, чем широкий `/goal`, потому что Codex меньше будет фантазировать.

---

# 6. Короткий вывод

У нас есть:

```text
Truth-First Protocol
+ Obstruction Atlas
+ Hermitian positivity square
+ PSD-pd operator-difference engine
+ Step 32–35 roadmap
```

Работает это так:

```text
Atlas говорит, какие стены нельзя игнорировать.
Truth protocol запрещает поддакивать красивым идеям.
Hermitian square задаёт правильную RH-геометрию.
PSD-pd engine даёт finite positivity.
Step 32–35 должны превратить finite positivity в global Weil positivity и RH export.
```

Правильный `/goal`:

```text
не “докажи RH”,
а “закрой конкретный theorem-gate, проверь compile, не обходи Atlas”.
```

Гоблинский перевод:

```text
Не отправляй Codex в лес искать РХ.
Дай ему одну крысу, один коридор, один капкан.
Первый капкан: Step 32 / B-spline matrix identification.
```

