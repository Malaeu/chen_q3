# Rayleigh Q Compilation Issue

https://chat.openai.com/c/696ccc1a-1d98-832c-8417-c8c63139ef1c

## USER
# PROSHKA REQUEST: Rayleigh_Q_identification.lean Performance Crisis                                                                          
                                                                                                                                                   
     **Date:** 2026-01-18                                                                                                                          
     **Priority:** CRITICAL                                                                                                                        
     **Problem:** File compiles for 7+ hours and never finishes                                                                                    
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Problem Summary                                                                                                                            
                                                                                                                                                   
     `Q3/Proofs/Rayleigh_Q_identification.lean` (695 lines) hangs during compilation:                                                              
     - 100% CPU usage                                                                                                                              
     - Memory grows to 10GB+                                                                                                                       
     - Never completes (tested for 7 hours)                                                                                                        
     - No `sorry` in the file — all proofs are "complete"                                                                                          
                                                                                                                                                   
     **Location:** `/Users/emalam/Documents/GitHub/chen_q3/sandboxes/carleson/full/q3.lean.aristotle/Q3/Proofs/Rayleigh_Q_identification.lean`     
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## File Structure                                                                                                                             
                                                                                                                                                   
     Key theorems (from grep):                                                                                                                     
     ```                                                                                                                                           
     line 363: theorem integral_P_A_eq_arch_term (B t : ℝ) (hB : 0 < B) :                                                                          
     line 487: theorem arch_rayleigh_eq (B t : ℝ) (M : ℕ) ...                                                                                      
     line 514: theorem honest_formula (B t K : ℝ) (M : ℕ) ...                                                                                      
     line 537: theorem rayleigh_Q_identification (B t K : ℝ) (M : ℕ) ...                                                                           
     line 613: theorem rayleigh_Q_eq_Q (B t K : ℝ) (M : ℕ) ...                                                                                     
     line 683: theorem rayleigh_Q_eq_Q_shift (B t tau K : ℝ) (M : ℕ) ...                                                                           
     ```                                                                                                                                           
                                                                                                                                                   
     Settings:                                                                                                                                     
     ```lean                                                                                                                                       
     set_option maxHeartbeats 0  -- UNLIMITED!                                                                                                     
     ```                                                                                                                                           
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Suspected Heavy Parts                                                                                                                      
                                                                                                                                                   
     ### 1. `integral_P_A_eq_arch_term` (lines 363-483)                                                                                            
                                                                                                                                                   
     ~120 lines proof with:                                                                                                                        
     - Multiple `HasSum` / `tsum` manipulations                                                                                                    
     - `intervalIntegral` over `ℤ` indexed sums                                                                                                    
     - `Finset.Icc` bounds with `⌈B⌉`                                                                                                              
     - Complex `EqOn` / `integral_congr` chains                                                                                                    
                                                                                                                                                   
     **Complexity signature:**                                                                                                                     
     ```lean                                                                                                                                       
     HasSum (fun n : ℤ => ∫ θ in (-1/2)..(1/2), g B t (θ + n)) (∫ x, g B t x)                                                                      
     ```                                                                                                                                           
                                                                                                                                                   
     This involves:                                                                                                                                
     - Converting between `tsum` and finite sums                                                                                                   
     - Interval integral over varying domains                                                                                                      
     - Multiple reindexing steps                                                                                                                   
                                                                                                                                                   
     ### 2. Dependencies on ShiftedWindows.lean                                                                                                    
                                                                                                                                                   
     ```lean                                                                                                                                       
     import Q3.Proofs.ShiftedWindows                                                                                                               
     ```                                                                                                                                           
                                                                                                                                                   
     ShiftedWindows has 2 sorries:                                                                                                                 
     - `g_shift_zero_of_large_m` (line 97) — sorry                                                                                                 
     - `integral_P_A_shift_eq_arch_term` (line 139) — sorry                                                                                        
                                                                                                                                                   
     **BUT:** These are `sorry` so they should be fast. The problem must be elsewhere.                                                             
                                                                                                                                                   
     ### 3. Type Class Resolution Hell                                                                                                             
                                                                                                                                                   
     The file uses:                                                                                                                                
     ```lean                                                                                                                                       
     [Fintype (Q3.Nodes K)]                                                                                                                        
     ```                                                                                                                                           
                                                                                                                                                   
     `Nodes K` is:                                                                                                                                 
     ```lean                                                                                                                                       
     def Nodes (K : ℝ) : Type := {n : ℕ // 2 ≤ n ∧ Q3.xi_n n ≤ K}                                                                                  
     ```                                                                                                                                           
                                                                                                                                                   
     This subtype with real inequality condition could cause instance search issues.                                                               
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Hypotheses                                                                                                                                 
                                                                                                                                                   
     ### H1: `tsum` over `ℤ` with interval bounds                                                                                                  
     The proof manipulates `∑' m : ℤ, f(m)` with finite support determined by `⌈B⌉`.                                                               
     Lean may be trying to compute/reduce these symbolically.                                                                                      
                                                                                                                                                   
     ### H2: `EqOn` / `Set.uIcc` unification                                                                                                       
     ```lean                                                                                                                                       
     EqOn (fun θ => ∑' m : ℤ, g B t (θ + m))                                                                                                       
          (fun θ => ∑ m ∈ s, g B t (θ + m))                                                                                                        
          ([[(-1/2 : ℝ), (1/2 : ℝ)]])                                                                                                              
     ```                                                                                                                                           
                                                                                                                                                   
     The `Set.uIcc` notation may trigger heavy elaboration.                                                                                        
                                                                                                                                                   
     ### H3: `integral_comp_add_right` conversion                                                                                                  
     ```lean                                                                                                                                       
     intervalIntegral.integral_comp_add_right (f:=fun x => g B t x) (d:=(n : ℝ))                                                                   
     convert hcomp using 1 <;> ring                                                                                                                
     ```                                                                                                                                           
                                                                                                                                                   
     The `convert ... using 1` could be searching for expensive congruence proofs.                                                                 
                                                                                                                                                   
     ### H4: Finset.Icc with ℤ ceiling                                                                                                             
     ```lean                                                                                                                                       
     let s : Finset ℤ := Finset.Icc (-(⌈B⌉ + 1)) (⌈B⌉ + 1)                                                                                         
     ```                                                                                                                                           
                                                                                                                                                   
     `Int.ceil` in Finset bounds may cause elaboration issues.                                                                                     
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## What We Need                                                                                                                               
                                                                                                                                                   
     ### Option A: Identify the Slow Lemma                                                                                                         
     Add `#check_timers` or split file to isolate which theorem hangs.                                                                             
                                                                                                                                                   
     ### Option B: Rewrite Heavy Parts                                                                                                             
     Replace computational patterns with:                                                                                                          
     1. Explicit axioms for periodization identity                                                                                                 
     2. Simpler tsum→finite_sum lemmas                                                                                                             
     3. Avoid `maxHeartbeats 0` — set reasonable limit                                                                                             
                                                                                                                                                   
     ### Option C: Factor Out Utilities                                                                                                            
     Move heavy lemmas like `tsum_subtype_ge_eq_nat_add` to separate utils file that compiles once.                                                
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Request to Proshka                                                                                                                         
                                                                                                                                                   
     Please analyze:                                                                                                                               
                                                                                                                                                   
     1. **Which specific proof construct is likely causing infinite elaboration?**                                                                 
        - Is it `tsum`/`HasSum` manipulation?                                                                                                      
        - Is it `EqOn`/`Set.uIcc` unification?                                                                                                     
        - Is it type class search for `Fintype (Nodes K)`?                                                                                         
                                                                                                                                                   
     2. **What is the recommended rewrite pattern?**                                                                                               
        - Should we use explicit `Finset.sum` from the start?                                                                                      
        - Should we axiomatize the periodization identity?                                                                                         
        - Should we split into smaller files?                                                                                                      
                                                                                                                                                   
     3. **Lean 4 performance best practices for:**                                                                                                 
        - `tsum` over `ℤ` with compact support                                                                                                     
        - `intervalIntegral` with translation                                                                                                      
        - `Finset.Icc` with computed bounds                                                                                                        
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Files to Read                                                                                                                              
                                                                                                                                                   
     - `Q3/Proofs/Rayleigh_Q_identification.lean` (full file)                                                                                      
     - `Q3/Proofs/ShiftedWindows.lean` (dependency)                                                                                                
     - `docs/insights/ARISTOTLE_PROMPT_GUIDELINES.md` (tactic policy)                                                                              
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Priority                                                                                                                                   
                                                                                                                                                   
     This blocks ALL progress on Q3. Without this file compiling:                                                                                  
     - Cannot close `Q_single_atom_nonneg`                                                                                                         
     - Cannot close `Q_nonneg_on_atoms`                                                                                                            
     - Cannot complete RH proof chain                                                                                                              
                                                                                                                                                   
     **Response urgency: HIGH**                                                            

## ASSISTANT
Понял. По симптомам (100% CPU, рост памяти, *никогда* не заканчивает, и при этом стоит `maxHeartbeats 0`) это почти всегда не “медленный lemma”, а **(а) тактика/элаборация, которая ушла в бесконечную/квазибесконечную работу**, или **(б) взрыв размера терма из‑за `simp/convert` на `tsum`/интегралах**, который потом ещё и долго проверяется ядром.

Ниже — максимально практичный разбор “кто виноват” и “как переписать так, чтобы компилилось”.

---

## 1) Кто с наибольшей вероятностью виноват

### 1.1. Главный усилитель кризиса: `set_option maxHeartbeats 0`
Это **не причина**, но это **почему ты не видишь ошибку**. Любая “плохая” ветка тактики (особенно `simp`, `convert`, `aesop`, иногда typeclass search) вместо того, чтобы упасть по heartbeat’ам и показать место, будет молотить бесконечно.

**Вывод:** первым шагом убирай `0` (или ставь большой, но конечный). Иначе ты не отличишь “экспоненциальный взрыв” от “зацикливания”.

---

### 1.2. Самый вероятный реальный виновник: ручная периодизация через `HasSum/tsum` + `intervalIntegral` + `EqOn`
То, что ты описал в `integral_P_A_eq_arch_term` (примерно `HasSum (fun n : ℤ => ∫ θ in (-1/2)..(1/2), g (θ+n)) ) ...`) — это ровно тот класс доказательств, где:

- `simp` пытается протащить равенства под `tsum`, под интегралы, под `EqOn`,
- `convert` генерит гигантские задачи на конгруэнцию,
- на каждом шаге подтягиваются “побочные” typeclass’ы (`Measurable`, `Integrable`, `IntervalIntegrable`, `AE*`), и search может разрастись.

Ключевой сигнал: **у mathlib уже есть готовые леммы для этого exact сценария** — и их использование резко уменьшает размер термов и нагрузку.

В частности, в `Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic` есть лемма  
`MeasureTheory.Integrable.hasSum_intervalIntegral_comp_add_int` (для `Integrable f volume`) про `HasSum` суммы по `ℤ` от интервал-интегралов с сдвигом на целое. citeturn24search1turn31view0  
Плюс есть стандартные леммы вида `intervalIntegral.integral_comp_add_right` и `intervalIntegral.integral_congr_ae`, чтобы **не строить вручную** цепочки `EqOn`/`integral_congr`. citeturn31view0turn23view0

**Вывод по Q(1):** да, *tsum/HasSum манипуляции* — топ‑кандидат №1. `EqOn/Set.uIcc` — №2 (как триггер взрыва `simp/convert`).  

---

### 1.3. `Fintype (Nodes K)` — почти наверняка НЕ первопричина именно этого зависания
Почему: `[Fintype (Nodes K)]` в теореме — это параметр. Он не синтезируется сам по себе, пока ты не делаешь `infer_instance` или что-то типа `Fintype.card` без явного instance.

Но **может стать виновником**, если внутри файла есть место, где Lean пытается *синтезировать* `Fintype (Nodes K)` из “ничего”, и для этого разворачивает тяжёлую цепочку доказательства конечности подтипа `{n // ... ≤ K}`.

**Вывод по Q(1):** как первичный подозреваемый — слабее, чем `tsum/intervalIntegral/convert`. Я бы проверял `Nodes K` только если профайлер покажет, что время уходит в `synthInstance` (см. ниже).

---

## 2) Как быстро и точно поймать “медленное место” (без гадания)

### 2.1. Включи Diagnostics Counters
Lean умеет печатать счётчики по подсистемам (`simp`, typeclass synthesis и т.п.):

```lean
set_option diagnostics true
set_option diagnostics.threshold 5
```

Смысл: он будет репортить места, где счётчики превысили порог. Это официально описано в релизах Lean 4.8/4.9. citeturn29search4turn29search2

Практический эффект: если компиляция “зависает”, то последняя напечатанная команда/теорема обычно и есть виновник, а счётчики скажут — `simp` или `typeclass` или `reduction`.

### 2.2. Включи профайлер тактик локально на подозреваемой теореме
Для тактик есть профайлер `trace.profiler`:

```lean
set_option trace.profiler true in
theorem integral_P_A_eq_arch_term ... := by
  ...
```

Это стандартный приём: даёт древовидную раскладку времени по тактикам/подтактикам. citeturn29search3turn29search17

### 2.3. Убери “бесконечность” из heartbeat’ов
Сделай ошибку воспроизводимой:

- Убери `set_option maxHeartbeats 0`.
- Если реально нужна большая квота — ставь **конечную** (например, 2–5 млн) на уровне конкретной теоремы, а не всего файла.

---

## 3) Рекомендованный rewrite-паттерн (чтобы файл начал компилироваться)

Твой `integral_P_A_eq_arch_term` почти наверняка пытается доказать **классический разбор ℝ на фундаментальный домен длины 1** и сумму по целым сдвигам. Это уже решено в mathlib.

### Вариант A: использовать готовую `Integrable.hasSum_intervalIntegral_comp_add_int` (самый “короткий”)
Идея: вместо ручной сборки `HasSum/tsum` + `Finset.Icc` + “вне диапазона 0”, делай так:

1) докажи `Integrable (fun x => g B t x) volume`;
2) применяй `hfi.hasSum_intervalIntegral_comp_add_int`;
3) если нужно окно `(-1/2)..(1/2)` вместо `0..1`, делай **один** аккуратный сдвиг через `intervalIntegral.integral_comp_add_right` / `..._left`, а не через `convert`‑цепочки. Эти леммы есть в `IntervalIntegral.Basic`. citeturn31view0turn23view0

Скелет (идеологически):

```lean
have hg : Integrable (fun x : ℝ => g B t x) volume := ...
have hsum : HasSum (fun (n : ℤ) => ∫ x in (0:ℝ)..1, g B t (x + n)) (∫ x, g B t x) :=
  hg.hasSum_intervalIntegral_comp_add_int
-- дальше 1 раз переводишь 0..1 -> (-1/2)..(1/2) через integral_comp_add_*
-- и завершаешь `simpa`/`simp_rw`, без `convert`.
```

Факт существования леммы `hasSum_intervalIntegral_comp_add_int` — прямо в docs mathlib. citeturn24search1turn31view0

**Почему это ускоряет:** ты перестаёшь строить огромный ручной терм `HasSum` из кирпичиков, а используешь один “плотный” лемматизированный результат.

---

### Вариант B: фундаментальный домен через `IsAddFundamentalDomain.integral_eq_tsum_of_ac` (самый “концептуально чистый”)
Если тебе принципиально важно окно именно `Ioc (-1/2) (1/2)` или общий `Ioc t (t+1)`, то можно применить machinery фундаментальных доменов:

В `Mathlib.MeasureTheory.Group.FundamentalDomain` есть теорема  
`MeasureTheory.IsAddFundamentalDomain.integral_eq_tsum_of_ac` (и варианты), выражающая интеграл как `tsum` интегралов по translates фундаментального домена. citeturn10view0

Плюс в `IntervalIntegral.Periodic` обсуждается фундаментальный домен `Ioc t (t+T)` для подгруппы `ℤ ∙ T`. citeturn28search1

Это чуть более тяжёлый по зависимостям путь, но он избавляет от ручной “геометрии” покрытия ℝ.

---

## 4) Что конкретно переписать в твоих “подозрительных местах”

### 4.1. `EqOn` / `Set.uIcc` / `integral_congr` цепочки
Если ты используешь:

```lean
intervalIntegral.integral_congr (h : Set.EqOn f g (Set.uIcc a b))
```

то, во‑первых, это нормально (и такая лемма есть). citeturn31view0turn23view0  
Но в тяжёлых доказательствах лучше перейти на **AE‑версию**:

- `intervalIntegral.integral_congr_ae` / `integral_congr_ae_restrict`, чтобы не заставлять `simp` работать с `uIcc` как с set‑термом, а просто закрывать `AE`‑равенство. Эти леммы тоже есть. citeturn31view0turn23view0

**Паттерн:**
- вместо `EqOn` + `by intro x hx; ...`
- делай `refine intervalIntegral.integral_congr_ae ?_`
- и доказывай `∀ᵐ x ∂(volume.restrict (Set.uIoc a b)), f x = g x` через `Filter.eventually_of_forall` если равенство точечное.

Это обычно уменьшает унификацию и `simp`‑нагрузку.

---

### 4.2. `convert ... using 1 <;> ring` на интегралах
`convert` — полезный, но **дорогой**: он создаёт цели на равенство/конгруэнцию больших выражений и запускает тяжёлую машинерию.

**Заменяй на:**
- `simpa [add_assoc, add_comm, add_left_comm]` если это просто перестановка,
- `simp_rw` с 1–2 леммами,
- или `have` маленьких равенств для концов интервала (типа `by ring`) *до* применения интегральной леммы.

Если ты уже используешь `intervalIntegral.integral_comp_add_right`, то очень часто хватает:

```lean
simpa [add_assoc] using intervalIntegral.integral_comp_add_right (f := ...) (d := (n:ℝ))
```

Вместо `convert`.

Лемма `intervalIntegral.integral_comp_add_right` существует и именно для этого. citeturn31view0turn23view0

---

### 4.3. `Finset.Icc` с `Int.ceil` прямо в границах
Это редко “бесконечно”, но часто **ужасно раздувает** цели, особенно если дальше ты переписываешь/сравниваешь эти границы в `simp`/`linarith`.

**Паттерн стабилизации:**
```lean
let N : ℤ := ⌈B⌉ + 1
let s : Finset ℤ := Finset.Icc (-N) N
```
и дальше никогда не раскрывай `N` обратно в `⌈B⌉ + 1`, пока не надо.  
Если нужно, докажи отдельно леммы вида `abs m ≤ N → ...` и `abs m > N → ...`.

---

## 5) Best practices именно под твои 3 пункта

### 5.1. `tsum` по `ℤ` при компактной поддержке
- Если поддержка реально конечна: **работай Finset’ом с самого начала** и в конце делай `tsum_eq_sum`/`HasSum` через “finite support”.  
- Если в mathlib уже есть лемма уровня `Integrable → HasSum` (как тут), *не* “опускай” до Finset вообще — это чаще всего быстрее и короче.

### 5.2. `intervalIntegral` и перенос (translation)
- Используй готовые леммы `intervalIntegral.integral_comp_add_right/left` вместо “переписывания границ + convert”. citeturn31view0turn23view0
- Для замены подынтегральной функции: предпочитай `intervalIntegral.integral_congr_ae` (AE‑версия) вместо больших `EqOn` с `uIcc`. citeturn31view0turn23view0

### 5.3. `Finset.Icc` с вычисляемыми границами (`ceil`)
- “Заморозь” границы в локальной константе `N` (см. выше).
- Не давай `simp` трогать `Int.ceil`/`Nat.ceil` без крайней нужды.
- Если нужна арифметика на `Icc`: лучше отдельно держать леммы о включениях/пустоте, чем каждый раз гонять `linarith` по развёрнутым `ceil`.

---

## 6) Мой конкретный ответ на твои 3 вопросы

### (1) Что именно вероятнее всего вызывает “бесконечную” компиляцию?
**Самый вероятный источник:** комбинация `tsum/HasSum` + `intervalIntegral` + `EqOn` + `convert` внутри `integral_P_A_eq_arch_term`, усиленная `maxHeartbeats 0`.  
Почти наверняка это либо:
- “взрыв” в `simp`/`convert` на огромных термах,
- либо зациклившаяся/крайне дорогая typeclass synthesis (`Integrable`, `Measurable`, `Summable`) внутри этих шагов.

`Fintype (Nodes K)` как первичная причина — маловероятно, если только ты не делаешь `infer_instance` для него в этом же файле.

### (2) Рекомендуемый rewrite pattern?
**Да:**
- использовать готовую `MeasureTheory.Integrable.hasSum_intervalIntegral_comp_add_int` как “ядро” периодизации и убрать ручной `HasSum`‑конструктор; citeturn24search1turn31view0
- сдвиги интервалов — через `intervalIntegral.integral_comp_add_right/left`, без `convert`; citeturn31view0turn23view0
- `EqOn` → `...congr_ae` там, где можно.

А “аксиоматизировать периодизацию” я бы делал только как last resort. Судя по библиотеке, это как раз тот случай, когда лучше опираться на mathlib.

### (3) Best practices по трём темам?
Смотри раздел 5; плюс обязательно используй:
- `set_option diagnostics true` + `diagnostics.threshold` чтобы быстро видеть, где горит; citeturn29search4turn29search2
- `set_option trace.profiler true in` вокруг подозреваемых теорем, чтобы увидеть реальный “топ по времени”. citeturn29search3turn29search17

---

## Мини‑чеклист “разблокировать сегодня”
1) Убери `maxHeartbeats 0`.  
2) Включи `diagnostics` + low threshold. citeturn29search4turn29search2  
3) Оберни `integral_P_A_eq_arch_term` в `trace.profiler`. citeturn29search3turn29search17  
4) Перепиши `integral_P_A_eq_arch_term` на вызов `hg.hasSum_intervalIntegral_comp_add_int` + один сдвиг интервала (`integral_comp_add_right`). citeturn24search1turn31view0turn23view0  

Если сделать только пункт (4), есть хороший шанс, что файл начнёт собираться на порядки быстрее даже без точной диагностики.

Если хочешь, в следующем сообщении набросай *точные* 5–10 строк формулировки твоего `integral_P_A_eq_arch_term` (statement + как у тебя сейчас выглядит `g`) — я предложу максимально близкий “drop‑in” скелет доказательства под существующую сигнатуру (без `convert` и без ручной `Finset.Icc`).

## USER
diff --git a//Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotle/aristotle_input/proshka_tau_shift_floor_request_2026_01_18.md b//Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotle/aristotle_input/proshka_tau_shift_floor_request_2026_01_18.md
new file mode 100644
--- /dev/null
+++ b//Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotle/aristotle_input/proshka_tau_shift_floor_request_2026_01_18.md
@@ -0,0 +1,63 @@
+# Proshka request: tau-shift arch floor (A3) for P_A_shift
+
+## TL;DR
+Нужна формальная лемма для **tau-сдвинутого** символа `P_A_shift`, чтобы закрыть
+`Q_nonneg_on_atoms_of_A3_Fourier_RKHS_axiom`.
+
+Сейчас готово:
+- `Q3/Proofs/ShiftedWindows.lean`: `phi_shift`, `g_shift`, `P_A_shift`,
+  `integral_P_A_shift_eq_arch_term` (arch_term = integral of P_A_shift).
+- `A3_FLOOR_v22_stage4_floor.lean`: `P_A_ge_c_star` **только для** `P_A B_min t_sym` (tau=0).
+- `Q3/Proofs/RKHS_cap_rayleigh.lean`: tau-кап (Variant 1) уже сделан.
+
+Блокер: **arch floor для tau-сдвига** (нижняя оценка `arch_term (phi_shift ...)`).
+
+## Что нужно от тебя
+1) Подтвердить корректную **математическую формулировку** для tau-сдвига.
+2) Дать **структуру доказательства** (или skeleton), чтобы перевести в Lean.
+3) Сказать, нужно ли **править формулировку У3** (например, перейти на K-локальный floor).
+
+## Текущая Lean-цель (идеал)
+Вариант, максимально близкий к текущей архитектуре:
+
+```lean
+-- хотим что-то такого вида
+lemma P_A_shift_ge_c_star
+  (τ : ℝ) (hτ : |τ| + B_min ≤ K) :
+  ∀ θ ∈ Set.Icc (-1/2 : ℝ) (1/2),
+    P_A_shift B_min t_sym τ θ ≥ c_star
+```
+
+Тогда через `integral_P_A_shift_eq_arch_term` получаем:
+`arch_term (phi_shift B_min t_sym τ) ≥ c_star`.
+
+## Если это НЕ верно
+Тогда нужен **корректный K-зависимый floor**:
+
+```lean
+def c_star_K (K : ℝ) : ℝ := ...
+lemma P_A_shift_ge_c_star_K
+  (τ : ℝ) (hτ : |τ| + B_min ≤ K) :
+  ∀ θ ∈ Set.Icc (-1/2 : ℝ) (1/2),
+    P_A_shift B_min t_sym τ θ ≥ c_star_K K
+```
+
+и дальше проверяем, что `c_star_K/4 - rho_oneK K > 0`.
+
+## Контекст файлов
+- `A3_FLOOR_v22_stage4_floor.lean` — есть floor только при tau=0.
+- `Q3/Proofs/ShiftedWindows.lean` — есть `P_A_shift` и arch integral.
+- `Q3/Proofs/RKHS_cap_rayleigh.lean` — tau-кап (Variant 1, rho_oneK).
+
+## Вопрос по тексту У3
+Явно ли в У3 сказано, что floor **устойчив к сдвигу**?
+Если да — нужна ссылка/лемма (например, "shift-robust core mass" / Lemma 8.13?).
+
+Если нет — возможно, надо менять формулировку в У3:
+1) переход на K-локальный floor,
+2) grid→continuum (Lipschitz lift) вместо равномерного floor.
+
+## Что от тебя нужно в ответе
+- Четкая математическая формулировка (c_star или c_star_K).
+- Минимальный набор лемм (какие оценки нужны).
+- Скелет Lean-лемм (или хотя бы путь по существующим леммам/фактам).

## USER
И ? Чувак не вижу ответ ?

## ASSISTANT
## 0. Диагноз и статус

**Тезис (одно предложение):** зависание компиляции `Rayleigh_Q_identification.lean` почти наверняка не “бесконечная компиляция”, а **взрыв элаборации/тактики в одном конкретном месте**, который ты сам сделал невидимым через `set_option maxHeartbeats 0`.

**Статус:** это типичный Lean‑performance баг: либо “конгруэнс/`convert`‑ад”, либо “`simp`/`aesop` раздувает цель до гигантской”, либо “`tsum`/`HasSum` + интегралы запускают тяжёлый machinery (Summable/Integrable/Fubini) там, где по факту всё конечноподдержанное”.

---

## 1. Что, по симптомам, *маловероятно* является первопричиной

### 1.1 `[Fintype (Nodes K)]` как “typeclass hell”
Это **не похоже** на главный источник 7‑часового 100% CPU + 10GB памяти:

- если бы зависание было в синтезе `Fintype`, ты бы обычно видел это **во многих местах проекта**, а не только в одном файле;
- синтез инстанса чаще либо быстро срабатывает, либо быстро упирается в цикл/неразрешимость (и ты бы диагностировал через `trace.Meta.synthInstance`).

**Но**: если в этом файле где-то реально вычисляется `Finset.univ` для `Nodes K`, считается `Fintype.card`, или идёт `simp` по `Nodes K` с раскрытием “bounded by K” через `Real.log`, тогда да — может стать тяжёлым. Это уже не “инстанс”, это “вычисления/упрощения на данных”.

---

## 2. Наиболее вероятный виновник (и почему)

### 2.1 Комбо №1: `tsum/HasSum` + `intervalIntegral` + “потом окажется, что поддержка конечная”
Ты сам описал сигнатуру:

```lean
HasSum (fun n : ℤ => ∫ θ in (-1/2)..(1/2), g B t (θ + n)) (∫ x, g B t x)
```

Это **красная зона** в Lean по производительности, потому что:

- `HasSum`/`tsum` тянут за собой огромный пласт лемм про `Summable`, `hasSum_iff`, `tsum_eq`, иногда про перестановку суммы и интеграла;
- `intervalIntegral` — это “ориентированная” конструкция с `if a ≤ b then … else …`; в паре с `Set.uIcc` ещё одно `if`;
- если доказательство *по смыслу* сводится к “все слагаемые кроме конечного числа равны 0”, то **правильная инженерия** — с самого начала жить в `Finset.sum`, а не в `tsum`.

То есть у тебя типичная анти‑схема: *сначала бесконечность → потом доказать конечность → потом снова интегралы/конгруэнс*.

### 2.2 Комбо №2: `convert … using 1` вокруг переводов интеграла (особенно с `ring`)
Ты явно подозреваешь:

```lean
intervalIntegral.integral_comp_add_right ...
convert hcomp using 1 <;> ring
```

Это действительно частый “пожиратель времени”, потому что `convert`:
- создаёт большие цели на равенство выражений с биндерами,
- запускает унификацию с кучей метапеременных,
- а `ring`/`ring_nf` потом разворачивает и нормализует **очень большие термы** (особенно если там есть касты `Int.cast`, `Rat.cast`, `bit0`, `sub_eq_add_neg`, и т.д.).

### 2.3 `EqOn`/`Set.uIcc` как усилитель взрыва
Сам по себе `EqOn` не страшен, но он часто приводит к паттерну:

- “экстенсиональность на множестве” → куча `simp` по `Set.uIcc` (`dite`) → `linarith`/`nlinarith` в условии → снова `simp`.

Это редко *единственная* причина 7 часов, но легко становится **мультипликатором** в сочетании с 2.1–2.2.

---

## 3. Немедленный триаж: как локализовать “какая лемма жрёт всё” (без гадания)

### 3.1 Убери “бессмертие” (`maxHeartbeats 0`)
Это первый сигнал: **ты отключил единственный встроенный предохранитель**.

Сделай так:

- глобально в файле поставь что-то вроде `set_option maxHeartbeats 200000` (или даже меньше, чтобы быстро падало);
- и **точечно** повышай лимит только для маленьких локальных блоков (если реально нужно).

Смысл: ты хочешь получить *ошибку “max heartbeats exceeded” с позицией* — это и есть указатель на точку взрыва.

### 3.2 Бисекция по теоремам (линейная, без инструментов)
Раз файл 695 строк и “висит навсегда”, делай грубо:

1) закомментируй всё после `integral_P_A_eq_arch_term`; проверь, компилируется ли быстро;  
2) если да — виновник ниже; если нет — виновник внутри неё/до неё;  
3) затем делай бинарное деление блока.

Это тупо, но на практике даёт ответ за 10–20 минут.

### 3.3 Если подозрение на typeclass search
Только когда получишь конкретную строку, включай трассировку **локально** (иначе утонешь в выводе):
- `trace.Meta.synthInstance` (если реально кажется, что он бесконечно синтезит инстансы),
- или трассы на `simp`/`convert` в нужном месте.

---

## 4. Рекомендуемый rewrite‑паттерн (то, что реально лечит такие подвисания)

### 4.1 Главная идея: “finite‑first”
Если у тебя **компактная поддержка**, то конструктивно:

1) докажи один раз лемму “вне диапазона `|m| ≤ N` слагаемые ноль”;
2) зафиксируй `N` и `s : Finset ℤ`;
3) перепиши `P_A` и всё, что с ним связано, **через `Finset.sum`** на `s`;
4) `tsum` используй только в самом конце (и лучше вообще не используй, если не нужно).

Скелет:

```lean
-- 1) один раз фиксируем границу
let N : ℤ := (Int.ceil B) + 1
let s : Finset ℤ := Finset.Icc (-N) N

-- 2) ключ: вне s всё равно 0
lemma g_shift_eq_zero_outside (θ : ℝ) (hθ : θ ∈ Set.Icc (-1/2) (1/2)) :
  ∀ m : ℤ, m ∉ s → g B t (θ + m) = 0 := by
  -- чистая оценка |θ+m| ≥ B, дальше твоя existing lemma g_eq_zero_of_abs_ge
  ...

-- 3) один переход от tsum к sum
lemma tsum_g_eq_sum (θ : ℝ) (hθ : θ ∈ Set.Icc (-1/2) (1/2)) :
  (∑' m : ℤ, g B t (θ + m)) = ∑ m in s, g B t (θ + m) := by
  -- используй tsum_eq_sum_of_support_subset / tsum_eq_sum (в зависимости от того, что у тебя есть)
  -- но сделай это ОДИН РАЗ и потом реюзай
  ...
```

Дальше всё интегральное делай **через `Finset.sum`**, а не через `tsum`:
- перестановка `∫` и `∑` для `Finset` почти бесплатна (стандартные леммы `integral_finset_sum`, `intervalIntegral.integral_finset_sum` и т.п.);
- для `tsum` перестановка — дорогая.

### 4.2 Убийца `convert`: замени на “целенаправленный `simpa`”
В местах типа:

```lean
have hcomp := intervalIntegral.integral_comp_add_right ...
convert hcomp using 1 <;> ring
```

замена‑паттерн:

- сначала выдели маленькую лемму про арифметику аргументов (`by ring_nf`),  
- затем применяй её через `simp`/`simpa` **без** `convert`.

Например:

```lean
have hcomp := intervalIntegral.integral_comp_add_right (f := fun x => g B t x) (d := (n:ℝ))
-- вместо convert:
simpa [add_assoc, add_left_comm, add_comm] using hcomp
```

И да: **`ring_nf` лучше, чем `ring`** в таких местах (обычно стабильнее и меньше “магии”).

### 4.3 Убери `Set.uIcc` и “двойные if”
У тебя одновременно могут быть:
- `Set.uIcc` (неупорядоченный интервал через `if`),
- `intervalIntegral` (ориентация через `if`).

Если ты везде реально используешь `(-1/2)..(1/2)` и `Icc (-1/2) (1/2)`, то просто **прибей это явно**:
- `Set.Icc (-1/2) (1/2)` вместо `[[(-1/2),(1/2)]]`.

Это не “косметика”: это резко уменьшает объём целей после `simp`.

---

## 5. Lean 4 best practices по твоим трём пунктам

### 5.1 `tsum` over `ℤ` при конечной поддержке
**Делай:**
- докажи `∀ᶠ m, f m = 0` или “вне `s` ноль” и *одним* шагом переведи `tsum` в `Finset.sum`;
- кешируй `s` и `N` как `let`/`have` и дальше работай с ними, не пересоздавая.

**Не делай:**
- не пытайся много раз “в разных местах” заново доказывать, что поддержка конечная;
- не таскай `HasSum` там, где по смыслу конечная сумма.

### 5.2 `intervalIntegral` + translation
**Делай:**
- используй готовые леммы про `integral_comp_add_right/left` (как ты уже делаешь),  
  но добивай равенства через `simpa [...]`, а не `convert`;
- фиксируй `a b` и доказывай `ha : a ≤ b` один раз, а не гоняй `linarith` в каждом `simp`.

**Не делай:**
- `convert … using 1 <;> ring` на термах с кастами/интами/рационалами/константами — это реально частый источник “10GB RAM”.

### 5.3 `Finset.Icc` с `Int.ceil`
**Делай:**
- введи `N : ℤ := Int.ceil B + 1` один раз;
- если часто нужен `Nat`, работай через `Nat` и `Int.ofNat` аккуратно, но опять же — один раз;
- для membership‑целей используй леммы `Finset.mem_Icc` и затем `omega`/`linarith` *после* того, как всё приведено к чистой арифметике.

**Не делай:**
- не раскрывай `Int.ceil` внутри `simp`‑цепочек;
- не создавай `Finset.Icc (-(⌈B⌉ + 1)) (⌈B⌉ + 1)` в 10 местах: каждое раскрытие добавляет мусор в элаборацию.

---

## 6. Важная страховка: не “упростить” ценой нарушения контракта A3

Когда будешь переписывать Rayleigh/Toeplitz часть ради производительности, не уходи в запрещённые упрощения типа sampling Toeplitz или подмену символа на `a_star`. Контракт проекта прямо фиксирует: символ A3 — **периодизация `P_A` на period‑1 торе**, Toeplitz — через Fourier/Rayleigh, не через `P(π(i-j)/M)` и т.п. fileciteturn0file8 fileciteturn0file11

---

## 7. Мини‑вывод по твоим вопросам

1) **Что, скорее всего, вызывает “бесконечную” компиляцию?**  
   Самое вероятное: **внутри `integral_P_A_eq_arch_term`** комбинация  
   `tsum/HasSum`‑machinery + `intervalIntegral` + тяжёлые `convert`/`ring`/`simp` цепочки, которые раздувают термы и унификацию.  
   `Fintype (Nodes K)` — вторичный подозреваемый и только если где-то реально вычисляются `Finset.univ/card` или `simp` раскрывает определение `Nodes K` агрессивно.

2) **Рекомендуемый rewrite‑паттерн:**  
   **Finite‑first:** вырази периодизацию как `Finset.sum` на `Icc (-N) N` один раз (через лемму “вне диапазона ноль”), дальше интегралы/конгруэнс делай в финитарном мире; `tsum` используй либо один раз, либо вообще убери.

3) **Best practices:**  
   - `tsum` с конечной поддержкой → “одна лемма `tsum = finset.sum`, потом только `Finset`”;  
   - `intervalIntegral` сдвиг → `simpa` вместо `convert`;  
   - `Finset.Icc` + `ceil` → `let N := …` и не раскрывать `ceil` в `simp`.

---

Если хочешь, я могу дать **конкретный “переписанный” skeleton** для `integral_P_A_eq_arch_term` (с точными промежуточными леммами), но для этого мне нужен именно кусок кода: определения `g`, как именно ты доказываешь “g=0 вне окна”, и как сейчас устроен переход `tsum → sum`. Сейчас без файла я даю максимально вероятную диагностику и инженерный план, который в Lean обычно реально “размораживает” такие зависания.

## ASSISTANT
Ок, даю ответ сразу. Две части: **(I) почему `Rayleigh_Q_identification.lean` может “вечно” компилиться и что переписать**, **(II) что делать с τ‑сдвигом (A3 floor для `P_A_shift`)**.

---

## I. Rayleigh_Q_identification.lean: где почти наверняка “взрыв” и почему

### 0. Теорема и статус
**Утверждение (инженерное):** если в доказательстве периодизации/интеграла ты держишь `tsum/HasSum` над `ℤ` и параллельно гоняешь `intervalIntegral` + `EqOn`/`integral_congr`/`convert`, то Lean 4 может уйти в **экстремально дорогую элаборацию/упрощение**, особенно при `maxHeartbeats 0`, и “не закончить никогда”.

**Статус:** стандартная проблема производительности Lean 4 (не математика, а proof‑engineering).

---

### 1. Контекст (что в твоём описании выглядит как красная зона)
Ты сам уже попал в правильные “подозреваемые”:

- `integral_P_A_eq_arch_term` — длинная цепочка `HasSum`/`tsum`, `intervalIntegral`, `Finset.Icc` с `⌈B⌉`.
- `EqOn` + `Set.uIcc` + `integral_congr` — часто запускает тяжёлые унификации и simp‑цепочки.
- `convert ... using 1 <;> ring` — классический источник **огромных целей по равенству** (и дальше конгруэнс-генераторы начинают строить мегатермы).
- `set_option maxHeartbeats 0` — ты отключил единственный “предохранитель”; если где-то реально экспонента/петля simp, компиляция будет “вечной”.

Про `Fintype (Nodes K)` — это **менее вероятно**, что именно оно даёт 7 часов 100% CPU. Оно может быть неприятным, но обычно это “минуты/десятки минут”, а не бесконечный рост памяти до 10GB. Гигантский рост памяти — чаще **терм взрывается** (конверты/конгруэнс/переписывания) или симп/инстанс‑резолвер строят огромный объект.

---

### 2. Диагноз: что именно, скорее всего, вызывает “бесконечную” элаборацию

#### (D1) Самый вероятный виновник: `convert ... using 1` в связке с `intervalIntegral.integral_comp_add_right`
**Почему:** `convert` пытается найти “почти” definitional equality и порождает огромные подцели равенства выражений с интегралами, интервалами, кастами `Int.cast`, `sub_eq_add_neg`, и т.д. Затем `ring` на таких целях может раздуваться.

**Сигнал:** если зависает в местах, где ты “чуть-чуть” меняешь границы `(-1/2)..(1/2)` на `(n-1/2)..(n+1/2)` и делаешь `ring`, это оно.

#### (D2) Второй вероятный: `EqOn`/`integral_congr` на `Set.uIcc`
**Почему:** `EqOn` часто требует доказательств равенства функций на множестве, что тянет за собой переписывание `Set.uIcc`, приведение типов, и симп начинает раскрывать определения множеств/интервалов и т.п.

#### (D3) Третий: `tsum` над `ℤ` в ситуации **фактически конечной суммы**, но Lean вынужден тащить Summable/Integrable/Fubini
**Почему:** ты математически знаешь “тут конечная поддержка”, но если ты поздно переводишь `tsum → Finset.sum`, Lean начинает строить инфраструктуру (summable, integrable, swap integral/tsum). Это часто **не заканчивается быстро**, если не дать ему правильную форму.

#### (D4) Наименее вероятный: `Fintype (Nodes K)`
Сама по себе эта инстанция может быть тяжёлой, но “7 часов без конца” обычно не от неё. Если это всё же она — тогда зависание будет **раньше**, уже при первых `by classical`/`simp` где требуется `Fintype`. Но твой “подозреваемый #1” всё равно более типичный.

---

## II. Как быстро локализовать “медленный” кусок (не гадая)

### 0. Главное правило
**Верни heartbeats.** `maxHeartbeats 0` сейчас мешает диагностике.

### 1. Минимальный протокол изоляции
1) Вверху файла поставь что-то типа:
- `set_option maxHeartbeats 300000` (или 1–3 млн)  
и **убери `0`**.

2) Разрежь файл на “промежуточные checkpoints”:
- закомментируй всё после `integral_P_A_eq_arch_term`, проверь компиляцию;
- если компилируется — значит зависает ниже;
- если нет — зависает внутри этой леммы/её локальных `have`.

3) Самый эффективный трюк:
- внутри тяжелой леммы временно заменяй блоки на `by
    -- isolate
    admit`
  и смотри, где “перестает виснуть”.  
Да, это грязно, но это **самая быстрая бинарная локализация**.

---

## III. Рекомендованный rewrite-паттерн для `integral_P_A_eq_arch_term`

### 0. Цель (математически)
Ты хочешь стандартную идентичность периодизации:
\[
\int_{-1/2}^{1/2} \left(\sum_{m\in\mathbb{Z}} g(\theta+m)\right)\,d\theta
\;=\;
\int_\mathbb{R} g(x)\,dx,
\]
когда у `g` компактная поддержка.

### 1. Ключевой инженерный принцип (сильно ускоряет Lean)
**Не доказывай это через `HasSum`/Fubini, если у тебя compact support.**  
Сделай так, чтобы Lean увидел **конечную сумму сразу**, тогда:
- нет `Summable`/`Integrable` инфраструктуры на `tsum`;
- нет swap `∫` и `∑'`;
- нет `EqOn`/`integral_congr` по сути.

### 2. Правильная форма (шаблон)
**Шаг A.** Выбираешь один раз “радиус” и Finset:

- Пусть `N : ℕ := Nat.ceil B + 2` (или `Nat.ceil (B + 1)` — что легче доказать).
- `s : Finset ℤ := Finset.Icc (-(N : ℤ)) (N : ℤ)`.

**Шаг B.** Доказываешь “вне `s` ноль” **в виде леммы**:

> `lemma g_eq_zero_of_not_mem (θ ∈ Icc (-1/2) (1/2)) (m : ℤ) (hm : m ∉ s) : g B t (θ+m)=0`

Важно: **не раскрывай `s` много раз**. Один `let s := ...` и дальше работай с ним.

**Шаг C.** Сразу убиваешь `tsum`:

\[
\sum'_{m:\mathbb{Z}} g(\theta+m) = \sum_{m\in s} g(\theta+m)
\]

в Lean это обычно через лемму типа `tsum_eq_sum`/`tsum_eq_sum_of_support_subset` (названия могут отличаться), но идея одна: “вне finset = 0 ⇒ `tsum` = `Finset.sum`”.

**Шаг D.** Меняешь интеграл:

\[
\int_{-1/2}^{1/2} \sum_{m\in s} g(\theta+m)\,d\theta
= \sum_{m\in s} \int_{-1/2}^{1/2} g(\theta+m)\,d\theta
\]

Это **быстро**, потому что сумма конечная (`intervalIntegral.integral_sum` / `integral_finset_sum`).

**Шаг E.** Сдвиг интервала — но без `convert`:
Используй лемму `intervalIntegral.integral_comp_add_right` (или аналог) так, чтобы цель закрывалась `simpa` + переписывание границ, а не `convert`.

Идея:
\[
\int_{-1/2}^{1/2} g(\theta+m)\,d\theta
=
\int_{m-1/2}^{m+1/2} g(x)\,dx.
\]

**Критично:** избегай `convert ... using 1`. Лучше “подогнать” выражение заранее:

- сделай `have := intervalIntegral.integral_comp_add_right (f := fun x => g B t x) (a := -1/2) (b := 1/2) (d := (m:ℝ))`
- потом `simpa [add_assoc, add_left_comm, add_comm, sub_eq_add_neg]` using that.

**Шаг F.** Собираешь сумму по `m ∈ s` в один интеграл по большому интервалу, а затем режешь до `ℝ` по support:
- `∑_{m∈s} ∫_{m-1/2}^{m+1/2} g = ∫_{-(N+1/2)}^{N+1/2} g`
  (это можно сделать через разбиение на смежные интервалы; даже если это неприятно — можно оставить как конечную сумму, а потом показать что “вне [-B,B] ноль”, и что этот finset покрывает support).
- затем `∫_{-(N+1/2)}^{N+1/2} g = ∫_ℝ g` потому что `g=0` вне.

**Выигрыш:** никакого `EqOn`, никакого `HasSum`, никакого Fubini.

---

## IV. Lean 4 best practices для твоих 3 болевых точек

### A) `tsum` over `ℤ` при конечной поддержке
1) Доказывай “finite support” **явно** и **сразу**:
   - `∀ m ∉ s, f m = 0`
2) Делай `tsum` → `Finset.sum` максимально рано.
3) Не заставляй Lean доказывать `Summable`/`HasSum` через анализ — пусть это будет “finite sum”.

Практический хак:
- держи отдельную лемму `support_subset_Icc` или `eq_zero_of_abs_large`.
- используй `Nat.ceil` → потом cast в `ℤ`. `Int.ceil` внутри `Finset.Icc` хуже.

### B) `intervalIntegral` + translation
1) Избегай `convert`.
2) Своди к `by simpa [...] using intervalIntegral.integral_comp_add_right ...`.
3) Не давай `ring` цели, где полно `Int.cast` и `sub`/`add` вперемешку. Сначала `simp [sub_eq_add_neg]`, приведи к нормальной форме, потом `ring_nf` если реально надо.

### C) `Finset.Icc` с “вычисляемыми” границами (`⌈B⌉`)
1) Вынеси границы в `let`:
   ```lean
   let N : ℕ := Nat.ceil B + 2
   let s : Finset ℤ := Finset.Icc (-(N : ℤ)) (N : ℤ)
   ```
2) Никогда не пиши `Finset.Icc (-(⌈B⌉ + 1)) (⌈B⌉ + 1)` прямо в цели — это взрывает `simp`/касты.
3) Если `N` используется 15 раз — сделай `have hN : ... := ...` и переиспользуй.

---

## V. τ‑shift arch floor для `P_A_shift`: что корректно по математике и как закрывать в Lean

### 0. Теорема и статус
**Утверждение (проверяемое):** существует “τ‑сдвинутая” версия arch floor для `P_A_shift`, и она либо:
- (Case 1) **тривиально следует** из floor для `P_A`, если `P_A_shift` — это просто *трансляция* `P_A` по `θ` (или `g` целиком);  
- (Case 2) требует **K‑зависимого floor** (или ограничения на τ), если `P_A_shift` реально меняет, где берётся фактор `a(ξ)`.

**Статус:** зависит от точного определения `P_A_shift` в `ShiftedWindows.lean`.

---

### 1. Главная “аномалия”, на которую надо указать
Если вдруг в твоих определениях
\[
g_{\text{shift}}(\xi) = a(\xi)\cdot \Phi(\xi-\tau)
\]
(то есть сдвигается только окно, а `a` остаётся “на месте”), то **одинаковый floor `c_*` для всех τ быть не может** без дополнительных ограничений на τ. Причина простая: `a(ξ)` убывает и становится отрицательной на больших |ξ| (это стандартно для digamma‑ядра). Значит при больших τ окно будет сидеть там, где `a` отрицательная, и arch‑часть станет отрицательной.

Это критический sanity‑check: если ты пытаешься доказать “uniform `c_*` по τ” в этом случае, Lean может “не просто тормозить” — он может пытаться выжать невозможное через очень тяжёлые цепочки.

---

### 2. Рекомендую два сценария (и Lean‑скелеты)

#### Case 1 (лучший): `P_A_shift` — это просто сдвиг `P_A` по θ (или сдвиг всего g)
**Тогда формулировка с тем же `c_*` корректна**, и доказательство короткое.

Тебе нужно *одна* лемма‑мост:

```lean
-- примерная форма, подгони под свои def
lemma P_A_shift_eq_translate (B t τ θ : ℝ) :
  P_A_shift B t τ θ = P_A B t (θ - τ) := by
  -- unfold P_A_shift P_A g_shift g ...
  -- algebra
  sorry
```

Дальше:

```lean
lemma P_A_shift_ge_c_star
  (τ : ℝ) :
  ∀ θ ∈ Set.Icc (-1/2 : ℝ) (1/2),
    P_A_shift B_min t_sym τ θ ≥ c_star := by
  intro θ hθ
  -- перепиши через translate
  simp [P_A_shift_eq_translate]  -- или rw
  -- теперь нужно свести (θ-τ) к фундаментальному домену и применить P_A_ge_c_star
  -- используешь periodicity P_A_periodic и "mod 1" лемму
  sorry
```

Технический момент: `P_A_ge_c_star` у тебя на `Icc(-1/2,1/2)` (в A3_FLOOR) — см. файл `A3_FLOOR_v22_stage4_floor.lean` вокруг `P_A_ge_c_star`.  
Поэтому надо либо:
- доказать `∀ x, ∃ k:ℤ, x - k ∈ Icc(-1/2,1/2)`, и использовать `P_A_periodic` чтобы убрать `k`,  
либо
- заранее усилить floor до `∀ x, P_A x ≥ c_star` (через periodicity + локальная лемма).

**Это реально короткий путь.**

#### Case 2 (если `a` не сдвигается вместе с окном): uniform `c_*` по τ скорее всего ложен ⇒ нужен `c_*(K)` или ограничение на τ
Тогда твой “запасной план” из запроса выглядит правильно:

```lean
def c_star_K (K : ℝ) : ℝ := ...
lemma P_A_shift_ge_c_star_K
  (τ : ℝ) (hτ : |τ| + B_min ≤ K) :
  ∀ θ ∈ Set.Icc (-1/2 : ℝ) (1/2),
    P_A_shift B_min t_sym τ θ ≥ c_star_K K := ...
```

Но (!) тут важно: чтобы этот путь вообще вёл к `Q ≥ 0`, тебе нужно:
- гарантировать `c_star_K K > 0` в твоём диапазоне K,
- и затем проверить `c_star_K K / 4 - rho_oneK K > 0` (как ты и написал).

С учётом контракта “Rayleigh без Szegő‑Böttcher” и разделения `t_sym`/`t_rkhs`, это согласуется с текущей архитектурой проекта. fileciteturn0file21 fileciteturn0file24

---

### 3. Нужно ли править формулировку У3
Если твой реальный `P_A_shift` — это Case 2 (не просто translate), то да: **скорее всего У3 надо формулировать как K‑локальный floor** или как floor на “разрешённом подмножестве τ” (например, |τ| ≤ B-r, как в технике “shift‑robust core mass” из A3‑части текста).

Если же `P_A_shift` — Case 1 (translate), тогда У3 править не надо: floor устойчив автоматически.

---

## VI. Самый практичный ход, чтобы “разблокировать Q3 прямо сейчас”
По текущему статусу проекта, у тебя уже есть Rayleigh‑first линия, где **Szegő‑Böttcher не нужен**, и основной A3‑bridge закрывается Rayleigh + RKHS cap. Это прямо прописано как “Active Next Step” в оркестраторе. fileciteturn0file17  
Контракт тоже явно говорит: Rayleigh bound — основной, SB опционален. fileciteturn0file21 fileciteturn0file24

Поэтому, если `Rayleigh_Q_identification.lean` — это твоя старая/ручная версия “identification”, и она теперь тащит тяжёлую `tsum`‑инфраструктуру, **самый выгодный инженерный выбор**:
1) выкинуть из цепочки импорты этого файла (или оставить, но не импортить в `Main`);
2) заменить ключевые нужные факты на уже доказанные в rayleigh‑пакете (или переписать в стиле finite-sum как выше).

---

## TL;DR (что делать в ближайшие 30 минут)
1) **Убери `maxHeartbeats 0`** и бинарно локализуй место, где зависает (скорее всего внутри `integral_P_A_eq_arch_term`).
2) **Перепиши периодизацию через Finset сразу** (finite support → `tsum_eq_sum` → конечная сумма → интеграл суммы → сдвиг интервала без `convert`).
3) Для τ‑shift:
   - проверь, `P_A_shift` = translate от `P_A`?  
     Если да — floor тот же `c_*`, доказательство короткое.
   - если нет — uniform `c_*` по τ подозрителен; тогда иди в `c_star_K`/ограничение на τ.

Если хочешь, я могу дать прямо “готовый” Lean‑скелет для переписывания `integral_P_A_eq_arch_term` в стиле finite-sum (с типичными `simp`/`simpa` шаблонами), но даже без точных имен лемм у тебя уже есть все ключевые шаги, которые резко снимут 7‑часовой зависон.

