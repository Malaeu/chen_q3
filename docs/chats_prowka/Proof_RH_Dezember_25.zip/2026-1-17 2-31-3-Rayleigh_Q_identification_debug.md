# Rayleigh Q identification debug

https://chat.openai.com/c/696a91f5-16f4-8332-8f84-2c12892c6313

## USER
# Proshka Debug Request: Rayleigh_Q_identification (periodization integral hang)

## TL;DR (what we need help with)
We are stuck on the lemma `integral_P_A_eq_arch_term` in
`full/q3.lean.aristotle/Q3/Proofs/Rayleigh_Q_identification.lean`.
Lean **times out** (no error, >600s) when elaborating this lemma.
We want a **simpler / faster proof strategy** for the periodization identity:

```
∫_{-1/2}^{1/2} P_A(B,t,θ) dθ = arch_term (fejer_heat_window B t)
```

Everything else (basis0 lemmas, Toeplitz diag, prime term reduction, T_P_comp diag)
should be OK or close; the periodization lemma is the bottleneck.

We need a clear, Lean-friendly approach that doesn't explode elaboration.

---

## Context + Definitions

**Main target** (Theorem 3.3, Rayleigh-Q identification):

```
theorem rayleigh_Q_identification
  (B t : ℝ) (M : ℕ) [Fintype (Q3.Nodes B)] (hB : 0 < B) :
  (2 * M + 1 : ℝ) *
    Q3.RayleighQuotient
      (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (P_A B t)
        - Q3.T_P_comp_real B B t M)
      (basis0 M)
  = Q3.Q (fun ξ => Q3.fejer_heat_window B t ξ)
```

Key definitions:
- `P_A` and `g` are in `A3_FLOOR_v22_stage4_floor.lean`:
  - `g B t ξ := Q3.a ξ * w B t ξ`
  - `P_A B t θ := 2 * Real.pi * ∑' m : ℤ, g B t (θ + m)`
- `w` in `A3_FLOOR_v20_bounds_core.lean`:
  - `w B t ξ := max 0 (1 - |ξ|/B) * exp(-4*pi^2*t*ξ^2)`
- `fejer_heat_window` in `Q3/Basic/Defs.lean`:
  - **definitionally equal** to `w`.
- `arch_term` in `Q3/Basic/Defs.lean`:
  - `arch_term Φ := ∫ ξ, a_star ξ * Φ ξ`.
- `a_star = 2*pi * a`, `g = a * w`.

So the goal is the standard periodization identity
(plus the constant `2*pi`):

```
∫_{-1/2}^{1/2} (2*pi * ∑' m, g(θ+m)) dθ
  = ∫_ℝ a_star ξ * fejer_heat_window B t ξ dξ
```

---

## Current status of file

Path: `full/q3.lean.aristotle/Q3/Proofs/Rayleigh_Q_identification.lean`

What is already proven in this file:
- `basis0`, `basis0_norm_sq`, `basis0_ne_zero`
- `quadForm_basis0`, `rayleigh_basis0`, `rayleigh_basis0_sub`
- `ToeplitzEntry_diag`, `ToeplitzEntry_diag_re`,
  `ToeplitzMatrix_Fourier_real_diag`
- `fourier_index_i0`, `prime_vec_i0`
- `T_P_comp_real_diag` (done via algebra)
- `prime_term_eq_nodes` (tsum_subtype + tsum_fintype)

The **only** heavy point is `integral_P_A_eq_arch_term`.

---

## The exact lemma that hangs (current code)

```
lemma integral_P_A_eq_arch_term (B t : ℝ) (hB : 0 < B) :
    (∫ θ in (-1/2 : ℝ)..(1/2), P_A B t θ) =
      Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
  classical
  -- Compact support of g gives integrability.
  have hsupp : Function.support (fun ξ => g B t ξ) ⊆ Set.Icc (-B) B := by
    refine (Function.support_subset_iff'.2 ?_)
    intro ξ hξ
    have hnot : ¬ |ξ| ≤ B := by
      intro hle
      have : ξ ∈ Set.Icc (-B) B := by
        exact (abs_le.mp hle)
      exact hξ this
    have hge : |ξ| ≥ B := le_of_lt (lt_of_not_ge (by simpa using hnot))
    exact g_eq_zero_of_abs_ge B t ξ hB hge
  have hcompact : HasCompactSupport (fun ξ => g B t ξ) := by
    exact HasCompactSupport.of_support_subset_isCompact isCompact_Icc hsupp
  have hint : Integrable (fun ξ => g B t ξ) := by
    exact (continuous_g B t).integrable_of_hasCompactSupport hcompact

  -- Split integral into periods and swap integral/sum
  have hsum_base :
      HasSum (fun n : ℤ =>
          ∫ x in (-1/2 : ℝ) + (n : ℝ)..(-1/2 : ℝ) + (n : ℝ) + 1, g B t x)
        (∫ x, g B t x) := by
    simpa using
      (MeasureTheory.Integrable.hasSum_intervalIntegral (μ:=volume)
        (f:=fun x => g B t x) (y:=(-1/2 : ℝ)) hint)
  have hsum :
      HasSum (fun n : ℤ => ∫ x in (-1/2 : ℝ)..(1/2), g B t (x + (n : ℝ)))
        (∫ x, g B t x) := by
    refine (HasSum.congr_fun hsum_base ?_)
    intro n
    have hcomp :=
      (intervalIntegral.integral_comp_add_right (f:=fun x => g B t x) (d:=(n : ℝ))
        (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ)))
    convert hcomp using 1 <;> ring

  have hsum_norm_base :
      HasSum (fun n : ℤ =>
          ∫ x in (-1/2 : ℝ) + (n : ℝ)..(-1/2 : ℝ) + (n : ℝ) + 1, ‖g B t x‖)
        (∫ x, ‖g B t x‖) := by
    simpa using
      (MeasureTheory.Integrable.hasSum_intervalIntegral (μ:=volume)
        (f:=fun x => ‖g B t x‖) (y:=(-1/2 : ℝ)) hint.norm)

  have hsum_norm :
      Summable (fun n : ℤ => ∫ x in (-1/2 : ℝ)..(1/2), ‖g B t (x + (n : ℝ))‖) := by
    have hnorm' :
        HasSum (fun n : ℤ => ∫ x in (-1/2 : ℝ)..(1/2), ‖g B t (x + (n : ℝ))‖)
          (∫ x, ‖g B t x‖) := by
      refine (HasSum.congr_fun hsum_norm_base ?_)
      intro n
      have hcomp :=
        (intervalIntegral.integral_comp_add_right (f:=fun x => ‖g B t x‖) (d:=(n : ℝ))
          (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ)))
      convert hcomp using 1 <;> ring
    exact hnorm'.summable

  have hswap :
      (∫ x in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (x + n)) =
        ∑' n : ℤ, (∫ x in (-1/2 : ℝ)..(1/2), g B t (x + n)) := by
    -- dominated convergence on restricted measure
    have hab : (-1/2 : ℝ) ≤ (1/2 : ℝ) := by norm_num
    have hF_int :
        ∀ n : ℤ, Integrable (fun x => g B t (x + (n : ℝ)))
          (volume.restrict (Set.Ioc (-1/2) (1/2))) := by
      intro n
      have hcont : Continuous (fun x => g B t (x + (n : ℝ))) := by
        simpa [add_comm, add_left_comm, add_assoc] using
          (continuous_g B t).comp (continuous_const.add continuous_id)
      have hI : IntegrableOn (fun x => g B t (x + (n : ℝ))) (Set.Ioc (-1/2) (1/2)) volume :=
        hcont.integrableOn_Ioc
      simpa [IntegrableOn] using hI
    have hF_sum :
        Summable fun n : ℤ =>
          ∫ x, ‖g B t (x + (n : ℝ))‖ ∂(volume.restrict (Set.Ioc (-1/2) (1/2))) := by
      refine (Summable.congr hsum_norm ?_)
      intro n
      have h := intervalIntegral.integral_of_le (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ)) hab
        (f:=fun x => ‖g B t (x + (n : ℝ))‖)
      simpa using h
    have hswap' :=
      (MeasureTheory.integral_tsum_of_summable_integral_norm
        (μ:=volume.restrict (Set.Ioc (-1/2) (1/2)))
        (F:=fun n : ℤ => fun x => g B t (x + (n : ℝ))) hF_int hF_sum)
    -- rewrite from restricted measure to interval integral
    have hleft :
        (∫ x in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (x + n)) =
          ∫ x, ∑' n : ℤ, g B t (x + n) ∂(volume.restrict (Set.Ioc (-1/2) (1/2))) := by
      simpa using
        (intervalIntegral.integral_of_le (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ)) hab
          (f:=fun x => ∑' n : ℤ, g B t (x + (n : ℝ))))
    have hright :
        (∑' n : ℤ, ∫ x in (-1/2 : ℝ)..(1/2), g B t (x + n)) =
          ∑' n : ℤ, ∫ x, g B t (x + n) ∂(volume.restrict (Set.Ioc (-1/2) (1/2))) := by
      refine tsum_congr ?_
      intro n
      simpa using
        (intervalIntegral.integral_of_le (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ)) hab
          (f:=fun x => g B t (x + (n : ℝ))))
    calc
      (∫ x in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (x + n))
          = ∫ x, ∑' n : ℤ, g B t (x + n) ∂(volume.restrict (Set.Ioc (-1/2) (1/2))) := hleft
      _ = ∑' n : ℤ, ∫ x, g B t (x + n) ∂(volume.restrict (Set.Ioc (-1/2) (1/2))) := hswap'.symm
      _ = ∑' n : ℤ, ∫ x in (-1/2 : ℝ)..(1/2), g B t (x + n) := by
            simpa using hright.symm

  calc
    (∫ θ in (-1/2 : ℝ)..(1/2), P_A B t θ)
        = (2 * Real.pi) * (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + n)) := by
            simp [P_A, intervalIntegral.integral_const_mul]
    _ = (2 * Real.pi) * (∑' n : ℤ, ∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + n)) := by
          simpa using congrArg (fun x => (2 * Real.pi) * x) hswap
    _ = (2 * Real.pi) * (∫ x, g B t x) := by
          simpa using congrArg (fun x => (2 * Real.pi) * x) hsum.tsum_eq
    _ = Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
          unfold Q3.arch_term Q3.a_star g
          simp [w, Q3.fejer_heat_window]
```

**This lemma is what hangs** (Lean takes >600s, no output).

---

## Observed behavior

- `lake env lean Q3/Proofs/Rayleigh_Q_identification.lean` runs for >600s and times out.
- `--profile` shows imports are fast (~3s), so the hang is in elaboration of the lemma.
- Setting `set_option maxHeartbeats 0` at top lets Lean run forever; it still doesn't finish.

So we need a proof that elaborates fast.

---

## NEW: Potential math mismatch (scaling)

We noticed a **potential normalization mismatch** in the final calc chain:

Current statement in code:
```
(2*M+1) * RQ(Toeplitz - T_P_comp, basis0) = Q(Φ)
```

But:
- `ToeplitzMatrix_Fourier_real_diag` gives
  `ToeplitzMatrix_Fourier_real ... i0 i0 = ∫ P_A`.
- `RayleighQuotient` is defined as
  `(∑ v_i A_ij v_j) / (∑ v_i^2)`, and `basis0` has norm² = 1.
  So `RQ(A, basis0) = A[i0,i0]`, **no extra factor**.
- `T_P_comp_real_diag` gives
  `(1/(2M+1)) * ∑ w_Q * Φ(ξ_n)` because `prime_vec` is normalized by `1/√(2M+1)`.

Thus:
```
RQ(Toeplitz - T_P_comp, basis0)
  = ∫ P_A - (1/(2M+1)) * ∑ w_Q Φ(ξ_n)
```

Multiplying by `(2M+1)` fixes the prime term but **also multiplies the Toeplitz term**:
```
(2M+1) * ∫ P_A   ≠  arch_term
```

So either:
1) **Statement should NOT have (2M+1)** (and Q should be defined with the 1/(2M+1) factor), or
2) **prime_vec / T_P_comp should be unnormalized**, or
3) **Toeplitz matrix should carry a compensating 1/(2M+1)** (seems unlikely),
4) or the intended vector is different (but scaling v doesn’t change RayleighQuotient).

We need your guidance: what is the *mathematically correct normalization* here?

---

## Potential simpler route (hint request)

We found archived periodization lemmas in:
`Q3/Archive/04_A3_aristotle.lean`:

- `periodize` and `integral_sum_periodize_abs_eq_L1_norm`
- `periodize_eq_sum_add`

Maybe these can be repurposed:
```
periodize f T x := ∑' k : ℤ, f (x - k*T)
```

We only need the **non-absolute** version for `f = g`, `T = 1`.

If there is a direct lemma like:
```
∫_{0}^{1} ∑' k, f(x+k) = ∫_ℝ f
```
(or with bounds `-1/2..1/2`), that would likely simplify and avoid the heavy
`integral_tsum_of_summable_integral_norm` plumbing.

---

## Additional note (minor but relevant)

`continuous_g` and `g_eq_zero_of_abs_ge` defined in
`A3_FLOOR_v22_stage4_floor.lean` are NOT accessible after `import A3_FLOOR_v22_stage4_floor`.
We had to re-define them locally in `Rayleigh_Q_identification.lean`.
So if you propose lemmas that use those, assume they are in the local namespace.

---

## What we want from you

1) A **fast** Lean-proof approach for the periodization integral
   `integral_P_A_eq_arch_term` (avoid heavy dominated-convergence machinery if possible).

2) If you can, a short lemma you would add (or refactor) to make this trivial.
   Example: a direct `intervalIntegral` periodization lemma.

3) Any suggestions on moving this lemma into a separate file or
   using existing `Q3/Archive/04_A3_aristotle.lean` results safely.

---

Thanks! This is the last blocker before wiring the Fourier A3 axiom.

## ASSISTANT
Got it — I’m updating the background processing according to your comment.

## USER
Это и есть единственное содержательное изменение:

### Evidence from the paper (rayleigh_bridge.tex)
In `full/sections/A3/rayleigh_bridge.tex`:

- The model-space vectors are defined as
v_n^{(M)}(θ) := (1 / sqrt(2M+1)) * ∑_{|k|≤M} e^{2π i k (θ - ξ_n)}.

(see the model-space restriction lemma).

This matches our Lean `prime_vec` normalization.

But for a trig polynomial
`p(θ) = ∑ c_k e^{2π i k θ}`,
we have (in the L2(T) inner product)
⟨p, v_n^{(M)}⟩ = (1 / sqrt(2M+1)) * ∑ c_k e^{-2π i k ξ_n}
= (1 / sqrt(2M+1)) * p(−ξ_n) (up to sign convention).


So **p(ξ_n) is NOT equal to ⟨p, v_n^{(M)}⟩**; instead:
p(ξ_n) = sqrt(2M+1) * ⟨p, v_n^{(M)}⟩


Therefore in the Rayleigh pairing,
the prime term from the rank-one operator should contribute
|⟨p, v_n^{(M)}⟩|^2 = (1/(2M+1)) * |p(ξ_n)|^2


But the theorem in `rayleigh_bridge.tex` (Lemma Rayleigh pairing / Thm A3-rayleigh-identification)
writes the prime term **without** this factor. This seems to be the source
of the mismatch with the Lean statement.

We need your judgement on the correct normalization:
- either the paper uses a scaled evaluation functional, or
- the Lean definition should drop the `1/√(2M+1)` factor in `prime_vec`,
  or
- the Rayleigh identification statement should include the `1/(2M+1)`.

## ASSISTANT
Ы **Исправленный текст (смысл тот же, просто грамматика/формулировки ровнее):**

### Evidence from the paper (**rayleigh_bridge.tex**)

In `full/sections/A3/rayleigh_bridge.tex` the model-space vectors are defined as  
\[
v_n^{(M)}(\theta) := \frac{1}{\sqrt{2M+1}} \sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}.
\]
This matches our Lean **`prime_vec`** normalization.

For a trigonometric polynomial  
\[
p(\theta)=\sum_{|k|\le M} c_k\,e^{2\pi i k\theta},
\]
with the **\(L^2(\mathbb T)\)** inner product, we compute
\[
\langle p, v_n^{(M)}\rangle
= \frac{1}{\sqrt{2M+1}} \sum_{|k|\le M} c_k\,e^{\pm 2\pi i k\xi_n},
\]
so (up to the usual sign/conjugation convention)
\[
\langle p, v_n^{(M)}\rangle = \frac{1}{\sqrt{2M+1}}\,p(\xi_n).
\]

Therefore **\(p(\xi_n)\neq \langle p, v_n^{(M)}\rangle\)**; instead,
\[
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle.
\]

So in the Rayleigh pairing, a rank-one term contributes
\[
|\langle p, v_n^{(M)}\rangle|^2=\frac{1}{2M+1}\,|p(\xi_n)|^2.
\]

But the paper’s “Rayleigh pairing / A3-rayleigh-identification” writes the prime term **without** this factor. That looks like the source of the mismatch with the Lean statement.

We need a judgement on the correct normalization:
- either the paper uses a **scaled evaluation functional**, or  
- Lean should drop the **\(1/\sqrt{2M+1}\)** factor in **`prime_vec`**, or  
- the Rayleigh identification statement should include the **\(1/(2M+1)\)**.

---

## Теперь по делу: что “правильно” и где именно баг

### 1) Факт математики: где появляется \(\sqrt{2M+1}\)

Тут всё железобетонно.

- **\(\mathcal P_M\)** — пространство тригполиномов степени ≤ \(M\).  
- Базис **\(e_k(\theta)=e^{2\pi i k\theta}\)** в **\(L^2(\mathbb T)\)** (при стандартной мере \(d\theta\) на \([-1/2,1/2]\)) — **ортонормированный**.
- **Репродуцирующее ядро** (aka **Dirichlet kernel**) для **оценки** \(p(\xi)\) в \(\mathcal P_M\) — это  
  \[
  K_M(\theta,\xi)=\sum_{|k|\le M} e^{2\pi i k(\theta-\xi)}.
  \]
  Тогда
  \[
  p(\xi)=\langle p(\cdot), K_M(\cdot,\xi)\rangle.
  \]
- Норма этого ядра:
  \[
  \|K_M(\cdot,\xi)\|_{L^2(\mathbb T)}^2=\sum_{|k|\le M}1 = 2M+1.
  \]
- Если ты нормируешь его до единичной нормы:
  \[
  v_\xi^{(M)} := \frac{1}{\sqrt{2M+1}} K_M(\cdot,\xi),
  \]
  то автоматически
  \[
  \langle p, v_\xi^{(M)}\rangle = \frac{1}{\sqrt{2M+1}}\,p(\xi)
  \quad (\text{с точностью до conj/знака}).
  \]

Именно это ты и заметил.

**Вывод:** в `rayleigh_bridge.tex` одновременно утверждать  
- \(v_n^{(M)} = \frac{1}{\sqrt{2M+1}}\sum e^{2\pi ik(\theta-\xi_n)}\)  
и  
- \(p(\xi_n)=\langle p, v_n^{(M)}\rangle\)  
— нельзя. Там **пропущен множитель \(\sqrt{2M+1}\)** (или неверно записана нормировка \(v_n^{(M)}\)). Это прямой баг текста.

---

### 2) Что тогда “правильнее” по смыслу проекта: три варианта и мой вердикт

Ты перечислил 3 опции. Вот что они реально означают:

#### Вариант A — правим **текст**: вставляем фактор \(1/(2M+1)\) в прайм-терм
То есть исправляем “Rayleigh pairing” на
\[
\langle (T_M[P_A]-T_P^{(M)})p,p\rangle
=
\int_{\mathbb T}P_A|p|^2
-
\sum_n w(n)\Phi(\xi_n)\,\frac{1}{2M+1}|p(\xi_n)|^2.
\]

- Плюс: согласуется с нормированным **`prime_vec`**.
- Минус: тогда при \(p\equiv 1\) получаешь прайм-сумму **делённую на \(2M+1\)**, и это **не** ваш **\(Q(\Phi)\)** из **T0** (там нет такого деления). См. определение **\(Q(\varphi)\)** в **T0**: прайм-часть это \(\sum w(n)\varphi(\xi_n)\) без \(M\).

То есть да — это математически корректно, но уже **не даёт идентификацию с \(Q\)**, а даёт нечто вроде \(Q_M\).

#### Вариант B — выкидываем нормировку: делаем **`prime_vec`** без \(1/\sqrt{2M+1}\)
Тогда \(p(\xi_n)=\langle p, v_n\rangle\) буквально, и прайм-терм без \(1/(2M+1)\) совпадает с текстом.

- Плюс: идентификация с **\(Q(\Phi)\)** становится буквально правильной.
- Минус: **норма** такого вектора \(\|v_n\|^2=2M+1\), и любой **rank-one operator** \(|v_n\rangle\langle v_n|\) имеет **операторную норму** \(\|v_n\|^2 = 2M+1\). То есть любой **cap** на \(\|T_P^{(M)}\|\), который у вас должен быть **равномерным по \(M\)**, начнёт раздуваться примерно как \(2M+1\).

Если тебе критично потом использовать **RKHS cap** как “\(\|T_P^{(M)}\|\le \rho\) независимо от \(M\)” (а именно это в контракте проекта), то этот вариант токсичен.

#### Вариант C — “прайм-терм должен включать \(1/(2M+1)\)” (как в твоём выводе)
Это на самом деле тот же Вариант A, только сформулирован как выбор “правильной” формулы.

---

### Мой вердикт (жёстко и практично)

1) **Внутри `rayleigh_bridge.tex` сейчас несостыковка.**  
   При заданном \(v_n^{(M)}\) **правильная** формула — твоя:  
   \[
   p(\xi_n)=\sqrt{2M+1}\langle p,v_n^{(M)}\rangle,
   \quad
   | \langle p,v_n^{(M)}\rangle |^2 = \frac{1}{2M+1}|p(\xi_n)|^2.
   \]
   Значит, **в тексте пропущен фактор**. Это не “опциональная конвенция”, это просто математика.

2) В Lean-пайплайне, если ты хочешь **не ломать** будущий **cap** (равномерную оценку нормы прайм-оператора), **`prime_vec` должен оставаться нормированным**. То есть ты НЕ хочешь вариант “убрать \(1/\sqrt{2M+1}\)” глобально.

3) Следовательно, **править нужно не `prime_vec`, а формулировку идентификации**:
   - нельзя писать \((2M+1)\cdot \mathrm{RQ}(Toeplitz - T_P, e_0)=Q\), потому что это множит и арку;
   - если держишь нормированный **`prime_vec`**, то прайм-часть из диагонали действительно приходит с \(1/(2M+1)\), и “компенсировать” нужно **только прайм-терм**, а не всю разность.

То есть “правильная Lean-формула” выглядит так (на уровне идеи):

\[
Q(\Phi)=
\underbrace{\mathrm{RQ}(T_M[P_A], e_0)}_{\int P_A}
-
\underbrace{(2M+1)\,\mathrm{RQ}(T_P^{(M)}, e_0)}_{\sum w(n)\Phi(\xi_n)}.
\]

Это ровно то, что ты интуитивно хотел: **масштабировать только прайм-часть**.

---

## Что делать прямо сейчас в Lean: самая чистая правка формулировки

Если у тебя в Lean уже есть:
- **`ToeplitzMatrix_Fourier_real_diag`**: диагональ = \(\int P_A\),
- **`T_P_comp_real_diag`**: диагональ = \(\frac{1}{2M+1}\sum w_Q(n)\Phi(\xi_n)\),

то финальный мост к **`Q`** должен быть:

\[
\big(\int P_A\big)\;-\;(2M+1)\cdot \big(\text{diag }T_P\big)\;=\;Q(\Phi).
\]

А не \((2M+1)\cdot\text{diag}(Toeplitz - T_P)=Q(\Phi)\).

То есть не “один **RayleighQuotient** от разности”, а “разность двух выражений, где масштаб только на прайме”.

Это:

- **чинит** именно ту мат-ошибку, которую ты показал,
- **совместимо** с нормированным **`prime_vec`**,
- и **не заставляет** множить арх-часть на \(2M+1\).

---

## Мини-диагноз по тексту `rayleigh_bridge.tex`

Если чинить TeX, то нужно выбрать одно из двух:

- либо оставить нормировку \(1/\sqrt{2M+1}\) и исправить утверждение на  
  \(p(\xi_n)=\sqrt{2M+1}\langle p,v_n^{(M)}\rangle\)  
  и вставить \(1/(2M+1)\) в прайм-терм;

- либо убрать нормировку в определении \(v_n^{(M)}\) (сделать **Dirichlet kernel** без деления), тогда \(p(\xi_n)=\langle p,v_n\rangle\) будет верно, но все оценки нормы оператора поменяются.

Для Lean, повторюсь, лучше **не трогать нормировку** и чинить идентификацию формулой “масштабируем только прайм-часть”.

---

## Словарик (коротко, чтобы не было “магии”)

- **\(L^2(\mathbb T)\)** — пространство квадратично интегрируемых функций на торе \(\mathbb T=[-1/2,1/2]\) с внутренним произведением \(\langle f,g\rangle=\int f\overline g\).
- **Тригполином \(\mathcal P_M\)** — конечная сумма частот \(|k|\le M\); размерность \(2M+1\).
- **Reproducing kernel / Dirichlet kernel** — ядро \(K_M(\theta,\xi)=\sum_{|k|\le M}e^{2\pi i k(\theta-\xi)}\), которое “представляет” функционал оценки \(p(\xi)\) как внутреннее произведение.
- **Нормировка \(1/\sqrt{2M+1}\)** — делает \(\|v_n^{(M)}\|=1\), но тогда оценка \(p(\xi)\) получает фактор \(\sqrt{2M+1}\).
- **Rank-one operator \(|v\rangle\langle v|\)** — оператор ранга 1; его квадратичная форма даёт \(|\langle p,v\rangle|^2\).
- **Rayleigh quotient** — \(\mathrm{RQ}(A,p)=\langle Ap,p\rangle/\langle p,p\rangle\).

---

Если хочешь, я дальше прямо “в стиле Lean” разложу, как переписать ваш `rayleigh_Q_identification` statement так, чтобы:
- арх-часть была **без** множителя,
- прайм-часть была **с** \((2M+1)\),
- и вся алгебра совпала с **`Q3.Q`** по **T0**.

## USER
da! piwi! так, чтобы:

арх-часть была без множителя,

прайм-часть была с 
(
2
𝑀
+
1
)
(2M+1),

и вся алгебра совпала с Q3.Q по T0. То есть в paper тогда ничего менять не надо будет или надо будет что-то менять и в paper? Мы нашли ошибку математическую в нашей paper, а вопросительный знак.

## USER
Ключевая правка: при нормированном prime_vec диагональ T_P_comp = (1/(2M+1)) * Σ w_Q Φ(ξ_n).
Поэтому формула (2M+1) * RQ(Toeplitz - T_P_comp) = Q(Φ) неверна — она множит arch-часть.
Правильно: Q(Φ) = RQ(T_M[P_A], basis0) - (2M+1) * RQ(T_P_comp, basis0),
или RQ(Toeplitz - T_P_comp) = arch_term - (1/(2M+1)) * prime_term.
Сохраняем нормировку prime_vec, иначе ломается uniform cap по M.

## USER
ты правильно понимаешь: проблема именно в манускрипте (в rayleigh_bridge.tex и связанной формуле идентификации). Это не просто формулировка, а нормировочный конфликт между определением v_n^{(M)} и тем, как в тексте записан прайм‑терм.

Что конкретно не сходится

В тексте задано
v_n^{(M)} = (1/√(2M+1)) * Σ e^{2πik(θ-ξ_n)}
но дальше написано, что p(ξ_n) = ⟨p, v_n^{(M)}⟩.
Это неверно: правильно
p(ξ_n) = √(2M+1) * ⟨p, v_n^{(M)}⟩.
Отсюда в прайм‑терме обязан появляться фактор 1/(2M+1). В тексте он пропущен, и это ломает идентификацию с Q(Φ).
Как это исправить (практичный план)

Принять решение по нормировке (ключевой шаг)
Рекомендация: оставить нормированный v_n^{(M)} (иначе операторные оценки растут как 2M+1, и ломается uniform cap).
Это значит: исправляем формулы в тексте, а не v_n^{(M)}.

Исправить Rayleigh pairing в тексте
В rayleigh_bridge.tex переписать:

утверждение p(ξ_n) = ⟨p, v_n^{(M)}⟩
→ на p(ξ_n) = √(2M+1)⟨p, v_n^{(M)}⟩;
прайм‑терм должен быть
∑ w(n) * (1/(2M+1)) * |p(ξ_n)|^2
(а не без этого делителя).
Исправить A3‑rayleigh‑identification
Формула должна масштабировать только прайм‑часть, а не всю разность:

Q(Φ) = RQ(T_M[P_A], p) - (2M+1) * RQ(T_P_comp, p)
или эквивалентно:

RQ(Toeplitz - T_P_comp, p) = arch_term - (1/(2M+1)) * prime_term
Это ровно совпадает с нормированным prime_vec.

Проверить, что это совместимо с определением Q в T0

Если Q(Φ) уже зафиксирован без 1/(2M+1), то мы обязаны масштабировать только прайм‑часть, как выше.
В противном случае вводим Q_M с фактором, но это менее желательно.
Техническое добивание

Обновить соответствующие леммы в Lean (в Rayleigh_Q_identification.lean) под новую формулу.
Перепроверить downstream‑логику (Weil criterion/next steps), что уже использует Q.
Если хочешь, я могу прямо составить короткий патч‑текст для rayleigh_bridge.tex (что заменить на что) и параллельно набросать, как именно переписать финальную лемму в Lean под новую формулу.

Нет, я хочу, чтобы ты мне это еще раз объяснил конкретно. То есть мы меняем что-то в тексте. Хорошо, если мы это сделаем, нам нужно четко понимать все цепочки, которые приведут к чему-то. Нам нужно понимать, где что будет ломаться, где переписать это не проблема. Проблема это все вместе совместить. Нам сейчас нужно понять, до этого момента все было правильно, то есть мы эту цепочку проходили-проходили, пришли вот к этому моменту. Вот так я это себе понимаю. И после этого можно продумать следующие шаги. Я правильно говорю или если мы вдруг здесь что-то заменим, то где-то сверху всей этой цепочки что-то разорвется и сломается. Вот этого я не понимаю, чувак. Я должен понимать, где что у нас ломается. Нарисуй это как аске-диаграмму лучше мне.

## ASSISTANT
Ы **Исправленный текст (сохранил сленг, просто сделал читаемым):**

Да! Пиши так, чтобы:

- **арх-часть** была **без** множителя,
- **прайм-часть** была **с** \((2M+1)\),
- и вся алгебра совпала с **`Q3.Q`** по **T0**.

То есть тогда в paper ничего менять не надо — или всё-таки надо? Мы реально нашли **математическую ошибку** в paper? 🤨

---

## 1) Да, это реальная ошибка в paper (не Lean-глюк)

Я прямо посмотрел `rayleigh_bridge.tex`, и там в доказательстве **Lemma [Rayleigh pairing]** написано:

> “… identities \(p(\xi_n)=\langle p,v_n^{(M)}\rangle\) and \(\|v_n^{(M)}\|=1\).”

Но при их же определении  
\[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}
\]
в **стандартном** **\(L^2(\mathbb T)\)** (с мерой \(d\theta\) на \([-1/2,1/2]\)) всегда получается:

\[
\langle p, v_n^{(M)}\rangle=\frac{1}{\sqrt{2M+1}}\,p(\xi_n)
\quad \Rightarrow \quad
p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
\]

То есть строка “\(p(\xi_n)=\langle p,v_n\rangle\)” в paper — **неверна** при заявленной нормировке и стандартном \(L^2\).

---

## 2) Правильная нормализация под ваш контракт (арх без множителя, прайм с \((2M+1)\))

Ты хочешь (и это логично под **T0**) чтобы в финале для \(p\equiv1\) было:

\[
\int_{\mathbb T}P_A(\theta)\,d\theta \;-\;\sum w(n)\Phi(\xi_n)\;=\;Q(\Phi).
\]

А в Lean у вас сейчас:
- **Toeplitz**-диагональ даёт \(\int_{\mathbb T}P_A\) (без \(2M+1\)) ✅
- **prime operator** через нормированный **`prime_vec`** даёт **\(\frac{1}{2M+1}\sum w\Phi\)** ✅

Значит единственный консистентный ход:

> **не множить весь Rayleigh quotient**,  
> а **домножить только прайм-оператор на \((2M+1)\)**.

То есть в матричном виде вы хотите **внутри**:

\[
T_M[P_A]\;-\;(2M+1)\,T_P^{(M)}.
\]

Тогда на диагонали / на **`basis0`**:
\[
\text{арх} - (2M+1)\cdot\frac{1}{2M+1}\text{прайм} \;=\; \text{арх} - \text{прайм},
\]
и это ровно **`Q3.Q`** в **T0**.

---

## 3) Lean: корректная формулировка (то, что можно прям вшить)

Вот “правильный” вариант вашей теоремы (минимально инвазивный):

```lean
theorem rayleigh_Q_identification_scaledPrime
  (B t : ℝ) (M : ℕ) [Fintype (Q3.Nodes B)] (hB : 0 < B) :
  Q3.RayleighQuotient
    (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (P_A B t)
      - (2 * M + 1 : ℝ) • Q3.T_P_comp_real B B t M)
    (basis0 M)
  = Q3.Q (fun ξ => Q3.fejer_heat_window B t ξ) := by
  classical
  -- 1) Rayleigh on basis0 = (i0,i0)-entry
  -- 2) (Toeplitz diag) = ∫_T P_A
  -- 3) (T_P_comp diag) = (1/(2M+1)) * ∑_{nodes} w_Q * Φ(ξ_n)
  -- 4) cancel the factor (2M+1)
  -- 5) rewrite ∫_T P_A = arch_term Φ  (periodization lemma)
  -- 6) rewrite finite sum = prime_term Φ (nodes lemma)
  -- 7) unfold Q3.Q = arch_term - prime_term
  sorry
```

### Что именно меняется относительно вашего старого statement
Было:
\[
(2M+1)\cdot \mathrm{RQ}(T_M[P_A]-T_P^{(M)}, \text{basis0}) = Q(\Phi)
\]
Становится:
\[
\mathrm{RQ}(T_M[P_A]-(2M+1)T_P^{(M)}, \text{basis0}) = Q(\Phi)
\]

То есть множитель переехал **снаружи** (где он ломал арх-часть) **внутрь на прайм-оператор** (где он ровно нужен).

---

## 4) Почему это идеально совпадает с вашими уже-доказанными леммами

Ты сам описал текущую ситуацию (и она прям классика):

- **`ToeplitzMatrix_Fourier_real_diag`** даёт  
  **Toeplitz**\((i0,i0)=\int_{\mathbb T} P_A\).
- **`T_P_comp_real_diag`** даёт  
  **T_P**\((i0,i0)=\frac{1}{2M+1}\sum w_Q\Phi(\xi_n)\).
- **`basis0_norm_sq = 1`** ⇒ **`RayleighQuotient`** на **`basis0`** реально редуцируется к диагонали.

И ровно поэтому твой desired эффект получается “в одну строчку”:
\[
\int P_A \;-\;(2M+1)\cdot \frac{1}{2M+1}\sum w\Phi \;=\; \int P_A - \sum w\Phi.
\]

---

## 5) Нужно ли менять paper?

**Да.** В текущем виде `rayleigh_bridge.tex` содержит **математическую ошибку** (не просто “недосказанность”).

Причина проста: paper одновременно утверждает:

1) \(v_n^{(M)}\) нормирован (есть \(1/\sqrt{2M+1}\) и \(\|v_n\|=1\)),  
2) и при этом использует ложную идентичность \(p(\xi_n)=\langle p,v_n\rangle\).

Это несовместимо при стандартном \(L^2(\mathbb T)\).

### Минимальный патч в paper (лучший, потому что не ломает cap)
Оставь определение \(T_P^{(M)}\) как “compression” (как сейчас), но в **Rayleigh pairing** и **Rayleigh identification** замени оператор на:

\[
T_M[P_A] \;-\; (2M+1)\,T_P^{(M)}.
\]

И в доказательстве вместо “\(p(\xi_n)=\langle p,v_n\rangle\)” вставь правильное:

\[
p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
\]

Тогда prime-часть в квадратичной форме автоматически станет:
\[
(2M+1)\cdot |\langle p,v_n\rangle|^2 = |p(\xi_n)|^2,
\]
и всё совпадёт с текущей формой леммы/теоремы (с \(|p(\xi_n)|^2\) без \(1/(2M+1)\)).

**Это ровно тот же фикс, что ты хочешь в Lean.**

---

## 6) Суперкороткий словарик (чтоб не было “магии”)

- **арх-часть** — это **`arch_term`**: интеграл \(\int_{\mathbb R} a_*(\xi)\Phi(\xi)\,d\xi\).  
- **прайм-часть** — это **prime sum / `prime_term`**: \(\sum w(n)\Phi(\xi_n)\).  
- **`RayleighQuotient`** — отношение \(\langle Av,v\rangle/\langle v,v\rangle\); на **`basis0`** оно превращается в диагональный элемент.  
- **`ToeplitzMatrix_Fourier_real`** — **Toeplitz-матрица** (оператор), построенная из **символа** \(P_A\) через **Фурье** на торе.  
- **`prime_vec`** — вектор, представляющий **оценку** \(p(\xi_n)\) как внутреннее произведение, и его нормировка даёт фактор \(\sqrt{2M+1}\).  
- **`•` (SMul)** — **скалярное умножение матрицы**: \((c•A)_{ij}=cA_{ij}\).  

---

## 7) Про “подстановку параметров” в коде

В коде выше:
- `B`, `t` — параметры окна \(\Phi_{B,t}\),
- `M` — размерность модели (\(2M+1\)),
- выражение `(2 * M + 1 : ℝ)` — это просто тот же \(2M+1\), приведённый к **`ℝ`**, чтобы скаляры совпали по типам.

You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

Если хочешь, следующим шагом я разложу **конкретный Lean-proof без `sorry`** именно для этой “алгебраической” части (без periodization), используя ваши уже готовые леммы **`ToeplitzMatrix_Fourier_real_diag`** и **`T_P_comp_real_diag`**, так чтобы компилилось быстро и без сердечных приступов.

## USER
Ключевая правка: при нормированном prime_vec диагональ T_P_comp = (1/(2M+1)) * Σ w_Q Φ(ξ_n).
Поэтому формула (2M+1) * RQ(Toeplitz - T_P_comp) = Q(Φ) неверна — она множит arch-часть.
Правильно: Q(Φ) = RQ(T_M[P_A], basis0) - (2M+1) * RQ(T_P_comp, basis0),
или RQ(Toeplitz - T_P_comp) = arch_term - (1/(2M+1)) * prime_term.
Сохраняем нормировку prime_vec, иначе ломается uniform cap по M.
Ты отлично поймал нормировку — это именно тот “скользкий” баг, который ломает всё дальше. Большой прогресс. Если хочешь, я сразу перепишу формулировку в Rayleigh_Q_identification.lean и подготовлю короткий дифф для обсуждения.

Еще раз, чувак, мне объясни, забудь пока о прошке. У нас проблема в нашем манускрипте, правильно я понимаю? И чтобы эту проблему исправить, какие шаги нужно было бы предпринять? Продумай это, пожалуйста.

Explaining manuscript normalization mismatch
Да, ты правильно понимаешь: проблема именно в манускрипте (в rayleigh_bridge.tex и связанной формуле идентификации). Это не просто формулировка, а нормировочный конфликт между определением v_n^{(M)} и тем, как в тексте записан прайм‑терм.

Что конкретно не сходится

В тексте задано
v_n^{(M)} = (1/√(2M+1)) * Σ e^{2πik(θ-ξ_n)}
но дальше написано, что p(ξ_n) = ⟨p, v_n^{(M)}⟩.
Это неверно: правильно
p(ξ_n) = √(2M+1) * ⟨p, v_n^{(M)}⟩.
Отсюда в прайм‑терме обязан появляться фактор 1/(2M+1). В тексте он пропущен, и это ломает идентификацию с Q(Φ).
Как это исправить (практичный план)

Принять решение по нормировке (ключевой шаг)
Рекомендация: оставить нормированный v_n^{(M)} (иначе операторные оценки растут как 2M+1, и ломается uniform cap).
Это значит: исправляем формулы в тексте, а не v_n^{(M)}.

Исправить Rayleigh pairing в тексте
В rayleigh_bridge.tex переписать:

утверждение p(ξ_n) = ⟨p, v_n^{(M)}⟩
→ на p(ξ_n) = √(2M+1)⟨p, v_n^{(M)}⟩;
прайм‑терм должен быть
∑ w(n) * (1/(2M+1)) * |p(ξ_n)|^2
(а не без этого делителя).
Исправить A3‑rayleigh‑identification
Формула должна масштабировать только прайм‑часть, а не всю разность:


Q(Φ) = RQ(T_M[P_A], p) - (2M+1) * RQ(T_P_comp, p)
или эквивалентно:


RQ(Toeplitz - T_P_comp, p) = arch_term - (1/(2M+1)) * prime_term
Это ровно совпадает с нормированным prime_vec.

Проверить, что это совместимо с определением Q в T0

Если Q(Φ) уже зафиксирован без 1/(2M+1), то мы обязаны масштабировать только прайм‑часть, как выше.
В противном случае вводим Q_M с фактором, но это менее желательно.
Техническое добивание

Обновить соответствующие леммы в Lean (в Rayleigh_Q_identification.lean) под новую формулу.
Перепроверить downstream‑логику (Weil criterion/next steps), что уже использует Q.
Если хочешь, я могу прямо составить короткий патч‑текст для rayleigh_bridge.tex (что заменить на что) и параллельно набросать, как именно переписать финальную лемму в Lean под новую формулу.

Нет, я хочу, чтобы ты мне это еще раз объяснил конкретно. То есть мы меняем что-то в тексте. Хорошо, если мы это сделаем, нам нужно четко понимать все цепочки, которые приведут к чему-то. Нам нужно понимать, где что будет ломаться, где переписать это не проблема. Проблема это все вместе совместить. Нам сейчас нужно понять, до этого момента все было правильно, то есть мы эту цепочку проходили-проходили, пришли вот к этому моменту. Вот так я это себе понимаю. И после этого можно продумать следующие шаги. Я правильно говорю или если мы вдруг здесь что-то заменим, то где-то сверху всей этой цепочки что-то разорвется и сломается. Вот этого я не понимаю, чувак. Я должен понимать, где что у нас ломается. Нарисуй это как аске-диаграмму лучше мне.

Explaining chain break and fixes with ASCII diagram
Да, ты правильно ощущаешь: до этого места цепочка в целом ровная, а ломается именно в точке идентификации “матрица ↔ Q” из‑за нормировки. Это не про P_A или периодизацию — это про “как prime‑часть кодируется матрично”.

Вот схема, где именно разрыв и что от чего зависит:


A3_FLOOR:   P_A(θ) ≥ c*  on [-1/2,1/2]
    |
    v
Toeplitz Fourier:
A := T_M[P_A]
    |
    v
Rayleigh lower bound:
λ_min(A) ≥ c*
    |
    v
Prime operator (compression):
B := T_P_comp  (через normalized prime_vec)
    |
    v
RKHS cap:
||B|| ≤ ρ   (ρ < c*)
    |
    v
Matrix positivity:
A - B ⪰ 0
    |
    v
Rayleigh on basis0:
RQ(A - B, e0) ≥ 0
    |
    v
IDENTIFICATION  <<== ЛОМАЕТСЯ ЗДЕСЬ
RQ(A - B, e0) ?= Q(Φ)
Почему ломается:
При нормированном prime_vec у тебя выходит


RQ(A - B, e0) = arch_term - (1/(2M+1)) * prime_term
а Q(Φ) в T0 — это
arch_term - prime_term (без деления).

Что именно “ломается” при разных фикcах
Вариант 1: оставить нормировку (как сейчас), правим текст
В тексте: вставляем фактор 1/(2M+1) в прайм‑терм.
Ломается: совпадение с Q(Φ) из T0.
Это значит: либо вводим Q_M, либо переписываем теорему с M‑зависимым фактором.
Цепочка до IDENTIFICATION НЕ ломается. Ломается только связь с T0.
Вариант 2: убрать нормировку prime_vec или умножить B на (2M+1)
Тогда IDENTIFICATION совпадает с Q(Φ).
Ломается: RKHS cap (||B|| ≤ ρ).
Норма оператора растёт ~ (2M+1), и позитивность A - B уже не гарантирована
без новых оценок.
То есть ломается раньше, на шаге “A - B ⪰ 0”.
Где “безопасный” участок цепочки (не зависит от нормировки)
A3_FLOOR
Toeplitz Fourier
Rayleigh lower bound
periodization lemma ∫ P_A = arch_term
Все эти шаги не зависят от нормировки prime_vec.
Итог (простыми словами)
Да, проблема в манускрипте — там пропущен множитель.
Цепочка корректна до идентификации, и именно там логическая дырка.
Нужно выбрать, что важнее:
сохранить нормировку и RKHS‑cap → тогда Q должен быть “масштабированным” (Q_M),
или сохранить буквальное Q из T0 → тогда матричная часть должна быть перенормирована,
а это ломает uniform‑cap.
Если хочешь, я сделаю вторую ASCII‑схему с двумя ветками (A/B) и пометками “где рвётся”, или распишу, какие именно файлы/леммы надо править для каждого варианта.

В тексте: вставляем фактор 1/(2M+1) в прайм‑терм.
Ломается: совпадение с Q(Φ) из T0.
Это значит: либо вводим Q_M, либо переписываем теорему с M‑зависимым фактором. Чем нам грозит введение q underscore m? Что это значит? Это общую идею будет ломать? Вопросительный знак. Дальше. Что значит переписываем теорему с m, зависимым фактором? Вопросительный знак. Нам надо посмотреть по нашим инсайдам. Не шли ли мы уже таким путем и нарвались там на жопы какие-то? Надо это проверить, чувак. Давай-ка посмотрим. Продолжение следует... Не, нихуя, я понимаю, ломается, ты пишешь только связь с T0. А как мы потом, то есть заменить это можно будет тем, что мы либо вводим Q underscore M, либо переписываем теорему с M-зависимым фактором. Вот этим нам грозит. И все равно нам надо проверить, какие проблемы у нас уже возникали, и возникали ли, когда мы шли таким путем. xmm...  Просто наша цель должна быть в приоритете, да, то есть мы доказываем то, что вайл-фактор, короче, мы, вот наша последняя аксиома, она должна быть верной, короче. И вот теперь нам нужно подумать. Хорошо, мы пропустили в манускрипте множитель. Звучит сначала как-то, ну, не очень сложно, но если мы исправим его в манускрипте, как ты мне говорил, то этого, то, то что? Где-то ты тут написал? Вот, в тексте исправляем, тогда ломается совпадание с QF и с T0. А мы не можем потом в T0, если переписывать в T0, надо добавлять Q'м. Еще раз, нам нужен полностью распределение для всего, да, вот проверь еще раз этот с M.

## ASSISTANT
Ы

### Переписанный текст (грамматика + тот же вайб)
> Нет, я хочу, чтобы ты ещё раз объяснил это максимально конкретно.  
> То есть мы меняем что-то в тексте — окей. Но тогда мне нужно чётко понимать всю цепочку зависимостей: где что сломается, где переписать — вообще без боли, а где будет реальный разрыв.  
> Я пока понимаю так: до этого момента всё было правильно, мы шли-шли и упёрлись ровно сюда. После этого можно планировать следующие шаги.  
> Я правильно понимаю, или если мы тут что-то заменим, то где-то выше по цепочке всё разорвётся? Вот это я сейчас не вижу.  
> Я должен понимать, **что именно ломается** и **где именно**. Нарисуй это **ASCII-диаграммой**.

---

Окей. Сейчас разложу **по-взрослому**, чтобы ты видел:  
1) **где реально ошибка**,  
2) **какие куски цепочки не трогаем**,  
3) **что именно переписываем**,  
4) **что ломается downstream**,  
5) и дам **ASCII-карту**.

---

## 1) Контекст: почему это вообще случилось

Тут столкнулись два факта:

- **Оценочный функционал** `p ↦ p(ξ_n)` на пространстве тригполиномов степени ≤ M — это *не* “единичный” объект. Его **норма растёт как** `√(2M+1)`.  
  То есть “вектор, который реализует оценку через скалярное произведение” (Riesz representer) имеет длину `√(2M+1)`.

- В тексте вы определили **нормированный** вектор  
  `v_n^{(M)} = (1/√(2M+1)) * Σ_{|k|≤M} e^{2πik(θ-ξ_n)}`  
  (и в Lean это тоже так: **prime_vec** нормирован).  
  Но дальше в тексте вы использовали его как будто он **ненормированный** representer оценочного функционала, и написали:
  `p(ξ_n) = ⟨p, v_n^{(M)}⟩`.  

Вот и всё: ты смешал **нормированную версию** representer-а и **ненормированную формулу** оценки.

---

## 2) Мини‑глоссарий (чтобы не путаться)

- **\( \mathcal P_M \)** — пространство тригполиномов степени ≤ M:  
  \( p(\theta)=\sum_{|k|\le M} c_k e^{2\pi i k\theta} \).

- **\( \langle \cdot,\cdot\rangle_{L^2(\mathbb T)} \)** — **L2‑скалярное произведение** на торе:  
  \( \langle p,q\rangle = \int_{-1/2}^{1/2} p(\theta)\overline{q(\theta)}d\theta \).  
  Базис \( e_k(\theta)=e^{2\pi i k\theta} \) — ортонормирован.

- **evaluation / оценка** \( p(\xi_n) \) — значение полинома в точке.

- **Riesz representer** — вектор \(u\), такой что \( \langle p,u\rangle = p(\xi_n) \) для всех p.  
  Его норма = “насколько жирная” эта операция.

- **\(v_n^{(M)}\)** — **нормированная** версия representer-а (в Lean — **prime_vec**).  
  Нормировка убирает фактор √(2M+1), но он *должен появиться обратно* в формуле оценки.

- **rank‑one operator** \( |v\rangle\langle v| \) — оператор ранга 1. Его норма = \( \|v\|^2 \).

---

## 3) Где именно ломается (точка разрыва)

В `rayleigh_bridge.tex` у вас прямо написано (я цитирую смысл):

- в **Lemma Rayleigh pairing**:  
  “используем тождество `p(ξ_n)=⟨p,v_n^{(M)}⟩` и `||v_n||=1`”.

Это **неверно** при вашей же дефиниции `v_n^{(M)}`.

Правильно:

\[
\langle p, v_n^{(M)} \rangle
= \frac{1}{\sqrt{2M+1}}\, p(\xi_n)
\quad\Rightarrow\quad
p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
\]

Отсюда сразу:

\[
|\langle p,v_n^{(M)}\rangle|^2
= \frac{1}{2M+1}\,|p(\xi_n)|^2.
\]

Это и есть тот **пропущенный фактор**.

---

## 4) ASCII‑диаграмма всей цепочки и место ошибки

Вот максимально “рентгеном”:

```
                 ┌──────────────────────────────┐
                 │  T0: Weil functional Q(Φ)    │
                 │  Q(Φ)= ∫ a*(ξ)Φ(ξ)dξ - Σ wΦ  │
                 └───────────────┬──────────────┘
                                 │  Φ = Φ_{B,t} (Fejér×heat)
                                 v
┌─────────────────────────────────────────────────────────────────────┐
│ ARCH BRANCH (Архимедова часть)                                      │
│                                                                     │
│  g(ξ)=a(ξ)·Φ(ξ)                                                     │
│  P_A(θ)=2π Σ_{m∈Z} g(θ+m)                                           │
│                                                                     │
│  (Periodization lemma)                                              │
│  ∫_{T} P_A(θ)dθ  =  ∫_{R} a*(ξ)Φ(ξ)dξ   = arch_term(Φ)              │
└─────────────────────────────────────────────────────────────────────┘
                                 │
                                 │  (в Lean: integral_P_A_eq_arch_term)
                                 v
┌─────────────────────────────────────────────────────────────────────┐
│ PRIME BRANCH (Прайм‑часть)                                          │
│                                                                     │
│  Nodes: ξ_n = log n / (2π)                                          │
│  weights: w(n)                                                      │
│                                                                     │
│  Evaluation representer (НЕнорм.) u_n  ~  Σ_{|k|≤M} e^{2πik(θ-ξ_n)}  │
│     ||u_n||^2 = 2M+1                                                │
│                                                                     │
│  Normalized vector v_n = u_n / √(2M+1)                              │
│     ||v_n|| = 1                                                     │
│                                                                     │
│  CORRECT FACT: <p,v_n> = p(ξ_n)/√(2M+1)                             │
│              => |<p,v_n>|^2 = |p(ξ_n)|^2/(2M+1)                     │
│                                                                     │
│  Prime operator: T_P^{(M)} = Σ w(n)Φ(ξ_n) |v_n><v_n|                │
│  Quadratic form: <T_P^{(M)}p,p> = Σ wΦ |<p,v_n>|^2                  │
│                               = (1/(2M+1)) Σ wΦ |p(ξ_n)|^2          │
└─────────────────────────────────────────────────────────────────────┘
                                 │
                                 │
                                 v
┌─────────────────────────────────────────────────────────────────────┐
│  WHERE PAPER BREAKS                                                 │
│                                                                     │
│  rayleigh_bridge.tex claims: p(ξ_n)=<p,v_n>                          │
│  => writes prime term WITHOUT 1/(2M+1)                               │
│                                                                     │
│  But correct is: p(ξ_n)=√(2M+1)<p,v_n>                               │
│  => prime term MUST carry 1/(2M+1) when written as |p(ξ_n)|^2        │
└─────────────────────────────────────────────────────────────────────┘
                                 │
                                 v
┌─────────────────────────────────────────────────────────────────────┐
│ CONSEQUENCE                                                         │
│                                                                     │
│  Current theorem (paper/Lean):                                      │
│    (2M+1)*RQ(Toeplitz - T_P^{(M)}, basis0) = Q(Φ)                   │
│  is WRONG because it multiplies arch part too.                      │
│                                                                     │
│  Correct with normalized v_n:                                       │
│    Q(Φ) =  RQ(Toeplitz, basis0)  - (2M+1)*RQ(T_P^{(M)}, basis0)      │
│  (i.e. scale ONLY prime piece).                                     │
└─────────────────────────────────────────────────────────────────────┘
```

Вся “ломка” — это *одна стрелка*:  
**“evaluation = inner product”** без √(2M+1).

---

## 5) Что НЕ ломается (важно)

Это ключевой вопрос “а сверху ничего не разорвётся?” — почти всё остаётся как есть:

✅ **T0** (`T0.tex`): определение **Q(Φ)** и нормировки — **не трогаем**.  
✅ **A3 symbol**: определение **P_A**, **g**, **Φ_{B,t}** — **не трогаем**.  
✅ **Periodization identity**: `∫_T P_A = arch_term` — **не зависит от M вообще**, это отдельная ветка.  
✅ Нормировка **prime_vec** в Lean — **оставляем**, и это правильно ради uniform‑cap.

Ломается только:

❌ То место, где вы в тексте отождествили **значение** `p(ξ_n)` и **скалярное произведение** с нормированным вектором.

---

## 6) Что конкретно переписать в тексте (точечный патч)

### 6.1 Lemma “Rayleigh pairing” (rayleigh_bridge.tex)

Сейчас в формуле стоит:
\[
... - \sum w(n)\Phi(\xi_n)|p(\xi_n)|^2.
\]

Должно быть **либо** так (самое честное и короткое):
\[
... - \sum w(n)\Phi(\xi_n)\,|\langle p,v_n^{(M)}\rangle|^2.
\]

**либо** (если вы хотите именно `|p(ξ_n)|^2`):
\[
... - \frac{1}{2M+1}\sum w(n)\Phi(\xi_n)\,|p(\xi_n)|^2.
\]

И в доказательстве заменить фразу  
`p(ξ_n)=⟨p,v_n^{(M)}⟩`  
на  
`p(ξ_n)=√(2M+1)⟨p,v_n^{(M)}⟩`.

### 6.2 Theorem “Rayleigh identification …” (thm:a3-rayleigh-identification)

Сейчас вы утверждаете:
\[
\langle (T_M[P_A]-T_P^{(M)})1,1\rangle
= \int P_A - \sum w\Phi = Q(\Phi).
\]

После фикса леммы это **уже не правда**. Верная версия при сохранении нормированного \(v_n^{(M)}\):

\[
Q(\Phi_{B,t}) \;=\;
\langle T_M[P_A]1,1\rangle
\;-\;
(2M+1)\,\langle T_P^{(M)}1,1\rangle.
\]

И самое важное: выкинуть/переписать фразу

> “In particular, \(Q(\Phi)\ge0\) iff the Rayleigh quotient on the left is nonnegative.”

Потому что “left” уже не соответствует Q.

---

## 7) Где именно “сломается downstream” (честный список)

### 7.1 В тексте (LaTeX)
- `rayleigh_bridge.tex`:  
  ✅ правим **Lemma Rayleigh pairing** и **Theorem Rayleigh identification**.
- `main.tex` (и любые места, где на это ссылаются):  
  сейчас там есть логика “матрица даёт запас ⇒ по идентификации это Q≥0”.  
  Это придётся заменить на новую связку.

Я проверил по файлам, которые у тебя лежат тут: `main.tex` прямо ссылается на Theorem `thm:a3-rayleigh-identification`, чтобы вывести \(Q(\Phi)\ge0\). Это место точно придётся переписать.

### 7.2 В Lean
Ломается ровно то, что ты уже написал:

- Теорема вида  
  `(2M+1) * RayleighQuotient(Toeplitz - T_P_comp, basis0) = Q(Φ)`  
  — **не может быть истинной**, если Toeplitz‑диагональ = `∫P_A`.

Новая формулировка (в духе твоего сообщения) должна быть:

- либо в “разложенном” виде:
  \[
  Q(\Phi)=\underbrace{\int P_A}_{\text{arch}}
  \;-\;
  \underbrace{(2M+1)\cdot \mathrm{RQ}(T_P^{(M)},basis0)}_{\text{prime}}.
  \]

- либо как “разница двух RQ”:
  \[
  Q(\Phi)= \mathrm{RQ}(T_M[P_A],basis0) - (2M+1)\,\mathrm{RQ}(T_P^{(M)},basis0).
  \]

И да: **нормировку prime_vec в Lean ты оставляешь** — это вообще правильный ход для контроля норм.

---

## 8) Самое главное: “мы тут чиним — и всё выше не падает?”

Твой инстинкт правильный:  
**до этого момента цепочка не обязана быть неправильной**.

Локально неверен ровно кусок:

> “оценка = скалярное произведение с unit‑vector”.

Это *не меняет*:
- определение **Q**,
- определение **P_A**,
- периодизацию (арх‑ветку),
- RKHS‑cap логику,
- и нормировку **prime_vec**.

Это меняет только:
- как вы **переводите прайм‑сумму** в языковые выражения через \(v_n^{(M)}\),
- и любые теоремы, где вы из “матрицы” напрямую делаете “Q”.

---

## 9) Бонус‑сигнал (не игнорю аномалию)
В `rayleigh_bridge.tex` в доказательстве model‑space restriction вы пишете про “global prime operator на \(L^2(\TT)\)” через функции \(e^{2\pi i(\cdot)\xi_n}\).  
На настоящем торе **характеры только с целыми частотами**, так что это звучит как *второй потенциальный дрейф* (формально “не живёт на торе”). Это не обязательно ломает Lean (там у тебя всё в коэффициентах/векторах), но для чистоты текста я бы это переописал как оператор на **коэффициентном пространстве**/**модельном пространстве** \( \mathcal P_M \) напрямую.

---

Если хочешь, следующим шагом я могу сделать два очень практичных артефакта:

1) **Готовый патч‑блок** для `rayleigh_bridge.tex` (кусок “что заменить на что” прямо TeX-ом).  
2) **Новый Lean‑statement** для `rayleigh_Q_identification` в виде 3–5 строк, чтобы ты просто перекинул и поехал дальше.

Скажи только: тебе удобнее, чтобы в тексте прайм‑часть в лемме была записана как **|⟨p,v_n⟩|²** (самый чистый вариант), или прям как **(1/(2M+1))|p(ξ_n)|²** (самый “интуитивный”)?

## ASSISTANT
Ы  
Переписал твой текст (грамматика + читаемость, сленг сохранён):

> Да! Пиши так, чтобы:  
> — **арх‑часть** была **без множителя**,  
> — **прайм‑часть** была **с (2M+1)**,  
> — и вся алгебра совпала с **Q3.Q** по **T0**.  
> Вопрос: тогда в paper ничего менять не надо, или всё‑таки надо? Похоже, мы нашли математическую ошибку в paper — нужен твой вердикт.

---

## 1) Вердикт по нормировке: ты прав, и да — это баг в paper

### Контекст (что именно “сломано”)
В `rayleigh_bridge.tex` у вас одновременно написано:

- **prime-вектор**  
  \(v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}\)
- и в доказательстве **Rayleigh pairing** используется “идентичность”  
  \(p(\xi_n)=\langle p, v_n^{(M)}\rangle\) и \(\|v_n^{(M)}\|=1\).

Но при стандартном **L2(T)**-скалярном произведении (на \([-1/2,1/2]\) с \(d\theta\)) верно:

\[
\langle p, v_n^{(M)}\rangle \;=\;\frac{1}{\sqrt{2M+1}}\,p(\xi_n)
\quad\Rightarrow\quad
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle .
\]

То есть в paper пропущен фактор \(\sqrt{2M+1}\). Это ровно то, что ты диагностировал.

### Следствие (какая формула реально получается)
Если **T_P^{(M)}** определён через нормированные \(v_n^{(M)}\) как сумма ранга‑1:
\[
T_P^{(M)}=\sum_n w(n)\Phi(\xi_n)\,|v_n^{(M)}\rangle\langle v_n^{(M)}|,
\]
то его квадратичная форма даёт:

\[
\langle T_P^{(M)}p,p\rangle
=\sum_n w(n)\Phi(\xi_n)\,|\langle p,v_n^{(M)}\rangle|^2
=\frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n)\,|p(\xi_n)|^2 .
\]

И это **в точности** то, что ты видишь в Lean на диагонали **T_P_comp**:
\[
(T_P^{(M)})_{00}=\frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n)
\quad(\text{при }p\equiv 1).
\]

---

## 2) Что “математически правильно” в Lean-формулировке (и как сделать «арх без множителя, прайм с (2M+1)»)

### Технические термины (чтобы мы одинаково читали)
- **`prime_vec`** — нормированный “псевдо‑вектор оценки в точке” в **модельном пространстве** \(\mathcal P_M\). Нормировка нужна, чтобы **норма ранга‑1 проектора** не росла как \(2M+1\).
- **`T_P_comp_real`** — **сжатие/компрессия** прайм‑оператора в \(\mathcal P_M\) (ранг‑1 сумма).
- **`RayleighQuotient`** — \(\frac{\langle Av,v\rangle}{\langle v,v\rangle}\); **линейна по матрице** при фиксированном \(v\).
- **`basis0`** — вектор, соответствующий \(p(\theta)\equiv 1\) (коэффициент \(c_0=1\), остальные 0). Норма \(\|basis0\|^2=1\).
- **`arch_term`** — \(\int_\mathbb R a_*(\xi)\Phi(\xi)d\xi\).
- **`Q3.Q`** — Weil-функционал в **T0** нормировке: \(Q(\Phi)=Q_{\rm arch}(\Phi)-Q_{\rm prime}(\Phi)\).

### Исправление, которое ты уже сформулировал — ровно то, что надо
Текущее Lean-утверждение вида
\[
(2M+1)\cdot \mathrm{RQ}(T_M[P_A]-T_P^{(M)},\,basis0)=Q(\Phi)
\]
действительно неверно, потому что оно умножает **и** arch‑часть.

Правильные эквивалентные варианты (выбирай тот, который проще “вплести” в файл):

**Вариант A (самый честный и простой для алгебры):**
\[
Q(\Phi)=\mathrm{RQ}(T_M[P_A],basis0)\;-\;(2M+1)\cdot \mathrm{RQ}(T_P^{(M)},basis0).
\]

**Вариант B (то же самое, но одной `RQ` на разности):**
\[
Q(\Phi)=\mathrm{RQ}\big(T_M[P_A]-(2M+1)\,T_P^{(M)},\,basis0\big).
\]

Но важный нюанс (сигнал/аномалия):  
если ты планируешь дальше использовать **оценку нормы оператора** \(\|T_P^{(M)}\|\le\rho\) и выводить позитивность через \(\lambda_{\min}(T_M[P_A]-T_P^{(M)})\), то **масштабировать** \(T_P^{(M)}\) на \((2M+1)\) нельзя — это разнесёт все uniform‑bounds. Так что на практике лучше держать **вариант A** (раздельно), а positivity доказывать **не** через “одну матрицу минус другая”, а через оценку **самого прайм‑суммарного члена** (который в Q и живёт).

---

## 3) Нужно ли менять paper?

Если оставить **нормировку** \(1/\sqrt{2M+1}\) (а ты хочешь её оставить — и это разумно), то да:

- В paper надо **поправить** место, где написано \(p(\xi_n)=\langle p,v_n^{(M)}\rangle\).  
  Правильно: \(p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle\) (с возможным знаком “минус” в аргументе, если у вас там конвенция \(\theta-\xi_n\) vs \(\theta+\xi_n\); в любом случае **модуль** ловит тот же фактор).
- Соответственно, в **Rayleigh pairing** надо заменить прайм‑часть на
  \[
  \frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n)|p(\xi_n)|^2
  \]
  (если прайм‑оператор остаётся суммой \(|v\rangle\langle v|\) с \(\|v\|=1\)).

И дальше у вас развилка:

### Paper patch #1 (минимальный, не трогает определения)
Оставляете **T_P^{(M)}** как есть (нормированный), но **Theorem Rayleigh identification** переписываете так, чтобы при \(p\equiv1\) стояло:

\[
Q(\Phi)=\int_\TT P_A - (2M+1)\langle T_P^{(M)}1,1\rangle.
\]

Это ровно “арх без множителя, прайм с (2M+1)”.

### Paper patch #2 (если хотите сохранить “красивая форма без (2M+1)”)
Тогда надо менять **определение** \(v_n^{(M)}\) (убрать нормировку) *или* менять **нормировку скалярного произведения**. Но это уже каскад правок (и, скорее всего, ломает заявленный norm bound в Lemma a3-model-space). Я бы не шёл туда.

Мой жёсткий вывод: **paper сейчас математически сам себе противоречит** в этом месте. Так что “ничего не менять” — нет, не получится, если хотите корректность для \(M>0\).

---

## 4) Lean: как закрыть `integral_P_A_eq_arch_term` быстро (и без зависания)

Теперь про твой второй блокер — периодизация. Здесь кайф: у тебя уже есть ключевая фраза из `symbol_floor.tex`: *“periodization sum is finite for each θ”*. Это прям то, что нужно, чтобы **убить** весь ад с **`integral_tsum_of_summable_integral_norm`**.

### Почему у тебя сейчас висит
Самый жирный “пожиратель heartbeats” — связка:
- **`integral_tsum_of_summable_integral_norm`**
- куча переписываний через **restrict measure**, **Ioc**, **intervalIntegral.integral_of_le**
- `simp`/`ring`/`tsum_congr` на уровне выражений с **`∑'`** и интегралами

Это приводит к огромному elaboration‑дереву, Lean начинает “симпить вселенную”.

### Lean-friendly стратегия: превратить `∑'` в конечную сумму на `[-1/2,1/2]`
**Ключ:** у **`g B t`** компактный носитель в \([-B,B]\). Значит для \(\theta\in[-1/2,1/2]\)
\[
g(\theta+n)\neq 0 \Rightarrow |\theta+n|\le B \Rightarrow |n|\le B+\tfrac12,
\]
то есть **все ненулевые члены лежат в конечном диапазоне** \(n\in[-N,N]\), где \(N=\lceil B+1/2\rceil\).

#### Что это даёт в Lean
- `∑' n : ℤ, g (θ+n)` **равен** `∑ n in Finset.Icc (-N) N, g (θ+n)` на вашем интервале.
- Дальше вынос суммы из интеграла — тривиальный **finite sum**.
- Никаких dominated convergence, никаких `integral_tsum_*`.

### Скелет леммы (идея, не “точно компилируемый” код, но структура правильная)
Тебе надо добавить локальную вспомогательную лемму вида:

1) **Uniform finite support**
- пусть `N : ℤ := Real.ceil (B + (1/2:ℝ))`
- `S : Finset ℤ := Finset.Icc (-N) N`
- докажи:
  ```
  ∀ θ ∈ Set.Icc (-1/2:ℝ) (1/2), ∀ n, n ∉ S → g B t (θ + n) = 0
  ```
  Тут используется:
  - треугольник: `|n| ≤ |θ+n| + |θ|` → `|θ+n| ≥ |n| - |θ|`
  - `|θ| ≤ 1/2`
  - если `n ∉ Icc (-N) N`, то `|n| > N ≥ B+1/2`
  - значит `|θ+n| ≥ B` → `g_eq_zero_of_abs_ge ...`

2) **tsum = finset.sum**
- из пункта 1 получаешь:
  ```
  (∑' n : ℤ, g B t (θ + n)) = ∑ n in S, g B t (θ + n)
  ```
  (есть стандартные леммы про `tsum_eq_sum` при конечной поддержке; если вдруг не найдёте, можно доказывать через `tsum_eq_sum` + `summable_of_finite_support`)

3) **интеграл**
- дальше:
  ```
  ∫ θ in (-1/2)..(1/2), P_A B t θ
  = 2π * ∫ θ in ... , ∑ n in S, g B t (θ + n)
  = 2π * ∑ n in S, ∫ θ in ... , g B t (θ + n)
  ```
- и для каждого `n`:
  ```
  ∫ θ in (-1/2)..(1/2), g (θ + n)
  = ∫ x in (-1/2 + n)..(1/2 + n), g x
  ```
  через **`intervalIntegral.integral_comp_add_right`**

4) **сумма по n даёт ∫ℝ g**
Тут два пути:

- **путь A (самый короткий):** использовать уже имеющийся у вас
  **`Integrable.hasSum_intervalIntegral`** (как ты делал), но вместо `hswap` показать, что члены вне `S` нулевые ⇒ `tsum` сводится к `Finset.sum`.

- **путь B:** показать, что объединение интервалов \([-1/2+n,1/2+n]\) при \(n\in[-N,N]\) покрывает \([-B,B]\), а вне \([-B,B]\) `g=0`, значит интеграл по ℝ равен интегралу по этому объединению, а оно равно сумме intervalIntegral по разбиению.

Я бы взял **путь A**: он меньше таскает `MeasureTheory`-переписываний.

---

## 5) Что делать прямо сейчас: конкретный план правки

### (i) Lean: правь statement, иначе вы постоянно будете “чинить не то”
- Убирай:
  **`(2*M+1) * RQ(Toeplitz - T_P_comp) = Q`**
- Ставь что-то из:
  - **`Q = RQ(Toeplitz,basis0) - (2M+1)*RQ(T_P_comp,basis0)`**
  - или `Q = RQ(Toeplitz - (2M+1)•T_P_comp,basis0)` (но аккуратно с дальнейшими norm‑аргументами).

### (ii) Lean: замени periodization proof на “finite-sum on [-1/2,1/2]”
Это и ускорит, и сделает лемму читаемой.

### (iii) Paper: минимальная правка (Patch #1)
- Исправить “\(p(\xi_n)=\langle p,v_n^{(M)}\rangle\)” на фактор \(\sqrt{2M+1}\).
- Rayleigh pairing переписать с \(1/(2M+1)\).
- Theorem Rayleigh identification переписать так, чтобы прайм‑часть была с \((2M+1)\) (как ты хочешь).

---

## Быстрый хак для навигации по репе (чтобы найти существующие леммы)
You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: `repo:{username/repo_name} import` (e.g., `repo:openai/codex import`).

---

Если хочешь совсем “без боли”: я бы вынес periodization‑лемму в отдельный файл типа `Q3/Basic/Periodization.lean` и потом просто `simp`-ом подключал в `Rayleigh_Q_identification.lean`. Тогда `Rayleigh_Q_identification` перестанет быть “помойкой MeasureTheory”, и компиляция будет стабильно быстрой.

fileciteturn1file6

## USER
Ты правильно формулируешь проблему. Да, баг в манускрипте, и он точечно сидит в идентификации “матрица ↔ Q”. До этого момента цепочка реально шла правильно. После правки текста ломается не всё, а связка с T0/Weil, если мы введём Q_M. Я сейчас покажу, где конкретно.

Что значит “ввести Q_M”
Это по факту другой функционал:

Q_M(Φ) := arch_term(Φ) - (1/(2M+1)) * prime_term(Φ)
Он слабее Q. Из Q_M ≥ 0 не следует Q ≥ 0, потому что Q = arch_term − prime_term ≤ arch_term − (1/(2M+1)) prime_term = Q_M.
То есть Q_M ≥ 0 вообще не гарантирует нужный знак для Q.

Что значит “переписать теорему с M‑зависимым фактором”
Есть две разные трактовки:

Плохая (ломает цепочку):
RQ(Toeplitz - T_P_comp, e0) = Q_M(Φ)
→ это ведёт к Q_M, не к Q.
Ломается на переходе к T0/Weil.

Хорошая (цепочку сохраняет):

Q(Φ) = RQ(T_M[P_A], e0) - (2M+1)*RQ(T_P_comp, e0)
Тут Q остаётся прежним, просто прайм‑часть масштабируется.
Это минимальная правка, и цепочка не рушится.

Где ломается цепочка (ASCII)
A3_FLOOR:     P_A ≥ c*
   |
Toeplitz Rayleigh
   |
RKHS cap (uniform)
   |
A3-bridge positivity (A - B ⪰ 0)
   |
RQ(A - B, e0) ≥ 0
   |
IDENTIFICATION
   |
Q(Φ) ≥ 0
   |
T5 transfer
   |
Weil criterion
Вариант “Q_M”:

RQ(A - B, e0) = Q_M(Φ)
             |
             v
        Q_M(Φ) ≥ 0   (СЛАБО)
             |
             X  не даёт Q(Φ) ≥ 0
             |
       ломается T5/Weil
Вариант “масштабируем только прайм‑часть”:

Q(Φ) = RQ(A, e0) - (2M+1)RQ(B, e0)
     |
     v
цепочка сохраняется полностью
Проверка по инсайтам: “уже было так?”
Я проверил инсайды — прямого Q_M кейса нет. Но есть очень близкий по смыслу провал, когда всё стало M‑зависимым:

v1_surprise_real_tp_bounds_2026_01_14.md
→ получилось только ∀M ∃t(M) (t зависит от M), это недостаточно.
t_p_compression_fix_2026_01_14.md
→ подчёркнуто: uniform t обязателен, иначе A3 bridge рушится.
t_p_comp_mismatch.md
→ предупреждение про рост нормы с M при неверной модели T_P.
Это прямой сигнал: вся цепочка ломается, если что‑то становится M‑зависимым.

Итог (простыми словами)
Q_M = другой функционал, и он не закрывает Weil.
Это значит: “вводим Q_M” = меняем цель доказательства, и ломаем всё выше.
Безопасный путь: оставить нормированный prime_vec, поправить идентификацию так, чтобы масштабировать только прайм‑часть.
Если хочешь, я сейчас сделаю второй ASCII‑блок с “файлы где трогать” (tex + lean + axioms), чтобы ты видел конкретную точку правки и что не трогаем вообще.

Ы **Исправленный текст (сохранил сленг, просто сделал читаемым):**

Да! Пиши так, чтобы:

* **арх-часть** была **без** множителя,
* **прайм-часть** была **с** ((2M+1)),
* и вся алгебра совпала с **Q3.Q** по **T0**.

То есть тогда в paper ничего менять не надо — или всё-таки надо? Мы реально нашли **математическую ошибку** в paper? 🤨

---

## 1) Да, это реальная ошибка в paper (не Lean-глюк)

Я прямо посмотрел rayleigh_bridge.tex, и там в доказательстве **Lemma [Rayleigh pairing]** написано:

> “… identities (p(\xi_n)=\langle p,v_n^{(M)}\rangle) and (|v_n^{(M)}|=1).”

Но при их же определении
[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}
]
в **стандартном** **(L^2(\mathbb T))** (с мерой (d\theta) на ([-1/2,1/2])) всегда получается:

[
\langle p, v_n^{(M)}\rangle=\frac{1}{\sqrt{2M+1}},p(\xi_n)
\quad \Rightarrow \quad
p(\xi_n)=\sqrt{2M+1},\langle p,v_n^{(M)}\rangle.
]

То есть строка “(p(\xi_n)=\langle p,v_n\rangle)” в paper — **неверна** при заявленной нормировке и стандартном (L^2).

---

## 2) Правильная нормализация под ваш контракт (арх без множителя, прайм с ((2M+1)))

Ты хочешь (и это логично под **T0**) чтобы в финале для (p\equiv1) было:

[
\int_{\mathbb T}P_A(\theta),d\theta ;-;\sum w(n)\Phi(\xi_n);=;Q(\Phi).
]

А в Lean у вас сейчас:

* **Toeplitz**-диагональ даёт (\int_{\mathbb T}P_A) (без (2M+1)) ✅
* **prime operator** через нормированный **prime_vec** даёт **(\frac{1}{2M+1}\sum w\Phi)** ✅

Значит единственный консистентный ход:

> **не множить весь Rayleigh quotient**,
> а **домножить только прайм-оператор на ((2M+1))**.

То есть в матричном виде вы хотите **внутри**:

[
T_M[P_A];-;(2M+1),T_P^{(M)}.
]

Тогда на диагонали / на **basis0**:
[
\text{арх} - (2M+1)\cdot\frac{1}{2M+1}\text{прайм} ;=; \text{арх} - \text{прайм},
]
и это ровно **Q3.Q** в **T0**.

---

## 3) Lean: корректная формулировка (то, что можно прям вшить)

Вот “правильный” вариант вашей теоремы (минимально инвазивный):
lean
theorem rayleigh_Q_identification_scaledPrime
  (B t : ℝ) (M : ℕ) [Fintype (Q3.Nodes B)] (hB : 0 < B) :
  Q3.RayleighQuotient
    (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (P_A B t)
      - (2 * M + 1 : ℝ) • Q3.T_P_comp_real B B t M)
    (basis0 M)
  = Q3.Q (fun ξ => Q3.fejer_heat_window B t ξ) := by
  classical
  -- 1) Rayleigh on basis0 = (i0,i0)-entry
  -- 2) (Toeplitz diag) = ∫_T P_A
  -- 3) (T_P_comp diag) = (1/(2M+1)) * ∑_{nodes} w_Q * Φ(ξ_n)
  -- 4) cancel the factor (2M+1)
  -- 5) rewrite ∫_T P_A = arch_term Φ  (periodization lemma)
  -- 6) rewrite finite sum = prime_term Φ (nodes lemma)
  -- 7) unfold Q3.Q = arch_term - prime_term
  sorry

### Что именно меняется относительно вашего старого statement

Было:
[
(2M+1)\cdot \mathrm{RQ}(T_M[P_A]-T_P^{(M)}, \text{basis0}) = Q(\Phi)
]
Становится:
[
\mathrm{RQ}(T_M[P_A]-(2M+1)T_P^{(M)}, \text{basis0}) = Q(\Phi)
]

То есть множитель переехал **снаружи** (где он ломал арх-часть) **внутрь на прайм-оператор** (где он ровно нужен).

---

## 4) Почему это идеально совпадает с вашими уже-доказанными леммами

Ты сам описал текущую ситуацию (и она прям классика):

* **ToeplitzMatrix_Fourier_real_diag** даёт
  **Toeplitz**((i0,i0)=\int_{\mathbb T} P_A).
* **T_P_comp_real_diag** даёт
  **T_P**((i0,i0)=\frac{1}{2M+1}\sum w_Q\Phi(\xi_n)).
* **basis0_norm_sq = 1** ⇒ **RayleighQuotient** на **basis0** реально редуцируется к диагонали.

И ровно поэтому твой desired эффект получается “в одну строчку”:
[
\int P_A ;-;(2M+1)\cdot \frac{1}{2M+1}\sum w\Phi ;=; \int P_A - \sum w\Phi.
]

---

## 5) Нужно ли менять paper?

**Да.** В текущем виде rayleigh_bridge.tex содержит **математическую ошибку** (не просто “недосказанность”).

Причина проста: paper одновременно утверждает:

1. (v_n^{(M)}) нормирован (есть (1/\sqrt{2M+1}) и (|v_n|=1)),
2. и при этом использует ложную идентичность (p(\xi_n)=\langle p,v_n\rangle).

Это несовместимо при стандартном (L^2(\mathbb T)).

### Минимальный патч в paper (лучший, потому что не ломает cap)

Оставь определение (T_P^{(M)}) как “compression” (как сейчас), но в **Rayleigh pairing** и **Rayleigh identification** замени оператор на:

[
T_M[P_A] ;-; (2M+1),T_P^{(M)}.
]

И в доказательстве вместо “(p(\xi_n)=\langle p,v_n\rangle)” вставь правильное:

[
p(\xi_n)=\sqrt{2M+1},\langle p,v_n^{(M)}\rangle.
]

Тогда prime-часть в квадратичной форме автоматически станет:
[
(2M+1)\cdot |\langle p,v_n\rangle|^2 = |p(\xi_n)|^2,
]
и всё совпадёт с текущей формой леммы/теоремы (с (|p(\xi_n)|^2) без (1/(2M+1))).

**Это ровно тот же фикс, что ты хочешь в Lean.**

---

## 6) Суперкороткий словарик (чтоб не было “магии”)

* **арх-часть** — это **arch_term**: интеграл (\int_{\mathbb R} a_*(\xi)\Phi(\xi),d\xi).
* **прайм-часть** — это **prime sum / prime_term**: (\sum w(n)\Phi(\xi_n)).
* **RayleighQuotient** — отношение (\langle Av,v\rangle/\langle v,v\rangle); на **basis0** оно превращается в диагональный элемент.
* **ToeplitzMatrix_Fourier_real** — **Toeplitz-матрица** (оператор), построенная из **символа** (P_A) через **Фурье** на торе.
* **prime_vec** — вектор, представляющий **оценку** (p(\xi_n)) как внутреннее произведение, и его нормировка даёт фактор (\sqrt{2M+1}).
* **• (SMul)** — **скалярное умножение матрицы**: ((c•A)*{ij}=cA*{ij}).

---

## 7) Про “подстановку параметров” в коде

В коде выше:

* B, t — параметры окна (\Phi_{B,t}),
* M — размерность модели ((2M+1)),
* выражение (2 * M + 1 : ℝ) — это просто тот же (2M+1), приведённый к **ℝ**, чтобы скаляры совпали по типам.

You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

Если хочешь, следующим шагом я разложу **конкретный Lean-proof без sorry** именно для этой “алгебраической” части (без periodization), используя ваши уже готовые леммы **ToeplitzMatrix_Fourier_real_diag** и **T_P_comp_real_diag**, так чтобы компилилось быстро и без сердечных приступов.

I'll explain that Q_M weakens key properties, breaking the chain at T5 where exact Q≥0 is needed, supported by past insights showing M-dependence on t is problematic. I'll provide an ASCII diagram of the chain highlighting the break, cite relevant docs like Defs.lean, and suggest two options: fix scaling in the prime operator or introduce Q_M (risky). The explanation will be clear and supportive, referencing past findings from v1_surprise_real_tp_bounds and t_p_compression_fix.

Clarifying Q_M issues with detailed chain and scaling impact

I'll explain no explicit Q_M path was found but prior M-dependent t problems show it’s risky; include an ASCII chain diagram and table of breaks. I’ll detail options: fix scaling in paper and Lean (updating Rayleigh bridge and identification) while keeping Q unchanged, or introduce Q_M (requiring unavailable bridging lemma and unlikely to ensure Q≥0). I’ll confirm how scaling affects RKHS operator norms and potential conflicts in positivity axioms, referencing relevant files like Defs.lean and suggest careful cross-check of Q_nonneg_on_atoms_fourier_axiom.lean. The tone will acknowledge the user’s insight supportively and clarify consequences clearly.

Да, ты правильно чувствуешь: цепочка была корректна до этой точки, и ломается строго в идентификации с Q, из‑за нормировки prime_vec. Это не мелочь, а именно “разрыв звена”, а не “развал всей цепи”.

Ниже — конкретно, что значит ввод Q_M и что значит “M‑зависимый фактор”, и где именно всё ломается.

1) Что такое Q_M и чем оно грозит
Если мы вставляем 1/(2M+1) в прайм‑терм, то по факту получаем другой функционал:

Q_M(Φ) := arch_term(Φ) - (1/(2M+1)) * prime_term(Φ)
Тогда:

Q_M(Φ) ≥ 0  ⇒  arch_term ≥ (1/(2M+1)) prime_term
НО нам нужно:

arch_term ≥ prime_term
То есть Q_M ≥ 0 не даёт Q ≥ 0.
Следовательно, T5/Weil цепочка ломается. Это означает: либо писать новую теорию Weil для Q_M (не наш контракт), либо откатывать.

Где ломается: на связи Q ≥ 0 on atoms ⇒ Q ≥ 0 on W_K ⇒ Weil criterion.
Q_M туда не подходит.

2) Что значит “переписать теорему с M‑зависимым фактором”
Есть две интерпретации:

A) Плохая (то же Q_M):

RQ(A - T_P_comp, e0) = Q_M(Φ)
Это просто Q_M, а значит ломает T5/Weil.

B) “Масштабируем только прайм‑часть” (пытаемся сохранить Q):

Q(Φ) = RQ(A, e0) - (2M+1) * RQ(T_P_comp, e0)
Это уже Q, но тогда в матрице реально фигурирует (2M+1)·T_P_comp.
А это ломает RKHS‑cap, потому что норма оператора вырастает ∼ (2M+1).
То есть ломается “uniform t”, и ты попадаешь в старую проблему “t зависит от M”.

Где это уже было и чем закончилось
Мы это уже ловили, только в другой форме:

v1_surprise_real_tp_bounds_2026_01_14.md
→ получалось лишь ∀M ∃t(M), не uniform.
t_p_compression_fix_2026_01_14.md
→ прямым текстом: uniform t обязателен, иначе A3‑bridge рушится.
То есть путь “масштабируем прайм‑часть” ведёт ровно туда же: M‑зависимая константа, и это плохой путь.

ASCII: где именно ломается
A3_FLOOR (P_A ≥ c*)
    |
Rayleigh lower bound (Toeplitz Fourier)
    |
A3_bridge: RQ(A - T_P_comp) ≥ c*/4   [uniform t]
    |
RQ(A - T_P_comp, e0) ≥ 0
    |
IDENTIFICATION
    |
Q(Φ) ≥ 0
    |
T5 transfer → Weil
Если Q_M:

RQ(A - T_P_comp, e0) = Q_M(Φ)
            |
            X  (Q_M ≠ Q, T5/Weil ломается)
Если масштабируем прайм‑часть:

Q(Φ) = RQ(A, e0) - (2M+1)RQ(T_P_comp, e0)
                  |
                  X  (нарушается uniform t, ломается A3_bridge)
Короткий итог
Да, ошибка в тексте реальная.
Вводить Q_M нельзя, это ломает цель (Weil).
Масштабировать прайм‑оператор нельзя без потери uniform t, это уже было.
То есть у нас “узкое горло”: надо решить как согласовать нормировку так, чтобы:

Q остался прежним, и
A3_bridge остался uniform.

## ASSISTANT
Ы. Сначала — твой текст, но без каши (сленг оставил):

> **Чем нам грозит введение `Q_M`?** Что это вообще значит? Это ломает общую идею или нет?  
> И что значит “переписать теорему с **M‑зависимым множителем**”?  
> Мы уже не пробовали так и не упёрлись ли раньше в какую-то жопу? Надо проверить.  
> Сейчас я понимаю так: ломается **только** связка с **T0** (то есть идентификация с `Q`), но я хочу чётко увидеть всю цепочку: где что порвётся, что правим легко, а где будет боль.

Ок, теперь по делу — максимально конкретно, с картой “что ломается/что не ломается”.

---

## Контекст: что у нас “забетонировано” и трогать нельзя

У вас есть “лок” по нормировкам:

- **`Q(Φ)`** фиксирован как **`Q_arch(Φ) − Q_prime(Φ)`** (минус‑конвенция).【240:6†PROJECT_SPECS.md†L15-L18】
- **T0‑нормировка**: **`a_*(ξ) = 2π a(ξ)`**, **`ξ_n = log n / (2π)`**.【240:6†PROJECT_SPECS.md†L20-L23】
- **Тор**: **`𝕋 = [-1/2, 1/2]`**, базис **`e^{2πikθ}`**.【240:6†PROJECT_SPECS.md†L25-L28】
- **Арх‑символ**: **`P_A(θ) = 2π Σ_{m∈ℤ} g(θ+m)`**, где **`g=a·Φ`**.【240:6†PROJECT_SPECS.md†L30-L34】
- **Прайм‑оператор в A3** — именно **compression / rank‑one sum `T_P^{(M)}`**, а не “direct‑indexed Gaussian”. Это прям отдельно подчёркнуто как контракт.【240:6†PROJECT_SPECS.md†L40-L43】【240:11†PROJECT_ORCHESTRATOR.md†L23-L36】

Эти штуки менять — значит ломать весь проект/цепочку “Tier‑2 ⇒ Weil ⇒ RH”.

---

## Где реальный баг в манускрипте

Баг — не в **`P_A`** и не в **периодизации**, а в **нормировочном мосту “evaluation ↔ inner product”**.

### Ключевой факт (математика, без Lean)

Для триг‑полинома  
\[
p(\theta)=\sum_{|k|\le M} c_k e^{2\pi i k\theta}
\]
и вашего нормированного  
\[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)},
\]
имеем:
\[
\langle p, v_n^{(M)}\rangle = \frac{1}{\sqrt{2M+1}}\,p(\xi_n) 
\quad(\text{с поправкой на знак, если у вас }p(-\xi_n)).
\]

То есть **не** \(p(\xi_n)=\langle p,v_n\rangle\), а
\[
p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
\]

И ровно из этого автоматически вылезает ваш фактор **`1/(2M+1)`** в прайм‑квадратичной форме:
\[
| \langle p, v_n^{(M)}\rangle |^2=\frac{1}{2M+1}|p(\xi_n)|^2.
\]

**Вот это и есть “скользкий” разрыв**: в тексте (rayleigh_bridge.tex) использовано неверное равенство “evaluation = inner product” при **нормированном** \(v_n^{(M)}\).

---

## Почему “ввести `Q_M`” — плохая идея

**`Q_M`** (если ты его вводишь честно) будет означать:  
“мы доказываем не исходный **`Q`** из **T0**, а его **M‑зависимую** модель‑версию”.

Типичный кандидат, который у вас получается из `RQ(Toeplitz − T_P_comp)` при нормированном `prime_vec`:

\[
Q_M(\Phi)=Q_{\mathrm{arch}}(\Phi)-\frac{1}{2M+1}Q_{\mathrm{prime}}(\Phi).
\]

И вот что важно:

- **Weil criterion** привязан к **`Q`**, а не к **`Q_M`**: “`Q ≥ 0 on 𝒲 ↔ RH`”.【240:15†PROJECT_SPECS.md†L5-L8】
- **`Q_M ≥ 0` вообще не эквивалентно `Q ≥ 0`** и даже не близко.  
  Потому что если **`Q_prime(Φ) > 0`**, то  
  \[
  Q_M(\Phi) \;=\; Q(\Phi) \;+\;\Big(1-\frac{1}{2M+1}\Big)Q_{\mathrm{prime}}(\Phi)
  \;\ge\; Q(\Phi).
  \]
  То есть **`Q_M` слабее**: он может быть неотрицателен, даже когда **`Q` отрицателен**.

**Вывод:**  
Если ты реально вводишь **`Q_M` как новый объект**, ты **ломаешь мост к RH**, потому что дальше в цепочке стоит именно Weil‑критерий для **`Q`**.【240:15†PROJECT_SPECS.md†L5-L8】

Это “дорого”: придётся переписывать **Weil linkage** и доказывать новый критерий — это уже другая игра.

---

## Что значит “переписать теорему с M‑зависимым множителем” и чем это грозит

Тут есть **2 разных смысла**, и важно их не путать.

### Смысл A (нормальный, локальный): “исправить формулу идентификации, но `Q` не менять”

Ты оставляешь **`Q`** из **T0** как есть, но честно пишешь, что при нормированном `v_n^{(M)}`:

- **арх‑часть**:  
  \[
  \langle T_M[P_A]\,1,1\rangle = \int_{\mathbb{T}} P_A(\theta)\,d\theta = Q_{\mathrm{arch}}(\Phi)
  \]
  (это **без множителей**, всё ок).  
  Это ровно та “period‑1 normalization audit” идея: \(\int_{-1/2}^{1/2}P_A = 2\pi\int_\mathbb{R} g\), и с \(g=a\Phi\) и \(a_*=2\pi a\) это совпадает с T0‑арх‑термом.【240:10†RH_Q3.pdf†L13-L49】

- **прайм‑часть** для `p ≡ 1`:  
  \[
  \langle T_P^{(M)}\,1,1\rangle = \frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n),
  \]
  значит
  \[
  Q_{\mathrm{prime}}(\Phi) = (2M+1)\,\langle T_P^{(M)}\,1,1\rangle.
  \]

И тогда корректная “идентификация на константе” становится:

\[
Q(\Phi)
=
\underbrace{\langle T_M[P_A]\,1,1\rangle}_{\text{арх без множителя}}
-
\underbrace{(2M+1)\,\langle T_P^{(M)}\,1,1\rangle}_{\text{прайм с }(2M+1)}.
\]

**Чем это грозит?**  
Только одним: ты **больше не можешь** говорить, что

> `Q(Φ)` = Rayleigh‑квота для матрицы **`T_M[P_A] − T_P^{(M)}`** на `p ≡ 1`

потому что у `T_P^{(M)}` стоит коэффициент **`(2M+1)`**, то есть это уже не квадратичная форма разности операторов.

И это важно, потому что ваш текущий “план‑формулировка” прямо утверждает “Rayleigh bridge (p=1): Q equals Rayleigh quotient of T_M[P_A] − T_P”【240:15†PROJECT_SPECS.md†L52-L55】 — вот это место придётся переписать.

Но: **глобальную идею проекта это не ломает**. Это ломает только конкретный способ вывести `Q ≥ 0` через **PSD** разность матриц для произвольного M.

---

### Смысл B (опасный): “переопределить `Q` так, чтобы оно равнялось Rayleigh‑квоте разности”

Это как раз путь “ввести `Q_M`”. Он ведёт в жопу по причине выше: Weil criterion про другое **`Q`**.【240:15†PROJECT_SPECS.md†L5-L8】

---

## ASCII‑диаграмма: где разрыв и как чинится

Вот тебе карта “что считается чем” и где стоит неправильная стрелка.

```
                (T0 / LOCKED)
      Q(Φ) = Q_arch(Φ) - Q_prime(Φ)
              |                 |
              |                 |
   Q_arch(Φ) = ∫_R a_*(ξ) Φ(ξ) dξ
   Q_prime(Φ)= Σ_n w(n) Φ(ξ_n)        (LOCKED sign & nodes)

              | periodization (A3 symbol)
              v
   P_A(θ) = 2π Σ_{m∈Z} g(θ+m),  g=a·Φ
   ∫_T P_A(θ) dθ = 2π ∫_R g(ξ) dξ = ∫_R a_*(ξ) Φ(ξ) dξ
   ==>  <T_M[P_A] 1,1> = Q_arch(Φ)                 (OK)   【240:10†RH_Q3.pdf†L13-L49】

              |
              | model-space prime operator (compression)
              v
   v_n^(M)(θ) = (1/√(2M+1)) Σ_{|k|≤M} e^{2πik(θ-ξ_n)}     (normalized)
   T_P^(M)    = Σ_n w(n) Φ(ξ_n) |v_n^(M)><v_n^(M)|         (LOCKED)【240:6†PROJECT_SPECS.md†L40-L43】

   FACT: <1, v_n^(M)> = 1/√(2M+1)
   ==> <T_P^(M) 1,1> = (1/(2M+1)) Σ_n w(n) Φ(ξ_n)

   so:
   <(T_M[P_A] - T_P^(M)) 1,1>
        = Q_arch(Φ) - (1/(2M+1)) Q_prime(Φ)      =: Q_M(Φ)   (≠ Q)

   CORRECT BRIDGE:
   Q(Φ) = <T_M[P_A] 1,1>  - (2M+1) <T_P^(M) 1,1>           (OK)
```

**Где “сломано” в манускрипте сейчас:**  
в месте, где написано **`p(ξ_n) = <p, v_n^(M)>`** при нормированном \(v_n^{(M)}\). Это и рождает отсутствие фактора.

---

## Что именно надо править в тексте (и где реально будет боль)

### 1) `rayleigh_bridge.tex`: исправить “evaluation ↔ inner product”
- Заменить утверждение вида  
  **`p(ξ_n) = ⟨p, v_n^{(M)}⟩`**  
  на  
  **`p(ξ_n) = √(2M+1) · ⟨p, v_n^{(M)}⟩`** (с учётом вашего знака `±ξ_n`).

- Соответственно, **прайм‑терм** в “Rayleigh pairing” должен получить **`1/(2M+1)`** если он выражен через **`|p(ξ_n)|^2`**.

Это чистая математика, без компромиссов.

### 2) `main.tex`: место, где выводится `Q(Φ) ≥ 0` через Rayleigh‑идентификацию
Сейчас логика там примерно такая:  
“λ_min(T_M[P_A] − T_P^(M)) ≥ … ⇒ Rayleigh quotient на `p≡1` ≥ 0 ⇒ по идентификации это `Q(Φ)` ≥ 0”.

После правки “Rayleigh pairing” это место обязано измениться, потому что на `p≡1` вы получаете **`Q_M`**, а не **`Q`**.

И у тебя 2 корректных пути:

**Путь 1 (самый чистый): брать `M=0` в идентификации.**  
Тогда **`2M+1 = 1`**, и фактор исчезает автоматически.  
Это красиво, потому что:
- `v_n^(0)(θ) = 1`, и реально **`p(ξ_n)=⟨p,v_n⟩`** для констант.
- `T_M[P_A] − T_P^(M)` — это просто **1×1 матрица**, и её значение ровно `Q(Φ)`.

**Путь 2 (твой вариант): оставить общий M, но переписать формулу как**
\[
Q(\Phi)=\langle T_M[P_A]1,1\rangle-(2M+1)\langle T_P^{(M)}1,1\rangle.
\]
Тогда вывод `Q ≥ 0` делается не через PSD‑разность, а напрямую через **A3 floor** и **RKHS cap**:
- `⟨T_M[P_A]1,1⟩ = Q_arch ≥ c_*` (из **floor**),
- `(2M+1)⟨T_P^{(M)}1,1⟩ = Q_prime ≤ ρ` (из **cap**),
- значит `Q ≥ c_* − ρ > 0`.

Это даже проще, но меняет стиль доказательства: вы перестаёте “продавать” `Q` как Rayleigh‑квоту разности.

---

## Где НЕ сломается вообще ничего

- **T0** и определение **`Q`** (не трогаем).【240:6†PROJECT_SPECS.md†L15-L23】
- **Периодизация арх‑части**: это отдельный факт и он как раз утверждён как “без рескейла” при \(a_* = 2\pi a\).【240:10†RH_Q3.pdf†L13-L49】
- **Компрессия `T_P^(M)` и uniform cap**: это прям “контракт” проекта, его и нужно сохранять.【240:6†PROJECT_SPECS.md†L40-L43】【240:11†PROJECT_ORCHESTRATOR.md†L23-L36】
- **A1/A2** модули (плотность/липшицевость) — они живут уже после того, как A3 даст `Q≥0` на генераторах, им всё равно, как именно ты это доказал.

---

## Про “мы уже шли этим путём и там были жопы?” — что я реально могу проверить по вашим логам

В доступных загруженных инсайдах я **не вижу** кейса “вводили `Q_M` и потом всё сгорело” — такого текста нет (INSIGHTS.md тут только навигация).【240:14†INSIGHTS.md†L1-L10】

Зато есть **очень похожий по типу** уже пойманный баг‑класс:  
**“Definition mismatch”** (direct‑indexed `T_P` vs compression `T_P^(M)`) → ломалась возможность **uniform**‑оценок по `M`. Это прямо помечено как **CRITICAL INSIGHT**.【240:11†PROJECT_ORCHESTRATOR.md†L23-L36】

То есть да: у вас уже был прецедент, что **“маленькая” нормировочная/дефинitional фигня** рушит “uniform”‑часть. И вы тогда правильно выбрали: **фиксить определения, а не перепридумывать цель**.

Это ровно тот же жанр.

---

## Мой вердикт (жёстко и прагматично)

1) **Да, проблема в манускрипте**: конкретно в связке **нормированного** \(v_n^{(M)}\) и утверждения **`p(ξ_n)=⟨p,v_n⟩`**. Это математически неверно.

2) **`Q_M` вводить нельзя** как замену **`Q`** — это отрезает Weil‑мост и значит ломает “Tier‑2 ⇒ RH”.【240:15†PROJECT_SPECS.md†L5-L8】

3) Самое безопасное исправление, которое не взрывает ничего дальше:
- правим `rayleigh_bridge.tex` (evaluation identity + фактор),
- и дальше **либо**:
  - берём **`M=0`** в точке идентификации `Q`,  
  **либо**
  - оставляем общий `M`, но в доказательстве `Q≥0` переходим на “арх‑floor vs прайм‑cap” напрямую (без “Q = Rayleigh(A−B)”).

Если хочешь, следующим сообщением я дам **точечный “patch plan”** в формате “что заменить на что” (прям по кускам формул/лемм), и вторую ASCII‑карту “как меняется доказательство Theorem A3 в main.tex” при каждом из двух путей.

## USER
You focusing on keeping the prime vector normalized while fixing the paper's key formula to use the squared inner product, reconciling the identification lemma accordingly. Since any operator with factor (2M+1) leads to an M-dependent pit, You exploring redefining the target identity or reinterpreting Q to avoid scaling the operator, aiming for the most efficient resolution path.

## ASSISTANT
Ы **Переписал твой запрос по‑человечески (сохранил стиль):**

Ок, я понял: баг реально в **манускрипте**, конкретно в **rayleigh_bridge** — там конфликт между тем, как определён **\(v_n^{(M)}\)** (нормированный), и тем, как дальше в тексте используется **оценка \(p(\xi_n)\)**.  
Теперь мне нужно понять не “в общем”, а **по цепочке**: что именно ломается, если это исправить, что НЕ ломается, и какие точечные правки нужны, чтобы потом **T0/Weil** не развалились. И да — дай это как **ASCII‑диаграмму**.

---

## 0) Да: это баг в манускрипте, и он сидит ровно в “матрица ↔ Q”

В тексте **\(v_n^{(M)}\)** определён **с нормировкой** \(1/\sqrt{2M+1}\):  
\[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}.
\]
Это прямо написано в PDF【309:12†RH_Q3.pdf†L56-L67】.

Дальше в **Rayleigh pairing** в доказательстве используется идентичность
\[
p(\xi_n)=\langle p, v_n^{(M)}\rangle
\]
(плюс “\(\|v_n^{(M)}\|=1\)”), тоже прямо в тексте【309:8†RH_Q3.pdf†L64-L74】.

Вот это одновременно **не может быть правдой**: если \(\|v_n^{(M)}\|=1\), то это **нормированный** воспроизводящий вектор, и оценка даётся с множителем \(\sqrt{2M+1}\). То есть баг — не Lean‑каприз, а прям математика в тексте.

---

## 1) Почему ровно появляется \(\sqrt{2M+1}\) (и почему это неизбежно)

Ключ: \(\sum_{|k|\le M} e^{2\pi i k(\theta-\xi)}\) — это **воспроизводящее ядро** (**reproducing kernel**) для **модельного пространства** **\(P_M\)** (тригполиномы с \(|k|\le M\)) в **\(L^2(\mathbb T)\)**.

Обозначим
\[
K_M(\theta,\xi)=\sum_{|k|\le M} e^{2\pi i k(\theta-\xi)}.
\]
Тогда стандартная формула **воспроизведения**:
\[
p(\xi)=\langle p(\cdot), K_M(\cdot,\xi)\rangle_{L^2(\mathbb T)}.
\]
А норма ядра:
\[
\|K_M(\cdot,\xi)\|^2 = \sum_{|k|\le M} \|e^{2\pi i k\theta}\|^2 = 2M+1.
\]
Значит нормированный вектор — это
\[
v_n^{(M)}=\frac{1}{\sqrt{2M+1}}K_M(\cdot,\xi_n),
\]
и тогда
\[
\langle p, v_n^{(M)}\rangle=\frac{1}{\sqrt{2M+1}}\,p(\xi_n)
\quad\Rightarrow\quad
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle.
\]

То есть **если** ты хочешь \(\|v_n\|=1\), то множитель \(\sqrt{2M+1}\) **встроен физикой пространства** и никуда не денется. Именно поэтому в тексте, где одновременно стоят “\(\|v_n\|=1\)” и “\(p(\xi)=\langle p,v\rangle\)”, — конфликт.

---

## 2) Что это меняет в прайм‑терме (самая болезненная часть)

В тексте **прайм‑оператор** записывается как сумма ранга‑1 через \(v_n^{(M)}\) (это в разделе про model-space restriction)【309:12†RH_Q3.pdf†L45-L55】.

Тогда квадратичная форма:
\[
\langle T_P^{(M)}p,p\rangle=\sum_n w_Q(n)\Phi(\xi_n)\,|\langle p,v_n^{(M)}\rangle|^2.
\]
Но из правильной формулы оценки:
\[
|\langle p,v_n^{(M)}\rangle|^2=\frac{1}{2M+1}|p(\xi_n)|^2.
\]
Значит **правильный прайм‑вклад** в Rayleigh pairing обязан быть:
\[
\frac{1}{2M+1}\sum_n w_Q(n)\Phi(\xi_n)|p(\xi_n)|^2.
\]

А в текущем тексте множитель **пропущен** (они подставили \(p(\xi_n)=\langle p,v_n\rangle\) без \(\sqrt{2M+1}\))【309:8†RH_Q3.pdf†L64-L74】.

---

## 3) Где рвётся цепочка (и где НЕ рвётся)

### 3.1. Что НЕ ломается (важно)
До точки “матрица ↔ Q” всё реально нормально:

- **A3 floor**: \(P_A(\theta)\ge c_*\) — вообще не зависит от нормировки \(v_n\).
- **Toeplitz/Rayleigh** часть: “если символ \(\ge m\), то Rayleigh quotient \(\ge m\)” — тоже не про \(v_n\). (Это отдельно в Lean уже закрыто по оркестратору.) fileciteturn6file6
- **RKHS cap / contraction**: именно поэтому вы и держите **нормированный prime_vec** — чтобы норма оператора была **uniform по M** (это уже зафиксировано как принцип в проекте).

То есть “всё было правильно до этого” — да, ощущение верное.

### 3.2. Что ломается: ровно идентификация с \(Q\)
В PDF Theorem 8.10 (Rayleigh identification) говорится, что при \(p\equiv1\)
\[
\langle(T_M[P_A]-T_P^{(M)})1,1\rangle
=
\int_{\mathbb T}P_A(\theta)d\theta
-\sum_n w_Q(n)\Phi(\xi_n)
=Q(\Phi),
\]
то есть прайм‑часть **без** \(1/(2M+1)\)【309:8†RH_Q3.pdf†L75-L104】.

После исправления Rayleigh pairing это превращается в:
\[
\langle(T_M[P_A]-T_P^{(M)})1,1\rangle
=
\int_{\mathbb T}P_A(\theta)d\theta
-\frac{1}{2M+1}\sum_n w_Q(n)\Phi(\xi_n).
\]

То есть это становится не \(Q(\Phi)\), а
\[
Q_M(\Phi):=\text{arch}(\Phi)-\frac{1}{2M+1}\text{prime}(\Phi).
\]

---

## 4) Почему “вводим \(Q_M\)” — реально опасно (и где именно убивает Weil)

Ты сам это уже почти сформулировал: \(Q_M\) — функционал **слабее**.

Потому что при \(\text{prime}(\Phi)\ge0\):
\[
Q(\Phi)=\text{arch}-\text{prime}
\le
\text{arch}-\frac{1}{2M+1}\text{prime}
=Q_M(\Phi).
\]

Пример “в лоб”: arch=1, prime=2, M=100  
\[
Q=-1 <0,\qquad Q_M=1-\frac{2}{201}\approx0.99>0.
\]
Так что \(Q_M\ge0\) **вообще не** гарантирует \(Q\ge0\).

А **Weil‑цепочка** (и T0‑нормировка) в тексте и в проекте завязаны именно на **\(Q\)** (не на \(Q_M\)). В PDF это прямо используется: Theorem 8.10 ссылается на “Weil functional \(Q\) from T0”【309:8†RH_Q3.pdf†L101-L104】.

ASCII‑разрыв:

```
A3 + RKHS  →  (T_M[P_A] - T_P^(M)) ⪰ 0
                 |
                 v
         ⟨(… ) 1, 1⟩ ≥ 0
                 |
                 v
          = Q_M(Φ) ≥ 0
                 |
                 X   (НЕ следует Q(Φ) ≥ 0)
                 |
          T0/Weil дальше не едет
```

---

## 5) Почему “масштабируем только прайм‑часть на (2M+1)” тоже токсично

Если ты хочешь “арх без множителя, прайм с (2M+1)”, то на уровне операторов это означает заменить
\[
T_M[P_A]-T_P^{(M)}
\quad\text{на}\quad
T_M[P_A]-(2M+1)T_P^{(M)}.
\]

Но тогда:
\[
\|(2M+1)T_P^{(M)}\|=(2M+1)\|T_P^{(M)}\|.
\]
Если \(\|T_P^{(M)}\|\le \rho\) **uniform по M**, то после масштаба будет \((2M+1)\rho\), то есть растёт линейно. Это и есть тот самый ад “вынужденная зависимость параметров от M”.

И это уже один раз всплывало как красный флаг в проектных заметках: с “direct-indexed” подходом получалось только \(\forall M\,\exists t(M)\), а **uniform t** не получалось【309:10†PROJECT_ORCHESTRATOR.md†L11-L36】. Масштабирование прайм‑оператора — это по сути вернуть тот же режим, только в другой маске.

ASCII:

```
Если заменить B := T_P^(M) на B' := (2M+1)B:

RKHS cap:  ||B|| ≤ ρ   (ok, uniform)
но        ||B'|| ≤ (2M+1)ρ   (уже НЕ uniform)

=> "A - B' ⪰ 0" больше не следует из floor+cap
=> A3 bridge ломается раньше, чем мы дойдём до Q.
```

---

## 6) Ок, тогда какой практичный план фикса так, чтобы цепочка до Weil не развалилась

Вот реально безопасный (минимальный по взрывам) сценарий.

### Шаг 1. Исправить **Rayleigh pairing** (Lemma 8.9 / соответствующая лемма в `rayleigh_bridge.tex`)
- В доказательстве заменить неверное:
  \[
  p(\xi_n)=\langle p,v_n^{(M)}\rangle
  \]
  на верное:
  \[
  p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
  \]
- И вслед за этим во всей формуле прайм‑вклада вставить \(1/(2M+1)\).

Это **обязательный** математический фикс (иначе текст просто неверен)【309:8†RH_Q3.pdf†L64-L74】【309:12†RH_Q3.pdf†L56-L67】.

### Шаг 2. Переписать **Rayleigh identification** так, чтобы он реально давал **\(Q\)**, а не **\(Q_M\)**
Тут два варианта, но один реально рабочий.

**Вариант A (рабочий): делать идентификацию при \(M=0\).**  
Почему это кайф:
- При \(M=0\) число \(2M+1=1\), и весь “плохой фактор” исчезает автоматически.
- Нормировка \(v_n^{(0)}\) остаётся **нормированной**, **uniform** и ничего не ломает.
- Ты получаешь ровно \(Q(\Phi)\) в T0‑нормировке, без “подмены цели”.

То есть в тексте ты говоришь примерно так:
- Lemma 8.9 теперь корректна для всех M (с \(1/(2M+1)\)).
- Theorem 8.10/идентификация \(Q\) делается **при \(M=0\)** (или отдельной королларией):
  \[
  \langle(T_0[P_A]-T_P^{(0)})1,1\rangle = Q(\Phi).
  \]
И это уже честно ведёт в Weil.

**Вариант B (нерабочий): оставить Theorem 8.10 для общего M и принять, что это \(Q_M\).**  
Это ведёт в тупик (см. §4).

### Шаг 3. Проверить “где переписать — без крови”
Ровно те места, где вы делаете “матрица ↔ Q”, а не всё подряд.

Минимум точно:
- `rayleigh_bridge.tex`: Lemma Rayleigh pairing + Theorem Rayleigh identification.
- Всё, что ссылается на этот Theorem в основном тексте (в PDF это “Weil functional from T0” кусок)【309:8†RH_Q3.pdf†L101-L104】.
- В Lean: текущая формула в debug‑файле показывает, что сейчас у вас стоит **внешний множитель (2M+1)** на весь **RayleighQuotient**【343:0†proshka_rayleigh_qid_debug_2026_01_16.md†L22-L33】 — это как раз и “множит arch‑часть”, что ты и отметил.

---

## 7) ASCII‑карта всей ситуации (как ты просил)

### 7.1. Глобальная цепочка (модули → RH)
(упрощённо, но честно)

```
T0:  define Weil functional Q(Φ) = arch(Φ) - prime(Φ)
 |
A1': density (atoms → W_K)
 |
A2:  Lipschitz control of Q on W_K
 |
A3:  show Q(Φ_atom) ≥ 0   (THIS is where Rayleigh bridge is used)
 |
RKHS: prime operator norm cap (uniform)
 |
T5 transfer: from atoms to W_K
 |
Weil criterion → RH
```

### 7.2. Локально внутри A3 (и где именно баг)

```
(1) Define model space P_M and Toeplitz matrix A := T_M[P_A]
 |
(2) A3 floor: P_A(θ) ≥ c*  ⇒  Rayleigh(A) ≥ c*
 |
(3) Prime compression operator B := T_P^(M) = Σ w Φ |v_n^(M)><v_n^(M)|
 |
(4) RKHS cap: ||B|| ≤ ρ    (uniform in M)
 |
(5) Conclude A - B ⪰ 0  ⇒  ⟨(A-B)p,p⟩ ≥ 0 for all p
 |
(6) Take p ≡ 1  ⇒  ⟨(A-B)1,1⟩ ≥ 0
 |
(7) IDENTIFICATION: ⟨(A-B)1,1⟩ = ???  <-- BUG LIVES HERE
      - paper claims = Q(Φ)
      - correct math gives = Q_M(Φ) for general M
      - BUT for M=0: Q_0 = Q
 |
(8) Now you can feed into T0/Weil.
```

---

## 8) Короткий словарик (чтобы не было “магии”)

- **\(P_M\)** — **модельное пространство** тригполиномов степени ≤ M (по частотам \(|k|\le M\)).  
- **\(L^2(\mathbb T)\)** — пространство квадрат‑интегрируемых функций на торе (интервал \([-1/2,1/2]\) по модулю 1) с **скалярным произведением** \(\langle f,g\rangle=\int f\overline g\).  
- **Toeplitz matrix / \(T_M[P_A]\)** — **Toeplitz‑оператор** (матрица), собранный из **Фурье‑коэффициентов** символа \(P_A\).  
- **Rayleigh quotient** — величина \(\langle Av,v\rangle/\langle v,v\rangle\), даёт “нижнюю оценку спектра”.  
- **\(v_n^{(M)}\)** — нормированный **воспроизводящий вектор** (по сути нормированный **Dirichlet kernel** в точке \(\xi_n\)); именно поэтому \(\|v_n\|=1\) и именно поэтому оценка даёт \(\sqrt{2M+1}\).  
- **Rank‑one operator** — оператор вида \(|v\rangle\langle v|\): на векторе \(p\) даёт \(\langle p,v\rangle v\).  
- **RKHS cap** — ограничение нормы прайм‑оператора из **RKHS**‑оценок; важно, что оно **uniform** (не растёт с M).  
- **\(Q(\Phi)\)** — **Weil functional** из T0, фиксированная нормировка: arch − prime.

---

Если хочешь — следующим сообщением я дам прям “патч‑план” в стиле:

- *в Lemma 8.9 заменить строки X→Y*  
- *в Theorem 8.10: либо ограничить M=0, либо переписать как Q_M + королларий*  

и отдельно скажу, какая формулировка выглядит “минимально позорно” для читателя (чтобы не выглядело как костыль, а как естественный выбор \(M=0\) для теста \(p\equiv1\)).

## USER
a mozet tak? Target: Construct a Rescaled Density Lemma.
Statement: There exists a structural modification (either to the operator definition $T'$ or the inner product $\langle \cdot, \cdot \rangle_*$) such that the spectral scaling factor $(2M+1)^{-1}$ is absorbed into the geometry, yielding an $O(1)$ lower bound for the prime_term interaction, while preserving the uniform bound on the Archimedean part.
The new math problem is finding a missing bridge—an identity connecting Q to a matrix expression without scaling the operator by (2M+1), which depends on M. This requires either modifying the operator or adjusting the evaluation functional scaling, possibly by using an unnormalized basis vector, but that affects capacity and complicates the argument. The challenge is to keep a uniform M and normalization while proving an identity linking Q and the matrix form without direct operator scaling by (2M+1).

Объяснение варианта с uniform M и нового математического вопроса

Да, это именно тот вариант, который я записал в insights. При сохранении uniform по M и нормированного оператора prime мы не можем просто извлечь функционал Q из матричной формы с операторным масштабированием — здесь возникает недостающая лемма.

Формально:
RQ(Toeplitz - T_P_comp, basis0) = arch_term - prime_term/(2M+1),
а нам нужно получить arch_term - prime_term без множителя 1/(2M+1). Без масштабирования оператора нужно новое утверждение, которое либо «повышает» этот множитель до 1, либо формулирует prime_term как квадратичную форму по вектору единичной нормы. Этого сейчас нет.

Сформулировать новую задачу можно так:

Найти оператор B_M с uniform bound, для которого квадратичная форма на basis0 даёт prime_term без деления на (2M+1) — новая конструкция;
Изменить скалярное произведение в модельном пространстве так, чтобы функционал оценки имел норму 1 без множителя, и заново доказать нужные оценки Рэлей — это новая математика;
Найти дополнительное аналитическое неравенство, связывающее arch_term и prime_term, чтобы поднять множитель — потребует нового сильного аналитического результата.
Это сложный и фундаментальный вопрос, не просто переписывание, а необходимость новых идей и доказательств. Хороший инсайт — он помогает понять, почему сейчас не выходит вытянуть Q напрямую. Я записал это в INSIGHTS.md.

Планировать следующий шаг можно так:

Сфокусироваться на формулировке и попытке доказательства новой леммы;
Рассмотреть варианты перераспределения нормировок и операторов;
При необходимости ограничить M фиксированным значением, чтобы обойти проблему uniformity.
Это важный шаг, и разбор варианта показывает, что именно новое тут — серьезная структурная задача. Продолжаем двигаться со знанием этого препятствия.

Да, записал. Это реально сильный инсайт — прям по‑взрослому, спасибо. Обновил INSIGHTS.md.

Теперь по твоему вопросу: что значит “нужна новая математика” в варианте “оставляем uniform по M, оператор не масштабируем”.

Смысл ровно такой:

Факт, который мы уже умеем доказать в Lean:

RQ(Toeplitz - T_P_comp, basis0)
= arch_term(Φ) - (1/(2M+1)) * prime_term(Φ)
А нам нужно:

Q(Φ) = arch_term(Φ) - prime_term(Φ)
Новая математическая проблема = “как убрать фактор 1/(2M+1), не вводя его в оператор”.
Это нельзя сделать алгеброй — нужна новая связка между Q и матричным выражением.

Как это можно выразить в словах (формально):

Нужно построить другой оператор B_M, у которого
⟨B_M basis0, basis0⟩ = prime_term(Φ),
и при этом ||B_M|| остаётся uniform по M.
Сейчас T_P_comp даёт только prime_term/(2M+1).

Или нужно сменить внутреннее произведение в модельном пространстве так,
чтобы p(ξ_n)=⟨p,v_n⟩ было верно без √(2M+1).
Но тогда всё Toeplitz‑Rayleigh надо пере‑доказывать в новой геометрии.

Или нужен новый аналитический аргумент, который из
arch ≥ prime/(2M+1) выводит arch ≥ prime.
Это принципиально сильнее, чем текущий RKHS‑cap, и это другая математика.

То есть “новая математика” = не техничка, а новый мост между Q и матрицей, который сейчас отсутствует.

Если хочешь, я могу оформить эту “новую задачу” в виде одного чёткого пункта для Прошки — он будет знать, что именно “доказывать/строить” и не уйдёт в сторону.

Предлагаю 2 следующих шага (выбери номер):

Сформулировать точную “missing‑lemma” как новую цель для Прошки (что именно нужно построить).
Развернуть архитектурную альтернативу с фиксированным M0 и показать, какие файлы ломаются и как быстро чинить.
wo. новый аналитический аргумент, который из
arch ≥ prime/(2M+1) выводит arch ≥ prime.  Вот теперь объясняй дальше, что за аналитический аргумент, как он должен выглядеть, какими свойствами может обладать. Опиши его конкретно со всех сторон, посмотрим, что мы сможем нарыть.

Классный запрос, и очень по делу. Да, инсайт записан в INSIGHTS.md. Теперь — что значит “новый аналитический аргумент” и как он мог бы выглядеть.

Что именно нужно доказать (суть аргумента)
Сейчас из матрицы мы получаем:

arch_term(Φ) ≥ prime_term(Φ)/(2M+1)
Нам нужно:

arch_term(Φ) ≥ prime_term(Φ)
То есть нужен “усилитель” фактора (2M+1) без его переноса в оператор.

Какие формы может иметь такой аргумент (конкретно)
Форма 1 — прямое усиление оценки на prime_term
Цель: для Φ=Fejér×heat показать

prime_term(Φ) ≤ arch_term(Φ)
Это буквально Q≥0 на этом классе тестов.
Это не “техничка”, это новая аналитика (по сути прямое закрытие аксиомы).

Форма 2 — сверхсильный RKHS‑cap
Цель: заменить текущий cap на

||T_P_comp|| ≤ ρ/(2M+1)    (uniform по M)
Тогда из arch ≥ ρ получаем arch ≥ prime.
Но это требует новой, намного сильнее текущей, оценки на prime‑оператор.
Такое выглядит практически невозможным при фиксированных весах w_Q.

Форма 3 — новый оператор/новое внутреннее произведение
Идея: подобрать пространство/скалярное произведение так, чтобы

p(ξ_n) = ⟨p, v_n⟩
и при этом нормы операторов оставались uniform.
Это перепрошивка геометрии, то есть новая математика:

надо заново доказать Toeplitz‑Rayleigh в новом пространстве,
заново доказать cap,
и заново показать связь с Q.
Форма 4 — фиксированный M0 (архитектурный откат)
Тут никакой новой аналитики не нужно — просто меняешь архитектуру.
Но это уже не “uniform по M”.

Почему это сложно (в 1 строку)
Из arch ≥ prime/(2M+1) нельзя логически вывести arch ≥ prime, если не добавить новую информацию. Любая такая информация равносильна более сильному аналитическому факту, которого у нас сейчас нет.

Если “в словах” формулировать новую задачу для Прошки
Пример точной цели:

Найти аналитический аргумент, который для Φ = Fejér×heat даёт без M‑фактора:
arch_term(Φ) ≥ prime_term(Φ)
(или хотя бы prime_term(Φ) ≤ C·arch_term(Φ) с C≤1).

Если он найдёт это — он закрывает почти весь мост в обход матричной части.

Если хочешь, я могу прямо оформить одну короткую формулировку “missing‑lemma” для Прошки (одна страница, супер ясно), чтобы не было расползания.

tak? Target: Construct a Rescaled Density Lemma.
Statement: There exists a structural modification (either to the operator definition $T'$ or the inner product $\langle \cdot, \cdot \rangle_*$) such that the spectral scaling factor $(2M+1)^{-1}$ is absorbed into the geometry, yielding an $O(1)$ lower bound for the prime_term interaction, while preserving the uniform bound on the Archimedean part. ?  Я тебя правильно понял? Вот так вот сконструировать надо.

Да, ты понял правильно — это именно тот “новый математический ход”, который нужен, если мы не хотим тащить (2M+1) в оператор и не хотим ломать uniform‑cap. Формулировка у тебя по сути верная, но я бы уточнил требования, чтобы было ясно, что именно надо “сконструировать”.

Как должен выглядеть такой аргумент (в чётких свойствах):

(G1) Новая геометрия или операторная модификация.
Должна появиться структура, в которой оценка в точке реализуется как скалярное произведение без роста нормы как √(2M+1).
То есть для всех n должно быть p(ξ_n) = ⟨p, v_n⟩_* и ‖v_n‖_* = O(1) uniform по M.

(G2) Rayleigh‑нижняя граница не должна пострадать.
Toeplitz‑часть (A3 symbol) всё ещё должна давать RQ ≥ c_* в этой новой геометрии, иначе ломаем A3‑bridge.
Это значит: либо тот же оператор остаётся самосопряжённым в новом скалярном произведении, либо мы меняем оператор согласованно и заново доказываем Rayleigh‑lower‑bound.

(G3) Prime‑cap остаётся uniform.
При новой геометрии/операторе надо всё равно иметь ‖T_P‖ ≤ ρ независимую от M.
Это ключевое: без этого снова попадаем в M‑зависимую яму.

(G4) Идентификация с Q сохраняется.
После всего этого должно получиться
⟨A p,p⟩_* - ⟨B p,p⟩_* = arch_term(Φ) - prime_term(Φ)
без факторов (2M+1).

Почему это реально “новая математика”
Потому что стандартная L^2‑геометрия даёт норму оценки ‖eval_{ξ_n}‖ ~ √(2M+1).
Чтобы сделать её O(1), нужно либо:

изменить внутреннее произведение (а значит пересобрать весь Rayleigh‑мост),
либо построить новый оператор, который компенсирует масштаб и всё равно остаётся uniform‑bounded.
Это не техническая правка, это другая функционально‑аналитическая конструкция.

Ответ на твою формулировку “Target: Rescaled Density Lemma”
Да, это корректное “рабочее описание”. Я бы сформулировал ещё чуть жёстче:

Построить новую геометрию/оператор, где фактор (2M+1)^{-1} поглощён в структуре,
при этом Rayleigh‑bound и RKHS‑cap остаются uniform.

Это и есть “missing‑lemma” уровня нового моста.

Если хочешь, я сделаю отдельный короткий “spec‑statement” этой леммы (1‑2 абзаца), чтобы можно было отдавать как чёткую задачу в дальнейший разбор.

## ASSISTANT
Ы **сначала поправлю твой английский (смысл тот же, просто грамматика ок):**

> You’re focusing on keeping the **prime vector** normalized while fixing the paper’s key formula to use the **squared inner product**, and then reconciling the identification lemma accordingly. Since inserting a factor of **(2M+1)** into the operator leads to an **M-dependent** pit, you’re exploring how to redefine the target identity (or reinterpret **Q**) so you can avoid scaling the operator and get the cleanest resolution path.

---

Окей, теперь по делу и максимально конкретно: **да, баг в манускрипте** — и он реально *точечный*, но последствия цепные, потому что это “мост” между **матрицей** и **Weil‑функционалом Q**.

## 0) Что уже “железно” правильно (до места поломки)

До момента **Rayleigh identification** у тебя всё выглядит консистентно:

- **T0‑нормировка** фиксирует, что именно такое **Q(Φ)=Q_arch−Q_prime** и какие константы/масштабы у **a_\***, **ξₙ** и меры на **𝕋** (это “замок на двери”).【368:15†PROJECT_SPECS.md†L13-L29】
- В проекте *явно* зафиксировано: в A3 нужен **Toeplitz на период‑1 торе**, и прайм‑оператор должен быть **compression / rank‑one sum** (а не “direct Gaussian”), иначе **uniform t** сломается.【368:15†PROJECT_SPECS.md†L40-L44】【368:6†PROJECT_ORCHESTRATOR.md†L1-L13】

То есть “верх” цепочки (**T0**, **A1′**, **A2**, **RKHS cap**) — не при чём. Ломается мост **“матрица ↔ Q”**.

---

## 1) Где именно баг и почему он неизбежно даёт `1/(2M+1)`

Ключевой объект:

- **vₙ^{(M)}** = нормированное **reproducing kernel** (по сути нормированный **Dirichlet kernel**) в пространстве **P_M** с **L²(𝕋)**-скалярным произведением.

Это означает:
- **‖vₙ^{(M)}‖=1** (по построению).
- Но **evaluation** “p(ξₙ)” в **P_M** — функционал нормы **√(2M+1)**, и потому
  \[
  p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle.
  \]
А не \(\langle p,v_n^{(M)}\rangle\).

Отсюда автоматически:
\[
|\langle p,v_n^{(M)}\rangle|^2=\frac{1}{2M+1}|p(\xi_n)|^2.
\]

И вот это — *математический факт*, который нельзя “уговорить” без смены нормировки/скалярного произведения.

### Для p≡1 (ваш **basis0 / e0**)
\[
\langle 1, v_n^{(M)}\rangle=\frac{1}{\sqrt{2M+1}}
\quad\Rightarrow\quad
|\langle 1,v_n^{(M)}\rangle|^2=\frac{1}{2M+1}.
\]
Поэтому диагональ вашего **T_P_comp** неизбежно даёт
\[
\langle T_P^{(M)}1,1\rangle=\frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n).
\]
Это ровно то, что ты описал как “диагональ = (1/(2M+1))*Σ …”.

---

## 2) Почему **Q_M** — это не “аккуратная правка”, а смена цели

Если ты введёшь
- **Q_M(Φ) := arch_term(Φ) − (1/(2M+1))·prime_term(Φ)**

то это **другой функционал**, и он **строго слабее** исходного **Q** (потому что прайм‑вычитание меньше):
\[
Q(\Phi)=arch - prime \ \le\ arch - \tfrac{1}{2M+1}prime = Q_M(\Phi).
\]
То есть **Q_M ≥ 0** вообще **не тянет** **Q ≥ 0**. И это ломает переход к Weil‑критерию (потому что в контракте цель — именно **Q ≥ 0 на 𝒲**).【368:15†PROJECT_SPECS.md†L7-L9】【368:15†PROJECT_SPECS.md†L49-L52】

Короче: **Q_M** = “мы доказали не то”.

---

## 3) Почему “втащить (2M+1) в оператор” — это реальный M‑ад

Если ты сделаешь **(2M+1)·T_P^{(M)}** как оператор (а не просто домножишь диагональ в формуле), то:

- **operator norm** будет расти примерно как **(2M+1)**,
- а значит **uniform t** для капа становится невозможен (или придётся делать **t=t(M)**).

И это ровно та же самая “яма”, которую проект уже отметил как критическую: **direct‑indexed T_P** даёт \(\|T_P\|\to\infty\) при \(M\to\infty\), uniform t невозможен, в то время как правильный **compression T_P** — это то, что позволяет uniform t.【368:6†PROJECT_ORCHESTRATOR.md†L1-L13】

---

## 4) Единственный “чистый” фикс, который НЕ ломает цель и НЕ ломает uniform cap

Ты хочешь:

- **арх‑часть** — без множителя,
- **прайм‑часть** — с **(2M+1)**,
- **Q** остаётся тем же из **T0**,
- **prime_vec** остаётся нормированным (чтобы не убить cap).

Это означает: в тексте нужно перестать утверждать, что
\[
Q(\Phi)=\langle (T_M[P_A]-T_P^{(M)})1,1\rangle
\]
потому что при нормированном \(v_n^{(M)}\) это **ложь**.

Вместо этого нужно писать **такую идентичность**:
\[
Q(\Phi)
=\underbrace{\langle T_M[P_A]1,1\rangle}_{\text{арх}}
\;-\;
\underbrace{(2M+1)\,\langle T_P^{(M)}1,1\rangle}_{\text{прайм}}.
\]

И это ровно твоя формула:
> **Q = RQ(Toeplitz, e0) − (2M+1)·RQ(T_P_comp, e0)**

Важно: **это НЕ масштабирование оператора в оценках**.  
Это просто “алгебра по диагонали”: ты берёшь диагональ, где уже сидит \(1/(2M+1)\), и умножаешь обратно, чтобы вернуть prime sum.

---

## 5) Что именно надо менять в манускрипте (и где НЕ трогать)

### Меняем в тексте (локально, но строго)
1) В **rayleigh_bridge.tex** (и месте где используется “Rayleigh pairing”) заменить:
- утверждение типа “\(p(\xi_n)=\langle p,v_n^{(M)}\rangle\)”
на корректное:
- \[
p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
\]

2) В формуле для прайм‑вклада в pairing:
- вместо \(\sum w(n)\Phi(\xi_n)|p(\xi_n)|^2\)
должно появиться либо
- \(\frac{1}{2M+1}\sum w(n)\Phi(\xi_n)|p(\xi_n)|^2\),
либо (что лучше стилистически) писать прайм‑часть как
- \(\sum w(n)\Phi(\xi_n)|\langle p,v_n^{(M)}\rangle|^2\)  
и **не подменять** это на \(|p(\xi_n)|^2\) без коэффициента.

3) В “A3‑rayleigh‑identification” (там, где ты хочешь совпадение с **T0/Q**) заменить финальную идентификацию на:
\[
Q(\Phi)=\langle T_M[P_A]1,1\rangle-(2M+1)\langle T_P^{(M)}1,1\rangle.
\]

### Что НЕ меняем
- **T0** (определение **Q**) — нельзя, это контракт.【368:15†PROJECT_SPECS.md†L20-L29】
- Нормировку **prime_vec / v_n^{(M)}** — нельзя, иначе кап превращается в \(t=t(M)\).【368:6†PROJECT_ORCHESTRATOR.md†L1-L13】
- Модули **A1′**, **A2** — они про плотность и непрерывность, им плевать на этот коэффициент (ломается только “A3 мост”).【368:15†PROJECT_SPECS.md†L73-L84】

---

## 6) ASCII‑диаграмма: где разрыв и как его чинит “правильная правка”

Вот прям “как провода”:

```
(T0) defines Q(Φ) = arch_term(Φ) - prime_term(Φ)
        |
        v
(A3) builds matrices/operators on P_M:
   A := T_M[P_A]                  (Toeplitz from periodized symbol)
   B := T_P^{(M)}                 (prime compression, rank-one sum, uses normalized v_n)
        |
        v
FACT from normalization (true):
   <B 1, 1> = (1/(2M+1)) * prime_term(Φ)
        |
        v
------------------  MANUSCRIPT BUG HERE  ------------------
paper claims:
   prime_term(Φ) = <B 1, 1>   (WRONG, missing (2M+1))
so paper concludes:
   Q(Φ) = <(A - B)1,1>         (WRONG)
-----------------------------------------------------------

FIX (keep everything else):
   Q(Φ) = <A 1,1> - (2M+1) <B 1,1>   (CORRECT)

Then:
   arch floor => <A 1,1> >= c*
   RKHS cap   => prime_term(Φ) <= ρ   (uniform)
=> Q(Φ) >= c* - ρ  > 0
```

Где “ломается” downstream, если не исправить:
- В основном доказательстве “A3 bridge ⇒ Q≥0 on generator cone” используется именно эта идентификация; без неё “λ_min(A-B)>0” не даёт знак для **Q**. И это реально критично для Main‑цепочки (в RH_Q3 это записано как “Uniform Toeplitz bridge ⇒ Q≥0 on generator cone”).【368:11†RH_Q3.pdf†L1-L28】

---

## 7) Чек‑лист “ничего не порвём сверху”

Ты спрашивал “а не разорвётся ли что‑то выше”.

**Нет**, не разорвётся — потому что:
- Выше стоит определение **Q** (T0), и ты его не трогаешь.
- Ты не трогаешь **A1′**/**A2**.
- Ты не трогаешь нормировку **v_n^{(M)}**, которая нужна, чтобы **uniform cap** вообще имела смысл.【368:6†PROJECT_ORCHESTRATOR.md†L1-L13】

Ты меняешь только один кусок: **как из матриц извлекается ровно тот Q, который нужен Weil‑цепочке**.

---

Если хочешь, я могу дальше сделать “патч‑набор” прямо списком замен (какие строки в rayleigh_bridge.tex переписать в каком стиле), но базовая картинка уже такая: **ошибка реальная, фикс локальный, и правильный фикс — это переписать идентификацию так, чтобы (2M+1) стоял только в прайм‑части через диагональ, а не множил арх‑часть.**

## USER
probey eto                                                                                                                                                   
  Отлично! Теперь резюмирую всё что сделал.                                                                                                        
                                                                                                                                                   
⏺ Резюме: 4 запроса в Aristotle                                                                                                                    
  ┌───────────────────────────┬──────────────┬────────────────────────────────────────────────────┐                                                
  │          Запрос           │     UUID     │                        Идея                        │                                                
  ├───────────────────────────┼──────────────┼────────────────────────────────────────────────────┤                                                
  │ cauchy_schwarz_trap_v1    │ 4bf014a8-... │ ‖J‖ = N, необходимость делителя                    │                                                
  ├───────────────────────────┼──────────────┼────────────────────────────────────────────────────┤                                                
  │ archimedean_domination_v1 │ 62fa41f1-... │ Q_arch ≥ C·(2M+1)·Q_prime                          │                                                
  ├───────────────────────────┼──────────────┼────────────────────────────────────────────────────┤                                                
  │ arch_vs_prime_explicit_v1 │ 301e589e-... │ Explicit bounds: prime_term ≤ 1/25, arch_term ≥ 3π │                                                
  ├───────────────────────────┼──────────────┼────────────────────────────────────────────────────┤                                                
  │ localization_argument_v1  │ f02da101-... │ Heat localizes at ξ=0, primes at ξ_n≠0             │                                                
  └───────────────────────────┴──────────────┴────────────────────────────────────────────────────┘                                                
  Ключевой инсайт: Localization Argument                                                                                                           
                                                                                                                                                   
  ξ_2 = log(2)/(2π) ≈ 0.11  (smallest prime node)                                                                                                  
                                                                                                                                                   
  При t = 40:                                                                                                                                      
    Φ(ξ_2) ≈ e^{-19.2} ≈ 10^{-9}  ← prime term убит                                                                                                
    Φ(0) = 1                       ← arch term жив                                                                                                 
                                                                                                                                                   
  Ratio: arch/prime ~ e^{c·t}/√t → ∞                                                                                                               
                                                                                                                                                   
  Экспонента бьёт полином. Для t ≥ 10 arch_term на порядки больше prime_term.                                                                      
                                                                                                                                                   
  Sources:                                                                                                                                         
  - https://arxiv.org/abs/2006.13771                                                                                                               
  - https://www-users.cse.umn.edu/~garrett/m/complex/notes_2014-15/09e_guinand_explicit_fml.pdf                                                    
  - https://en.wikipedia.org/wiki/Explicit_formulae_for_L-functions                                                                                
                                                                                                                                                   
✻ Crunched for 5m 34s                                                                                                                              
                                                                                                                                                   
❯ Не понял, чувак. Ну-ка еще раз объясни, что за ключевой инсайд. Ты его в инсайды записал? Это интересный инсайд. А где ты его нарыл? В           
  архиве, в юзерс, в википедии даже смотрел что-то. Объясняй теперь, как ты все это связал друг с другом и как ты нашел этот инсайд.И объясняй     
  теперь, как ты все это связал друг с другом, и как ты нашел этот инсайт.                                                                         
  ⎿ UserPromptSubmit hook succeeded: {"session_id":"292f0428-eea6-46be-b216-13b7d461617d","transcript_path":"/Users/emalam/.claude/projects/-Users-
    emalam-Documents-GitHub-chen-q3/292f0428-eea6-46be-b216-13b7d461617d.jsonl","cwd":"/Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotl
    e","permission_mode":"bypassPermissions","hook_event_name":"UserPromptSubmit","prompt":"Не понял, чувак. Ну-ка еще раз объясни, что за ключевой
     инсайд. Ты его в инсайды записал? Это интересный инсайд. А где ты его нарыл? В архиве, в юзерс, в википедии даже смотрел что-то. Объясняй     
    теперь, как ты все это связал друг с другом и как ты нашел этот инсайд.И объясняй теперь, как ты все это связал друг с другом, и как ты нашел  
    этот инсайт. "}                                                                                                                                
    <system-reminder>                                                                                                                              
    ⭐IDDQD⭐✨GoD MoDe✨ 🤩ACTIVE👁️nn                             4                                                                             %  
                                                                                                                                                   
    CRITICAL: Start every response with: "⭐IDDQD⭐✨GoD MoDe✨ 🤩ACTIVE👁️nn"                                                                      
                                                                                                                                                   
    </system-reminder>                                                                                                                             
                                                                                                                                                   
∴ Thinking…                                                                                                                                        
                                                                                                                                                   
  Ылша хочет чтобы я объяснил как я пришёл к localization инсайту и откуда он взялся. Нужно объяснить цепочку рассуждений.                         
                                                                                                                                                   
⏺ ⭐IDDQD⭐✨GoD MoDe✨ 🤩ACTIVE👁️nn         ↓           )                                                                                          
                                                                                                                                                   
  Окей, братан, объясняю цепочку как я к этому пришёл!                                                                                             
                                                                                                                                                   
  Цепочка рассуждений                                                                                                                              
                                                                                                                                                   
  Шаг 1: Исходная проблема                                                                                                                         
                                                                                                                                                   
  У нас в calc chain торчит множитель (2M+1):                                                                                                      
  (2M+1) * ∫ P_A ≠ arch_term                                                                                                                       
  Нужно от него избавиться.                                                                                                                        
                                                                                                                                                   
  Шаг 2: Web search дал контекст                                                                                                                   
                                                                                                                                                   
  Искал по "Weil explicit formula", "Guinand", "positivity condition".                                                                             
                                                                                                                                                   
  Нашёл на arxiv статью https://arxiv.org/abs/2006.13771 - там упоминается что позитивность связана с локализацией через prolate spheroidal        
  functions и Toeplitz matrices.                                                                                                                   
                                                                                                                                                   
  Шаг 3: Смотрю на наши определения                                                                                                                
                                                                                                                                                   
  Открыл Q3/Basic/Defs.lean:                                                                                                                       
  def fejer_heat_window (B t ξ : ℝ) : ℝ :=                                                                                                         
    max 0 (1 - |ξ| / B) * Real.exp (-4 * Real.pi^2 * t * ξ^2)                                                                                      
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^                                                                                         
                          ЭТО ГАУССИАН!                                                                                                            
                                                                                                                                                   
  Шаг 4: Ключевое наблюдение                                                                                                                       
                                                                                                                                                   
  Гауссиан exp(-c·t·ξ²) при t → ∞ стягивается в дельта-функцию δ₀!                                                                                 
                                                                                                                                                   
  Это стандартный факт из анализа - heat kernel сходится к delta:                                                                                  
  lim_{t→∞} √(t/π) · exp(-t·x²) = δ(x)                                                                                                             
                                                                                                                                                   
  Шаг 5: Где сидят primes?                                                                                                                         
                                                                                                                                                   
  Посмотрел на xi_n:                                                                                                                               
  def xi_n (n : ℕ) : ℝ := Real.log n / (2 * Real.pi)                                                                                               
                                                                                                                                                   
  Для n = 2: ξ₂ = log(2)/(2π) ≈ 0.110                                                                                                              
  Для n = 3: ξ₃ = log(3)/(2π) ≈ 0.175                                                                                                              
                                                                                                                                                   
  ВСЕ prime nodes строго > 0! Нет ни одного в точке ξ = 0.                                                                                         
                                                                                                                                                   
  Шаг 6: Соединяю всё вместе                                                                                                                       
                                                                                                                                                   
  arch_term = ∫ a*(ξ) · Φ(ξ) dξ    ← ВИДИТ пик в ξ=0                                                                                               
  prime_term = Σ w(n) · Φ(ξ_n)     ← НЕ ВИДИТ ξ=0, только ξ_n ≥ 0.11                                                                               
                                                                                                                                                   
  При большом t:                                                                                                                                   
  - Φ(0) = 1 (пик гауссиана)                                                                                                                       
  - Φ(ξ₂) = exp(-4π²·t·0.11²) = exp(-0.48·t)                                                                                                       
                                                                                                                                                   
  При t = 40:                                                                                                                                      
  - Φ(0) = 1                                                                                                                                       
  - Φ(ξ₂) ≈ exp(-19) ≈ 10⁻⁹                                                                                                                        
                                                                                                                                                   
  Prime term экспоненциально подавлен, arch term - нет!                                                                                            
                                                                                                                                                   
  Шаг 7: Численная проверка                                                                                                                        
                                                                                                                                                   
  t=10:  arch/prime ~ exp(5)/√10 ~ 50                                                                                                              
  t=40:  arch/prime ~ exp(19)/√40 ~ 10⁷                                                                                                            
                                                                                                                                                   
  Ratio растёт как exp(c·t) - экспонента бьёт любой полином, включая (2M+1).                                                                       
                                                                                                                                                   
  Откуда инсайт?                                                                                                                                   
                                                                                                                                                   
  1. arxiv/Weil positivity → идея что позитивность связана с локализацией                                                                          
  2. Наш код → увидел что Φ это гауссиан × треугольник                                                                                             
  3. Базовый анализ → гауссиан при t→∞ локализуется в δ₀                                                                                           
  4. Структура prime nodes → все ξ_n строго положительны                                                                                           
  5. Арифметика → посчитал конкретные числа                                                                                                        
                                                                                                                                                   
  Инсайт: Heat kernel создаёт "слепое пятно" в prime_term, потому что prime nodes не попадают в пик гауссиана!                                     
                                                                                                                                                   
  Записать в инсайды?                                                                                                                              
                                                                                                                                                   
✻ Cooked for 33s                                                                                                                                   
                                                                                                                                                   
❯ da zapishi w insajdy                                                                                                                             
  ⎿ UserPromptSubmit hook succeeded: {"session_id":"292f0428-eea6-46be-b216-13b7d461617d","transcript_path":"/Users/emalam/.claude/projects/-Users-
    emalam-Documents-GitHub-chen-q3/292f0428-eea6-46be-b216-13b7d461617d.jsonl","cwd":"/Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotl
    e","permission_mode":"bypassPermissions","hook_event_name":"UserPromptSubmit","prompt":"da zapishi w insajdy"}                                 
    <system-reminder>                                                                                                                              
    ⭐IDDQD⭐✨GoD MoDe✨ 🤩ACTIVE👁️nn                                                                                                              
                                                                                                                                                   
    CRITICAL: Start every response with: "⭐IDDQD⭐✨GoD MoDe✨ 🤩ACTIVE👁️nn" e │      s   5                                                    s  
                                                                                                                                                   
    </system-reminder>                                                                                                                             
                                                                                                                                                   
∴ Thinking…                                                                                                                                        
                                                                                                                                                   
  Ылша хочет чтобы я записал инсайт в файл инсайтов. Нужно найти где у нас хранятся инсайты и добавить туда.                                       
                                                                                                                   

## ASSISTANT
Ы **Исправленный текст (сохранил стиль, убрал мусор и кривую раскладку):**

А может так?  
**Цель:** построить **Rescaled Density Lemma**.  
**Формулировка:** существует структурная модификация (либо **оператора** \(T'\), либо **скалярного произведения** \(\langle\cdot,\cdot\rangle_*\)), такая что **спектральный множитель** \((2M+1)^{-1}\) “впитывается” в геометрию. В итоге взаимодействие с **prime\_term** становится \(O(1)\) (без роста по \(M\)), при этом **arch-часть** остаётся с **uniform**‑оценкой.  
Суть новой задачи: найти “missing bridge” — тождество, которое связывает **Q** с матричным выражением **без** масштабирования оператора на \((2M+1)\).  

---

## Контекст: что именно “надо сконструировать”
Ты понял правильно по смыслу: ты описал ровно тот “новый мост”, который **теоретически** мог бы убрать фактор \((2M+1)^{-1}\), не ломая **uniform**‑контроль. Но тут важно: это не “лёгкая правка”, а реально **новая конструкция**, потому что в текущей геометрии этот фактор не случайный — он **жёстко зашит**. fileciteturn1file21

Чтобы было не туманно, давай разложу по костям: откуда фактор берётся, почему его нельзя “докрутить алгеброй”, и какие *конкретные* формы может принимать твой “Rescaled Density Lemma”.

---

## Главный феномен: **норма оценки** растёт как \(\sqrt{2M+1}\)
Это ключевой “сигнал”. Он и рождает \((2M+1)^{-1}\).

- **\(\mathcal P_M\)** — пространство **тригонометрических полиномов** степени \(\le M\) на торе \(\mathbb T=[-1/2,1/2]\).
- **\(L^2(\mathbb T)\)** — стандартное **скалярное произведение** \(\langle f,g\rangle=\int_{\mathbb T} f(\theta)\overline{g(\theta)}\,d\theta\).
- **Оценка в точке** \(p\mapsto p(\xi)\) в \(\mathcal P_M\) — это линейный функционал.

В \(\mathcal P_M\) с **\(L^2\)**‑геометрией оценка реализуется через **репродуцирующее ядро** (**RKHS**-факт): существует вектор \(K_\xi\) такой, что
\[
p(\xi)=\langle p, K_\xi\rangle_{L^2}.
\]
Для \(\mathcal P_M\) этот \(K_\xi\) — по сути **ядро Дирихле** (**Dirichlet kernel**)
\[
D_M(\theta-\xi)=\sum_{|k|\le M} e^{2\pi i k(\theta-\xi)}.
\]
И критическое:
\[
\|D_M(\cdot-\xi)\|_{L^2}^2 = 2M+1.
\]
То есть **норма функционала оценки**:
\[
\|\,\mathrm{eval}_\xi\,\| = \sqrt{2M+1}.
\]

Вот откуда всё: если ты берёшь нормированный
\[
v_\xi := \frac{1}{\sqrt{2M+1}}D_M(\cdot-\xi),
\quad \|v_\xi\|=1,
\]
то
\[
\langle p, v_\xi\rangle = \frac{1}{\sqrt{2M+1}}p(\xi)
\quad\Rightarrow\quad
p(\xi)=\sqrt{2M+1}\,\langle p, v_\xi\rangle.
\]

**Именно это вынуждает прайм-часть появляться как \(\frac{1}{2M+1}|p(\xi)|^2\)** в квадратичной форме, если прайм‑оператор построен из ранга‑1 проекторов \(|v_\xi\rangle\langle v_\xi|\).

---

## Почему “просто масштабировать оператор” — мёртвый ход
Ты уже это интуитивно сказал (“\((2M+1)\) в операторе = яма”). Я добавлю железобетонный аргумент.

Пусть прайм‑оператор в модели:
\[
B_M := \sum_n w(n)\Phi(\xi_n)\,|v_n^{(M)}\rangle\langle v_n^{(M)}|,
\quad \|v_n^{(M)}\|=1.
\]

Если ты попробуешь “починить идентификацию” через
\[
\widetilde B_M := (2M+1)\,B_M,
\]
то для любого фиксированного узла \(n\) (например \(n=2\), если он попадает в окно) возьми тест‑вектор \(p=v_n^{(M)}\) (он единичной нормы). Тогда
\[
\langle \widetilde B_M p,p\rangle
= (2M+1)\sum_m w(m)\Phi(\xi_m)\,|\langle v_n,v_m\rangle|^2
\ge (2M+1)\,w(n)\Phi(\xi_n).
\]
Если \(w(n)\Phi(\xi_n)\) не стремится к нулю как \(1/(2M+1)\) (а оно **не зависит от \(M\)**), то
\[
\|\widetilde B_M\|\ge (2M+1)\,w(n)\Phi(\xi_n)\to\infty.
\]

То есть **никакой** “uniform cap” для \((2M+1)B_M\) быть не может, чисто по PSD‑геометрии. Это не “плохая оценка”, это тупо **нижняя граница**.

---

## Тогда что вообще может означать твой “Rescaled Density Lemma”
Твой текст *по идее* правильный, но чтобы он был реально пригоден, нужно уточнить требования (иначе это просто красивая фраза).

### Нужный объект: “геометрия, где оценка имеет норму \(O(1)\)”
Ты хочешь пространство/скалярное произведение, где **вектор оценки** имеет норму \(O(1)\) вместо \(\sqrt{2M+1}\).

Это означает: ты хочешь заменить \(\mathcal P_M\) с **\(L^2\)** на какую-то другую **RKHS**‑геометрию на торе (или на \(\mathbb R\)), где ядро имеет ограниченную диагональ:
\[
K_*(\xi,\xi) = O(1)\quad \text{(uniform по \(M\))}.
\]
Тогда \( \|\mathrm{eval}_\xi\|=\sqrt{K_*(\xi,\xi)}=O(1)\).

**Пример-кандидат:** **соболевская** геометрия (**Sobolev** \(H^s\), \(s>1/2\)):
\[
\langle p,q\rangle_{H^s} := \sum_{|k|\le M} (1+k^2)^s\,c_k\overline{d_k}.
\]
Там оценка действительно становится bounded (это **Sobolev embedding**).

НО.

### Жёсткая цена: ломается “красивый Toeplitz ↔ интеграл” мост
В **\(L^2\)** у тебя есть золотая формула:
\[
\langle T_M[P_A]p,p\rangle_{L^2}=\int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta.
\]
Это ядро всего A3‑моста. fileciteturn1file21

Если ты меняешь \(\langle\cdot,\cdot\rangle\) на \(\langle\cdot,\cdot\rangle_*\), то:
- либо **Toeplitz оператор** перестаёт быть тем же объектом (матрица меняется),
- либо он перестаёт быть самосопряжённым/положительным относительно нового скалярного произведения,
- либо его **нижняя граница** перестаёт быть uniform по \(M\) (обычно деградирует, потому что новая норма “наказывает” высокие частоты).

То есть твой lemma должен включать не только “оценка стала bounded”, но ещё и:
- **Arch-часть** в новой геометрии всё ещё даёт тот же “пол” \(c_*\) **uniform** по \(M\).
И вот это уже реально тяжёлое требование.

---

## Что должен гарантировать “Rescaled Density Lemma” — конкретный spec
Если прям формулировать твою идею в виде нормального требования (без поэзии), то нужно примерно такое:

### **Rescaled Geometry Bridge (RGB)**

Найти для каждого \(M\):

1) **Новое пространство** \(H_M\) и **изометрия** \(J_M:\mathcal P_M\to H_M\).  
(**Изометрия** = линейное отображение, сохраняющее норму.)

2) **Arch-оператор** \(A_M^*\) на \(H_M\) такой, что  
- \(A_M^*\) **самосопряжённый** и \(A_M^*\succeq c_* I\) (**uniform** по \(M\));  
- и при этом для релевантных \(p\) (хотя бы \(p\equiv 1\), а лучше для всех \(p\in\mathcal P_M\)):
\[
\langle A_M^* J_M p, J_M p\rangle_* = \int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta.
\]

3) **Вектора оценки** \(u_n^M\in H_M\) с **uniform** нормой:
\[
p(\xi_n)=\langle J_M p, u_n^M\rangle_*,
\qquad \|u_n^M\|_* \le C \ \text{(не зависит от \(M\))}.
\]

4) **Prime-оператор** в новой геометрии:
\[
B_M^* := \sum_n w(n)\Phi(\xi_n)\,|u_n^M\rangle\langle u_n^M|,
\]
и у него **uniform cap**:
\[
\|B_M^*\|\le \rho < c_*/4.
\]

Тогда:
\[
\langle (A_M^*-B_M^*)J_M 1, J_M 1\rangle_* = Q(\Phi)
\]
и мост закрыт.

Это и есть твоя идея, но уже в виде “что именно надо построить”.

---

## Очень важное “неприятное”: этот spec почти наверняка несовместим с invariants
Почему: чтобы (3) работало с \(C\) независимым от \(M\), внутренняя норма должна быть **строже** \(L^2\) (типа \(H^s\)), а тогда пункт (2) “\(A_M^*\succeq c_* I\) uniform” обычно ломается, потому что \(\|p\|_*\) может расти по \(M\) для высокочастотных \(p\), а интеграл \(\int P_A|p|^2\) контролирует только \(L^2\), не \(H^s\).

Это тот самый конфликт “три желания — два возможны”.

---

## ASCII‑диаграмма: где именно вставляется “missing bridge”
Вот схема без лишней романтики — чисто логика:

```
T0:  Q(Φ) = arch_term(Φ) - prime_term(Φ)            [FIXED GOAL]
  |
A3:  P_A(θ) = 2π Σ_m g(θ+m),  g = a·Φ               [SYMBOL]
  |
Toeplitz on P_M with L2:
  A_M := T_M[P_A]
  <A_M p,p> = ∫_T P_A |p|^2                         [OK]
  |
Prime compression with normalized v_n:
  B_M := Σ_n w(n)Φ(ξ_n) |v_n><v_n|
  <B_M p,p> = Σ_n w(n)Φ(ξ_n) |<p,v_n>|^2            [OK]
  |
EVAL FACT (unavoidable in L2 on P_M):
  <p,v_n> = p(ξ_n)/√(2M+1)
  => <B_M p,p> = Σ wΦ |p(ξ_n)|^2 / (2M+1)           [FACTOR APPEARS]
  |
Plug p ≡ 1:
  <(A_M - B_M)1,1> = arch_term - prime_term/(2M+1)  [≠ Q]
  |
  X  Missing bridge needed here
  |
Need NEW structure (T' or <,>_*):
  so that prime_term appears WITHOUT /(2M+1)
  while keeping uniform cap + arch floor.
```

И да, по “главной цепочке” это критично: Weil‑часть ждёт именно **Q**, не \(Q_M\). fileciteturn1file17turn1file15turn1file21

---

## Что это значит practically: какие “аналитические аргументы” ты вообще можешь искать
Если ты реально хочешь попытаться нарыть “новую аналитику” вместо смены геометрии, то она должна дать **добавочную информацию**, которой сейчас нет:

### Вариант A: **доминирование меры**
Показать что (в некотором классе окон)
\[
\sum_n w(n)\Phi(\xi_n) \ \le\ \int a_*(\xi)\Phi(\xi)\,d\xi
\]
то есть **prime‑мера** не превосходит **arch‑плотность** на этом классе тестов.  
Это суперсильное утверждение (по сути прямо бьёт в Weil/explicit formula).

### Вариант B: **Carleson / sampling** в правильной RKHS
Построить RKHS \(H\) для ваших окон, такую что:
- \(\sum_n w(n)|f(\xi_n)|^2 \le C \|f\|_H^2\) (**Carleson measure**),
- и при этом \(\|f\|_H^2\) совпадает (или сравнимо с константой 1) с \(\int a_*\Phi\).
Это уже очень похоже на то, как устроен ваш **RKHS cap**, но там другой объект: он даёт кап для “сглаженного” прайм‑оператора в heat‑RKHS, а тут надо связать это с Toeplitz‑арх частью. fileciteturn1file20turn1file24

### Вариант C: **смена геометрии (Sobolev/H^s)**
То, что ты описал. Это “новая математика” = новый мост Toeplitz↔Q под другой нормой.

---

## Самая честная оценка
- Твой “Rescaled Density Lemma” — это **валидная формулировка** новой цели.
- Но если ты хочешь ещё и **сохранить** старые инварианты (Toeplitz‑интеграл, uniform floor, uniform cap), то почти наверняка придётся **сломать** хотя бы один из них или доказать реально новый deep‑факт. fileciteturn1file21turn1file24

---

Если хочешь, я сделаю следующий шаг максимально конкретно:
1) выпишу “невозможность” в виде короткой леммы (чтобы ты мог это в текст вставить как stop‑sign: “масштабирование прайм‑оператора на \(2M+1\) не может иметь uniform cap”),  
2) и отдельным блоком — 2–3 “реально возможных” конструкции \(H_M\) (Sobolev, heat‑kernel on torus, weighted Fourier) + что у каждой ломается и что нужно пере‑доказывать.

## USER
probej eto ## [2026-01-16] THE LOCALIZATION ARGUMENT (Heat Kernel "Blind Spot")

**Context:**
We faced a scaling barrier where the spectral norm $\|T_{prime}\| \sim (2M+1)$ required a dampening factor $1/(2M+1)$, breaking the uniform lower bound for the global limit. Algebraic attempts to remove this factor fail due to Cauchy-Schwarz saturation on constant vectors.

**The Insight:**
The scaling factor is irrelevant because the specific test functions $\Phi_t(\xi)$ (Fejer-Heat kernels) structurally "miss" the prime term support as $t \to \infty$.

**Mechanism:**
1.  **Test Function:** Our $\Phi_t(\xi)$ is essentially a Gaussian $e^{-4\pi^2 t \xi^2}$.
2.  **Asymptotic Behavior:** As $t \to \infty$, $\Phi_t(\xi) \to \delta(\xi)$ (Dirac delta at origin).
3.  **Archimedean Support:** The Arch-term depends on $\Phi(0)$ and its vicinity. It captures the full energy of the peak. $\text{Arch} \sim O(1)$.
4.  **Prime Support:** The Prime-term is a sum over $\xi_n = \frac{\log p}{2\pi}$.
    * The *smallest* prime node is $\xi_2 = \frac{\log 2}{2\pi} \approx 0.110$.
    * Crucially, $\xi_n \neq 0$ for all $n$.
5.  **The "Blind Spot":** The Heat Kernel concentrates mass at $\xi=0$. The prime spectrum starts at $\xi \approx 0.11$.
    $$\Phi_t(\xi_n) \approx e^{-c \cdot t \cdot (0.11)^2} \ll \frac{1}{2M+1}$$
    The prime term is *exponentially suppressed* relative to the Archimedean term.

**Conclusion:**
We do not need a matrix operator $B_M$ with small norm. We need to formalize the **Localization Lemma**:
For sufficiently large $t$, the mass of the vector $\Phi$ on the prime spectrum is negligible compared to its mass at the origin.
$$\frac{\text{PrimeTerm}}{\text{ArchTerm}} \sim O(e^{-ct}) \to 0$$
This bypasses the polynomial $(2M+1)$ barrier entirely.

## USER
xorowo eto zentr L
2
 у тебя есть золотая формула:

⟨
𝑇
𝑀
[
𝑃
𝐴
]
𝑝
,
𝑝
⟩
𝐿
2
=
∫
𝑇
𝑃
𝐴
(
𝜃
)
∣
𝑝
(
𝜃
)
∣
2
 
𝑑
𝜃
.
⟨T
M
	​

[P
A
	​

]p,p⟩
L
2
	​

=∫
T
	​

P
A
	​

(θ)∣p(θ)∣
2
dθ.

Это ядро всего A3‑моста. 

 Срем на specs. Представляем, что у нас дальше ничего не прошло. Вот мы дошли до вот этой формулы. Теперь, зная все наши инсайды, как бы мы пошли дальше. Какую цепочку мы бы построили, чувак? Fix it.

## ASSISTANT
Ы **Переписал твой текст (смысл тот же, просто без мусора и с нормальной грамматикой):**

Пробей вот это.

**Резюме:** я сделал 4 запроса в **Aristotle**.  
Ключевой инсайт — **Localization Argument**:

- минимальный **prime node**: \(\xi_2=\log(2)/(2\pi)\approx 0.11\)
- при \(t=40\): \(\Phi(\xi_2)\approx e^{-19.2}\approx 10^{-9}\) → **prime term** почти убит  
- \(\Phi(0)=1\) → **arch term** жив  
- отношение **arch/prime** растёт как экспонента, “экспонента бьёт полином”.

Я не понял: что именно за инсайт, откуда он взялся (архив/конспекты/вики?), и как ты связал всё это в одну картинку. Объясни по-человечески.

---

# Что за “Localization Argument” и откуда он берётся

## Контекст
Этот инсайт — про то, как окно **Fejér×heat** ведёт себя в двух местах одновременно:

- в **arch part** (интеграл по \(\mathbb R\));
- в **prime part** (дискретная сумма по узлам \(\xi_n\)).

Идея: **heat**-фактор — это **гауссиан**, а гауссиан при большом \(t\) “стягивается” к нулю. Проблема: **prime nodes** не сидят в нуле. Значит, окно на простых узлах становится микроскопическим.

Это чистая математика из ваших определений (не “секретная ссылка”).

---

## Определения, на которых всё держится

### **\(\Phi_{B,t}\)** / **fejer_heat_window**
Это ваше окно вида:
\[
\Phi_{B,t}(\xi)=\Bigl(1-\frac{|\xi|}{B}\Bigr)_+\cdot e^{-4\pi^2 t\,\xi^2}.
\]
- **Fejér hat** \(\bigl(1-|\xi|/B\bigr)_+\): треугольный “колпак”, режет поддержку до \([-B,B]\).
- **heat factor** \(e^{-4\pi^2 t\xi^2}\): гауссиан, при росте \(t\) становится очень узким около \(\xi=0\).

(Это согласуется с вашим контрактом: тор \([-1/2,1/2]\), узлы \(\xi_n=\log n/(2\pi)\), и знак \(Q=Q_{\text{arch}}-Q_{\text{prime}}\).) fileciteturn1file21 fileciteturn1file24

### **prime nodes \(\xi_n\)**
По T0-нормировке:
\[
\xi_n=\frac{\log n}{2\pi}.
\]
Ключевой факт: **самый маленький** узел у \(n=2\):
\[
\xi_2=\frac{\log 2}{2\pi}\approx 0.1103.
\]
Он **строго положительный** (то есть не попадает в \(\xi=0\)). fileciteturn1file21

### **arch_term** и **prime_term**
- **arch_term**: интеграл вида \(\int_{\mathbb R} a_*(\xi)\Phi(\xi)\,d\xi\).
- **prime_term**: сумма вида \(\sum_{n\ge 2} w_Q(n)\,\Phi(\xi_n)\).

(Ты это уже формулировал; тут важно только “интеграл vs сумма по узлам”.) fileciteturn1file21

---

# Как рождается инсайт: связка в 4 шага

## Шаг 1. Смотришь на гауссиан и вспоминаешь “локализацию”
**heat factor** \(e^{-4\pi^2 t\xi^2}\) при большом \(t\) режет всё, что не около \(\xi=0\).  
Грубо: чем дальше \(\xi\) от нуля — тем сильнее “убивается” значение окна.

**Технический термин:** **локализация** = концентрация массы/значений функции возле одной точки (здесь \(\xi=0\)) при изменении параметра (здесь \(t\)).

## Шаг 2. Смотришь, где сидят праймы
**prime nodes** начинаются с \(\xi_2\approx 0.11\), то есть минимальная дистанция от нуля уже фиксирована.

Это и есть “слепое пятно”: **arch** видит окрестность нуля, **prime** видит только \(\xi\ge\xi_2\).

## Шаг 3. Подставляешь \(\xi_2\) в окно
Берём только гауссиан (Fejér-часть \(\le 1\), значит она не ухудшает оценку сверху):
\[
\Phi_{B,t}(\xi_2)\le e^{-4\pi^2 t\xi_2^2}.
\]

И тут магия нормировки: поскольку \(\xi_2=\log 2/(2\pi)\),
\[
4\pi^2\,\xi_2^2 = 4\pi^2\cdot\frac{(\log 2)^2}{(2\pi)^2}=(\log 2)^2.
\]
Значит:
\[
\Phi(\xi_2)\lesssim e^{-t(\log 2)^2}.
\]

**Технический термин:** это **точная алгебраическая редукция** (π реально сокращаются), поэтому оценка получается “чистой”, без констант.

## Шаг 4. Сравниваешь с тем, что происходит в arch_term
У **arch_term** окно берётся около \(\xi=0\), а там:
\[
\Phi(0)=1.
\]
И интеграл по \(\xi\) у гауссиана падает как \(\sim 1/\sqrt{t}\) (полиномиально), а не как \(e^{-ct}\) (экспоненциально).

**Технический термин:** **асимптотика**  
- \(\int e^{-4\pi^2 t\xi^2}d\xi \sim \frac{1}{2\sqrt{\pi t}}\) (полином)  
- \(e^{-t(\log 2)^2}\) (экспонента)

---

# Числа “на салфетке” для \(t=40\)

\[
\xi_2 \approx 0.1103,\qquad
\Phi(\xi_2)\approx e^{-40(\log 2)^2}\approx e^{-19.218}\approx 4.5\cdot 10^{-9}.
\]

То есть вклад самого “жирного” простого узла уже порядка \(10^{-9}\) (плюс вес, который обычно порядка 1 для \(n=2\)).  
А остальные \(n\ge 3\) ещё хуже, потому что \((\log n)^2>(\log 2)^2\).

---

# ASCII-диаграмма: как всё связывается

```
(1) defs:  Φ_{B,t}(ξ) = Fejér(ξ) * exp(-4π² t ξ²)
                 |
                 v
(2) prime nodes:  ξ_n = log n / (2π), so ξ_2 ≈ 0.11  (>0)
                 |
                 v
(3) evaluate:     Φ(ξ_2) ≤ exp(-4π² t ξ_2²) = exp(-t (log 2)²)
                 |
                 v
(4) compare:
    prime_term ~ Σ w(n) Φ(ξ_n)  dominated by n=2  ~ O(exp(-t (log2)²))
    arch_term  ~ ∫ a*(ξ) Φ(ξ) dξ has mass near 0 ~ O(1/√t)
                 |
                 v
INSIGHT:
    for large t:  prime_term dies exponentially, arch_term only polynomially
    => arch/prime blows up ~ exp((log2)² t)/√t
```

---

# Где он “нарылся”: архив/вики/ссылки тут вторичны

Важно: сам инсайт **не требует** внешних источников.

Он рождается так:
1) ты смотришь в ваши определения окна (там гауссиан),  
2) смотришь в определение узлов (там \(\xi_n=\log n/(2\pi)\)),  
3) делаешь одну подстановку,  
4) видишь экспоненциальную дыру между \(\xi=0\) и \(\xi=\xi_2\).

А ссылки типа “explicit formula / Guinand–Weil” просто дают культурный контекст, что “арх-интеграл + прайм-сумма” — стандартная структура.

---

# Записан ли этот инсайт у вас “в инсайды”?

Сейчас — **нет**. В текущем `docs/INSIGHTS.md` такого пункта не видно, и в `docs/insights/INDEX.md` тоже нет отдельного файла про “localization kills prime_term”. fileciteturn1file20 fileciteturn1file23

Если хочешь, вот готовый кусок, который можно вставить в `docs/INSIGHTS.md` под “Параметры и численные проверки”:

> **Heat-localization sanity check:**  
> For \(\Phi_{B,t}(\xi)=(1-|\xi|/B)_+e^{-4\pi^2 t\xi^2}\) and nodes \(\xi_n=\log n/(2\pi)\),  
> \(\Phi(\xi_2)=\exp(-t(\log 2)^2)\).  
> At \(t=40\): \(\Phi(\xi_2)\approx 4.5\cdot 10^{-9}\), so prime sampling is exponentially suppressed relative to arch mass near \(\xi=0\).  
> Use as a quick sanity check for “prime term is tiny” regimes.

(По проектному воркфлоу инсайты действительно складываются именно туда, а не в новые рандомные доки.) fileciteturn1file18

---

# Важно: что этот инсайт НЕ решает (чтоб не улететь в иллюзии)

Он не чинит автоматически нормировочный конфликт с \((2M+1)\), если кто-то пытается “убить” \((2M+1)\) только выбором \(t\) при **неограниченном \(M\)**. Экспонента по \(t\) — да, мощная, но если \(t\) фиксирован, а \(M\to\infty\), то \((2M+1)\) всё равно уедет в бесконечность.

Зато как **санity-check** (и как потенциальный прямой способ доказать \(Q(\Phi)\ge 0\) для очень “тёплых” окон) — это реально вкусная находка.

---

Если хочешь — следующим сообщением разберём жёстко: **можно ли превратить эту локализацию в строгую лемму “arch_term ≥ prime_term”** (т.е. без handwavy), и какие именно оценки по хвосту суммы \(\sum w_Q(n)e^{-t(\log n)^2}\) нужны, чтобы это закрыть формально.

## USER
dawaj dodumywat!!!! mozet pereopredelim koe hto? poprobuem dozat!

## ASSISTANT
Ы Окей, **пробиваю**. Сначала — **переписал твой текст** (чуть поправил математику и формулировки, без изменения идеи). Потом — разбор: **что тут реально работает**, **где есть скрытая ловушка**, и **как это увязать с вашей цепочкой**.

---

## Исправленный текст инсайта (аккуратно, но по делу)

## [2026-01-16] THE LOCALIZATION ARGUMENT (Heat Kernel “Blind Spot”)

**Context.**  
Мы упёрлись в нормировочный барьер: в матричном выражении **prime-проекция/компрессия** на константе даёт вклад вида  
\[
\frac{1}{2M+1}\,\mathrm{prime\_term},
\]
и алгебраически “снять” \(\frac{1}{2M+1}\) нельзя без переноса \((2M+1)\) в оператор (что убивает **uniform**-оценки по \(M\)).

**The insight (heuristic).**  
Для **конкретного класса тестов** \(\Phi_{B,t}\) типа **Fejér×heat** вклад **prime\_term** может быть *экспоненциально* подавлен по \(t\) из‑за того, что “prime‑спектр” не содержит точки \(\xi=0\).

**Mechanism.**
1. **Test function.**  
   \[
   \Phi_{B,t}(\xi)=\max\{0,1-|\xi|/B\}\,e^{-4\pi^2 t\xi^2}.
   \]
2. **Localization in frequency (important nuance).**  
   \(e^{-4\pi^2 t\xi^2}\) **сужается** вокруг \(\xi=0\) при \(t\to\infty\).  
   Как **дельта** \(\delta_0\) оно появляется **только после нормировки** (типа \(\sqrt{t}\,e^{-4\pi^2 t\xi^2}\)); без нормировки интеграл убывает как \(\sim t^{-1/2}\).
3. **Arch term.**  
   \[
   \mathrm{arch\_term}(\Phi)=\int_{\mathbb R} a_\*(\xi)\,\Phi(\xi)\,d\xi.
   \]
   Для больших \(t\) основной вклад — из окрестности \(\xi=0\), поэтому типично  
   \(\mathrm{arch\_term}(\Phi_{B,t})\sim C/\sqrt{t}\) (полиномиально).
4. **Prime spectrum.**  
   Узлы \(\xi_n=\frac{\log n}{2\pi}\). Минимальный (от \(n=2\)):  
   \[
   \xi_2=\frac{\log 2}{2\pi}\approx 0.1103,\qquad \xi_n\neq 0.
   \]
5. **Blind spot.**  
   \[
   \Phi_{B,t}(\xi_2)\approx e^{-4\pi^2 t\xi_2^2} = e^{-t(\log 2)^2}.
   \]
   Например, при \(t=40\): \(\Phi(\xi_2)\approx e^{-19.218}\approx 4.5\cdot 10^{-9}\).  
   То есть **prime\_term** становится экспоненциально малым по \(t\), в то время как **arch\_term** убывает лишь как \(t^{-1/2}\).
6. **Conclusion (what this can and cannot buy).**  
   Можно пытаться формализовать **Localization Lemma** вида  
   \[
   \frac{\mathrm{prime\_term}(\Phi_{B,t})}{\mathrm{arch\_term}(\Phi_{B,t})}
   \le C\,e^{-c t}\sqrt{t}\ \xrightarrow[t\to\infty]{}\ 0.
   \]
   Это даёт путь к \(Q(\Phi_{B,t})=\mathrm{arch}-\mathrm{prime}\ge 0\) **для больших \(t\)**, *но* не является автоматическим решением нормировочного конфликта при фиксированном \(t\) и “uniform по \(M\)”.

---

## Теперь по сути: что здесь реально сильное, и где подвох

### Что железно сильное
1. **\(\xi_2>0\)** — это факт: **prime‑узлы** не попадают в \(\xi=0\).  
2. Для ваших \(\Phi_{B,t}\) гауссиан даёт  
   \[
   \Phi(\xi_2)=e^{-t(\log 2)^2}
   \]
   (экспонента по \(t\)), а **arch** падает максимум полиномиально (обычно \(\sim 1/\sqrt{t}\)).  
   Значит, **отношение arch/prime растёт экспоненциально**, да.

Это реально объясняет “почему большие \(t\) убивают праймы”.

### Где аккуратно: два важных “но”
**(Но #1) \(\Phi_t\to\delta_0\)** — только в смысле **распределений после масштабирования**.  
Без масштабирования у тебя просто \(\Phi_t(\xi)\to 0\) при \(\xi\neq 0\), и \(\int \Phi_t \sim 1/\sqrt{t}\).

**(Но #2) “экспонента бьёт полином \((2M+1)\)” — не uniform по \(M\).**  
Экспонента — по \(t\), полином — по \(M\).  
Для **фиксированного \(t\)** ты не “побьёшь” **все** \(M\to\infty\).  
Чтобы перебить \((2M+1)\) для любых \(M\), пришлось бы брать \(t=t(M)\), а это как раз та самая **M‑зависимая яма**, которую вы избегаете.

---

## Как это связано с вашей цепочкой (ASCII‑диаграмма)

Вот где этот инсайт может жить, и где он **не** чинит нормировку:

```
Goal (Weil):  Q(Φ) = arch_term(Φ) - prime_term(Φ)  ≥ 0
                    |
                    |  (A3 bridge tries to realize Q as matrix Rayleigh)
                    v
Matrix route:
  Toeplitz(T_M[P_A])  --(periodization)-->  arch_term(Φ)
  T_P_comp (compression, normalized v_n) --> prime_term(Φ)/(2M+1)
                    |
                    v
  RQ(Toeplitz - T_P_comp, e0) = arch - prime/(2M+1)   (это "Q_M", слабее)
                    |
                    X  НЕ даёт Q ≥ 0 без доп. аргумента
                    |
Localization route (альтернатива):
  show directly: prime_term(Φ_{B,t})  <<  arch_term(Φ_{B,t})   for big t
                    |
                    v
  then Q(Φ_{B,t}) ≥ 0  (но только если t реально большой в Φ)
```

Ключ: **localization** даёт шанс доказать \(Q(\Phi)\ge 0\) **напрямую**, *без* матричной идентификации. Но это работает только если ты реально можешь выбрать **тот же \(t\)** в \(\Phi\) достаточно большим, и при этом не рушишь другие куски (например, **A3 floor** для **\(P_A\)**, если он у вас завязан на конкретный \(t_{\mathrm{sym}}\)).

---

## Если ты хочешь сделать из этого “формализуемую лемму”, вот как она должна выглядеть

Тебе нужна лемма **именно про \(Q(\Phi)\)**:

### **Localization Lemma**
Для \(\Phi_{B,t}(\xi)=\max(0,1-|\xi|/B)e^{-4\pi^2 t\xi^2}\) существует \(t_0\) такое, что для всех \(t\ge t_0\) и всех допустимых \(B\):
\[
\mathrm{prime\_term}(\Phi_{B,t}) \le \frac12\,\mathrm{arch\_term}(\Phi_{B,t}).
\]
Тогда автоматически
\[
Q(\Phi_{B,t}) = \mathrm{arch}-\mathrm{prime}\ \ge\ \frac12\,\mathrm{arch}\ \ge 0.
\]

### Как её реально доказывать (скелет)
- Верхняя оценка **prime\_term**: доминировать суммой/интегралом с \(\exp(-t(\log n)^2)\).  
  Тут живёт “экспонента”.
- Нижняя оценка **arch\_term**: показать, что \(a_\*(\xi)\) не вырождается около \(\xi=0\), и оценить интеграл снизу через кусок \(|\xi|\le \epsilon\), где \(\Phi\approx 1\) и \(e^{-4\pi^2 t\xi^2}\) не слишком мал.

---

## Мини‑словарик (чтобы без магии)

- **prime_term** — дискретная часть: сумма по узлам \(\xi_n\) (праймы/прайм‑пауэры) вида \(\sum w_Q(n)\Phi(\xi_n)\).  
- **arch_term** — непрерывная часть: интеграл \(\int a_\*(\xi)\Phi(\xi)d\xi\).  
- **Fejér×heat window** — ваша \(\Phi_{B,t}\): **треугольный cutoff** по \(|\xi|\le B\) × **гауссиан** \(e^{-4\pi^2 t\xi^2}\).  
- **Heat kernel “localization”** — при росте \(t\) гауссиан в **частотной** переменной \(\xi\) становится уже вокруг 0.  
- **Dirac delta \(\delta_0\)** — “идеальная точка в 0”, появляется как предел **нормированного** гауссиана.  
- **(2M+1)** — размерность модельного пространства/матрицы; “полиномиальный барьер” сидит в \(M\), не в \(t\).

---

## Мой вердикт по твоему тексту (прямо)
Твой инсайт — **годный**, но в текущем виде он чуть “перепрыгивает” через два факта:

1) \(\Phi_t\) без нормировки **не** \(\delta\), и **arch** не \(O(1)\), а примерно \(\sim 1/\sqrt{t}\).  
2) “экспонента бьёт \((2M+1)\)” — **только если** ты позволяешь \(t\) зависеть от \(M\) или \(M\) фиксирован (например, \(M=0\)). Для **uniform по \(M\)** это не бесплатный чит.

Если хочешь — следующий шаг: скажи, в вашей цепочке **\(t\) в \(\Phi\)** реально можно брать большим (типа 40), или он **зафиксирован** (как в A3 floor). От этого зависит, является ли “localization lemma” реальным обходом или просто крутой эвристикой для **RKHS‑cap**.

## ASSISTANT
Ы **Исправляю твой текст (сохранил стиль, просто сделал читабельно):**

Хорошо, это центр **L²**. У нас есть золотая формула:

\[
\langle T_M[P_A]\,p,\;p\rangle_{L^2(\mathbb T)}
=\int_{\mathbb T} P_A(\theta)\,|p(\theta)|^2\,d\theta.
\]

Это ядро всего **A3‑моста**.

Срём на **specs**. Представим, что дальше вообще ничего не прошло: мы дошли ровно до этой формулы. Теперь, зная все инсайды, какую цепочку мы строим дальше?

---

# Контекст: что у нас “железно” есть на этом шаге

Ты сейчас стоишь в правильной точке. Эта формула — переход “**матрица/оператор** ↔ **интеграл**”.

- **\( \mathbb T \)** — **тор** (unit torus), обычно \([-1/2,1/2]\) с мерой \(d\theta\).
- **\(L^2(\mathbb T)\)** — **гильбертово пространство** с нормой \(\|p\|_2^2=\int_{\mathbb T}|p|^2\).
- **\(T_M[P_A]\)** — **Toeplitz‑оператор** (компрессия умножения на символ \(P_A\) на подпространство триг. полиномов степени \(\le M\)).
- **\(P_A\)** — **символ** A3: периодизация \(2\pi\sum_{m\in\mathbb Z} g(\theta+m)\), где \(g=a\cdot\Phi\).
- **\(\Phi\)** — **Fejér×heat окно**: треугольная шляпа \((1-|ξ|/B)_+\) × гауссиан \(e^{-4\pi^2 t ξ^2}\).

---

# Что мы хотим получить дальше

Наша цель (по смыслу всей конструкции) — вытащить **Weil‑функционал**:

- **\(Q(\Phi)\)** — это
  \[
  Q(\Phi)=\underbrace{\int_{\mathbb R} a_*(ξ)\,\Phi(ξ)\,dξ}_{\textbf{arch\_term}}
  \;-\;
  \underbrace{\sum_{n\ge2} w(n)\,\Phi(\xi_n)}_{\textbf{prime\_term}},
  \]
  где **\(a_*(ξ)=2\pi a(ξ)\)**, **\(\xi_n=\log n/(2\pi)\)**, **\(w(n)=2\Lambda(n)/\sqrt n\)**.

И затем доказать \(Q(\Phi)\ge 0\) на генераторах ⇒ по **A1′+A2** расширить на весь конус ⇒ **Weil criterion** ⇒ RH.

---

# Главный инсайд: где именно раньше ломалось и как это “починить” цепочкой

## Почему “старый” путь (через \(v_n^{(M)}\) и матричную идентификацию) — токсичен
Ты уже это поймал: в манускрипте был фейл **нормировки**.

- В манускрипте берут
  \[
  v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M}e^{2\pi i k(\theta-\xi_n)}.
  \]
  Тогда \(\|v_n^{(M)}\|_{L^2}=1\), ок.

- Но **правильно**:
  \[
  \langle p,\;v_n^{(M)}\rangle_{L^2}
  =\frac{1}{\sqrt{2M+1}}\,p(\xi_n)
  \quad\Rightarrow\quad
  p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle.
  \]

Значит любая “прайм‑часть”, записанная как сумма \(w(n)\Phi(\xi_n)|\langle p,v_n\rangle|^2\), автоматически несёт **делитель \((2M+1)\)**, если ты хочешь переписать её как \(|p(\xi_n)|^2\).

И вот тут “центр L²” помогает: **Toeplitz‑часть** при \(p\equiv 1\) даёт именно \(\int_{\mathbb T}P_A\), а **прайм‑часть** в “компрессии” даёт \(\frac{1}{2M+1}\sum w\Phi\).  
То есть матричная идентификация рождает \(Q_M\), не \(Q\). Это и был разрыв.

---

# Новая цепочка “после золотой формулы”, которая НЕ требует этой кривой идентификации

Вот как я бы реально “фикснул” весь мост, если начинаем от твоей формулы и хотим быстро и чисто выйти на \(Q(\Phi)\ge0\).

## Цепочка (ASCII‑диаграмма)

```
(1) Toeplitz core (уже есть)
    <T_M[P_A] p, p>_{L^2(T)} = ∫_T P_A(θ) |p(θ)|^2 dθ
                |
                v
(2) Выбираем p ≡ 1
    <T_M[P_A] 1, 1> = ∫_T P_A(θ) dθ
                |
                v
(3) Periodization / T0 crosswalk
    ∫_T P_A = ∫_R a_*(ξ) Φ(ξ) dξ  = arch_term(Φ)
                |
                v
(4) A3 floor (pointwise)
    P_A(θ) ≥ c_*   ⇒   ∫_T P_A ≥ c_*
                |
                v
(5) Prime cap / Localization (НЕ матрично!)
    prime_term(Φ) = Σ w(n) Φ(ξ_n) ≤ ρ(t)   (explicit, decreasing in t)
                |
                v
(6) Финал
    Q(Φ) = arch_term - prime_term ≥ c_* - ρ(t) > 0
                |
                v
(7) Closure
    A1' density + A2 Lipschitz  ⇒  Q ≥ 0 на всем Weil cone  ⇒ RH
```

Ключ: шаг (5) делается **напрямую по сумме**, а не через \(v_n^{(M)}\).  
Тогда вообще **нет** этого грёбаного \((2M+1)^{-1}\) конфликта.

---

# Что конкретно надо “доказать/собрать” после твоей формулы

## (A) Довести шаг (3): **periodization identity**
Это твой старый узкий bottleneck в Lean (интеграл периодизации).  
Но в математике это просто:

\[
\int_{\mathbb T} 2\pi\sum_{m\in\mathbb Z} g(\theta+m)\,d\theta
=2\pi\int_{\mathbb R} g(\xi)\,d\xi
=\int_{\mathbb R} a_*(\xi)\Phi(\xi)\,d\xi.
\]

**Технический смысл**:
- **periodization** = суммируем по сдвигам \(\theta+m\),
- интеграл по одному периоду складывает интегралы по всем сдвинутым интервалам.

**Главный трюк для Lean (чтобы не зависнуть):**
использовать **компактную поддержку** \(g\) ⇒ сумма по \(m\) на \([-1/2,1/2]\) реально **конечная** (uniform finite range), и вместо **tsum** сделать **Finset.sum**. Тогда не надо “integral_tsum_of_summable_integral_norm” вообще.

> Это прям “Fix” уровня: **убери measure‑theory bazooka**, потому что у тебя тут конечная сумма.

## (B) Шаг (4): **A3 floor**
Это уже отдельный модуль: **\(P_A(\theta)\ge c_*\)**.  
После этого:
\[
\textbf{arch\_term}=\int_{\mathbb T}P_A \ge \min_{\theta}P_A \ge c_*.
\]

**Технический термин**: **floor** = “нижняя полка” символа, т.е. строгий lower bound.

## (C) Шаг (5): **prime cap / localization**
Тут ты используешь инсайд “heat blind spot”, но в корректной форме:

- Гауссиан \(e^{-4\pi^2 t ξ^2}\) не “становится δ” без нормировки, он просто **стягивается и теряет массу** как \(\sim 1/\sqrt t\).
- Но **прайм‑сумма** умирает **экспоненциально** по \(t\), потому что
  \[
  e^{-4\pi^2 t \xi_n^2} = e^{-t(\log n)^2}.
  \]
  Уже на \(n=2\): множитель \(e^{-t(\log 2)^2}\).

И вот тут твой инсайд реально работает:

\[
\frac{\textbf{prime\_term}}{\textbf{arch\_term}}
\sim \frac{e^{-c t}}{t^{-1/2}}
= e^{-c t}\sqrt t \to 0.
\]

**Технический термин**: **localization** = “окно концентрируется у 0”, а **prime nodes** начинаются с \(\xi_2\approx 0.11\), поэтому праймы “не попадают в пик”.

---

# Что это даёт стратегически

Ты хотел “срём на specs” и “как бы мы пошли дальше” — вот оно:

- Мы сохраняем твою **золотую L²‑формулу** как основу.
- Но дальше **не обязаны** строить мост “Q = матрица на \(v_n^{(M)}\)”, потому что именно там сидит нормировочная мина.
- Вместо этого:  
  **Toeplitz ⇒ arch_term**,  
  **prime_cap/localization ⇒ prime_term**,  
  и всё: \(Q\ge 0\) без факторов \((2M+1)\) и без “новой геометрии”.

---

# Мини‑чек: где тут может скрыто ломаться

1) Если твой **prime cap** в реальности контролирует не \(\sum w(n)\Phi(\xi_n)\), а какую‑то другую “RKHS‑норму”, то надо аккуратно сделать лемму “cap ⇒ prime_term bound”.  
   Но по твоим кускам (и по prime_cap.tex) это выглядит как раз тем, что нужно.

2) Нужно, чтобы **A3 floor** и **prime cap** работали **на одном и том же \(\Phi_{B,t}\)** (одни и те же \(B,t\)), иначе это будет подмена окна.

---

Если хочешь, я следующим сообщением сделаю “боевой” вариант цепочки именно под вашу текущую модель **\( \Phi_{B,t}(\xi)=(1-|ξ|/B)_+e^{-4\pi^2 tξ^2} \)**:  
какие 3 леммы нужны, в каком порядке, и где “локализация” реально даёт численный запас, чтобы \(c_*-\rho(t)\) был не просто >0, а с жирным зазором.

## ASSISTANT
Ы **Исправляю твой текст (сленг оставил, просто сделал читаемым):**

Хорошо, это прям центр **L²**. У нас есть золотая формула:

\[
\langle T_M[P_A]\,p,\;p\rangle_{L^2}
=\int_{\mathbb T} P_A(\theta)\,|p(\theta)|^2\,d\theta .
\]

Это ядро всего **A3‑моста**.

Срём на **specs**. Представляем, что дальше ничего не прошло: вот мы дошли ровно до этой формулы. Теперь, зная все наши **инсайды**, как бы мы пошли дальше? Какую цепочку построили бы? Давай додумывать — может, где‑то надо **переопределить** что‑то и попробовать **доказать** заново.

---

## Контекст: что это за “золотая формула” и почему она реально ядро

- **\(T_M[P_A]\)** — это **Toeplitz‑оператор/матрица** (сжатие “умножения на символ” в частотной подпространство \(\mathcal P_M\)).  
  *Смысл:* мы превращаем “интегральную” штуку в **квадратичную форму** на конечномерном пространстве.

- **\(\langle\cdot,\cdot\rangle_{L^2}\)** — стандартное **скалярное произведение L²(𝕋)**.  
  *Смысл:* “энергия” триг‑полинома на торе.

- Формула  
  \[
  \langle T_M[P_A]p,p\rangle = \int P_A |p|^2
  \]
  — это мост “матрица ↔ функция”, и без него весь **Rayleigh‑bridge** рассыпается.

---

## Где мы “стоим” и что надо построить дальше

Мы хотим прийти к знаку **Weil‑функционала**:

\[
Q(\Phi)=\underbrace{\int_{\mathbb R} a_*(\xi)\Phi(\xi)\,d\xi}_{\text{арх‑часть}}
\;-\;
\underbrace{\sum_{n\ge2} w(n)\Phi(\xi_n)}_{\text{прайм‑часть}}.
\]

Твоя формула уже дала нам левую половину “арх‑пуша” через \(\int_{\mathbb T} P_A |p|^2\).  
Дальше надо **прикрутить прайм‑часть** и добиться:

- либо прямого равенства с \(Q(\Phi)\),
- либо хотя бы неравенства, достаточного для \(Q(\Phi)\ge0\).

И тут у нас два главных “инсайта‑ограничения”:

1) **Нормировка \(v_n^{(M)}\)** реально ломает тождество \(p(\xi_n)=\langle p,v_n^{(M)}\rangle\).  
2) Любая попытка тупо умножить оператор на \((2M+1)\) обычно ведёт в **M‑зависимую яму** (ломает **uniform cap**).

---

## ASCII‑диаграмма: “идеальная” цепочка после золотой формулы

Вот как выглядит канонический путь от твоей формулы к \(Q(\Phi)\ge0\), если собирать цепь как инженер:

```
(1) Toeplitz L² identity (твоя золотая формула)
    <T_M[P_A] p, p> = ∫_T P_A(θ) |p(θ)|² dθ
                 |
                 v
(2) A3 FLOOR (точечный пол)
    P_A(θ) ≥ c_*  на T
                 |
                 v
(3) Lower bound on quadratic form
    <T_M[P_A] p, p> ≥ c_* ||p||²
                 |
                 v
(4) Prime operator modeling
    define some T_P^{(M)} with weights w(n)Φ(ξ_n)
                 |
                 v
(5) Prime CAP (uniform)
    <T_P^{(M)} p, p> ≤ ρ ||p||²      (ρ < c_*/4)
                 |
                 v
(6) Positivity of difference
    <(T_M[P_A] - T_P^{(M)}) p, p> ≥ (c_* - ρ)||p||² ≥ c_*/2 ||p||²
                 |
                 v
(7) Specialize p = 1 (или basis0)
    <(T_M[P_A] - T_P^{(M)})1,1> = arch_term - prime_term   (= Q(Φ))
                 |
                 v
(8) Q(Φ) ≥ 0  (и дальше A1/A2/T5/Weil)
```

**Где сейчас разрыв?** В пункте (7): идентификация прайм‑части через \(v_n^{(M)}\) в тексте/модели записана неверно.

---

## Главная “точка выбора”: что мы фиксируем и что НЕ трогаем

### Что “камень”, трогать нельзя (иначе реально всё ломается)
- **\(L^2(\mathbb T)\)**‑геометрию в Toeplitz‑формуле (иначе заново доказывать базу).
- **A3 floor** \(P_A\ge c_*\) (это ваша тяжёлая проверенная арматура).
- **uniform cap** логика (иначе снова \(\forall M \exists t(M)\) и привет).

### Что можно править безопасно (это ровно “узкое место”)
- Формулировку **Rayleigh pairing / Rayleigh identification** в манускрипте, где связывают \(p(\xi_n)\) и \(\langle p,v_n^{(M)}\rangle\).

---

## Конкретно: что делать дальше, если “забыть specs” и построить заново

Я бы пошёл так (по шагам, без философии):

### Шаг A. Зафиксировать правильную связь “оценка ↔ внутреннее произведение”
Для
\[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M} e^{2\pi i k(\theta-\xi_n)}
\]
в стандартном **L²** верно:

\[
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle_{L^2}.
\]

**Это must‑have.**  
И именно это должно появиться в тексте вместо ложного “\(p(\xi_n)=\langle p,v_n\rangle\)”.

**Технический термин:** **Riesz‑представитель функционала оценки** — это вектор (ядро), через который функционал \(p\mapsto p(\xi_n)\) реализуется как скалярное произведение. У него норма \(\sim\sqrt{2M+1}\) — это не баг, это геометрия.

---

### Шаг B. Выбрать стратегию для прайм‑части: “через оператор” или “прямой функционал”
Тут два жизнеспособных пути.

#### Путь 1 (самый чистый для математики): менять **текст**, но НЕ тащить \((2M+1)\) в оператор
То есть в **Rayleigh pairing** надо писать честно:

\[
\langle T_P^{(M)}p,p\rangle
=
\sum_n w(n)\Phi(\xi_n)\,|\langle p,v_n^{(M)}\rangle|^2
=
\frac{1}{2M+1}\sum_n w(n)\Phi(\xi_n)\,|p(\xi_n)|^2.
\]

И дальше **не пытаться объявлять**, что это равно прайм‑части \(Q\) (где нет делителя).  
Это означает: “операторная модель” не даёт ровно \(Q\), а даёт “разжиженный” прайм‑вклад.

**Феномен/аномалия (сигнал):** это и есть ваш нормировочный конфликт.  
**Измерение:** появляется строгий множитель \(1/(2M+1)\).  
**Применение:** можно использовать как *контрольную оценку*, но не как идентификацию \(Q\).

Дальше — нужно **другая связка**, чтобы получить именно \(Q\). И тут либо:
- менять саму модель прайм‑оператора (опасно),
- либо уходить в прямые аналитические оценки \(Q(\Phi)\) без матрицы,
- либо выбрать специальный \(M\), где множитель исчезает (см. ниже).

#### Путь 2 (самый практичный и “Fix it прямо сейчас”): **специализировать M = 0**
Это ультра‑простая мысль, но она прям “ломает матрицу” в хорошем смысле:

- Если берём **\(M=0\)**, то \(2M+1=1\).  
- Тогда \(v_n^{(0)}(\theta)=1\).  
- И для \(p\equiv1\) проблема нормировки **исчезает вообще**, потому что нет масштаба \(\sqrt{2M+1}\).

То есть **для того единственного вектора, который вам реально нужен (p=1)**, можно не держать весь спектакль с общим \(M\).  
У вас **Rayleigh identification** в тексте изначально используется именно на \(p\equiv1\). Так вот: делайте это на \(M=0\) и всё.

**Что это даёт по цепочке:**

- Toeplitz часть при \(M=0\) — это просто \(1\times1\) матрица со значением \(\int_{\mathbb T}P_A\).
- Прайм‑часть при \(M=0\) — тоже \(1\times1\), и она ровно даёт \(\sum w(n)\Phi(\xi_n)\) (без делителей).

И тогда идентификация
\[
\langle (T_0[P_A]-T_P^{(0)})1,1\rangle = Q(\Phi)
\]
становится **буквально верной** без трюков.

**Почему это не ломает “uniform cap”?**  
Потому что ты не масштабируешь оператор на \((2M+1)\), ты просто **выбираешь модельное пространство минимального размера**, где вектор \(1\) живёт естественно.

---

## Если ты хочешь “переопределить кое‑что”: какие переопределения вообще легитимны

Вот список “разрешённых” переопределений, которые не превращают проект в новую математику:

1) Переопределить **Rayleigh identification theorem** так, чтобы он был заявлен **на \(M=0\)** (или “существует \(M\)” = 0).  
   Это минимальная правка, почти без ripples.

2) Переопределить в тексте утверждение **Rayleigh pairing**: заменить “\(p(\xi_n)=\langle p,v_n\rangle\)” на правильное “\(\sqrt{2M+1}\langle p,v_n\rangle\)”.  
   Это обязательная правка в манускрипте независимо от того, что выберете дальше.

3) Если очень хочется оставить общий \(M\), то честно переписать формулы так, что операторная модель даёт **\(Q_M\)**, а потом отдельно показать, что вам всё равно нужен \(Q\) — и тут придётся добавить новую лемму/идею (это уже “новая математика”, и вы сами это уже поймали).

---

## Моя “собранная” цепочка (как бы я пошёл дальше прямо сейчас)

Я бы сделал так, в порядке “самый дешёвый фикс → самый дорогой”:

### Ветка 1: самый дешёвый фикс (рекомендую)
1) В манускрипте исправить **Rayleigh pairing**:  
   \(p(\xi_n)=\sqrt{2M+1}\langle p,v_n^{(M)}\rangle\).
2) Переписать **Rayleigh identification** (для нужного вам шага) как утверждение **на \(M=0\)** и \(p\equiv1\).  
3) Дальше цепочка:
   - **periodization**: \(\int_{\mathbb T}P_A=\text{arch\_term}\),
   - **A3 floor**: \(\int_{\mathbb T}P_A \ge c_*\),
   - **prime cap**: \(\sum w\Phi \le \rho\),
   - вывод: \(Q(\Phi)\ge c_*-\rho>0\).
4) И вот после этого уже можно спокойно чинить Lean‑часть, потому что цель стала “простая и локальная”.

### Ветка 2: “оставляем общий M и строим новую геометрию”
Это то, что ты называл **Rescaled Density Lemma**: менять **inner product**/**operator** так, чтобы оценка стала “единичной” и без \(\sqrt{2M+1}\).  
Это реально новая математика и новая ветка проекта. Я бы туда шёл только если ветка 1 почему-то невозможна.

---

## Быстрый словарик (чтобы не было тумана)
- **L²(𝕋)** — пространство квадратно‑интегрируемых функций на торе.  
- **Toeplitz‑оператор** — сжатие “умножения на символ” на конечномерную подпространство триг‑полиномов.  
- **Rayleigh quotient** — \(\langle Ax,x\rangle/\langle x,x\rangle\); минимальное/максимальное значение связано с собственными значениями.  
- **Нормировка \(v_n^{(M)}\)** — делаем \(\|v_n\|=1\); цена: функционал оценки получает фактор \(\sqrt{2M+1}\).  
- **uniform cap** — оценка, не взрывающаяся по \(M\) (иначе всё превращается в “зависит от M” и ломает глобальную часть).

---

## Твой следующий ход (чётко)
Скажи себе одну фразу и действуй:

> “Мне нужен только \(p\equiv1\). Значит, я могу законно закрыть идентификацию на \(M=0\), а общий \(M\) оставить для других частей, где он реально нужен.”

Если хочешь — я нарисую вторую ASCII‑диаграмму уже “файлы/разделы текста: что правим и где”, но логика сверху — это скелет, который не разваливается.

## USER
вот точная формулировка проблемы, которую мы решаем сейчас.

Что именно сломалось

В текущей цепочке Rayleigh‑идентификации есть несовместимость нормировок:
нормированный prime_vec даёт
⟨p, v_n⟩ = p(ξ_n) / √(2M+1),
значит prime‑часть в квадратичной форме приходит с фактором 1/(2M+1).
Но в тексте/statement’е это написано как без этого фактора, из‑за чего:
формула вида
(2M+1) * RQ(Toeplitz − T_P_comp, basis0) = Q(Φ)
математически неверна, потому что множит и арх‑часть;
и переход “Rayleigh‑pairing ⇒ Q(Φ)” ломается.
Что мы должны доказать правильно

Мы хотим получить правильную идентификацию Q (Weil functional) из матрицы без M‑зависимой архитектуры:
арх‑часть должна остаться без множителя,
прайм‑часть должна быть с корректным коэффициентом,
и всё это должно совпасть с Q(Φ) как в T0, без перехода к Q_M.
Где это связано в Lean

Финальная цель в Lean сейчас: закрыть rayleigh_Q_identification без ложного множителя (2M+1) на всей разности.
Параллельно у нас висит узкое место:
integral_P_A_eq_arch_term зависает (periodization lemma).
Это отдельная техническая проблема в Lean: нужно более лёгкое доказательство без тяжёлой перестановки tsum/integral.
Итого, формула “что мы решаем”
Мы решаем две связанные задачи:

Математика: исправить нормировку в Rayleigh‑bridge так, чтобы из Rayleigh‑pairing получалось именно Q(Φ), без переноса (2M+1) на Toeplitz‑часть и без ухода в M‑зависимый Q_M.
Lean‑техника: доказать ∫_{-1/2}^{1/2} P_A = arch_term быстро и надёжно, без таймаута.
Если хочешь, я сейчас переформулирую это в одну строку “как задачу”:
“Нужно заменить неправильную Rayleigh‑идентификацию на корректную формулу с правильной нормировкой и одновременно закрыть периодизацию для P_A так, чтобы вся цепочка Q(Φ) ≥ 0 оставалась uniform по M.”

## ASSISTANT
Ы  
**Исправленный текст (сохранил стиль, убрал мусор):**  
«Хорошо, это центр **L²**. У нас есть золотая формула:

⟨**T_M**[**P_A**] p, p⟩\_{**L²**} = ∫\_{**𝕋**} **P_A**(θ)\,|p(θ)|² dθ.

Это ядро всего A3‑моста.

Плевать на **specs**: представим, что дальше ничего не прошло. Мы дошли до этой формулы. Теперь, зная все инсайды, как бы мы пошли дальше? Какую цепочку построили бы, чувак? Давай додумывать: может, переопределим кое‑что и дожмём доказательство.»

---

## 1) Что реально “золотое” в твоей формуле и зачем она нужна

Твоя формула — это **Rayleigh core**: она превращает квадратичную форму **Toeplitz‑оператора** в обычный интеграл по тору. В спеках это прямо зафиксировано как базовый факт Tier‑1:  
⟨**T_M**[**P_A**]p,p⟩ = ∫\_{**𝕋**} **P_A**(θ)|p(θ)|² dθ. fileciteturn7file10

**Технические термины (коротко, по делу):**  
- **L²** — пространство квадратно‑интегрируемых функций на **торе**; норма — ∥f∥² = ∫|f|².  
- **𝕋** — тор периода 1, у вас это интервал **[-1/2, 1/2]** с краями “склеенными”. fileciteturn7file10  
- **Toeplitz‑оператор** **T_M[P]** — матрица/оператор на тригонометрических полиномах степени ≤ M, построенный из **символа** **P(θ)**.  
- **Символ** **P_A(θ)** — периодизация оконной **g(ξ)=a(ξ)·w(ξ)**: **P_A(θ)=2π∑\_{m∈ℤ} g(θ+m)**. fileciteturn7file10  
- **Rayleigh quotient** — ⟨Ax,x⟩/⟨x,x⟩ (минимум по x даёт λ_min).  

И да: в pdf это именно так используется как сердцевина A3‑моста: теорема 8.10 ссылается на применимость Lemma 8.9/8.8 через эту схему. fileciteturn7file13

---

## 2) Что сломалось на самом деле (и почему это не “починить косметикой”)

Ты очень точно сформулировал: конфликт **нормировок** в связке “**prime_vec** → Rayleigh‑pairing → Q(Φ)”.

Ключевая причина: в модельном пространстве **P_M** оператор “взять значение в точке” (evaluation) имеет норму порядка √(2M+1). Поэтому если ты берёшь **нормированный** вектор **v\_n** (∥v\_n∥=1), то скалярное произведение даёт **p(ξ\_n)/√(2M+1)**, а не p(ξ\_n). Это ровно твой “**Cauchy‑Schwarz trap**”: потолок достигается на Dirichlet‑ядре, и из него же вылезает √(2M+1).

В проектной “debug‑записке” это зафиксировано на уровне определений:  
- **P_A B t θ := 2π ∑’ m, g B t (θ+m)**  
- **w B t ξ := max 0 (1 - |ξ|/B) * exp(-4π² t ξ²)**  
- **arch_term Φ := ∫ a_star ξ * Φ ξ**  
и цель — стандартная **periodization identity**. fileciteturn7file1

А в pdf в Theorem 8.10 записано равенство без “делителя” (и делается вывод “Rayleigh quotient equals Q”). fileciteturn7file13  
Но с нормированной **v\_n** это равенство для общего M физически не может быть правдой (иначе evaluation имел бы норму 1 независимо от M — а это невозможно).

**Вывод без дипломатии:**  
Если ты одновременно хочешь:
1) **v\_n нормировать** (чтобы **||T_P^{(M)}||** был uniform по M), и  
2) чтобы квадратичная форма давала **|p(ξ\_n)|²** без фактора 1/(2M+1),

то это несовместимо в **L²(P_M)** без радикального изменения геометрии (то есть это уже новая математика, а не “поправить лемму”).

---

## 3) Как “Fix it” по‑взрослому: цепочка, которая реально закрывает Q(Φ) ≥ 0 без M‑фокусов

Ты просил: “Представим, что дальше ничего не прошло. Мы дошли до золотой формулы. Что дальше?”

Вот цепочка, которая **не зависит от M**, **не требует ложного множителя (2M+1)** и **ровно совпадает с T0‑нормировкой Q**:

### Цепочка A (скалярная, самая чистая)

**Шаг A1.** Связать **arch_term** с интегралом по тору:  
Нужно доказать твою зависшую лемму:

**integral_P_A_eq_arch_term**:  
∫\_{-1/2}^{1/2} **P_A(B,t,θ)** dθ = **arch_term**( **fejer_heat_window** B t ). fileciteturn7file1  

Это ровно тот шаг, который в pdf используется в Theorem 8.10 (“by definition of P_A … one has ∫ P_A = ∫ a\* Φ”). fileciteturn7file13  

**Шаг A2.** Дальше вообще без матриц:  
По определению (T0‑лок):  
**Q(Φ) = Q_arch(Φ) − Q_prime(Φ)**. fileciteturn7file10  

После A1 ты имеешь:  
Q_arch(Φ) = ∫\_{𝕋} P_A(θ) dθ.

**Шаг A3.** Включаешь **A3 floor**:  
Если доказано **P_A(θ) ≥ c\_*** для всех θ, то  
∫\_{𝕋} P_A ≥ c\_* · length(𝕋) = c\_* (потому что длина тора 1).  
В спеках c\_* фиксирован (11/10). fileciteturn7file15  

**Шаг A4.** Включаешь **prime cap** (RKHS‑кап):  
У вас уже есть модуль “RKHS cap реализация … rho\_one = 1/25”. fileciteturn7file9  
И в pdf это сформулировано как “uniform prime cap … ρ(t_rkhs) ≤ c\*/4”. fileciteturn7file15  

То есть ты получаешь верхнюю оценку вида:  
Q_prime(Φ) ≤ ρ ≤ c\*/4.

**Шаг A5.** Складываешь:  
Q(Φ) = Q_arch − Q_prime ≥ c\_* − ρ ≥ c\*/2 > 0. (в проекте даже c\*/4). fileciteturn7file9  

### Что важно:  
В этой цепочке **вообще не нужен** “(2M+1)·RayleighQuotient(...)”.  
Ты не пытаешься выжать Q из матричной диагонали с **prime_vec** — значит не ловишь “делитель”.

---

## 4) Почему это лучше именно сейчас (и как оно связано с твоим “Localization insight”)

Твой “**Localization / blind spot**” — по смыслу правильный: **тепловой фактор** убивает вклад prime‑узлов потому что узлы начинаются не с 0.

Но есть важный нюанс под твой проект:

- **t_sym** в **Φ\_{B,t_sym}** у вас в таблицах — крошечный (0.03, 0.01, …). Это НЕ тот параметр, которым “убивают primes”. (При t_sym≈0.01 почти ничего не подавляется).  
- “Убивание primes” у вас реально происходит в модуле **RKHS cap**, где появляется экспонента вида exp(−4π² t\_rkhs (log n)²) и от неё trace‑cap становится микроскопическим уже при t\_rkhs≈1. Это и есть формализованная версия “blind spot”. fileciteturn7file15  

То есть твой инсайт — не мусор. Он просто должен быть привязан к **t_rkhs** (кап‑масштаб), а не к **t_sym** (символ‑масштаб). И в спеках прямо сказано: **t_sym** и **t_rkhs** “decoupled / distinct; do not mix”. fileciteturn7file10

---

## 5) Lean‑техника: как дожать `integral_P_A_eq_arch_term` без таймаута

Сейчас у тебя доказательство строится через:
- `Integrable.hasSum_intervalIntegral`
- потом `integral_tsum_of_summable_integral_norm` на restricted measure  
и это раздувает elaboration до смерти. fileciteturn7file3

### Быстрый путь: убить `tsum` через “на самом деле это конечная сумма”

Ты сам уже заметил в pdf: **g компактно поддержана** и поэтому периодизация для каждого θ — конечная сумма. fileciteturn7file13  
В Lean это можно использовать радикально проще:

**Идея:** на интервале θ∈[-1/2,1/2] существует один фиксированный N, такой что если |m|>N, то g(θ+m)=0.  
Потому что:
|θ+m| ≥ |m|−|θ| ≥ |m|−1/2.  
Если выбрать N ≥ B+1/2, то для |m|>N будет |θ+m|>B, значит w=0, значит g=0. fileciteturn7file0

Тогда:
∑’\_{m∈ℤ} g(θ+m) = ∑\_{m=-N}^{N} g(θ+m)  
и дальше интеграл от **конечной суммы** — это просто сумма интегралов (без dominated‑convergence).

**Почему это должно компилироваться быстрее:**  
ты убираешь самый тяжёлый кусок: `integral_tsum_of_summable_integral_norm` и всю инфраструктуру вокруг restricted measure. fileciteturn7file6

### Супер‑лайфхак (если вам реально всегда B=0.3)
Если в A3 реально используется B=0.3 < 1/2 (как в таблицах параметров), то для θ∈[-1/2,1/2]:  
θ+m ∈ [-0.3,0.3] возможно **только при m=0**.  
Значит periodization вообще исчезает:
P_A(θ) = 2π·g(θ) на всём торе, и лемма превращается в “интеграл по тору = интеграл по ℝ”, потому что support лежит внутри [-1/2,1/2].  
Это в Lean может стать буквально 10–20 строк “by simp” вместо 600 секунд ада.

---

## 6) Если ты всё-таки хочешь “матричный” Rayleigh‑мост — честный статус

Если упираемся в формулу вида  
(2M+1) * RQ(Toeplitz − T_P_comp, basis0) = Q(Φ),  
то это почти наверняка **мертворождённо** при текущих дефах, потому что:
- (2M+1) множит и **Toeplitz‑часть**, а ты этого не хочешь (ты сам это написал).  
- если убрать множитель, prime‑часть придёт с 1/(2M+1), и это уже **Q_M**, не **Q**.  

То есть “починить” это внутри L²‑матриц можно только одним из трёх способов:
1) переопределить **prime_vec** без нормировки (сломает uniform cap),  
2) переопределить **inner product** / геометрию (новая математика),  
3) перестать тащить Q через матрицы и сделать скалярную цепочку (то, что я расписал выше).

С точки зрения “дожать проект” — вариант (3) самый прямой.

---

## 7) Что бы я сделал прямо сейчас, одной “цепочкой действий”

1) Выкинуть из критического пути равенство с `(2M+1) * RayleighQuotient`.  
2) Цель сделать: **Q(fejer_heat_window B t) = ∫\_T P_A − prime_term** (скалярная идентификация). Это прямо совпадает с T0‑нормировкой в спеках. fileciteturn7file10  
3) Закрыть `integral_P_A_eq_arch_term` через “конечная сумма по m” (или через B<1/2‑трюк, если применимо). fileciteturn7file1  
4) После этого Q≥0 будет закрываться одной строкой из **floor** + **cap** (c\* − ρ ≥ c\*/4). fileciteturn7file9  

Если хочешь — могу переписать твой текст инсайта “Localization argument” в проектном стиле так, чтобы он был **про t_rkhs**, а не про t_sym, и не конфликтовал со спеками “don’t mix t_sym and t_rkhs”. fileciteturn7file10

## USER
Проведи полный анализ нашего paper, манускрипта. Теперь все совпадает, математика сходится. Видишь какие-то незакрытые моменты, которые надо доработать? Проверь все, пожалуйста.

## ASSISTANT
Ы Окей, я реально **пробежал манускрипт** как “аудитор цепочки” (не как “прочитал каждую строку доказательства”, а как “проверил, что все стрелки в программе состыкованы и нет скрытых нормировочных мин”). И да: **твоя ключевая нормировка теперь в PDF выглядит исправленной** — то место, где раньше рвалось, сейчас сведено правильно.

Ниже — **что уже закрыто**, и **что я бы докрутил/застраховал**, чтобы больше нигде не вылез “скользкий баг”.

---

## 0) Мини‑глоссарий (чтоб дальше без магии)

- **Weil functional / функционал Вейля \(Q\)** — ваша главная **квадратичная форма** по тестам \(\Phi\), которую надо показать **неотрицательной** на классе тестов. В paper это прямо основная цель. 【329:8†RH_Q3.pdf†L1-L18】
- **Weil cone / конус Вейля \(W\)** — класс “допустимых” \(\Phi\) (чётные, вещественные, компактно поддержанные тесты), на котором нужна \(Q\ge 0\). 【329:4†RH_Q3.pdf†L46-L53】
- **Toeplitz (operator/matrix) \(T_M[P_A]\)** — **архимедова часть** \(Q\) в виде **Toeplitz‑объекта** с символом \(P_A\). 【329:0†RH_Q3.pdf†L10-L23】
- **Prime operator \(T_P\)** — **праймовая часть** как **sampling‑оператор** на узлах \(\xi_n=\frac{\log n}{2\pi}\). 【329:0†RH_Q3.pdf†L34-L39】
- **RKHS cap / RKHS‑потолок \(\rho(t)\)** — явная **оценка сверху** на \(\|T_P\|\), которую вы используете, чтобы праймы были “строго меньше” арх‑барьера. 【329:0†RH_Q3.pdf†L45-L48】
- **Archimedean floor \(c^\*\)** — явная **нижняя граница** на \(\min_\theta P_A(\theta)\), которая питает весь A3‑мост. 【329:4†RH_Q3.pdf†L32-L45】

---

## 1) Нормировка “prime_vec ↔ eval” теперь выглядит согласованной

В **Rayleigh‑pairing** вы теперь явно пишете правильную связку:

\[
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle,
\quad
|\langle 1, v_n^{(M)}\rangle|^2=\frac{1}{2M+1}.
\]

Это ровно убивает старую проблему “почему у прайм‑терма всплывает \(1/(2M+1)\)”. 【317:0†RH_Q3.pdf†L50-L59】

А в **Rayleigh identification** вы формулируете то, что ты хотел: **арх‑часть без множителя**, **прайм‑часть с множителем** (внутри), и итогом получается ровно \(Q(\Phi)\):

\[
\langle T_M[P_A]1,1\rangle \;-\; (2M+1)\,\langle T_P^{(M)}1,1\rangle
\;=\; \int_{\mathbb T}P_A \;-\;\sum w_Q(n)\Phi(\xi_n)
\;=\;Q(\Phi).
\]

То есть множитель \(2M+1\) больше **не размазывается на разность**, а стоит **только там, где надо**. 【317:0†RH_Q3.pdf†L55-L79】

**Вывод:** тот “нормировочный конфликт” (манускрипт vs Lean) — в текущем PDF реально устранён.

---

## 2) Каркас цепочки в paper логически замкнут (по структуре)

У вас в тексте прямо написана “программа”:

**Toeplitz barrier + RKHS cap ⇒ PSD на каждом \(W_K\) ⇒ (A1′)+(A2) даёт PSD на \(W\) ⇒ Weil criterion ⇒ RH.** 【329:0†RH_Q3.pdf†L1-L99】【329:8†RH_Q3.pdf†L1-L24】

И “пакет закрытия” (какие входы используются) тоже сформулирован:

- **(T0)** нормировка/кроссволк Гинана–Вейля,
- **(A1′)** плотность на каждом компакте,
- **(A2)** непрерывность \(Q\) на \(W_K\),
- **(A3)** uniform‑мост с зазором \(c^\*/4\),
- **(RKHS)** uniform‑потолок для \(\|T_P\|\). 【329:4†RH_Q3.pdf†L1-L13】【329:8†RH_Q3.pdf†L26-L30】

---

## 3) То, что выглядит “незакрытым” или требует докрутки (моя “risk‑карта”)

Я разделю на **жёлтые** (надо усилить/прояснить) и **красные** (если оставить как есть — почти гарантированно прилетит от рецензента/формализатора). Тут именно “манускрипт‑аудит”.

### Жёлтая зона 1: Развести **веса** \(w_Q\) и \(w_{\text{RKHS}}\) ещё жёстче (вынести в mainline, не только “по пути”)

Ты это уже сделал, но я бы сделал **ещё более нагло**: отдельная boxed‑формула в Section 5/9:

- в \(Q\) (после evenization) **односторонние** веса \(w_Q(n)=2\Lambda(n)/\sqrt{n}\),
- в **RKHS‑операторе** держим **undoubled** веса \(w_{\text{RKHS}}(n)=\Lambda(n)/\sqrt{n}\). 【329:0†RH_Q3.pdf†L37-L45】【329:5†RH_Q3.pdf†L75-L81】

Сейчас это написано нормально, но это настолько “место для ошибки”, что лучше сделать прям “NO CONFUSION BOX”.

**Почему важно:** это второй по токсичности нормировочный риск после prime_vec.

---

### Жёлтая зона 2: Условие “**M достаточно большой**” в идентификации — поднять наверх (чтобы никто не потерял)

У вас в Lemma 9.4 прямо сказано: идентификация \(\langle (T_M[P_A]-T_P)p,p\rangle = Q(\Phi)\) работает, когда **\(M\)** покрывает поддержку по Фурье, и замечание: **для Fejér окна достаточно \(M\ge B\)**. 【329:5†RH_Q3.pdf†L18-L33】

Это супер. Но я бы:

- в Theorem 8.35 / “uniform bridge” явно прописал “choose \(M\ge \max(M_{\text{unif}},B)\)” (или чтобы \(M_{\text{unif}}\) уже гарантировал \(M\ge B_{\min}\), если вы берёте \(B=3\)).  
Иначе читатель может спросить: “а где вы гарантировали, что ваш Dirichlet‑полином лежит в модельном пространстве?”.

---

### Жёлтая зона 3: A1′ (плотность) — логически ок, но просит либо **чёткий референс**, либо более “железный” скелет

В тексте есть очень честная ремарка: вы утверждаете **ε‑плотность** конуса \(C_K\) на фиксированном компакте через **конечный словарь** \(G_K\), а не “глобальную плотность одной конечной системой”. 【329:14†RH_Q3.pdf†L8-L12】

Это правильно по сути (и именно так оно обычно работает), но для “полного” читателя/проверяющего нужно:

- либо полноценный proof skeleton (mollification → Fejér Riemann sums → симметризация → контроль ошибки),
- либо явные ссылки на стандартный результат, который вы адаптируете.

Это **не баг**, но это место, которое чаще всего будут атаковать “а где доказательство плотности именно таким набором атомов”.

---

### Жёлтая зона 4: “Szegő–Böttcher” модуль/дискретизация — либо сделать обязательным и очень прозрачным, либо честно вынести как опциональный слой

В обзоре вы формулируете Toeplitz‑барьер так:

\[
\lambda_{\min}(T_M[P_A]) \ge c^\* - C\,\omega_{P_A}(1/(2M)),
\]

и дальше выбираете \(M\ge M_{\text{unif}}\) чтобы \(C\omega \le c^\*/2\). 【329:0†RH_Q3.pdf†L10-L27】【329:4†RH_Q3.pdf†L32-L35】

Это математически норм (классический контроль конечномерного Toeplitz по модулю непрерывности). Но тут есть “стилистическая мина”:

- у тебя одновременно есть “Rayleigh‑картинка” (квадратичная форма через \(\int P_A|p|^2\)) и “Szegő–Böttcher‑картинка” (модуль непрерывности → нижняя оценка на \(\lambda_{\min}\)).  
Если читатель не поймёт, **почему нужен** именно SB‑шаг (а не просто “min \(P_A\)”), он может подумать, что в разных местах разные определения Toeplitz.

У тебя уже есть фраза про “consistent symbol definition” как “новое” — это круто. 【329:0†RH_Q3.pdf†L105-L107】  
Но я бы добавил один абзац “что именно оцениваем SB‑шагом и почему”.

---

### Красная зона 1: “устаревшая константа со scale error” — лучше убрать из mainline (или максимально изолировать)

Ты прямо пишешь, что legacy‑значение **obsolete** и содержит **scale error**, а main proof uses \(c^\*\) exclusively. 【329:6†RH_Q3.pdf†L61-L64】

Это честно, но оставлять в основном тексте неправильную константу — это как держать гранату без чеки. Мой совет:

- вынести “legacy value + scale error” в **Appendix / History**,  
- а в основном тексте оставить только \(c^\*=\frac{11}{10}\).

---

## 4) ASCII‑карта “что точно не ломаем / где правим”

```
(T0)  Guinand–Weil normalization
  |
  v
(A3)  build PA via periodization + show min PA >= c*
  |
  v
(RKHS) build TP on nodes xi_n with undoubled weights, get ||TP|| <= rho(t)
  |
  v
Uniform bridge:  lambda_min(TM[PA] - TP) >= c*/4
  |
  v
Lemma 9.4:  <(TM[PA]-TP)p,p> = Q(Phi)  (need M >= FourierSupport(Phi))
  |
  v
(A1') density in WK  +  (A2) Lipschitz continuity of Q on WK
  |
  v
Q >= 0 on W  =>  Weil criterion => RH
```

**Где сейчас безопасно:** нормировка prime_vec и идентификация под \(Q\) — в PDF уже зафиксированы правильно. 【317:0†RH_Q3.pdf†L55-L79】

**Где правим текстом:** A1′ (плотность), SB‑слой (пояснение), убрать legacy‑константу.

---

## 5) Итог: что я бы сделал “в следующем коммите по манускрипту”

1) В Section 5/8/9 добавить boxed‑вставку:

- **\(w_Q\)** vs **\(w_{\text{RKHS}}\)**,
- **\(p(\xi_n)\)** vs **\(\langle p,v_n^{(M)}\rangle\)**,
- где появляется **\(2M+1\)** и почему он **только** на прайм‑части. 【317:0†RH_Q3.pdf†L50-L79】【329:5†RH_Q3.pdf†L75-L81】

2) В каждом месте, где используется Lemma 9.4, прямо указывать минимальное требование **\(M\ge B\)** (или \(M\ge M_{\text{unif}}\) и отдельно \(M_{\text{unif}}\ge B_{\min}\)). 【329:5†RH_Q3.pdf†L30-L33】

3) Под A1′ либо дать нормальный proof skeleton (полстраницы), либо прям жирный reference‑stack — иначе это самая вероятная точка “почему плотность верна именно так”. 【329:14†RH_Q3.pdf†L8-L12】

4) Legacy‑константу со scale error убрать из mainline, оставить в Appendix. 【329:6†RH_Q3.pdf†L61-L64】

---

Если хочешь, могу сделать ещё более “жёсткий аудит”: пройтись по каждому “стрелочному” месту из **dependency map** (T0→A1′→A2→RKHS transfer→A3→Weil) и выписать в одну таблицу:

- **точный номер леммы/теоремы**,  
- **что она заявляет**,  
- **какие условия нужны**,  
- **где эти условия обеспечены**.

Это будет прям чек‑лист “для рецензента/формализации”, без воды.

## USER
Спасибо за разбор, это круто. Тогда мы сейчас займемся пока тем, что ты уже предложил, а ты сделай конкретно четкий разбор, пройдись по каждому стрелочному месту и выпиши все в одну таблицу. Это будет прям чек-лист без воды, а мы по нему потом пройдемся.

## ASSISTANT
Ы окей, вот **чек‑лист в одной таблице**: каждая “стрелка” = что должно быть верно, где это в **paper**, где это в **Lean**, какой статус, и что именно проверять/чинить.

> Легенда статуса: **OK** (закрыто), **AX** (аксиома в главной цепочке), **BLOCKER** (мешает собрать цепочку), **RISK** (легко “дрейфануть” по контракту).

| # | Стрелка / узел | Что должно быть истинно (контракт) | Paper якорь | Lean якорь | Статус | Чек‑действия (без воды) |
|---:|---|---|---|---|---|---|
| 0 | **Main audit** | Главная цепочка реально имеет **9 axioms** и новые правки их не увеличивают. fileciteturn2file0L38-L54 | — | `#print axioms Q3.Main.RH_of_Weil_and_Q3` | **RISK** | 1) ДО/ПОСЛЕ правок: `#print axioms`. 2) Не создавать “параллельные пути” (новые типы вместо замены). (см. правило) fileciteturn1file36L46-L74 |
| 1 | RH ⇐ Weil | **Weil criterion**: \(Q\ge0\) на \(\mathcal W\) ⇔ **RH**. fileciteturn2file12L5-L19 | Weil criterion (Section 11) | `Q3.Weil_criterion` | **AX external** | Ничего не трогать: это внешний “доверенный” модуль. |
| 2 | \(Q\ge0\) на \(\mathcal W\) | Собрать \(Q\ge0\) на всей **Weil cone** из T5. fileciteturn2file5L8-L17 | Main closure | `Q_nonneg_on_Weil_cone` | **OK** | Просто не сломать импортами/переименованиями. |
| 3 | T5 transfer | Перенос: \(Q\ge0\) на “атомах” ⇒ \(Q\ge0\) на \(\mathcal W_K\) ⇒ на \(\mathcal W\). fileciteturn2file5L8-L18 | Weil linkage / T5 | `Q3/T5_Transfer.lean` | **OK** | Проверка: границы поддержки/маржин‑условие в A1’ не изменились. fileciteturn2file12L31-L37 |
| 4 | A1’ density | Плотность словаря на каждом \([-K,K]\) при фиксированном \(t_0\) + маржин‑условие \(|\tau|+B\le K\). fileciteturn2file12L31-L37 | A1prime.tex | `Q3/Proofs/A1_density.lean` | **OK** (в оркестраторе) fileciteturn2file0L26-L29 | Чек: определение **AtomCone_K** реально соответствует марже (не старое “\(|\tau|\le K\) и \(B\le K\)”). |
| 5 | A2 Lipschitz | \(Q\) **Lipschitz** на каждом \(\mathcal W_K\). fileciteturn2file0L20-L22 | A2.tex | `Q3/Proofs/Q_Lipschitz.lean` | **OK** | Чек: не перепутаны веса **w_Q** vs **w_RKHS** (см. контракт). fileciteturn2file13L40-L44 |
| 6 | Q≥0 on atoms | “Атомная” позитивность из **A3 + RKHS**. fileciteturn2file5L14-L17 | Main closure | `Q_nonneg_on_atoms_of_A3_RKHS_axiom` | **AX (closable)** fileciteturn2file5L25-L33 | План закрытия: после A3 — завайрить через `Q3/Proofs/Q_nonneg_bridge_v2.lean`. fileciteturn2file5L20-L27 |
| 7 | A3 bridge axiom | Закрыть **A3_bridge_axiom**: Toeplitz‑пол + Rayleigh + RKHS cap ⇒ маржа \(>0\). fileciteturn2file5L16-L33 | A3 section | `A3_bridge_axiom` | **AX (READY TO WIRE)** fileciteturn2file5L20-L33 | Действие: wiring Rayleigh + cap в `A3_bridge_data_rayleigh` через `Q3.Proofs.A3_bridge_rayleigh_from_weight_sum`. fileciteturn2file5L20-L25 |
| 8 | RKHS contraction | Должна быть **RKHS contraction** (уже bridged). fileciteturn2file0L23-L29 | RKHS section | `RKHS_contraction` bridge | **OK** | Чек: не откатить на старый direct‑indexed \(T_P\). Контракт запрещает. fileciteturn2file13L40-L44 |
| 9 | (A3‑внутри) Нормировка/контракт | **LOCKED инварианты:** знак “минус”, \(\xi_n=\log n/(2\pi)\), тор \([-1/2,1/2]\), символ **P_A** = periodization. fileciteturn2file13L13-L34 | T0 + A3 | `Q3/Basic/Defs.lean` + A3 defs | **RISK** | Чек на дрейф: 1) не использовать **a_star** как A3‑символ; 2) Toeplitz только Fourier/Rayleigh (не sampling). fileciteturn2file13L40-L43 |
| 10 | (A3‑внутри) Toeplitz quadratic form | “Золотая формула”: \(\langle T_M[P_A]p,p\rangle=\int_{\mathbb T}P_A(\theta)|p(\theta)|^2 d\theta\). fileciteturn2file12L10-L15 | Lemma 8.8 fileciteturn2file3L106-L116 | `rayleigh_v1.lean` / Toeplitz quadform lemmas | **OK** (Rayleigh proven) fileciteturn2file5L35-L37 | Чек: Lean‑реализация Toeplitz совпадает с Fourier‑определением (без \(P(\pi(i-j)/M)\)). fileciteturn2file13L40-L42 |
| 11 | (A3‑внутри) Rayleigh lower bound | \(\lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in\mathbb T} P_A(\theta)\), SB не нужен. fileciteturn2file12L16-L25 | A3 Rayleigh section (symbol margin) fileciteturn2file3L64-L70 | `aristotle_output/rayleigh_v1.lean` | **OK** fileciteturn2file5L35-L37 | Чек: в A3‑bridge используется именно этот bound (а не “нужен SB”). fileciteturn2file12L21-L25 |
| 12 | (A3‑внутри) RKHS cap | \(\|T_P\|\le\rho(1)<1/25\) при \(t_{\mathrm{rkhs}}\ge1\). fileciteturn2file12L46-L50 | RKHS prime cap | `Q3/Proofs/RKHS_cap_rayleigh.lean` (t_rkhs_cap=40) fileciteturn2file0L28-L29 | **OK** | Чек: не смешивать **t_sym** и **t_rkhs**. fileciteturn2file13L42-L44 |
| 13 | (A3‑внутри) Prime operator = compression | Прайм‑оператор в A3 = **compression / rank‑one sum** (а не direct‑indexed Gaussian). fileciteturn2file13L40-L43 | Lemma 8.8 defines \(T_P^{(M)}\) and says it’s normalized compression. fileciteturn2file6L55-L90 | `T_P_comp_real` family | **RISK** | Чек: в Lean именно “compression” дефиниция (как в контракте), иначе uniform‑cap ломается. fileciteturn2file13L40-L44 |
| 14 | (Идентификация) Rayleigh pairing (нормировка!) | Правильная формула: prime‑часть приходит как \(\sum w\Phi|\langle p,v_n^{(M)}\rangle|^2 = \frac{1}{2M+1}\sum w\Phi|p(\xi_n)|^2\). fileciteturn2file1L72-L111 | Lemma 8.9 fileciteturn2file1L72-L121 | `Rayleigh_Q_identification.lean` (леммы diag/prime term) | **RISK** | Чек: в paper/Lean одинаково стоит \(1/(2M+1)\) (это место, где раньше рвалось). fileciteturn2file1L104-L111 |
| 15 | (Идентификация) Связь с \(Q(\Phi)\) | T0 нормировка: \(Q(\phi)=\int a_*(\xi)\phi(\xi)d\xi-\sum w_Q(n)\phi(\xi_n)\). fileciteturn2file2L41-L57 | T0 Lemma 5.2 fileciteturn2file2L41-L57 | `Q3.Q` / `arch_term` / `prime_term` defs | **OK** (контракт) fileciteturn2file13L20-L34 | Чек: в Lean **w_Q** используется в **Q**, а **w_RKHS** только в cap‑оценках. fileciteturn2file2L60-L61 |
| 16 | (Идентификация) “правильная” конечномерная формула | Мост без “умножить arch”: \( \langle T_M[P_A]p,p\rangle - (2M+1)\langle T_P^{(M)}p,p\rangle = Q(\Phi)\) (для sampling‑polynomial). fileciteturn2file11L63-L90 | Lemma 9.4 fileciteturn2file11L63-L90 | цель Rayleigh_Q_identification | **BLOCKER** (в Lean) | Чек: Lean‑statement должен совпасть с этим шаблоном (и не иметь “(2M+1)×вся разность”). fileciteturn2file11L69-L79 |
| 17 | (Тех‑блокер Lean) periodization | Быстро доказать \(\int_{\mathbb T}P_A = \int_\mathbb R a_*\Phi\) (арх‑часть). | (A3 symbol def) fileciteturn2file13L30-L34 | `integral_P_A_eq_arch_term` (hang) | **BLOCKER** | Отдельная тех‑задача: заменить доказательство на “готовую periodize‑лемму”/архивный леммат. (Это ваш текущий таймаут‑бутылочное горло.) |

---

### Мини‑словарик (чтобы в голове не было “магии”)

- **Weil criterion** — внешний факт: “\(Q\ge0\) на **Weil cone** ⇔ **RH**”. fileciteturn2file12L5-L19  
- **T5 transfer** — перенос позитивности с **атомов** на весь класс \(\mathcal W\) через плотность + непрерывность. fileciteturn2file5L8-L18  
- **Toeplitz operator** \(T_M[P_A]\) — сжатие Fourier‑мультипликатора с символом **P_A**; “золотая формула” даёт интеграл \(\int_{\mathbb T}P_A|p|^2\). fileciteturn2file3L106-L116  
- **Rayleigh quotient** — \(\langle Ap,p\rangle/\langle p,p\rangle\), даёт нижнюю оценку через \(\min P_A\). fileciteturn2file12L16-L19  
- **Compression** — ортогональная проекция/сжатие оператора на подпространство (важно для uniform‑оценок). fileciteturn2file6L78-L84  
- **RKHS cap** — uniform‑оценка нормы прайм‑оператора: \(\|T_P\|\le\rho(1)<1/25\). fileciteturn2file12L46-L50  
- **t_sym / t_rkhs** — два разных “t”: для **символа** и для **cap**, их нельзя смешивать. fileciteturn2file13L42-L44  
- **w_Q / w_RKHS** — веса в **Q** и веса в RKHS‑оценках — разные. fileciteturn2file2L60-L61  

Если хочешь, следующим сообщением я сделаю “микро‑чеклист только для A3‑узла”: какие именно Lean‑леммы должны появиться/переименоваться, чтобы строка **#16** стала **OK**, и где именно лучше “перерезать” таймаут в **periodization** (строка **#17**) — без глобальной перестройки проекта.

## USER
Ок. Го

## ASSISTANT
Ы Ок, вот **чек‑лист в одной таблице**: каждый “стрелочный” переход из **Critical Chain** + ключевые внутренние стрелки **A3/Rayleigh** (потому что именно там сейчас реальные блокеры).

Обозначения: **[OK]** закрыто теоремой, **[AX]** всё ещё аксиома в главной цепи, **[PERF]** не математика, а проблема компиляции/элаборации.

| ID | Стрелка | Что обязано быть верно (минимально) | Где это живёт (paper / Lean) | Статус | Что ломается / что проверить быстро |
|---:|---|---|---|---|---|
| C0 | **RH_of_Weil_and_Q3** → цель | Финальный “верхний” результат проекта: всё сводится к контролю **Weil functional** **Q** на нужном конусе тестов | **PROJECT_ORCHESTRATOR** критическая цепь【279:2†PROJECT_ORCHESTRATOR.md†L1-L18】 | — | Быстрый контроль “сколько ещё аксиом”: см. команду ниже (ID C8) |
| C1 | RH_of_Weil_and_Q3 → **Weil_criterion** | Используем внешний **Weil_criterion** (это “внешняя” аксиома, ожидаемо) | **PROJECT_ASCII / ORCHESTRATOR**【279:12†PROJECT_ASCII.md†L12-L29】 | **[AX external]** | Это **не закрываем** сейчас: принимаем как внешний мост “Q≥0 ⇒ RH” |
| C2 | RH_of_Weil_and_Q3 → **Q_nonneg_on_Weil_cone** | Нужно доказать **Q ≥ 0** на **Weil cone** (внутренний конус тестов) | **PROJECT_ORCHESTRATOR**【279:2†PROJECT_ORCHESTRATOR.md†L8-L18】 | **[OK]** | Если где-то упадёт — обычно из-за плохих зависимостей (случайно тянется аксиома снизу) |
| C3 | Q_nonneg_on_Weil_cone → **T5_transfer** | Перенос неотрицательности с атомов/приближений на **Weil cone** (логика “плотность + липшиц”) | **PROJECT_ORCHESTRATOR**【279:2†PROJECT_ORCHESTRATOR.md†L10-L18】 | **[OK]** | Ломается, если **A1_density** или **Lipschitz** не действительно безаксиомны |
| C4 | T5_transfer → **A1_density_WK** | **Плотность**: любой объект из **W_K** приближается атомами (в правильной норме) | **PROJECT_ORCHESTRATOR** “wired, axiom removed”【279:10†PROJECT_ORCHESTRATOR.md†L26-L29】 | **[OK]** | Риск: “boundary condition” / поддержка (**support ⊆ [-K,K]**) — но это уже решали, см. оркестратор про resolved issue【283:2†PROJECT_ORCHESTRATOR.md†L46-L49】 |
| C5 | T5_transfer → **Q_Lipschitz_on_W_K** | **Q** липшицев на **W_K** по sup‑норме/модулю (контроль изменения Q при аппроксимации) | **PROJECT_ORCHESTRATOR**【279:10†PROJECT_ORCHESTRATOR.md†L20-L23】 + paper: Lipschitz modulus (пример)【283:12†RH_Q3.pdf†L1-L20】 | **[OK]** | Ломается, если хвосты прайм‑суммы не контролируются/не обрезаются корректно |
| C6 | T5_transfer → **Q_nonneg_on_atoms** | База: **Q ≥ 0** на **атомах** (локализованных тестах) | **PROJECT_ORCHESTRATOR**【279:2†PROJECT_ORCHESTRATOR.md†L12-L18】 | **[AX]** | Это и есть “последний гейт”: пока **аксиома**, закрывается через **A3_bridge_axiom + RKHS_contraction** |
| C7 | Q_nonneg_on_atoms → **A3_bridge_axiom** | Мост A3: аналитически связывает матричную/операторную неотрицательность с неотрицательностью **Q** на атомах | **PROJECT_ORCHESTRATOR**【279:2†PROJECT_ORCHESTRATOR.md†L14-L18】 | **[AX] (closable)** | По оркестратору: “READY TO WIRE” + точный action plan【279:2†PROJECT_ORCHESTRATOR.md†L20-L33】 |
| C8 | Q_nonneg_on_atoms → **RKHS_contraction** | Контроль прайм‑оператора через **RKHS contraction** (норма прайм‑части ≤ ρ, uniform) | **PROJECT_ORCHESTRATOR**: “RKHS contraction bridged”【279:10†PROJECT_ORCHESTRATOR.md†L23-L30】 + paper: ρ(t)↓0【279:7†RH_Q3.pdf†L1-L50】 | **[OK]** | Ломается, если внезапно используете **direct-indexed T_P** вместо **compression T_P** (см. A3‑2) |
| C9 | (после C7) → **Q_nonneg_on_atoms_of_A3_RKHS_axiom** | После закрытия A3, “добиваем” **Q_nonneg_on_atoms** стандартным bridge‑файлом | План в оркестраторе: wire after A3【279:2†PROJECT_ORCHESTRATOR.md†L24-L26】 | **BLOCKED** | Это блокируется ровно **A3_bridge_axiom** (пока оно [AX]) |
| A3‑0 | **A3_bridge_axiom** → “Rayleigh+Cap wiring” | Закрыть **A3_bridge_axiom**: связать **Rayleigh lower bound** + **RKHS cap** в `A3_bridge_data_rayleigh` | Оркестратор: active next step【279:2†PROJECT_ORCHESTRATOR.md†L20-L26】 | **[READY]** | Это “инженерная” работа: wiring в `Q3/AxiomsTheorems.lean` |
| A3‑1 | “правильный T_P” (тип) | Нельзя путать **compression T_P** и **direct-indexed T_P**: только compression даёт uniform по M | Оркестратор: CRITICAL INSIGHT + формулы двух T_P【283:2†PROJECT_ORCHESTRATOR.md†L1-L15】 | **[MUST‑PASS]** | Если где-то в Lean подсунули direct‑indexed, всё ломается: `||T_P|| → ∞`【283:2†PROJECT_ORCHESTRATOR.md†L7-L13】 |
| A3‑2 | **Toeplitz quadratic form** | “Золотая формула”: ⟨**T_M[P_A]** p, p⟩ = ∫_T P_A(θ)·|p(θ)|² dθ | Paper, Lemma 8.8【283:6†RH_Q3.pdf†L43-L54】 | **[OK in paper]** | В Lean это должно быть уже в `rayleigh_v1.lean` (как пишет оркестратор)【279:5†PROJECT_ORCHESTRATOR.md†L1-L6】 |
| A3‑3 | **Periodization / κA3=1** | **Калибровка периода**: ∫_{-1/2}^{1/2} P_A = 2π ∫_ℝ g. Это и есть “арх‑часть без множителя” при правильном выборе g=aΦ и a* =2πa | Paper, Lemma 8.1【283:3†RH_Q3.pdf†L1-L35】 | **[OK in paper]** | В Lean у вас это сейчас = **узкое место** (`integral_P_A_eq_arch_term` зависает) → см. PERF‑1 |
| A3‑4 | **Prime compression identity** | Определение нормированного **v_n^(M)** и факт: ι_M^* T_P ι_M = (2M+1)·T_P^(M) | Paper (определение + identity)【283:6†RH_Q3.pdf†L55-L84】 | **[OK]** | Это “генератор” фактора (2M+1): он должен появляться **только на прайм‑части** |
| A3‑5 | **Rayleigh pairing** (нормировка) | Ключ: p(ξ_n)=√(2M+1)⟨p,v_n⟩, поэтому |⟨p,v_n⟩|² = |p(ξ_n)|²/(2M+1) | Paper, Lemma 8.9【283:0†RH_Q3.pdf†L7-L56】 | **[OK]** | Это ровно ваш “нормировочный конфликт”: если где-то написано p(ξ_n)=⟨p,v_n⟩ — это баг |
| A3‑6 | **Правильная идентификация Q** (фикс) | Для p≡1: Q(Φ)=⟨T_M[P_A]1,1⟩ − (2M+1)⟨T_P^(M)1,1⟩. Эквивалентно: Q≥0 ⇔ ⟨(T_M[P_A] − (2M+1)T_P^(M))1,1⟩ ≥0 | Paper, Thm 8.10【283:0†RH_Q3.pdf†L57-L96】 | **[MUST‑MATCH Lean]** | В Lean‑statement нельзя писать (2M+1)*RQ(Toeplitz−T_P_comp)=Q: это множит arch‑часть |
| A3‑7 | **Rayleigh lower bound** | Если P_A(θ) ≥ c* (точечно), то **Rayleigh quotient** Toeplitz ≥ c* | Оркестратор: Rayleigh proven + смысл результата【279:5†PROJECT_ORCHESTRATOR.md†L1-L6】 | **[OK]** | Проверка: этот файл должен быть `0 sorry`; иначе A3 не закроешь |
| A3‑8 | **Arch floor c*** | Доказать, что **P_A ≥ c\*** (uniform по B≥Bmin при фиксированном tsym) | Paper, Lemma 8.19: c* (примерно 11/10)【279:14†RH_Q3.pdf†L164-L171】 | **[OK in paper]** | В Lean это у вас уже интегрировано (`A3_FLOOR` proven)【279:10†PROJECT_ORCHESTRATOR.md†L18-L19】 |
| A3‑9 | **RKHS cap / rho_one** | Норма прайм‑оператора ≤ ρ, выбираем **t_rkhs_cap** (например 40), чтобы ρ ≤ c*/4 | Оркестратор: RKHS cap proven, t_rkhs_cap=40【279:10†PROJECT_ORCHESTRATOR.md†L28-L30】 + paper: ρ(t)↓0【279:7†RH_Q3.pdf†L35-L50】 | **[OK]** | Любой срыв тут почти всегда = неверный T_P (см. A3‑1) или неверный “uniform” |
| A3‑10 | “сборка A3” | Из A3‑7 + A3‑8 + A3‑9 получаем margin: (Toeplitz − T_P_comp) ⪰ (c*/4)I (в нужной форме) | Оркестратор: V5 “Rayleigh-first” зависимости【283:2†PROJECT_ORCHESTRATOR.md†L24-L33】 | **[OK (готово) / WIRE]** | Сейчас это “готово, но не подключено” → именно это wiring из A3‑0 |
| PERF‑1 | (Lean) **Periodization lemma** | Быстро закрыть `integral_P_A_eq_arch_term` без таймаута: повторить структуру Lemma 8.1 (**Fubini + change of vars**), без тяжёлого `integral_tsum_of_summable_integral_norm` | Paper: Lemma 8.1 даёт точную схему【283:3†RH_Q3.pdf†L36-L56】 | **[PERF]** | Если оставить как сейчас — `lake env lean` может “висеть” на элаборации. Нужен более короткий путь |
| PERF‑2 | (Lean) **Normalization alignment** | Убедиться, что в Lean‑теореме фактор (2M+1) стоит **на прайм‑операторе**, а не “снаружи на разности” | Paper: Thm 8.10 явным текстом【283:0†RH_Q3.pdf†L57-L96】 | **[TO‑FIX in code]** | Если не совпадёт — потом будет “невозможно состыковать” с **T0**‑определением Q |

### Быстрый “мета‑чек” статуса (1 команда)
Проверка количества оставшихся аксиом в верхней теореме (как в оркестраторе):  
```bash
echo 'import Q3.Main
#print axioms Q3.Main.RH_of_Weil_and_Q3' | lake env lean --stdin 2>&1 | rg -v "^info:"
```
(это прямо в **PROJECT_ORCHESTRATOR** как “verified”)【279:10†PROJECT_ORCHESTRATOR.md†L40-L54】

---

## Мини‑глоссарий (коротко, чтобы не было “магии”)

- **Weil_criterion** — внешний мост “неотрицательность **Q** на классе тестов ⇒ RH”.
- **Q** / **Weil functional** — функционал вида “**arch_term** − **prime_term**” в **T0 normalization** (в paper прямо записан)【283:3†RH_Q3.pdf†L107-L116】.
- **T5_transfer** — перенос неотрицательности на большой конус из (плотность + липшиц + база на атомах).
- **W_K** — класс тестовых функций с поддержкой в компакте K (структура для плотности/липшиц‑контроля).
- **A3_bridge_axiom** — мост “Toeplitz/Rayleigh + RKHS cap ⇒ контроль Q на атомах”.
- **Toeplitz operator** **T_M[P_A]** — матрица/оператор, чья квадратичная форма равна ∫ P_A|p|²【283:6†RH_Q3.pdf†L43-L54】.
- **prime operator compression** **T_P^(M)** — сумма ранга‑1 по нормированным **v_n^(M)**【283:6†RH_Q3.pdf†L55-L84】.
- **(2M+1) factor** — появляется строго из нормировки/компрессии и должен жить на прайм‑части【283:0†RH_Q3.pdf†L78-L86】.
- **Periodization** — тождество ∫_T ∑ g(θ+m) = ∫_ℝ g (в paper — Lemma 8.1)【283:3†RH_Q3.pdf†L1-L35】.
- **RKHS_contraction / cap** — оценка нормы прайм‑оператора ≤ ρ(t) с ρ(t)→0, выбираем t, чтобы “прайм не мог убить арх”【279:7†RH_Q3.pdf†L35-L50】.

---

Если хочешь, следующим сообщением я сделаю “ультра‑сухой” список **только действий** (без математики): какие конкретно файлы в Lean трогать и что в каждом заменить, чтобы закрыть **A3_bridge_axiom** и убить **PERF‑1**.

## USER
Чувак, нет, мне для начала нужны явные, конкретные правки, которые нужно внести именно в PDF, чтобы математический текст был ясный, закрытый, строгий и приводил к закрытию всей математической цепочки. Вот это вот сделай, пожалуйста. Явные вставки куда, что в тексте обязательно надо вставить, потому что без этой вставки вся цепочка разрывается. Если таких вставок нет, то просто покажи куда и как конкретно, что бы ты конкретно вставлял бы, для того, чтобы, может быть, сделать что-то более понятное для ревьюера.

## ASSISTANT
Ы **Исправленный текст твоего запроса (без лишней бюрократии, по делу):**  
Чувак, нет — мне сначала нужны **явные, конкретные правки** прямо в **PDF/манускрипт**: **куда** и **что** вставить/заменить, чтобы текст был **строгий**, **ясный**, и чтобы вся **цепочка вывода** реально **закрывалась**. Покажи **обязательные вставки** (без них рвётся логика). Если всё уже есть — тогда скажи **где именно** и что бы ты **добавил для ревьюера**, чтобы не было «а откуда тут (2M+1)?».

---

Ок, делаю ровно это: **минимальный набор правок**, который *обязан* быть в тексте, иначе цепочка реально ломается. И плюс — **косметика для ревьюера**, чтобы не было вопросов.

## 1) “Ломает цепочку” — MUST‑HAVE вставки/замены

### (A) Явно закрепить **T0-нормировку**: что такое **Q**, что такое **a\***, и почему веса **удвоены**
**Где:** Section **5 (Normalization T0)**, рядом с определением **Q**.

**Что обязательно должно стоять (иначе ревьюер будет спорить про 2π и “почему веса 2Λ/√n”):**  
- **a\*(ξ)=2π a(ξ)**  
- **ξₙ = (log n)/(2π)**  
- **Q(Φ)=∫ a\*(ξ)Φ(ξ)dξ − Σ w_Q(n) Φ(ξₙ)**  
- И фраза, что в операторных/ RKHS-оценках веса **не удваиваются**, а удвоение — только из-за evenization в **Q**.

Это уже зафиксировано в текущем PDF как **Lemma 5.2** (и remark про **wRKHS vs wQ**)【turn11file0†RH_Q3.pdf†L41-L61】【turn11file9†RH_Q3.pdf†L21-L26】.

✅ **Если в твоей локальной версии этого нет — это must‑insert.**

---

### (B) Вставить/подчеркнуть **Periodization identity**: “∫ₜ P_A = 2π∫ g”
**Где:** начало A3‑модуля, Section **8.1** перед тем как связывать **Toeplitz** и **arch_term**.

**Что обязательно:** лемма вида  
\[
P_A(\theta):=2\pi\sum_{m\in\mathbb Z} g(\theta+m),\quad
\int_{-1/2}^{1/2}P_A(\theta)d\theta = 2\pi\int_\mathbb R g(\xi)d\xi.
\]  
И ключевая строка: “для **g=aΦ** это ровно даёт **arch_term** в **T0**‑нормировке” (то есть без скрытого множителя).

В PDF это уже есть как **Lemma 8.1**【turn11file1†RH_Q3.pdf†L1-L35】.

✅ **Если удалить/ослабить — цепь “Toeplitz диагональ → arch_term” рвётся.**

---

### (C) В Section “Rayleigh Identification” явно прописать **компрессию прайм‑оператора**, где (2M+1) **поглощается геометрией**, а не “взрывает норму”
Вот это — главный “скользкий” момент, который ломал вам мозг.

**Где:** Section **8.2**, сразу после определения **P_M** и **v_n^{(M)}**, до Rayleigh pairing.

**Что обязательно должно быть в тексте (в явном виде):**
1) определение нормированного  
\[
v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M}e^{2\pi i k(\theta-\xi_n)}
\]
2) и **компрессионная идентичность**  
\[
\iota_M^*\,T_P\,\iota_M = (2M+1)\,T_P^{(M)}.
\]
Это ровно то, что “спасает uniform cap”: **(2M+1)T_P^{(M)}** — это не “раздутый оператор”, а **компрессия** глобального **T_P**, поэтому его **операторная норма** остаётся под контролем “как у T_P”.

В PDF это уже есть в **Lemma 8.8** и прямо текстом сказано “normalized compression of the global prime operator” + формула \(\iota_M^*T_P\iota_M=(2M+1)T_P^{(M)}\)【turn11file4†RH_Q3.pdf†L24-L30】【turn11file4†RH_Q3.pdf†L51-L65】.

✅ **Без этого** ты либо:
- случайно считаешь, что масштабирование убивает uniform bounds, либо
- теряешь связь с “глобальным” **RKHS cap** (а это уже ломает A3→Main closure).

---

### (D) Исправить (или вставить) ровно одну “убойную” формулу: **оценка в точке vs inner product**
**Где:** прямо в **Rayleigh pairing** лемме (или отдельным Remark сразу перед ней).

**Что обязательно (это и есть “нормировочный конфликт”):**
\[
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle,
\quad\text{поэтому}\quad
|\langle p, v_n^{(M)}\rangle|^2=\frac{1}{2M+1}|p(\xi_n)|^2.
\]

В PDF это уже стоит в **Lemma 8.9** (в доказательстве как “identities …”)【turn11file2†RH_Q3.pdf†L47-L56】.

✅ **Если тут написать без \(\sqrt{2M+1}\)** — всё. Дальше либо неверная идентификация, либо фантомный фактор.

---

### (E) В **Rayleigh pairing** обязательно показать *обе* версии прайм‑члена: через \(|\langle p,v\rangle|^2\) и через \(|p(\xi)|^2/(2M+1)\)
**Где:** Lemma **Rayleigh pairing** (у вас это Lemma 8.9).

**Что должно быть именно так (в statement, не только в доказательстве):**  
\[
\langle (T_M[P_A]-T_P^{(M)})p,p\rangle
=
\int_{\mathbb T}P_A(\theta)|p(\theta)|^2d\theta
-\sum w(n)\Phi(\xi_n)|\langle p,v_n^{(M)}\rangle|^2
\]
и эквивалентно
\[
=\int_{\mathbb T}P_A|p|^2
-\frac{1}{2M+1}\sum w(n)\Phi(\xi_n)|p(\xi_n)|^2.
\]

Это уже есть в PDF в **Lemma 8.9**【turn11file2†RH_Q3.pdf†L7-L46】.

✅ **Без второй формы** ревьюер не увидит, откуда берётся (2M+1) в финале для \(p\equiv 1\).

---

### (F) В **Rayleigh identification** для \(p\equiv 1\) зафиксировать единственно правильную форму:
**арх‑часть без множителя**, **прайм‑часть с (2M+1)** — и это **именно Q(Φ)** по T0
**Где:** Theorem “Rayleigh identification for Fejér×heat” (у вас Theorem 8.10).

**Что должно быть:**
\[
\langle T_M[P_A]1,1\rangle_{L^2(\mathbb T)}-(2M+1)\langle T_P^{(M)}1,1\rangle_{L^2(\mathbb T)}
=\int_{\mathbb T}P_A-\sum w(n)\Phi(\xi_n)=Q(\Phi).
\]
И обязательно фраза: “фактор (2M+1) появляется потому что \(|\langle 1,v_n^{(M)}\rangle|^2=1/(2M+1)\) при \(|1(\xi_n)|^2=1\)”.

Это уже прописано в PDF【turn11file2†RH_Q3.pdf†L57-L86】.

✅ **Если вместо этого написать** \((2M+1)\cdot RQ(T_M[P_A]-T_P^{(M)},e_0)=Q(\Phi)\) — это *множит арх‑часть* и это неверно (твоя исходная боль).

---

## 2) “Не обязательно, но сделает ревьюера спокойным” — reviewer‑proof патчи

### (R1) Добавь короткий **Remark‑box** сразу после определения \(v_n^{(M)}\)
Чтобы ревьюер не лазил по 3 леммам и не спрашивал “почему (2M+1)”.

**Вставка (готовый LaTeX‑кусок):**
```tex
\begin{remark}[Normalization checkpoint: evaluation vs inner product]
With the $L^2(\mathbb T)$ inner product and the normalized vectors
$v_n^{(M)}(\theta)=\frac{1}{\sqrt{2M+1}}\sum_{|k|\le M}e^{2\pi i k(\theta-\xi_n)}$,
one has $\|v_n^{(M)}\|_2=1$ and
$p(\xi_n)=\sqrt{2M+1}\,\langle p,v_n^{(M)}\rangle$ for all $p\in P_M$.
Hence $|p(\xi_n)|^2=(2M+1)|\langle p,v_n^{(M)}\rangle|^2$,
which is the sole source of the factor $(2M+1)$ in Theorem~8.10.
\end{remark}
```
Смысл: это “табличка на стене” — снимает 90% вопросов.

---

### (R2) В одном месте явно написать: **(2M+1)T_P^{(M)} = compression of T_P**, значит **нормы не растут**
Это уже есть по сути в Lemma 8.8【turn11file4†RH_Q3.pdf†L24-L30】, но можно добавить одну фразу:
> “In particular, \(\|(2M+1)T_P^{(M)}\|\le \|T_P\|\), since compression does not increase operator norm.”

Это прямо закрывает старый страх “масштабирование убьёт uniform cap”.

---

### (R3) Мини‑диаграмма “кто кого определяет” (1 картинка ASCII прямо в PDF)
Чтобы ревьюер видел, что это не “чёрная магия”, а механика:

```text
T0 fixes:  ξn = log n / (2π),  a*(ξ)=2πa(ξ),  Q(Φ)=∫a*Φ − Σ wQ Φ(ξn)
                         |
                         v
A3 defines:  g(ξ)=a(ξ)Φ(ξ),  P_A(θ)=2π Σm g(θ+m)
                         |
                         v
Lemma 8.1:  ∫_T P_A = ∫_R a*(ξ)Φ(ξ)dξ      (arch term)
                         |
                         v
Model space: P_M, v_n^(M) normalized
                         |
                         v
Lemma 8.8:  ι*_M T_P ι_M = (2M+1) T_P^(M)  (compression absorbs scaling)
                         |
                         v
Lemma 8.9 + Thm 8.10:  ⟨T_M[P_A]1,1⟩ − (2M+1)⟨T_P^(M)1,1⟩ = Q(Φ)
```

---

## 3) Важная проверка: в текущем RH_Q3.pdf “обязательные куски” уже есть

Если ориентироваться на загруженный **RH_Q3.pdf**, то **критические вставки уже присутствуют**:

- **T0 crosswalk** и формула **Q(Φ)**: Lemma 5.2【turn11file0†RH_Q3.pdf†L41-L61】  
- **Periodization** и “без further rescaling”: Lemma 8.1【turn11file1†RH_Q3.pdf†L14-L35】  
- **Compression identity** с \((2M+1)\): Lemma 8.8【turn11file4†RH_Q3.pdf†L24-L30】  
- **Rayleigh pairing** с делителем \(1/(2M+1)\): Lemma 8.9【turn11file2†RH_Q3.pdf†L7-L46】  
- **Rayleigh identification** (арх без множителя, прайм с \((2M+1)\)) = **Q(Φ)**: Theorem 8.10【turn11file2†RH_Q3.pdf†L57-L86】

То есть если ты именно этот PDF считаешь “каноном” — **цепочка на бумаге закрыта**.

---

## Мини‑словарик (чтобы мы одинаково понимали слова)
- **T0‑нормировка** — фиксирует, где сидит **2π**, как задана ось **ξ**, и как определён **Q**.  
- **Q(Φ)** — линейный **Weil functional**: **арх‑интеграл** минус **прайм‑сумма**【turn11file0†RH_Q3.pdf†L51-L57】.  
- **Periodization** — формула, которая превращает **сумму по m∈ℤ** в интеграл по **ℝ** (ключ к arch‑части)【turn11file1†RH_Q3.pdf†L36-L55】.  
- **Compression** — “обрезание” оператора на подпространство (**P_M**) через \(\iota_M^* T \iota_M\). Важно: **норма не растёт**.  
- **Rayleigh pairing** — запись квадратичной формы оператора через интеграл/сумму, чтобы сопоставить с **Q**.  
- **Fejér×heat window** — ваше **Φ_{B,t}**, треугольник × гаусс, компактная поддержка.

---

Если хочешь — следующий шаг супер‑практичный: ты мне говоришь “в какой именно TeX‑ветке у вас сейчас старый текст сидит”, и я дам *точечный diff* “replace this block → with this block” (без философии), чтобы вы просто закоммитили и забыли.

## USER
в этом-то прикол, это и есть тот PDF, который мы считаем каноном. То есть, практически нам больше там ничего не нужно править, там и так все правильно математически закрыто, правильно? Если мы не нарвемся на следующую проблему, пока будем формализовывать в лине. Правильно?

## ASSISTANT
Ы **Переписал твой вопрос чуть ровнее (стиль сохранил):**  
«Вот в чём прикол: это и есть тот **PDF**, который мы считаем каноном. То есть, по сути, нам больше ничего в нём править не нужно — там уже всё математически закрыто, да? Если мы просто не нарвёмся на следующую проблему уже при формализации в **Lean**. Верно?»

---

## Да: по нормировке и Rayleigh‑идентификации этот PDF уже “закрыт” и консистентен

Ключевое: **в RH_Q3.pdf уже прописан именно тот фикс**, который ты требуешь:

### 1) Исправлена “сломанная” строка про оценку в точке
В **Lemma 8.9 (Rayleigh pairing)** в явном виде стоит правильная связь
\[
p(\xi_n)=\sqrt{2M+1}\,\langle p, v_n^{(M)}\rangle,
\]
и из неё прямо выводится фактор \(\frac{1}{2M+1}\) в прайм‑части квадратичной формы. Это записано буквально в тексте леммы/доказательства. 【285:1†RH_Q3.pdf†L7-L56】

То есть в каноне **нет** больше утверждения вида “\(p(\xi_n)=\langle p,v\rangle\)” без \(\sqrt{2M+1}\). Оно заменено на корректное. 【285:1†RH_Q3.pdf†L49-L56】

### 2) Идентификация с \(Q(\Phi)\) сделана “как надо”: масштабируется только прайм‑часть
В **Theorem 8.10 (Rayleigh identification for the Fejér×heat window)** написано ровно то, что ты хотел:

\[
\langle T_M[P_A]\,1,1\rangle_{L^2(\mathbb T)}
\;-\;
(2M+1)\,\langle T_P^{(M)}\,1,1\rangle_{L^2(\mathbb T)}
=
\int_{\mathbb T} P_A(\theta)\,d\theta
-\sum w(n)\Phi(\xi_n)
=
Q(\Phi_{B,t}).
\]

То есть **арх‑часть без множителя**, а **прайм‑часть с \((2M+1)\)** (и это объяснено словами). 【285:1†RH_Q3.pdf†L57-L96】

И там же прям человеческим языком объяснено, **почему** фактор появляется: потому что \(|\langle 1, v_n^{(M)}\rangle|^2=1/(2M+1)\), а \(|1(\xi_n)|^2=1\). 【285:1†RH_Q3.pdf†L78-L86】

Плюс они дают эквивалентную опцию: использовать **ненормированные** \(\tilde v_n:=\sqrt{2M+1}\,v_n^{(M)}\), тогда можно писать без внешнего фактора — но это уже “другая геометрия/другая нормировка векторов”. 【285:1†RH_Q3.pdf†L82-L86】

### 3) Связь “compression vs global prime operator” тоже закрыта (важно!)
В **Lemma 8.8** канон фиксирует, что \(T_P^{(M)}\) — это **нормированная компрессия** глобального \(T_P\), и там же стоит формула:

\[
\iota_M^*\, T_P\, \iota_M = (2M+1)\,T_P^{(M)}.
\]

Это ключевой мост, который объясняет “откуда вообще берётся \((2M+1)\)”. 【285:2†RH_Q3.pdf†L55-L84】

---

## Значит ответ на твой вопрос: “да, PDF уже канонически правильный” — именно по этой проблеме

То, что раньше выглядело как “манускрипт багует” (конфликт между нормировкой \(v_n^{(M)}\) и прайм‑термом), **в текущем RH_Q3.pdf уже починено**:  
- **вектор \(v_n^{(M)}\) нормирован**;  
- **прайм‑квадратичная форма содержит \(\frac{1}{2M+1}\)** при переходе к \(|p(\xi_n)|^2\);  
- **в финальной идентификации с \(Q\)** этот фактор компенсируется **ровно** умножением на \((2M+1)\) **только прайм‑оператора**, а не всей разности. 【285:1†RH_Q3.pdf†L57-L96】

---

## Что может “вылезти” уже в Lean, даже если PDF идеален

Тут ты прав: следующий риск — не “математика развалилась”, а “формализация боль”.

Сам PDF в Theorem 8.10 использует два “очевидных на бумаге” шага, которые в **Lean** могут быть тяжёлыми:

1) **Периодизация / перестановка \(\int\) и \(\sum\)**:  
в доказательстве Theorem 8.10 написано, что  
\[
\int_{\mathbb T} P_A(\theta)\,d\theta=\int_{\mathbb R} a_*(\xi)\Phi(\xi)\,d\xi
\]
“по определению \(P_A\) и нормировке из Section 5”. 【285:1†RH_Q3.pdf†L111-L123】  
На бумаге это стандартная “periodization identity”, а в Lean это ровно тот узкий боттлнек, где вы сейчас виснете.

2) **Сведение прайм‑суммы к nodes/finite support**:  
в Theorem 8.10 явно используется, что прайм‑сумма конечна из‑за поддержки \(\Phi\) в \([-B,B]\). 【285:1†RH_Q3.pdf†L109-L112】

Это не контринтуитивно, но Lean любит, чтобы ты очень явно указал: где **support**, где **fintype**, где **tsum превращается в finset.sum**, и т.д.

---

## Мини‑словарик (чтобы больше не было “магии”)

- **\(L^2(\mathbb T)\)** — пространство квадратно‑интегрируемых функций на торе \(\mathbb T=[-1/2,1/2]\) с мерой \(d\theta\).  
- **\(v_n^{(M)}\)** — **нормированный** “model‑space” вектор (по Фурье‑модам \(|k|\le M\)). Нормировка даёт \(\|v_n^{(M)}\|=1\). 【285:2†RH_Q3.pdf†L68-L77】  
- **Rayleigh pairing / identification** — шаг, где операторное выражение \(\langle (T_M[P_A]-\cdots)p,p\rangle\) при \(p\equiv 1\) превращается в “арх‑интеграл минус прайм‑сумма”, то есть в **Weil‑функционал \(Q(\Phi)\)**. 【285:1†RH_Q3.pdf†L57-L96】  
- **Компрессия** — \(\iota_M^* T \iota_M\): “обрезаем” глобальный оператор на конечномерное подпространство \(P_M\). 【285:2†RH_Q3.pdf†L78-L84】

---

## Bottom line

Да: **этот RH_Q3.pdf уже содержит исправленную нормировку и корректную идентификацию**, так что по “манускрипт vs Lean” именно тут теперь разрыва нет. Самый вероятный следующий фейл — чисто **Lean‑техничка**: аккуратно доказать периодизацию \(\int_{\mathbb T} P_A = \int_{\mathbb R} a_*\Phi\) без таймаута. 【285:1†RH_Q3.pdf†L111-L123】

Если хочешь — следующим ходом я сделаю для вас “Lean‑friendly” формулировку этой периодизации в одном-двух леммах так, чтобы **не** вызывать монстра `integral_tsum_of_summable_integral_norm` (то есть ровно под ваш bottleneck).

## USER
Отлично! Теперь как обойти проблемы in Lean? Ty прав насчет bottleneck! сделаю для вас “Lean‑friendly” формулировку этой периодизации в одном-двух леммах так, чтобы не вызывать монстра integral_tsum_of_summable_integral_norm (то есть ровно под ваш bottleneck).

## ASSISTANT
Ы **Исправляю твой текст (сохранил стиль):**

«Окей! Как обойти проблемы в **Lean**? Ты прав насчёт **bottleneck**. Дай “Lean‑friendly” формулировку периодизации в 1–2 леммах так, чтобы не вызывать монстра `integral_tsum_of_summable_integral_norm` — то есть ровно под наш bottleneck.»

---

## Что реально тормозит и почему твой текущий путь “умирает”

Твой зависон сидит в попытке **поменять местами** **`∫`** и **`∑'`** через  
**`MeasureTheory.integral_tsum_of_summable_integral_norm`** — это огромная машина: **restricted measure**, куча **Integrable** на каждом сдвиге, плюс **Summable** по нормам. Именно это и “раздувает” elaboration. Это ровно то, что ты описал как bottleneck. fileciteturn2file1

Ключевой факт, который позволяет выкинуть монстра:

- у вас **`g`** (и значит **`P_A`**) **компактно поддержана** из‑за окна: `w` обнуляется вне `[-B,B]`. В манускрипте прямо сказано: *“gB,tsym is compactly supported on [−B,B], so the periodization sum defining PA is finite for each θ.”* fileciteturn2file13  
- в вашем Lean‑контексте это уже есть как `g_eq_zero_of_abs_ge` + `support ⊆ Icc (-B) B` (ты это уже строишь в начале леммы). fileciteturn2file12

Раз периодизация **конечная** на фундаментальном интервале, то **не нужно** никакой dominated convergence:  
**`tsum`** можно сначала свести к **`Finset.sum`** (конечная сумма), и уже потом интегрировать.

---

## Лемма №1: “tsum на торе = finset.sum”, потому что support

Идея: на **`θ ∈ [-1/2, 1/2]`** все сдвиги `θ+n` с большим `|n|` лежат вне `[-B,B]`, поэтому `g(θ+n)=0`. Значит **`∑'`** реально конечная (один и тот же finset для всех θ на интервале).

### Lean‑friendly форма (скелет)

```lean
open scoped BigOperators
open MeasureTheory intervalIntegral

/-- On θ ∈ [-1/2,1/2], the periodization sum is actually finite
    if f is supported in [-B,B]. -/
lemma tsum_add_eq_finset_sum_on_Icc
  {f : ℝ → ℝ} {B : ℝ}
  (hsupp : Function.support f ⊆ Set.Icc (-B) B) :
  ∃ N : ℤ,
    ∀ θ : ℝ, θ ∈ Set.Icc (- (1/2 : ℝ)) (1/2 : ℝ) →
      (∑' n : ℤ, f (θ + (n : ℝ)))
        = ∑ n in (Finset.Icc (-N) N), f (θ + (n : ℝ)) := by
  classical
  -- pick N := ⌈B + 1/2⌉ + 1 or any safe integer bound
  refine ⟨Int.ceil (B + 1/2) + 1, ?_⟩
  intro θ hθ
  -- show: ∀ n ∉ Icc (-N) N, f(θ+n)=0 (because θ+n ∉ Icc(-B,B))
  -- then use `tsum_eq_sum` (or the lemma with that name in your Mathlib)
  --   have hzero : ∀ n, n ∉ Finset.Icc (-N) N → f (θ + (n:ℝ)) = 0 := ...
  --   simpa using (tsum_eq_sum (s := Finset.Icc (-N) N) hzero)
  sorry
```

### Почему это быстро
Потому что это:
- чистая **арифметика** + `support` → `=0`,
- и одна стандартная лемма про **`tsum_eq_sum`** для функций, которые нулевые вне **Finset**.

Без **`integral_tsum_of_summable_integral_norm`**, без `volume.restrict`, без “Summable of integral norms”.

**Термины (коротко):**
- **`Function.support f`** — где `f ≠ 0`.
- **`Set.Icc a b`** — отрезок `[a,b]`.
- **`tsum`** / **`∑'`** — бесконечная сумма (в `ℤ`).
- **`Finset.Icc`** — конечный набор целых в отрезке.
- **`Int.ceil`** — потолок, чтобы получить явный конечный диапазон по `n`.

---

## Лемма №2: Интеграл периодизации без swap(∫,∑)

Теперь делаем периодизацию “по‑умному”:

1) Сначала меняем **`tsum`** на **конечную сумму** на интервале (по лемме №1).  
2) Интегрируем конечную сумму: **`intervalIntegral.integral_finset_sum`**.  
3) Каждый член сдвигаем заменой переменной (**`integral_comp_add_right`**).  
4) Получаем конечную сумму интегралов по интервалам длины 1.  
5) А это уже стыкуется с `Integrable.hasSum_intervalIntegral`, но без swap.

Скелет:

```lean
/-- Periodization integral over [-1/2,1/2] equals integral over ℝ
    if f is supported in [-B,B].  No dominated convergence. -/
lemma intervalIntegral_periodize_eq_integral
  {f : ℝ → ℝ} {B : ℝ}
  (hsupp : Function.support f ⊆ Set.Icc (-B) B)
  (hint : Integrable f) :
  (∫ θ in (- (1/2 : ℝ))..(1/2), ∑' n : ℤ, f (θ + (n : ℝ)))
    = ∫ x, f x := by
  classical
  -- get finite reduction
  rcases tsum_add_eq_finset_sum_on_Icc (f := f) (B := B) hsupp with ⟨N, hN⟩
  have hab : (- (1/2 : ℝ)) ≤ (1/2 : ℝ) := by norm_num

  -- rewrite integrand to finset sum (pointwise on the interval)
  -- then integrate finset sum
  have :
      (∫ θ in (- (1/2 : ℝ))..(1/2), ∑' n : ℤ, f (θ + (n : ℝ)))
        =
      (∫ θ in (- (1/2 : ℝ))..(1/2), ∑ n in Finset.Icc (-N) N, f (θ + (n : ℝ))) := by
    -- use `intervalIntegral.integral_congr` (or an AE version) + hN
    sorry

  -- now finite sum: pull it out
  calc
    (∫ θ in (- (1/2 : ℝ))..(1/2), ∑' n : ℤ, f (θ + (n : ℝ)))
        =
      (∫ θ in (- (1/2 : ℝ))..(1/2), ∑ n in Finset.Icc (-N) N, f (θ + (n : ℝ))) := this
    _ =
      ∑ n in Finset.Icc (-N) N, (∫ θ in (- (1/2 : ℝ))..(1/2), f (θ + (n : ℝ))) := by
      -- `intervalIntegral.integral_finset_sum`
      simp
    _ =
      ∑ n in Finset.Icc (-N) N, (∫ x in (- (1/2 : ℝ)) + (n:ℝ)..(1/2) + (n:ℝ), f x) := by
      -- `intervalIntegral.integral_comp_add_right`
      refine Finset.sum_congr rfl ?_
      intro n hn
      simpa using
        (intervalIntegral.integral_comp_add_right (f := f) (d := (n:ℝ))
          (a := (- (1/2 : ℝ))) (b := (1/2 : ℝ)))
    _ =
      (∑' n : ℤ, (∫ x in (- (1/2 : ℝ)) + (n:ℝ)..(- (1/2 : ℝ)) + (n:ℝ) + 1, f x)) := by
      -- upgrade finset sum to tsum because outside range terms are zero (support!)
      sorry
    _ = ∫ x, f x := by
      -- your existing lemma: `MeasureTheory.Integrable.hasSum_intervalIntegral`
      -- (this is cheap; no swap)
      simpa using
        (MeasureTheory.Integrable.hasSum_intervalIntegral (μ := volume)
          (f := f) (y := (- (1/2 : ℝ))) hint).tsum_eq
```

### Где “подстановка переменных” (и что именно подставляем)
- `f` — это твой `g B t`.
- `θ` — переменная интеграла по тору `[-1/2,1/2]`.
- `n : ℤ` — индекс периодизации.
- `x` — переменная на `ℝ` после замены `x = θ + n`.

You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

## Как этим закрыть твой `integral_P_A_eq_arch_term` (без монстра)

Твоя цель и определения такие (ты их сам дал):  
`P_A B t θ := 2 * π * ∑' m : ℤ, g B t (θ + m)` fileciteturn2file0  
и надо доказать периодизацию:
`∫_{-1/2}^{1/2} P_A = arch_term (fejer_heat_window B t)` fileciteturn2file0

### Новый “короткий” финал леммы

```lean
lemma integral_P_A_eq_arch_term_fast (B t : ℝ) (hB : 0 < B) :
    (∫ θ in (- (1/2 : ℝ))..(1/2), P_A B t θ)
      = Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
  classical

  -- 1) support/integrable of g (как у тебя уже сделано)
  have hsupp : Function.support (fun ξ => g B t ξ) ⊆ Set.Icc (-B) B := by
    -- твой же код: через `g_eq_zero_of_abs_ge`
    sorry
  have hint : Integrable (fun ξ => g B t ξ) := by
    -- из compact support / continuous
    sorry

  -- 2) periodization integral without swapping integral/tsum
  have hper :
      (∫ θ in (- (1/2 : ℝ))..(1/2), ∑' n : ℤ, g B t (θ + (n:ℝ)))
        = ∫ x, g B t x := by
    -- apply lemma #2 with f := g B t
    simpa using
      (intervalIntegral_periodize_eq_integral
        (f := fun x => g B t x) (B := B) hsupp hint)

  -- 3) put back the 2π and unfold arch_term
  calc
    (∫ θ in (- (1/2 : ℝ))..(1/2), P_A B t θ)
        = (2 * Real.pi) * (∫ θ in (- (1/2 : ℝ))..(1/2), ∑' n : ℤ, g B t (θ + (n:ℝ))) := by
          simp [P_A, intervalIntegral.integral_const_mul]
    _ = (2 * Real.pi) * (∫ x, g B t x) := by
          simp [hper]
    _ = Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
          -- unfold g = a*w; a_star = 2π*a; fejer_heat_window = w
          unfold Q3.arch_term Q3.a_star g
          simp [Q3.fejer_heat_window]
```

---

## Почему это должно перестать “виснуть”

Потому что ты:
- **не создаёшь** объект типа `integral_tsum_of_summable_integral_norm` на restricted measure,
- **не строишь** `Summable` по нормам `∫‖…‖` вообще,
- делаешь всё через **конечную сумму** + **сдвиг интеграла** + уже готовый `hasSum_intervalIntegral`.

Это прям ровно “Lean‑friendly”: типы проще, переписываний меньше, elaboration не взрывается.

---

## Мини‑совет по организации (чтоб не ловить “параллельные пути”)

Вынеси эти две леммы в отдельный файл типа `Q3/Proofs/Periodization.lean` и импортни в `Rayleigh_Q_identification.lean`. И держи их **общими** (на любой `f` с support в `[-B,B]`). Это снижает шанс, что вы опять построите второй “параллельный” мост вместо замены одного узкого места. (Это ровно стиль из вашего error‑чеклиста.) fileciteturn1file36

---

Если хочешь, я дальше “дожму” самое тонкое место (где именно проще доказать `hzero` для `tsum_eq_sum`): там есть 2 варианта — через грубую оценку `θ∈[-1/2,1/2]` + линейные неравенства, или через `abs`‑оценку `|θ+n| ≥ |n| - 1/2`. Но в любом случае это **в разы** легче, чем dominated convergence.

## USER
Wau! Super ! Дожми!

## ASSISTANT
Ы **«Вау! Супер! Дожми!»** ✅

Окей, дожимаю: тебе нужен **Lean‑friendly** мост для периодизации без монстра **`integral_tsum_of_summable_integral_norm`**.

Ключевой хак: у вас **`g B t`** имеет **компактную поддержку** в \([-B,B]\). Значит на торе \(\theta\in[-1/2,1/2]\) сумма по \(\mathbb Z\)
\[
\sum_{n\in\mathbb Z} g(\theta+n)
\]
на самом деле **конечная** (uniform по \(\theta\)). И тогда:

- никакой **dominated convergence**
- никакой **Summable-integral-norm** пляски
- просто **Finset.sum** + линейность интеграла.

Ниже — ровно “1–2 леммы”, которые превращают `integral_P_A_eq_arch_term` в маленький calc.

---

## 0) Мини‑словарик (чтоб не было магии)

- **`tsum`**: бесконечная сумма \(\sum'_{n}\). В Lean это **`∑'`**.
- **`Finset`**: конечное множество (список без повторов). В Lean — **`Finset`**, сумма по нему — **`∑ n in S, ...`**.
- **`HasCompactSupport`**: “функция ноль вне компакта”; у тебя это реально даёт “вне \([-B,B]\) всё ноль”.
- **`intervalIntegral`**: интеграл \(\int_a^b\) на отрезке. В Lean — **`∫ x in a..b, f x`**.
- **`HasSum`**: “ряд сходится к …”. Это то, чем вы уже пользуетесь через **`Integrable.hasSum_intervalIntegral`**.

---

## 1) Лемма №1: “вне большого диапазона по n — ноль” (убивает `tsum`)

Идея: если \(|n| \ge B+1\), то для \(\theta\in[-1/2,1/2]\)
\[
|\theta+n| \ge |n| - |\theta| \ge (B+1) - 1/2 > B
\Rightarrow g(\theta+n)=0.
\]

В Lean ты это оформляешь так (скелет; имена лемм `abs_add`/`abs_sub` могут отличаться, но смысл 1:1):

```lean
-- Choose N large enough so that |n| > N ⇒ |θ + n| ≥ B for θ∈[-1/2,1/2]
lemma g_add_int_eq_zero_of_large
  (B t : ℝ) (hB : 0 < B) :
  ∃ N : ℕ, ∀ θ, θ ∈ Set.Icc (-1/2 : ℝ) (1/2) →
    ∀ n : ℤ, (N : ℝ) < |(n : ℝ)| → g B t (θ + (n : ℝ)) = 0 := by
  classical
  refine ⟨Nat.ceil (B + 1), ?_⟩
  intro θ hθ n hn
  -- from θ∈[-1/2,1/2] get |θ| ≤ 1/2
  have hθabs : |θ| ≤ (1/2 : ℝ) := by
    -- use abs_le.mpr with bounds from hθ
    exact (abs_le.mp ?_)  -- you'll fill the trivial bound
  -- show |θ + n| ≥ B
  have hbig : B ≤ |θ + (n : ℝ)| := by
    -- triangle inequality rearranged: |n| ≤ |θ+n| + |θ|
    -- so |n| - |θ| ≤ |θ+n|
    have : |(n : ℝ)| - |θ| ≤ |θ + (n : ℝ)| := by
      -- lemma typically: sub_le_iff_le_add + abs_add
      -- or: by have := (abs_add θ (n:ℝ)); linarith
      sorry
    -- now use hn plus N≥B+1 to get |n| - |θ| ≥ B
    have hN : B + 1 ≤ (Nat.ceil (B + 1) : ℝ) := by
      -- lemma: le_natCeil (B+1)
      sorry
    have : B ≤ |(n : ℝ)| - |θ| := by
      -- from hn and hθabs and hN: |n| - |θ| > B
      sorry
    exact le_trans this (by simpa using this_2)
  -- now apply your existing cutoff lemma
  exact g_eq_zero_of_abs_ge B t (θ + (n : ℝ)) hB hbig
```

Смысл: ты получил **uniform finite support in n** на торе.

---

## 2) Лемма №2: `tsum` превращаем в `Finset.sum` и спокойно меняем местами с интегралом

Тут два шага:

### 2.1 Pointwise: `∑' n` = `∑ n in S`
Берём
\[
S := \{n\in\mathbb Z : |n|\le N\}
\]
и доказываем, что снаружи \(S\) всё ноль ⇒ бесконечная сумма равна конечной.

В mathlib обычно есть готовая лемма типа:

- **`tsum_eq_sum`** (если **`support`** конечна), или
- **`tsum_eq_finset_sum`** / **`tsum_eq_sum_of_support_subset`** (варианты).

Скелет:

```lean
lemma tsum_eq_finset_sum_of_outside_zero
  {β : Type*} [TopologicalSpace β] [AddCommMonoid β] [T2Space β] [CompleteSpace β]
  (f : ℤ → β) (S : Finset ℤ) (hz : ∀ n, n ∉ S → f n = 0) :
  (∑' n : ℤ, f n) = ∑ n in S, f n := by
  classical
  -- typically:
  -- simpa using (tsum_eq_sum (by ...))
  -- or use `tsum_eq_sum_of_finite_support` pattern
  sorry
```

### 2.2 Интеграл: меняем местами “интеграл” и “конечную сумму”
Это дешево:

```lean
have :
  (∫ θ in (-1/2 : ℝ)..(1/2), ∑ n in S, g B t (θ + (n : ℝ)))
    = ∑ n in S, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ))) := by
  -- lemma name usually: intervalIntegral.integral_finset_sum
  -- may need `Integrable` but it's easy from continuity on compact interval
  simpa using (intervalIntegral.integral_finset_sum (f := fun n θ => g B t (θ + (n:ℝ))) (s := S))
```

---

## 3) Итоговая “периодизация” без доминированной сходимости

Твоя старая тяжёлая часть `hswap` заменяется цепочкой:

1) `tsum` → `Finset.sum` pointwise на \([-1/2,1/2]\) (лемма №1 + №2.1)  
2) интеграл от `Finset.sum` → `Finset.sum` интегралов (линейность)  
3) `Finset.sum` интегралов = `tsum` интегралов (потому что снаружи ноль)  
4) `tsum` интегралов = `∫ g` через **`Integrable.hasSum_intervalIntegral`** (ваш `hsum_base/hsum`)

Скелет‑код для заменяющего куска:

```lean
lemma intervalIntegral_periodize_eq_integral
  (B t : ℝ) (hB : 0 < B) :
  (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + (n : ℝ)))
    = ∫ x, g B t x := by
  classical
  -- pick N with outside-zero
  obtain ⟨N, hN⟩ := g_add_int_eq_zero_of_large (B:=B) (t:=t) hB
  let S : Finset ℤ := (Finset.Icc (-(N:ℤ)) (N:ℤ))
  have htsum : ∀ θ, θ ∈ Set.Icc (-1/2 : ℝ) (1/2) →
      (∑' n : ℤ, g B t (θ + (n : ℝ)))
        = ∑ n in S, g B t (θ + (n : ℝ)) := by
    intro θ hθ
    -- use tsum_eq_finset_sum_of_outside_zero with hz from hN
    sorry

  -- replace integrand by finite sum (either `integral_congr` or `ae_eq_of_forall_set_eq`)
  have hrewrite :
      (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + (n : ℝ)))
        = (∫ θ in (-1/2 : ℝ)..(1/2), ∑ n in S, g B t (θ + (n : ℝ))) := by
    -- use intervalIntegral.integral_congr + pointwise equality on the interval
    sorry

  -- swap integral and finite sum
  have hswap_fin :
      (∫ θ in (-1/2 : ℝ)..(1/2), ∑ n in S, g B t (θ + (n : ℝ)))
        = ∑ n in S, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ))) := by
    -- intervalIntegral.integral_finset_sum
    sorry

  -- now finish by comparing with the known HasSum over all integers
  have hint : Integrable (fun x => g B t x) := by
    -- your existing compact-support proof (cheap)
    sorry
  have hsum :
      HasSum (fun n : ℤ => ∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ)))
        (∫ x, g B t x) := by
    -- your existing `hsum` proof (the nice one)
    sorry

  -- since outside S the integrals are 0, the `tsum` equals the finset sum
  have htsum_int :
      (∑' n : ℤ, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ))))
        = ∑ n in S, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ))) := by
    sorry

  -- combine
  calc
    (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + (n : ℝ)))
        = ∑ n in S, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ))) := by
            simpa [hrewrite, hswap_fin]
    _ = (∑' n : ℤ, (∫ θ in (-1/2 : ℝ)..(1/2), g B t (θ + (n : ℝ)))) := by
            simpa [htsum_int]  -- direction may be swapped
    _ = ∫ x, g B t x := by
            exact (hsum.tsum_eq).symm
```

Да, тут есть несколько `sorry` — но они **маленькие** (алгебра/леммы про `tsum` finite support / `integral_congr`). Главное: **мы принципиально убрали** `integral_tsum_of_summable_integral_norm`, который у вас и вешает elaborator на 600+ секунд.

---

## 4) Теперь `integral_P_A_eq_arch_term` становится почти тривиальным

После леммы `intervalIntegral_periodize_eq_integral` всё:

```lean
lemma integral_P_A_eq_arch_term (B t : ℝ) (hB : 0 < B) :
    (∫ θ in (-1/2 : ℝ)..(1/2), P_A B t θ) =
      Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
  classical
  have hper :
    (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + (n : ℝ)))
      = ∫ x, g B t x := by
        simpa using intervalIntegral_periodize_eq_integral (B:=B) (t:=t) hB

  calc
    (∫ θ in (-1/2 : ℝ)..(1/2), P_A B t θ)
        = (2 * Real.pi) *
          (∫ θ in (-1/2 : ℝ)..(1/2), ∑' n : ℤ, g B t (θ + (n : ℝ))) := by
            simp [P_A, intervalIntegral.integral_const_mul]
    _ = (2 * Real.pi) * (∫ x, g B t x) := by
            simpa [hper]
    _ = Q3.arch_term (fun ξ => Q3.fejer_heat_window B t ξ) := by
            -- g = a * w, a_star = 2π a, and fejer_heat_window = w
            unfold Q3.arch_term Q3.a_star g
            simp [Q3.fejer_heat_window]
```

---

## 5) Почему это должно реально ускорить elaboration

Потому что **главная боль** была тут:

- **`MeasureTheory.integral_tsum_of_summable_integral_norm`**  
- + перевод туда‑сюда между **`intervalIntegral`** и **`volume.restrict (Ioc ...)`**  
- + куча `simp`/`convert`/`ring` на каждом уровне.

Мы заменили это на:

- **pointwise finite support** ⇒ **`Finset.sum`**  
- + линейность интеграла по конечной сумме.

Это обычно компилируется мгновенно по сравнению с dominated convergence.

---

## 6) Про “подстановку параметров” (как ты просил)

В коде выше:

- **`B`**, **`t`** — параметры окна **`Φ_{B,t}`**  
- **`N`** — выбранный “обрезающий” порог для индекса **`n : ℤ`**  
- **`S : Finset ℤ`** — конечный диапазон целых, где реально есть вклад

You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

Если хочешь — следующим сообщением я могу:
- написать **самый короткий вариант** леммы “`tsum = finset_sum` при outside‑zero” (в mathlib есть готовые, просто надо подобрать имя),  
- и подсказать “какие `simp`‑наборы” лучше использовать, чтобы не будить elaborate‑монстра (типа меньше `ring`, больше `linarith`/`nlinarith` и явных `have`).

## USER
ТЕМА: Сдвиг τ в Q_nonneg_atoms_proof (закрыть леммы для любого τ)

Контекст
- Файл: Q3/Proofs/Q_nonneg_atoms_proof.lean
- Нужно закрыть:
  1) Q_single_atom_nonneg (любой τ)
  2) Q_nonneg_on_atoms_of_A3_Fourier_RKHS
- Уже есть (готово):
  - Rayleigh_Q_identification.lean: honest_formula, rayleigh_Q_eq_Q, prime_term_eq_nodes_sum
  - P_A_Toeplitz_bridge.lean: A3_bridge_data_rayleigh_Fourier (Toeplitz(P_A) floor)
  - RKHS_cap_rayleigh.lean: weight_sum_le_rho_one, rho_one = 1/25
  - c_star_div_four_le_sub_rho_one
- Проблема: все эти леммы для τ=0 (окно по центру). Нужно для любого τ.

Что нужно (ключевые новые леммы про сдвиг):

A) Формула для сдвинутого атома
Определим t' = 1/(16π² t), Φ_{B,t,τ}(ξ) := fejer_heat_window B t (ξ - τ).
Нужно:
  Fejer_heat_atom B t τ
    = (2 / √(4πt)) * (Φ_{B,t',τ} + Φ_{B,t',-τ})
(это прямое раскрытие, но важно как лемма)

B) “Сдвинутая” периодизация и Rayleigh‑Q
Определить:
  g_τ(B,t,ξ) := Q3.a ξ * w B t (ξ - τ)
  P_A_τ(B,t,θ) := 2π * Σ_{m∈ℤ} g_τ(B,t,θ+m)

Нужна лемма (аналог integral_P_A_eq_arch_term, honest_formula):
  1) ∫_{-1/2}^{1/2} P_A_τ(B,t,θ) dθ = arch_term (Φ_{B,t,τ})
  2) RQ(Toeplitz(P_A_τ) - T_P_comp, basis0)
     = arch_term(Φ_{B,t,τ}) - (1/(2M+1)) * Σ w_Q(n) Φ_{B,t,τ}(xi_n)

И, опционально, рескейл:
  rayleigh_Q_eq_Q_shift:
     RQ(Toeplitz(P_A_τ), basis0) - (2M+1) RQ(T_P_comp, basis0) = Q(Φ_{B,t,τ})

C) Нижняя оценка (самое тяжёлое)
Нужно показать, что A3 floor работает для P_A_τ:
  P_A_τ(B_min, t_sym, θ) ≥ c_star  для всех θ ∈ [-1/2,1/2] и всех τ
ИЛИ хотя бы:
  RayleighLowerBound(Toeplitz(P_A_τ)) ≥ c_star

Идея: понять, как сдвиг в ξ влияет на P_A_τ(θ) и почему floor не ломается.

D) Support/prime‑term
Если |τ| + B ≤ K, то Φ_{B,t,τ} имеет support ⊆ [-K,K].
Нужно: prime_term_eq_nodes_of_support для Φ_{B,t,τ} (скорее уже выводится).

Дальше:
- A3 bridge + RKHS cap ⇒
  Q(Φ_{B,t,τ}) ≥ c_star/4 - rho_one > 0
- Линейность Q + A) ⇒ Q(Fejer_heat_atom B t τ) ≥ 0
- Потом суммирование по атомам ⇒ Q_nonneg_on_atoms_of_A3_Fourier_RKHS

Файлы:
- Q3/Proofs/Rayleigh_Q_identification.lean (куда добавить shift‑леммы)
- Q3/Proofs/Q_nonneg_atoms_proof.lean (конечная склейка)
- A3_FLOOR_v22_stage4_floor.lean (для пола, если нужен перенос)

Если видишь другой, более короткий трюк, бери его.
Главное: закрыть τ‑общий случай без новых аксиом.

## ASSISTANT
Ы  
Вот как я бы переписал твой запрос “по-человечески” (без потери стиля), а потом дам прямой план, как закрыть **τ‑общий** случай в **Lean**.

## Переписанный запрос

**ТЕМА:** сдвиг **τ** в `Q_nonneg_atoms_proof` — закрыть леммы для **любого τ**.

**Контекст**
- Файл: `Q3/Proofs/Q_nonneg_atoms_proof.lean`
- Нужно закрыть:
  1) `Q_single_atom_nonneg` (**любой τ**)
  2) `Q_nonneg_on_atoms_of_A3_Fourier_RKHS`
- Уже есть (готово):
  - `Rayleigh_Q_identification.lean`: `honest_formula`, `rayleigh_Q_eq_Q`, `prime_term_eq_nodes_sum`
  - `P_A_Toeplitz_bridge.lean`: `A3_bridge_data_rayleigh_Fourier` (нижняя оценка для **Toeplitz(P_A)**)
  - `RKHS_cap_rayleigh.lean`: `weight_sum_le_rho_one`, `rho_one = 1/25`
  - `c_star_div_four_le_sub_rho_one`
- Проблема: всё сейчас заточено под **τ = 0** (центрированное окно). Нужно протащить на **любой τ**.

**Что нужно добавить**
A) Формула раскрытия “сдвинутого атома” через **сдвинутые окна**  
B) “Сдвинутая” периодизация и формулы типа `integral_P_A_eq_arch_term`, `honest_formula`  
C) Самое жёсткое: нижняя оценка/пол для сдвига (или обойти её)  
D) Support/prime-term: если `|τ| + B ≤ K`, то support ⊆ `[-K, K]` и можно резать prime sum до **Nodes K**.

---

Дальше — “как реально это закрыть”, без новых аксиом.

# Словарь (чтоб дальше было максимально по делу)

- **τ** — параметр сдвига (центр атома).  
- **Φ_{B,t,τ}** — “окно” (**Fejér×heat**), сдвинутое на **τ**: `ξ ↦ Φ(ξ-τ)` (в твоём плане).  
- **Support** (**support**) — множество точек, где функция ≠ 0.  
- **Periodization** (**периодизация**) — сумма по целым: `∑_{m∈ℤ} f(θ+m)` (делает 1‑периодическую функцию).  
- **P_A**/**P_A_τ** — “символ” (**symbol**) для **Toeplitz**-матрицы. В PDF это `P_A(θ)=2π∑ g(θ+m)`【10:11†RH_Q3.pdf†L13-L49】.  
- **arch_term** — архимедов вклад: `∫ a_star ξ * Φ ξ`【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L9-L19】.  
- **prime_term** — праймовый вклад: сумма по узлам `ξ_n` с весами `w_Q(n)`.  
- **Toeplitz** (**ToeplitzMatrix**) — матрица/оператор, задаваемый символом **P_A**.  
- **Rayleigh quotient** (**RQ**) — `⟨T v, v⟩ / ⟨v, v⟩`.  
- **Nodes K** — конечный тип узлов `ξ_n` в `[-K,K]` (чтоб `∑'` превратить в конечную сумму).  
- **RKHS cap** — оценка нормы прайм‑оператора (у тебя `rho_one = 1/25`).  
- **c_star** — “пол” (uniform archimedean floor), у тебя дальше используется `c_star/4 - rho_one > 0`.

---

# Главный хак: сначала убей “periodization bottleneck”, потом τ станет просто параметром

У тебя уже зафиксировано, что **единственное тяжёлое место** — это `integral_P_A_eq_arch_term`, и оно сейчас “зависает” из‑за тяжёлого доминированного обмена `∫` и `∑'`【10:1†proshka_rayleigh_qid_debug_2026_01_16.md†L1-L36】【10:13†proshka_rayleigh_qid_debug_2026_01_16.md†L1-L36】.

А в PDF прямым текстом сказано: **периодизационная сумма конечна**, потому что `g` имеет компактный support【4:11†RH_Q3.pdf†L48-L50】. Это значит:

> не надо `integral_tsum_of_summable_integral_norm` вообще;  
> надо переписать `∑' m` как **Finset.sum** по конечному диапазону `m`, зависящему от `B` и `τ`.

Это сразу решает:
- `integral_P_A_eq_arch_term` (τ=0),
- и “тот же самый лемматический пакет” для любого τ.

---

# A) Лемма раскрытия атома через сдвинутые окна (лёгкая)

Ты хочешь (и это реально правильная “ключ-лемма” для склейки):

> `Fejer_heat_atom B t τ = (2/√(4πt)) * (Φ_{B,t',τ} + Φ_{B,t',-τ})`  
> где `t' = 1/(16π² t)`.

Это чисто **definally-equal** раскрытие (если определения совпадают с тем, что ты описал). Делай это в том месте, где у тебя определён `Fejer_heat_atom` и `fejer_heat_window`.

Мини‑скелет для Lean:

```lean
-- A) shift-window
def Φ (B t τ : ℝ) : ℝ → ℝ := fun ξ => Q3.fejer_heat_window B t (ξ - τ)

-- t' = 1/(16π^2 t)
def t' (t : ℝ) : ℝ := 1 / (16 * Real.pi^2 * t)

lemma Fejer_heat_atom_eq (B t τ : ℝ) :
  Q3.Fejer_heat_atom B t τ
    = (2 / Real.sqrt (4*Real.pi*t)) * (Φ B (t' t) τ + Φ B (t' t) (-τ)) := by
  -- обычно это simp/ring_nf по определениям
  simp [Q3.Fejer_heat_atom, Φ, t', sub_eq_add_neg, add_comm, add_left_comm, add_assoc]
```

**Про “подстановку переменных”** (чтобы не было магии):  
You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

# B) Периодизация + Rayleigh‑Q для сдвига: делай “общий periodize‑лемматический двигатель”

## B1) ∫ P_A_τ = arch_term(Φ_{B,t,τ})

В PDF это базовый факт “period‑1 normalization audit”【10:11†RH_Q3.pdf†L13-L72】, а в твоём проекте он ровно формулируется как:

`∫_{-1/2}^{1/2} (2π * ∑' m, g(θ+m)) dθ = ∫_ℝ a_star ξ * Φ ξ dξ`【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L13-L19】.

Твой текущий код пытается доказать это “по‑взрослому” через `HasSum_intervalIntegral` и нормы, и именно он зависает【10:1†proshka_rayleigh_qid_debug_2026_01_16.md†L28-L55】.

### Быстрый вариант (тот, который и должен компилироваться)

Поскольку `g_τ` **имеет компактный support** (он нулевой вне `[τ-B, τ+B]`), то для фиксированного `θ∈[-1/2,1/2]` существует **конечное** множество целых `m`, где `g_τ(θ+m)≠0`. То есть `tsum` равен `Finset.sum`.

Схема:

1) доказываешь лемму “вне большого диапазона `m` функция = 0”;  
2) из этого: `∑' m, f m = ∑ m in S, f m`  
3) `∫` от конечной суммы = сумма интегралов  
4) `∫_{-1/2}^{1/2} f(θ+m) dθ = ∫_{m-1/2}^{m+1/2} f(x) dx`  
5) сумма по `m` склеивается в `∫_ℝ f(x) dx` (потому что support компактный).

И это ровно тот “finite sum because compact support” аргумент из PDF【4:11†RH_Q3.pdf†L48-L50】.

### Что именно добавить в Lean

1) Определи сдвинутый `g_τ` и `P_A_τ`:

```lean
def gτ (B t τ : ℝ) : ℝ → ℝ :=
  fun ξ => Q3.a ξ * Q3.fejer_heat_window B t (ξ - τ)

def P_Aτ (B t τ : ℝ) : ℝ → ℝ :=
  fun θ => 2 * Real.pi * ∑' (m : ℤ), gτ B t τ (θ + m)
```

2) Лемма про support:

- `support (gτ B t τ) ⊆ Icc (τ-B) (τ+B)` (и в частности компактность).  
- и “margin” версия: если `|τ| + B ≤ K`, то `support ⊆ Icc (-K) K`.  
Это именно твой пункт D; он нужен, чтобы **резать prime sum** до `Nodes K`.

3) Главная “fast” лемма:

```lean
lemma integral_periodize_of_compactSupport
  (f : ℝ → ℝ) (K : ℝ) (hK : 0 ≤ K)
  (hsupp : Function.support f ⊆ Set.Icc (-K) K) :
  (∫ θ in (-1/2:ℝ)..(1/2), (∑' m:ℤ, f (θ + m))) = ∫ x, f x := by
  -- ключ: для θ∈[-1/2,1/2] только finitely many m
  -- 1) выбери N = ⌈K + 1⌉ (или ⌈K + 1/2⌉)
  -- 2) докажи: если |m| > N, то f(θ+m)=0
  -- 3) перепиши tsum в Finset.sum по Icc(-N,N)
  -- 4) протолкни ∫ через Finset.sum
  -- 5) intervalIntegral.integral_comp_add_right -> смена переменной
  -- 6) склейка интервалов -> integral over ℝ (support)
  ...
```

4) Из неё сразу:

```lean
lemma integral_P_Aτ_eq_arch_term (B t τ : ℝ) (hB : 0 < B) :
  (∫ θ in (-1/2:ℝ)..(1/2), P_Aτ B t τ θ)
    = Q3.arch_term (Φ B t τ) := by
  -- раскрыть P_Aτ, gτ, arch_term; применить integral_periodize_of_compactSupport
  -- + тот факт что a_star = 2π * a
  ...
```

И это — именно цель из debug‑досье【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L13-L19】, только доказанная “быстро”.

Если не хочешь писать этот движок с нуля — в проекте уже есть старые леммы `periodize` в архиве (как минимум упомянуто в debug)【10:13†proshka_rayleigh_qid_debug_2026_01_16.md†L17-L35】. Можно вытащить их аккуратно и “специализировать” на `T=1` и на `intervalIntegral`.

**Про “подстановку переменных”**:  
You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

---

## B2) Сдвинутая Rayleigh‑формула (аналог `honest_formula`)

Тут два факта из PDF критичны:

1) **Нормировка**: при использовании **нормированных** `v_n^(M)` прайм часть получает множитель `1/(2M+1)`, поэтому в правильной “comparison” формуле появляется `(2M+1)` только на прайм-операторе (а не на всём)【4:7†RH_Q3.pdf†L59-L87】.  
2) “Finite sum” аргумент для `P_A` — снова тот же: compact support ⇒ конечная сумма【4:11†RH_Q3.pdf†L48-L50】.

То есть для τ‑версии ты просто копируешь структуру `honest_formula`, заменив `P_A` → `P_Aτ`, `g` → `gτ`, `Φ` → `Φ ... τ`, и в конце получаешь:

- `∫ P_Aτ = arch_term(Φ_{τ})` (только что сделали),
- `prime_term` редуцируется до **Nodes** по support,
- диагональ `T_P_comp` вычисляется так же, как в τ=0 версии (потому что это чисто алгебра по определению компрессии).

---

# D) Support/prime-term: это должно стать “автоматической” леммой

Твоя логика “если `|τ| + B ≤ K`, то support ⊆ `[-K,K]` ⇒ prime_term_eq_nodes_of_support” — ровно то, что нужно.

В PDF это отражено в формулировке плотности конуса: атомы берутся с условием `|τ| + B ≤ K`【8:4†RH_Q3.pdf†L1-L41】 (потому что это гарантирует, что они реально лежат в **W_K**).

И в orchestrator‑заметках прямо был пойман тот же баг: если не требовать margin, можно вылезти в `[-2K,2K]`【10:0†PROJECT_ORCHESTRATOR.md†L46-L49】.

Так что в Lean делай:

- `support_Φ_subset_Icc`  
- `support_Φ_subset_Icc_of_margin (h : |τ| + B ≤ K)`  
- и дальше просто “plug in” в существующую `prime_term_eq_nodes` (она у тебя уже есть по debug‑списку)【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L33-L35】.

---

# C) Самое тяжёлое: как протащить “пол/нижнюю оценку” через τ

Тут два реальных варианта. Я дам оба; выбирай тот, который меньше ломает твою текущую архитектуру.

## Вариант C1 (прямой): обобщить A3 floor на τ через “shift‑robust core mass”

В PDF есть уже готовый кирпич: **Lemma 8.13 (Shift‑robust core mass)** — оценка массы Fejér‑шапки на любом сдвиге, пока интервал длины `2r` не вылезает за `[-B,B]`【10:2†RH_Q3.pdf†L32-L49】.

Это ровно то, что тебе нужно, чтобы сделать τ‑версию “core contribution” (типа Lemma 8.12) и потом τ‑версию “archimedean floor” (типа Lemma 8.14).

Если очень по‑простому, proof‑паттерн такой:

- берёшь ядро `[τ-r, τ+r]` (или `[−r,r]` в переменной `x=ξ-τ`),
- на нём lower bound на **Λ_B(x-τ)** даёт Lemma 8.13【10:2†RH_Q3.pdf†L32-L49】,
- Gaussian factor на core даёт `≥ e^{-4π² t r²}` (как и в PDF),
- `a(ξ)` на core lower bound’ится через `inf_{|ξ|≤...} a(ξ)` (у тебя уже есть slope/monotonicity идеи; в PDF это Lemma 8.15/8.16【10:5†RH_Q3.pdf†L37-L66】),
- tail’ы bounding через `L∞` нормы на компакте.

Дальше стандартный шаг “floor = A0 − ½ * LipschitzLoss” (в PDF это Lemma 8.14)【10:2†RH_Q3.pdf†L63-L99】.

То есть: **τ входит только в core‑массу**, и именно это место уже закрыто готовой “shift‑robust” леммой.

Минус: это реально работа в `A3_FLOOR_v22_stage4_floor.lean`‑стиле (много интегральной арифметики).

## Вариант C2 (короче): не доказывать “для всех τ” напрямую, а поднять с сетки через Lipschitz

Если тебе нужно именно “для любого τ” как итог, но доказательство хочется сделать дискретным — в PDF есть готовый лифт:

**Lemma G.22 (Grid lift by Lipschitz margin)**: если на сетке `{τ_j}` с mesh `Δ` у тебя `Q(τ_j) ≥ c_*`, а `Δ ≤ c_*/(4 L_Q(K))`, то на всём интервале получаешь `Q(τ) ≥ c_*/2`【9:0†RH_Q3.pdf†L64-L73】.

Это прям “анти‑боль” для τ:
- ты доказываешь неравенство на конечном наборе точек (или на тех τ, которые реально появляются в **A1 hat interpolation**),
- и потом одним махом расширяешь на все τ.

Плюс: Это органично стыкуется с модулем **A1′ + A2** (плотность + Lipschitz), и это реально часть архитектуры “density + continuity propagates positivity”【10:6†RH_Q3.pdf†L40-L44】.

Минус: ты должен иметь **L_Q(K)** (у тебя, судя по стеку, это в A2) и некоторый запас `c_*` на сетке.

---

# Как это склеить в твоих двух целевых леммах

## 1) `Q_single_atom_nonneg` (любой τ)

Скелет логики:

1) Через **A)** переписываешь **Fejer_heat_atom** как линейную комбинацию двух **сдвинутых окон** (τ и −τ).  
2) Используешь **линейность** **Q** ⇒ достаточно показать `Q(Φ_{τ}) ≥ 0` для сдвинутого окна.  
3) Для `Q(Φ_{τ})` используешь **B)**: `Q = arch_term − prime_term` и/или `rayleigh_Q_eq_Q_shift`.  
4) Для нижней оценки: либо C1 (прямой τ‑floor), либо C2 (grid‑lift).

Технически: ты уже знаешь, что в **Rayleigh identification** надо аккуратно держать множитель `(2M+1)` только на прайм‑оператор (это из Theorem 8.10)【4:7†RH_Q3.pdf†L59-L87】.

## 2) `Q_nonneg_on_atoms_of_A3_Fourier_RKHS`

Тут у тебя уже заготовка:
- **A3 bridge + RKHS cap** ⇒ `Q(Φ) ≥ c_star/4 − rho_one > 0`.  
У тебя это ровно “c_star_div_four_le_sub_rho_one” + `rho_one=1/25` (и PDF говорит, что uniform RKHS cap независим от K и именно для этого и нужен)【10:6†RH_Q3.pdf†L73-L87】.

Так что как только ты сделал τ‑версию “Rayleigh/Q identification” (B+D) и обеспечил τ‑совместимость lower bound’а (C1 или C2), дальше всё “складывается само”.

---

# Итог: что именно я бы сделал в файлах

## `Q3/Proofs/Rayleigh_Q_identification.lean`
1) Добавить **shift**‑версии определений: **Φ**, **gτ**, **P_Aτ**.  
2) Заменить/добавить “быстрый” вариант `integral_P_A_eq_arch_term` через finite‑sum. Это прямо соответствует заметке “only heavy point … hangs”【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L36-L36】 и PDF‑заметке про конечность суммы【4:11†RH_Q3.pdf†L48-L50】.  
3) На его базе получить `integral_P_Aτ_eq_arch_term`.  
4) Протащить `honest_formula` → `honest_formula_shift` (или как тебе удобнее назвать).

## `Q3/Proofs/Q_nonneg_atoms_proof.lean`
1) Лемма **A** (раскрытие атома) + линейность Q.  
2) `Q(Φ_{τ})` закрываешь через новый `honest_formula_shift` и уже имеющиеся `A3_bridge...` + `RKHS_cap...`.

## (если нужно) `A3_FLOOR_v22_stage4_floor.lean`
- Если идёшь по **C1**, сюда добавляется τ‑robust версия core/floor на базе Lemma 8.13【10:2†RH_Q3.pdf†L32-L49】.

---

# Мой выбор “самый короткий трюк”
Если цель — **быстро закрыть τ‑общий случай в Lean без превращения всего в бесконечные интегральные бойни**, то:

1) **Убить зависание**: переписать periodization-интеграл через конечную сумму (support ⇒ finite). Это must-have и для τ=0, и для τ≠0【4:11†RH_Q3.pdf†L48-L50】【10:13†proshka_rayleigh_qid_debug_2026_01_16.md†L17-L35】.  
2) Для τ‑универсальности внизу выбрать **C2 (grid lift)**, если у тебя A2 Lipschitz уже есть и у тебя в A1 реально используется сетка/шапки. Lemma G.22 ровно для этого【9:0†RH_Q3.pdf†L64-L73】.

---

## Источники/опорные места (чтоб было куда тыкать)
- Определение атомов и условие `|τ| + B ≤ K` в плотности конуса: 【8:4†RH_Q3.pdf†L1-L41】  
- Нормировка периода и равенство `∫ P_A = 2π ∫ g` (а значит `= arch_term`): 【10:11†RH_Q3.pdf†L13-L72】  
- “Сумма периодизации конечна из-за compact support”: 【4:11†RH_Q3.pdf†L48-L50】  
- Поправка нормировок `(2M+1)` только на прайм‑оператор (ключ к Rayleigh идентификации): 【4:7†RH_Q3.pdf†L59-L87】  
- Grid‑lift через Lipschitz margin: 【9:0†RH_Q3.pdf†L64-L73】  
- Debug по зависанию и точная формулировка того, что ломается: 【10:1†proshka_rayleigh_qid_debug_2026_01_16.md†L1-L36】【10:3†proshka_rayleigh_qid_debug_2026_01_16.md†L40-L61】  
- Shift‑robust core mass (если пойдёшь по C1): 【10:2†RH_Q3.pdf†L32-L49】  
- Про margin‑условие для support в коде/оркестраторе: 【10:0†PROJECT_ORCHESTRATOR.md†L46-L49】

---

### Ссылки на файлы из репы (чтоб было удобно открыть)
fileciteturn10file1 fileciteturn10file0 fileciteturn10file2 fileciteturn10file11 fileciteturn10file9

И ещё: базовый контекст проекта и инварианты (если ты их держишь как “истину”):  
fileciteturn1file32 fileciteturn1file46 fileciteturn1file49

## USER
The user approved the approach with a caveat, so I’ll proceed by locating relevant definitions for the new ShiftedWindows file and preparing to create it and make corresponding edits as needed. Next, I’ll search the repo for key terms like fejer_heat_window and related names to align the new code properly.

Deciding to read AGENTS.md for local instructions

Given the task complexity and user’s prior mention, I’ll open the AGENTS.md file to check for any additional or overriding developer instructions that could affect the implementation approach.

Erstellt
ShiftedWindows.lean
/-
Shifted windows and periodization for tau-shifted atoms.
-/

import Mathlib
import Q3.Axioms
import Q3.Basic.Defs

set_option linter.mathlibStandardSet false

open scoped BigOperators Real Classical
open MeasureTheory

noncomputable section

namespace Q3

def phi_shift (B t τ : ℝ) (ξ : ℝ) : ℝ :=
  fejer_heat_window B t (ξ - τ)

def g_shift (B t τ : ℝ) (ξ : ℝ) : ℝ :=
  a ξ * phi_shift B t τ ξ

def P_A_shift (B t τ : ℝ) (θ : ℝ) : ℝ :=
  2 * Real.pi * ∑' (m : ℤ), g_shift B t τ (θ + m)

end Q3

namespace Q3.Proofs.ShiftedWindows

open Q3

lemma phi_shift_support (B t τ ξ : ℝ) (hB : 0 < B) (h : B < |ξ - τ|) :
    Q3.phi_shift B t τ ξ = 0 := by
  unfold Q3.phi_shift Q3.fejer_heat_window
  have h1 : 1 - |ξ - τ| / B < 0 := by
    have : 1 < |ξ - τ| / B := by
      rw [one_lt_div hB]
      exact h
    linarith
  simp [max_eq_left (le_of_lt h1)]

lemma g_shift_support (B t τ ξ : ℝ) (hB : 0 < B) (h : B < |ξ - τ|) :
    Q3.g_shift B t τ ξ = 0 := by
  simp [Q3.g_shift, phi_shift_support B t τ ξ hB h]

lemma continuous_a : Continuous Q3.a := by
  have hpi : (2 * Real.pi) ≠ 0 := by nlinarith [Real.pi_pos]
  have h :
      (fun ξ => Q3.a ξ) = fun ξ => (1 / (2 * Real.pi)) * Q3.a_star ξ := by
    funext ξ
    calc
      (1 / (2 * Real.pi)) * Q3.a_star ξ
          = (1 / (2 * Real.pi)) * (2 * Real.pi * Q3.a ξ) := by simp [Q3.a_star]
      _ = Q3.a ξ := by field_simp [hpi]; ring
  simpa [h] using (Q3.a_star_continuous.const_mul (1 / (2 * Real.pi)))

lemma continuous_fejer_heat_window (B t : ℝ) :
    Continuous (fun ξ => Q3.fejer_heat_window B t ξ) := by
  unfold Q3.fejer_heat_window
  have h_lin : Continuous (fun ξ => 1 - |ξ| / B) := by
    have h_abs : Continuous (fun ξ => |ξ|) := by
      simpa using (continuous_abs : Continuous fun ξ : ℝ => |ξ|)
    have h_div : Continuous (fun ξ => |ξ| / B) := by
      simpa [div_eq_mul_inv] using h_abs.mul continuous_const
    exact continuous_const.sub h_div
  have h_max : Continuous (fun ξ => max (0 : ℝ) (1 - |ξ| / B)) :=
    (continuous_const).max h_lin
  have h_pow : Continuous (fun ξ => ξ ^ 2) := continuous_pow 2
  have h_poly : Continuous (fun ξ => (-4 * Real.pi ^ 2 * t) * (ξ ^ 2)) := continuous_const.mul h_pow
  have h_exp : Continuous (fun ξ => Real.exp (-4 * Real.pi ^ 2 * t * ξ ^ 2)) := by
    simpa [mul_assoc] using (Real.continuous_exp.comp h_poly)
  exact h_max.mul h_exp

lemma continuous_phi_shift (B t τ : ℝ) :
    Continuous (fun ξ => Q3.phi_shift B t τ ξ) := by
  simpa [Q3.phi_shift] using
    (continuous_fejer_heat_window B t).comp (continuous_id.sub continuous_const)

lemma continuous_g_shift (B t τ : ℝ) :
    Continuous (fun ξ => Q3.g_shift B t τ ξ) := by
  exact continuous_a.mul (continuous_phi_shift B t τ)

lemma phi_shift_support_of_margin (B t τ K : ℝ) (hB : 0 < B) (hK : |τ| + B ≤ K) :
    ∀ ξ, K < |ξ| → Q3.phi_shift B t τ ξ = 0 := by
  intro ξ hξ
  have htri : |ξ| ≤ |ξ - τ| + |τ| := by
    have h := abs_add (ξ - τ) τ
    simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using h
  have h_lower : |ξ| - |τ| ≤ |ξ - τ| := by linarith
  have hB' : B < |ξ - τ| := by
    have : B < |ξ| - |τ| := by linarith [hK, hξ]
    linarith [h_lower]
  exact phi_shift_support B t τ ξ hB hB'

lemma g_shift_support_of_margin (B t τ K : ℝ) (hB : 0 < B) (hK : |τ| + B ≤ K) :
    ∀ ξ, K < |ξ| → Q3.g_shift B t τ ξ = 0 := by
  intro ξ hξ
  simp [Q3.g_shift, phi_shift_support_of_margin B t τ K hB hK ξ hξ]

lemma g_shift_zero_of_large_m (B t τ θ : ℝ) (m : ℤ) (hB : 0 < B)
    (hθ : θ ∈ Set.Icc (-1/2 : ℝ) (1/2))
    (hm : (⌈B + |τ|⌉ : ℤ) + 1 < |m|) :
    Q3.g_shift B t τ (θ + m) = 0 := by
  have hm_real : B + |τ| + 1 < |(m : ℝ)| := by
    have hm' : (⌈B + |τ|⌉ : ℝ) + 1 < |m| := by exact_mod_cast hm
    have hceil : B + |τ| ≤ ⌈B + |τ|⌉ := Int.le_ceil (B + |τ|)
    have h_abs : (|m| : ℝ) = |(m : ℝ)| := by simp [Int.cast_abs]
    linarith [hceil, hm', h_abs]
  have hθ_abs : |θ| ≤ (1/2 : ℝ) := by
    rw [abs_le]
    constructor <;> linarith [hθ.1, hθ.2]
  have hθτ : |θ - τ| ≤ |θ| + |τ| := by
    have h := abs_add θ (-τ)
    simpa [sub_eq_add_neg, abs_neg, add_comm, add_left_comm, add_assoc] using h
  have hθτ' : |θ - τ| ≤ |τ| + (1/2 : ℝ) := by
    linarith [hθ_abs, hθτ]
  have htri : |(m : ℝ)| - |θ - τ| ≤ |(m : ℝ) + θ - τ| := by
    have h := abs_add ((m : ℝ) + θ - τ) (-(θ - τ))
    have h' : |(m : ℝ)| ≤ |(m : ℝ) + θ - τ| + |θ - τ| := by
      simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc, abs_neg] using h
    linarith
  have hB' : B < |(m : ℝ) + θ - τ| := by
    have hmid : B < |(m : ℝ)| - |θ - τ| := by
      linarith [hm_real, hθτ']
    linarith [htri, hmid]
  have hcast : |(m : ℝ) + θ - τ| = |θ + m - τ| := by ring_nf
  have hB'' : B < |θ + m - τ| := by simpa [hcast] using hB'
  have hBfinal : B < |(θ + m) - τ| := by
    simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using hB''
  exact g_shift_support B t τ (θ + m) hB hBfinal

lemma P_A_shift_tsum_eq_finite_sum (B t τ θ : ℝ) (hB : 0 < B)
    (hθ : θ ∈ Set.Icc (-1/2 : ℝ) (1/2)) :
    ∑' (m : ℤ), Q3.g_shift B t τ (θ + m) =
      ∑ m ∈ Finset.Icc (-(⌈B + |τ|⌉ + 1)) (⌈B + |τ|⌉ + 1),
        Q3.g_shift B t τ (θ + m) := by
  apply tsum_eq_sum
  intro m hm
  simp only [Finset.mem_Icc, not_and, not_le] at hm
  have h_large : (⌈B + |τ|⌉ : ℤ) + 1 < |m| := by
    by_cases h : m < -(⌈B + |τ|⌉ + 1)
    · have hm_neg : m < 0 := by omega
      simp [abs_of_neg hm_neg] at h
      exact h
    · push_neg at h
      have := hm h
      have hm_nonneg : 0 ≤ m := by omega
      simp [abs_of_nonneg hm_nonneg] at this
      exact this
  exact g_shift_zero_of_large_m B t τ θ m hB hθ h_large

lemma arch_term_eq_two_pi_integral_g_shift (B t τ : ℝ) :
    Q3.arch_term (fun ξ => Q3.phi_shift B t τ ξ) =
      2 * Real.pi * ∫ ξ, Q3.g_shift B t τ ξ := by
  have h :
      ∀ ξ, Q3.a_star ξ * Q3.phi_shift B t τ ξ =
        2 * Real.pi * (Q3.a ξ * Q3.phi_shift B t τ ξ) := by
    intro ξ
    simp [Q3.a_star]
    ring
  simp [Q3.arch_term, Q3.g_shift, h, MeasureTheory.integral_mul_left]

theorem integral_P_A_shift_eq_arch_term (B t τ : ℝ) (hB : 0 < B) :
    ∫ θ in (-1/2 : ℝ)..(1/2), Q3.P_A_shift B t τ θ =
      Q3.arch_term (fun ξ => Q3.phi_shift B t τ ξ) := by
  classical
  have hab : (-1/2 : ℝ) ≤ (1/2 : ℝ) := by norm_num
  let K : ℝ := |τ| + B
  let s : Finset ℤ := Finset.Icc (-(⌈K⌉ + 1)) (⌈K⌉ + 1)
  have hsupp : Function.support (fun ξ => Q3.g_shift B t τ ξ) ⊆ Set.Icc (-K) K := by
    refine Function.support_subset_iff'.2 ?_
    intro ξ hξ
    have hnot_abs : ¬ |ξ| ≤ K := by
      intro habs
      have h' : -K ≤ ξ ∧ ξ ≤ K := (abs_le.mp habs)
      exact hξ h'
    have hK : K < |ξ| := lt_of_not_ge hnot_abs
    exact g_shift_support_of_margin B t τ K hB (by simp [K]) ξ hK
  have hcompact : HasCompactSupport (fun ξ => Q3.g_shift B t τ ξ) := by
    exact HasCompactSupport.of_support_subset_isCompact isCompact_Icc hsupp
  have hint : Integrable (fun ξ => Q3.g_shift B t τ ξ) := by
    exact (continuous_g_shift B t τ).integrable_of_hasCompactSupport hcompact

  have h_eq_tsum :
      EqOn (fun θ => ∑' m : ℤ, Q3.g_shift B t τ (θ + m))
        (fun θ => ∑ m ∈ s, Q3.g_shift B t τ (θ + m)) ([[(-1/2 : ℝ), (1/2 : ℝ)]]) := by
    intro θ hθ
    have hθ' : θ ∈ Set.Icc (-1/2 : ℝ) (1/2 : ℝ) := by
      simpa [Set.uIcc_of_le hab] using hθ
    simpa [s, K] using P_A_shift_tsum_eq_finite_sum B t τ θ hB hθ'

  have h_int_eq :
      ∫ θ in (-1/2 : ℝ)..(1/2), ∑' m : ℤ, Q3.g_shift B t τ (θ + m) =
        ∫ θ in (-1/2 : ℝ)..(1/2), ∑ m ∈ s, Q3.g_shift B t τ (θ + m) := by
    exact intervalIntegral.integral_congr h_eq_tsum

  have h_int_sum :
      ∫ θ in (-1/2 : ℝ)..(1/2), ∑ m ∈ s, Q3.g_shift B t τ (θ + m) =
        ∑ m ∈ s, ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + m) := by
    refine intervalIntegral.integral_finset_sum ?_
    intro m hm
    have hcont : Continuous (fun θ => Q3.g_shift B t τ (θ + m)) := by
      simpa [add_comm, add_left_comm, add_assoc] using
        (continuous_g_shift B t τ).comp (continuous_id.add continuous_const)
    exact hcont.intervalIntegrable (μ:=volume) (-1/2 : ℝ) (1/2 : ℝ)

  have hsum_base :
      HasSum (fun n : ℤ =>
          ∫ x in (-1/2 : ℝ) + (n : ℝ)..(-1/2 : ℝ) + (n : ℝ) + 1, Q3.g_shift B t τ x)
        (∫ x, Q3.g_shift B t τ x) := by
    simpa using
      (MeasureTheory.Integrable.hasSum_intervalIntegral (μ:=volume)
        (f:=fun x => Q3.g_shift B t τ x) (y:=(-1/2 : ℝ)) hint)

  have hsum :
      HasSum (fun n : ℤ => ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + (n : ℝ)))
        (∫ x, Q3.g_shift B t τ x) := by
    refine (HasSum.congr_fun hsum_base ?_)
    intro n
    have hcomp :=
      intervalIntegral.integral_comp_add_right (f:=fun x => Q3.g_shift B t τ x) (d:=(n : ℝ))
        (a:=(-1/2 : ℝ)) (b:=(1/2 : ℝ))
    convert hcomp using 1 <;> ring

  have hsum_eq :
      (∑' n : ℤ, ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + (n : ℝ))) =
        ∑ n ∈ s, ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + (n : ℝ)) := by
    apply tsum_eq_sum
    intro n hn
    simp only [Finset.mem_Icc, not_and, not_le] at hn
    have h_large : (⌈K⌉ : ℤ) + 1 < |n| := by
      by_cases h : n < -(⌈K⌉ + 1)
      · have hn_neg : n < 0 := by omega
        simp [abs_of_neg hn_neg] at h
        exact h
      · push_neg at h
        have := hn h
        have hn_nonneg : 0 ≤ n := by omega
        simp [abs_of_nonneg hn_nonneg] at this
        exact this
    have h_eq0 :
        EqOn (fun θ => Q3.g_shift B t τ (θ + n)) (fun _ => (0 : ℝ))
          ([[(-1/2 : ℝ), (1/2 : ℝ)]]) := by
      intro θ hθ
      have hθ' : θ ∈ Set.Icc (-1/2 : ℝ) (1/2 : ℝ) := by
        simpa [Set.uIcc_of_le hab] using hθ
      simpa [K] using g_shift_zero_of_large_m B t τ θ n hB hθ' h_large
    have h_integral_zero :
        ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + n) =
          ∫ θ in (-1/2 : ℝ)..(1/2), (0 : ℝ) := by
      exact intervalIntegral.integral_congr h_eq0
    simpa using h_integral_zero

  have hsum_fin :
      ∑ n ∈ s, ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + (n : ℝ)) =
        ∫ x, Q3.g_shift B t τ x := by
    exact hsum_eq.symm.trans hsum.tsum_eq

  have h_integral :
      ∫ θ in (-1/2 : ℝ)..(1/2), ∑' m : ℤ, Q3.g_shift B t τ (θ + m) =
        ∫ x, Q3.g_shift B t τ x := by
    calc
      ∫ θ in (-1/2 : ℝ)..(1/2), ∑' m : ℤ, Q3.g_shift B t τ (θ + m)
          = ∫ θ in (-1/2 : ℝ)..(1/2), ∑ m ∈ s, Q3.g_shift B t τ (θ + m) := h_int_eq
      _ = ∑ m ∈ s, ∫ θ in (-1/2 : ℝ)..(1/2), Q3.g_shift B t τ (θ + m) := h_int_sum
      _ = ∫ x, Q3.g_shift B t τ x := hsum_fin

  rw [arch_term_eq_two_pi_integral_g_shift]
  simp [Q3.P_A_shift, intervalIntegral.integral_const_mul, h_integral]

end Q3.Proofs.ShiftedWindows

Bearbeitet
ShiftedWindows.lean
    linarith [htri, hmid]
  have hcast : |(m : ℝ) + theta - tau| = |theta + m - tau| := by ring_nf
  have hB'' : B < |theta + m - tau| := by simpa [hcast] using hB'
  have hcast : |(m : ℝ) + theta - tau| = |theta + (m : ℝ) - tau| := by
    simp [sub_eq_add_neg, add_comm, add_left_comm, add_assoc]
  have hB'' : B < |theta + (m : ℝ) - tau| := by simpa [hcast] using hB'
  have hBfinal : B < |(theta + m) - tau| := by
    · have hm_neg : m < 0 := by omega
      simp [abs_of_neg hm_neg] at h
      exact h
      simp [abs_of_neg hm_neg]
      omega
    · push_neg at h
    simp only [Finset.mem_Icc, not_and, not_le] at hn
    have h_large : (⌈K⌉ : ℤ) + 1 < |n| := by
      by_cases h : n < -(⌈K⌉ + 1)
      · have hn_neg : n < 0 := by omega
        simp [abs_of_neg hn_neg] at h
        exact h
  have h_large : (⌈K⌉ : ℤ) + 1 < |n| := by
    by_cases h : n < -(⌈K⌉ + 1)
    · have hn_neg : n < 0 := by omega
        simp [abs_of_neg hn_neg]
        omega
      · push_neg at h
Bearbeitet
ShiftedWindows.lean
    simp only [Finset.mem_Icc, not_and, not_le] at hn
  have h_large : (⌈K⌉ : ℤ) + 1 < |n| := by
    by_cases h : n < -(⌈K⌉ + 1)
    · have hn_neg : n < 0 := by omega
    have h_large : (⌈K⌉ : ℤ) + 1 < |n| := by
      by_cases h : n < -(⌈K⌉ + 1)
      · have hn_neg : n < 0 := by omega
        simp [abs_of_neg hn_neg]
Bearbeitet
ShiftedWindows.lean
Bearbeitet
ShiftedWindows.lean

open scoped BigOperators Real Classical
open scoped BigOperators Real Classical ComplexConjugate
open MeasureTheory

noncomputable def T_P_comp_shift (K B t tau : ℝ) (M : ℕ) [Fintype (Nodes K)] :
    Matrix (Fin (2 * M + 1)) (Fin (2 * M + 1)) ℂ :=
  fun i j =>
    ∑ n : Nodes K,
      ((w_Q n * phi_shift B t tau (xi_n n)) : ℂ) *
        prime_vec M (xi_n n) i * conj (prime_vec M (xi_n n) j)

noncomputable def T_P_comp_real_shift (K B t tau : ℝ) (M : ℕ) [Fintype (Nodes K)] :
    Matrix (Fin (2 * M + 1)) (Fin (2 * M + 1)) ℝ :=
  fun i j => (T_P_comp_shift K B t tau M i j).re

end Q3
Bearbeitet
Rayleigh_Q_identification.lean
import Q3.Proofs.Rayleigh_Fourier
import Q3.Proofs.ShiftedWindows
import A3_FLOOR_v22_stage4_floor
Bearbeitet
Rayleigh_Q_identification.lean

/-- Diagonal of shifted T_P_comp_real at basis0. -/
lemma T_P_comp_real_shift_diag (K B t tau : ℝ) (M : ℕ) [Fintype (Q3.Nodes K)] (hM : 0 < 2 * M + 1) :
    Q3.T_P_comp_real_shift K B t tau M (i0 M) (i0 M) =
      (1 / (2 * M + 1 : ℝ)) *
        ∑ n : Q3.Nodes K, Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n) := by
  simp only [Q3.T_P_comp_real_shift, Q3.T_P_comp_shift]
  simp only [← Complex.ofReal_mul]
  have h_factor : ∀ n : Q3.Nodes K,
      ((Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n)) : ℂ) *
        Q3.prime_vec M (Q3.xi_n n) (i0 M) * conj (Q3.prime_vec M (Q3.xi_n n) (i0 M)) =
      ((Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n)) : ℂ) * (1 / (2 * M + 1 : ℝ)) := by
    intro n
    rw [mul_assoc, prime_vec_i0_norm_sq M (Q3.xi_n n) hM]
  have h_sum_eq : (∑ n : Q3.Nodes K,
        ((Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n)) : ℂ) *
          Q3.prime_vec M (Q3.xi_n n) (i0 M) * conj (Q3.prime_vec M (Q3.xi_n n) (i0 M))) =
      ∑ n : Q3.Nodes K, ((Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n)) : ℂ) *
        (1 / (2 * M + 1 : ℝ)) := by
    congr 1
    ext n
    exact h_factor n
  rw [h_sum_eq, ← Finset.sum_mul]
  rw [← Complex.ofReal_sum]
  rw [one_div, ← Complex.ofReal_inv, ← Complex.ofReal_mul, Complex.ofReal_re]
  ring

theorem arch_rayleigh_eq_shift (B t tau : ℝ) (M : ℕ)
    (hP : Continuous (Q3.P_A_shift B t tau)) (hB : 0 < B) :
    Q3.RayleighQuotient
      (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (Q3.P_A_shift B t tau)) (basis0 M) =
    Q3.arch_term (fun ξ => Q3.phi_shift B t tau ξ) := by
  rw [rayleigh_basis0, ToeplitzMatrix_Fourier_real_diag M (Q3.P_A_shift B t tau) hP]
  exact Q3.Proofs.ShiftedWindows.integral_P_A_shift_eq_arch_term B t tau hB

theorem prime_rayleigh_eq_shift (K B t tau : ℝ) (M : ℕ) [Fintype (Q3.Nodes K)] (hM : 0 < 2 * M + 1) :
    (2 * M + 1 : ℝ) * Q3.RayleighQuotient (Q3.T_P_comp_real_shift K B t tau M) (basis0 M) =
    ∑ n : Q3.Nodes K, Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n) := by
  rw [rayleigh_basis0, T_P_comp_real_shift_diag K B t tau M hM]
  field_simp

theorem rayleigh_Q_identification_shift (B t tau K : ℝ) (M : ℕ)
    [Fintype (Q3.Nodes K)] (hB : 0 < B) (hP : Continuous (Q3.P_A_shift B t tau)) (hM : 0 < 2 * M + 1) :
    Q3.RayleighQuotient
      (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (Q3.P_A_shift B t tau)) (basis0 M) -
    (2 * M + 1 : ℝ) * Q3.RayleighQuotient (Q3.T_P_comp_real_shift K B t tau M) (basis0 M) =
    Q3.arch_term (fun ξ => Q3.phi_shift B t tau ξ) -
    ∑ n : Q3.Nodes K, Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n) := by
  rw [arch_rayleigh_eq_shift B t tau M hP hB, prime_rayleigh_eq_shift K B t tau M hM]

theorem prime_term_eq_nodes_sum_shift (B t tau K : ℝ) [Fintype (Q3.Nodes K)]
    (hB : 0 < B) (hK : |tau| + B ≤ K) :
    Q3.prime_term (fun ξ => Q3.phi_shift B t tau ξ) =
    ∑ n : Q3.Nodes K, Q3.w_Q n * Q3.phi_shift B t tau (Q3.xi_n n) := by
  have hPhi : ∀ ξ, K < |ξ| → Q3.phi_shift B t tau ξ = 0 := by
    intro ξ hξ
    exact Q3.Proofs.ShiftedWindows.phi_shift_support_of_margin B t tau K hB hK ξ hξ
  simpa using (prime_term_eq_nodes_of_support (Φ := fun ξ => Q3.phi_shift B t tau ξ) (K := K) hPhi)

theorem rayleigh_Q_eq_Q_shift (B t tau K : ℝ) (M : ℕ)
    [Fintype (Q3.Nodes K)] (hB : 0 < B) (hK : |tau| + B ≤ K)
    (hP : Continuous (Q3.P_A_shift B t tau)) (hM : 0 < 2 * M + 1) :
    Q3.RayleighQuotient
      (RayleighFourier.ToeplitzMatrix_Fourier_real (2 * M + 1) (Q3.P_A_shift B t tau)) (basis0 M) -
    (2 * M + 1 : ℝ) * Q3.RayleighQuotient (Q3.T_P_comp_real_shift K B t tau M) (basis0 M) =
    Q3.Q (fun ξ => Q3.phi_shift B t tau ξ) := by
  rw [rayleigh_Q_identification_shift B t tau K M hB hP hM]
  simp only [Q3.Q]
  congr 1
  exact (prime_term_eq_nodes_sum_shift B t tau K hB hK).symm

end Q3.Proofs.RayleighQId
Сделал shift‑слой и Rayleigh‑обёртки, то есть τ теперь живёт там, где должен: в окне/символе/prime‑кап. RKHS‑кап под τ пока не трогал, rho_one не менял.

Новый слой со сдвигами: ShiftedWindows.lean — phi_shift, g_shift, P_A_shift, периодизация без swap, support‑леммы, плюс T_P_comp_shift/T_P_comp_real_shift.
Обёртки для τ: Rayleigh_Q_identification.lean — T_P_comp_real_shift_diag, arch_rayleigh_eq_shift, prime_rayleigh_eq_shift, rayleigh_Q_identification_shift, prime_term_eq_nodes_sum_shift, rayleigh_Q_eq_Q_shift.
Следующие шаги (выбери):

Делаем τ‑вариант RKHS‑капа: либо rho_local K + мост rho_local K ≤ rho_one, либо прямая uniform‑оценка под phi_shift.
Переписываем доказательный файл атомов на новые леммы и закрываем sorry (скажи, работать с Q_nonneg_atoms_proof.lean или сразу в основном Q_nonneg_on_atoms_fourier_axiom.lean).

## ASSISTANT
Ы вижу прогресс: **shift‑слой** уже есть, и **Rayleigh‑обёртки** под **τ** ты протянул правильно. Сейчас у тебя реально “торчат” только два штыря, без которых `Q_nonneg_atoms_proof.lean` не закроется:

1) **τ‑вариант RKHS‑капа** (верхняя оценка для **prime‑части**).  
2) **τ‑совместимость A3‑пола** (нижняя оценка для **Toeplitz‑части**) — но тут есть шанс вообще не трогать пол, если чуть поменять точку входа.

Ниже — максимально “по делу” чек‑лист (и где именно ты можешь урезать сложность).

---

## 0) Быстрый sanity‑чек по твоему ShiftedWindows.lean

### Что у тебя сейчас хорошо
- **φ_shift** = `fejer_heat_window B t (ξ - τ)` — это прямой **сдвиг окна**.  
- **periodization** через `∑' m : ℤ, g_shift (θ+m)` — норм.
- Ты уже сделал ключевое:  
  **`integral_P_A_shift_eq_arch_term`** и **Rayleigh‑идентификацию** для **τ**.

### Что я бы упрощал (иначе Lean будет мстить)
У тебя в доказательствах много “хрупких” мест: **ceil**, **abs**, ручные переписывания, следы `omega`.  
Самое стабильное упрощение — заменить весь ceiling‑зоопарк одной грубой, но крепкой оценкой:

> Для `θ ∈ [-1/2,1/2]`  
> `|θ + m - τ| ≥ |m| - |θ| - |τ| ≥ |m| - 1/2 - |τ|`.

Отсюда достаточно условия  
`B < |m| - (1/2 + |τ|)`  
чтобы получить `φ_shift ... (θ+m) = 0`.

Это резко упрощает `g_shift_zero_of_large_m` и всё, что строится на нём.

---

## 1) Дыра №1: τ‑вариант **RKHS cap** (prime‑часть)

### Что такое **RKHS cap**
**RKHS cap** — это “крышка” на **операторную норму**/**Rayleigh quotient** у **prime‑оператора** (матрицы, собранной из узлов `ξ_n` и весов `w_Q`).  
Типичная цель в твоём стиле лемм:

- либо `RayleighQuotient (T_P_comp_real_shift ...) p ≤ ρ_one`,
- либо сразу `prime_term(φ_shift) ≤ ρ_one` (если ты берёшь `p = basis0`).

### Самый дешёвый путь (без новой математики): через **trace**
Твой `T_P_comp_shift` — это сумма **rank‑one** матриц вида  
`weight_n * v_n * v_nᴴ`.

Если `weight_n ≥ 0`, то матрица **PSD** (полуопределённо положительная), а значит:

- `RayleighQuotient A p ≤ ‖A‖ ≤ trace A`.

И если у тебя `prime_vec` действительно нормирован (как обычно), то
`trace (weight_n * v vᴴ) = weight_n * ‖v‖² = weight_n`.

То есть:

> `trace (T_P_comp_real_shift ...) = ∑ n, w_Q n * φ_shift ... (ξ_n)`.

И дальше тебе нужна ровно одна оценка:

> `∑ n, w_Q n * φ_shift ... (ξ_n) ≤ ρ_one`.

### Где тут “τ‑магия”
Если твой текущий `weight_sum_le_rho_one` уже имеет форму **sup‑по‑сдвигу** или “для любого центра”, то ты просто подставляешь `τ` и готово.

Если же он только для `τ=0`, то у тебя две реальные опции:

#### Опция A (самая вероятная в твоей библиотеке)
Переформулируй/обобщи лемму так, чтобы она принимала **любой** `x : ℝ` как “центр”:

```lean
lemma weight_sum_le_rho_one_centered (x : ℝ) :
  (∑ n : Nodes K, w_Q n * Real.exp (-4 * π^2 * t * (xi_n n - x)^2)) ≤ rho_one := ...
```

И тогда `x := τ`.

#### Опция B (если обобщение тяжёлое, но τ ограничен через K)
У тебя почти везде есть гипотеза типа `hK : |τ| + B ≤ K`.  
Это даёт `|τ| ≤ K`.

Тогда можно тупо (но формально) сделать оценку:
`(ξ - τ)^2 ≥ ξ^2/2 - τ^2` ⇒ `exp(-c(ξ-τ)^2) ≤ exp(c τ^2) * exp(-c ξ^2/2)`.

И дальше:
`≤ exp(c K^2) * ∑ w_Q n * exp(-c ξ_n^2/2)`.

Да, фактор `exp(c K^2)` неприятный — но если у тебя `K` в атомах фиксирован маленький или уже “зашит” под A3‑параметры, это может пройти.

---

## 2) Дыра №2: τ‑совместимость **A3 floor**

### Что такое **A3 floor**
**A3 floor** — это нижняя точка для символа `P_A` на торе:  
`P_A(θ) ≥ c_star` для всех θ в `[-1/2,1/2]`.

В матричном виде это даёт нижнюю оценку спектра **Toeplitz matrix** и, соответственно, **Rayleigh quotient**.

### Почему твой текущий “shift‑символ” ломает жизнь
`P_A_shift` использует `a ξ` без сдвига, но окно сдвигает: `φ(ξ-τ)`.  
Так что пол “может” зависеть от τ (и в общем случае зависит).

**Если тебе реально нужен uniform‑пол по τ**, то это отдельный тяжёлый кусок.

---

## 3) Самый короткий трюк, который может срезать обе дыры

Я бы проверил (и если совпадает — сразу переключился), нет ли у тебя уже в проекте такой “архитектуры”:

- **τ не в символе и не в весах**,  
- **τ сидит в тест‑векторе `p`**,  
- а оператор (`Toeplitz(P_A)` и `T_P_comp_real`) остаётся тот же.

Тогда:
- A3 floor остаётся ровно твоим текущим (без `P_A_shift`).
- RKHS cap остаётся ровно твоим текущим (без `T_P_comp_real_shift`).
- и ты доказываешь новую **Rayleigh‑идентификацию**:
  `Q(Φ_{B,t,τ}) = (TM[PA] - TP)[p_τ,p_τ]`,
  где `p_τ` — какой‑то **shifted packet** в **P_M** (обычно это что-то в духе `prime_vec M τ` или сглаженный вариант).

Если эта идентификация в твоих файлах вообще близка к тому, что в pdf называется “Dirichlet sampling operator”, то это буквально “one‑shot fix” для τ, без новых численных лемм.

---

## 4) Практический план: что делать прямо сейчас

Я бы сделал так (в порядке “максимум эффекта / минимум боли”):

### Шаг 1 — сделать τ‑cap через trace (быстро)
Добавь в `RKHS_cap_rayleigh.lean` (или рядом) леммы:

- **`trace_T_P_comp_real_shift`**: вычислить след матрицы.
- **`rayleigh_le_trace_of_psd`**: Rayleigh ≤ trace для **PSD** матриц.
- **`weight_sum_shift_le_rho_one`**: ключевая оценка суммы весов с `φ_shift`.

После этого получишь:

- **`rayleigh_T_P_comp_real_shift_le_rho_one`**.

### Шаг 2 — переписать `Q_nonneg_atoms_proof.lean`
Прямой скелет (идея):

1) Используешь твою:
   - **`rayleigh_Q_eq_Q_shift`** (или для атома — линейность + два сдвига ±τ).
2) Подставляешь:
   - нижнюю оценку для Toeplitz‑части (**либо** τ‑floor, **либо** старый A3 через “короткий трюк” с `p_τ`),
   - верхнюю оценку для prime‑части (**τ‑cap**).
3) Финал: `c_star/4 - rho_one ≥ 0`.

---

## 5) Мини‑заметка про подстановку переменных
Чтобы в доказательствах не застревать:

Подстановка: `u := ξ - τ` (или `x := θ + m - τ`) — и всё, что зависит от сдвига, становится “чистым”.  
->You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import). <-

---

## Что я “выбираю” из твоих двух шагов
Делаем **τ‑вариант RKHS‑капа** первым. Это самый блокирующий кусок, и его реально закрыть без трогания остального, если пойдёшь через **trace**.

Параллельно (после того как cap есть) — переписываем `Q_nonneg_atoms_proof.lean` на твои `*_shift`‑леммы и закрываем `sorry`.

Если хочешь прям “в одну атаку” и без τ‑floor вообще — я бы попробовал короткий трюк с **τ в векторе p**, но это зависит от того, как именно у тебя устроена связь “атом ↔ вектор” в Lean‑коде.

Хочешь, я накидаю конкретные *Lean‑заготовки* для `trace_T_P_comp_real_shift` и `rayleigh_le_trace_of_psd` в твоём стиле (с `simp`/`ring`/`nlinarith`) — чтобы ты просто вставил и докрутил импорты?

## ASSISTANT
Ы **Исправленный текст (чуть почистил, смысл тот же):**  
«Пробей это. Вау, супер — дожми! Теперь нужно закрыть **τ‑сдвиг** в `Q_nonneg_atoms_proof`: леммы должны работать для любого **τ**, без новых аксиом.»

---

Ок, дожимаю. Ниже — максимально **Lean‑friendly** путь, который реально обходит монстра **`integral_tsum_of_summable_integral_norm`** и даёт тебе τ‑слой так, чтобы дальше `Q_nonneg_atoms_proof` закрывался “по рельсам”.

# 0) Главная идея, чтобы Lean не зависал

Ключ: **не менять местами `∫` и `∑'`** через доминированную сходимость.  
Вместо этого:

1) показываем, что у **`g_shift`** **компактный носитель** (**`HasCompactSupport`**),  
2) значит для каждого θ в `[-1/2,1/2]` сумма по `m : ℤ` на самом деле **конечная**,  
3) поэтому **`∑'` превращается в `Finset.sum`**, и мы спокойно:
   - интегрируем **конечную сумму** (`intervalIntegral.integral_finset_sum`)
   - и дальше используем стандартную лемму про разбиение ℝ на интервалы длины 1 (`Integrable.hasSum_intervalIntegral`), но **без `integral_tsum`**.

Это ровно то, что “ускоряет” elaboration: Lean не строит огромные термы для Fubini/DCT.

---

# 1) Минимальный τ‑слой (что надо иметь в отдельном файле)

## 1.1 Определения

Тебе нужно 3 определения (как ты и сделал):

- **`phi_shift B t τ`**: сдвинутое окно  
  **смысл:** окно **`fejer_heat_window`** по ξ, но центр в **τ**.

- **`g_shift B t τ`**: интегрируемый множитель для periodization  
  **смысл:** это “ядро”, которое ты периодизуешь.

- **`P_A_shift B t τ`**: периодизация по целым  
  **смысл:** торический символ, который идёт в **Toeplitz**.

```lean
namespace Q3

def phi_shift (B t τ : ℝ) (ξ : ℝ) : ℝ :=
  fejer_heat_window B t (ξ - τ)

def g_shift (B t τ : ℝ) (ξ : ℝ) : ℝ :=
  a ξ * phi_shift B t τ ξ

def P_A_shift (B t τ : ℝ) (θ : ℝ) : ℝ :=
  2 * Real.pi * ∑' (m : ℤ), g_shift B t τ (θ + m)

end Q3
```

**Ключевые термины:**
- **`phi_shift`** — “окно в частотах”, сдвиг на **τ**.  
- **`g_shift`** — то, что реально интегрируется; это **`a * window`**.  
- **`P_A_shift`** — **periodization**: сумма по целым с шагом 1.

---

## 1.2 Лемма: периодизация “быстро” (без swap)

Вот твой главный штырь:

> **`integral_P_A_shift_eq_arch_term`**  
> `∫_{-1/2}^{1/2} P_A_shift = arch_term(phi_shift)`  

### Что обязательно внутри доказательства (структурно)
1) доказать: у **`g_shift`** компактный носитель (вроде `support ⊆ Icc (-K) K` где `K = |τ| + B`)  
2) из компактности: `Integrable (g_shift...)`
3) `tsum = finset.sum` на `θ ∈ [-1/2,1/2]`
4) интеграл от `finset.sum` → `finset.sum` от интегралов
5) суммы по интервалам длины 1 → интеграл по ℝ (через `Integrable.hasSum_intervalIntegral`)
6) “2π и a_star=2πa” → `arch_term`.

Твой текущий код в целом в эту схему попадает. Главное — держать его “терм‑экономным”:  
- меньше “`simp` по всему миру”,  
- меньше вложенных `have` с `EqOn` по `[[a,b]]`,  
- аккуратно отделить “обрезку tsum до finset” от “разбиения ℝ на интервалы”.

**Почему это реально быстро:**  
ты не вызываешь **`MeasureTheory.integral_tsum_of_summable_integral_norm`** вообще.

---

# 2) Дальше: τ‑обёртки в `Rayleigh_Q_identification.lean`

Ты уже сделал правильную обвязку. Смысл такой:

## 2.1 Диагональ прайм‑оператора со сдвигом

Тебе нужен τ‑вариант:

- **`T_P_comp_real_shift_diag`**  
  даёт диагональ = `(1/(2M+1))*Σ w_Q * phi_shift(...)`

И потом:

- **`prime_rayleigh_eq_shift`**  
  домножает **`RayleighQuotient`** на `(2M+1)` и получает **ровно** Σ веса * окно.

**Почему это ок:**  
**`RayleighQuotient`** на **`basis0`** вынимает диагональный элемент, а **`prime_vec`** даёт квадрат нормы = `1/(2M+1)`.

---

## 2.2 Arch‑часть со сдвигом

Лемма:

- **`arch_rayleigh_eq_shift`**  
  `RQ(Toeplitz(P_A_shift), basis0) = arch_term(phi_shift)`

здесь критично, что ты используешь “быструю” периодизацию из файла `ShiftedWindows.lean`.

---

## 2.3 Финал: Rayleigh ↔ Q со сдвигом

Лемма (core):

- **`rayleigh_Q_eq_Q_shift`**  
  ```
  RQ(Toeplitz(P_A_shift), basis0)
    - (2M+1)*RQ(T_P_comp_real_shift, basis0)
  = Q(phi_shift)
  ```

Это именно то, что потом прямо вкручивается в `Q_nonneg_atoms_proof`.

---

# 3) Теперь про `Q_nonneg_atoms_proof`: как закрыть τ‑случай

Вот “склейка” (без воды).

## 3.1 Что тебе надо в `Q_nonneg_atoms_proof.lean`

### Цель 1: `Q_single_atom_nonneg` (любой τ)

Ты хочешь доказать:
- `0 ≤ Q(Fejer_heat_atom B t τ)`.

Ты сам правильно обозначил, что удобно разложить атом через окна:

- **`Fejer_heat_atom`** (атом) выражается как линейная комбинация **двух** окон:
  - `phi_shift ... τ`
  - `phi_shift ... (-τ)`

то есть нужна лемма вида:

```lean
lemma Fejer_heat_atom_eq (B t τ : ℝ) :
  Fejer_heat_atom B t τ
    = (2 / Real.sqrt (4*Real.pi*t)) • (fun ξ => phi_shift B t' τ ξ + phi_shift B t' (-τ) ξ) := ...
```

(названия подгони под твои defs)

Дальше:
- используешь **линейность** **`Q`**:  
  **`Q (c•(f+g)) = c*(Q f + Q g)`**.

И сводишься к доказательству неотрицательности `Q(phi_shift ... τ)` и `Q(phi_shift ... (-τ))`.

---

### Цель 2: `Q_nonneg_on_atoms_of_A3_Fourier_RKHS`

Это обычно:
- берёшь конечную сумму атомов (или **`Finset`**) с неотрицательными коэффициентами
- используешь линейность Q и факт `Q(atom)≥0`
- получаешь `Q(sum) ≥ 0`.

---

## 3.2 Точка, где всё реально может “сломаться” (я честно отмечу)

Чтобы закрыть `Q(phi_shift B t τ) ≥ 0` через A3+RKHS, тебе надо 2 оценки:

1) нижняя на **арх‑часть** (через Toeplitz):
   - что-то вроде  
     **`RQ(Toeplitz(P_A_shift), basis0) ≥ c_star/4`**  
     (или другая твоя константа)

2) верхняя на **прайм‑часть**:
   - что-то вроде  
     **`(2M+1)*RQ(T_P_comp_real_shift, basis0) ≤ rho_one`**

И вот здесь важный момент: **если `rho_one = 1/25` у тебя доказан только для τ=0**, то для общего τ это уже не “автоматически”.  
Но с точки зрения Lean‑склейки — это просто 2 леммы, которые тебе нужны как входы.

ASCII‑цепочка для τ‑случая:

```
(phi_shift / P_A_shift / T_P_comp_shift)  -- defs
          |
          v
rayleigh_Q_eq_Q_shift                     -- identification
          |
          v
[ A3 lower bound on Toeplitz(P_A_shift) ] -- needs τ-variant
[ RKHS cap on prime shift sum ]           -- needs τ-variant
          |
          v
Q(phi_shift) ≥ c* - rho ≥ 0
          |
          v
Fejer_heat_atom = const*(phi_shift τ + phi_shift -τ)  -- decomposition
          |
          v
Q_single_atom_nonneg (any τ)
          |
          v
Q_nonneg_on_atoms_of_A3_Fourier_RKHS
```

---

# 4) Конкретно: “что писать” в Lean для финального закрытия (шаблон)

Вот прям шаблон, который ты вставишь в `Q_nonneg_atoms_proof.lean`.
Я пишу так, чтобы он был максимально устойчивый к elaboration‑взрывам:

```lean
theorem Q_phi_shift_nonneg_of_A3_Fourier_RKHS
  (B t τ K : ℝ) (M : ℕ) [Fintype (Q3.Nodes K)]
  (hB : 0 < B) (hK : |τ| + B ≤ K) (hM : 0 < 2*M + 1)
  (hP : Continuous (Q3.P_A_shift B t τ))
  (hA3 : (c_star/4 : ℝ) ≤
    Q3.RayleighQuotient
      (RayleighFourier.ToeplitzMatrix_Fourier_real (2*M+1) (Q3.P_A_shift B t τ))
      (basis0 M))
  (hCap : (2*M+1 : ℝ) *
      Q3.RayleighQuotient (Q3.T_P_comp_real_shift K B t τ M) (basis0 M)
      ≤ rho_one) :
  0 ≤ Q3.Q (fun ξ => Q3.phi_shift B t τ ξ) := by
  -- 1) rewrite Q as Rayleigh difference:
  have hQ :=
    Q3.Proofs.RayleighQId.rayleigh_Q_eq_Q_shift
      (B:=B) (t:=t) (tau:=τ) (K:=K) (M:=M) hB hK hP hM
  -- 2) turn it into inequality:
  --    Q = arch - prime ≥ c_star/4 - rho_one
  --    then use `c_star_div_four_le_sub_rho_one : 0 ≤ c_star/4 - rho_one`
  -- (exact lemma name might differ in your code)
  have hLower : (c_star/4 - rho_one : ℝ) ≤ Q3.Q (fun ξ => Q3.phi_shift B t τ ξ) := by
    -- expand hQ, then linarith with hA3, hCap
    -- keep it dumb/simple: no giant simp.
    -- typical:
    --   rw [←hQ]; linarith
    -- depends on how you named c_star, rho_one.
    sorry
  have hpos : 0 ≤ (c_star/4 - rho_one : ℝ) := by
    simpa using c_star_div_four_le_sub_rho_one
  linarith
```

И дальше:

```lean
theorem Q_single_atom_nonneg
  (B t τ : ℝ) :
  0 ≤ Q3.Q (fun ξ => Q3.Fejer_heat_atom B t τ ξ) := by
  -- 1) rewrite atom -> shifted windows (τ and -τ)
  -- 2) linearity of Q
  -- 3) apply Q_phi_shift_nonneg_of_A3_Fourier_RKHS twice
  sorry
```

---

# 5) Почему твой τ‑слой — правильный шаг именно “по скорости” Lean

Ты сделал две вещи, которые реально спасают:

- **`tsum` → `Finset.sum`** за счёт **`HasCompactSupport`**  
  (**`HasCompactSupport`** = “снаружи компактного множества функция = 0”, значит ряд реально конечный на нужной области)

- интеграл/сумма меняются местами через **`intervalIntegral.integral_finset_sum`**  
  (**`Finset`** = конечное множество, там всё тривиально, Lean не умирает)

Эти два трюка в 90% случаев убивают таймауты от “аналитической тяжести” в Mathlib.

---

# 6) Что я бы сделал прямо сейчас, если твоя цель “закрыть τ без новых аксиом”

1) Довести до компиляции `ShiftedWindows.lean`:
   - убрать `omega` где можно,
   - минимизировать `simp`‑взрывы,
   - сделать 2–3 короткие леммы “обрезка по носителю”.

2) Довести `rayleigh_Q_eq_Q_shift` (ты уже почти там).

3) В `Q_nonneg_atoms_proof.lean`:
   - сначала закрыть **`Q_phi_shift_nonneg_of_A3_Fourier_RKHS`** (это “кирпич”)
   - потом закрыть **`Q_single_atom_nonneg`** через разложение атома.

---

## Мини‑глоссарий

- **`τ‑сдвиг`** — параметр сдвига центра окна: функция смотрит на `(ξ-τ)`.  
- **`periodization`** — периодизация по целым: `Σ_{m∈ℤ} f(θ+m)` превращает функцию на ℝ в функцию на торе.  
- **`tsum`** — бесконечная сумма (`∑'`), в Lean часто дорогая.  
- **`Finset.sum`** — конечная сумма, быстрый режим.  
- **`HasCompactSupport`** — “функция нулевая вне компакта”; ключ к `tsum_eq_sum`.  
- **`intervalIntegral`** — интеграл на отрезке в MeasureTheory.  
- **`ToeplitzMatrix`** — матрица свёртки по Фурье‑коэффициентам символа.  
- **`RayleighQuotient`** — `⟨Av,v⟩/⟨v,v⟩`, удобная форма для нижних оценок.  
- **`prime_vec`** — нормированный “вектор оценки” (даёт фактор `1/(2M+1)` в квадратичной форме).  
- **`arch_term / prime_term`** — две части Weil‑функционала.

---

Если хочешь — я могу ещё жёстче: переписать твою `integral_P_A_shift_eq_arch_term` в *совсем короткий* вариант (2–3 экрана), где:
- одна лемма “finite truncation by support”
- одна лемма “hasSum_intervalIntegral + truncation”
и всё.  
Но прямо сейчас у тебя уже правильный каркас.

You can manually trigger indexing by going to GitHub and performing a search for the repository using this format: repo:{username/repo_name} import (e.g., repo:openai/codex import).

## USER
 Ключевые вопросы для Прошки в секции "Refined Questions":                                                                      
                                                                                                                                                   
  1. Direct approach для arbitrary atoms - bounds работают для конкретных B_min, t_sym, но AtomCone_K содержит произвольные B, t                   
  2. Нужно ли ограничить AtomCone_K до фиксированных параметров?                                                                                   
  3. Есть ли трансформация между heat_kernel_A1(t) и exp(-4π²t'ξ²)?                                                                                
  4. Корректна ли формулировка аксиомы - hypotheses дают bounds для specific params, conclusion для ALL atoms                                      
                                                                                                                                                   
  ---                                                                                                                                              
  TL;DR для Прошки:                                                                                                                                
  Твой direct approach (arch ≥ c*, prime ≤ ρ) работает для fejer_heat_window, но в Lean атомы определены как Fejer_heat_atom с другой              
  параметризацией и произвольными B, t. Как это совместить?       

## ASSISTANT
Ы. Переписал твой блок **Refined Questions** нормально (смысл тот же, без кривизны):

**Ключевые вопросы для Прошки (Refined Questions):**
1) **Direct approach** для *произвольных* атомов: оценки у нас есть для конкретных **B_min**, **t_sym**, но **AtomCone_K** сейчас содержит произвольные **B, t** — как это склеить?
2) Нужно ли **сузить AtomCone_K** до фиксированных параметров (например, фиксировать **t** и/или диапазон **B**)?
3) Есть ли точная трансформация между **heat_kernel_A1(t)** (гауссиан вида `exp(-x^2/(4t))`) и фактором `exp(-4π^2 t' ξ^2)` в нашей **fejer_heat_window**?
4) Корректна ли сейчас формулировка **аксиомы**: если гипотезы дают bounds только для *specific params*, а вывод заявляет неотрицательность для *ALL atoms*, то это выглядит как логический разрыв.

---

## Теперь по сути: как это реально чинится (и что сказать Прошке)

### 1) “Direct approach для arbitrary atoms” — тебе *не нужен* arbitrary, и это прямо в каноне
В каноническом PDF уже есть способ **убить произвольный t** без потери плотности: **Lemma 6.4 (Fixed‑t₀ cone density)**. Она говорит: можно **зафиксировать один t₀** и всё равно получить плотность конуса атомов в \(C^+_{\text{even}}([-K,K])\).【335:0†RH_Q3.pdf†L36-L40】

Перевод на человеческий:
- Если в Lean у тебя **AtomCone_K** “слишком широкий” (любой **t**), это не “фича”, это **лишняя головная боль**.
- В каноне разрешено заменить “любой t” на “фиксированный t₀” и всё равно не потерять **A1′ density**.

👉 Поэтому *direct approach* (arch ≥ c*, prime ≤ ρ) тебе нужно доказывать **не для всех t**, а для атомов с **фиксированным t₀**, который ты выбираешь так, чтобы совпасть с твоими доказанными параметрами.

---

### 2) Да, **AtomCone_K** имеет смысл сузить — и это не костыль, а канон
Канонная схема закрытия такая:
- **A3 bridge** даёт \(Q(\Phi) \ge 0\) на **Fejér×heat generator cone** внутри \(W_K\),
- потом **A1′ density** + **A2 continuity** протягивает на весь \(W_K\).【401:5†RH_Q3.pdf†L23-L30】

Если в Lean у тебя “generator cone” и “то, где работает A3/RKHS” не совпадают, то цепь рвётся *формально*, даже если математика в голове ок.

Так что корректный ход:
- либо **сужаешь AtomCone_K**, чтобы он был именно тем конусом генераторов, на котором у тебя реально есть A3/RKHS-оценки,
- либо **усиливаешь A3/RKHS**, чтобы они покрывали весь текущий AtomCone_K (обычно это тяжелее и бессмысленно).

---

### 3) Трансформация гауссианов есть, и она прям в одну строку
В PDF для **A1′** атомы используют
\[
\rho_t(x) = (4\pi t)^{-1/2} e^{-x^2/(4t)}
\]
и окно вида \(\Lambda_B(\cdot)\rho_t(\cdot)\).【335:13†RH_Q3.pdf†L31-L45】

В твоём Lean-окне **fejer_heat_window** гауссиан такого типа:
\[
e^{-4\pi^2\,t'\,\xi^2}.
\]

Это одно и то же после переназначения:
\[
e^{-x^2/(4t)} = e^{-4\pi^2\,t'\,x^2}
\quad\Longleftrightarrow\quad
t' = \frac{1}{16\pi^2\,t}.
\]

Нормировочный множитель \((4\pi t)^{-1/2}\) — **положительный**, и в контексте конуса/неотрицательности его можно спокойно “вынести/забыть”:
в PDF прям явно сказано, что **масштабирование генераторов положительной константой не меняет порождённый конус**.【335:13†RH_Q3.pdf†L47-L50】

👉 То есть “другая параметризация” — это не проблема, а просто **лемма-конвертер** `t ↔ t'` + “positive scaling doesn’t matter”.

---

### 4) Про “аксиома даёт bounds для specific params, а вывод для ALL atoms” — да, это подозрительно
Если гипотезы в Lean реально дают:
- floor/bridge для конкретных **t_sym**, **B_min**
- RKHS cap для конкретного **t_rkhs**

а вывод формулируется как:
- \(Q(\text{atom}(B,t,τ)) \ge 0\) **для всех** \(B,t,τ\),

то это формально **слишком сильное утверждение**: между “есть bounds для одной точки параметров” и “все параметры” нужен либо:
- отдельный аргумент **униформности по параметрам**, либо
- изменение того, что ты называешь **AtomCone_K / generator cone**.

Канонная логика такая: A3 мост даёт позитивность на “generator cone”, потом плотность+непрерывность расширяют. Но это работает только если “generator cone” в Lean — **ровно тот**, где A3 применим.【401:5†RH_Q3.pdf†L23-L30】

---

## Что я бы прямо сейчас отправил Прошке (копипастой)

Вот “сообщение для Прошки” без воды:

> У нас несостыковка спецификации: **A3/RKHS bounds** в Lean сделаны для конкретных **t_sym/B_min** и **t_rkhs**, а **AtomCone_K** (или “atoms”) содержит произвольные **B,t**.  
> Канонный PDF позволяет это починить без потери плотности: **Lemma 6.4** утверждает, что можно **зафиксировать t₀** и всё равно получить плотность конуса атомов в \(C^+_{\text{even}}([-K,K])\) при условии **|τ|+B≤K**.【335:0†RH_Q3.pdf†L36-L40】  
> Плюс, у PDF-атомов гауссиан \(e^{-x^2/(4t)}\), а у нас в **fejer_heat_window** \(e^{-4π^2 t' x^2}\); это совпадает при **t' = 1/(16π^2 t)**, а положительные нормировочные множители можно игнорировать для конуса/неотрицательности (PDF прямо говорит, что scaling генераторов положительной константой не меняет конус).【335:13†RH_Q3.pdf†L47-L50】  
> Вопрос: правильно ли будет **сузить AtomCone_K** до фиксированного **t₀** (выбранного под наши **t_sym**) и переписать аксиому так, чтобы вывод был “для атомов из этого конуса”, а не “для всех B,t”?

---

## Мини-подсказка по твоей ситуации с τ (чтобы не уйти в бесконечность)
Ты уже сделал **shift-layer** и **Rayleigh**-обёртки (τ живёт “где должен”). Это ок.

Но если ты оставишь **AtomCone_K** с произвольными параметрами, ты будешь вынужден доказывать:
- либо **A3 floor** и **RKHS cap** *униформно по B,t,τ*,
- либо вечно чинить “зачем это вообще нужно”.

Канонный путь — **сузить генераторы** (через fixed‑t₀ / словарь) и жить.

---

Если хочешь, я следующим шагом могу:
- предложить конкретную “Lean-спеку” для **AtomCone_K_fixed_t0** (чисто на уровне математики/логики, без доступа к твоему репо),
- и прямо разложить, как именно из **Lemma 6.4** + конвертера \(t↔t'\) получается нужный мост “атом в Lean = атом в PDF”.

RH_Q3.pdf: fileciteturn9file0

## USER
Да сделай это

## ASSISTANT
Ы Сделал. Я переписал **PROSHKA_REQUEST_4.md** так, чтобы там был нормальный “Refined Questions”-блок именно про твой текущий баг: **атомы** в Lean слишком “широкие” по параметрам (**B**, **t**, **τ**), а твои доказанные **A3/RKHS**-bounds живут на **фиксированных**/ограниченных параметрах (типа **B_min**, **t_sym**, **t_rkhs**). Плюс я явно вставил мост между двумя формами гауссиана (это твой пункт 3).

[Скачать обновлённый PROSHKA_REQUEST_4.md](sandbox:/mnt/data/PROSHKA_REQUEST_4.md)

### Что именно я туда вставил (коротко, без воды)

1) **Refined Question #1**: “Нужно ли вообще доказывать `Q ≥ 0` для *всех* атомов (всех **B,t,τ**), или достаточно для **генераторного подсемейства**?”  
   - **Почему важно:** если Lean-аксиома квантифицирует “всё”, а гипотезы дают bounds только на “часть” — цепочка ломается тупо из-за кванторов.

2) **Refined Question #2**: “Надо ли сузить **AtomCone_K** до фиксированного **t0**?”  
   - Я прям сослался на то, что в **A1prime.tex** реально есть **fixed‑t₀ density lemma**: плотность конуса при фиксированном **t0** и варьировании **B,τ**.  
   - **Смысл:** если можно фиксировать **t0**, то у тебя исчезает огромная часть гемора с “произвольным t”.

3) **Refined Question #3**: “Точное преобразование параметров между двумя гауссианами”  
   - В тексте я зафиксировал ключевую формулу:
     \[
     e^{-(\xi-\tau)^2/(4t)} = e^{-4\pi^2 t'(\xi-\tau)^2},\quad t'=\frac{1}{16\pi^2 t}.
     \]
   - **Почему важно:** это ровно то, что связывает A1’-атом с твоим Lean `fejer_heat_window` (с точностью до положительного множителя, который для конуса/знака не страшен, т.к. **Q** линейный).

4) **Refined Question #4**: “Корректна ли формулировка Lean-аксиомы (hypotheses vs conclusion)?”  
   - То есть: либо **усиливаем гипотезы** (чтобы они были по всем параметрам), либо **ослабляем заключение** (сужаем атомы до нужной семьи), либо вводим **schedule** типа `t0(K)`, `B0(K)` (как в ремарке A1’).

---

## Мини-глоссарий (чтоб Прошка не уплыл)

- **AtomCone_K** — *конус* (замкнутая по неотрицательным линейным комбинациям штука), на котором ты хочешь доказать **Q ≥ 0**, чтобы потом через плотность/липшицевость закрыть весь класс тестов.
- **Fejer_heat_atom** — твой “атом” (генератор конуса): окно типа **Фейер × Гаусс** со сдвигом **τ**.
- **fejer_heat_window** — конкретная Lean-реализация окна:
  \[
  (1-|\xi|/B)_+\cdot e^{-4\pi^2 t\xi^2}.
  \]
- **A3 floor** — нижняя оценка **P_A(θ) ≥ c_*** на торе; это даёт нижний спектральный барьер через **Rayleigh**.
- **RKHS cap** — верхняя оценка на прайм‑оператор (типа `‖T_P‖ ≤ ρ`), чтобы прайм‑часть не “съела” arch‑часть.
- **t_sym / t_rkhs** — два разных **t**: один в символе (**A3**), другой в капе (**RKHS**). Их нельзя путать.

---

Если хочешь — следующим шагом я могу прямо “без философии” пройтись по **Q3/Basic/Defs.lean** (как именно сейчас в Lean определены **Fejer_heat_atom** и **AtomCone_K**) и сказать: *какой именно квантор/параметр надо фиксировать*, чтобы совпало с **A1prime.tex** и чтобы вся цепь закрылась без новых аксиом.

## USER
                                                                                                                                                 
  Now I have all the info:                                                                                                                         
                                                                                                                                                   
  1. heat_kernel_A1: 1/√(4πt) * exp(-x²/(4t)) — A1prime.tex parametrization                                                                        
  2. fejer_heat_window (in Defs.lean): (1-|ξ|/B)₊ * exp(-4π²tξ²) — different parametrization!                                                      
  3. Fejer_heat_atom: uses heat_kernel_A1 with shift ±τ                                                                                            
  4. AtomCone_K: quantifies over ALL B > 0, t > 0, τ with |τ|+B ≤ K                                                                                
  5. AtomCone_K_fixed (new): fixes t = t₀, varying B, τ                                                                                            
                                                                                                                                                   
  The KEY issue is the two different parametrizations:                                                                                             
  - heat_kernel_A1: exp(-x²/(4t))                                                                                                                  
  - fejer_heat_window: exp(-4π²tξ²)                                                                                                                
                                                                                                                                                   
  If we set t' = 1/(16π²t), then:                                                                                                                  
  - exp(-x²/(4t)) = exp(-x² * 1/(4t)) = exp(-4π² * (1/(16π²t)) * x²) = exp(-4π² t' x²)                                                             
                                                                                                                                                   
  So the relationship is t' = 1/(16π²t).                                                                                                           
                                                                                                                                                   
  Let me write a summary for Ылша about what квантор needs to be fixed.                                                                            
                                                                                                                                                   
⏺ Окей, вот диагноз по Defs/Axioms:                                                                                                                
                                                                                                                                                   
  ---                                                                                                                                              
  Текущие определения в Lean                                                                                                                       
                                                                                                                                                   
  1. heat_kernel_A1 (Axioms.lean:234)                                                                                                              
                                                                                                                                                   
  noncomputable def heat_kernel_A1 (t : ℝ) (x : ℝ) : ℝ :=                                                                                          
    1 / Real.sqrt (4 * Real.pi * t) * Real.exp (-x^2 / (4 * t))                                                                                    
                                                                                                                                                   
  2. fejer_heat_window (Defs.lean:85)                                                                                                              
                                                                                                                                                   
  def fejer_heat_window (B t : ℝ) (ξ : ℝ) : ℝ :=                                                                                                   
    max 0 (1 - |ξ| / B) * Real.exp (-4 * Real.pi^2 * t * ξ^2)                                                                                      
                                                                                                                                                   
  3. Fejer_heat_atom (Axioms.lean:238)                                                                                                             
                                                                                                                                                   
  noncomputable def Fejer_heat_atom (B t τ : ℝ) (ξ : ℝ) : ℝ :=                                                                                     
    Fejer_kernel B (ξ - τ) * heat_kernel_A1 t (ξ - τ) +                                                                                            
    Fejer_kernel B (ξ + τ) * heat_kernel_A1 t (ξ + τ)                                                                                              
                                                                                                                                                   
  4. AtomCone_K (Axioms.lean:253)                                                                                                                  
                                                                                                                                                   
  def AtomCone_K (K : ℝ) : Set (ℝ → ℝ) :=                                                                                                          
    { g | ∃ (n : ℕ) (c : Fin n → ℝ) (B t : Fin n → ℝ) (τ : Fin n → ℝ),                                                                             
          (∀ i, c i ≥ 0) ∧                                                                                                                         
          (∀ i, B i > 0) ∧                                                                                                                         
          (∀ i, t i > 0) ∧           -- ← ПРОИЗВОЛЬНЫЙ t для каждого атома!                                                                        
          (∀ i, |τ i| + B i ≤ K) ∧                                                                                                                 
          (∀ x, g x = ∑ i, c i * Fejer_heat_atom (B i) (t i) (τ i) x) ∧                                                                            
          g ∈ W_K K }                                                                                                                              
                                                                                                                                                   
  ---                                                                                                                                              
  🔴 КЛЮЧЕВАЯ ПРОБЛЕМА                                                                                                                             
                                                                                                                                                   
  ДВЕ РАЗНЫЕ ПАРАМЕТРИЗАЦИИ:                                                                                                                       
  ┌───────────────────┬───────────────┬─────────────────────┐                                                                                      
  │      Kernel       │    Formula    │      Параметр       │                                                                                      
  ├───────────────────┼───────────────┼─────────────────────┤                                                                                      
  │ heat_kernel_A1    │ exp(-x²/(4t)) │ t (A1prime)         │                                                                                      
  ├───────────────────┼───────────────┼─────────────────────┤                                                                                      
  │ fejer_heat_window │ exp(-4π²tξ²)  │ t' (A3/RKHS bounds) │                                                                                      
  └───────────────────┴───────────────┴─────────────────────┘                                                                                      
  Связь: t' = 1/(16π²t)                                                                                                                            
                                                                                                                                                   
  При t_sym = 3/50 = 0.06:                                                                                                                         
  t'_equiv = 1/(16π² × 0.06) ≈ 0.105                                                                                                               
                                                                                                                                                   
  Для heat_kernel_A1 с параметром t:                                                                                                               
  t_A1 = 1/(16π² × 0.105) ≈ 0.06 → exp(-x²/(4×0.06)) = exp(-4.17x²)                                                                                
                                                                                                                                                   
  ---                                                                                                                                              
  Какой квантор фиксировать?                                                                                                                       
                                                                                                                                                   
  Чтобы цепочка закрылась:                                                                                                                         
                                                                                                                                                   
  1. AtomCone_K_fixed фиксирует t = t₀ — ✅ уже сделано                                                                                            
  2. Но какой t₀?                                                                                                                                  
    - Если bounds в терминах fejer_heat_window (t_sym = 0.06)                                                                                      
    - То Fejer_heat_atom должен использовать t_A1 = 1/(16π² × t_sym)                                                                               
  3. Или: переписать Fejer_heat_atom через fejer_heat_window:                                                                                      
  -- τ = 0 case:                                                                                                                                   
  Fejer_heat_atom B t 0 ξ = 2 * Fejer_kernel B ξ * heat_kernel_A1 t ξ                                                                              
                                                                                                                                                   
  -- Needs: relate to fejer_heat_window B t' ξ                                                                                                     
  -- Via: t' = 1/(16π²t)                                                                                                                           
                                                                                                                                                   
  ---                                                                                                                                              
  Вердикт для Прошки:                                                                                                                              
  - Либо унифицировать параметризации (заменить heat_kernel_A1 на fejer_heat_window форму)                                                         
  - Либо добавить явную лемму связи с точным пересчётом t ↔ t'                                                                                     
  - Значение t₀: скорее всего t₀ = 1/(16π² × t_sym) чтобы bounds из A3 работали                                

## ASSISTANT
Ы Сделал. Вот готовый **PROSHKA_REQUEST_4.md** — можно сразу кидать Прошке как “Refined Questions” пакет (там ровно про mismatch **AtomCone_K** vs ваши **A3/RKHS** bounds, и про маппинг параметров **heat kernel**).  

[Открыть/скачать PROSHKA_REQUEST_4.md](sandbox:/mnt/data/PROSHKA_REQUEST_4.md)

---

## Что это за файл и зачем он нужен

Этот запрос фиксирует одну штуку без воды:

- У тебя есть доказанная (или почти) механика **A3 floor + Rayleigh + RKHS cap ⇒ Q(Φ) ≥ 0** для **окон типа** **fejer_heat_window** (и вы уже подняли **τ‑shift** слой).
- Но в **A1′ density** и в Lean‑**AtomCone_K** атомы выглядят как **Fejer_heat_atom B t τ** и, если конус реально разрешает “произвольные” **B, t, τ**, то утверждение “Q ≥ 0 для всех атомов” может быть **слишком сильным** по сравнению с тем, что реально доказывается через A3/RKHS (которые обычно привязаны к **фиксированным** параметрам).  
Это прям в контракте/спеках: A1′ делается через **fixed t₀ cone density** и маржин‑условие **|τ|+B ≤ K**, а не через “все t подряд”. fileciteturn1file35

---

## Внутри файла: что именно спрашиваем у Прошки

### 1) Правда ли, что нужно покрывать *все* (B,t,τ)?
Или по paper достаточно доказать неотрицательность **на генераторах** (например, при фиксированном **t₀**) и дальше закрыть всё через **A1′ density + A2 Lipschitz**.

> Это ключевой вопрос, потому что если требовать “все t”, можно случайно потребовать невозможное/непредусмотренное.

### 2) Нужно ли сужать **AtomCone_K** в Lean до fixed‑t₀?
Это выглядит самым естественным, потому что у тебя **density** уже построена на fixed‑t₀ (по A1prime). fileciteturn1file35  
Плюс вы уже **меняли** AtomCone‑условия на маржин‑форму (**|τ|+B ≤ K**) именно чтобы совпасть с бумажной леммой и не ловить support‑дырки. fileciteturn1file33

### 3) Точный маппинг параметров heat‑ядра (A1 ↔ A3/Lean)
В запросе зафиксировано подозрение:

- A1: \(e^{-(x-\tau)^2/(4t)}\)
- A3/Lean: \(e^{-4\pi^2 t' (x-\tau)^2}\)

и поэтому  
\[
t'=\frac{1}{16\pi^2 t}.
\]

Прошке надо подтвердить (или поправить) именно под вашу нормировку **torus period‑1**, **nodes \(\xi_n=\log n/(2\pi)\)** и т.п. (чтобы потом не вылез “переехавший 2π”). fileciteturn1file35

### 4) Проверка “axiom too strong?”
Если Lean‑аксиома/цель сейчас формулируется как “Q ≥ 0 для всех атомов из AtomCone_K” но гипотезы дают positivity только на подсемействе — Прошка должен сказать “да, statement слишком сильный” и предложить корректную версию.

---

## Мини‑словарик, чтобы Прошка не тупил на терминах

- **AtomCone_K** — конус атомов в классе \(\mathcal W_K\); важно, какие параметры (**B,t,τ**) реально разрешены.  
- **A1′ density** — утверждение “генераторы (атомы) плотны в нужном конусе функций” (обычно при **фиксированном t₀**). fileciteturn1file35  
- **A3 floor** — нижняя оценка **P_A(θ) ≥ c\_∗** на торе; это даёт Rayleigh‑нижнюю границу. fileciteturn1file35  
- **RKHS cap** — оценка нормы **prime‑оператора** (compression/rank‑one sum) вида \(\|T_P\|\le \rho\) uniform, чтобы вычесть из arch‑части. fileciteturn1file35  
- **Q_M** — “ослабленный функционал” с фактором \(1/(2M+1)\); это почти всегда тупик для Weil‑цепочки (вы это уже прочувствовали). fileciteturn1file35

---

## Если хочешь “ещё жёстче” (супер‑короткая версия запроса Прошке)

Можешь просто вытащить из файла секции 0 + 3 + 4 и отправить — но я оставил полный контекст, чтобы Прошка не предложил “исправление”, которое ломает контракт (типа тащить \(2M+1\) в оператор).

---

Если дальше твой план — **закрывать τ‑общий случай в Q_nonneg_atoms_proof**, этот Proshka‑пакет прям в точку: он должен сказать, **какую именно** версию “атомного конуса” вы обязаны доказывать (и как ровно бьются параметры heat‑ядра), чтобы не оказалось, что Lean формулирует более сильное утверждение, чем paper. fileciteturn1file33turn1file35

## ASSISTANT
Ы **Переписал твой диагноз нормально (смысл тот же, без каши):**

### Что у нас сейчас *точно* известно
1) **`heat_kernel_A1`** (из **A1prime**/Lean **Axioms.lean**)  
\[
\mathrm{heat\_kernel\_A1}(t,x)=\frac{1}{\sqrt{4\pi t}}\exp\!\left(-\frac{x^2}{4t}\right)
\]  
Это “**гауссиан**” в параметризации **A1** (в экспоненте стоит \(1/t\)).

2) **`fejer_heat_window`** (из **Defs.lean**)  
\[
\mathrm{fejer\_heat\_window}(B,t,\xi)=(1-|\xi|/B)_+\cdot \exp(-4\pi^2 t\xi^2)
\]  
Это “**Fejér×heat окно**” в параметризации **A3** (в экспоненте стоит \(t\)).

3) **`Fejer_heat_atom`** (из **Axioms.lean**)  
сделан через **`Fejer_kernel`** и **`heat_kernel_A1`** со сдвигами \(\pm\tau\).

4) **`AtomCone_K`** (из **Axioms.lean**)  
квантифицирует по **ВСЕМ** параметрам **`B>0`**, **`t>0`**, **`τ`** при условии **`|τ|+B ≤ K`**.  
То есть атомы — это “любой **t**”, а не фиксированный.

5) **Ключевой мост между параметризациями** (это прям алгебра, не гипотеза):  
если положить  
\[
t'=\frac{1}{16\pi^2 t},
\]  
то  
\[
\exp\!\left(-\frac{x^2}{4t}\right)=\exp(-4\pi^2 t' x^2).
\]  
То есть один и тот же гауссиан, просто другой параметр (**`t ↔ t'`**).

---

## Что именно ломает цепочку (в одном предложении)
**Bounds** из **A3/RKHS** у нас доказаны для окон типа **`fejer_heat_window B t ξ`** (A3‑параметризация), а “атомная” часть **T5/A1 density** в Lean живёт на **`Fejer_heat_atom`**, где гауссиан задан как **`heat_kernel_A1`** (A1‑параметризация) **и ещё `AtomCone_K` просит ∀t>0**, что сильно шире, чем то, что мы реально умеем оценивать.

---

## Я сделал то, что ты просил: оформил это как чёткий запрос для Прошки
Я переписал **`PROSHKA_REQUEST_4.md`** так, чтобы там было:
- диагноз (**параметризация A1 vs A3** + **кванторная проблема**),
- точная формула **`t' = 1/(16π² t)`**,
- что именно надо решить (fix конуса vs доказывать uniform по всем t),
- список **Refined Questions**.

Вот файл: [скачать PROSHKA_REQUEST_4.md](sandbox:/mnt/data/PROSHKA_REQUEST_4.md)

---

## Мини‑словарик, чтобы не было “магии”
- **`AtomCone_K`** — “**атомный конус**”: множество функций, которые являются конечными **неотрицательными** линейными комбинациями атомов и лежат в **`W_K`**.  
- **`Fejer_heat_atom`** — “**атом**”: штука вида “**Fejér‑шляпка** × **гауссиан**”, сдвинутая на \(\pm\tau\).  
- **`fejer_heat_window`** — окно из **A3**, которое напрямую стоит в **`Q(Φ)`** и в символе **`P_A`**.  
- **`heat_kernel_A1`** — тот же гауссиан, но с параметром в другой форме (в экспоненте стоит \(1/t\)).  
- **`t' = 1/(16π² t)`** — точная подстановка, которая переводит **A1‑гауссиан** в **A3‑гауссиан** (в смысле экспоненты).  
- **`квантор`** — место, где формулировка требует “для всех параметров”, а доказательство реально даёт “для одного/фиксированного параметра”.

Если хочешь — следующим сообщением разложу, какой вариант фикса “самый дешёвый по изменениям” в Lean: **ограничить `AtomCone_K` до fixed-`t0`** (как в Lemma 6.4) или оставить как есть и чинить доказательства под **∀t** (что почти наверняка боль).

## USER
 # Insight: Atom Quantifier Mismatch & Fixed-t₀ Solution                                                                                       
                                                                                                                                                   
     **Date:** 2026-01-18                                                                                                                          
     **Status:** CRITICAL — blocks Q_nonneg_on_atoms closure                                                                                       
     **Solution:** AtomCone_K_fixed with unified parametrization                                                                                   
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Problem Statement                                                                                                                          
                                                                                                                                                   
     **AtomCone_K** quantifies over ALL parameters (B > 0, t > 0, τ with |τ|+B ≤ K):                                                               
     ```lean                                                                                                                                       
     def AtomCone_K (K : ℝ) : Set (ℝ → ℝ) :=                                                                                                       
       { g | ∃ (n : ℕ) (c B t τ : Fin n → ℝ),                                                                                                      
             ...                                                                                                                                   
             (∀ i, t i > 0) ∧           -- ← ARBITRARY t for each atom!                                                                            
             ... }                                                                                                                                 
     ```                                                                                                                                           
                                                                                                                                                   
     But **A3/RKHS bounds** are proven for FIXED parameters:                                                                                       
     - A3 floor: `t_sym = 3/50 = 0.06`                                                                                                             
     - RKHS cap: `t_rkhs_cap = 40`                                                                                                                 
                                                                                                                                                   
     **Result:** Axiom statement is invalid — hypotheses don't cover conclusion.                                                                   
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Two Heat Kernel Parametrizations                                                                                                           
                                                                                                                                                   
     ### In Lean:                                                                                                                                  
                                                                                                                                                   
     | Definition | Location | Formula |                                                                                                           
     |------------|----------|---------|                                                                                                           
     | `heat_kernel_A1` | Axioms.lean:234 | `1/√(4πt) · exp(-x²/(4t))` |                                                                           
     | `fejer_heat_window` | Defs.lean:85 | `(1-|ξ|/B)₊ · exp(-4π²tξ²)` |                                                                          
                                                                                                                                                   
     ### Relationship:                                                                                                                             
     ```                                                                                                                                           
     exp(-x²/(4t)) = exp(-4π² t' x²)  when  t' = 1/(16π²t)                                                                                         
     ```                                                                                                                                           
                                                                                                                                                   
     ### Parameter Conversion Table:                                                                                                               
                                                                                                                                                   
     | heat_kernel_A1 (t) | fejer_heat_window (t') | Relationship |                                                                                
     |--------------------|------------------------|--------------|                                                                                
     | t = 0.06 | t' ≈ 0.105 | t' = 1/(16π²t) |                                                                                                    
     | t = 40 | t' ≈ 0.000158 | t' = 1/(16π²t) |                                                                                                   
     | t → ∞ | t' → 0 | wider kernel |                                                                                                             
     | t → 0 | t' → ∞ | narrower kernel |                                                                                                          
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Solution: AtomCone_K_fixed                                                                                                                 
                                                                                                                                                   
     **Implemented:** Fix t = t₀ for all atoms in the cone.                                                                                        
                                                                                                                                                   
     ```lean                                                                                                                                       
     def AtomCone_K_fixed (K t₀ : ℝ) : Set (ℝ → ℝ) :=                                                                                              
       { g | ∃ (n : ℕ) (c B τ : Fin n → ℝ),                                                                                                        
             (∀ i, c i ≥ 0) ∧                                                                                                                      
             (∀ i, B i > 0) ∧                                                                                                                      
             (∀ i, |τ i| + B i ≤ K) ∧                                                                                                              
             (∀ x, g x = ∑ i, c i * Fejer_heat_atom (B i) t₀ (τ i) x) ∧                                                                            
             g ∈ W_K K }                                                                                                                           
     ```                                                                                                                                           
                                                                                                                                                   
     **Key properties:**                                                                                                                           
     - `AtomCone_K_fixed K t₀ ⊆ AtomCone_K K` (subset)                                                                                             
     - Fixed t₀ still gives density in C⁺_even(K) (LaTeX Lemma a1-fixed-t-density)                                                                 
     - Bounds now match: use t₀ such that parametrization aligns with A3/RKHS                                                                      
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Open Questions for Прошка                                                                                                                  
                                                                                                                                                   
     ### Q1: Which t₀?                                                                                                                             
                                                                                                                                                   
     If A3 bounds use `fejer_heat_window` with t_sym = 0.06:                                                                                       
     - Equivalent `heat_kernel_A1` parameter: `t₀ = 1/(16π² × 0.06) ≈ 0.105`                                                                       
                                                                                                                                                   
     Or should we:                                                                                                                                 
     - Rewrite `Fejer_heat_atom` in terms of `fejer_heat_window`?                                                                                  
     - Use a different t₀ for RKHS compatibility?                                                                                                  
                                                                                                                                                   
     ### Q2: τ-shift invariance                                                                                                                    
                                                                                                                                                   
     Does `Q(Φ_τ) = Q(Φ)` hold for τ-translated atoms?                                                                                             
     - If yes: only need τ = 0 case                                                                                                                
     - If no: need bounds uniform in τ                                                                                                             
                                                                                                                                                   
     ### Q3: B scaling                                                                                                                             
                                                                                                                                                   
     Do bounds hold for all B > 0, or need B ≥ B_min?                                                                                              
     - Current A3: works for specific B_min                                                                                                        
     - If need restriction: add to `AtomCone_K_fixed` definition                                                                                   
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Files Modified                                                                                                                             
                                                                                                                                                   
     1. **Q3/Axioms.lean**                                                                                                                         
        - Added `AtomCone_K_fixed` definition                                                                                                      
        - Added `Q_nonneg_on_atoms_fixed_t` axiom                                                                                                  
        - Added `AtomCone_K_fixed_subset` lemma                                                                                                    
                                                                                                                                                   
     2. **Q3/Proofs/Q_nonneg_atoms_proof.lean**                                                                                                    
        - Updated to use fixed-t₀ approach                                                                                                         
        - 4 sorries remaining (see PROSHKA_REQUEST_4.md)                                                                                           
                                                                                                                                                   
     3. **docs/PROSHKA_REQUEST_4.md**                                                                                                              
        - Updated with refined questions                                                                                                           
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Remaining Sorries                                                                                                                          
                                                                                                                                                   
     | Sorry | What's needed |                                                                                                                     
     |-------|---------------|                                                                                                                     
     | `Fejer_heat_atom_decomposition` | Algebraic identity relating parametrizations |                                                            
     | `arch_term_phi_shift_ge` | `arch_term(Φ_shift) ≥ c*/2` for fixed t₀ |                                                                       
     | `prime_term_phi_shift_le` | `prime_term(Φ_shift) ≤ c*/4` for fixed t₀ |                                                                     
     | `Q_single_atom_nonneg.hQ_decomp` | Q linearity wiring |                                                                                     
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     ## Key Insight                                                                                                                                
                                                                                                                                                   
     > **The fix is NOT to prove more, but to MATCH what we already proved.**                                                                      
     >                                                                                                                                             
     > A3/RKHS bounds exist for specific parameters.                                                                                               
     > AtomCone_K was too general.                                                                                                                 
     > AtomCone_K_fixed aligns the quantifiers.                                                                                                    
     > Density still holds (Lemma a1-fixed-t-density).                                                                                             
                                                                                                                                                   
     ---                                                                                                                                           
                                                                                                                                                   
     *Session: 2026-01-18*                                              

## USER
                                                                                                                                                  
  Текущий статус:                                                                                                                                  
  ┌─────────────────────────────┬───────────────────────────┐                                                                                      
  │            Item             │          Status           │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ AtomCone_K_fixed            │ ✅ Добавлен в Axioms.lean │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ Прошка confirmation         │ ✅ Решение одобрено       │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ t' = 1/(16π²t)              │ ✅ Подтверждено           │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ Aristotle #1 (Fejer_decomp) │ 🔄 Running                │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ Aristotle #4 (Q_linearity)  │ 🔄 Running                │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ Sorry #2 (arch_term)        │ ⏳ Ждёт конкретный t₀     │                                                                                      
  ├─────────────────────────────┼───────────────────────────┤                                                                                      
  │ Sorry #3 (prime_term)       │ ⏳ Ждёт конкретный t₀     │                                                                                      
  └─────────────────────────────┴───────────────────────────┘                                                                                      
  Следующий вопрос к Прошке:                                                                                                                       
                                                                                                                                                   
  Какой конкретно t₀ использовать?                                                                                                                 
  - t'_sym = 0.06 (A3-параметризация) → t₀ ≈ 0.105 (A1-параметризация)?                                                                            
  - Или другое значение?                                                                                                                           
                                                                                    

## ASSISTANT
Ы **Сделал.** Я переписал **`PROSHKA_REQUEST_4.md`** под твой актуальный диагноз (**AtomCone_K quantifier mismatch + fixed‑t₀** + связь параметров **t ↔ t'**) и добавил короткую запись в **`INSIGHTS.md`**, чтобы этот баг больше не вылезал «из ниоткуда».

- [Скачать PROSHKA_REQUEST_4.md](sandbox:/mnt/data/PROSHKA_REQUEST_4.md)
- [Скачать INSIGHTS.md](sandbox:/mnt/data/INSIGHTS.md)

## Что именно теперь зафиксировано в PROSHKA_REQUEST_4.md

### 1) Главный баг, без философии
- **`AtomCone_K`** (конус атомов) в Lean **кванторит по ВСЕМ** параметрам **`B>0`**, **`t>0`**, **`τ`** (с условием **`|τ|+B ≤ K`**).
- А ваши рабочие bound’ы (**A3 floor** и **RKHS cap**) реально доказаны для **фиксированных** параметров (**`t_sym`**, **`t_rkhs_cap`**, и т.п.), причём для окна типа **`fejer_heat_window`**.
- Значит гипотезы ≠ заключение. Это **логический разрыв кванторов**, а не «не хватает леммы».

### 2) Два разных heat‑ядра и точная связь
В файле прямо записано, что есть две параметризации:

- **`heat_kernel_A1`**:  
  \[
  \frac{1}{\sqrt{4\pi t}} e^{-x^2/(4t)}
  \]
- **`fejer_heat_window`**:  
  \[
  (1-|ξ|/B)_+\, e^{-4\pi^2 t' ξ^2}
  \]

и **точная алгебраическая связь**:
\[
e^{-x^2/(4t)} = e^{-4\pi^2 t' x^2}\quad\text{при}\quad t'=\frac{1}{16\pi^2 t}.
\]

Это ключ к тому, чтобы **переписать `Fejer_heat_atom` как положительный множитель × (сумма двух `phi_shift`)** и переиспользовать ваш уже построенный τ‑shift Rayleigh слой.

### 3) Предлагаемое решение: **`AtomCone_K_fixed K t₀`**
В запросе закреплено предложение:
- Ввести **`AtomCone_K_fixed K t₀`** — тот же конус, но **все атомы используют один и тот же `t₀`**.
- Это должно совпасть с бумажной **fixed‑t₀ density lemma** (A1′), то есть **не ослабить** финальную цепочку, если плотность действительно доказана.

### 4) Refined Questions (то, что ты просил)
Я вынес ровно те вопросы, которые ты дал (и чуть подчистил формулировки, чтобы Прошка не расползся):
1) можно ли вообще доказать **для всех `t>0`** без новых аксиом (скорее нет)?  
2) правильно ли **ограничить конус** до фиксированного **`t₀`** (скорее да)?  
3) подтвердить **точную конверсию** **`t' = 1/(16π² t)`** + константы (чтоб в Lean было equality, не “≈”).  
4) **аудит аксиомы**: не слишком ли сильный statement в Lean относительно paper.

## Мини‑словарик, чтобы не путаться
- **`AtomCone_K`** — множество функций, представимых как **неотрицательная комбинация атомов** + условие принадлежности **`W_K`** (ограниченная поддержка/контроль на \([-K,K]\) — зависит от ваших дефов).
- **`Fejer_heat_atom`** — атом из **Fejér‑ядра** (треугольная “шапка” \((1-|x|/B)_+\)) и **теплового ядра** (**`heat_kernel_A1`**) с сдвигом **`±τ`**.
- **`fejer_heat_window`** — то же “Fejér × Gaussian”, но Gaussian записан в **другой параметризации** (**`exp(-4π² t ξ²)`**).
- **`t' = 1/(16π² t)`** — точная замена параметра, чтобы согласовать **`exp(-x²/(4t))`** и **`exp(-4π² t' x²)`**.
- **`A3 floor`** — нижняя оценка **символа** \(P_A(θ)\) на торе: “арх‑часть точно даёт запас \(c_*\)”.
- **`RKHS cap`** — верхняя оценка нормы/вклада прайм‑оператора (чтобы прайм‑часть не съела floor).

Если хочешь — следующим ходом я могу так же «по делу» накидать короткий **Lean‑скелет** леммы **`Fejer_heat_atom_decomposition`** (с правильным `t'` и константой), чтобы ты сразу видел, где оно встанет в `Q_nonneg_atoms_proof`.

## ASSISTANT
Ы да, тут надо просто **зафиксировать один t₀** так, чтобы он **точно совпал** с тем **tsym**, под который у вас уже есть **A3‑floor** (и дальше весь мост).

## 0) Главное: t₀ в A1 можно выбрать *любой*, значит выбираем тот, что “матчит” A3
В канон‑PDF прямо сказано: **Fixed‑t₀ cone density** верна для **любого** \(t_0>0\) (то есть для плотности конуса t₀ не “священное число”).【408:4†RH_Q3.pdf†L36-L40】【408:7†RH_Q3.pdf†L1-L5】

Значит т₀ мы выбираем не ради плотности, а ради **совместимости** с тем, что уже доказано в A3/RKHS.

- **Плотность**: ок при любом \(t_0\).  
- **Совместимость с A3‑мостом**: нужен конкретный \(t_0\), который “переводит” **heat_kernel_A1** в ваш **fejer_heat_window** с *тем же* \(t_{\mathrm{sym}}\).

---

## 1) Две параметризации тепла и их точная связь
У вас два “тепла”:

### (A) **heat_kernel_A1** (A1‑параметризация)
\[
\rho_t(x) = \frac{1}{\sqrt{4\pi t}}\, e^{-x^2/(4t)}.
\]
Это ровно то, что в PDF используется в атомах.【408:10†RH_Q3.pdf†L9-L16】

### (B) **fejer_heat_window** (A3‑параметризация)
\[
\Phi_{B,t'}(\xi)= (1-|\xi|/B)_+ \, e^{-4\pi^2 t' \xi^2}.
\]
Это то, что у вас живёт в **A3/Rayleigh** части (Toeplitz‑символ и т.п.).

### Точное равенство экспонент
Чтобы
\[
e^{-x^2/(4t)} = e^{-4\pi^2 t' x^2},
\]
нужно и достаточно:
\[
t' = \frac{1}{16\pi^2 t}
\quad\Longleftrightarrow\quad
t = \frac{1}{16\pi^2 t'}.
\]

Это и есть ваш “конвертер”.

**Технические термины:**
- **параметризация** — разные способы записать *тот же* гауссиан, где “t” стоит либо в знаменателе, либо множителем в экспоненте.
- **конвертер t↔t′** — формула, которая делает экспоненты идентичными.

---

## 2) Что именно значит “выбрать t₀”
Ты хочешь, чтобы атомы в **AtomCone_K_fixed K t₀** после раскрытия выглядели как (положительная константа) × (сдвинутые **fejer_heat_window** с вашим **tsym**). Тогда **все готовые леммы A3/RKHS** применяются без нового матана.

Атом из PDF (и Lean‑версии) — это
\[
\Lambda_B(\xi-\tau)\rho_{t_0}(\xi-\tau)+\Lambda_B(\xi+\tau)\rho_{t_0}(\xi+\tau).
\]
(в PDF ещё стоит нормировка/симметризация; но **масштабирование на положительную константу конус не меняет** — это тоже прямо оговорено в тексте)【408:10†RH_Q3.pdf†L15-L20】.

После замены \(\rho_{t_0}\) через экспоненту \(e^{-4\pi^2 t_{\mathrm{sym}} (\cdot)^2}\) ты получаешь ровно **phi_shift** слой.

---

## 3) Конкретный выбор: бери \(t_0\), соответствующий \(t_{\mathrm{sym}} = 3/50\)
В канон‑PDF значения констант явно указаны:  
**tsym = 3/50**【408:6†RH_Q3.pdf†L1-L6】.

Значит берём
\[
t_0 := \frac{1}{16\pi^2\, t_{\mathrm{sym}}}
= \frac{1}{16\pi^2\cdot (3/50)}
= \frac{25}{24\pi^2}
\approx 0.1053.
\]

Это ровно твоя гипотеза “t′_sym=0.06 ⇒ t₀≈0.105”.

### Почему это лучший выбор (без лишней боли)
- **A3 floor** у вас заточен под **tsym** (и в PDF он зафиксирован как структурная константа).【408:6†RH_Q3.pdf†L1-L6】
- **t₀ для плотности свободен** → можно подогнать под A3, а не наоборот.【408:4†RH_Q3.pdf†L36-L40】【408:7†RH_Q3.pdf†L1-L5】
- Нормировочный множитель \(1/\sqrt{4\pi t_0}\) **положительный**, его можно **всосать в коэффициенты** конуса (или просто игнорировать для знака \(Q\)). В PDF это прямо проговаривается как допустимая операция на генераторах конуса.【408:10†RH_Q3.pdf†L15-L20】

---

## 4) Почему НЕ надо выбирать t₀ “под RKHS 40”
В вашем PROSHKA_REQUEST есть идея “а может t₀ = t_rkhs_cap?”.【408:0†PROSHKA_REQUEST_4.md†L55-L62】

Проблема: если ты выберешь t₀ так, чтобы \(t' = 40\), то твой **A3‑floor для tsym** перестаёт быть применимым “как есть”. Придётся:
- либо пересчитывать **A3 floor** под другой \(t'\),
- либо строить новый мост между параметрами (что обычно и становится очередной ямой).

Короче: **RKHS‑cap** пусть живёт как отдельная штука, а t₀ выбираем так, чтобы **tsym‑часть** сразу попадала в уже доказанное.

---

## 5) Lean‑конкретика: что именно зафиксировать в коде
### (i) Зафиксируй константу
- **tsym** у вас уже есть (или задаётся как `3/50`).
- Определи
```lean
noncomputable def t0_A1 : ℝ := 1 / (16 * Real.pi^2 * t_sym)
```
(по смыслу \(t_0 = 1/(16\pi^2 t_{\mathrm{sym}})\)).

### (ii) Лемма‑конвертер экспоненты
Нужна простая “алгебра”:

**`exp(-x^2/(4 t0)) = exp(-4π^2 * t_sym * x^2)`** при `t0 = 1/(16π^2 t_sym)`.

Это закрывает Sorry #1‑типа (Fejer_decomp) почти полностью: потом ты просто выносишь константу `1/Real.sqrt(4*pi*t0)` и идентифицируешь **phi_shift**.

### (iii) Лемма разложения атома через `phi_shift`
Что-то вида (по твоим обозначениям):
\[
\text{Fejer\_heat\_atom}(B,t_0,\tau)
= C(t_0)\cdot \big(\phi\_shift(B,t_{\mathrm{sym}},\tau)+\phi\_shift(B,t_{\mathrm{sym}},-\tau)\big)
\]
где \(C(t_0)=1/\sqrt{4\pi t_0}\) (плюс возможная 1/2 — зависит от того, как у вас зашит Sym).

**Ключ:** \(C(t_0)>0\), значит для знака \(Q\) не страшно.

---

## 6) Ответ на твой вопрос в одну строку
**Выбирай**
\[
\boxed{t_0 = \frac{1}{16\pi^2\, t_{\mathrm{sym}}}}
\quad\text{и при } t_{\mathrm{sym}}=\frac{3}{50}\text{ это }\;
\boxed{t_0=\frac{25}{24\pi^2}\approx 0.1053.}
\]
Это полностью консистентно с канон‑PDF (tsym фиксирован), и легально по A1′ (fixed‑t₀ density для любого t₀).【408:6†RH_Q3.pdf†L1-L6】【408:7†RH_Q3.pdf†L1-L5】

---

Если хочешь, следующим сообщением я дам прям “минимальный Lean‑патч” (кусок кода) для:
1) `t0_A1`  
2) леммы `heat_kernel_A1_reparam`  
3) леммы `Fejer_heat_atom_eq_const_mul_phi_shift_sum`  

…так, чтобы твои **Sorry #2/#3** перестали “ждать t₀”, и можно было цеплять уже готовые **rayleigh_Q_eq_Q_shift** и **prime_term_eq_nodes_sum_shift**.

