# Matches mismatches инварианты

https://chat.openai.com/c/6973e278-f7c8-832f-9f7e-ed2d945e3fa8

## ASSISTANT
### Matches / mismatches (инварианты 1–8)

Ниже — **контракт**, который должен совпадать с тем, что ты держишь в Lean/в цепочке. Я не “проверяю репозиторий” (у меня здесь нет твоего Lean-кода), поэтому отмечаю **где обычно происходит дрейф** и что именно считать mismatch. fileciteturn0file8 fileciteturn0file11

1) **Sign**  
**Match:** \(Q(\Phi)=Q_{\mathrm{arch}}(\Phi)-Q_{\mathrm{prime}}(\Phi)\).  
**Mismatch-сигнал:** где-то стоит “+” или prime/arch поменялись местами.  
**Последствие:** ломается весь бюджет “floor − cap”.

2) **Normalization**  
**Match:** \(\xi_n=\log n/(2\pi)\) и \(a_*(\xi)=2\pi a(\xi)\).  
**Mismatch-сигнал:** узлы \(\log n\) без деления на \(2\pi\), или \(a\) используется без множителя \(2\pi\).  
**Последствие:** появляется фантомный “лишний \(2\pi\)” в bridge и/или неверные константы цели.

3) **Torus / Fourier basis**  
**Match:** период‑1: \(\mathbb T=[-1/2,1/2]\), базис \(e^{2\pi i k\theta}\), мера \(d\theta\).  
**Mismatch-сигнал:** переход к \(2\pi\)-периодическому кругу, \([- \pi,\pi]\), или базис \(e^{ik\theta}\).  
**Последствие:** сдвигаются все нормировки коэффициентов/Toeplitz.

4) **A3 symbol**  
**Match:** символ именно \(P_A\) как периодизация \(2\pi\sum_m g_{B,t_{\rm sym}}(\theta+m)\), где \(g=a\Phi_{B,t}\).  
**Mismatch-сигнал:** A3 “символ” внезапно называется/строится через `a_star` (как объект на \(\mathbb R\)) вместо periodized \(P_A\).  
**Последствие:** несостыковка Toeplitz–Rayleigh слоя с остальной цепочкой.

5) **Floor constant**  
**Match:** \(c_*=11/10\).  
**Mismatch-сигнал:** где-то всплывает старое \(1.5\) или другие “красивые” числа.  
**Последствие:** неверный бюджет в финальном \(\lambda_{\min}(T_M[P_A]-T_P)\) и неверные “целевые” заявления.

6) **Rayleigh step**  
**Match:** \(\lambda_{\min}(T_M[P_A])\ge \min_{\mathbb T} P_A\) — **достаточно**, SB не обязателен.  
**Mismatch-сигнал:** Szegő–Böttcher выставлен как “блокер” (без него якобы нельзя).  
**Последствие:** искусственный техдолг и лишняя дискретизация.

7) **Prime cap**  
**Match:** разделение шкал: \(t_{\rm rkhs}\ge 1\Rightarrow \rho(1)<1/25\), и это отдельно от \(t_{\rm sym}\).  
**Mismatch-сигнал:** смешение \(t_{\rm sym}\) и \(t_{\rm rkhs}\), или \(w_Q\) и \(w_{\rm RKHS}\) считаются “одним и тем же”.  
**Последствие:** cap начинает “плавать” и перестаёт быть униформным.

8) **Goal**  
**Match:** цель — только \(Q(\Phi)\ge 0\) (не “\(Q\ge 1.125\)” и не “строгий зазор” как утверждение теоремы).  
**Mismatch-сигнал:** в statement/roadmap появляется \(Q\ge 1.125\) или что-то подобное без уточнения нормировок.  
**Последствие:** формально доказываешь не тот тезис (или неверный).

---

### Reassembled text of §0–§8 (single block)

## §0. Status and goal

**Goal:** Prove only $Q(\Phi) \ge 0$ for all $\Phi \in \mathcal{W}$.

**Status:** Conditional chain "Tier-2 ==> RH" via Weil criterion (no "RH proven").

---

## §1. Normalization / sign / torus (LOCKED)

### Sign (MINUS)
$$
Q(\Phi) = Q_{\mathrm{arch}}(\Phi) - Q_{\mathrm{prime}}(\Phi)
$$

### T0 normalization
$$
a_*(\xi) = 2\pi a(\xi), \qquad \xi_n = \frac{\log n}{2\pi}
$$

### Period-1 torus
$$
\mathbb{T} = [-1/2, 1/2], \quad e_k(\theta) = e^{2\pi i k\theta}, \quad d\theta
$$

### A3 symbol (period-1)
$$
P_A(\theta) = 2\pi \sum_{m \in \mathbb{Z}} g_{B,t_{\mathrm{sym}}}(\theta + m),
\quad g_{B,t}(\xi) = a(\xi)\Phi_{B,t}(\xi)
$$

---

## §1.1 Contract checks (RH_Q3)

- A3 symbol is `P_A` (periodized, windowed). Do not use `a_star` as A3 symbol.
- Toeplitz in A3 uses Fourier/Rayleigh on period-1 torus; sampling `P(π(i-j)/M)` is not allowed in the main chain.
- Prime operator in A3 is the compression/rank-one sum `T_P^{(M)}` with `w_Q`, not direct-indexed Gaussian.
- Keep `t_sym` (symbol) and `t_rkhs` (cap) distinct; do not mix `w_Q` and `w_RKHS`.

---

## §2. Tier-1 facts

### Weil criterion
$$
Q \ge 0 \text{ on } \mathcal{W} \iff \mathrm{RH}
$$

### Toeplitz quadratic form (Rayleigh core)
For trig polynomials $p$ in $P_M$:
$$
\langle T_M[P_A]p,p\rangle = \int_{\mathbb{T}} P_A(\theta) |p(\theta)|^2\,d\theta
$$

### Rayleigh lower bound (no Szego-Bottcher needed)
$$
\lambda_{\min}(T_M[P_A]) \ge \min_{\theta \in \mathbb{T}} P_A(\theta)
$$

**Note:** The classical Szego-Bottcher estimate
$$
\lambda_{\min}(T_M[\sigma]) \ge \min \sigma - C_{SB} \cdot \omega_\sigma(1/(2M))
$$
is **optional** and follows as a corollary since $\omega_\sigma \ge 0$.

---

## §3. Tier-2 modules (current plan)

### A1' density (fixed $t_0$, hat interpolation)
Atoms are restricted by the margin condition:
$$
|\tau| + B \le K
$$
so support stays in $[-K,K]$. Use hat interpolation (Lemma 6.4) on $[-K,K]$.

### A2 (Lipschitz)
$Q$ is Lipschitz on each $\mathcal{W}_K$.

### A3 floor (pointwise)
$$
P_A(\theta) \ge c_* = 11/10 \quad \forall \theta \in [-1/2, 1/2]
$$

### RKHS cap
For $t_{\mathrm{rkhs}} \ge t_{*,\mathrm{rkhs}}^{\mathrm{unif}} = 1$:
$$
\|T_P\| \le \rho(1) < 1/25
$$

### Rayleigh bridge (p = 1)
$Q(\Phi_{B,t_{\mathrm{sym}}})$ equals the Rayleigh quotient of
$T_M[P_A] - T_P$ at $p \equiv 1$ (no extra $2\pi$ factor; already in $P_A$).

---

## §4. Discretization (optional)

No $M_0$ is required if we use the Rayleigh lower bound directly.
If we still want Szego-Bottcher, treat it as a weaker corollary:
$$
\lambda_{\min} \ge \min P_A \ge \min P_A - 4\,\omega_{P_A}(1/(2M))
$$

---

## §5. Positivity on generators

1) **A3 floor:** $P_A \ge c_*$ (pointwise)  
2) **Rayleigh:** $\lambda_{\min}(T_M[P_A]) \ge c_*$  
3) **RKHS cap:** $\|T_P\| \le c_*/4$

Hence
$$
\lambda_{\min}(T_M[P_A] - T_P) \ge c_* - \|T_P\| \ge 3c_*/4 > 0
$$
so $Q(\Phi_{B,t_{\mathrm{sym}}}) \ge 0$.

---

## §6. Closure and RH

By A1'+A2 we extend $Q \ge 0$ from generators to all of $\mathcal{W}_K$, then to $\mathcal{W}$.  
By Weil criterion we obtain **RH (conditional on Tier-2)**.

---

## §7. Key invariants (checklist)

| # | Invariant | Value |
|---|-----------|-------|
| 1 | Sign | $Q = Q_{\mathrm{arch}} - Q_{\mathrm{prime}}$ |
| 2 | Normalization | $\xi_n = \log n/(2\pi)$, $a_* = 2\pi a$ |
| 3 | Torus | period-1, $\mathbb{T} = [-1/2, 1/2]$ |
| 4 | Symbol | $P_A = 2\pi \sum_m g(\theta+m)$ |
| 5 | Floor | $c_* = 11/10$ (NOT 1.5) |
| 6 | Rayleigh | $\lambda_{\min} \ge \min P_A$ (no SB needed) |
| 7 | Prime cap | $t_{\mathrm{rkhs}} \ge 1 \Rightarrow \rho(1) < 1/25$ |
| 8 | Goal | $Q(\Phi) \ge 0$ (NOT $\ge 1.125$) |

---

## §8. Response format

- Short "matches / mismatches" report for items 1-8
- Reassembled text of §0-§8 (single block)
- No new notation, no external links

fileciteturn0file8

