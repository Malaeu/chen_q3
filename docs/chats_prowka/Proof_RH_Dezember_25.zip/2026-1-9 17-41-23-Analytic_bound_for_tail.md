# Analytic bound for tail

https://chat.openai.com/c/6960db4f-ca60-832f-9e91-06a29a3b53e7

## USER
We need an analytic bound for the tail: prove in Q3 that for all xi >= 5/2, |Re(psi(1/4 + i*pi*xi))| <= log(1 + xi^2). We already have the series representation from Gamma'/Gamma (digammaSeq -> digamma), so the remaining step is a real-analysis bound on the series or via the integral formula. We can use: psi(sigma+i*tau) = -gamma + ∫_0^∞ (e^{-t}/t - e^{-sigma t} cos(tau t)/(1-e^{-t})) dt (sigma>0). Do you know a clean inequality or reference that yields |Re psi(1/4 + i*pi*xi)| <= log(1+xi^2) for xi>=5/2, or a slightly weaker explicit bound sufficient for tail estimates? Please outline steps usable for Lean formalization.

## ASSISTANT
## 0. Теорема: что можно и что нельзя (важная аномалия)

**Феномен/аномалия (сигнал):** утверждение  
\[
\forall \xi\ge \tfrac52:\quad \bigl|\Re\psi(\tfrac14+i\pi\xi)\bigr|\le \log(1+\xi^2)
\]
в таком виде **неверно** (падает уже на \(\xi=\tfrac52\)). Причина простая: \(\Re\psi(\sigma+i\tau)\) при больших \(|\tau|\) ведёт себя как \(\log|\tau|\), а здесь \(\tau=\pi\xi\); на \(\xi=2.5\) фактор \(\pi\) ещё “слишком большой” по сравнению с \(\xi^2\).

**Решение/применение:** для tail-оценок тебе достаточно одной из двух корректных замен:

1) **Сдвинуть порог:** для \(\xi\ge 3\) уже верно без константы:
\[
\bigl|\Re\psi(\tfrac14+i\pi\xi)\bigr|\le \log(1+\xi^2).
\]

2) **Оставить порог \(\xi\ge\tfrac52\)**, но добавить маленькую явную константу:
\[
\forall \xi\ge \tfrac52:\quad 
\bigl|\Re\psi(\tfrac14+i\pi\xi)\bigr|\le \log(1+\xi^2)+\tfrac{1}{10}.
\]
Эта версия “железобетонно” проходит в Lean на рациональных оценках \(\pi\) и стандартных леммах про \(\log\).

И ещё: если цель именно **tail интеграла в Лемме 8.19**, то вообще не нужно лезть в \(\Re\psi\): в тексте уже есть **готовый логарифмический рост** для \(a(\xi)=\log\pi-\Re\psi(\tfrac14+i\pi\xi)\) через \(a'\) (Леммы 8.16–8.17). Это самый Lean-дружелюбный маршрут. 【62:12†RH_Q3.pdf†L70-L83】【62:0†RH_Q3.pdf†L53-L77】

---

## 1. Формальное утверждение (корректная версия)

### Вариант A (рекомендуемый для \(\xi\ge \tfrac52\))
\[
\forall \xi\in\mathbb R,\ \xi\ge \tfrac52:\quad 
\bigl|\Re\psi(\tfrac14+i\pi\xi)\bigr|\le \log(1+\xi^2)+\tfrac{1}{10}.
\]
**Статус:** стандартный анализ при условии классической remainder-оценки дигаммы (DLMF 5.11), которую вы уже используете в Q3. 【66:0†RH_Q3.pdf†L32-L48】

### Вариант B (если хочешь без добавки, но с порогом 3)
\[
\forall \xi\ge 3:\quad \bigl|\Re\psi(\tfrac14+i\pi\xi)\bigr|\le \log(1+\xi^2).
\]

---

## 2. Определения и нотация

- \(\psi(z)=\Gamma'(z)/\Gamma(z)\) — дигамма.  
- \(z=\sigma+i\tau\), где \(\sigma=\tfrac14\), \(\tau=\pi\xi\).  
- \(|z|^2=\sigma^2+\tau^2=\tfrac{1}{16}+\pi^2\xi^2\).  
- В Q3 используется \(a(\xi)=\log\pi-\Re\psi(\tfrac14+i\pi\xi)\). 【66:4†RH_Q3.pdf†L47-L53】

---

## 3. Зависимости

1) **Remainder-оценка дигаммы** (DLMF §5.11), уже применённая в Лемме 8.18:
\[
\Bigl|\psi(z)-\log z+\frac{1}{2z}\Bigr|\le \frac{1}{12|z|^2}\quad(\Re z>0).
\]
【66:0†RH_Q3.pdf†L32-L48】

2) Базовые оценки:
- \(\log(1+u)\le u\) для \(u>-1\).
- \(\log\) монотонна на \((0,\infty)\).
- \(\sqrt{1+u}\le 1+\frac{u}{2}\) для \(u\ge 0\).
- Рациональные bounds для \(\pi\): \(\pi<\frac{22}{7}\), \(\pi>3\) (в тексте они используются постоянно). 【66:0†RH_Q3.pdf†L11-L13】【66:0†RH_Q3.pdf†L51-L52】

---

## 4. План доказательства (для варианта A)

1) Из remainder-оценки получить верхнюю оценку на \(\Re\psi(z)\) через \(\log|z|\).
2) Разложить \(\log|z|=\log(\pi\xi)+\tfrac12\log(1+\frac{1}{16\pi^2\xi^2})\) и грубо оценить добавку.
3) Сравнить \(\log(\pi\xi)\) с \(\log(1+\xi^2)\) через убывание функции \(\xi\mapsto \xi/(1+\xi^2)\) на \([1,\infty)\) и \(\pi<22/7\).
4) Показать \(\Re\psi(z)\ge 0\) для \(\xi\ge 5/2\), чтобы \(|\Re\psi|=\Re\psi\).

---

## 5. Леммы (Lean-скелет)

### Лемма 1: из remainder-оценки в “real part bound”
**Формулировка.** Пусть \(\Re z>0\) и
\[
\Bigl|\psi(z)-\log z+\frac{1}{2z}\Bigr|\le \frac{1}{12|z|^2}.
\]
Тогда
\[
\Re\psi(z)\le \log|z|-\Re\Bigl(\frac{1}{2z}\Bigr)+\frac{1}{12|z|^2}
\le \log|z|.
\]

**Доказательство (шаги для Lean).**
1. Обозначь \(\varepsilon := \psi(z)-\log z+\frac{1}{2z}\).
2. Из \(|\varepsilon|\le \frac{1}{12|z|^2}\) следует \(\Re\varepsilon\le \frac{1}{12|z|^2}\) (лемма вида `re_le_abs` + `abs_le`).
3. \(\Re\log z = \log|z|\) при \(\Re z>0\) (в Lean: через `Complex.log_re`/ветку `Complex.log` при `re z > 0`).
4. Сложить реальныe части.

*(Эта техника ровно та же, что используется в тексте, когда “берут real parts” от remainder-оценки.)* 【66:0†RH_Q3.pdf†L32-L48】

---

### Лемма 2: явное разложение \(\log|\,\tfrac14+i\pi\xi\,|\)
**Формулировка.** Для \(\xi>0\),
\[
\log\bigl|\tfrac14+i\pi\xi\bigr|
=\log(\pi\xi)+\frac12\log\Bigl(1+\frac{1}{16\pi^2\xi^2}\Bigr).
\]

**Доказательство.**  
\(|\tfrac14+i\pi\xi|=\sqrt{\tfrac{1}{16}+\pi^2\xi^2}=\pi\xi\sqrt{1+\tfrac{1}{16\pi^2\xi^2}}\); затем \(\log(ab)=\log a+\log b\), \(\log\sqrt{u}=\tfrac12\log u\).

Lean-заметки: нужно \(\xi>0\) чтобы \(\log(\pi\xi)\) был про `Real.log` на положительном.

---

### Лемма 3: маленькая добавка к \(\log(\pi\xi)\)
**Формулировка.** Для \(\xi\ge \tfrac52\),
\[
\frac12\log\Bigl(1+\frac{1}{16\pi^2\xi^2}\Bigr)\le \frac{1}{1800}.
\]

**Доказательство (чисто рационально).**
1. Используй \(\log(1+u)\le u\) при \(u\ge 0\):
\[
\frac12\log(1+u)\le \frac{u}{2},\quad u=\frac{1}{16\pi^2\xi^2}.
\]
2. Далее оцени \(u/2 = \frac{1}{32\pi^2\xi^2}\).
3. При \(\pi>3\Rightarrow \pi^2>9\) и \(\xi\ge 5/2\Rightarrow \xi^2\ge 25/4\):
\[
\frac{1}{32\pi^2\xi^2} < \frac{1}{32\cdot 9\cdot 25/4}=\frac{1}{1800}.
\]

---

### Лемма 4: сравнение \(\log(\pi\xi)\) и \(\log(1+\xi^2)\)
**Формулировка.** Для \(\xi\ge \tfrac52\),
\[
\log(\pi\xi)\le \log(1+\xi^2)+\frac{17}{203}.
\]

**Доказательство (без производных, “алгебраическая монотонность”).**
1. Рассмотри \(r(x)=\frac{x}{1+x^2}\). Покажи: если \(1\le y\le x\), то \(r(x)\le r(y)\).  
   Это *очень Lean-friendly*:  
   \[
   \frac{x}{1+x^2}\le \frac{y}{1+y^2}
   \iff x(1+y^2)\le y(1+x^2)
   \iff (x-y)\le xy(x-y)
   \iff 1\le xy
   \]
   (последний шаг — так как \(x-y\ge 0\), делишь/переносишь; и \(xy\ge 1\)).  
2. Отсюда при \(\xi\ge 5/2\ge 1\):  
   \[
   \frac{\xi}{1+\xi^2}\le \frac{5/2}{1+(5/2)^2}=\frac{10}{29}.
   \]
3. Значит
   \[
   \frac{\pi\xi}{1+\xi^2}\le \frac{10\pi}{29}<\frac{10}{29}\cdot\frac{22}{7}=\frac{220}{203}=1+\frac{17}{203}.
   \]
4. Тогда
   \[
   \log(\pi\xi)=\log(1+\xi^2)+\log\Bigl(\frac{\pi\xi}{1+\xi^2}\Bigr)
   \le \log(1+\xi^2)+\log\Bigl(1+\frac{17}{203}\Bigr)
   \le \log(1+\xi^2)+\frac{17}{203}.
   \]
   (последний шаг снова \(\log(1+u)\le u\)).

---

### Лемма 5: итоговая оценка \(\Re\psi\) и модуль
**Формулировка.** Для \(\xi\ge 5/2\) и \(z=\tfrac14+i\pi\xi\),
\[
0\le \Re\psi(z)\le \log(1+\xi^2)+\frac{1}{10}.
\]
Следовательно \(|\Re\psi(z)|\le \log(1+\xi^2)+\frac{1}{10}\).

**Доказательство.**
- Верхняя оценка:
  \[
  \Re\psi(z)\le \log|z|
  =\log(\pi\xi)+\frac12\log\Bigl(1+\frac{1}{16\pi^2\xi^2}\Bigr)
  \le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800}
  < \log(1+\xi^2)+\frac{1}{10}.
  \]
- Низ (чтобы убрать модуль): можно взять грубое
  \(\Re\psi(z)\ge \log|z|-\frac{1}{2|z|}-\frac{1}{12|z|^2}\) из той же remainder-оценки и заметить, что при \(\xi\ge 5/2\) \(|z|\ge |\tau|=\pi\xi > 7\), так что RHS \(>0\).  
  (Если хочешь совсем без “\(>7\)” — можно зафиксировать рациональный нижний bound через \(\pi>3\).)

---

## 6. Почему исходное утверждение с \(\log(1+\xi^2)\) (без +константы) не пройдёт при \(\xi=\tfrac52\)

Если тебе нужно **официально** объяснить “почему не доказывается” (и поймать баг в постановке), это делается *тем же* remainder-неравенством DLMF:

Из remainder-оценки получаешь также нижнюю границу
\[
\Re\psi(z)\ge \log|z|-\frac{5}{24|z|^2}\quad(\sigma=\tfrac14),
\]
потому что \(\Re(1/(2z))=\sigma/(2|z|^2)=1/(8|z|^2)\) и \(|\Re\varepsilon|\le 1/(12|z|^2)\). Это ровно тот “taking real parts” шаг, который у вас используется для \(a(\xi)\). 【66:0†RH_Q3.pdf†L32-L48】

На \(\xi=5/2\): \(|z|^2=\tfrac{1}{16}+(\tfrac{5\pi}{2})^2>\tfrac{901}{16}\) (из \(\pi>3\)), поэтому
\[
\Re\psi(z)>\log\Bigl(\frac{\sqrt{901}}{4}\Bigr)-\frac{5}{24}\cdot\frac{16}{901}
>\log\Bigl(\frac{15}{2}\Bigr)-\frac{10}{2703}.
\]
А \(\log(1+\xi^2)=\log(29/4)\). Разность логов — \(\log\bigl(\frac{15/2}{29/4}\bigr)=\log(30/29)\), и можно оценить снизу
\[
\log\Bigl(\frac{30}{29}\Bigr)\ge \frac{(30/29)-1}{30/29}=\frac{1/29}{30/29}=\frac{1}{30}.
\]
Но \(\frac{1}{30}>\frac{10}{2703}\), значит \(\Re\psi(z)>\log(29/4)\), т.е. требуемое \(\Re\psi\le \log(1+\xi^2)\) **ложно** при \(\xi=5/2\).

Это полезно как “диагностика”: в Lean ты не будешь биться в стену.

---

## 7. Практический совет для Q3: tail делай через \(a(\xi)\), не через \(\Re\psi\)

Если цель — именно “tail estimates” в стиле Леммы 8.19, то наиболее чистый Lean-путь уже прописан:

- \(a(\xi)=\log\pi-\Re\psi(\tfrac14+i\pi\xi)\). 【66:4†RH_Q3.pdf†L47-L53】
- Дифференцируешь \(a\) через тригамму и получаешь явный ряд и знак \(a'(\xi)<0\), плюс оценку \(|a'(\xi)|\le \frac{11}{10}\frac{1}{|\xi|}\) для \(\xi\ge 1\). 【62:0†RH_Q3.pdf†L53-L77】
- Интегрируешь bound на \(|a'|\) и получаешь логарифмический рост:
  \[
  |a(\xi)|\le a(0)+\frac{11}{10}\log(1+\xi)\quad(\xi\ge 1),
  \]
  что прямо используется далее для tail. 【62:12†RH_Q3.pdf†L70-L83】

Это *намного* проще для Lean, чем строить отдельный глобальный upper bound на \(\Re\psi\).

---

Если хочешь, могу прямо разложить “Lean-лейммы” в виде списка целей (какие `simp`-леммы нужны, какие `have hpos : 0 < ...` и как лучше делать cross-multiplication для рациональных оценок), но ключевой момент уже здесь: **исходная формулировка с \(\xi\ge 5/2\) без добавки — не истинна**, зато версии “\(+\frac{1}{10}\)” или “\(\xi\ge 3\)” — идут гладко.

## USER
Update: we locked in the practical/correct tail bound in the project: for all ξ ≥ 5/2, |Re ψ(1/4 + iπξ)| ≤ log(1+ξ^2) + 1/10. This implies |a(ξ)| ≤ 21/10 + log(1+ξ^2).  Could you provide a clean analytic derivation (no numerics) with Lean‑friendly steps? Please state the exact remainder inequality you use (from Q3 Appendix F.4 / DLMF 5.11), including any sec^2 factor, and show how it yields the +1/10 constant for ξ ≥ 5/2. If a different constant/threshold is cleaner, propose it explicitly with the inequality chain.

## ASSISTANT
### 0. Theorem: Digamma tail bound at \( \tfrac14+i\pi\xi \) (Q3 tail)
**Precise statement (what you want in Lean).**  
For all real \(\xi\) with \(\xi \ge \tfrac52\),
\[
\bigl|\Re\,\psi\!\left(\tfrac14+i\pi\xi\right)\bigr|
\;\le\;
\log(1+\xi^2)\;+\;\tfrac{1}{10}.
\]
**Status:** standard complex analysis + explicit asymptotic remainder for \(\psi\) (DLMF §5.11 / your Appendix F.4), plus elementary real inequalities.

---

### 1. Context
You already have the series formula for \(\Re\psi(\tfrac14+i\pi\xi)\) in Appendix F.2/F.4 (the `digammaSeq -> digamma` route). What remains is a clean *non-numerical* upper bound for \(|\Re\psi|\) in the tail region \(\xi\ge 5/2\). The most Lean-friendly route (fewest analytic lemmas) is:

- use the **first-term asymptotic expansion** of \(\psi\) with an explicit remainder bound (DLMF 5.11(ii)),
- take real parts,
- then do **pure inequalities** (no integrals, no series bounding).

This matches how Q3 already invokes the “standard digamma remainder bound” in Appendix F.4/Lemma 8.18. 【64:9†RH_Q3.pdf†L136-L144】

---

### 2. Definitions and notation
- \(\psi(z) = \Gamma'(z)/\Gamma(z)\) is the digamma function.
- \(\log z\) is the principal complex logarithm (Lean: `Complex.log`).
- \(\arg z\) is the principal argument (Lean: `Complex.arg`).
- \(|z|\) is the complex modulus (Lean: `Complex.abs`).
- We set
  \[
  z := \tfrac14 + i\pi\xi,\qquad \sigma:=\Re z=\tfrac14,\qquad \tau:=\Im z=\pi\xi.
  \]
Then
\[
|z|^2 = \sigma^2+\tau^2 = \tfrac{1}{16}+\pi^2\xi^2.
\]

---

### 3. Dependencies you actually use
1. **Asymptotic remainder (exact form with \(\sec^2\)).**  
   DLMF §5.11(ii) says: if you truncate the Poincaré expansion for \(\psi(z)\) (equation (5.11.2)) at the first neglected term, then for complex \(z\) the remainder is bounded by a \(\sec^2(\tfrac12\arg z)\) factor times that first neglected term. citeturn1view0  
   Concretely, truncating after \(\log z - \frac1{2z}\) (i.e. first neglected term \( \frac{B_2}{2z^2} = \frac{1}{12z^2}\)) gives:
   \[
   \boxed{\;
   \left|\psi(z)-\log z+\frac{1}{2z}\right|
   \le
   \frac{1}{12|z|^2}\,\sec^2\!\left(\frac{\arg z}{2}\right)
   \;}
   \quad(|\arg z|<\pi).
   \]
   (This is exactly the “first neglected term” rule specialized to (5.11.2).)

2. **Q3’s project-local simplified remainder bound.**  
   Appendix F.4 states (and uses) a version without the \(\sec^2\) factor, for \(\Re z>0\):  
   \[
   \left|\psi(z)-\log z+\frac{1}{2z}\right|\le \frac{1}{12|z|^2}\quad(\Re z>0),
   \]
   used there to lower-bound \(a(\xi)\). 【64:9†RH_Q3.pdf†L136-L144】  
   For the tail bound you asked, you can start from the DLMF-sec\(^2\) version (more “official”) and then bound \(\sec^2\) by \(2\) in the right half-plane.

3. Elementary real inequalities:
   - \(\log(1+u)\le u\) for \(u>-1\) (Lean: `Real.log_le_sub_one_of_pos` with \(x=1+u\)).
   - \(\pi<\frac{22}{7}\) and \(\pi>3\) (explicit bounds listed in your verification appendix). 【64:7†RH_Q3.pdf†L23-L27】
   - A rational comparison for \(\xi/(1+\xi^2)\) when \(\xi\ge 5/2\) (see Lemma 5 below).

---

### 4. Roadmap
1. Apply the first-term asymptotic expansion with remainder \(R(z)\).
2. Take real parts to write \(\Re\psi(z)\) as \(\log|z|\) plus an \(O(|z|^{-2})\) correction.
3. Bound \(|\Re\psi(z)|\) by \(\log|z|\) plus an explicit rational multiple of \(1/|z|^2\).
4. Compare \(\log|z|\) to \(\log(1+\xi^2)\) using only rational bounds for \(\pi\) and monotonicity-like algebra.
5. Combine constants and show they’re \(<\tfrac{1}{10}\) for \(\xi\ge \tfrac52\).

---

## 5. Lemmas (Lean-friendly “chunks”)

### Lemma 5.1 (Remainder bound with \(\sec^2\))
Let \(z\in\mathbb C\) with \(|\arg z|<\pi\). Define
\[
R(z):=\psi(z)-\log z+\frac{1}{2z}.
\]
Then
\[
|R(z)| \le \frac{1}{12|z|^2}\sec^2\!\left(\frac{\arg z}{2}\right).
\]
**Source:** DLMF §5.11(ii), “complex remainder bounded by \(\sec^2(\tfrac12\arg z)\) times first neglected term” applied to the digamma expansion (5.11.2). citeturn1view0

*(If you prefer to stay entirely inside Q3, you can take the Appendix F.4 variant directly, but you explicitly asked to include the \(\sec^2\) version.)*

---

### Lemma 5.2 (\(\sec^2\) is uniformly bounded in the right half-plane)
If \(\Re z>0\), then \(|\arg z|<\pi/2\), hence
\[
\sec^2\!\left(\frac{\arg z}{2}\right)\le 2.
\]
**Lean hint:** show \(|\arg z| \le \pi/2\) from \(\Re z>0\); then \(|\arg z|/2\le \pi/4\); use monotonicity of \(\cos\) on \([0,\pi/2]\) to get \(\cos(|\arg z|/2)\ge \cos(\pi/4)=\sqrt2/2\), hence \(\sec^2\le 2\).

**Consequence:** for \(\Re z>0\),
\[
|R(z)|\le \frac{1}{6|z|^2}.
\]

---

### Lemma 5.3 (Real-part decomposition)
For any \(z=\sigma+i\tau\) with \(\sigma>0\),
\[
\Re\psi(z) = \log|z| - \frac{\sigma}{2|z|^2} + \Re R(z)
\]
(where \(R\) is as above).
**Lean hint:** use `Complex.re_log` to rewrite \(\Re(\log z)=\log|z|\), and compute \(\Re(1/z)=\sigma/|z|^2\).

Then using triangle inequality on reals:
\[
|\Re\psi(z)| \le \log|z| + \frac{\sigma}{2|z|^2} + |R(z)|.
\]

In our application \(\sigma=\tfrac14\), so
\[
|\Re\psi(z)| \le \log|z| + \frac{1}{8|z|^2} + |R(z)|.
\]

---

### Lemma 5.4 (Turn the remainder into a rational \(1/|z|^2\))
With \(\Re z>0\), combine Lemmas 5.2 and 5.3:
\[
|\Re\psi(z)| \le \log|z| + \frac{1}{8|z|^2} + \frac{1}{6|z|^2}
= \log|z| + \frac{7}{24|z|^2}.
\]

---

### Lemma 5.5 (A clean bound for \(\log|z|\))
For \(z=\tfrac14+i\pi\xi\) with \(\xi>0\),
\[
|z|^2 = \pi^2\xi^2 + \frac1{16}
= \pi^2\xi^2\left(1+\frac{1}{16\pi^2\xi^2}\right).
\]
Thus
\[
\log|z|
= \log(\pi\xi) + \frac12\log\!\left(1+\frac{1}{16\pi^2\xi^2}\right)
\le \log(\pi\xi) + \frac{1}{32\pi^2\xi^2},
\]
using \(\log(1+u)\le u\).

For \(\xi\ge \tfrac52\) and \(\pi>3\),
\[
\frac{1}{32\pi^2\xi^2} \le \frac{1}{32\cdot 9\cdot (25/4)}=\frac{1}{1800}.
\]
So:
\[
\boxed{\;\log|z|\le \log(\pi\xi)+\frac{1}{1800}\;}.
\]

---

### Lemma 5.6 (Compare \(\log(\pi\xi)\) with \(\log(1+\xi^2)\) at \(\xi\ge 5/2\))
Write
\[
\log(\pi\xi)=\log(1+\xi^2) + \log\!\left(\frac{\pi\xi}{1+\xi^2}\right).
\]

Now bound the ratio by a rational:
1) For \(\xi\ge \tfrac52\),
\[
\frac{\xi}{1+\xi^2}\le \frac{5/2}{1+(5/2)^2}=\frac{10}{29}.
\]
**Lean-friendly proof:** cross-multiply and factor:
\[
\frac{\xi}{1+\xi^2}\le\frac{a}{1+a^2}
\iff a(1+\xi^2)-\xi(1+a^2)\ge0
\iff (\xi-a)(a\xi-1)\ge0,
\]
so it holds if \(\xi\ge a\) and \(a\xi\ge1\). Take \(a=\tfrac52\), then \(a\xi\ge a^2=25/4>1\).

2) Use \(\pi<\frac{22}{7}\) to get
\[
\frac{\pi\xi}{1+\xi^2}\le \frac{22}{7}\cdot\frac{10}{29}=\frac{220}{203}
=1+\frac{17}{203}.
\]

3) Then
\[
\log\!\left(\frac{\pi\xi}{1+\xi^2}\right)
\le \log\!\left(1+\frac{17}{203}\right)
\le \frac{17}{203}.
\]
(using \(\log(1+u)\le u\)).

So
\[
\boxed{\;\log(\pi\xi)\le \log(1+\xi^2)+\frac{17}{203}\;}.
\]

---

### Lemma 5.7 (Bound \(\tfrac{7}{24|z|^2}\) for \(\xi\ge 5/2\))
Since \(|z|^2=\pi^2\xi^2+\tfrac1{16}\ge \pi^2\xi^2\),
\[
\frac{7}{24|z|^2}\le \frac{7}{24\pi^2\xi^2}.
\]
With \(\pi>3\) and \(\xi\ge\tfrac52\),
\[
\frac{7}{24\pi^2\xi^2}\le \frac{7}{24\cdot 9\cdot (25/4)}=\frac{7}{1350}.
\]

---

## 6. Main proof (assemble the inequalities)
Let \(\xi\ge \tfrac52\) and \(z=\tfrac14+i\pi\xi\). Then \(\Re z=\tfrac14>0\), so Lemmas 5.1–5.4 apply and give
\[
|\Re\psi(z)| \le \log|z| + \frac{7}{24|z|^2}.
\]

Apply Lemma 5.5 and Lemma 5.6:
\[
\log|z| \le \log(\pi\xi)+\frac{1}{1800}
\le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800}.
\]

Apply Lemma 5.7:
\[
\frac{7}{24|z|^2}\le \frac{7}{1350}.
\]

Therefore
\[
|\Re\psi(z)|
\le \log(1+\xi^2) + \left(\frac{17}{203}+\frac{1}{1800}+\frac{7}{1350}\right).
\]

Now the constant is purely rational:
\[
\frac{17}{203}+\frac{1}{1800}+\frac{7}{1350}
=\frac{98093}{1096200}
<\frac{1}{10}.
\]
Hence
\[
|\Re\psi(\tfrac14+i\pi\xi)| \le \log(1+\xi^2)+\frac{1}{10},
\]
as required.

---

## 7. How this yields the project’s \(|a(\xi)|\) tail bound
Recall \(a(\xi)=\log\pi-\Re\psi(\tfrac14+i\pi\xi)\) (Section 8.3 setup). 【64:0†RH_Q3.pdf†L125-L127】  
Then
\[
|a(\xi)| \le |\log\pi| + |\Re\psi(\tfrac14+i\pi\xi)|
\le \log\pi + \log(1+\xi^2) + \frac{1}{10}.
\]
Using \(\pi<\frac{22}{7}<4\) gives \(\log\pi<\log 4\), and \(\log 4<2\) (e.g. \(\log 4=2\log 2\) and \(\log 2<1\) because \(2<e\)). So \(\log\pi \le 2\), hence
\[
|a(\xi)| \le \frac{21}{10} + \log(1+\xi^2).
\]
(This matches your locked-in bound.)

---

## 8. Audit and options
- **Branch issues:** the only complex-log fact used is \(\Re(\log z)=\log|z|\), standard for the principal branch (Lean has `Complex.re_log`).
- **No numerics:** every “constant” step is rational: \(\pi<22/7\), \(\pi>3\), and rational comparisons in \(\xi\).
- **If you want a slightly tighter explicit constant:** the proof actually gives
  \[
  |\Re\psi(\tfrac14+i\pi\xi)| \le \log(1+\xi^2) + \frac{98093}{1096200}
  \]
  for \(\xi\ge 5/2\), and \(\frac{98093}{1096200}<\frac{9}{100}\) too. So you can safely replace \(1/10\) by \(9/100\) if you prefer a cleaner “\(0.09\)”.
- **If you are willing to raise the threshold:** for \(\xi\ge 3\) you can even force \(\pi\xi/(1+\xi^2)\le 1\) (since \(\xi^2-\pi\xi+1\ge0\) there), making the “\(+17/203\)” disappear; then the constant becomes just the tiny \(O(1/\xi^2)\) terms.

If you want, I can translate the above into an explicit Lean lemma skeleton (names + the exact `field_simp` goals you’ll hit) based on how your project currently names the remainder lemma and the digamma function.

## USER
Нужен короткий план/сертификат для нижних границ a(1/2), a(3/2), a(5/2).
Хотим обойтись без Re ψ‑series, через DLMF 5.11 (remainder bound).
Цель: a(1/2) >= 17/25, a(3/2) >= -9/20, a(5/2) >= -1 (или предложи минимально достаточные константы).
Если есть удобная интегральная/асимптотическая оценка Re ψ, набросай шаги и константы.

## ASSISTANT
Ниже — **короткий “сертификат”** (цепочки неравенств, максимально Lean‑friendly) для
\[
a(\xi):=\log\pi-\Re\psi\!\Bigl(\tfrac14+i\pi\xi\Bigr),
\]
который даёт **без Re ψ‑series** нижние оценки в точках \(\xi=\tfrac12,\tfrac32,\tfrac52\).

---

## 0) База: что используем из DLMF 5.11 / Appendix F.4

### (R) Ремайндер‑оценка дигаммы (как в Q3)
В Q3 зафиксирована “standard digamma remainder bound”
\[
\Bigl|\psi(z)-\log z+\frac{1}{2z}\Bigr|\;\le\;\frac{1}{12|z|^2}\qquad(\Re z>0),
\]
со ссылкой на [22, §5.11].【63:1†RH_Q3.pdf†L32-L40】

Это и есть единственный “аналитический” вход.

---

## 1) Ключевая лемма: из (R) получаем \(a(\xi)\ge -\log\xi\) для \(\xi\ge \tfrac12\)

Пусть \(\xi>0\) и
\[
z=\tfrac14+i\pi\xi,\qquad \sigma:=\Re z=\tfrac14,\qquad |z|^2=\sigma^2+\pi^2\xi^2.
\]

### Шаг 1. Разложение с остатком
Положим
\[
\varepsilon:=\psi(z)-\log z+\frac{1}{2z}.
\]
Тогда из (R) имеем \(|\varepsilon|\le \frac{1}{12|z|^2}\).

Следовательно
\[
\psi(z)=\log z-\frac{1}{2z}+\varepsilon.
\]

### Шаг 2. Берём действительные части и даём верхнюю оценку \(\Re\psi\)
Так как \(\Re z>0\), то \(\Re(\log z)=\log|z|\). Кроме того,
\[
\Re\Bigl(\frac{1}{2z}\Bigr)=\frac{\sigma}{2|z|^2}=\frac{1}{8|z|^2}.
\]
И \(\Re(\varepsilon)\le |\varepsilon|\).

Отсюда
\[
\Re\psi(z)
\le
\log|z|-\frac{1}{8|z|^2}+\frac{1}{12|z|^2}
=
\log|z|-\frac{1}{24|z|^2}.
\]

### Шаг 3. Переводим в нижнюю оценку \(a(\xi)\)
По определению \(a(\xi)=\log\pi-\Re\psi(z)\)【63:7†RH_Q3.pdf†L8-L24】, значит
\[
a(\xi)\ge \log\pi-\log|z|+\frac{1}{24|z|^2}.
\]

Теперь выражаем \(|z|\) через маленький параметр \(u\):
\[
|z|^2=\pi^2\xi^2+\frac{1}{16}
=\pi^2\xi^2\Bigl(1+u\Bigr),
\qquad
u:=\frac{1}{16\pi^2\xi^2}.
\]
Тогда
\[
\log|z|=\log(\pi\xi)+\frac12\log(1+u),
\]
и
\[
\log\pi-\log|z|=-\log\xi-\frac12\log(1+u),
\qquad
\frac{1}{24|z|^2}=\frac{1}{24\pi^2\xi^2(1+u)}=\frac{2u}{3(1+u)}.
\]
Итого:
\[
a(\xi)\ge -\log\xi\;+\;\underbrace{\Bigl(\frac{2u}{3(1+u)}-\frac12\log(1+u)\Bigr)}_{=:g(u)}.
\]

### Шаг 4. Показываем \(g(u)\ge 0\) при \(u\le \tfrac13\) без производных
Используем стандартное \(\log(1+u)\le u\) при \(u\ge 0\). Тогда
\[
g(u)\ge \frac{2u}{3(1+u)}-\frac{u}{2}
=
\frac{u(1-3u)}{6(1+u)}.
\]
Значит при \(0\le u\le \tfrac13\) имеем \(g(u)\ge 0\), и потому
\[
a(\xi)\ge -\log\xi.
\]

### Шаг 5. Проверяем \(u\le \tfrac13\) для \(\xi\ge \tfrac12\)
Если \(\xi\ge \tfrac12\) и \(\pi>3\) (фиксировано в Q3)【63:0†RH_Q3.pdf†L23-L27】, то \(\pi^2>9\), и
\[
u=\frac{1}{16\pi^2\xi^2}\le \frac{1}{16\cdot 9\cdot (1/4)}=\frac{1}{36}<\frac13.
\]
Следовательно:
\[
\boxed{\;\forall \xi\ge\tfrac12:\quad a(\xi)\ge -\log\xi.\;}
\]
Это — основной “универсальный” сертификат для трёх точек.

---

## 2) Применение к \(\xi=\tfrac32,\tfrac52\) (вообще без новых оценок)

### 2.1) \(a(\tfrac32)\ge -\tfrac{9}{20}\)
Из леммы выше:
\[
a(\tfrac32)\ge -\log(\tfrac32).
\]
В Q3 записано \(\log(\tfrac32)<\tfrac{5}{12}\)【63:0†RH_Q3.pdf†L29-L37】, и \(\tfrac{5}{12}<\tfrac{9}{20}\) (проверка: \(5\cdot 20=100<108=9\cdot 12\)).
Значит \(-\log(\tfrac32)>-\tfrac{9}{20}\), следовательно
\[
\boxed{a(\tfrac32)\ge -\tfrac{9}{20}.}
\]

### 2.2) \(a(\tfrac52)\ge -1\)
Аналогично:
\[
a(\tfrac52)\ge -\log(\tfrac52).
\]
В Q3: \(\log(\tfrac52)<1\)【63:0†RH_Q3.pdf†L39-L45】, значит \(-\log(\tfrac52)>-1\), и
\[
\boxed{a(\tfrac52)\ge -1.}
\]

*(Это сильнее, чем оценки в тексте через \(-\log\xi-\frac{1}{2\pi\xi}-\dots\)【63:1†RH_Q3.pdf†L42-L48】 — потому что мы не “убиваем” точную структуру \(\log|z|\) лишними грубыми заменами.)*

---

## 3) Точка \(\xi=\tfrac12\): \(a(\tfrac12)\ge \tfrac{17}{25}\)

Из общей леммы:
\[
a(\tfrac12)\ge -\log(\tfrac12)=\log 2.
\]
Значит достаточно показать
\[
\log 2\ge \frac{17}{25}.
\]

### Сертификат для \(\log 2\ge 17/25\) через \(\exp\) (без чисел)
Достаточно доказать \(\exp(17/25)\le 2\).

1) Для \(x\in[0,1]\) используем тейлоровскую верхнюю оценку (остаток Лагранжа/интегральный остаток):
\[
e^x \le 1+x+\frac{x^2}{2}+\frac{x^3}{6}+\frac{e\;x^4}{24}.
\]
2) В Q3 зафиксировано \(e<3\)【63:0†RH_Q3.pdf†L47-L52】, значит
\[
e^x \le 1+x+\frac{x^2}{2}+\frac{x^3}{6}+\frac{x^4}{8}\qquad(0\le x\le 1).
\]
3) Подставляем \(x=\frac{17}{25}\) (он в \([0,1]\)) и считаем **строго рационально**:
\[
1+\frac{17}{25}+\frac{1}{2}\Bigl(\frac{17}{25}\Bigr)^2+\frac{1}{6}\Bigl(\frac{17}{25}\Bigr)^3+\frac{1}{8}\Bigl(\frac{17}{25}\Bigr)^4
=\frac{18659363}{9375000}
<\frac{18750000}{9375000}=2.
\]
Значит \(e^{17/25}<2\), а потому (монотонность \(\log\)):
\[
\frac{17}{25}<\log 2.
\]
И, следовательно,
\[
\boxed{a(\tfrac12)\ge \log 2\ge \tfrac{17}{25}.}
\]

---

## 4) Итоговый “сертификат” (в одну строку на каждую точку)

- (i) **Общая лемма** (из DLMF 5.11 ремайндера):  
  \[
  \forall\xi\ge \tfrac12,\qquad a(\xi)\ge -\log\xi.
  \]
  (вся работа — в шаге \(g(u)\ge0\) при \(u\le 1/3\)).

- (ii) Тогда:
  \[
  a(\tfrac32)\ge -\log(\tfrac32)>-\tfrac{9}{20}
  \quad\text{(так как }\log(\tfrac32)<\tfrac{5}{12}<\tfrac{9}{20}\text{)}.
  \]
  【63:0†RH_Q3.pdf†L29-L37】

- (iii)
  \[
  a(\tfrac52)\ge -\log(\tfrac52)>-1
  \quad\text{(так как }\log(\tfrac52)<1\text{)}.
  \]
  【63:0†RH_Q3.pdf†L39-L45】

- (iv)
  \[
  a(\tfrac12)\ge \log 2\ge \tfrac{17}{25}
  \quad\text{(потому что }e^{17/25}<2\text{ из тейлора + }e<3\text{)}.
  \]
  【63:0†RH_Q3.pdf†L47-L52】

---

## 5) Если хочешь ещё проще (другие “минимально достаточные” константы)
Если цель — только A3 floor как в тексте, то уже хватает их старых чисел
\(a(\tfrac32)\ge -\tfrac35\), \(a(\tfrac52)\ge -\tfrac{11}{10}\)【63:1†RH_Q3.pdf†L50-L86】,
но твои цели \(-\tfrac{9}{20}\) и \(-1\) **тоже** получаются “чисто” через \(a(\xi)\ge -\log\xi\), без дополнительных трюков.

---

Если хочешь, я могу переписать это прямо как набор Lean‑лемм (типы, имена, какие `have`/`nlinarith`/`field_simp` удобнее), но математический сертификат выше уже оптимизирован под формализацию: **одна общая лемма + три подстановки + две готовые log‑оценки из Q3 + один exp‑полином.**

## USER
Quick update: your certificate for a(1/2), a(3/2), a(5/2) is already formalized in Lean (A3_FLOOR_v20_bounds_manual.lean: a_ge_neg_log_xi, a_half_bound, a_three_half_bound, a_five_half_bound). So those are done.

Now Stage 4: we need a safe lower bound for P_A on θ∈[-1/2,1/2] without assuming g is monotone. Could you propose a Lean‑friendly bound for the m = −2 term (e.g. g(2−θ) ≥ −C using w(3/2) or w(2)) and a simple explicit upper bound for w(3/2) (or alternative constant)? Any hint to handle evenness/reindexing or a clean truncation/tail lemma would also help.

## ASSISTANT
Ок, Stage 4 можно сделать совсем «реал‑анализом + знаки», не трогая монотонность **g**. Ниже — ровно тот кусок, который ты просишь: безопасный lower bound для терма **m = −2** (то есть \(g(2-\theta)\)) и простой сертификат для \(w(3/2)\), плюс Lean‑friendly приёмы для чётности/переиндексации и обрезки суммы.

---

## Контекст: что именно мы оцениваем

В Q3 символ строится как периодизация
\[
P_A(\theta)=2\pi\sum_{m\in\mathbb Z} g(\theta+m),\qquad
g(\xi)=a(\xi)\,\Phi_{B,t}(\xi),
\]
где
\[
\Phi_{B,t}(\xi)=(1-|\xi|/B)_+\,e^{-4\pi^2t\,\xi^2}.
\]
Это буквально определение в тексте Q3. 【102:6†RH_Q3.pdf†L1-L7】

Для \(0\le \xi\le B\) удобно выделить “окно”
\[
w_B(\xi):=(1-\xi/B)\,e^{-4\pi^2t\,\xi^2},
\]
и тогда \(g(\xi)=a(\xi)\,w_B(|\xi|)\) на \(|\xi|\le B\). 【102:2†RH_Q3.pdf†L6-L8】

В вашем «uniform» режиме параметры фиксированы: \(t=t_{\mathrm{sym}}=3/50\), \(B=B_{\min}=3\).

---

## Цель (локально): нижняя оценка для терма \(m=-2\)

На \(\theta\in[-\tfrac12,\tfrac12]\) терм \(m=-2\) — это
\[
g(\theta-2)=g(2-\theta)\quad(\text{чётность }g).
\]
Если мы дальше ограничиваемся \(\theta\in[0,\tfrac12]\) (см. ниже про чётность \(P_A\)), то
\[
2-\theta\in\Big[\frac32,2\Big].
\]

### Шаг A. Отделяем знак \(a\) и «окно» \(w\)

Предположим, что у тебя уже есть (как ты и писал) сертификат
\[
a(5/2)\ge -1
\]
(или любой другой фиксированный \(\ge -C_a\)).

Тогда по убыванию \(a\) на \([0,\infty)\) (у вас это уже есть в Stage 2) и потому что \(2-\theta\le 5/2\), получаем
\[
a(2-\theta)\ge a(5/2)\ge -1.
\]

Дальше:
\[
g(2-\theta)=a(2-\theta)\,w(2-\theta).
\]
Поскольку \(w\ge 0\), из \(a(2-\theta)\ge -1\) следует
\[
g(2-\theta)\;\ge\;(-1)\cdot w(2-\theta)= -\,w(2-\theta).
\]
Lean‑шаг: `mul_le_mul_of_nonneg_right` (умножаем неравенство на \(w(2-\theta)\ge0\)).

Остаётся заменить \(w(2-\theta)\) на **верхнюю** оценку (важно: \( -w\) даёт разворот, поэтому именно *upper bound* на \(w\) даёт *lower bound* на \(-w\)).

---

## Вариант 1 (самый Lean‑дешёвый): через уже готовое \(w(1)\)

На \([0,3]\) окно \(w(\xi)=(1-\xi/3)e^{-4\pi^2t\xi^2}\) убывает, и потому при \(2-\theta\ge 3/2\ge 1\)
\[
w(2-\theta)\le w(1).
\]

Тогда
\[
g(2-\theta)\ge -w(2-\theta)\ge -w(1).
\]

А у вас уже есть «ручной» bound (он же в Lemma 8.19) \(w(1)\le 1/15\). 【102:1†RH_Q3.pdf†L24-L35】

Итого **готовый сертификат**:
\[
\boxed{\forall\,\theta\in[0,1/2],\quad g(2-\theta)\ge -\frac1{15}.}
\]

**Lean‑склейка по знакам (важно):**
- `hw : w (2-θ) ≤ w 1`
- `hneg : (-1:ℝ) ≤ 0`
- `mul_le_mul_of_nonpos_left hw hneg` даёт \((-1)\cdot w(1)\le (-1)\cdot w(2-\theta)\), то есть \(-w(2-\theta)\ge -w(1)\).
- потом `le_trans` с \(g(2-\theta)\ge -w(2-\theta)\).

Это вообще не требует вычислять \(w(3/2)\).

---

## Вариант 2 (чуть сильнее и автономно): явный bound для \(w(3/2)\)

Если тебе удобнее именно «\(w(3/2)\) как константа» (и не хочется тащить монотонность \(w\) до \(1\)), то делается так:

### (i) Точная формула при \(B=3\), \(t=3/50\)

\[
w\Big(\frac32\Big)=\Big(1-\frac{(3/2)}{3}\Big)\exp\!\Big(-4\pi^2\cdot\frac{3}{50}\cdot\frac{9}{4}\Big)
=\frac12\exp\!\Big(-\frac{27\pi^2}{50}\Big).
\]

### (ii) Грубая нижняя оценка на показатель через \(\pi>3\)

Из \(\pi>3\) (оно явно записано как разрешённая «элементарная» константа в верификационных неравенствах) получаем \(\pi^2>9\). 【102:12†RH_Q3.pdf†L23-L27】

Значит
\[
\frac{27\pi^2}{50}\;\ge\;\frac{27\cdot 9}{50}=\frac{243}{50}.
\]
Следовательно
\[
w(3/2)\le \frac12\exp\!\Big(-\frac{243}{50}\Big).
\]

### (iii) Сертификат \(e^{243/50}\ge 100\) без “численной магии”

Используй стандартное неравенство для экспоненты:
\[
e^x \ge \sum_{k=0}^{6}\frac{x^k}{k!}\quad(x\ge 0).
\]
(В Lean это обычно: монотонность частичных сумм ряда exp.)

Берём \(x=\frac{243}{50}\). Тогда
\[
\sum_{k=0}^{6}\frac{x^k}{k!}
= \frac{126178377778061}{1250000000000}
>100,
\]
значит \(e^{243/50}\ge 100\), и потому \(e^{-243/50}\le 1/100\).

Итог:
\[
w(3/2)\le \frac12\cdot\frac1{100}=\frac1{200}.
\]

То есть:
\[
\boxed{w(3/2)\le \frac1{200}\quad\Rightarrow\quad g(2-\theta)\ge -\frac1{200}\ \text{для }\theta\in[0,1/2].}
\]

Это очень приятный bound: терм \(m=-2\) становится почти нулевым «вручную».

---

## Чётность и переиндексация: как убрать \([-1/2,1/2]\to[0,1/2]\)

Т.к. \(a(\xi)\) чётна и \(\Phi_{B,t}(\xi)\) чётна, то \(g\) чётна. Тогда периодизация \(P_A\) тоже чётна:

\[
P_A(-\theta)=2\pi\sum_{m\in\mathbb Z} g(-\theta+m)
=2\pi\sum_{m\in\mathbb Z} g(\theta-m)
=2\pi\sum_{m\in\mathbb Z} g(\theta+m)=P_A(\theta),
\]
где во втором равенстве использован факт \(g\) чётна, а в третьем — переиндексация \(m\mapsto -m\).

**Lean‑friendly трюк:** избегай `tsum` и сразу работай с конечной суммой (см. следующий пункт), тогда переиндексация делается через `Finset.sum_bij` с биекцией \(m\mapsto -m\).

---

## «Чистая» обрезка суммы (truncation lemma), без интегралов

Из-за \((1-|\xi|/3)_+\) имеем \(\Phi(\xi)=0\) при \(|\xi|\ge 3\), значит \(g(\xi)=0\) при \(|\xi|\ge 3\). Поэтому для \(\theta\in[-1/2,1/2]\) и \(|m|\ge 4\):
\[
|\theta+m|\ge |m|-|\theta|\ge 4-\frac12=\frac72>3
\quad\Rightarrow\quad g(\theta+m)=0.
\]

Отсюда:
\[
P_A(\theta)=2\pi\sum_{m=-3}^{3} g(\theta+m)
\]
(или даже можно убрать \(m=3\) на \(\theta\in(0,1/2]\), где \(\theta+3>3\), но это уже микрооптимизация).

**Lean‑шаблон:**
1. доказываешь лемму `hg_zero_of_abs_ge`:
   `|m| ≥ 4 → |θ| ≤ 1/2 → g (θ+m)=0`.
2. затем `tsum` превращаешь в `Finset.sum` по `Icc (-3) 3` через лемму вида `tsum_eq_sum` для финитной поддержки (или вообще определяешь `PA` через конечную сумму на этом отрезке).

---

## Что именно делать дальше в Stage 4 (минимальный план)

1) **Reduce θ**: доказать `PA (-θ)=PA θ`, значит достаточно \(\theta\in[0,1/2]\).

2) **Truncate**: заменить сумму по \(\mathbb Z\) на `Finset.Icc (-3) 3`.

3) **Нижние оценки по термам**:
   - \(m=0:\ g(\theta)\ge a(1/2)\,w(1/2)\) (оба фактора ≥, знак положительный).
   - \(m=1:\ g(\theta+1)\ge a(3/2)\,w(1)\) (знак отрицательный ⇒ берёшь *upper bound* на \(w\)).
   - \(m=-1:\ g(1-\theta)\ge 0\) — если у тебя уже есть \(a(1)\ge 0\) или другой сертификат неотрицательности на \([0,1]\). Если нет — лучше доказать именно \(a(1)\ge 0\) отдельной короткой леммой (она действительно true, и её можно получить из DLMF‑remainder, но ты это уже, кажется, делал в Stage 3‑цепочке).
   - \(m=2:\ g(\theta+2)\ge a(5/2)\,w(2)\) и \(w(2)\) у вас уже микроскопичен.
   - \(m=-2:\) **используй один из двух сертификатов выше**:
     - суперпростой: \(g(2-\theta)\ge -w(1)\ge -1/15\);
     - сильный: \(g(2-\theta)\ge -w(3/2)\ge -1/200\).

4) **Сложить и умножить на \(2\pi\)**, применить ваши рациональные bounds на \(\pi\) (в Q3 уже разрешены стандартные \(\pi>333/106\), \(\pi<22/7\) и т.п.). 【102:12†RH_Q3.pdf†L23-L28】

---

Если хочешь, я могу прямо предложить «конечную цепочку констант» для всего \(P_A(\theta)\) на \([0,1/2]\) в том стиле, как в Lemma 8.19 (только без шага \(g(1-\theta)\ge g(\theta+1)\)), чтобы она сшивалась одной `linarith`‑финалкой. Но для твоего вопроса про \(m=-2\) — наиболее чистый Lean‑сертификат это либо \(-1/15\) через \(w(1)\), либо \(-1/200\) через явную экспоненту.

## USER
Hi! Quick status update (see attached PROWKA_BRIEF.md).

Stage 4 is CLOSED in Lean:
- file: A3_FLOOR_v22_stage4_floor.lean
- wrapper: A3_FLOOR_THEOREM.lean
Build passes; final A3 floor is proven in Lean, but still conditional on the DLMF remainder bound.

Only remaining blocker is the axiom:
Q3.re_digamma_remainder_bound (DLMF §5.11):

For all z : ℂ with 0 < Re(z),
|Re(digamma z) - log‖z‖ + Re(z)/(2‖z‖^2)| ≤ 1/(12‖z‖^2).

We need a real proof (or a clean lemma split) of this exact statement.
If you prefer an equivalent formulation or want to tweak constants, please state it precisely.

Once this is proven, the A3_FLOOR chain becomes fully unconditional.

## ASSISTANT
According to a document from 2026-01-09, the only remaining Lean blocker is the axiom `Q3.re_digamma_remainder_bound` you stated (DLMF §5.11), namely the uniform half‑plane bound with constant `1/12‖z‖^2`.【4:0†PROWKA_BRIEF.md†L49-L56】

### 1) First: the axiom as stated is **not true** on the full half‑plane `0 < Re(z)`

The bound you wrote is exactly the one used informally in the writeup (“standard digamma remainder bound … for Re z > 0”).【1:5†RH_Q3.pdf†L32-L48】  
But the **uniform** statement (no sector/arg factor) cannot hold over the entire right half‑plane: there are explicit counterexamples with `Re(z)>0` where the left side exceeds `1/(12‖z‖^2)`.

One concrete numeric check (high precision) is:
- `z = 0.1 + i`
- LHS ≈ `0.08807`
- RHS = `1/(12|z|^2)` ≈ `0.08251`

So LHS > RHS, i.e. the inequality fails.

This matters for you because Lean cannot prove a false statement; the clean way forward is to **adjust the lemma statement** to a true form (or restrict its domain to what you actually use).

### 2) What DLMF §5.11 actually supports for complex `z`

DLMF’s asymptotic expansion for the digamma function is (their Eq. 5.11.2):  
\[
\psi(z)\sim \ln z-\frac{1}{2z}-\sum_{k\ge 1}\frac{B_{2k}}{2k\,z^{2k}}.
\]  
This is the expansion being referenced in your project notes.【turn7image0†L0-L2】

In §5.11(ii) (“Error Bounds …”), DLMF explicitly says:
- for **real positive** `z`, the remainder is bounded by the first neglected term and has the same sign, and
- for **complex** `z`, the remainder bounds pick up an extra multiplicative factor (the text does not render cleanly in the tool output, but it explicitly distinguishes the complex case and says the bounds are multiplied by an additional factor for (5.11.2)).【turn27view1†L252-L253】

That is: in the complex case you do **not** get a uniform `1/(12|z|^2)` bound without an additional sector/argument‑dependent factor (or, at minimum, a larger constant).

### 3) Recommended Lean fix: swap the axiom for a true lemma you can still use

You have two “clean” options, depending on how much you want to touch Stage 4.

#### Option A (closest to DLMF): add the missing sector/arg factor
Replace the axiom with a DLMF‑faithful version such as

\[
\bigl|\Re(\psi(z))-\log|z|+\frac{\Re z}{2|z|^2}\bigr|
\;\le\;
\frac{1}{12|z|^2}\,\Phi(\arg z),
\]

where \(\Phi(\arg z)\) is the (secant‑type) factor coming from §5.11(ii).  
Then, in your application domain `Re(z)>0` you immediately bound \(\Phi(\arg z)\) by a small absolute constant (because `|arg z| < π/2` in the right half‑plane).

This has the advantage that it matches the real analysis story in DLMF.

#### Option B (Lean‑friendly, no arg): weaken the constant uniformly on `Re z > 0`
If you don’t want to drag `arg` / `sec` into Lean at all, you can replace your axiom by a **strictly weaker but true** inequality:

\[
\bigl|\Re(\psi(z))-\log|z|+\frac{\Re z}{2|z|^2}\bigr|
\;\le\;
\frac{1}{6|z|^2}
\qquad (\Re z>0).
\]

This is exactly what you get from the DLMF complex bound once you replace the sector factor by its maximum over the right half‑plane (a small fixed constant). It’s also more than strong enough for your tail stage, because your `z` satisfies `|z|^2 = 1/16 + π^2 ξ^2` and you only need `ξ ≥ 5/2`, so `1/|z|^2` is tiny.

Concretely, for `z = 1/4 + iπξ`, `ξ ≥ 5/2`:
\[
\frac{1}{6|z|^2}\le \frac{1}{6\pi^2\xi^2}\le \frac{1}{6\pi^2(5/2)^2} < 0.003.
\]
So any constant deterioration from `1/12` to `1/6` will not affect your `+1/10` slack in the tail bound.

### 4) How to connect this to your existing tail goal (so Stage 4 remains closed)

Your current “goal shape” for the tail is exactly (from the brief):
\[
\bigl|\Re(\psi(\tfrac14+i\pi\xi))\bigr|\le \log(1+\xi^2)+\frac{1}{10}
\quad (\xi\ge 5/2).
\]【4:0†PROWKA_BRIEF.md†L49-L56】

Once you have any remainder bound of the form
\[
\Re(\psi(z)) \le \log|z| - \frac{\Re z}{2|z|^2} + \frac{C}{|z|^2},
\]
with, say, `C = 1/6` (or even `C = 1/4`), the rest is just elementary inequalities:

- `log|1/4 + iπξ| = (1/2) log(1/16 + π^2 ξ^2)`
- compare `(1/2) log(1/16 + π^2 ξ^2)` to `log(1 + ξ^2)` for `ξ ≥ 5/2` (you have room: at ξ=2.5 the gap to `log(1+ξ^2)+0.1` is ~0.02)
- `((Re z)/2 + C)/|z|^2` is ≤ a few thousandths at ξ≥2.5, so it fits inside your `+1/10` buffer.

So you can keep the final constant `1/10` unchanged even if you relax the remainder bound constant substantially.

### 5) If you insist on keeping the *exact* axiom statement verbatim

Then you’re asking Lean to prove something that (as stated) is false on the full domain `0 < Re(z)`.

The only way to keep *that exact algebraic form* is to **add a domain restriction** that makes it true (e.g. something like `Re(z) ≥ 1/4` or `|Im(z)| ≥ …`), or to add the missing **sector factor** (Option A).

### 6) What I’d do next in your repo (minimal disruption)

- **Change the axiom statement** to a true one (Option B is simplest operationally):
  ```lean
  -- new
  Q3.re_digamma_remainder_bound :
    ∀ z : ℂ, 0 < z.re →
      |(Complex.digamma z).re - Real.log ‖z‖ + z.re / (2 * ‖z‖^2)|
        ≤ 1 / (6 * ‖z‖^2)
  ```
- Then re-run the chain that uses it; you should only need to tweak small numeric inequalities, and in the tail range `ξ ≥ 5/2` it should go through essentially unchanged because the remainder term is so small.

If you want, paste the exact Lean lemma name(s) that consume `Q3.re_digamma_remainder_bound` (and the downstream numeric inequality that produces the `+1/10`) and I’ll tell you the tightest “drop-in” replacement constant that will preserve your existing arithmetic with zero refactoring.

## USER
We only need the real‑part remainder bound on the line z = 1/4 + iπξ (ξ ≥ 0).
Please confirm/prove one of the following (Lean‑friendly):
1) |Re ψ(z) − log|z| + Re(z)/(2|z|^2)| ≤ 1/(12|z|^2) for Re z ≥ 1/4, or
2) a corrected version with an explicit constant C (e.g. 1/6) and the exact domain where it holds.
If the complex DLMF bound needs a sector/arg factor, please show how to bound that factor on our line.
We only need enough to derive |Re ψ(1/4 + iπξ)| ≤ log(1+ξ^2) + 1/10 for ξ ≥ 5/2.
Provide a proof skeleton (Binet/Euler‑Maclaurin or series remainder), with the exact inequalities used.

## ASSISTANT
Ок — можно закрыть этот «последний аксиомный хвост» чисто аналитически на вашей вертикали, и даже без `arg/sec`‑фактора, если брать **только \(N=1\)** (то есть аппроксимацию \(\psi(z)\approx \log z - \frac1{2z}\)) и пользоваться **стилтьесовской формулой остатка**.

Ниже даю Lean‑дружелюбный скелет: какие точные тождества/неравенства нужны, и как из них выходит ваш хвост
\[
| \Re \psi(\tfrac14+i\pi\xi) |\le \log(1+\xi^2)+\tfrac1{10}\quad(\xi\ge\tfrac52)
\]
(всё без численных вычислений, только рациональные оценки \(\pi\)).

---

## 1) Что именно брать как “DLMF 5.11 остаток” (версия Stieltjes / Euler–Maclaurin)

В Johansson (Maple Trans. 2023) это выписано в виде интегрального остатка Стилтьеса для производных \(\log\Gamma\), а затем специализация к дигамме:

- Формула остатка (27) для \(m\ge 0\):
\[
R^{(m)}_N(z)=(-1)^m(2N)^m\int_0^\infty \frac{B_{2N}-B_{2N}(\{x\})}{2N\,(x+z)^{2N+m}}\,dx.
\]
citeturn14view4

- А для \(m=1\) (дигамма) записано разложение (28):
\[
\psi(z)=\log z-\frac1{2z}-\sum_{n=1}^{N-1}\frac{B_{2n}}{2n\,z^{2n}}+R'_N(z),
\]
где \(R'_N\) — тот самый остаток, соответствующий \(m=1\). citeturn14view4

Для **\(N=1\)** сумма пуста, и получается:
\[
\psi(z)-\log z+\frac1{2z}=R'_1(z).
\]

А \(R'_1(z)\) из (27) при \(N=1,m=1\) упрощается очень приятно:
- \(B_2=1/6\),
- множитель \((2N)^m/(2N)=2/2=1\),
- знак \((-1)^1=-1\).

Итого:
\[
R'_1(z)=-\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

**Это и есть “точный остаток” для \(N=1\)**, который можно формализовать (как итог Euler–Maclaurin / Stieltjes).

---

## 2) Простая (и очень безопасная) оценка остатка без сектора

Определи (в Lean) функцию
\[
E(z):=\psi(z)-\log z+\frac1{2z}.
\]
Тогда \(E(z)=R'_1(z)\) и
\[
|E(z)| \le \int_0^\infty \frac{|B_2-B_2(\{x\})|}{|x+z|^3}\,dx.
\]

### 2.1. Грубая константа на бернуллиевском “пилообразном” факторе

Бернуллиев полином
\[
B_2(t)=t^2-t+\frac16,\qquad t\in[0,1]
\]
имеет минимум \(-\frac1{12}\) (в \(t=\frac12\)) и максимум \(\frac16\) (в \(t=0,1\)). Поэтому для любой \(x\):
\[
0\le B_2 - B_2(\{x\}) \le \frac16 -\Big(-\frac1{12}\Big)=\frac14.
\]

Значит
\[
|B_2-B_2(\{x\})|\le \frac14.
\]

### 2.2. Чистая оценка интеграла \(\int_0^\infty |x+z|^{-3}dx\)

Пусть \(z=\sigma+i\tau\) с \(\sigma>0\). Тогда
\[
|x+z|^2=(x+\sigma)^2+\tau^2,
\qquad
|x+z|^3=\big((x+\sigma)^2+\tau^2\big)^{3/2}.
\]
И интеграл вычисляется в закрытом виде (обычный интеграл рациональной подстановкой):
\[
\int_0^\infty \frac{dx}{\big((x+\sigma)^2+\tau^2\big)^{3/2}}
=
\frac{1}{|z|\,(|z|+\sigma)} \le \frac{1}{|z|^2}.
\]
(Последнее, потому что \(|z|+\sigma\ge |z|\).)

### 2.3. Итоговая универсальная оценка остатка

Комбинируя:
\[
|E(z)|
\le \frac14\int_0^\infty \frac{dx}{|x+z|^3}
\le \frac{1}{4|z|^2}
\qquad(\Re z=\sigma>0).
\]

А значит автоматически:
\[
\big|\Re E(z)\big|\le |E(z)| \le \frac{1}{4|z|^2}.
\]

И это даёт **Lean‑замену вашему аксиому**, например:

> **Lemma (замена аксиома, безопасная):**  
> если \(0<\Re z\), то  
> \[
> \Big|\Re\psi(z)-\log|z|+\frac{\Re z}{2|z|^2}\Big|
> \le \frac{1}{4|z|^2}.
> \]
> (Потому что \(\Re(\log z)=\log|z|\) и \(\Re(\frac1{2z})=\frac{\Re z}{2|z|^2}\).)

Это пункт (2) из твоих вариантов с явной константой \(C=1/4\) и доменом \(0<\Re z\).

---

## 3) Как из этого получить ваш хвост \(\log(1+\xi^2)+1/10\) при \(\xi\ge 5/2\)

Дальше — чистая арифметика.

Положи
\[
z(\xi)=\frac14+i\pi\xi,\qquad \xi\ge 0.
\]
Тогда \(\Re z(\xi)=1/4>0\), и применима оценка выше.

### 3.1. От остатка к \(|\Re\psi|\)

Из
\[
\Re\psi(z)=\log|z|-\Re\frac1{2z}+\Re E(z)
\]
и неравенства треугольника:
\[
|\Re\psi(z)|
\le \log|z|+\Big|\Re\frac1{2z}\Big|+|\Re E(z)|.
\]

Теперь:
- \(\Big|\Re\frac1{2z}\Big|=\frac{\Re z}{2|z|^2}\) (так как \(\Re z>0\)),
- \(|\Re E(z)|\le 1/(4|z|^2)\).

Значит
\[
|\Re\psi(z)|\le \log|z|+\frac{\Re z}{2|z|^2}+\frac1{4|z|^2}
=
\log|z|+\frac{1}{8|z|^2}+\frac{1}{4|z|^2}
=
\log|z|+\frac{3}{8|z|^2}.
\]

Для \(z=z(\xi)\):
\[
|z|^2=\Big(\frac14\Big)^2+(\pi\xi)^2=\frac1{16}+\pi^2\xi^2.
\]

### 3.2. Оценка маленького рационального хвостика \(3/(8|z|^2)\)

При \(\xi\ge 5/2\) и \(\pi\ge 3\):
\[
|z|^2 \ge \pi^2\xi^2 \ge 9\cdot \frac{25}{4}=\frac{225}{4}.
\]
Отсюда
\[
\frac{3}{8|z|^2}\le \frac{3}{8\cdot(225/4)}=\frac{1}{150}.
\]

### 3.3. Оценка \(\log|z|\) через \(\log(1+\xi^2)\) без экспонент

Хотим:
\[
\log|z|\le \log(1+\xi^2)+\frac{1}{11}.
\]
Достаточно показать
\[
|z|\le \frac{12}{11}(1+\xi^2),
\]
потому что тогда (монотонность \(\log\)):
\[
\log|z|
\le \log\Big(\frac{12}{11}(1+\xi^2)\Big)
=\log(1+\xi^2)+\log\Big(\frac{12}{11}\Big)
\le \log(1+\xi^2)+\frac{1}{11},
\]
используя стандартную оценку \(\log(1+t)\le t\) при \(t> -1\) для \(t=1/11\).

Проверка \(|z|\le (12/11)(1+\xi^2)\) делается квадратами и рациональной оценкой \(\pi\le 22/7\):

- \(\pi\le 22/7 \Rightarrow \pi^2\le (22/7)^2=484/49\).
- Тогда
\[
|z|^2=\pi^2\xi^2+\frac1{16}
\le \frac{484}{49}\xi^2+\frac1{16}.
\]
- Нужно доказать, что при \(\xi\ge 5/2\):
\[
\frac{484}{49}\xi^2+\frac1{16}
\le \frac{144}{121}(1+\xi^2)^2.
\]

Введи \(u=\xi^2\ge 25/4\) и перенеси всё в одну сторону:
\[
\frac{144}{121}(1+u)^2-\frac{484}{49}u-\frac1{16}\ge 0.
\]
У Johansson‑алгебры это сводится к квадратичному многочлену
\[
P(u)=112896u^2-711232u+106967
\]
(общий знаменатель положителен), и достаточно показать \(P(u)\ge 0\) на \(u\ge 25/4\).
Это Lean‑дружелюбно так:

- \(P'(u)=225792u-711232\), и \(P'(25/4)>0\), значит \(P\) возрастает на \([25/4,\infty)\).
- проверить \(P(25/4)>0\) (там получается положительное целое число; по факту \(71767\)).

Этим закрываешь \(|z|\le (12/11)(1+\xi^2)\).

### 3.4. Финальная склейка констант

Итак, при \(\xi\ge 5/2\):
\[
|\Re\psi(z(\xi))|
\le \log|z(\xi)|+\frac{1}{150}
\le \log(1+\xi^2)+\frac{1}{11}+\frac{1}{150}.
\]
А
\[
\frac{1}{11}+\frac{1}{150}=\frac{161}{1650}<\frac{1}{10}.
\]
Значит
\[
|\Re\psi(\tfrac14+i\pi\xi)|
\le \log(1+\xi^2)+\frac{1}{10}
\quad(\xi\ge 5/2).
\]

Это ровно то, что вам нужно для хвоста.

---

## 4) Как это лучше “разрезать” на Lean‑леммы

Вот минимальный набор лемм (по смыслу), чтобы код был прямой:

1) **Stieltjes remainder identity (N=1, m=1)**  
`E(z) = ψ(z) - log z + 1/(2z) = -∫_0^∞ (B2 - B2 (fract x))/(x+z)^3 dx`  
(это специализация (27)+(28)). citeturn14view4

2) **Bernoulli bound**  
`0 ≤ B2 - B2(fract x) ∧ B2 - B2(fract x) ≤ 1/4`  
через `fract x ∈ [0,1)` и минимум/максимум квадратика \(t^2-t+1/6\).

3) **Integral evaluation**  
для `σ>0`:
\[
\int_0^\infty \frac{dx}{((x+\sigma)^2+\tau^2)^{3/2}}
= \frac{1}{|z|(|z|+\sigma)}\le \frac{1}{|z|^2}.
\]

4) **Remainder bound**  
из (1)+(2)+(3):
\[
|E(z)|\le \frac{1}{4|z|^2}
\quad\Rightarrow\quad
|\Re E(z)|\le \frac{1}{4|z|^2}.
\]

5) **Log comparison**  
для \(\xi\ge 5/2\):
\[
|z(\xi)|\le \frac{12}{11}(1+\xi^2)
\Rightarrow
\log|z(\xi)|\le \log(1+\xi^2)+\frac{1}{11}.
\]
(через \(\pi\le 22/7\) и квадратичный многочлен \(P(u)\) как выше.)

6) **Tail lemma**  
склейка:
\[
|\Re\psi(z(\xi))|
\le \log|z(\xi)|+\frac{3}{8|z(\xi)|^2}
\le \log(1+\xi^2)+\frac{1}{10}.
\]

---

## 5) Комментарий про “сек² фактор” и почему я его здесь не использовал

Если тебе хочется следовать DLMF‑формулировке буквально: в общем случае для комплексных \(z\) классические оценки остатков действительно идут с секторным множителем вида \(\sec^k(\tfrac12\arg z)\) (это то, что Johansson называет \(\phi(z)\)). citeturn10view1turn12view1  
Но на вашей задаче (и особенно на вертикали \(\Re z=1/4\)) **проще и надёжнее** уйти от `arg` полностью и оценить остаток через:
- супремум \(B_2-B_2(\{x\})\le 1/4\),
- точный интеграл \(\int |x+z|^{-3}\).

Это даёт аккуратную глобальную (по правой полуплоскости) оценку \(\le 1/(4|z|^2)\), которая с огромным запасом закрывает требуемую \(+1/10\) при \(\xi\ge 5/2\).

---

Если хочешь, я могу прямо в следующем сообщении переписать это в стиле “Lean lemma statements” (имена/типы в духе `Complex`, `Real.fract`, `intervalIntegral`, `Complex.abs`, `Complex.re`), чтобы ты смог быстро встроить как замену `Q3.re_digamma_remainder_bound`.

## USER
Hi! We changed the tail step to avoid the DLMF remainder bound entirely.
We now use the Stieltjes / Euler–Maclaurin remainder identity for N=1.

Ask 1 (main): please provide a clean analytic proof (or reference) for:

For Re(z) > 0,
ψ(z) − log z + 1/(2z)
= − ∫_0^∞ (B2 − B2(fract x)) / (x + z)^3 dx,
where B2(t) = t^2 − t + 1/6 and fract x ∈ [0,1).

We only need N=1, m=1 (digamma) — no higher terms.
If you know a standard reference, please cite exact formula number
(Johansson 2023 / Stieltjes remainder / Euler–Maclaurin).

Ask 2 (easy calculus): verify the kernel integral (for σ>0, z=σ+iτ):
∫_0^∞ ((x+σ)^2 + τ^2)^(-3/2) dx = 1 / (|z| (|z| + σ)) ≤ 1/|z|^2.

Ask 3 (still open): numeric point bounds for a(ξ):
a(ξ) := log π − Re ψ(1/4 + iπ ξ).
We need explicit lower bounds:
- a(1/2) ≥ 17/25
- a(3/2) ≥ -9/20
- a(5/2) ≥ -1
If you can get simpler constants that still work, propose them.
Please avoid the old DLMF remainder axiom if possible.

## ASSISTANT
Below is a clean “N=1, m=1 only” certificate that matches what you now want to formalize: it reduces everything to (i) the Stirling–Euler–Maclaurin remainder identity for **log Γ** (with fractional‑part Bernoulli polynomials) and (ii) one differentiation under the integral sign.

I’ll also give a compact, Lean‑friendly proof of the kernel integral, and then a practical template for the three point bounds for \(a(\xi)\) using **only** this identity + the shift formula \(\psi(z+1)=\psi(z)+1/z\).

---

## Ask 1 — Stieltjes / Euler–Maclaurin remainder identity for \(N=1, m=1\) (digamma)

### 0. Theorem and status
**Claim.** For every \(z\in\mathbb C\) with \(\Re z>0\),
\[
\psi(z)-\log z+\frac{1}{2z}
\;=\;
-\int_{0}^{\infty}\frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\]
where \(B_2(t)=t^2-t+\tfrac16\) and \(\{x\}=x-\lfloor x\rfloor\in[0,1)\) is the fractional part.

**Status.** Standard complex analysis / Euler–Maclaurin for \(\log\Gamma\). The exact integral remainder form appears explicitly in Johansson (Maple Transactions, 2023) for the remainder term of Stirling’s series for \(\log\Gamma\), and your identity is the \(N=1\) derivative of that formula.

### 1. Reference (exact formula numbers)

In Johansson, the “logarithmic Stirling series” is written as
\[
\log\Gamma(z)
=
\Bigl(z-\frac12\Bigr)\log z - z + \frac{\log(2\pi)}{2}
+
\sum_{n=1}^{N-1} T_n(z) + R_N(z)
\tag{21}
\]
with
\[
T_n(z)=\frac{B_{2n}}{2n(2n-1) z^{2n-1}}
\tag{22}
\]
and the **remainder term** satisfies the integral identity
\[
R_N(z)=\int_0^\infty \frac{B_{2N}-B_{2N}(\{x\})}{2N\,(x+z)^{2N}}\,dx,
\qquad z\notin(-\infty,0],\;N\ge1.
\tag{23}
\]
Johansson also defines Bernoulli polynomials via the standard generating function and explicitly states \(\{x\}=x-\lfloor x\rfloor\) is the fractional part. citeturn7view2

Johansson remarks that (23) can be proved using Euler–Maclaurin and points to Olver for a proof. citeturn7view2

That’s exactly the “Stieltjes remainder identity” you want, at the level of \(\log\Gamma\).

### 2. Derivation of your \(N=1, m=1\) identity from (21)+(23)

Fix \(z\) with \(\Re z>0\). Then \(z\notin(-\infty,0]\), so (21)–(23) apply.

**Step 1 (specialize \(N=1\)).**  
When \(N=1\), the sum \(\sum_{n=1}^{N-1}\) is empty, so (21) becomes
\[
\log\Gamma(z)
=
\Bigl(z-\frac12\Bigr)\log z - z + \frac{\log(2\pi)}{2}
+ R_1(z),
\]
and (23) gives
\[
R_1(z)=\int_0^\infty \frac{B_2 - B_2(\{x\})}{2\,(x+z)^2}\,dx.
\]

**Step 2 (differentiate both sides).**  
By definition \(\psi(z)=\frac{d}{dz}\log\Gamma(z)\). Differentiating the explicit part:
\[
\frac{d}{dz}\Bigl(\Bigl(z-\frac12\Bigr)\log z - z\Bigr)
= \log z - \frac{1}{2z}.
\]

So we just need \(\frac{d}{dz}R_1(z)\).

**Step 3 (differentiate under the integral sign).**  
Let
\[
F(x,z)=\frac{B_2 - B_2(\{x\})}{2\,(x+z)^2}.
\]
Then for fixed \(x\ge0\), \(F(\cdot,z)\) is holomorphic in \(z\) on \(\Re z>0\), and
\[
\partial_z F(x,z)=\frac{B_2 - B_2(\{x\})}{2}\cdot\frac{d}{dz}(x+z)^{-2}
=
\frac{B_2 - B_2(\{x\})}{2}\cdot(-2)(x+z)^{-3}
=
-\frac{B_2 - B_2(\{x\})}{(x+z)^3}.
\]

To justify exchanging derivative and integral in a Lean‑friendly way, you can use dominated convergence / “differentiate under the integral” with a global integrable majorant:

- Since \(\Re z>0\), for all \(x\ge0\), \(|x+z|\ge x+\Re z\).
- Also \(B_2 - B_2(\{x\})\) is bounded on \([0,\infty)\); in fact
  \[
  B_2 - B_2(t) = t - t^2 = t(1-t)\in[0,1/4]\quad (t\in[0,1]).
  \]
  (This identity is just algebra from \(B_2(t)=t^2-t+1/6\).)

Hence for \(x\ge0\),
\[
|\partial_z F(x,z)|
\le \frac{1/4}{|x+z|^3}
\le \frac{1/4}{(x+\Re z)^3},
\]
and \(\int_0^\infty (x+\Re z)^{-3}\,dx <\infty\).  
So `integrable` majorant exists, and you can swap derivative and integral.

Therefore
\[
R_1'(z)
=\int_0^\infty \partial_z F(x,z)\,dx
=
-\int_0^\infty \frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx.
\]

**Step 4 (conclude).**  
Differentiating the \(N=1\) Stirling identity:
\[
\psi(z)
=
\log z - \frac{1}{2z} + R_1'(z)
=
\log z - \frac{1}{2z}
-
\int_0^\infty \frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\]
which rearranges to the claimed formula.

That’s exactly your Ask 1 identity, with the reference anchored at Johansson (21) and (23). citeturn7view2

---

## Ask 2 — Kernel integral (exact evaluation + inequality)

Let \(z=\sigma+i\tau\) with \(\sigma>0\), \(|z|=\sqrt{\sigma^2+\tau^2}\).

Define
\[
I(\sigma,\tau)=\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2}\,dx.
\]

### Step 1: shift
Let \(y=x+\sigma\). Then
\[
I(\sigma,\tau)=\int_\sigma^\infty (y^2+\tau^2)^{-3/2}\,dy.
\]

### Step 2: antiderivative
- If \(\tau=0\):  
  \(\int_\sigma^\infty y^{-3}\,dy = \big[-\tfrac12 y^{-2}\big]_\sigma^\infty = \frac{1}{2\sigma^2}\).  
  And \(\frac{1}{|z|(|z|+\sigma)}=\frac{1}{\sigma(2\sigma)}=\frac{1}{2\sigma^2}\), so the formula matches.
- If \(\tau\ne 0\): the standard primitive is
  \[
  \frac{y}{\tau^2\sqrt{y^2+\tau^2}}
  \quad\text{since}\quad
  \frac{d}{dy}\Big(\frac{y}{\sqrt{y^2+\tau^2}}\Big)=\frac{\tau^2}{(y^2+\tau^2)^{3/2}}.
  \]
  Hence
  \[
  I(\sigma,\tau)
  =
  \Big[\frac{y}{\tau^2\sqrt{y^2+\tau^2}}\Big]_{y=\sigma}^{\infty}
  =
  \frac{1}{\tau^2}-\frac{\sigma}{\tau^2\sqrt{\sigma^2+\tau^2}}
  =
  \frac{\sqrt{\sigma^2+\tau^2}-\sigma}{\tau^2\sqrt{\sigma^2+\tau^2}}.
  \]
  Multiply numerator and denominator by \(\sqrt{\sigma^2+\tau^2}+\sigma\):
  \[
  I(\sigma,\tau)=
  \frac{\tau^2}{\tau^2\,\sqrt{\sigma^2+\tau^2}\,(\sqrt{\sigma^2+\tau^2}+\sigma)}
  =
  \frac{1}{|z|(|z|+\sigma)}.
  \]

So in all cases:
\[
\boxed{
\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2}\,dx
=
\frac{1}{|z|(|z|+\sigma)}.
}
\]

### Step 3: inequality
Since \(|z|+\sigma \ge |z|\) for \(\sigma\ge0\),
\[
\frac{1}{|z|(|z|+\sigma)}\le \frac{1}{|z|^2}.
\]

That proves Ask 2.

---

## Ask 3 — Point bounds for \(a(\xi)=\log\pi-\Re\psi(\tfrac14+i\pi\xi)\) without any DLMF remainder axiom

You can do this **purely** from Ask 1 + Ask 2 + the digamma shift \(\psi(z+1)=\psi(z)+1/z\).

### 3.1. A single reusable lemma (error bound from the identity)

Define the “error term”
\[
E(z):=\psi(z)-\log z+\frac{1}{2z}.
\]
Ask 1 gives
\[
E(z)= -\int_0^\infty \frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx.
\]
Since \(0\le B_2 - B_2(\{x\}) = \{x\}(1-\{x\}) \le 1/4\),
\[
|E(z)|\le \frac14\int_0^\infty \frac{dx}{|x+z|^3}.
\]
For \(\Re z=\sigma>0\), \(|x+z|^2=(x+\sigma)^2+\tau^2\), so by Ask 2,
\[
\int_0^\infty \frac{dx}{|x+z|^3}
=\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2}dx
=\frac{1}{|z|(|z|+\sigma)}
\le \frac{1}{|z|^2}.
\]
Therefore:
\[
\boxed{
|E(z)|\le \frac{1}{4|z|(|z|+\Re z)}\le \frac{1}{4|z|^2}
\qquad(\Re z>0).
}
\]

This is the “replacement remainder inequality” you can use everywhere.

Also, since \(\Re(\log z)=\log|z|\) on the principal branch (safe for \(\Re z>0\)), you get the real‑part version:
\[
\Re\psi(z)
=
\log|z|-\Re\!\Big(\frac{1}{2z}\Big)+\Re E(z),
\qquad
|\Re E(z)|\le |E(z)|.
\]

### 3.2. Use the shift identity to make the error tiny at small \(\xi\)

Use
\[
\psi(z+r)=\psi(z)+\sum_{k=0}^{r-1}\frac{1}{z+k},
\quad\text{so}\quad
\psi(z)=\psi(z+r)-\sum_{k=0}^{r-1}\frac{1}{z+k}.
\]
Taking real parts:
\[
\Re\psi(z)
=
\Re\psi(z+r) - \sum_{k=0}^{r-1}\Re\!\Big(\frac{1}{z+k}\Big),
\]
and for \(z=\sigma+i\tau\) with \(\sigma>0\),
\[
\Re\!\Big(\frac{1}{z+k}\Big)=\frac{\sigma+k}{(\sigma+k)^2+\tau^2}>0.
\]

So to get an **upper** bound for \(\Re\psi(z)\) (hence a **lower** bound for \(a(\xi)\)), you:
1) upper‑bound \(\Re\psi(z+r)\) via the \(E(z)\) bound at the shifted point (large \(|z+r|\) ⇒ small error),
2) subtract a **lower** bound for the positive sum \(\sum \Re(1/(z+k))\).

This is exactly the “no numerics” route that still gives tight point bounds.

### 3.3. Recommended practical constants / shifts

- For \(\xi=\tfrac32,\tfrac52\), you can usually take **\(r=0\)**: \(|z|\) is already large, so \(|E(z)|\le 1/(4|z|^2)\) is tiny, and
  \[
  \Re\psi(z)\le \log|z|-\Re(1/(2z))+1/(4|z|^2)
  \]
  is good enough to prove very comfortable bounds like
  \[
  a(3/2)\ge -\tfrac12,\qquad a(5/2)\ge -1.
  \]
  (Your targets \(-9/20\) and \(-1\) are certainly achievable this way; the first is easy margin‑wise.)

- For \(\xi=\tfrac12\), **do a shift**, because \(|z|\) is small and the raw \(1/(4|z|^2)\) error is too weak.
  A safe choice is **\(r=5\)** (even \(r=6\) if you want more slack):
  \[
  z = \frac14 + i\frac{\pi}{2},\qquad w=z+5=\frac{21}{4}+i\frac{\pi}{2}.
  \]
  Then
  \[
  \Re\psi(z)=\Re\psi(w)-\sum_{k=0}^4\frac{k+1/4}{(k+1/4)^2+(\pi/2)^2}.
  \]
  Bound \(\Re\psi(w)\) using
  \[
  \Re\psi(w)\le \log|w|-\frac{\Re w}{2|w|^2}+\frac{1}{4|w|^2},
  \]
  and bound the sum from below using \(\pi\le 22/7\) to upper‑bound the denominators (bigger subtraction ⇒ smaller \(\Re\psi(z)\)).

This gives a clean analytic proof route for \(a(1/2)\ge 17/25\) with enough margin if you take \(r=5\) or \(6\). (The remaining work is just bounding a couple of logs of rationals and a few rational functions of \(\pi\); all elementary.)

### 3.4. If you want “simpler but safe” constants
If you’d rather avoid tight log bookkeeping, these are much easier to certify from the same method and typically still work in the A3 floor arithmetic:

- \(a(1/2)\ge 2/3\)
- \(a(3/2)\ge -1/2\)
- \(a(5/2)\ge -1\)

If your downstream constants were tuned specifically to \(17/25\) and \(-9/20\), keep your original targets; otherwise these are cheaper.

---

## Summary of what you can implement as Lean lemmas

1) **(Main identity)** derived from Johansson (21)+(23) at \(N=1\) by differentiation:
\[
\psi(z)-\log z+\frac{1}{2z} = -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx\quad(\Re z>0).
\]
Source for (21)–(23) and the fractional part definition: citeturn7view2

2) **(Kernel integral)**:
\[
\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2} dx
=
\frac{1}{|z|(|z|+\sigma)}
\le \frac{1}{|z|^2}.
\]

3) **(Uniform remainder bound)**:
\[
|E(z)| \le \frac{1}{4|z|(|z|+\Re z)} \le \frac{1}{4|z|^2}.
\]

4) **(Point bounds for \(a(\xi)\))** via shift:
\[
\Re\psi(z)=\Re\psi(z+r)-\sum_{k=0}^{r-1}\Re\!\Big(\frac{1}{z+k}\Big),
\]
with \(\Re(1/(z+k))=(\Re z+k)/|z+k|^2\).

If you want, paste the exact Lean statements you’re using for `digamma_add_one` / `intervalIntegral` so I can match the proof skeleton to the API (e.g. which “differentiate under integral sign” lemma you already have available).

## USER
Task: validate and formalize the Stieltjes N=1 remainder route for the digamma tail.

1) Confirm the exact identity (Johansson eqs 21 + 23, N=1, m=1):
   ψ(z) − log z + 1/(2z) = −∫₀^∞ (B2 − B2(fract x))/(x+z)^3 dx  for Re z > 0,
   with a clean differentiation-under-integral justification.

2) Provide Lean-friendly lemmas:
   - 0 ≤ B2 − B2(fract x) ≤ 1/4.
   - ∫₀^∞ ((x+σ)^2+τ^2)^(-3/2) dx = 1/(|z|(|z|+σ)) ≤ 1/|z|^2.
   - |E(z)| ≤ 1/(4|z|^2), hence |Re E(z)| ≤ 1/(4|z|^2).

3) Tail bound on the vertical line:
   For z = 1/4 + iπξ, ξ ≥ 5/2, show
   log|z| ≤ log(1+ξ^2) + 1/11 (using π ≤ 22/7),
   and conclude |Re ψ(z)| ≤ log(1+ξ^2) + 1/10.

If any constant needs loosening to simplify the Lean proof, propose the cleanest replacement.

## ASSISTANT
Below is a **Lean‑friendly certificate** for the whole Stieltjes \(N=1\) tail route, with (i) the exact reference in Johansson and (ii) the exact inequality chain that yields your final
\[
|\Re\psi(\tfrac14+i\pi\xi)|\le \log(1+\xi^2)+\tfrac{1}{10}\quad(\xi\ge\tfrac52).
\]

I’ll keep everything at the level of “statements + proof skeletons” that map cleanly to `Real.fract`, `Complex.log`, norms, and improper integrals.

---

## 1) Main identity (Johansson (21)+(23), specialize \(N=1\), differentiate)

### 1.1 Reference and specialization

Johansson gives the logarithmic Stirling expansion with remainder (his equations (21)–(24)):

- **(21)** \(\log\Gamma(z) = (z-\tfrac12)\log z - z + \tfrac12\log(2\pi) + \sum_{n=1}^{N-1}T_n(z) + R_N(z)\).  
- **(23)** \(R_N(z)=\displaystyle\int_0^\infty \frac{B_{2N}-B_{2N}(\{x\})}{2N(x+z)^{2N}}\,dx\), for \(z\notin(-\infty,0]\), \(N\ge 1\).  
- **(24)** Bernoulli polynomials and fractional part \(\{x\}=x-\lfloor x\rfloor\).  
All explicitly in the PDF around the statement of (21)–(24). citeturn6view0

Johansson also notes that (23) can be proved using Euler–Maclaurin, citing Olver (1997, Ch. 8). citeturn6view0

Now specialize to **\(N=1\)**. Then the sum \(\sum_{n=1}^{N-1}\) is empty, and (23) becomes
\[
R_1(z)=\int_0^\infty \frac{B_2-B_2(\{x\})}{2(x+z)^2}\,dx,
\qquad z\notin(-\infty,0].
\]
On your line \(\Re z=\tfrac14>0\), we are certainly in the domain \(z\notin(-\infty,0]\).

### 1.2 Differentiate to get digamma (your target identity)

Define
\[
E(z):=\psi(z)-\log z+\frac{1}{2z}.
\]

**Goal identity (what you want in Lean):** for \(\Re z>0\),
\[
E(z)= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx,
\]
equivalently
\[
\psi(z)-\log z+\frac{1}{2z}
= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

**Proof skeleton (clean and formalizable):**

1) Start from Johansson \(N=1\) identity:
\[
\log\Gamma(z) = \Bigl(z-\frac12\Bigr)\log z - z + \frac12\log(2\pi) + R_1(z),
\]
with \(R_1\) as above. citeturn6view0

2) Differentiate both sides on the domain \(\Re z>0\), where the principal \(\log\) is holomorphic:
- \(\frac{d}{dz}\log\Gamma(z)=\psi(z)\) (this is the standard definition/lemma connecting digamma and logGamma; you already have `digamma_add_one`, etc., so you likely already have the logGamma derivative lemma available).
- \(\frac{d}{dz}\big((z-\tfrac12)\log z - z\big)=\log z-\frac{1}{2z}\).

3) For \(R_1\), differentiate under the integral sign:
\[
R_1(z)=\int_0^\infty \underbrace{\frac{B_2-B_2(\{x\})}{2(x+z)^2}}_{=:f(x,z)}\,dx.
\]
Then
\[
\partial_z f(x,z)=\frac{B_2-B_2(\{x\})}{2}\cdot(-2)(x+z)^{-3}
=-(B_2-B_2(\{x\}))(x+z)^{-3}.
\]
So (formally)
\[
R_1'(z)=\int_0^\infty \partial_z f(x,z)\,dx
=-\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

4) Putting derivatives together yields
\[
\psi(z)=\log z-\frac{1}{2z}+R_1'(z)
=\log z-\frac{1}{2z}-\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx,
\]
and rearranging gives your target formula.

### 1.3 Differentiation-under-integral justification (Lean‑friendly)

You only need a **dominated convergence** style lemma for parameter differentiation.

Take \(z\) with \(\sigma=\Re z>0\). Choose a small neighborhood \(U\) of \(z\) such that \(\Re w\ge \sigma/2\) for all \(w\in U\) (easy by continuity of `re`).

Then for all \(w\in U\), \(x\ge 0\):
- \(|x+w|\ge x+\Re w\ge x+\sigma/2\).
- (See next section) \(0\le B_2-B_2(\{x\})\le 1/4\).

So
\[
|\partial_z f(x,w)|
\le \frac{1/4}{|x+w|^3}
\le \frac{1/4}{(x+\sigma/2)^3}.
\]
And \(\int_0^\infty (x+\sigma/2)^{-3}dx <\infty\). Hence \(\partial_z f(\cdot,w)\) is dominated by an integrable function independent of \(w\in U\), which is exactly what the standard “differentiate under the integral sign” lemma asks for.

That’s the clean justification you want to mirror in Lean.

---

## 2) Lean‑friendly lemmas you asked for

I’ll phrase them in math statements; you can translate to Lean with `Real.fract`, `Complex.abs` / `‖·‖`, etc.

### 2.1 Bernoulli \(B_2\) bounds: \(0\le B_2-B_2(\{x\})\le 1/4\)

Let \(B_2(t)=t^2-t+\tfrac16\).

**Lemma (algebraic simplification):** for any real \(t\),
\[
B_2 - B_2(t)=\frac16-\Big(t^2-t+\frac16\Big)=t-t^2=t(1-t)=\frac14-(t-\tfrac12)^2,
\]
where \(B_2 := B_2(0)=\tfrac16\).

**Lemma (range of fract):** for any real \(x\),
\[
0\le \{x\}<1.
\]

**Lemma (bounds):** for any real \(x\),
\[
0 \le B_2 - B_2(\{x\}) \le \frac14.
\]

**Proof skeleton:**
- Put \(t=\{x\}\). Then \(0\le t\le 1\).
- Use \(B_2-B_2(t)=t(1-t)\). Nonnegativity is immediate.
- Use \(t(1-t)=\frac14-(t-\tfrac12)^2\le \frac14\) since squares are \(\ge 0\).

This is exactly the kind of lemma Lean likes (`sq_nonneg`, `mul_nonneg`, `sub_nonneg`, etc.).

---

### 2.2 Kernel integral: exact evaluation and inequality

Let \(\sigma>0\), \(\tau\in\mathbb R\), and \(z=\sigma+i\tau\), \(|z|=\sqrt{\sigma^2+\tau^2}\).

**Lemma (exact):**
\[
\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2}\,dx
=
\frac{1}{|z|(|z|+\sigma)}.
\]

**Lemma (inequality):**
\[
\frac{1}{|z|(|z|+\sigma)}\le \frac{1}{|z|^2}.
\]

**Proof skeleton:**
1) Substitute \(y=x+\sigma\), so integral becomes \(\int_\sigma^\infty (y^2+\tau^2)^{-3/2}dy\).
2) Antiderivative:
   - If \(\tau=0\): \(\int_\sigma^\infty y^{-3}dy=\frac{1}{2\sigma^2}\), which equals \(\frac{1}{|z|(|z|+\sigma)}\) since \(|z|=\sigma\).
   - If \(\tau\neq 0\): use
     \[
     \frac{d}{dy}\Big(\frac{y}{\sqrt{y^2+\tau^2}}\Big)=\frac{\tau^2}{(y^2+\tau^2)^{3/2}},
     \]
     so
     \[
     \int (y^2+\tau^2)^{-3/2}dy = \frac{y}{\tau^2\sqrt{y^2+\tau^2}}.
     \]
     Evaluate between \(y=\sigma\) and \(y\to\infty\), simplify, and rationalize to get \(\frac{1}{|z|(|z|+\sigma)}\).
3) Inequality is just \(|z|+\sigma\ge |z|\).

---

### 2.3 Remainder bound: \(|E(z)|\le 1/(4|z|^2)\) and real part

Define
\[
E(z):=\psi(z)-\log z+\frac{1}{2z}.
\]
Using the identity from §1:
\[
E(z)= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

**Lemma (absolute bound, sharper form):** for \(\Re z=\sigma>0\),
\[
|E(z)|\le \frac{1}{4|z|(|z|+\sigma)}.
\]

**Lemma (weaker but simpler):**
\[
|E(z)|\le \frac{1}{4|z|^2}.
\]

**Lemma (real part):**
\[
|\Re E(z)|\le |E(z)|\le \frac{1}{4|z|^2}.
\]

**Proof skeleton:**
- Triangle inequality:
  \[
  |E(z)|\le \int_0^\infty \frac{|B_2-B_2(\{x\})|}{|x+z|^3}\,dx.
  \]
- Use \(0\le B_2-B_2(\{x\})\le 1/4\).
- Note \(|x+z|^2=(x+\sigma)^2+\tau^2\) so \(|x+z|^{-3} = ((x+\sigma)^2+\tau^2)^{-3/2}\).
- Apply the kernel integral lemma:
  \[
  \int_0^\infty |x+z|^{-3}dx = \frac{1}{|z|(|z|+\sigma)}\le \frac{1}{|z|^2}.
  \]
- Multiply by \(1/4\).

This produces exactly the bound you use downstream.

---

## 3) Tail bound on the vertical line \(z=\tfrac14+i\pi\xi\)

Let
\[
z(\xi)=\frac14+i\pi\xi,\qquad \xi\ge \frac52.
\]
Then \(\sigma=\Re z=1/4\) and \(|z|^2=\frac1{16}+\pi^2\xi^2\).

### 3.1 Reduce \(|\Re\psi|\) to \(\log|z|\) plus a tiny rational tail

From the \(N=1\) formula:
\[
\psi(z)=\log z-\frac{1}{2z}+E(z).
\]
Take real parts on \(\Re z>0\) (principal log): \(\Re(\log z)=\log|z|\). Hence
\[
\Re\psi(z)=\log|z|-\Re\Big(\frac{1}{2z}\Big)+\Re E(z).
\]
So
\[
|\Re\psi(z)|
\le \log|z|+\Big|\Re\frac{1}{2z}\Big|+|\Re E(z)|.
\]
Now
\[
\Re\frac{1}{2z}=\frac{\Re z}{2|z|^2}=\frac{1}{8|z|^2},
\quad
|\Re E(z)|\le \frac{1}{4|z|^2}.
\]
Therefore
\[
|\Re\psi(z)|
\le \log|z|+\frac{1}{8|z|^2}+\frac{1}{4|z|^2}
=
\log|z|+\frac{3}{8|z|^2}.
\]

**Bounding the small term:** for \(\xi\ge 5/2\) and using the standard \(\pi\ge 3\),
\[
|z|^2=\frac1{16}+\pi^2\xi^2\ge \pi^2\xi^2\ge 9\cdot\frac{25}{4}=\frac{225}{4},
\]
so
\[
\frac{3}{8|z|^2}\le \frac{3}{8\cdot(225/4)}=\frac{1}{150}.
\]

So you’re down to:
\[
|\Re\psi(z(\xi))|\le \log|z(\xi)|+\frac{1}{150}.
\]

---

### 3.2 Log bound: \(\log|z|\le \log(1+\xi^2)+1/11\) for \(\xi\ge 5/2\)

You asked specifically for the \(1/11\) version using \(\pi\le 22/7\). Here’s a clean “polynomial certificate”:

1) Use \(\pi\le 22/7\Rightarrow \pi^2\le 484/49\). Then
\[
|z|^2=\frac1{16}+\pi^2\xi^2 \le \frac1{16}+\frac{484}{49}\xi^2.
\]

2) Set \(u=\xi^2\) (so \(u\ge 25/4\)). It suffices to show
\[
\frac1{16}+\frac{484}{49}u \le \frac{144}{121}(1+u)^2,
\]
because then taking square roots gives
\[
|z|\le \frac{12}{11}(1+u)=\frac{12}{11}(1+\xi^2).
\]

3) Multiply by the positive common denominator \(94864=16\cdot49\cdot121\). The inequality becomes:
\[
P(u):=112896u^2-711232u+106967 \ge 0.
\]

4) Check monotonicity for \(u\ge 25/4\):
\[
P'(u)=225792u-711232.
\]
At \(u_0=25/4\), \(P'(u_0)=699968>0\). Hence \(P\) is increasing on \([25/4,\infty)\).

5) Check \(P(u_0)\):
\[
P(25/4)=71767>0.
\]
So \(P(u)\ge P(u_0)>0\) for all \(u\ge 25/4\). Therefore
\[
|z|\le \frac{12}{11}(1+\xi^2).
\]

6) Take logs (all positive):
\[
\log|z|
\le \log\Big(\frac{12}{11}(1+\xi^2)\Big)
=
\log(1+\xi^2)+\log(12/11).
\]
Use \(\log x \le x-1\) for \(x>0\) with \(x=12/11\):
\[
\log(12/11)\le \frac{1}{11}.
\]
So
\[
\boxed{\log|z|\le \log(1+\xi^2)+\frac{1}{11}}.
\]

---

### 3.3 Final tail bound with your constants

Combine:
\[
|\Re\psi(z(\xi))|
\le \log|z(\xi)|+\frac{1}{150}
\le \log(1+\xi^2)+\frac{1}{11}+\frac{1}{150}.
\]
And
\[
\frac{1}{11}+\frac{1}{150}=\frac{161}{1650}<\frac{165}{1650}=\frac{1}{10}.
\]
So finally:
\[
\boxed{|\Re\psi(\tfrac14+i\pi\xi)|\le \log(1+\xi^2)+\frac{1}{10}\quad(\xi\ge\tfrac52).}
\]

---

## Constants: do we need to loosen anything?

You don’t have to. The chain above is already “Lean‑clean”:

- all comparisons are polynomial/rational;
- the only transcendental bits are `pi ≤ 22/7`, `pi ≥ 3`, and `log x ≤ x-1`.

If you *do* want an even simpler proof of the log step (at the cost of a slightly weaker final constant), the clean escape hatch is:

- prove \(\log|z|\le \log(1+\xi^2)+1/10\) (larger constant → easier inequality),
- keep the \(1/150\) term,
- conclude \(|\Re\psi|\le \log(1+\xi^2)+ (1/10+1/150)\), i.e. replace \(1/10\) by \(1/9\) safely.

But since you explicitly want the **\(1/10\)** statement, the \(1/11\) split is the right sweet spot.

---

If you want, I can rewrite the above as a **literal list of Lean lemma signatures** (with `Complex.abs`, `Real.fract`, `MeasureTheory.integral` over `Ioi (0:ℝ)`), but analytically this is the complete certificate.

## USER
Goal: formalize the kernel integral in Q3.

lemma integral_kernel_eq (σ τ : ℝ) (hσ : 0 < σ) :
  ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ)^2 + τ^2)^(3/2:ℝ)
    = 1 / (Real.sqrt (σ^2 + τ^2) * (Real.sqrt (σ^2 + τ^2) + σ))

Two acceptable routes:
1) exact evaluation by primitive F(y)=y/(τ^2*sqrt(y^2+τ^2)), split τ=0 vs τ≠0,
   use integral_Ioi_of_hasDerivAt_of_tendsto'.
2) if exact eval too heavy, prove bound only:
   ∫ ... ≤ 1/(σ^2+τ^2) and use it for Stieltjes remainder.

Files to look at: Q3/DigammaRemainder.lean and PROWKA_RESPONSE_3.md.

## ASSISTANT
Ниже — максимально «Lean‑friendly» сертификат именно для твоей леммы `integral_kernel_eq` (и сразу как её закрыть через route 1), плюс упрощённый fallback route 2 (если упрёшься в `tendsto`).

Я ориентируюсь на то, что у тебя уже есть скелет в `Q3/DigammaRemainder.lean` и план в `PROWKA_RESPONSE_3.md`. fileciteturn0file0

---

## 0) Что нужно доказать

```lean
lemma integral_kernel_eq (σ τ : ℝ) (hσ : 0 < σ) :
  ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ)^2 + τ^2)^(3/2:ℝ)
    = 1 / (Real.sqrt (σ^2 + τ^2) * (Real.sqrt (σ^2 + τ^2) + σ))
```

---

## 1) Route 1 (точное вычисление) — структура доказательства в Lean

### 1.1. Разбиение по `τ = 0` / `τ ≠ 0`

```lean
by_cases hτ : τ = 0
· -- τ = 0 branch
· -- τ ≠ 0 branch
```

Это прям реально облегчает: в `τ ≠ 0` у тебя появляется «правильная» первообразная с делением на `τ^2`, а в `τ=0` интеграл элементарный (как `∫ (x+σ)^{-3}`).

---

### 1.2. Ветка `τ ≠ 0`: первообразная и `integral_Ioi_of_hasDerivAt_of_tendsto'`

#### (A) Определи первообразную

Возьми именно такую:

\[
F(x) := \frac{x+\sigma}{\tau^2\sqrt{(x+\sigma)^2+\tau^2}}.
\]

Lean:

```lean
let F : ℝ → ℝ := fun x =>
  (x + σ) / (τ^2 * Real.sqrt ((x + σ)^2 + τ^2))
```

#### (B) Производная: `F' = integrand` на `Ioi 0`

Ключевая «ручная» математика:

Пусть \(u(x)=(x+σ)^2+τ^2\). Тогда
\[
\frac{d}{dx}\Big(\frac{x+σ}{\sqrt{u(x)}}\Big)
= \frac{u(x)-(x+σ)^2}{u(x)^{3/2}}
= \frac{τ^2}{u(x)^{3/2}}.
\]
Значит
\[
F'(x)=\frac{1}{τ^2}\cdot \frac{τ^2}{u(x)^{3/2}}
=\frac{1}{u(x)^{3/2}}.
\]

Lean‑friendly приём: **не пытайся сразу дифференцировать “деление”**. Лучше сделай:
- `G x := (x+σ) / Real.sqrt u`
- потом `F = (1/τ^2) * G / 1` (или `F = G / τ^2`) и используй `HasDerivAt.const_mul` / `HasDerivAt.div_const`.

Технически тебе нужны леммы:
- `HasDerivAt` для `x ↦ x+σ`,
- `HasDerivAt` для `x ↦ (x+σ)^2`,
- `HasDerivAt` для `x ↦ (x+σ)^2 + τ^2`,
- `HasDerivAt` для `Real.sqrt` композиции (требует `u(x) ≠ 0`, а у нас `u(x) > 0`),
- `HasDerivAt` для `x ↦ 1/(Real.sqrt u)` (через `HasDerivAt.inv`),
- правила произведения/суммы.

**Важно:** `u(x)>0` для всех `x>0`, потому что `σ>0` и `τ^2≥0`:
\[
u(x)=(x+σ)^2+τ^2 \ge (x+σ)^2 > 0.
\]
Так что `sqrt` и `inv` легальны без “edge cases”.

#### (C) Предел на бесконечности: `Tendsto F atTop (𝓝 (1/τ^2))`

Самый Lean‑дружелюбный путь — не мудрить с `1 / sqrt(1 + ...)`, а показать, что дробь стремится к 1 через оценку разности:

Пусть \(y=x+σ>0\). Тогда
\[
\left|1-\frac{y}{\sqrt{y^2+τ^2}}\right|
=\frac{\sqrt{y^2+τ^2}-y}{\sqrt{y^2+τ^2}}
=\frac{τ^2}{\sqrt{y^2+τ^2}\,(\sqrt{y^2+τ^2}+y)}.
\]
И так как \(\sqrt{y^2+τ^2}\ge y\), то знаменатель \(\ge y(2y)=2y^2\), откуда
\[
0 \le 1-\frac{y}{\sqrt{y^2+τ^2}} \le \frac{τ^2}{2y^2}.
\]
А \(\frac{τ^2}{2(x+σ)^2}\to 0\) при \(x\to\infty\). Значит \(\frac{x+σ}{\sqrt{(x+σ)^2+τ^2}}\to 1\). Тогда \(F(x)\to 1/τ^2\).

В Lean это делается через squeeze:
- показать `0 ≤ 1 - ratio`,
- показать `1 - ratio ≤ τ^2 / (2*(x+σ)^2)`,
- `tendsto` правой части к `0`,
- вывести `tendsto (1-ratio) atTop (𝓝 0)` и значит `tendsto ratio atTop (𝓝 1)`,
- потом `tendsto` для `F` как `((1/τ^2) * ratio)`.

#### (D) Применение `integral_Ioi_of_hasDerivAt_of_tendsto'`

Ты сам указал эту лемму как целевую. Обычно она выдаёт:
\[
\int_{(0,\infty)} F'(x)\,dx = \lim_{x\to\infty}F(x)-F(0).
\]

То есть в конце ты получишь:
\[
\int_0^\infty \frac{dx}{((x+σ)^2+τ^2)^{3/2}}
=
\frac{1}{τ^2} - \frac{σ}{τ^2\sqrt{σ^2+τ^2}}.
\]

#### (E) Алгебра: привести к требуемому RHS

Положи \(a:=\sqrt{σ^2+τ^2}\). Надо показать:
\[
\frac{1}{τ^2} - \frac{σ}{τ^2 a}
=
\frac{1}{a(a+σ)}.
\]

Самый надёжный Lean‑приём: умножить обе стороны на \(τ^2 a (a+σ)\) (через `field_simp [hτ]`) и свести к тождеству:

Левая часть * \(τ^2 a (a+σ)\) = \((1-\frac{σ}{a})a(a+σ)=(a-σ)(a+σ)=a^2-σ^2=τ^2\).  
Правая часть * \(τ^2 a (a+σ)\) = \(τ^2\).

Для этого ещё нужен факт:
\[
a^2 = σ^2+τ^2
\]
в Lean: `Real.sq_sqrt` (с предварительным `0 ≤ σ^2+τ^2`).

---

### 1.3. Ветка `τ = 0`: элементарный интеграл

При `τ=0` интеграл:
\[
\int_0^\infty \frac{dx}{((x+σ)^2)^{3/2}}=\int_0^\infty \frac{dx}{(x+σ)^3}
=\frac{1}{2σ^2}.
\]

RHS при `τ=0`:
\[
\frac{1}{\sqrt{σ^2}\,(\sqrt{σ^2}+σ)}
=\frac{1}{σ(σ+σ)}=\frac{1}{2σ^2}
\]
(так как `σ>0` ⇒ `Real.sqrt (σ^2)=σ`).

Lean‑технически здесь два узких места:

1) Превратить `((x+σ)^2)^(3/2:ℝ)` в `(x+σ)^3` на `x>0`.  
   Самый мягкий способ: **вообще не раскрывать `rpow`**, а в `τ=0` ветке тоже используй первообразную для `1/(x+σ)^3` и просто покажи, что `((x+σ)^2)^(3/2)= (x+σ)^3` для `x∈Ioi 0` (т.е. `x+σ>0`). Это обычно делается через:
   - `Real.rpow_mul` или `Real.sqrt_sq_eq_abs` + `abs_of_pos`,
   - либо через `Real.sqrt_mul_self` для `0 ≤ x+σ`.

2) Предел первообразной `(-1/(2*(x+σ)^2))` на `atTop` равен `0`.

После этого можно применить тот же `integral_Ioi_of_hasDerivAt_of_tendsto'`.

---

## 2) Route 2 (если exact eval больно): докажи только bound, но **честно**

Ты написал альтернативу:

\[
\int_0^\infty ((x+σ)^2+τ^2)^{-3/2}dx \le \frac{1}{σ^2+τ^2}.
\]

Честно: доказать это *без* точной первообразной всё равно неудобно — большинство “простых” сравнений дают слабее (типа `≤ 1/(σ|z|)`), что для хвоста уже не годится. Поэтому route 2 практически всё равно придёт к той же первообразной и тем же пределам, просто не будет финальной алгебры к `1/(|z|(|z|+σ))`. Но раз у тебя уже есть `integral_kernel_bound` выведенный из `integral_kernel_eq`, то реально лучше закрыть **exact eval** и всё.

---

## 3) Что у тебя уже готово в файле

Хорошая новость: в `DigammaRemainder.lean` у тебя уже закрыта Bernoulli‑оценка:

```lean
lemma bernoulli2Diff_bounds (x : ℝ) :
    0 ≤ bernoulli2Diff x ∧ bernoulli2Diff x ≤ (1 / 4 : ℝ) := ...
```

т.е. пункт “\(0\le B_2-B_2(\mathrm{fract}\,x)\le 1/4\)” уже полностью DONE.

Остаётся только заменить

```lean
axiom integral_kernel_eq ...
```

на реальную лемму тем способом, который выше.

---

## 4) Мини‑чеклист (чтобы не утонуть в Lean)

Если делать быстро и без долгих отклонений, я бы шёл так:

1) Напиши отдельную лемму на “сдвиг” (не обязательно, но удобно):
   \[
   \int_{0}^{\infty} f(x+σ)\,dx = \int_{σ}^{\infty} f(y)\,dy
   \]
   (в MeasureTheory это обычно `Measure.map_add_right`/`integral_comp_add_right`‑подобные штуки; если больно — вообще не делай, дифференцируй первообразную прямо по `x`).

2) Сначала закрой ветку `τ ≠ 0` полностью (там нет `rpow`‑проблемы, только `sqrt`).

3) Потом ветку `τ=0` отдельной маленькой леммой:
   - или докажи упрощение `((x+σ)^2)^(3/2)= (x+σ)^3` на `x>0`;
   - или сразу перепиши integrand как `(x+σ)⁻³` используя `Real.rpow`‑идентичности.

---

Если хочешь, скинь кусок из твоего окружения с **точным именем** леммы `integral_Ioi_of_hasDerivAt_of_tendsto'` (её сигнатуру `#check ...`) — и я подгоню “почти готовый” Lean‑код под конкретные аргументы (`HasDerivAt`/`Tendsto`/`aeStronglyMeasurable` и т.д.).

## USER
We replaced `axiom integral_kernel_eq` with a real proof attempt in
Q3/DigammaRemainder.lean. Need help with two Lean bits:
1) best lemma chain to show `Tendsto (fun x => 1/(x+σ)^2) atTop (𝓝 0)`
   and then `Tendsto g atTop (𝓝 (1/τ^2))` using the decomposition
   g = 1/τ^2 - 1/(sqrt(...) * (sqrt(...)+(x+σ))).
2) any ready-made lemma for `sqrt((x+σ)^2+τ^2) ≥ x+σ` or a clean proof
   of `1/(sqrt...*(sqrt...+x+σ)) ≤ 1/(x+σ)^2` on Ioi 0.

If you can give Lean-ready snippets/lemma names, I can close it fast.

## ASSISTANT
Got it. These two bits are exactly the “glue” you need to close the `τ ≠ 0` limit step and the squeeze.

I’ll give you **Lean‑ready proof patterns** that are robust even if some lemma names differ slightly in your Mathlib version. Where I rely on a library lemma name that might vary, I also give the “manual” fallback (usually 3–5 lines with `tendsto_atTop.2` / `linarith`).

I’m also matching the decomposition you said you use for the primitive-limit:

\[
g(x)=\frac{1}{\tau^2}-\frac{1}{\sqrt{(x+\sigma)^2+\tau^2}\,\big(\sqrt{(x+\sigma)^2+\tau^2}+(x+\sigma)\big)}.
\]

(That decomposition is the cleanest for Lean, as noted in your project notes. fileciteturn0file1)

---

# 1) `Tendsto (fun x => 1/(x+σ)^2) atTop (𝓝 0)` and then `Tendsto g … (1/τ^2)`

### 1.1 A robust chain for `Tendsto (x ↦ 1/(x+σ)^2) → 0`

This avoids any “power tends to infinity” lemma and uses only:
- `tendsto_atTop.2` (manual shift),
- `tendsto_inv_atTop_zero` (if available),
- `Tendsto.pow` (always available),
- a small `simp` rewrite.

```lean
open Filter

-- Step 1: x ↦ x + σ tends to atTop
have h_add : Tendsto (fun x : ℝ => x + σ) atTop atTop := by
  refine tendsto_atTop.2 ?_
  intro b
  refine ⟨b - σ, ?_⟩
  intro x hx
  linarith

-- Step 2: inverse tends to 0
have h_inv : Tendsto (fun x : ℝ => (x + σ)⁻¹) atTop (𝓝 (0 : ℝ)) := by
  -- if `tendsto_inv_atTop_zero` exists:
  simpa using (tendsto_inv_atTop_zero.comp h_add)
  -- fallback (if lemma name differs):
  -- prove directly via tendsto_atTop.1 + ε argument (ask if needed)

-- Step 3: square tends to 0
have h_inv_sq : Tendsto (fun x : ℝ => ((x + σ)⁻¹) ^ 2) atTop (𝓝 (0 : ℝ)) := by
  simpa using (h_inv.pow 2)

-- Step 4: rewrite to 1 / (x+σ)^2
have h_one_div_sq : Tendsto (fun x : ℝ => 1 / (x + σ)^2) atTop (𝓝 (0 : ℝ)) := by
  -- `inv_pow` is the key simp lemma: (a^n)⁻¹ = (a⁻¹)^n
  simpa [one_div, inv_pow] using h_inv_sq
```

**Notes:**
- If `simp [one_div, inv_pow]` doesn’t close the last line, try:
  ```lean
  simp [one_div, pow_two, inv_mul_eq_iff_eq_mul]  -- sometimes works
  ```
  or explicitly:
  ```lean
  have : (1 / (x + σ)^2) = ((x + σ)⁻¹) ^ 2 := by
    simp [one_div, inv_pow]
  ```
- If you don’t have `tendsto_inv_atTop_zero` under that exact name, search your environment for one of these common aliases:
  - `tendsto_inv_atTop_zero`
  - `tendsto_one_div_atTop_nhds_0`
  - `tendsto_inv_atTop_zero'`

If none exist, say so and I’ll give the 6‑line “epsilon proof” using `tendsto_atTop.1` and `Metric.tendsto_atTop`.

---

### 1.2 `Tendsto g atTop (𝓝 (1/τ^2))` via squeeze on the small term

Define the small term
```lean
let s : ℝ → ℝ := fun x => Real.sqrt ((x + σ)^2 + τ^2)
let term : ℝ → ℝ := fun x => 1 / (s x * (s x + (x + σ)))
```

Then prove:
- `0 ≤ term x` eventually,
- `term x ≤ 1/(x+σ)^2` eventually,
- use squeeze + your `h_one_div_sq` to get `term → 0`,
- and hence `g = const - term` tends to `1/τ^2`.

Lean pattern:

```lean
have hterm_tendsto : Tendsto term atTop (𝓝 (0 : ℝ)) := by
  -- squeeze between 0 and 1/(x+σ)^2
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le tendsto_const_nhds h_one_div_sq ?_ ?_
  · -- 0 ≤ term eventually
    filter_upwards [eventually_gt_atTop (0 : ℝ)] with x hx
    -- prove 0 ≤ term x here
    -- (see section 2 below for positivity of denom)
    exact term_nonneg σ τ hσ x hx  -- you'll implement this lemma
  · -- term ≤ 1/(x+σ)^2 eventually
    filter_upwards [eventually_gt_atTop (0 : ℝ)] with x hx
    exact term_le_one_div_sq σ τ hσ x hx  -- implement lemma below
```

Then:

```lean
have hg : Tendsto (fun x => (1/τ^2) - term x) atTop (𝓝 ((1/τ^2) - 0)) :=
  (tendsto_const_nhds.sub hterm_tendsto)
-- simplify (… - 0) and your definition of g
```

This avoids ever proving `term` is integrable at infinity; only needs the squeeze inequality + the limit of `1/(x+σ)^2`.

---

# 2) `sqrt((x+σ)^2+τ^2) ≥ x+σ` and the key inequality `term ≤ 1/(x+σ)^2`

You asked for either a ready lemma or a clean proof. The clean proof is short and stable.

## 2.1 Lemma: `sqrt((x+σ)^2+τ^2) ≥ x+σ` on `x>0`

```lean
have hxσ : 0 < x + σ := add_pos hx hσ

have hsq : (x + σ)^2 ≤ (x + σ)^2 + τ^2 :=
  le_add_of_nonneg_right (sq_nonneg τ)

have hsqrt' : Real.sqrt ((x + σ)^2) ≤ Real.sqrt ((x + σ)^2 + τ^2) :=
  Real.sqrt_le_sqrt hsq

-- sqrt((x+σ)^2) = |x+σ|, and since x+σ>0 this is x+σ
have hsqrt : x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) := by
  simpa [Real.sqrt_sq_eq_abs, abs_of_pos hxσ] using hsqrt'
```

That’s the canonical route: `sqrt_le_sqrt` + `sqrt_sq_eq_abs` + `abs_of_pos`.

## 2.2 Inequality: `1/(s*(s+(x+σ))) ≤ 1/(x+σ)^2`

Let `s = sqrt((x+σ)^2+τ^2)` and assume `hx : 0 < x` so `hxσ : 0 < x+σ`.

**Idea:** show \((x+\sigma)^2 \le s(s+(x+\sigma))\), then invert with `inv_le_inv_of_le`.

Lean snippet:

```lean
set s : ℝ := Real.sqrt ((x + σ)^2 + τ^2)
have hs0 : 0 ≤ s := Real.sqrt_nonneg _
have hxσ : 0 < x + σ := add_pos hx hσ
have hxσ0 : 0 ≤ x + σ := le_of_lt hxσ

have hs : x + σ ≤ s := by
  -- reuse the `hsqrt` proof above, then `simp [s]`:
  -- exact ...
  simpa [s] using hsqrt

have h2 : x + σ ≤ s + (x + σ) := by
  -- b ≤ a+b if 0 ≤ a
  simpa [add_assoc, add_comm, add_left_comm] using (le_add_of_nonneg_left hs0)

have hmul : (x + σ)^2 ≤ s * (s + (x + σ)) := by
  -- mul_le_mul : a≤b → c≤d → 0≤c → 0≤b → a*c ≤ b*d
  have := mul_le_mul hs h2 hxσ0 hs0
  -- left is (x+σ)*(x+σ) = (x+σ)^2
  simpa [pow_two, mul_assoc, mul_left_comm, mul_comm] using this

have hxσ2 : 0 < (x + σ)^2 := sq_pos_of_pos hxσ

have hinv : (s * (s + (x + σ)))⁻¹ ≤ ((x + σ)^2)⁻¹ :=
  inv_le_inv_of_le hxσ2 hmul

have term_le : 1 / (s * (s + (x + σ))) ≤ 1 / (x + σ)^2 := by
  simpa [one_div] using hinv
```

**Nonnegativity of `term`:** once you know `x+σ>0`, both `s` and `s+(x+σ)` are positive, hence product positive, hence reciprocal nonnegative:

```lean
have hspos : 0 < s := lt_of_lt_of_le hxσ hs   -- since hxσ>0 and x+σ ≤ s
have hsplpos : 0 < s + (x + σ) := add_pos (lt_of_lt_of_le hxσ hs) hxσ
have hdenpos : 0 < s * (s + (x + σ)) := mul_pos hspos hsplpos
have term_nonneg : 0 ≤ 1 / (s * (s + (x + σ))) := by
  have : 0 ≤ (s * (s + (x + σ)))⁻¹ := inv_nonneg.mpr (le_of_lt hdenpos)
  simpa [one_div] using this
```

This is usually enough for the squeeze.

---

# 3) Suggested minimal packaging: two helper lemmas you can drop into `DigammaRemainder.lean`

These are exactly what you need to unblock the `Tendsto g` proof.

```lean
lemma sqrt_ge_add (σ τ x : ℝ) (hσ : 0 < σ) (hx : 0 < x) :
  x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) := by
  have hxσ : 0 < x + σ := add_pos hx hσ
  have hsq : (x + σ)^2 ≤ (x + σ)^2 + τ^2 :=
    le_add_of_nonneg_right (sq_nonneg τ)
  have hsqrt' : Real.sqrt ((x + σ)^2) ≤ Real.sqrt ((x + σ)^2 + τ^2) :=
    Real.sqrt_le_sqrt hsq
  simpa [Real.sqrt_sq_eq_abs, abs_of_pos hxσ] using hsqrt'

lemma term_le_one_div_sq (σ τ x : ℝ) (hσ : 0 < σ) (hx : 0 < x) :
  1 / (Real.sqrt ((x + σ)^2 + τ^2) *
        (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ)))
    ≤ 1 / (x + σ)^2 := by
  set s : ℝ := Real.sqrt ((x + σ)^2 + τ^2)
  have hs0 : 0 ≤ s := Real.sqrt_nonneg _
  have hxσ : 0 < x + σ := add_pos hx hσ
  have hxσ0 : 0 ≤ x + σ := le_of_lt hxσ
  have hs : x + σ ≤ s := by simpa [s] using sqrt_ge_add σ τ x hσ hx
  have h2 : x + σ ≤ s + (x + σ) := by
    simpa [add_assoc, add_comm, add_left_comm] using (le_add_of_nonneg_left hs0)
  have hmul : (x + σ)^2 ≤ s * (s + (x + σ)) := by
    have := mul_le_mul hs h2 hxσ0 hs0
    simpa [s, pow_two, mul_assoc, mul_left_comm, mul_comm] using this
  have hxσ2 : 0 < (x + σ)^2 := sq_pos_of_pos hxσ
  have hinv : (s * (s + (x + σ)))⁻¹ ≤ ((x + σ)^2)⁻¹ :=
    inv_le_inv_of_le hxσ2 hmul
  simpa [one_div, s] using hinv
```

Then the squeeze→limit step is quick.

---

If you paste the exact local names for your `term` and `g` definitions (and whether you’re in `ℝ` or coercing from `ℝ≥0∞` somewhere), I can tailor the final `Tendsto g …` proof line-for-line.

## USER
zadanie wnutri fila!

## ASSISTANT
Понял: в `PROSHKA_REQUEST_4` ты хочешь закрыть **последний аксиомный хвост** `re_digamma_remainder_bound_stieltjes` через **Stieltjes / Euler–Maclaurin remainder при N=1**, и дальше собрать tail‑оценку без DLMF. fileciteturn0file0  
Ниже даю ровно то, что нужно: (1) корректность тождества и доминирование для дифференцирования под интегралом, (2) цепочку к bound \(1/(4\|z\|^2)\), (3) самый Lean‑дружелюбный вывод хвоста \(\log(1+\xi^2)+1/10\) при \(\xi\ge 5/2\), причём без тяжёлого полинома “\(12/11\)” — можно сделать проще, но всё равно получить твой промежуточный `+1/11`. fileciteturn0file1

---

## 0) Цели (что именно доказать в Lean)

1) **Stieltjes N=1 identity** (по Johansson Eq. 21+23, \(N=1\), дифференцирование):
\[
\psi(z)-\log z+\frac{1}{2z}
=
-\int_{0}^{\infty}\frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\qquad \Re z>0,
\]
где \(B_2(t)=t^2-t+\frac16\), \(\{x\}=\mathrm{fract}(x)\in[0,1)\). fileciteturn0file0

2) Из него:
\[
|E(z)|\le \frac14\int_0^\infty |x+z|^{-3}\,dx \le \frac{1}{4\|z\|^2},
\quad
|\,\Re E(z)\,|\le \frac{1}{4\|z\|^2},
\]
и затем
\[
\Big|\Re\psi(z)-\log\|z\|+\frac{\Re z}{2\|z\|^2}\Big|\le \frac{1}{4\|z\|^2},
\qquad \Re z>0. fileciteturn0file0
\]

3) Tail на вертикали \(z=\frac14+i\pi\xi\), \(\xi\ge\frac52\):
\[
|\Re\psi(z)|\le \log(1+\xi^2)+\frac{1}{10}.
\]
Причём ты просишь промежуточно
\(\log\|z\|\le \log(1+\xi^2)+\frac{1}{11}\) через \(\pi\le 22/7\). fileciteturn0file0

---

## 1) (1) Stieltjes N=1 identity: как получить и как обосновать дифференцирование под интегралом

### 1.1. Стартовая формула (Johansson Eq 21+23)
Johansson даёт (Stirling для \(\log\Gamma\) с остатком)
\[
\log\Gamma(z)
=
\Bigl(z-\frac12\Bigr)\log z - z + \frac12\log(2\pi)
+ \sum_{n=1}^{N-1}T_n(z)+R_N(z),
\]
и интегральный остаток
\[
R_N(z)=\int_0^\infty \frac{B_{2N}-B_{2N}(\{x\})}{2N\,(x+z)^{2N}}\,dx,
\]
для \(z\notin(-\infty,0]\). На вашей области \(\Re z>0\) это выполнено автоматически. fileciteturn0file1

Берём \(N=1\). Тогда \(\sum_{n=1}^{0}\) пуста, и
\[
R_1(z)=\int_0^\infty \frac{B_2-B_2(\{x\})}{2(x+z)^2}\,dx.
\]

### 1.2. Дифференцирование по \(z\)
Дифференцируем:
- \((d/dz)\log\Gamma(z)=\psi(z)\) (это стандартное).
- \((d/dz)((z-\tfrac12)\log z - z)=\log z-\frac{1}{2z}\).

Осталось: \(R_1'(z)\). Введи
\[
f(x,z):=\frac{B_2-B_2(\{x\})}{2(x+z)^2}.
\]
Тогда
\[
\partial_z f(x,z)=\frac{B_2-B_2(\{x\})}{2}\cdot(-2)(x+z)^{-3}
=-(B_2-B_2(\{x\}))(x+z)^{-3}.
\]
Формально это даёт
\[
R_1'(z)=\int_0^\infty \partial_z f(x,z)\,dx
=-\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx,
\]
и значит
\[
\psi(z)=\log z-\frac{1}{2z}+R_1'(z),
\]
то есть ровно целевое тождество.

### 1.3. Доминирование для “d/dz под интегралом” (ключевой сертификат)
Фиксируй \(z_0\) с \(\sigma_0:=\Re z_0>0\). Выбери окрестность \(U\) такая, что \(\Re z\ge \sigma_0/2\) для всех \(z\in U\).

Тогда для \(x\ge 0\), \(z\in U\):
- **Bernoulli‑gap**:  
  \[
  0\le B_2-B_2(\{x\}) = \{x\}(1-\{x\})\le \frac14.
  \]
  (Это у тебя уже доказано как `bernoulli2Diff_bounds`.) fileciteturn0file0
- **нижняя оценка знаменателя**:  
  \(|x+z|\ge x+\Re z\ge x+\sigma_0/2\).

Значит
\[
|\partial_z f(x,z)|
\le \frac{1/4}{|x+z|^3}
\le \frac{1/4}{(x+\sigma_0/2)^3}.
\]
А функция \(x\mapsto (x+\sigma_0/2)^{-3}\) интегрируема на \([0,\infty)\). Это и есть “tight” доминирующая оценка, которую просишь: она одновременно обеспечивает
- integrable majorant,
- локальную (по \(z\)) равномерность доминирования,
- и тем самым позволяет применить стандартную лемму “derivative under integral sign” (в Lean: вариант `integral_hasDerivAt_of_dominated_locally` / `hasDerivAt_integral_of_dominated` — точное имя зависит от вашего Mathlib, но по сути это ровно этот шаблон).

---

## 2) (2) Bound для \(E(z)\) и real‑part remainder bound без arg/sec фактора

Определи
\[
E(z):=\psi(z)-\log z+\frac{1}{2z}.
\]

Из тождества выше:
\[
E(z)= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

### 2.1. Абсолютная оценка
\[
|E(z)|
\le \int_0^\infty \frac{|B_2-B_2(\{x\})|}{|x+z|^3}\,dx
\le \frac14\int_0^\infty |x+z|^{-3}\,dx.
\]
Это ровно пункт (2) из запроса. fileciteturn0file0

### 2.2. Привязка к kernel integral
Пусть \(z=\sigma+i\tau\), \(\sigma>0\). Тогда
\[
|x+z|^2=(x+\sigma)^2+\tau^2
\quad\Rightarrow\quad
|x+z|^{-3}=\big((x+\sigma)^2+\tau^2\big)^{-3/2}.
\]
По kernel‑лемме (которую вы уже закрыли) имеем
\[
\int_0^\infty |x+z|^{-3}\,dx
=
\frac{1}{|z|(|z|+\sigma)}
\le \frac{1}{|z|^2}.
\]
Значит
\[
\boxed{|E(z)|\le \frac{1}{4|z|^2}.}
\]

### 2.3. Переход к формату вашего аксиома `re_digamma_remainder_bound_stieltjes`
Берём действительные части:

- На \(\Re z>0\) для главной ветви \(\log\): \(\Re(\log z)=\log|z|=\log\|z\|\).
- \(\Re\!\left(\frac{1}{2z}\right)=\frac{\Re z}{2|z|^2}=\frac{z.re}{2\|z\|^2}\).
- Тогда
\[
\Re E(z)=\Re\psi(z)-\log\|z\|+\frac{\Re z}{2\|z\|^2}.
\]
- И наконец
\[
\Big|\Re\psi(z)-\log\|z\|+\frac{\Re z}{2\|z\|^2}\Big|
=|\Re E(z)|\le |E(z)|\le \frac{1}{4\|z\|^2}.
\]

Это именно то, что просится заменить вместо аксиомы `re_digamma_remainder_bound_stieltjes`. fileciteturn0file0

---

## 3) (3) Tail на линии \(z=\frac14+i\pi\xi\), \(\xi\ge\frac52\)

Пусть \(z=\frac14+i\pi\xi\). Тогда \(\Re z=\frac14\), \(\|z\|^2=\frac1{16}+\pi^2\xi^2\).

### 3.1. Из remainder bound к \(|\Re\psi(z)|\)
Из равенства
\[
\Re\psi(z)=\log\|z\|-\frac{\Re z}{2\|z\|^2}+\Re E(z)
\]
и треугольника:
\[
|\Re\psi(z)|
\le \log\|z\|+\frac{\Re z}{2\|z\|^2}+|\Re E(z)|
\le \log\|z\|+\frac{1}{8\|z\|^2}+\frac{1}{4\|z\|^2}
=\log\|z\|+\frac{3}{8\|z\|^2}.
\]

### 3.2. Маленький хвост \(3/(8\|z\|^2)\le 1/150\)
При \(\xi\ge 5/2\) и \(\pi\ge 3\):
\[
\|z\|^2\ge \pi^2\xi^2\ge 9\cdot\frac{25}{4}=\frac{225}{4}
\quad\Rightarrow\quad
\frac{3}{8\|z\|^2}\le \frac{3}{8\cdot(225/4)}=\frac{1}{150}.
\]

### 3.3. Самый лёгкий Lean‑путь к \(\log\|z\|\le \log(1+\xi^2)+\frac{1}{11}\)
Вместо тяжёлого полинома “\(12/11\)”, можно сделать так:

1) Разложение:
\[
\|z\|
=\sqrt{\pi^2\xi^2+\frac1{16}}
=\pi\xi\sqrt{1+\frac{1}{16\pi^2\xi^2}}.
\]
Значит
\[
\log\|z\|
=\log(\pi\xi)+\frac12\log\Bigl(1+\frac{1}{16\pi^2\xi^2}\Bigr).
\]

2) Для \(\xi\ge 5/2\), \(\pi\ge 3\):
\[
u:=\frac{1}{16\pi^2\xi^2}\le \frac{1}{16\cdot 9\cdot (25/4)}=\frac{1}{900}.
\]
И \(\log(1+u)\le u\), значит
\[
\frac12\log(1+u)\le \frac{u}{2}\le \frac{1}{1800}.
\]

3) Оценка \(\log(\pi\xi)\) через \(\log(1+\xi^2)\) (это чистая алгебра + \(\pi\le 22/7\)):
- Для \(\xi\ge 5/2\) верно
\[
\frac{\xi}{1+\xi^2}\le \frac{5/2}{1+(5/2)^2}=\frac{10}{29}.
\]
(доказывается умножением крест‑накрест; в Lean это обычно 3 строки `field_simp` + `nlinarith`.)
- Тогда
\[
\frac{\pi\xi}{1+\xi^2}\le \frac{22}{7}\cdot\frac{10}{29}=\frac{220}{203}=1+\frac{17}{203}.
\]
- Следовательно
\[
\log(\pi\xi)=\log(1+\xi^2)+\log\Big(\frac{\pi\xi}{1+\xi^2}\Big)
\le \log(1+\xi^2)+\log\Big(1+\frac{17}{203}\Big)
\le \log(1+\xi^2)+\frac{17}{203},
\]
используя \(\log(1+t)\le t\).

4) Собираем:
\[
\log\|z\|\le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800}.
\]
И чисто рационально:
\[
\frac{17}{203}+\frac{1}{1800}\le \frac{1}{11}.
\]
(проверка: \(11(17\cdot1800+203)\le 203\cdot1800\) — `nlinarith`.)

Итого:
\[
\boxed{\log\|z\|\le \log(1+\xi^2)+\frac{1}{11}.}
\]

### 3.4. Финал: \(|\Re\psi(z)|\le \log(1+\xi^2)+1/10\)
\[
|\Re\psi(z)|\le \log\|z\|+\frac{1}{150}
\le \log(1+\xi^2)+\frac{1}{11}+\frac{1}{150}
<\log(1+\xi^2)+\frac{1}{10}.
\]
(последнее: \(\frac{1}{11}+\frac{1}{150}=\frac{161}{1650}<\frac{1}{10}\).)

---

## Что “можно ослабить” ради ещё более простой формализации

Если вдруг где-то упираешься в арифметику для `1/11`, то самый дешёвый вариант — **вообще не доказывать `+1/11`**, а доказывать сразу
\[
\log\|z\|\le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800}
\]
и дальше показать
\[
\frac{17}{203}+\frac{1}{1800}+\frac{1}{150}\le \frac{1}{10}.
\]
Это одна рациональная проверка (всё на одном `nlinarith` после `norm_num`), и она легче, чем промежуточный `1/11`.  

Но если тебе важно сохранить именно лемму с `1/11` (как в запросе), то выше я показал, как получить её **без** тяжёлого полинома.

---

Если хочешь, я могу предложить точные “лейммы‑кирпичи” в стиле вашего `Q3/DigammaRemainder.lean` (как назвать `E`, как оформить `complexIntegral` и где лучше брать `abs_re_le_norm`) — но по математике и цепочке констант это уже полный сертификат для замены `re_digamma_remainder_bound_stieltjes`.

## ASSISTANT
Ок, беру задачу «внутри файла» и фиксирую **сертификат** для замены `re_digamma_remainder_bound_stieltjes` через Stieltjes \(N=1\) + ваш уже закрытый `integral_kernel_eq` + `bernoulli2Diff_bounds`. fileciteturn0file0 fileciteturn0file2

Ниже: (1) sanity‑check тождества + доминирование для дифф‑под‑интегралом, (2) цепочка к bound \(1/(4\|z\|^2)\), (3) компактный tail \(\log(1+\xi^2)+1/10\) при \(\xi\ge 5/2\), без DLMF и без `arg/sec`.

---

## 0. Теорема и статус

### 0.1 Теорема A (Stieltjes \(N=1\) для дигаммы)
**Формулировка.** Для всех \(z\in\mathbb C\) с \(\Re z>0\),
\[
\psi(z)-\log z+\frac{1}{2z}
\;=\;
-\int_{0}^{\infty}\frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx,
\]
где \(B_2(t)=t^2-t+\tfrac16\), \(\{x\}=\mathrm{fract}(x)\in[0,1)\).

**Статус.** Это прямое следствие Johansson (Maple Trans. 2023) Eq. (21)+(23) (остаток Стилтьеса для \(\log\Gamma\)), при \(N=1\), после дифференцирования по \(z\). fileciteturn0file2

---

## 1) Sanity‑check тождества и “tight” дифференцирование под интегралом

### 1.1 Откуда берётся ровно ваш интеграл
Johansson даёт:
- (21) разложение \(\log\Gamma(z)\) с остатком \(R_N(z)\),
- (23) интегральную формулу остатка:
\[
R_N(z)=\int_0^\infty \frac{B_{2N}-B_{2N}(\{x\})}{2N(x+z)^{2N}}\,dx.
\]
Специализация \(N=1\):
\[
R_1(z)=\int_0^\infty \frac{B_2-B_2(\{x\})}{2(x+z)^2}\,dx.
\]
Дифференцируя (21) по \(z\):
\[
\psi(z)=\frac{d}{dz}\log\Gamma(z)=\log z-\frac{1}{2z}+R_1'(z),
\]
и дифференцируя под интегралом:
\[
R_1'(z)=\int_0^\infty \frac{d}{dz}\Big(\frac{B_2-B_2(\{x\})}{2(x+z)^2}\Big)\,dx
= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]
Переносим влево — получаем точь‑в‑точь вашу формулу. fileciteturn0file2

### 1.2 Доминирование для `differentiate under integral` (самый чистый majorant)
Фиксируй \(z_0\) с \(\sigma_0=\Re z_0>0\). Возьми окрестность \(U\) так, что \(\Re z\ge \sigma_0/2\) для \(z\in U\).

Положим
\[
f(x,z):=\frac{B_2-B_2(\{x\})}{2(x+z)^2}.
\]
Тогда
\[
\partial_z f(x,z)=-(B_2-B_2(\{x\}))(x+z)^{-3}.
\]

1) У тебя уже есть ключевой bound
\[
0\le B_2-B_2(\{x\})\le \tfrac14
\]
(это `bernoulli2Diff_bounds`). fileciteturn0file0

2) Для \(x\ge0\), \(z\in U\): \(|x+z|\ge x+\Re z\ge x+\sigma_0/2\). Тогда
\[
|\partial_z f(x,z)|
\le \frac{1/4}{|x+z|^3}
\le \frac{1/4}{(x+\sigma_0/2)^3}.
\]

3) \(\int_0^\infty (x+\sigma_0/2)^{-3}dx<\infty\). Более того, это **ровно ваш kernel‑интеграл** при \(\tau=0\), так что интегрируемость/конечность можно оформить через уже имеющуюся “kernel” лемму (или прямым вычислением \(=1/(2(\sigma_0/2)^2)\)).

Итого: у тебя есть **локально‑равномерный интегрируемый majorant**, что идеально подходит под стандартную лемму Mathlib вида “`hasDerivAt_integral_of_dominated` / `integral_hasDerivAt_of_dominated_locally`” (имя зависит от версии, но гипотезы ровно такие: `ae_stronglyMeasurable`, `∀ z∈U, …`, и общий интегрируемый доминатор).

---

## 2) Реал‑part remainder bound без `arg/sec`: как собрать в Lean

### 2.1 Введи \(E(z)\)
\[
E(z):=\psi(z)-\log z+\frac{1}{2z}.
\]
По Теореме A:
\[
E(z)= -\int_0^\infty \frac{B_2-B_2(\{x\})}{(x+z)^3}\,dx.
\]

### 2.2 Оценка нормы интеграла → интеграл нормы
Используй стандартную лемму:
- **для \(\mathbb C\)-интеграла**: `norm_integral_le_integral_norm`
- или для \(\mathbb R\): `abs_integral_le_integral_abs`.

Тогда
\[
|E(z)| \le \int_0^\infty \frac{|B_2-B_2(\{x\})|}{|x+z|^3}\,dx
\le \frac14\int_0^\infty |x+z|^{-3}\,dx,
\]
где второй шаг — `bernoulli2Diff_bounds` + монотонность интеграла по `≤` для неотрицательных функций.

Это ровно пункт (2) из файла. fileciteturn0file0

### 2.3 Привязка \(\int |x+z|^{-3}\) к вашему kernel‑интегралу
Пусть \(z=\sigma+i\tau\). Тогда
\[
|x+z|^2=(x+\sigma)^2+\tau^2
\quad\Rightarrow\quad
|x+z|^{-3}=\big((x+\sigma)^2+\tau^2\big)^{-3/2}.
\]
Значит
\[
\int_0^\infty |x+z|^{-3}\,dx
=
\int_0^\infty \big((x+\sigma)^2+\tau^2\big)^{-3/2}dx
\le \frac{1}{\sigma^2+\tau^2}.
\]
Последнее — ваш `integral_kernel_bound` (полученный из `integral_kernel_eq`). fileciteturn0file2

Итак:
\[
|E(z)|\le \frac14\cdot \frac{1}{\sigma^2+\tau^2}
= \frac{1}{4|z|^2}
= \frac{1}{4\|z\|^2}.
\]

### 2.4 Переход к нужной форме `re_digamma_remainder_bound_stieltjes`
Дальше чистая алгебра на `re`:

1) \(|\Re E(z)|\le |E(z)|\). В Lean обычно это `abs_re_le_abs` (иногда `abs_re_le_norm`).

2) Разложи \(\Re E(z)\):
\[
\Re E(z)=\Re\psi(z)-\Re(\log z)+\Re\Big(\frac{1}{2z}\Big).
\]

3) **Леммы‑переписывания, которые тебе нужны (кандидаты имён):**
- \(\Re(\log z)=\log\|z\|\): в Mathlib обычно `Complex.log_re` или `Complex.re_log`  
  (часто формулировка: `(Complex.log z).re = Real.log ‖z‖`).
- \(\Re(z^{-1}) = z.re/\|z\|^2\): обычно `Complex.inv_re` или `Complex.re_inv`.  
  Фоллбек без имени: через `Complex.inv_def : z⁻¹ = conj z / (Complex.normSq z)` и `Complex.normSq = ‖z‖^2`, тогда `re (conj z)=re z`.

После этого у тебя ровно:
\[
\big|\Re\psi(z)-\log\|z\|+\frac{z.re}{2\|z\|^2}\big|
=|\Re E(z)|
\le \frac{1}{4\|z\|^2},
\]
т.е. можно заменить ваш аксиом `re_digamma_remainder_bound_stieltjes` доказательством.

---

## 3) Tail на линии \(z=\tfrac14+i\pi\xi\) (\(\xi\ge 5/2\)) с вашими константами

Тут вообще не нужен `arg/sec`: только остаток \(1/(4\|z\|^2)\), \(\pi\ge3\), \(\pi\le 22/7\), \(\log(1+t)\le t\). fileciteturn0file0

### 3.1 Сначала оцениваем \(|\Re\psi(z)|\) через \(\log\|z\|\)
Из
\[
\Re\psi(z)=\log\|z\|-\frac{z.re}{2\|z\|^2}+\Re E(z)
\]
получаем
\[
|\Re\psi(z)|
\le \log\|z\|+\frac{z.re}{2\|z\|^2}+|\Re E(z)|
\le \log\|z\|+\frac{1}{8\|z\|^2}+\frac{1}{4\|z\|^2}
=\log\|z\|+\frac{3}{8\|z\|^2}.
\]

Для \(z=\tfrac14+i\pi\xi\):
\(\|z\|^2=\tfrac1{16}+\pi^2\xi^2 \ge \pi^2\xi^2\).
Если \(\xi\ge 5/2\) и \(\pi\ge 3\),
\[
\frac{3}{8\|z\|^2}
\le \frac{3}{8\pi^2\xi^2}
\le \frac{3}{8\cdot 9\cdot 25/4}
=\frac{1}{150}.
\]

Итого:
\[
|\Re\psi(z)|\le \log\|z\|+\frac{1}{150}.
\]

### 3.2 Лёгкий log‑bound без тяжёлого полинома (даёт даже сильнее, чем +1/11)
Разложение:
\[
\|z\|^2=\pi^2\xi^2+\frac1{16}
=\pi^2\xi^2\Big(1+\frac{1}{16\pi^2\xi^2}\Big),
\]
\[
\log\|z\|=\log(\pi\xi)+\frac12\log\Big(1+\frac{1}{16\pi^2\xi^2}\Big)
\le \log(\pi\xi)+\frac{1}{32\pi^2\xi^2}.
\]
При \(\xi\ge 5/2\), \(\pi\ge 3\):
\[
\frac{1}{32\pi^2\xi^2}\le \frac{1}{32\cdot 9 \cdot 25/4}=\frac{1}{1800}.
\]

Дальше сравниваем \(\log(\pi\xi)\) с \(\log(1+\xi^2)\):
\[
\log(\pi\xi)=\log(1+\xi^2)+\log\Big(\frac{\pi\xi}{1+\xi^2}\Big).
\]
Для \(\xi\ge 5/2\) докажи (алгеброй) \(\xi/(1+\xi^2)\le 10/29\). Тогда при \(\pi\le 22/7\):
\[
\frac{\pi\xi}{1+\xi^2}\le \frac{22}{7}\cdot\frac{10}{29}=\frac{220}{203}=1+\frac{17}{203},
\]
и
\[
\log\Big(\frac{\pi\xi}{1+\xi^2}\Big)\le \log\Big(1+\frac{17}{203}\Big)\le \frac{17}{203}.
\]

Итак:
\[
\log\|z\|\le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800}.
\]

Теперь можно либо:
- (а) показать \(\frac{17}{203}+\frac{1}{1800}\le \frac{1}{11}\) (это чистая рациональная проверка), и получить ровно ваш промежуточный `+1/11`;  
либо
- (б) **вообще не вводить `1/11`**, а сразу сложить константы в финале (в Lean это проще: один `nlinarith` на рационалах).

### 3.3 Финал
\[
|\Re\psi(z)|\le \log\|z\|+\frac{1}{150}
\le \log(1+\xi^2)+\Big(\frac{17}{203}+\frac{1}{1800}+\frac{1}{150}\Big)
< \log(1+\xi^2)+\frac{1}{10}.
\]
(Последнее — снова рациональная проверка.)

---

## Самая “чистая” замена констант (если хочешь упростить Lean)
Если `+1/11` где-то мешает, самое лёгкое: **не доказывать** `log‖z‖ ≤ log(1+ξ^2)+1/11`, а держать ровно
\[
\log\|z\|\le \log(1+\xi^2)+\frac{17}{203}+\frac{1}{1800},
\]
и в конце доказывать
\[
\frac{17}{203}+\frac{1}{1800}+\frac{1}{150}\le \frac{1}{10}.
\]
Это обычно проще для `linarith`/`nlinarith`, чем промежуточная “красивая” константа.

---

Если ты пришлёшь (копипастом) **точные имена** используемых у вас определений `Q3.digamma` и как именно ты уже записал Stieltjes‑тождество в Lean (функция `E(z)` и integrand), я могу дать “почти готовую” Lean‑склейку в стиле вашего файла (с `by`‑блоками и `simp`‑линиями), но математический сертификат выше — полностью закрывает пункты 1–3 из `PROSHKA_REQUEST_4`. fileciteturn0file0

## ASSISTANT
Ок, давай «сертификат» именно для *убийства* `axiom digamma_stieltjes_identity` через Stieltjes N=1 + дифференцирование под интегралом. Я дам:

- точную матем. цепочку;
- какие леммы в mathlib реально есть (важные: `Complex.log_re`, `Complex.inv_re`, и главный инструмент — `hasDerivAt_integral_of_dominated_loc_of_deriv_le`);
- Lean‑friendly скелет с тем, **какой `bound` взять**, чтобы `hasDerivAt_integral...` сработал без боли (и без твоего kernel‑интеграла — он нужен дальше, но не для swapping derivative/integral).

---

## 0. Теорема: Stieltjes N=1 identity for digamma — Статус

**Точная формулировка:**  
\[
\forall z\in\mathbb C,\ \Re z>0:\quad 
\psi(z)-\log z+\frac1{2z}
= -\int_0^\infty \frac{B_2-\;B_2(\{x\})}{(x+z)^3}\,dx,
\]
где \(B_2(t)=t^2-t+\tfrac16\), \(\{x\}\in[0,1)\) — дробная часть, интеграл — по \(x\in(0,\infty)\).

**Статус:** стандартная аналитика (Euler–Maclaurin/Stieltjes remainder). В Lean‑проекте ты хочешь получить это как следствие от формулы для \(\log\Gamma\) при \(N=1\) (Johansson eq (21)+(23) / Stieltjes remainder) + дифференцирование под интегралом.

---

## 1. Формально (Lean target)

То, что у тебя сейчас как аксиома:

```lean
axiom digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
  Q3.digamma z - Complex.log z + (1 / (2 : ℂ)) * z⁻¹ =
    -∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3
```

Здесь `bernoulli2Diff x = 1/6 - B2(fract x)` (или эквивалентно `fract x*(1-fract x)`).

---

## 2. Определения и нотация

- `bernoulli2Diff : ℝ → ℝ` уже у тебя (и `0 ≤ ... ≤ 1/4` доказано).
- Интеграл: `∫ x in Set.Ioi (0:ℝ), ...` = `MeasureTheory.integral` по `volume` restricted.
- `Q3.digamma` — твоя `ψ`.
- `Complex.log` — главная ветвь (в mathlib есть стандартная).

---

## 3. Зависимости

### (A) Внешняя формула на logGamma (Stieltjes remainder, N=1)
Тебе нужна **одна** «база» (не про digamma, а про logGamma):

\[
\log\Gamma(z) \;=\; \Big(z-\tfrac12\Big)\log z \;-\;z\;+\;\tfrac12\log(2\pi)\;+\;
\int_0^\infty \frac{B_2-\;B_2(\{x\})}{2(x+z)^2}\,dx,\qquad \Re z>0.
\]

Назови её в Lean, например:

```lean
theorem logGamma_stieltjes_N1 (z : ℂ) (hz : 0 < z.re) :
  Complex.logGamma z - ((z - (1/2:ℂ)) * Complex.log z - z + (1/2:ℂ) * Complex.log (2*Real.pi)) =
    ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (2 * (x+z)^2) := ...
```

Это ровно тот «Johansson eq (21)+(23), N=1». Если это у тебя уже есть (как лемма/аксиома) — отлично. Если нет, то *именно это* становится новым “single axiom”, но ты хотя бы убираешь digamma‑аксиому и переносишь доверие на logGamma‑уровень (обычно проще согласиться).

### (B) Digamma как производная logGamma
Нужно что-то типа:
```lean
-- либо definitional, либо lemma:
Q3.digamma z = deriv Complex.logGamma z
```
или `HasDerivAt (fun z => Complex.logGamma z) (Q3.digamma z) z` на домене где Γ не имеет полюсов.

### (C) Дифференцирование под интегралом (в mathlib!)
Вот главный инструмент:

`Mathlib.Analysis.Calculus.ParametricIntegral` содержит лемму  
`hasDerivAt_integral_of_dominated_loc_of_deriv_le`. citeturn24view0

Это то, чем ты легально меняешь `deriv` и `∫`.

### (D) Реальная часть log / inverse — готовые леммы
Тебе они нужны для конечного `Re`‑bound, но раз ты просишь “Lean-friendly names”:

- `Complex.log_re` : \((\log z).re = \log ‖z‖\) (обычно при `z ≠ 0`). citeturn0search8  
- `Complex.inv_re` : \((z⁻¹).re = z.re / Complex.normSq z\). citeturn0search4

Дальше `Complex.normSq` ↔ `‖z‖^2` обычно через `by simpa [Complex.abs, Complex.normSq]`/`simp`‑леммы (`Complex.normSq_eq_norm_sq` часто есть).

---

## 4. План доказательства (Roadmap)

1) Стартуй от `logGamma_stieltjes_N1 z hz`.  
2) Возьми `deriv` обеих частей по `z`.  
3) На правой части применяй `hasDerivAt_integral_of_dominated_loc_of_deriv_le` (или похожую) к
   \[
   F(z,x) := \frac{bernoulli2Diff(x)}{2(x+z)^2}.
   \]
   Тогда `deriv_z F = -(bernoulli2Diff x)/(x+z)^3`.
4) На левой части: `deriv logGamma = digamma`, и вычисли производную элементарных выражений.
5) Перенеси всё, получишь ровно целевую формулу.

---

## 5. Ключевая лемма: swapping derivative and integral

### 5.1. Формулировка (то, что реально надо)

Пусть `z0` с `0 < z0.re`. Определи
\[
F(z,x) = \frac{b(x)}{2(x+z)^2},\quad b(x)=bernoulli2Diff(x)\in[0,1/4].
\]
Тогда:
\[
\frac{d}{dz}\int_0^\infty F(z,x)\,dx
= \int_0^\infty \frac{\partial}{\partial z}F(z,x)\,dx
= -\int_0^\infty \frac{b(x)}{(x+z)^3}\,dx.
\]

### 5.2. Почему это Lean-friendly: выбор `bound(x)`

Самый важный ход: для swapping *не нужен* твой точный kernel‑интеграл. Достаточно дать грубую, но интегрируемую доминацию.

Возьми `ε := z0.re / 2` (положительное). Рассмотри окрестность
\[
s := \{z : \mathbb C \mid \Re z \ge ε\}.
\]
Это множество — neighbourhood `z0` (через непрерывность `re`).

Тогда для любого `z ∈ s` и любого `x>0`:
\[
|x+z| \ge \Re(x+z) = x+\Re z \ge x+ε.
\]
Следовательно
\[
\left|\frac{\partial}{\partial z}F(z,x)\right|
= \left|\frac{b(x)}{(x+z)^3}\right|
\le \frac{1/4}{|x+z|^3}
\le \frac{1/4}{(x+ε)^3}.
\]
И функция \((1/4)/(x+ε)^3\) интегрируема на \(x\in(0,\infty)\) (интеграл равен \(1/(8ε^2)\), но величина неважна — важна интегрируемость).

Эта доминация **не зависит от Im(z)** и не требует `τ`‑разбивки.

### 5.3. Lean‑скелет (идея кода)

Ниже — не “готовый компилируемый файл” (я не могу прогнать Lean здесь), но структура соответствует `ParametricIntegral`‑лемме.

```lean
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.MeasureTheory.Integral.Bochner
-- + твои импорты

open scoped Topology Real
open Filter MeasureTheory

namespace Q3

-- shorthand
def F (z : ℂ) (x : ℝ) : ℂ :=
  (bernoulli2Diff x : ℂ) / (2 * (x + z)^2)

def F' (z : ℂ) (x : ℝ) : ℂ :=
  -(bernoulli2Diff x : ℂ) / (x + z)^3

-- 1) pointwise derivative in z
lemma hasDerivAt_F (z : ℂ) (x : ℝ) (hx : x ≠ 0 := by trivial) :
  HasDerivAt (fun z => F z x) (F' z x) z := by
  -- routine: derivative of (x+z)^(-2)
  -- use simp [F, F', div_eq_mul_inv, pow_succ] + `hasDerivAt` lemmas:
  -- `HasDerivAt.const_mul` etc.
  -- key: deriv (fun z => (x+z)^(-2)) = -2*(x+z)^(-3)
  -- times 1/2 gives -(x+z)^(-3)
  sorry

-- 2) choose neighborhood s = {z | ε ≤ z.re}
lemma nhdsSet_re_ge (z0 : ℂ) (h : 0 < z0.re) :
  {z : ℂ | (z0.re / 2) ≤ z.re} ∈ 𝓝 z0 := by
  -- use continuity of Complex.re: `continuous_re` or `continuousAt_re`
  -- `isOpen_lt` on (fun z => z.re) ?
  sorry

-- 3) dominated derivative bound
lemma norm_F'_le_bound (z0 : ℂ) (h : 0 < z0.re) :
  ∀ᵐ x : ℝ ∂(volume.restrict (Set.Ioi (0:ℝ))),
    ∀ z : ℂ, (z0.re/2 ≤ z.re) →
      ‖F' z x‖ ≤ ( (1/4:ℝ) / (x + z0.re/2)^3 ) := by
  -- use bernoulli2Diff_bounds: ‖b‖ ≤ 1/4
  -- and |x+z| ≥ x + ε when Re z ≥ ε and x>0
  -- then 1/|x+z|^3 ≤ 1/(x+ε)^3
  sorry

-- 4) integrability of bound
lemma integrable_bound (z0 : ℂ) (h : 0 < z0.re) :
  Integrable (fun x : ℝ => ( (1/4:ℝ) / (x + z0.re/2)^3 ))
    (volume.restrict (Set.Ioi (0:ℝ))) := by
  -- standard: compare with integrable on Ioi (0) of (x+c)^(-3)
  -- use known integrability lemma: `integrableOn_Ioi_inv_pow`-style
  sorry

-- 5) now apply parametric integral derivative lemma
lemma hasDerivAt_integral_F (z0 : ℂ) (h : 0 < z0.re) :
  HasDerivAt
    (fun z => ∫ x in Set.Ioi (0:ℝ), F z x)
    (∫ x in Set.Ioi (0:ℝ), F' z0 x)
    z0 := by
  -- apply `hasDerivAt_integral_of_dominated_loc_of_deriv_le` (H=ℂ, α=ℝ)
  -- set s := {z | z0.re/2 ≤ z.re}
  -- provide:
  --  (i) s ∈ nhds z0  (from nhdsSet_re_ge)
  --  (ii) measurability of F z (aeStronglyMeasurable)
  --  (iii) integrable of F z0
  --  (iv) bound on derivative norm (norm_F'_le_bound)
  --  (v) integrable bound (integrable_bound)
  --  (vi) ∀ᵐ x, ∀ z ∈ s, HasDerivAt (fun z => F z x) (F' z x) z
  sorry

end Q3
```

**Сигнал/аномалия:** в swapping‑шаге чаще всего “ломается” не аналитика, а Lean‑мелочи: `AEStronglyMeasurable`, `Integrable` на `volume.restrict`, и типы `Set.Ioi`.  
Решение: работай на мере `μ := volume.restrict (Set.Ioi 0)` и используй `ae`‑формулировки `∀ᵐ x ∂μ`.

---

## 6. Основное доказательство digamma_stieltjes_identity (как собрать всё вместе)

Предположим, что есть `logGamma_stieltjes_N1`. Тогда:

1) Применяешь `deriv` к обеим сторонам `logGamma_stieltjes_N1`.  
2) Левую часть раскалываешь на сумму:
   - `deriv (logGamma)` → `digamma` (твоя лемма/определение).
   - `deriv ((z - 1/2) * log z)` = `log z + (z-1/2)* (1/z)`; потом −`deriv z` = −1; всё вместе даёт `log z - 1/(2z)` (обычная алгебра).  
   В Lean: делается через `by` + `simp` + стандартные `HasDerivAt.mul`, `HasDerivAt.log` и т.п.
3) Правую часть дифференцируешь через `hasDerivAt_integral_F` выше, получая
   `deriv (∫ F) = ∫ F' = -∫ (bernoulli2Diff)/(x+z)^3`.
4) Переносишь члены — получаешь ровно формулу для digamma.

---

## 7. Аудит — где реально тонко

### 7.1. Интегрируемость `F z0`
Для `F(z0,x) = b(x)/(2(x+z0)^2)` достаточно:
\[
|F(z0,x)| \le \frac{1/4}{2(x+ε)^2},
\]
а \(\int_0^\infty (x+ε)^{-2} dx < \infty\).  
Это тоже очень Lean‑friendly (простые степенные интегралы).

### 7.2. Условие `z ≠ 0` для `log`
Если где-то используешь `HasDerivAt.log`, оно требует `z ≠ 0`.  
На домене `Re z > 0` это автоматически: `z ≠ 0` из `z.re > 0`. В Lean обычно `by
  intro hz0; ...` и `simp [hz0]` не проходит, надо явно:
`have : z ≠ 0 := by
  intro hz; have : z.re = 0 := by simpa [hz] ; linarith`
(или `simp [hz]` + `linarith`).

### 7.3. Условие `x+z ≠ 0`
В производных `(x+z)⁻²`/`⁻³` нужно `x+z ≠ 0`.  
Для `x>0` и `Re z ≥ ε>0`: `Re(x+z)=x+Re z>0`, значит `x+z≠0`.  
Это ровно то, зачем мы берём `s := {Re z ≥ ε}`.

---

## 8. Что дальше (связь с твоим remainder bound)

После того как `digamma_stieltjes_identity` доказан, твой remainder‑bound:

\[
|E(z)| \le \frac{1}{4|z|^2},\qquad
E(z):=\psi(z)-\log z+\frac{1}{2z}
\]

получается уже твоей цепочкой:
- `0 ≤ bernoulli2Diff ≤ 1/4`;
- `|∫ f| ≤ ∫ |f|`;
- \(|x+z|^{-3}\) интеграл = kernel‑интеграл, который ты уже закрыл/почти закрыл.

И для реал‑части:
- `Complex.log_re` для `re (log z) = log ‖z‖` citeturn0search8
- `Complex.inv_re` чтобы переписать `re(z⁻¹)` через `z.re` и `‖z‖^2` citeturn30search4

---

Если ты хочешь, я могу прямо **под твой текущий стиль файла** предложить минимальный набор новых лемм с именами/параметрами так, чтобы они “встали” в `Q3/DigammaRemainder.lean` и `simp` начал работать (особенно вокруг `HasDerivAt` для `(x+z)^(-2)` и вокруг `Integrable` на `volume.restrict`).

## ASSISTANT
Ок, давай закроем именно те “Lean‑биты”, которые у тебя ломаются в `stieltjes_integral_deriv`. Ниже — максимально короткие, но “стабильные” цепочки лемм/сниппеты.

---

## 1) Какая лемма для swap deriv/integral и как она выглядит

Тебе нужна ровно

`hasDerivAt_integral_of_dominated_loc_of_deriv_le`

из `Mathlib/Analysis/Calculus/ParametricIntegral`.

Её сигнатура (важно: **возвращает пару** `Integrable … ∧ HasDerivAt …`) такая: citeturn17view0

```lean
theorem hasDerivAt_integral_of_dominated_loc_of_deriv_le
  {bound : α → ℝ} {F : 𝕜 → α → E} {x₀ : 𝕜} {s : Set 𝕜} (hs : s ∈ 𝓝 x₀)
  (hF_meas : ∀ᶠ x in 𝓝 x₀, AEStronglyMeasurable (F x) μ)
  (hF_int : Integrable (F x₀) μ)
  {F' : 𝕜 → α → E} (hF'_meas : AEStronglyMeasurable (F' x₀) μ)
  (h_bound : ∀ᵐ a ∂μ, ∀ x ∈ s, ‖F' x a‖ ≤ bound a)
  (bound_integrable : Integrable bound μ)
  (h_diff : ∀ᵐ a ∂μ, ∀ x ∈ s, HasDerivAt (fun x : 𝕜 => F x a) (F' x a) x) :
  Integrable (F' x₀) μ ∧
    HasDerivAt (fun n : 𝕜 => ∫ a, F n a ∂μ) (∫ a, F' x₀ a ∂μ) x₀
```

**Как использовать:**

```lean
have h :=
  hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := volume.restrict (Set.Ioi (0:ℝ))) hs hF_meas hF_int hF'_meas
    h_bound bound_integrable h_diff

have hF'Int : Integrable (F' z) (volume.restrict (Set.Ioi (0:ℝ))) := h.1
have hDeriv : HasDerivAt (fun w => ∫ x, F w x ∂(volume.restrict (Set.Ioi (0:ℝ))))
                          (∫ x, F' z x ∂(volume.restrict (Set.Ioi (0:ℝ)))) z := h.2
```

---

## 2) Самый короткий proof: `{w | ε ≤ w.re} ∈ 𝓝 z` (без `Metric.ball`)

Трюк: берёшь **открытую** половинуплоскость `{w | ε < w.re}`, она ∈ `𝓝 z`, потом расширяешь до `≤`.

```lean
lemma nhds_re_ge (z : ℂ) (ε : ℝ) (hε : ε < z.re) :
    {w : ℂ | ε ≤ w.re} ∈ 𝓝 z := by
  -- open half-plane
  have hopen : IsOpen {w : ℂ | ε < w.re} := by
    -- preimage of Ioi under continuous re
    simpa [Set.preimage, Set.setOf_app_iff] using
      (isOpen_Ioi.preimage (RCLike.continuous_re : Continuous fun w : ℂ => w.re))
  have hzmem : z ∈ {w : ℂ | ε < w.re} := by
    simpa [Set.mem_setOf_eq] using hε
  have hnhds : {w : ℂ | ε < w.re} ∈ 𝓝 z :=
    hopen.mem_nhds hzmem
  -- widen < to ≤
  exact Filter.mem_of_superset hnhds (by
    intro w hw; exact le_of_lt hw)
```

Замечание: `RCLike.continuous_re` точно есть (см. в `Mathlib.Analysis.RCLike.Basic`). citeturn18view0

Если ты хочешь именно `ε = z.re/2`, то `hε` делается чисто `nlinarith [hz]`.

---

## 3) “Минимальный компилируемый” паттерн для `Measurable (fun x => -(bernoulli2Diff x : ℂ))`

Самый простой и устойчивый путь:

- Сначала `Measurable bernoulli2Diff` (или у тебя уже есть `measurable_bernoulli2Diff`).
- Потом “поднять” в `ℂ` через `Complex.measurable_ofReal`.
- Потом `.neg`.

`Complex.measurable_ofReal : Measurable ofReal` есть в `MeasureTheory.Function.SpecialFunctions.Basic`. citeturn20view0

```lean
have hB : Measurable bernoulli2Diff := by
  -- если уже есть measurable_bernoulli2Diff, то просто:
  -- simpa using measurable_bernoulli2Diff
  measurability

have hC : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ)) := by
  -- coercion ℝ → ℂ is Complex.ofReal
  simpa using (Complex.measurable_ofReal.comp hB)

have hneg : Measurable (fun x : ℝ => -(bernoulli2Diff x : ℂ)) := by
  simpa using hC.neg
```

Если `measurability` вдруг не берёт `bernoulli2Diff` из-за `Int.fract`, импорт/лемма: `Int.measurable_fract` лежит в `Mathlib.MeasureTheory.Function.Floor` (но судя по твоему статусу, это уже заведено).

---

## 4) `abs_re_le_norm`: точное имя

Тебе надо:

```lean
have : |z.re| ≤ ‖z‖ := by simpa using (RCLike.abs_re_le_norm (z := z))
```

Лемма называется именно `RCLike.abs_re_le_norm`. citeturn18view0

---

## 5) Быстрые фиксы для двух твоих мелких несоответствий

### (a) `1/6` vs `6⁻¹`
Когда `simp` ругается на форму, просто нормализуй:

```lean
simp [one_div]   -- переводит 1/6 ↔ (6:ℝ)⁻¹
-- или:
have : (1/6 : ℝ) = (6 : ℝ)⁻¹ := by norm_num
```

В твоём `bernoulli2`/`bernoulli2Diff` уже стоит `(1/6:ℝ)`, так что чаще всего достаточно `simp [bernoulli2, bernoulli2Diff, one_div]`.

### (b) `1/(x+ε)^2` vs `((x+ε)^2)⁻¹`
Это почти всегда решается одной строкой:

```lean
simp [one_div, pow_two]
```

Если у тебя где-то `(x+ε)^(2:ℕ)` vs `((x+ε)^2)` (разные нотации), добавь `simp [pow_two]` / `simp [sq]` по месту.

---

## 6) Замена `pow_le_pow_of_le_left` для куба (если реально нужно)

Если ты в ℝ и у тебя `0 ≤ a` и `a ≤ b`, то можно вообще без спец‑лемм:

```lean
have hb0 : 0 ≤ b := le_trans ha0 hab
have h2 : a^2 ≤ b^2 := by
  -- a*a ≤ b*b
  simpa [pow_two] using (mul_le_mul hab hab ha0 hb0)
have h3 : a^3 ≤ b^3 := by
  -- a^3 = a^2 * a, b^3 = b^2 * b
  have : a^2 * a ≤ b^2 * b :=
    mul_le_mul h2 hab ha0 (by nlinarith [hb0])
  simpa [pow_succ, pow_two, mul_assoc] using this
```

---

## Микро‑совет по структуре `stieltjes_integral_deriv` (чтобы Lean перестал “душить”)

Вместо `Metric.ball z ε` везде:

- зафиксируй `ε := z.re/2`,
- возьми `s := {w : ℂ | ε ≤ w.re}`,
- получи `hs : s ∈ 𝓝 z` через лемму `nhds_re_ge` выше,
- дальше во всех `h_bound`/`h_diff` у тебя будет простой `hw : w ∈ s` ⇒ `ε ≤ w.re`, никаких `linarith` про расстояние.

Это резко упрощает оценку `‖(x+w)⁻³‖ ≤ (x+ε)⁻³` (ты уже это делаешь).

---

Если хочешь, кинь (сюда текстом) ровно кусок твоего `stieltjes_integral_deriv` proof с `have hs : ...` и местом, где строишь `h_bound` — я подгоню под твою текущую нотацию `F/F'` так, чтобы вставилось без рефакторинга.

## ASSISTANT
Я понял: у тебя **все гипотезы для `hasDerivAt_integral_of_dominated_loc_of_deriv_le` уже компилируются**, но сам вызов леммы вызывает **`timeout at whnf`** при проверке типов/унификации. Это типичная ситуация, когда Lean пытается слишком много раскрывать/нормализовать (особенно вокруг `∫ x in Set.Ioi 0, …` и `volume.restrict …`) прямо во время применения большой “parametric integral”‑леммы. fileciteturn0file0

Ниже — конкретные **“практики ускорения”**, которые обычно мгновенно снимают `whnf`‑взрыв.

---

## 1) Самый сильный фикс: **приведи цель к форме `∫ x, … ∂μ` и зафиксируй μ как локальную константу**

Почти всегда `whnf`‑взрыв происходит, когда Lean пытается сопоставить:

- твою цель вида `∫ x in Set.Ioi (0:ℝ), …`
- с формой в теореме `∫ a, F n a ∂μ`

и он начинает раскручивать “интеграл по множеству” как “интеграл по restricted measure”, а затем ещё `volume`, и так далее.

### Рекомендую переписать **внутри** леммы `stieltjes_integral_deriv`:

```lean
classical
let μ : Measure ℝ := volume.restrict (Set.Ioi (0:ℝ))
-- дальше везде использовать ∂μ

-- вместо: ∫ x in Set.Ioi (0:ℝ), ...
-- пиши: ∫ x, ... ∂μ
```

И в самом месте применения `hasDerivAt_integral...` сделай `change` до **точно** совпадающей формы:

```lean
-- было: HasDerivAt (fun w => ∫ x in Set.Ioi 0, F w x) ...
-- сделай:
change HasDerivAt (fun w => ∫ x, F w x ∂μ) (∫ x, F' z x ∂μ) z
```

Очень часто **одного этого** хватает: унификация становится тривиальной и `whnf` не взрывается.

---

## 2) Второй фикс: **не передавай F/F'/bound как огромные λ**, а вынеси в `def`/`abbrev`

Если ты пишешь прямо в вызове:

```lean
(F := fun z x => (bernoulli2Diff x : ℂ) / (2*(x+z)^2))
(F' := fun z x => -(bernoulli2Diff x : ℂ) / (x+z)^3)
(bound := fun x => (1/4:ℝ) / (x+ε)^3)
```

то Lean может пытаться `whnf`‑нормализовать эти лямбды при унификации (и это бывает дорого).

Лучше:

```lean
abbrev F  (z : ℂ) (x : ℝ) : ℂ := (bernoulli2Diff x : ℂ) / (2 * (x + z)^2)
abbrev F' (z : ℂ) (x : ℝ) : ℂ := -(bernoulli2Diff x : ℂ) / (x + z)^3
abbrev bound (ε : ℝ) (x : ℝ) : ℝ := (1/4 : ℝ) / (x + ε)^3
```

И потом в вызове:

```lean
have h := hasDerivAt_integral_of_dominated_loc_of_deriv_le
  (μ := μ) (F := F) (F' := F') (bound := bound ε) (x₀ := z) (s := s) hs
  hF_meas hF_int hF'_meas h_bound bound_integrable h_diff
exact h.2
```

**Почему быстрее:** унификация видит константы `F`, `F'`, `bound` вместо больших термов.

Если хочешь ещё сильнее, можно сделать `opaque F …` и отдельно иметь лемму `F_def : F z x = …` для ручного раскрытия в местах, где надо; но чаще хватает `abbrev`.

---

## 3) Третий фикс: **вынеси `h_bound` и `h_diff` наружу (как отдельные леммы), не держи их внутри одного гигантского `by`**

Да, это реально помогает компилятору: вместо одного огромного term‑graph, ты даёшь ссылку на уже типчекнутую лемму.

То есть:

```lean
lemma h_bound_lemma (z : ℂ) (hz : 0 < z.re) :
  ∀ᵐ x ∂μ, ∀ w ∈ s, ‖F' w x‖ ≤ bound ε x := ...

lemma h_diff_lemma (z : ℂ) (hz : 0 < z.re) :
  ∀ᵐ x ∂μ, ∀ w ∈ s, HasDerivAt (fun w => F w x) (F' w x) w := ...
```

А в `stieltjes_integral_deriv` просто:

```lean
have h :=
  hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := μ) (F := F) (F' := F') (bound := bound ε) (x₀ := z) (s := s) hs
    hF_meas hF_int hF'_meas
    (h_bound_lemma z hz) (bound_integrable_lemma z hz) (h_diff_lemma z hz)
exact h.2
```

Это часто снимает `whnf`‑таймаут именно потому, что Lean перестаёт пытаться нормализовать гигантский “всё‑в‑одном” proof term вокруг вызова.

---

## 4) Четвёртый фикс: **используй открытый half‑plane, а не `Metric.ball`**

Ты уже перешёл на half‑plane, но подчеркну: это важно и для скорости, и для `linarith`.

Берёшь:
```lean
let ε : ℝ := z.re / 2
let s : Set ℂ := {w : ℂ | ε < w.re}  -- именно <, чтобы s была IsOpen
have hs : s ∈ 𝓝 z := (isOpen_Ioi.preimage (RCLike.continuous_re)).mem_nhds ?_
```

Потом (в `h_bound`/`h_diff`) ты получаешь `ε < w.re` напрямую без метрик и без `linarith`‑акробатики.

---

## 5) Пятый фикс: **не `simp`‑и `F/F'` в самом вызове леммы**

Если у тебя есть `simp [F, F']` **внутри** аргументов к `hasDerivAt_integral...`, это часто и вызывает `whnf` blow‑up.

Правило:

- до вызова: никакого `simp` на больших выражениях;
- вызываем лемму “как есть”;
- **после** получения `HasDerivAt` делаем маленькие `simp` только на цели/результате (и лучше `simp_rw` точечно).

---

## 6) Если нужен “лёгкий аналог” леммы: попробуй версию без `loc` (если есть)

В некоторых версиях mathlib есть “глобальная” версия типа:

- `hasDerivAt_integral_of_dominated_of_deriv_le` (без `s ∈ 𝓝 x₀`, без `∀ x ∈ s`)

Если у тебя domination/дифференцируемость и так доказаны на **всем** half‑plane `Re w ≥ ε`, то эта версия может быть ощутимо проще для унификации.

Я не гарантирую имя в твоей ревизии, но стратегия такая:

- `#check hasDerivAt_integral_of_dominated_of_deriv_le`
- если есть — используешь её вместо `..._loc_...`

---

## 7) Мини‑шаблон “как обычно закрывают whnf при ParametricIntegral”

Вот “идеальный” вид леммы (по опыту):

```lean
lemma stieltjes_integral_deriv (z : ℂ) (hz : 0 < z.re) :
  HasDerivAt
    (fun w => ∫ x, F w x ∂μ)
    (∫ x, F' z x ∂μ)
    z := by
  classical
  let μ : Measure ℝ := volume.restrict (Set.Ioi (0:ℝ))
  let ε : ℝ := z.re / 2
  let s : Set ℂ := {w : ℂ | ε < w.re}
  have hs : s ∈ 𝓝 z := ...  -- коротко через isOpen + continuous_re

  -- все гипотезы леммы — отдельными have/леммами, без simp-взрывов:
  have hF_meas : ∀ᶠ w in 𝓝 z, AEStronglyMeasurable (fun x => F w x) μ := ...
  have hF_int  : Integrable (fun x => F z x) μ := ...
  have hF'_meas : AEStronglyMeasurable (fun x => F' z x) μ := ...
  have h_bound : ∀ᵐ x ∂μ, ∀ w ∈ s, ‖F' w x‖ ≤ bound ε x := ...
  have h_bound_int : Integrable (fun x => bound ε x) μ := ...
  have h_diff : ∀ᵐ x ∂μ, ∀ w ∈ s, HasDerivAt (fun w => F w x) (F' w x) w := ...

  exact (hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := μ) (bound := fun x => bound ε x) (F := fun w x => F w x) (F' := fun w x => F' w x)
    (x₀ := z) (s := s) hs
    hF_meas hF_int hF'_meas h_bound h_bound_int h_diff).2
```

Ключевое: **минимум редукции в момент вызова**.

---

## Если хочешь, самый быстрый “диагностический” шаг

Вставь перед вызовом:

```lean
set_option trace.type_context.is_def_eq true
```

и посмотри, *что именно* Lean пытается редуцировать до whnf (обычно это унификация `∫ x in Ioi 0` vs `∫ x, … ∂μ` или бета‑редукции огромных лямбд). Но часто даже не нужно — пункты 1–3 выше почти всегда лечат. fileciteturn0file0

## ASSISTANT
Сразу феномен (важный, не рутина): **при твоём текущем определении**
```lean
namespace Complex
def logGamma (z : ℂ) : ℂ := Complex.log (Complex.Gamma z)
end Complex
```
оба “закрывающих” аксиома в виде `∀ z, 0 < Re z, ...` **в общем виде неверны** — не потому, что “не хватает лемм”, а потому что `Complex.log` *не* голоморфна на ветвевом разрезе, и образ `Gamma` при `Re z > 0` **иногда попадает на отрицательную вещественную ось**. Тогда `Complex.log (Gamma z)` не непрерывна ⇒ не дифференцируема в этом `z`. В mathlib это отражено тем, что производная `Complex.log` дана только на `Complex.slitPlane`. citeturn1view0  
Это же ровно то, что пишут практические библиотеки: `loggamma(z)` может отличаться от `log(gamma(z))` на целое кратное `2π i` (разные ветви). citeturn13view0

Отсюда вывод: **заменить эти аксиомы на теоремы “без изменения остального кода” невозможно**, если оставить такое `logGamma := log ∘ Gamma` и оставить домен `Re z > 0` без доп. условий. Но есть два рабочих Lean‑friendly пути (оба конечные).

---

## Путь A (самый быстрый и локальный): исправить формулировку `logGamma_hasDerivAt` и не трогать остальное

### 0. Теорема: производная `log ∘ Gamma` при попадании в `slitPlane`
**Формулировка:**  
\[
\forall z,\ (0<\Re z)\land (\Gamma(z)\in\text{slitPlane})
\;\Rightarrow\;
\frac{d}{dz}\log(\Gamma z)=\frac{\Gamma'(z)}{\Gamma(z)}.
\]

### 1. Lean‑формулировка (почти 1:1)
```lean
import Mathlib.Analysis.SpecialFunctions.Gamma.Deriv
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv

namespace Q3

theorem logGamma_hasDerivAt_of_gamma_mem_slitPlane
    (z : ℂ) (hz : 0 < z.re) (hslit : Complex.Gamma z ∈ Complex.slitPlane) :
    HasDerivAt (fun w => Complex.log (Complex.Gamma w))
      (deriv Complex.Gamma z / Complex.Gamma z) z := by
  -- 1) Gamma differentiable
  have hdiff : DifferentiableAt ℂ Complex.Gamma z := by
    -- Gamma is differentiable away from negative integers; `hz` implies `z ≠ -m`.
    -- In mathlib: `Complex.differentiableAt_Gamma` takes a proof `∀ m : ℕ, z ≠ -m`.
    refine Complex.differentiableAt_Gamma z ?_
    intro m
    -- show contradiction from real parts: Re(-m) = -m ≤ 0 < Re(z)
    have : (z.re) = (- (m : ℂ)).re := by
      -- from `z = -m` (contradiction assumption) take real parts
      -- exact congrArg Complex.re ?h
      -- (fill with `simp` once you have `h : z = - (m:ℂ)`)
      sorry
    -- then `hz` contradicts `(- (m:ℂ)).re ≤ 0`
    -- (finish with `linarith` after `simp` gives `(- (m:ℂ)).re = -m`)
    sorry

  have hderiv : HasDerivAt Complex.Gamma (deriv Complex.Gamma z) z :=
    hdiff.hasDerivAt

  -- 2) chain rule for clog (log on slitPlane)
  -- lemma exists: `HasDerivAt.clog` in `Complex.LogDeriv` citeturn1view0
  simpa [Complex.logGamma, Q3.digamma] using (HasDerivAt.clog hderiv hslit)

end Q3
```

**Зависимости в mathlib:**
- `Complex.differentiableAt_Gamma` (из `Gamma.Deriv`) citeturn4view0  
- `HasDerivAt.clog` / логарифмическая производная для `log` (из `Complex.LogDeriv`) citeturn1view0  

### 2. Что делать дальше (чтобы получить нужную `digamma_stieltjes_identity`)
Если ты сейчас выводишь `digamma_stieltjes_identity` из `logGamma_stieltjes_N1` через дифференцирование, то **вместо** глобального `logGamma_hasDerivAt hz` просто применяешь новую лемму с `hslit` *локально на множестве*
\[
U := \{z : \Re z>0 \land \Gamma(z)\in\text{slitPlane}\}.
\]
Это `U` — открытое множество (по непрерывности `Gamma` и открытости `slitPlane`). На `U` дифференцирование корректно, и получается равенство для `digamma` на `U`.  
Далее можно добить “все `Re z>0`” так:
- левая и правая части `digamma_stieltjes_identity` — голоморфны на `{Re z>0}` (интеграл даёт голоморфность через вашу `stieltjes_integral_deriv`),
- равны на непустом открытом `U`,
- значит равны на всей связной области `{Re z>0}` (identity theorem).

**Это строго корректный ремонт** без изменения определения `logGamma`.  
Минус: тебе понадобится один “уникальность голоморфного продолжения”‑лемма (в mathlib это стандартный инструмент про совпадение на множестве с предельной точкой).

---

## Путь B (математически правильный и ещё чище): перестать звать `log ∘ Gamma` “logGamma”

Это концептуально то же, что в любой CAS: **логарифм гаммы — это не `log(Gamma z)` как principal log**, а отдельная голоморфная ветвь, выбранная так, что `exp(logGamma z)=Gamma z` и `logGamma` голоморфна на нужной области. Именно поэтому в численных библиотеках и говорится про расхождение на `2π i`. citeturn13view0  

Если в файле `Q3/DigammaRemainder.lean` у тебя `logGamma_stieltjes_N1` — это Johansson/Stieltjes формула для *аналитического* `logGamma` на `Re z>0`, то самый “Lean‑дружелюбный” ход:

1) **переопредели `Complex.logGamma`** не как `log ∘ Gamma`, а прямо как RHS Stieltjes‑формулы (она голоморфна на `Re z>0` из‑за голоморфности `log z` и твоего лемматического блока про дифференцирование интеграла). Тогда `logGamma_stieltjes_N1` станет `rfl`/`by simp`.

2) дальше доказывай `HasDerivAt logGamma (digamma z) z` не через `Complex.log` вообще, а через равенство:
\[
(\logGamma)'(z)=\frac{\Gamma'(z)}{\Gamma(z)}
\]
которое следует из факта `exp(logGamma z)=Gamma z`. Но это уже потребует показать `exp(RHS)=Gamma`, то есть связать RHS с Γ. Это нетривиально.

Поэтому, если цель только хвост/оценка ψ, **путь B обычно хуже по трудозатратам**, чем путь A + identity theorem.

---

## Про второй аксиом `logGamma_stieltjes_N1`
Честно: **в mathlib готового “Johansson eq (21)” для комплексного Γ я не нашёл**, а значит “просто заменить на короткий proof term” обычно не выйдет. Это означает:
- либо ты оставляешь `logGamma_stieltjes_N1` как внешний лемматический импорт из вашего PDF/препринта,
- либо ты действительно формализуешь Euler–Maclaurin/Stieltjes остаток для `log Γ` (это большой кусок анализа).

Если вам уже удалось уйти от DLMF remainder и вы сейчас реально живёте на “Stieltjes N=1 для ψ”, то **самый экономичный** способ “убить” `logGamma_stieltjes_N1` — вообще **не** доказывать его, а доказывать **сразу** `digamma_stieltjes_identity` (Johansson eq (23)) через частные суммы / Euler–Maclaurin для `1/(x+z)` (что вы уже почти делаете в `DigammaRemainder` по карте).  

---

## Мини‑бонус: почему “Gamma z ∈ slitPlane при Re z>0” не стоит пытаться доказывать
Твоё требование “построй helper lemma `Gamma z ∈ slitPlane` для `0<Re z`” из запроса — это ровно та ловушка.  
`Complex.log` дифференцируема на `slitPlane`, и это правильно отражено в mathlib; но Γ не сохраняет `slitPlane` от полуплоскости.

---

## Что я бы сделал, чтобы закрыть всё быстро
1) **Переписать `logGamma_hasDerivAt` → версия с `hslit : Gamma z ∈ slitPlane`**, доказать 5–10 строками через `HasDerivAt.clog` + `Complex.differentiableAt_Gamma`. citeturn1view0turn4view0  
2) `digamma_stieltjes_identity`: получить на `U` и затем добить на весь `{Re z>0}` через identity theorem (это “чистый” комплексный анализ, без чисел).
3) Оставить `logGamma_stieltjes_N1` только как промежуточный шаг, если он реально нужен; но если уже есть план напрямую на ψ‑identity, то лучше выкинуть logGamma вообще.

---

### Ссылки на ваши внутренние файлы/карты
fileciteturn0file4 fileciteturn0file5 fileciteturn0file6 fileciteturn0file8 fileciteturn0file11

## ASSISTANT
Ок, давай закроем оба “Lean‑бита” максимально прямым путём (и заодно дам пару бонус‑лемм для твоего `stieltjes_integral_deriv` и для branch‑cut фикса).

---

## 1) `Tendsto (fun x => 1/(x+σ)^2) atTop (𝓝 0)`

**Цель (типично):**
```lean
have h : Tendsto (fun x : ℝ => 1 / (x + σ)^2) atTop (𝓝 (0 : ℝ)) := ...
```

Самая короткая цепочка — через `tendsto_atTop_add_const_right`, потом `tendsto_pow_atTop`, потом `tendsto_inv_atTop_zero`.  
Леммы про `add_const_right` и `pow_atTop` стандартные. citeturn10view0

```lean
open Filter

have h_add : Tendsto (fun x : ℝ => x + σ) atTop atTop := by
  -- `tendsto_id` : Tendsto (fun x => x) atTop atTop
  simpa using (Filter.tendsto_atTop_add_const_right (l := atTop) σ tendsto_id)

have h_pow : Tendsto (fun y : ℝ => y ^ (2 : ℕ)) atTop atTop := by
  simpa using (Filter.tendsto_pow_atTop (n := (2 : ℕ)) (by decide))

have h_sq : Tendsto (fun x : ℝ => (x + σ) ^ (2 : ℕ)) atTop atTop :=
  h_pow.comp h_add

have h_inv : Tendsto (fun x : ℝ => ((x + σ) ^ (2 : ℕ))⁻¹) atTop (𝓝 (0 : ℝ)) :=
  (tendsto_inv_atTop_zero).comp h_sq

-- если у тебя в коде стоит `(x+σ)^2` как `pow_two`/`sq`,
-- то просто `simp`:
have h : Tendsto (fun x : ℝ => 1 / (x + σ) ^ (2 : ℕ)) atTop (𝓝 (0 : ℝ)) := by
  simpa [one_div] using h_inv
```

Если у тебя именно `((x+σ)^2 : ℝ)` (как `pow_two`), то:
```lean
by
  simpa [pow_two, one_div] using h_inv
```

---

## 2) Оценка `sqrt((x+σ)^2+τ^2) ≥ x+σ` и следствие  
`1/(sqrt…*(sqrt…+x+σ)) ≤ 1/(x+σ)^2` на `Ioi 0`

### 2.1 Лемма `sqrt ≥ x+σ`

Для `hx : 0 < x` и `hσ : 0 < σ` положим `u := x + σ`. Тогда `0 ≤ u`, и:

\[
\sqrt{u^2} \le \sqrt{u^2+\tau^2}\quad\Rightarrow\quad |u|\le \sqrt{u^2+\tau^2}\quad\Rightarrow\quad u\le \sqrt{u^2+\tau^2}.
\]

Lean‑скелет:

```lean
have hu_pos : 0 < x + σ := add_pos hx hσ
have hu_nonneg : 0 ≤ x + σ := le_of_lt hu_pos

have hsqrt_ge :
    x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) := by
  -- монотонность sqrt:
  have hle : (x + σ)^2 ≤ (x + σ)^2 + τ^2 := by
    nlinarith [sq_nonneg τ]
  -- sqrt_le_sqrt : a ≤ b -> sqrt a ≤ sqrt b
  have := Real.sqrt_le_sqrt hle
  -- переписываем sqrt((x+σ)^2)=|x+σ|=x+σ (так как u≥0)
  simpa [Real.sqrt_sq_eq_abs, abs_of_nonneg hu_nonneg] using this
```

### 2.2 Неравенство для “ядра” (то, что тебе нужно для squeeze)

Обозначим
```lean
term x :=
  1 / (Real.sqrt ((x+σ)^2 + τ^2) * (Real.sqrt ((x+σ)^2 + τ^2) + (x+σ)))
```

Хочешь:
\[
term(x)\le \frac{1}{(x+\sigma)^2}.
\]

Делаем так: сначала докажем
\[
(x+\sigma)^2 \le \sqrt(u^2+\tau^2)\,(\sqrt(u^2+\tau^2)+u),
\]
а затем применим `one_div_le_one_div_of_le` (или `inv_le_inv_of_le`). Это чисто алгебра + монотонность умножения.

Lean‑скелет (на одной строке “без магии”):

```lean
have hu_pos : 0 < x + σ := add_pos hx hσ
have hu_nonneg : 0 ≤ x + σ := le_of_lt hu_pos
have hsqrt_nonneg : 0 ≤ Real.sqrt ((x + σ)^2 + τ^2) := Real.sqrt_nonneg _

have h_u_le_sqrt : x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) := hsqrt_ge (x:=x) (σ:=σ) (τ:=τ) hx hσ

-- (x+σ) ≤ sqrt + (x+σ)
have h_u_le_sum : x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) + (x + σ) :=
  le_add_of_nonneg_left hsqrt_nonneg

-- шаг 1: (x+σ)^2 ≤ sqrt * (x+σ)
have h1 : (x + σ) * (x + σ) ≤ Real.sqrt ((x + σ)^2 + τ^2) * (x + σ) := by
  exact mul_le_mul_of_nonneg_right h_u_le_sqrt hu_nonneg

-- шаг 2: sqrt*(x+σ) ≤ sqrt*(sqrt + x+σ)
have h2 :
    Real.sqrt ((x + σ)^2 + τ^2) * (x + σ)
      ≤ Real.sqrt ((x + σ)^2 + τ^2) * (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ)) := by
  exact mul_le_mul_of_nonneg_left h_u_le_sum hsqrt_nonneg

have hden :
    (x + σ)^2
      ≤ Real.sqrt ((x + σ)^2 + τ^2) *
          (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ)) := by
  -- (x+σ)^2 = (x+σ)*(x+σ)
  simpa [pow_two] using le_trans h1 h2

-- теперь инвертируем:
have hterm_le :
    1 / (Real.sqrt ((x + σ)^2 + τ^2) *
          (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ)))
      ≤ 1 / (x + σ)^2 := by
  -- one_div_le_one_div_of_le : 0 < a -> a ≤ b -> 1/b ≤ 1/a
  exact one_div_le_one_div_of_le (by nlinarith [hu_pos]) hden
```

Это как раз твоё “clean proof of `1/(sqrt...*(sqrt...+x+σ)) ≤ 1/(x+σ)^2`”.

---

## 3) `Tendsto g atTop (𝓝 (1/τ^2))` через decomposition + squeeze

Ты писал:
> “use the decomposition  
> g = 1/τ^2 − 1/(sqrt(...) * (sqrt(...)+(x+σ))).”

Пусть
```lean
g x := (1 / τ^2) - term x
```
Тогда достаточно показать `Tendsto term atTop (𝓝 0)`, а потом:

```lean
have hg : Tendsto g atTop (𝓝 (1/τ^2 - 0)) :=
  (tendsto_const_nhds.sub hterm)
-- и `simp`:
simpa using hg
```

Для `term → 0` пользуйся **`squeeze_zero`** (он прямо под это заточен). citeturn23search1  
Тебе нужны два пункта: `0 ≤ term x` и `term x ≤ 1/(x+σ)^2` плюс `1/(x+σ)^2 → 0` (пункт 1).

Скелет:

```lean
-- term ≥ 0 (деноминатор ≥ 0)
have hterm_nonneg : ∀ x, 0 ≤ term x := by
  intro x
  -- 0 ≤ 1/denom при denom>0; можно проще: `positivity` часто работает
  -- иначе:
  have hsqrt_nonneg : 0 ≤ Real.sqrt ((x + σ)^2 + τ^2) := Real.sqrt_nonneg _
  have hsum_nonneg :
      0 ≤ Real.sqrt ((x + σ)^2 + τ^2) + (x + σ) := by
    -- если надо “eventually”, то на больших x это очевидно; но можно и глобально,
    -- если σ≥0 и x≥0. Здесь можно делать eventually на Ioi 0.
    nlinarith [hsqrt_nonneg]
  have hden_nonneg :
      0 ≤ Real.sqrt ((x + σ)^2 + τ^2) *
          (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ)) :=
    mul_nonneg hsqrt_nonneg hsum_nonneg
  -- теперь 0 ≤ 1/denom:
  have : 0 ≤ 1 / (Real.sqrt ((x + σ)^2 + τ^2) *
          (Real.sqrt ((x + σ)^2 + τ^2) + (x + σ))) := by
    exact one_div_nonneg.2 hden_nonneg
  simpa [term] using this

-- term ≤ 1/(x+σ)^2 eventually (на Ioi 0) — используешь hterm_le из пункта 2.2
have hterm_le' : ∀ᶠ x in atTop, term x ≤ 1/(x+σ)^2 := by
  -- filter_upwards, берёшь hx : 0 < x, потом применяешь hterm_le
  -- (внутри всё из 2.2)
  ...

have hmain : Tendsto (fun x : ℝ => 1 / (x + σ)^2) atTop (𝓝 (0:ℝ)) := h

have hterm : Tendsto term atTop (𝓝 (0:ℝ)) := by
  -- squeeze_zero требует ∀ x, 0 ≤ term x (или eventually),
  -- и eventually term ≤ g, и Tendsto g -> 0
  refine squeeze_zero hterm_nonneg ?_ hmain
  -- ≤ часть:
  exact hterm_le'
```

С `squeeze_zero` обычно всё гладко: либо используешь “∀x” версию, либо “eventually” версию `squeeze_zero'` (она тоже есть). citeturn23search1

---

## 4) Бонус: два точечных “Lean‑камня” из твоего `stieltjes_integral_deriv`

### 4.1 Как получить `s ∈ 𝓝 z` для `s := {w | ε ≤ w.re}` (не шар)

Трюк: берёшь **открытое** множество `s' := {w | ε < w.re}`, оно в `𝓝 z` (если `ε < z.re`), и `s' ⊆ s`.

```lean
have hzε : ε < z.re := by linarith

have hs' : {w : ℂ | ε < w.re} ∈ 𝓝 z := by
  have hopen : IsOpen {w : ℂ | ε < w.re} :=
    isOpen_lt continuous_const continuous_re
  exact hopen.mem_nhds hzε

have hs : {w : ℂ | ε ≤ w.re} ∈ 𝓝 z :=
  Filter.mem_of_superset hs' (by intro w hw; exact le_of_lt hw)
```

Это обычно самый чистый способ.

### 4.2 `|re E| ≤ ‖E‖` (твоя `abs_re_le_norm`)

Используй `RCLike.abs_re_le_norm`. citeturn11search0  
В комплексном случае это работает “из коробки”:

```lean
have : |(E : ℂ).re| ≤ ‖(E : ℂ)‖ := by simpa using RCLike.abs_re_le_norm (z := (E : ℂ))
```

---

## 5) Branch‑cut: правильная замена твоего (ложного) глобального `logGamma_hasDerivAt`

Если где-то ещё у тебя всплывает “лог‑гамма дифференцируема на `Re z>0`” для `log ∘ Gamma`, то **это в общем неверно** из-за ветвления `Complex.log`. Правильный Lean‑friendly statement — *с условием* `Gamma z ∈ slitPlane`, и тогда берёшь `HasDerivAt.clog`. citeturn14view0turn21view0

Скелет:

```lean
open Complex

theorem logGamma_hasDerivAt_of_gamma_mem_slitPlane
    (z : ℂ) (hz : 0 < z.re) (hslit : Gamma z ∈ slitPlane) :
    HasDerivAt (fun w => log (Gamma w)) (deriv Gamma z / Gamma z) z := by
  have hdiffG : DifferentiableAt ℂ Gamma z := by
    refine Complex.differentiableAt_Gamma z ?_
    intro m hm
    -- если z = -m, то re z ≤ 0, contradiction with hz
    have : z.re = (-(m : ℂ)).re := by simpa [hm]
    -- (-(m:ℂ)).re = -(m:ℝ)
    have : z.re = -(m : ℝ) := by simpa using this
    have : z.re ≤ 0 := by nlinarith
    exact (not_lt_of_ge this hz)

  have hderivG : HasDerivAt Gamma (deriv Gamma z) z :=
    hdiffG.hasDerivAt

  -- главный шаг:
  simpa using (HasDerivAt.clog hderivG hslit)
```

Если хочешь именно твой `digamma z`, то просто `simp [digamma]` в конце.

---

## 6) Если нужно “протянуть” равенство с open‑сета на всю полуплоскость

В mathlib есть identity theorem: `AnalyticOnNhd.eqOn_of_preconnected_of_eventuallyEq` и вариант через “часто” (`frequently`) — `AnalyticOnNhd.eqOn_of_preconnected_of_frequently_eq`. citeturn20search0

Практика такая:
- берёшь `V := {z | 0 < z.re}` (выпукло → `IsPreconnected`),
- доказываешь `AnalyticOnNhd` для обеих сторон на `V`,
- находишь точку `z0` и окрестность `𝓝 z0`, где они равны (обычно из `Gamma z0 ∈ slitPlane` + открытость slitPlane),
- применяешь uniqueness lemma.

---

Если ты скинешь конкретный кусок `Q3/DigammaRemainder.lean` вокруг этих двух мест (Tendsto + sqrt‑оценка) — я могу “подогнать” `simp`/`nlinarith`/`ring_nf` так, чтобы оно встало без ручных переписываний, но уже сейчас этих лемм‑цепочек обычно хватает, чтобы закрыть proof‑holes за один проход.

## USER
taaks smotri 
Q3 FULL PROJECT (RH via Weil)

                               [AX] Weil_criterion
                                      ^
                                      |
                            [OK] Q_nonneg_on_Weil_cone
                                      ^
                                      |
                         [OK] Q_nonneg_on_W_K  (T5_transfer)
                                      ^
          +---------------------------+---------------------------+
          |                                                       |
   [AX] A1_density_WK                                   [OK*] A2_Q_Lipschitz
          |                                                       |
          +---------------------------+---------------------------+
                                      |
                          [OK*] Q_nonneg_on_atoms
                                      ^
                 +--------------------+--------------------+
                 |                                         |
          [OK*] A3_bridge                             [OK*] RKHS_contraction
                 ^                                         ^
                 |                                         |
   +-------------+-------------+               +-----------+-----------+
   |                           |               |                       |
[AX] Szego_Bottcher +          |         [OK*] node_spacing            |
     eigenvalue_le_norm +      |         [OK*] off_diag_exp_sum         |
     Schur_test +              |         [OK*] S_K_small                |
     c_arch_pos + a_star_*     |         [OK*] T_P_row_sum_bound         |
                 |                                         |
        [OK*] A3_FLOOR (new kernel)                         |
                 |
    Stage 1 trigamma foundations .......... [OK]
    Stage 2 monotonicity .................. [OK]
    Stage 3 numerical bounds .............. [OK*] (uses digamma remainder)
    Stage 4 final P_A >= 11/10 ............ [OK*]
    Current gap: logGamma_stieltjes_N1 .... [WIP]
                 + remove DLMF remainder axiom

(Also used: [AX] explicit_formula: Q = arch_term - prime_term)
Программа нашего проекта. Смотри, мы, вроде бы, неплохо продвинулись, кучу вещей закрыли, вот сейчас дорабатываем вот эти вещи, давай тогда предлагай самый быстрый способ закрытия всех этих наработок, делаем план и закрываем часть за частью.

## ASSISTANT
Ок, дерево вижу. Ключевой феномен (важный): **у тебя сейчас “критический путь” упёрся не в Tier‑2 (Weil/explicit_formula), а в маленький аналитический блок Q3**, который делает A3_FLOOR условным. Причём именно в форме “Johansson/Stieltjes N=1 через logGamma” всплывает **branch‑cut** и ложная глобальная производная для `log ∘ Gamma`. Это уже зафиксировано в вашем `PROSHKA_REQUEST_7`: глобально “для всех Re z>0” так писать нельзя; нужна либо оговорка `Gamma z ∈ slitPlane`, либо вообще уход от `logGamma`. fileciteturn0file0

Ниже — **самый быстрый план закрытия** (минимум новых больших теорем, максимум reuse того, что уже есть), плюс что делать дальше по верхним [AX].

---

## 0) Что реально блокирует цепь сейчас

По твоей схеме Stage 4 уже собран, но “звёздочка” висит из‑за остатка для digamma/хвоста (раньше DLMF, теперь Stieltjes). В ваших рабочих файлах это описано как “Stieltjes N=1 identity still axiomatic / conditional”. fileciteturn0file5 fileciteturn0file6

**Самый быстрый выигрыш:** сделать Q3‑остаток без `logGamma` вообще ⇒ тогда branch‑cut перестаёт существовать как проблема.

---

## 1) Закрываем Q3 полностью и делаем A3_FLOOR unconditional

### 1.1. Принципиальный выбор маршрута (fastest)

**Не пытайся закрывать `logGamma_stieltjes_N1` как теорему про `log(Gamma z)`**. Это автоматически тянет branch‑cut и аналитику `log` на slitPlane, и в итоге ты либо:
- добавляешь домен `Gamma z ∈ slitPlane` + аналитическое продолжение (что ок, но длиннее), либо
- снова получаешь ложную глобальную лемму.

Вместо этого делаем так:

> **Цель:** доказать сразу `digamma_stieltjes_identity` (Johansson Eq.23, N=1) напрямую из “Stieltjes summation / Euler–Maclaurin N=1 для `f(x)=1/(x+z)`” + limit‑характеризации digamma.

Это ровно то, что вам нужно для остатка и хвоста, и это обходится **без** logGamma.

Почему это быстро: вы уже закрыли/закрываете все “интегральные куски” (оценка Bernoulli, kernel integral), значит остаётся 1 новый **суммирование‑интеграл** лемма.

---

### 1.2. Мини‑ядро: какие леммы нужны (Lean‑friendly список)

#### (A) Stieltjes summation (N=1) для произвольной C¹‑функции
Сформулируй как отдельную лемму (самую общую не надо; достаточно под вашу `f`):

**Лемма `stieltjes_sum_eq` (идеальная форма):**

Для `N : ℕ`, `z : ℂ` с `0 < z.re`:

\[
\sum_{n=0}^{N-1} \frac{1}{z+n}
=
\log(z+N)-\log z + \frac{1}{2z}-\frac{1}{2(z+N)}
-\int_{0}^{N} \frac{B_1(\{x\})}{(x+z)^2}\,dx
\]

где \(B_1(t)=t-\tfrac12\), \(\{x\}=\text{fract}(x)\).

Lean‑скелет:

- определяешь `B1fract x : ℝ := Int.fract x - (1/2:ℝ)`.
- доказываешь на каждом интервале `[k,k+1]` интегрирование по частям/телескоп:
  \[
  \int_k^{k+1} f(x)\,dx = f(k+\theta) \text{ и } \int_k^{k+1}(x-k-\tfrac12)f'(x)dx
  \]
  стандартный Stieltjes trick.
- суммируешь по `k=0..N-1` (`intervalIntegral.sum_integral_adjacent_intervals`‑подобная лемма или `MeasureTheory.integral_Icc_eq_sum_integral_Icc`).

**Важно:** на линии `0<Re z`, у тебя `x+z` лежит в правой полуплоскости, значит `Complex.log` можно использовать *без* branch‑условий, потому что правая полуплоскость ⊂ slitPlane автоматически. То есть в этой части branch‑cut не всплывает.

#### (B) Переход `N→∞` к digamma через limit
Ключевая “смычка”:

\[
\psi(z)=\lim_{N\to\infty}\left(\log N - \sum_{n=0}^{N-1}\frac{1}{z+n}\right)
\]

Это следует из стандартной серии digamma (которая у вас уже есть в Stage 1/2 через `digammaSeq → digamma`). В `PROWKA_RESPONSE_3` ровно эта стратегия описана “без чисел”. fileciteturn0file9

Lean‑friendly доказательство:

1) Берёшь уже имеющуюся лемму вида  
`digamma z = -γ + ∑ (1/(n+1) - 1/(n+z))`.
2) Пишешь для частичных сумм:
`log N - ∑ 1/(n+z) = (∑ (1/(n+1)-1/(n+z)) - γ_N) + (log N - H_N)`  
и используешь:
- `tendsto` частичных сумм к `∑`,
- `tendsto (H_N - log N) = γ` (это обычно **определение** `Real.eulerMascheroni` в mathlib, так что часто это легко).

Фишка: γ сократится, и предел будет именно `digamma z`.

#### (C) Превращаем B1‑интеграл в ваш B2Diff‑интеграл
Вы хотите финальную форму с `bernoulli2Diff/(x+z)^3`. Для этого делается **интегрирование по частям по x на каждом (k,k+1)**, где `bernoulli2Diff` гладкая:

- у вас уже есть формула:
  `bernoulli2Diff x = fract x * (1 - fract x)` и границы. fileciteturn0file8
- на `(k,k+1)` имеем `fract x = x-k`, значит  
  `d/dx (bernoulli2Diff x) = 1 - 2*fract x = -2*(fract x - 1/2) = -2*B1(fract x)`.
- и также `d/dx (x+z)^{-2} = -2 (x+z)^{-3}`.

Отсюда на каждом интервале:
\[
\int_k^{k+1} \frac{B_1(\{x\})}{(x+z)^2}dx
=
-\int_k^{k+1}\frac{\text{bernoulli2Diff}(x)}{(x+z)^3}dx
\]
потому что граничные члены обнуляются: `bernoulli2Diff k = bernoulli2Diff (k+1)=0`.

Суммируешь по k, получаешь равенство на `[0,N]`, затем `N→∞`.

#### (D) Готовая цель: `digamma_stieltjes_identity`
Получается ровно ваш target:

\[
\psi(z)-\log z+\frac{1}{2z}
=
-\int_{0}^{\infty}\frac{\text{bernoulli2Diff}(x)}{(x+z)^3}dx,
\quad \Re z>0.
\]

Это и есть то, что в ваших файлах фигурирует как “digamma_stieltjes_identity”. fileciteturn0file4

---

### 1.3. Из identity сразу получаем остаток и хвост (то, что вам реально нужно)

После того как `digamma_stieltjes_identity` закрыта:

1) Берёшь норму/реальную часть:
   - `|Re E(z)| ≤ ‖E(z)‖`.
2) Используешь bounds `0 ≤ bernoulli2Diff x ≤ 1/4` (уже есть). fileciteturn0file8
3) `‖ ∫ f ‖ ≤ ∫ ‖f‖` (`norm_integral_le_integral_norm`).
4) `‖ (x+z)^{-3} ‖ = |x+z|^{-3}` и оценка интеграла “kernel bound”
   (у вас уже: либо точная формула, либо `≤ 1/‖z‖²`). fileciteturn0file7

И получаешь ваш рабочий остаток:
\[
\left|\Re\psi(z)-\log\|z\|+\frac{\Re z}{2\|z\|^2}\right|
\le
\frac{1}{4\|z\|^2}.
\]
(или с чуть хуже константой — но у вас уже “достаточно”.)

Это ровно то, что вы хотели вместо DLMF. fileciteturn0file7

Дальше tail‑лемма вида
`|Re ψ(1/4+iπξ)| ≤ log(1+ξ^2)+1/10` для ξ≥5/2
докидывается теми же чисто‑реальными оценками (π≤22/7, log(1+t)≤t), и вся Stage 3/4 перестаёт быть условной. fileciteturn0file7

---

## 2) Что делать с branch‑cut / `logGamma_*` (если они ещё где‑то торчат)

Если где‑то в коде всё ещё используется `Complex.logGamma := log ∘ Gamma`, то:

- **глобальный** `logGamma_hasDerivAt (Re z>0)` надо выбросить,
- заменить на “branch‑aware” версию с `Gamma z ∈ slitPlane` (это реально доказывается через `HasDerivAt.clog`), как вы уже наметили. fileciteturn0file0

Но если ты пойдёшь по маршруту выше (digamma‑only), то `logGamma_stieltjes_N1` вообще можно удалить из критического пути и забыть.

---

## 3) После того как Q3 закрыт: как “быстро” закрывать остальные [AX] сверху

Тут честно: **не все [AX] одинаковы по цене**. Я бы делил на слои:

### Слой L1 (скорее всего быстро закрываемые)
- `eigenvalue_le_norm` — обычно есть в mathlib для Hermitian/normal матриц или выводится из спектральной теории.
- `Schur_test` для конечных матриц — часто доказывается элементарно через Cauchy–Schwarz и row/col sums.  
Эти две штуки я бы атаковал сразу после Q3: они “математика уровня линал/анализ”, без огромной АНТ.

### Слой L2 (средне)
- `A1_density_WK` (Fejér×heat‑конус) — это функциональный анализ + аппроксимации (Fejér kernel, сглаживание). Реально, но нужен аккуратный слой лемм про свёртки и нормировки.

### Слой L3 (тяжёлые / “отдельный проект”)
- `explicit_formula` и `Weil_criterion`. Это уже полноценная аналитическая теория чисел и связь с RH. Даже если “теоретически” это стандарт, в Lean это большой объём.

**Быстрый практический план**:  
1) делаем Q3 unconditional (это даёт “замкнутый Tier‑2 модуль A3”).  
2) закрываем L1 (eigenvalue/norm, Schur) — это даст “закрытую дискретизацию/матрицы” часть.  
3) потом решаем: либо фиксируем L2/L3 как внешние аксиомы (если цель — Tier‑2 эксперимент), либо начинаем отдельный бранч “формализуем explicit formula/Weil criterion”.

---

## 4) Как именно разбить работу “часть за частью” (чтобы реально быстро закрывать)

Я бы нарезал **5 атомарных задач**, каждая — отдельный Lean‑файл/лемма:

1) `stieltjes_sum_inv` : формула для `∑_{n<N} 1/(z+n)` через `log(z+N)-log z + ... + ∫ B1/(x+z)^2`.
2) `digamma_eq_tendsto_log_sub_sum` : `Tendsto (log N - ∑ 1/(z+n)) → digamma z`.
3) `B1_to_B2Diff` : `∫ B1/(x+z)^2 = -∫ bernoulli2Diff/(x+z)^3` (с разбиением по интервалам `[k,k+1]`).
4) `digamma_stieltjes_identity` : собираем (1)+(2)+(3).
5) `re_digamma_remainder_bound_stieltjes` : оценка через `bernoulli2Diff_bounds` + `integral_kernel_bound`.

Эта нарезка буквально соответствует вашим “что осталось” в `PROSHKA_REQUEST_6/7`. fileciteturn0file2turn0file0

---

Если хочешь, я могу прямо в следующем сообщении дать **очень конкретные Lean‑формулировки** этих 5 лемм (с типами `∫ x in Set.Ioc ...` vs `∂μ`, какие `simp`‑линии лучше, какие “sum over adjacent intervals” леммы обычно не взрывают `whnf`). Но стратегически: **самый быстрый путь** — “digamma‑only Stieltjes N=1”, и тогда ваш “Current gap: logGamma_stieltjes_N1” просто исчезает из критического пути.

## ASSISTANT
По текущей карте (Stage 1–4 закрыты, но «всё ещё условно» из‑за хвоста digamma) самый быстрый путь — **не пытаться продавить тяжёлую `hasDerivAt_integral_of_dominated_loc_of_deriv_le`** (она у тебя уже дала `whnf`‑взрыв), а **переключиться на “finite‑N Stieltjes/Euler–Maclaurin N=1”** и напрямую доказать `digamma_stieltjes_identity` без `logGamma`. Это прямо то, что зафиксировано в `PROSHKA_REQUEST_7` как целевая стратегия. 【343:0†PROSHKA_REQUEST_7.md†L1-L47】【343:6†PROSHKA_REQUEST_6.md†L30-L38】

Ниже — план закрытия “часть за частью”, с минимальными зависимостями и Lean‑дружелюбными леммами.

---

## 0) Что сейчас реально блокирует “unconditional A3_FLOOR”

**Единственный критический разрыв** в цепочке A3_FLOOR — это доказательство Stieltjes‑формулы N=1 для digamma **без logGamma**:  
```lean
lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
  Q3.digamma z - Complex.log z + (1/2:ℂ) * z⁻¹
    = - ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3
```  
Точно этот statement зафиксирован как target. 【343:0†PROSHKA_REQUEST_7.md†L7-L14】

Именно он должен заменить старую ветку “logGamma_stieltjes_N1 → differentiate under integral → digamma…”, которая уже упиралась в `whnf` timeout. 【343:8†PROSHKA_REQUEST_6.md†L30-L38】

---

## 1) Быстрый маршрут: Finite‑N Stieltjes (Euler–Maclaurin N=1) → предел N→∞

### 1.1. Локальная (unit interval) лемма: “трапеция + остаток через B1”

**Цель леммы на одном отрезке `[n, n+1]`** (реальная переменная `x`, значения в `ℂ`):

Пусть `f : ℝ → ℂ` дифференцируема на `[n,n+1]`. Тогда:
\[
\int_n^{n+1} f(x)\,dx
= \frac{f(n)+f(n+1)}{2} - \int_n^{n+1} (x-(n+\tfrac12))\, f'(x)\,dx.
\]

**Lean‑скелет** (без магии, только ФТОК на производной произведения):

- Введи `g(x) := (x - (n + 1/2)) * f x`.
- Тогда `g'(x) = f x + (x - (n+1/2)) * f' x`.
- Интегрируй `g'` на `n..n+1` и распиши `g(n+1)-g(n)`.

Это в Lean обычно делается через `intervalIntegral.integral_deriv_eq_sub`/`integral_eq_sub_of_hasDerivAt` на `g`, плюс `HasDerivAt.mul` и `HasDerivAt.sub_const`.

**Почему это быстро:** это *маленькая* лемма, без measure‑theory на `Ioi` и без глобальных доминируемых сходимостей.

---

### 1.2. Суммирование по n=0..N−1: “finite‑N Stieltjes sum identity”

Берёшь `f(x) = 1/(x+z)` при `0 < z.re`. Тогда `f'(x) = -(x+z)^{-2}`.

После суммирования unit‑interval леммы ты получаешь стандартную формулу из `PROSHKA_REQUEST_7` (п.1): 【343:0†PROSHKA_REQUEST_7.md†L41-L48】

\[
\sum_{n=0}^{N-1} \frac{1}{z+n}
= \log(z+N) - \log z + \frac1{2z} - \frac1{2(z+N)}
- \int_0^N \frac{B_1(\{x\})}{(x+z)^2}\,dx,
\]
где \(B_1(t)=t-\frac12\).

**Lean‑заметки, чтобы не словить branch cut:**

- Используй `Complex.hasDerivAt_log` и условие `x+z ∈ Complex.slitPlane`. Это есть в mathlib: `Complex.hasDerivAt_log` требует `z ∈ slitPlane`. 【turn15view0†L82-L90】
- Для `0 < z.re` и `x≥0` имеем `(x+z).re > 0`, значит `x+z ∈ slitPlane` (поскольку slitPlane содержит правую полуплоскость). Это прямо упоминается в `PROSHKA_REQUEST_7`. 【343:0†PROSHKA_REQUEST_7.md†L49-L52】

---

### 1.3. Конверсия “B1(fract) → bernoulli2Diff” через интегрирование по частям на каждом `[k,k+1]`

Это шаг (2) из `PROSHKA_REQUEST_7`: 【343:0†PROSHKA_REQUEST_7.md†L53-L64】

Используй вашу функцию `bernoulli2Diff x = Int.fract x * (1 - Int.fract x)` (уже есть как `bernoulli2Diff_eq_mul`). 【343:0†PROSHKA_REQUEST_7.md†L28-L30】

На интервале `(k,k+1)`:
- `u(x) := bernoulli2Diff x = t(1-t)` где `t = fract x`.
- Производная: `u'(x) = 1 - 2t = -2(t - 1/2) = -2 * B1(fract x)`.

Дальше на `[k,k+1]`:
\[
\int_{k}^{k+1} \frac{B_1(\{x\})}{(x+z)^2}\,dx
= -\int_{k}^{k+1} \frac{u(x)}{(x+z)^3}\,dx
\]
потому что:
- `B1 = -u'/2`,
- интегрирование по частям переносит производную на `(x+z)^{-2}`,
- и **границы исчезают**, т.к. `u(k)=u(k+1)=0` (fract=0 ⇒ u=0).

Именно это и написано как целевое равенство (2) в `PROSHKA_REQUEST_7`. 【343:0†PROSHKA_REQUEST_7.md†L60-L64】

---

### 1.4. Переход N→∞: два предела

Здесь ровно шаг (3) `PROSHKA_REQUEST_7`: 【343:0†PROSHKA_REQUEST_7.md†L35-L41】

Нужны:

**(A) предел суммы:**
\[
\lim_{N\to\infty}\left(\log N - \sum_{n=0}^{N-1} \frac{1}{z+n}\right) = \psi(z)
\]
(в вашем коде это “existing digamma series machinery”). 【343:0†PROSHKA_REQUEST_7.md†L35-L41】

Если вдруг этого exact‑леммы не хватает, самый короткий путь — разложить:
\[
\log N - \sum_{n=0}^{N-1}\frac{1}{z+n}
= (\log N - H_N) + \sum_{n=0}^{N-1}\left(\frac1{n+1}-\frac1{z+n}\right),
\]
и использовать mathlib‑лемму о пределе гармоник:
`Real.tendsto_harmonic_sub_log` (в файле про Euler–Mascheroni). 【turn16search1†L1-L4】

**(B) предел интеграла:**
\[
\int_0^N \frac{bernoulli2Diff(x)}{(x+z)^3}\,dx \to
\int_0^\infty \frac{bernoulli2Diff(x)}{(x+z)^3}\,dx
\]
Это делается стандартно через “integrable tail” (раз integrand абсолютно интегрируемый на `Ioi 0`, то `integral_Icc 0 N → integral_Ioi 0`).

Итог после (A)+(B) даёт:
\[
\psi(z) - \log z + \frac{1}{2z}
= -\int_0^\infty \frac{bernoulli2Diff(x)}{(x+z)^3}\,dx,
\]
то есть ровно целевую `digamma_stieltjes_identity`. 【343:0†PROSHKA_REQUEST_7.md†L7-L14】

---

## 2) Что дальше “сразу закрывается” после `digamma_stieltjes_identity`

Как только `digamma_stieltjes_identity` есть, ты автоматически снимаешь условность Stage 3/4:

- `bernoulli2Diff_bounds : 0 ≤ … ≤ 1/4` уже есть (и это ключ к remainder bound). 【343:0†PROSHKA_REQUEST_7.md†L32-L35】【343:6†PROSHKA_REQUEST_6.md†L5-L8】
- Значит остаток `E(z)` оценивается чисто:
  \[
  |E(z)| \le \frac14 \int_0^\infty |x+z|^{-3} dx \le \frac1{4|z|^2}
  \]
  (это твоя текущая “kernel route”; kernel‑леммы уже отмечены как DONE/WIP в request_6). 【343:6†PROSHKA_REQUEST_6.md†L5-L13】

И уже из этого строится ваш хвост `|Re ψ(1/4+iπξ)| ≤ log(1+ξ^2)+…` и `|a(ξ)|` bound, что у тебя в Stage 3 сейчас “DONE, но conditional”. 【343:13†PROWKA_BRIEF.md†L39-L55】

То есть **после Stieltjes‑identity** A3_FLOOR становится unconditional внутри вашего модуля A3 (и цепочка до A3_bridge/RKHS_contraction перестаёт зависеть от DLMF‑аксиомы). 【343:13†PROWKA_BRIEF.md†L39-L57】

---

## 3) Про остальные [AX] в верхней диаграмме (как закрывать “быстро”)

Тут важно не путать: есть **локальные AX** (которые реально можно добить быстро в Lean), и есть **архитектурные AX** уровня “Weil criterion / explicit formula / Szegő–Böttcher”, которые по масштабу сравнимы с самостоятельными статьями.

Я бы разделил так:

### 3.1. “Быстро закрываемые” (скорее всего уже в mathlib или коротким портом)
- `eigenvalue_le_norm`: в mathlib обычно есть спектральные оценки типа `spectralRadius_le_norm` для нормированных алгебр/матриц. Это почти наверняка “поднять нужную лемму/переписать утверждение”.
- `Schur_test`: иногда нет готового, но доказательство на 1–2 страницы (Cauchy–Schwarz + row/col sums). В Lean обычно делается через `LinearMap.opNorm_le_bound` и стандартные inequalities.
- “мелкие” positivity/normalization леммы (`c_arch_pos`, `a_star_*`): часто чистая алгебра + `simp`.

**Стратегия:** сначала попытка найти готовое через `#find`/`#check` и docs; если нет — пишешь минимальную абстрактную лемму (без конкретики RH) и используешь её везде.

### 3.2. “Средние” (реалистично, но займёт время)
- `A1_density_WK`: это функциональный анализ/приближение тестов. Вероятно, придётся строить конкретные аппроксимации (Fejér×heat) и доказывать плотность в нужной топологии. Это уже не “1 вечер”, но можно “распилить”.

### 3.3. “Тяжёлые” (закрывать последними, отдельными эпиками)
- `Weil_criterion`: это крупный теоретический кусок (эквивалент RH ↔ positivity на Weil cone) — обычно не в mathlib из коробки.
- `explicit_formula`: тоже большой модуль.
- `Szego_Bottcher`: сильная теорема о Toeplitz‑матрицах/символах.

**Быстрый “engineering” ход:** оставить эти как axioms **на самом верхнем уровне**, но сделать всё ниже максимально unconditional. Это то, что у вас уже описано в структуре “Tier‑2 conditional” в заметках. 【343:3†PROSHKA_REQUEST_3.md†L5-L8】

---

## 4) Практический “спринт‑план” (в правильном порядке зависимостей)

### Sprint A (закрыть Q3 полностью, убрать последнюю условность A3_FLOOR)
1) **Вынести** в отдельный файл (или секцию) `finite_stieltjes_sum_identity` для `f(x)=1/(x+z)`.  
   (Это шаг 1 из `PROSHKA_REQUEST_7`.)【343:0†PROSHKA_REQUEST_7.md†L41-L48】
2) Лемма `B1_to_bernoulli2Diff` по интервалам `[k,k+1]` (integration by parts).  
   (Шаг 2 из `PROSHKA_REQUEST_7`.)【343:0†PROSHKA_REQUEST_7.md†L53-L64】
3) Лемма “limit‑to‑digamma” (если уже есть — просто использовать; если нет — через `Real.tendsto_harmonic_sub_log` + вашу series‑лемму). 【343:0†PROSHKA_REQUEST_7.md†L35-L41】【turn16search1†L1-L4】
4) Собрать `digamma_stieltjes_identity` и удалить `logGamma_stieltjes_N1` как dependency. 【343:0†PROSHKA_REQUEST_7.md†L16-L18】

### Sprint B (переподключить Stage 3 хвост на новый remainder и снести DLMF‑аксиому)
5) Переопределить/перепривязать `re_digamma_bound_tail_log` так, чтобы оно выходило из Stieltjes remainder bound (а не DLMF 5.11).  
   (Сейчас оно помечено как conditional на DLMF‑аксиому.)【343:13†PROWKA_BRIEF.md†L39-L55】
6) Прогнать `lake build` и обновить “proof map”: Stage 3/4 станет ✅ unconditional.

### Sprint C (дальше по дереву: “быстро закрываемые AX”)
7) Убрать `eigenvalue_le_norm`, `Schur_test` через существующие mathlib‑леммы или короткие порты.
8) Только после этого решать, идёшь ли ты в большие эпики `A1_density_WK` / `explicit_formula` / `Weil_criterion` / `Szego_Bottcher`.

---

## 5) Почему это реально самый быстрый путь

**Феномен/аномалия:** `hasDerivAt_integral_of_dominated_loc_of_deriv_le` вызывает `whnf` timeout даже при больших heartbeats. Это сигнал, что выбранный “measure‑theory heavy” путь плох для Lean‑пропускной способности. 【343:8†PROSHKA_REQUEST_6.md†L30-L38】

**Решение:** finite‑N Stieltjes/Euler–Maclaurin N=1:
- избегает больших локальных доминируемых доказательств внутри `Metric.ball`/`volume.restrict`;
- работает через **маленькие** `intervalIntegral`‑леммы и summation;
- branch cut для `Complex.log` решается чисто через `slitPlane` и `z.re>0` (есть готовая `Complex.hasDerivAt_log`). 【turn15view0†L82-L90】

Это прямо совпадает с вашим новым target‑планом. 【343:0†PROSHKA_REQUEST_7.md†L36-L47】

---

Если хочешь, следующим шагом я могу дать **конкретный Lean‑скелет** для пункта 1.1–1.2 (unit interval → суммирование → появление `∫ B1(fract)/(x+z)^2`), с максимально “легкими” леммами (без `simp`‑бомб) и с тем, как быстро показать `(x+z) ∈ slitPlane` из `0<z.re`.

## USER
Привет! Это единый запрос по Q3: файл PROSHKA_REQUEST_7.md.
Нужно вернуть Lean‑доказательство леммы

lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
  Q3.digamma z - Complex.log z + (1/2:ℂ) * z⁻¹
    = - ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3

Важно: без logGamma и без ветвевых условий (никаких log ∘ Gamma). 
Используем finite‑N Stieltjes/Euler–Maclaurin N=1 и предел N→∞.
Просьба вернуть Lean‑код, который вставляется в Q3/DigammaRemainder.lean и компилируется.
Без `sorry` / `exact?` / новых axioms.
Если нужны вспомогательные леммы — пришли в том же ответе.

## ASSISTANT
Ок, вижу цель: убрать последний «аксиоматический» кусок Q3 и получить **чистую** формулу Стилтьеса для `digamma` на полуплоскости `Re z > 0`, причём **без** `logGamma` и без ветвления `log ∘ Gamma`.

Ниже даю **самый быстрый** путь, который реально «Lean‑friendly» (разбивается на маленькие леммы, всё через FTC + integration by parts + пределы). Сразу честно: я не могу прогнать `lake build` в этой среде, поэтому *точные* имена некоторых лемм/симпов могут потребовать микро‑правки у тебя локально. Но **структура**, “what to prove”, и «какими стандартными инструментами» — полностью рабочая.

---

## 0. Теорема и статус

### 0. Теорема: Stieltjes N=1 для digamma на `Re z > 0`
**Формулировка (как у тебя):**
\[
\forall z\in\mathbb C,\ (\Re z>0)\Rightarrow
\psi(z)-\log z+\frac1{2z}
= -\int_{0}^{\infty}\frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\]
где \(B_2(t)=t^2-t+\frac16\), \(\{x\}=\mathrm{fract}(x)\in[0,1)\), а у тебя
`bernoulli2Diff x = (1/6) - bernoulli2 (Int.fract x)`.

**Статус:** стандартная математика (Euler–Maclaurin / Stieltjes remainder), без дополнительных гипотез, кроме `Re z > 0` (для корректности комплексного `log` на пути интегрирования).

---

## 1. Что реально надо сделать в Lean (минимальный набор лемм)

### Шаг A. Финитная формула Эйлера–Маклорена для `f(x)=1/(x+z)` на `[0,N]`
Для `N : ℕ`, `N>0`, доказать:
\[
\sum_{n=0}^{N-1}\frac1{z+n}
=
\int_0^N \frac{dx}{x+z}
+\frac12\Big(\frac1z-\frac1{z+N}\Big)
-\int_0^N \frac{B_1(\{x\})}{(x+z)^2}\,dx,
\]
где \(B_1(t)=t-\frac12\) и на каждом интервале \((n,n+1)\) имеем \(B_1(\{x\})=x-n-\frac12\).

**Как сделать в Lean “по‑камешкам”:**
- разрезать интегралы на сумму по интервалам `[n,n+1]`;
- на каждом `[n,n+1]` применить integration by parts к
  \(u(x)=x-n-\frac12\), \(v(x)=\frac1{x+z}\).

Это даёт локально:
\[
\int_n^{n+1}\frac{dx}{x+z}
=
\frac12\Big(\frac1{z+n}+\frac1{z+n+1}\Big)
-\int_n^{n+1}(x-n-\tfrac12)\cdot\Big(-\frac1{(x+z)^2}\Big)dx.
\]
Суммирование по `n=0..N-1` и телескоп даёт формулу выше.

**Ключевой момент:** тут **не нужно** дифференцировать `Int.fract`. На каждом интервале просто используешь, что `Int.fract x = x - n` на `x ∈ Ioo (n) (n+1)` (через `Int.floor_eq_iff` / `Int.fract_def`), и всё становится линейным.

---

### Шаг B. Перепаковка “B1‑интеграла” в “B2Diff‑интеграл” без ветвления
Определим (как у тебя):
\[
\mathrm{B2Diff}(x)=\frac16-B_2(\{x\}) = \{x\}-\{x\}^2.
\]

На каждом `(n,n+1)` имеем:
\[
\mathrm{B2Diff}(x) = (x-n)-(x-n)^2,\quad
\frac{d}{dx}\mathrm{B2Diff}(x) = 1-2(x-n)= -2\big((x-n)-\tfrac12\big).
\]
То есть:
\[
\mathrm{B1Fract}(x):=\{x\}-\tfrac12 = -\frac12(\mathrm{B2Diff})'(x)
\quad\text{на }(n,n+1).
\]

Теперь на **каждом** `[n,n+1]` делаем integration by parts:
- `u = bernoulli2Diff` (квадратичная по `x` на интервале),
- `v = - (1/2) * (x+z)⁻²` (так что `v' = (x+z)⁻³`).

Получаешь локально:
\[
\int_n^{n+1}\frac{B_1(\{x\})}{(x+z)^2}\,dx
= -\int_n^{n+1}\frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx
\]
**без граничных членов**, потому что `bernoulli2Diff n = bernoulli2Diff (n+1) = 0` (у тебя это легко: `Int.fract_int = 0`).

Суммируя `n=0..N-1`:
\[
\int_0^N \frac{B_1(\{x\})}{(x+z)^2}\,dx
= -\int_0^N \frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx.
\]

---

### Шаг C. Предел `N → ∞` и связь с `digamma`
Нужно использовать известную формулу:
\[
\psi(z)=\lim_{N\to\infty}\Big(\log N - \sum_{n=0}^{N-1}\frac1{z+n}\Big)
\quad(\Re z>0),
\]
которая выводится из уже имеющейся у тебя **series‑версии** digamma + факта `harmonic N - log N → γ`.

Это, судя по твоим Stage 1/2, у тебя уже есть как часть `digammaSeq`‑машины (или его легко добить одной леммой через `Real.tendsto_harmonic_sub_log`).

Потом подставляешь финитную формулу из Шага A+B:
\[
\log N - \sum_{n=0}^{N-1}\frac1{z+n}
=
(\log N - \log(z+N))
+ \log z
-\frac1{2z}
+\frac1{2(z+N)}
-\int_0^N\frac{\mathrm{B2Diff}(x)}{(x+z)^3}dx.
\]

Дальше:
- `log N - log(z+N) → 0`,
- `1/(z+N) → 0`,
- `∫_0^N ... → ∫_0^∞ ...` (через dominated convergence / `tendsto_integral_Icc_atTop` и `‖(x+z)⁻³‖ ≤ (x + Re z)⁻³`).

И получаешь:
\[
\psi(z)=\log z-\frac1{2z}-\int_0^\infty\frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx
\]
=> требуемая формула.

---

## 2. Lean‑friendly леммы, которые прям “закрывают” твой statement

Ниже — набор лемм и код‑скелет, который удобно вставлять в `Q3/DigammaRemainder.lean`. Я пишу так, чтобы было ясно, что доказывать; где конкретные `simp`‑леммы могут отличаться именем — помечаю комментариями.

### 2.1. Вспомогательные определения (B1)
```lean
namespace Q3
open scoped BigOperators
open MeasureTheory Complex

/-- B₁(t) = t - 1/2 -/
def bernoulli1 (t : ℝ) : ℝ := t - (1/2 : ℝ)

/-- B₁({x}) = fract x - 1/2 -/
def bernoulli1Fract (x : ℝ) : ℝ := bernoulli1 (Int.fract x)
```

### 2.2. Нули `bernoulli2Diff` на целых (нужно для исчезновения boundary terms)
У тебя уже есть `Int.fract_int : Int.fract (n:ℝ) = 0`.

Тогда:
```lean
lemma bernoulli2Diff_int (n : ℤ) : bernoulli2Diff (n :

## ASSISTANT
Ок, вижу цель: убрать последний «аксиоматический» кусок Q3 и получить **чистую** формулу Стилтьеса для `digamma` на полуплоскости `Re z > 0`, причём **без** `logGamma` и без ветвления `log ∘ Gamma`.

Ниже даю **самый быстрый** путь, который реально «Lean‑friendly» (разбивается на маленькие леммы, всё через FTC + integration by parts + пределы). Сразу честно: я не могу прогнать `lake build` в этой среде, поэтому *точные* имена некоторых лемм/симпов могут потребовать микро‑правки у тебя локально. Но **структура**, “what to prove”, и «какими стандартными инструментами» — полностью рабочая.

---

## 0. Теорема и статус

### 0. Теорема: Stieltjes N=1 для digamma на `Re z > 0`
**Формулировка (как у тебя):**
\[
\forall z\in\mathbb C,\ (\Re z>0)\Rightarrow
\psi(z)-\log z+\frac1{2z}
= -\int_{0}^{\infty}\frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\]
где \(B_2(t)=t^2-t+\frac16\), \(\{x\}=\mathrm{fract}(x)\in[0,1)\), а у тебя
`bernoulli2Diff x = (1/6) - bernoulli2 (Int.fract x)`.

**Статус:** стандартная математика (Euler–Maclaurin / Stieltjes remainder), без дополнительных гипотез, кроме `Re z > 0` (для корректности комплексного `log` на пути интегрирования).

---

## 1. Что реально надо сделать в Lean (минимальный набор лемм)

### Шаг A. Финитная формула Эйлера–Маклорена для `f(x)=1/(x+z)` на `[0,N]`
Для `N : ℕ`, `N>0`, доказать:
\[
\sum_{n=0}^{N-1}\frac1{z+n}
=
\int_0^N \frac{dx}{x+z}
+\frac12\Big(\frac1z-\frac1{z+N}\Big)
-\int_0^N \frac{B_1(\{x\})}{(x+z)^2}\,dx,
\]
где \(B_1(t)=t-\frac12\) и на каждом интервале \((n,n+1)\) имеем \(B_1(\{x\})=x-n-\frac12\).

**Как сделать в Lean “по‑камешкам”:**
- разрезать интегралы на сумму по интервалам `[n,n+1]`;
- на каждом `[n,n+1]` применить integration by parts к
  \(u(x)=x-n-\frac12\), \(v(x)=\frac1{x+z}\).

Это даёт локально:
\[
\int_n^{n+1}\frac{dx}{x+z}
=
\frac12\Big(\frac1{z+n}+\frac1{z+n+1}\Big)
-\int_n^{n+1}(x-n-\tfrac12)\cdot\Big(-\frac1{(x+z)^2}\Big)dx.
\]
Суммирование по `n=0..N-1` и телескоп даёт формулу выше.

**Ключевой момент:** тут **не нужно** дифференцировать `Int.fract`. На каждом интервале просто используешь, что `Int.fract x = x - n` на `x ∈ Ioo (n) (n+1)` (через `Int.floor_eq_iff` / `Int.fract_def`), и всё становится линейным.

---

### Шаг B. Перепаковка “B1‑интеграла” в “B2Diff‑интеграл” без ветвления
Определим (как у тебя):
\[
\mathrm{B2Diff}(x)=\frac16-B_2(\{x\}) = \{x\}-\{x\}^2.
\]

На каждом `(n,n+1)` имеем:
\[
\mathrm{B2Diff}(x) = (x-n)-(x-n)^2,\quad
\frac{d}{dx}\mathrm{B2Diff}(x) = 1-2(x-n)= -2\big((x-n)-\tfrac12\big).
\]
То есть:
\[
\mathrm{B1Fract}(x):=\{x\}-\tfrac12 = -\frac12(\mathrm{B2Diff})'(x)
\quad\text{на }(n,n+1).
\]

Теперь на **каждом** `[n,n+1]` делаем integration by parts:
- `u = bernoulli2Diff` (квадратичная по `x` на интервале),
- `v = - (1/2) * (x+z)⁻²` (так что `v' = (x+z)⁻³`).

Получаешь локально:
\[
\int_n^{n+1}\frac{B_1(\{x\})}{(x+z)^2}\,dx
= -\int_n^{n+1}\frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx
\]
**без граничных членов**, потому что `bernoulli2Diff n = bernoulli2Diff (n+1) = 0` (у тебя это легко: `Int.fract_int = 0`).

Суммируя `n=0..N-1`:
\[
\int_0^N \frac{B_1(\{x\})}{(x+z)^2}\,dx
= -\int_0^N \frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx.
\]

---

### Шаг C. Предел `N → ∞` и связь с `digamma`
Нужно использовать известную формулу:
\[
\psi(z)=\lim_{N\to\infty}\Big(\log N - \sum_{n=0}^{N-1}\frac1{z+n}\Big)
\quad(\Re z>0),
\]
которая выводится из уже имеющейся у тебя **series‑версии** digamma + факта `harmonic N - log N → γ`.

Это, судя по твоим Stage 1/2, у тебя уже есть как часть `digammaSeq`‑машины (или его легко добить одной леммой через `Real.tendsto_harmonic_sub_log`).

Потом подставляешь финитную формулу из Шага A+B:
\[
\log N - \sum_{n=0}^{N-1}\frac1{z+n}
=
(\log N - \log(z+N))
+ \log z
-\frac1{2z}
+\frac1{2(z+N)}
-\int_0^N\frac{\mathrm{B2Diff}(x)}{(x+z)^3}dx.
\]

Дальше:
- `log N - log(z+N) → 0`,
- `1/(z+N) → 0`,
- `∫_0^N ... → ∫_0^∞ ...` (через dominated convergence / `tendsto_integral_Icc_atTop` и `‖(x+z)⁻³‖ ≤ (x + Re z)⁻³`).

И получаешь:
\[
\psi(z)=\log z-\frac1{2z}-\int_0^\infty\frac{\mathrm{B2Diff}(x)}{(x+z)^3}\,dx
\]
=> требуемая формула.

---

## 2. Lean‑friendly леммы, которые прям “закрывают” твой statement

Ниже — набор лемм и код‑скелет, который удобно вставлять в `Q3/DigammaRemainder.lean`. Я пишу так, чтобы было ясно, что доказывать; где конкретные `simp`‑леммы могут отличаться именем — помечаю комментариями.

### 2.1. Вспомогательные определения (B1)
```lean
namespace Q3
open scoped BigOperators
open MeasureTheory Complex

/-- B₁(t) = t - 1/2 -/
def bernoulli1 (t : ℝ) : ℝ := t - (1/2 : ℝ)

/-- B₁({x}) = fract x - 1/2 -/
def bernoulli1Fract (x : ℝ) : ℝ := bernoulli1 (Int.fract x)
```

### 2.2. Нули `bernoulli2Diff` на целых (нужно для исчезновения boundary terms)
У тебя уже есть `Int.fract_int : Int.fract (n:ℝ) = 0`.

Тогда:
```lean
lemma bernoulli2Diff_int (n : ℤ) : bernoulli2Diff (n : ℝ) = 0 := by
  -- unfold bernoulli2Diff bernoulli2
  -- simp [Int.fract_int]   -- bernoulli2 0 = 1/6
  simp [bernoulli2Diff, bernoulli2, Int.fract_int]
```

### 2.3. Локальная идентичность на интервале `(n,n+1)`:
`Int.fract x = x - n` и, следовательно, явный вид B1/B2Diff
Это “вся магия” с floor/fract, но она стандартная:

```lean
lemma fract_eq_sub_int_on_Ioo (n : ℤ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n+1 : ℝ)) :
    Int.fract x = x - n := by
  -- Int.fract_def : fract x = x - Int.floor x
  -- и на Ioo (n,n+1) имеем Int.floor x = n.
  -- обычно: have hfloor : Int.floor x = n := by
  --   exact (Int.floor_eq_iff ...).2 ⟨..., ...⟩  -- надо подобрать точную форму
  -- then simp [Int.fract, Int.fract_def, hfloor]
  ...
```

> Тут я специально оставляю `...`: именно **это место** у тебя локально решается 2–3 строками после того, как ты выберешь правильную лемму `Int.floor_eq_iff`/`Int.floor_eq_iff` из `Mathlib.Algebra.Order.Floor.Ring`. Дальше всё становится чисто полиномиальным.

После этого:
```lean
lemma bernoulli1Fract_eq (n : ℤ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n+1 : ℝ)) :
    bernoulli1Fract x = x - n - (1/2 : ℝ) := by
  simp [bernoulli1Fract, bernoulli1, fract_eq_sub_int_on_Ioo n hx]
```

И аналогично:
```lean
lemma bernoulli2Diff_eq (n : ℤ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n+1 : ℝ)) :
    bernoulli2Diff x = (x - n) - (x - n)^2 := by
  -- bernoulli2Diff = 1/6 - (t^2 - t + 1/6) = t - t^2
  simp [bernoulli2Diff, bernoulli2, fract_eq_sub_int_on_Ioo n hx, pow_two]
```

---

## 3. “Готовый” скелет главной леммы (что вставлять вместо axioms)

Ниже — **каркас** `digamma_stieltjes_identity` в том стиле, который реально доводится до `simp`‑финала.

```lean
/-- Main goal: Stieltjes N=1 identity for digamma on Re z > 0. -/
lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
  Q3.digamma z - Complex.log z + (1/2 : ℂ) * z⁻¹
    = - ∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3 := by
  classical

  /- Step 1: finite Euler–Maclaurin identity for S_N(z) = ∑_{n=0}^{N-1} 1/(z+n). -/
  have hEM :
      ∀ N : ℕ, 1 ≤ N →
        (∑ n in Finset.range N, (z + (n : ℂ))⁻¹)
          = (∫ x in Set.Icc (0:ℝ) (N:ℝ), ((x:ℂ) + z)⁻¹)
            + (1/2:ℂ) * (z⁻¹ - (z + (N:ℂ))⁻¹)
            - (∫ x in Set.Icc (0:ℝ) (N:ℝ),
                (bernoulli1Fract x : ℂ) * ((x:ℂ) + z)⁻²) := by
    intro N hN
    -- (A) split integral into sum over n=0..N-1 of ∫_{n}^{n+1}
    -- (B) on each interval use integration by parts with u(x)=x-n-1/2 and v(x)=(x+z)⁻¹
    -- (C) use bernoulli1Fract_eq on each interval to rewrite u
    -- (D) telescope boundary terms to get (1/2)*(1/z - 1/(z+N))
    ...
  
  /- Step 2: convert the B1 integral to bernoulli2Diff integral on [0,N]. -/
  have hB1_to_B2 :
      ∀ N : ℕ, 1 ≤ N →
        (∫ x in Set.Icc (0:ℝ) (N:ℝ),
            (bernoulli1Fract x : ℂ) * ((x:ℂ) + z)⁻²)
          = - (∫ x in Set.Icc (0:ℝ) (N:ℝ),
                (bernoulli2Diff x : ℂ) / ((x:ℂ) + z) ^ 3) := by
    intro N hN
    -- split into intervals [n,n+1] and do IBP with bernoulli2Diff (quadratic) and v=-1/2*(x+z)⁻²
    -- boundary terms vanish using bernoulli2Diff_int
    ...
  
  /- Step 3: evaluate ∫_0^N (x+z)⁻¹ = log(z+N) - log z -/
  have hint :
      ∀ N : ℕ, 1 ≤ N →
        (∫ x in Set.Icc (0:ℝ) (N:ℝ), ((x:ℂ) + z)⁻¹)
          = Complex.log (z + (N:ℂ)) - Complex.log z := by
    intro N hN
    -- FTC: derivative of x ↦ log ((x:ℂ)+z) is ((x:ℂ)+z)⁻¹ on [0,N]
    -- use hz : 0 < Re z to stay in right half-plane
    ...
  
  /- Step 4: assemble finite identity in the “B2Diff” form. -/
  have hFinite :
      ∀ N : ℕ, 1 ≤ N →
        (∑ n in Finset.range N, (z + (n:ℂ))⁻¹)
          = Complex.log (z + (N:ℂ)) - Complex.log z
            + (1/2:ℂ) * (z⁻¹ - (z + (N:ℂ))⁻¹)
            + (∫ x in Set.Icc (0:ℝ) (N:ℝ),
                (bernoulli2Diff x : ℂ) / ((x:ℂ)+z)^3) := by
    intro N hN
    -- start from hEM, rewrite integral via hint, rewrite B1 integral via hB1_to_B2, ring_nf
    ...
  
  /- Step 5: take limit N→∞ using digamma limit formula. -/
  have hdigamma_lim :
      Tendsto (fun N : ℕ => (Complex.log (N:ℂ)) - ∑ n in Finset.range N, (z + (n:ℂ))⁻¹)
        atTop (𝓝 (Q3.digamma z)) := by
    -- this is the “digamma = lim (log N - sum 1/(z+n))” lemma
    -- either already exists in your Stage 1/2 (best!), or prove from digamma series + harmonic_sub_log → γ
    ...
  
  -- Now push tendsto through the finite identity:
  -- log N - (log(z+N) - log z + 1/(2z) - 1/(2(z+N)) + ∫_0^N ...)
  -- → log z - 1/(2z) - ∫_0^∞ ...
  have hlog :
      Tendsto (fun N : ℕ => Complex.log (N:ℂ) - Complex.log (z + (N:ℂ)))
        atTop (𝓝 (0:ℂ)) := by
    -- use: (z+N)/N → 1 and continuity of log near 1 in right half-plane
    ...
  
  have hinv :
      Tendsto (fun N : ℕ => (1/2:ℂ) * (z + (N:ℂ))⁻¹) atTop (𝓝 0) := by
    -- because (z+N)⁻¹ → 0
    ...
  
  have hinterr :
      Tendsto (fun N : ℕ =>
        ∫ x in Set.Icc (0:ℝ) (N:ℝ), (bernoulli2Diff x : ℂ) / ((x:ℂ)+z)^3)
      atTop (𝓝 (∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / ((x:ℂ)+z)^3)) := by
    -- use integrability dominated by (x + z.re)^(-3) and standard lemma tendsto_integral_Icc_atTop
    ...
  
  -- Finally, take limits in:
  -- digamma z = lim (log N - sum) = lim [log N - log(z+N) + log z - 1/(2z) + 1/(2(z+N)) - ∫_0^N ...]
  -- rearrange to desired equality
  ...
```

---

## 4. Где конкретно “быстро закрывается” (что у тебя уже есть)

Судя по твоим апдейтам:
- `integral_kernel_eq` уже закрыт;
- `0 ≤ bernoulli2Diff ≤ 1/4` закрыто;
- tail bounds уже закрыты;
- Stage 1/2 gives digamma series machinery.

Значит **реально** остались только “комбинаторные”/FTC‑части:
1) финитный Euler–Maclaurin для `∑ (z+n)⁻¹`;
2) превращение `B1`→`B2Diff`;
3) аккуратный `tendsto` для интеграла `[0,N] → [0,∞)`.

И это именно те три блока, которые я разложил выше.

---

## 5. Если хочешь “ещё быстрее”: минимально‑достаточная версия
Если тебе *строго* нужна только **оценка остатка** (а не полная идентичность), то можно формально доказать только неравенство:
\[
\Big\|\psi(z)-\log z+\frac1{2z}\Big\|
\le \frac14 \int_0^\infty \frac{dx}{|x+z|^3},
\]
и дальше уже твоим `integral_kernel_eq` получить `≤ 1/(4|z|^2)`.

Но ты просишь именно равенство — ок.

---

## 6. Что я бы сделал “самым быстрым способом закрытия Q3” в твоём проекте

1) **Сделать отдельный файл** `Q3/StieltjesN1_sum_inv.lean`:
   - доказать `hEM` и `hB1_to_B2` (финитные версии) как отдельные леммы.
2) В `Q3/DigammaRemainder.lean`:
   - импортнуть эти леммы и завершить `digamma_stieltjes_identity` чисто лимитом.
3) Всё downstream (tail bound, A3 floor) у тебя уже едет.

---

Если ты скинешь (копипастой сюда) *текущий* кусок `Q3/DigammaRemainder.lean` вокруг места, где ты пытался писать `digamma_stieltjes_identity`, я подгоню именно под твою инфраструктуру:
- где у тебя `Set.Icc` vs `intervalIntegral`,
- какие у тебя уже есть леммы типа `digamma_eq_lim`/`digammaSeq_tendsto`,
- и какие `simp`‑атрибуты для `Int.fract`/`Int.floor` уже доступны.

Но даже без этого: выше — рабочий, формализуемый маршрут, без `logGamma` и без новых аксиом.

## USER
Hi! Please take PROSHKA_REQUEST_7.md as the single source of truth.
We need a Lean proof of:

lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
  Q3.digamma z - Complex.log z + (1/2:ℂ) * z⁻¹
    = - ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3

Important constraints:
- Do NOT use logGamma or log ∘ Gamma.
- No new axioms/sorry/exact?.
- Prefer finite‑N Stieltjes/Euler–Maclaurin N=1 on [n,n+1], then N→∞.

Please return Lean code that compiles, either as a patch/snippet or as a file.
If you introduce helper lemmas, include them in the same response.

## ASSISTANT
Ок, вижу картину. Сейчас единственная «узкая» точка — *чистая* Stieltjes/Euler–Maclaurin‑N=1 идентичность для `digamma` без `log ∘ Gamma`, чтобы окончательно убрать старый DLMF‑axiom. Это ровно то, что ты описал: «finite‑N на [n,n+1] + предел N→∞». Это реально самый быстрый/надежный путь в Lean, потому что:
- мы работаем **только с рациональными функциями** `1/(x+z)^k` и кусочно‑полиномиальными Bernoulli‑термами;
- никаких ветвей `Complex.log (Gamma z)` и доказательств `Gamma z ∈ slitPlane` не надо.

Ниже даю **Lean‑friendly сертификат**: точная математическая цепочка + «как резать на леммы» + готовые куски кода для тех двух “Lean bits” (tendsto и sqrt‑оценка), и **скелет основной леммы** в стиле «вставил в `Q3/DigammaRemainder.lean` и добил 2–3 локальных места» (без `sorry` я не могу гарантировать компиляцию у тебя локально, потому что я не вижу текущие имена лемм из твоих файлов `Q3.Basic.Defs`, но структура и все ключевые шаги — те, что реально закрываются).  
Аномалия: текущий `PROSHKA_REQUEST_7.md` у тебя описывает план через `logGamma_stieltjes_N1` и `logGamma_hasDerivAt` fileciteturn0file4, но ты просишь **строго без logGamma**; ниже даю именно этот “logGamma‑free” маршрут.

---

## 0. Теорема и статус

**Утверждение (Stieltjes N=1 remainder для digamma, logGamma‑free):**  
Для любого `z : ℂ` с `0 < Re(z)` верно
\[
\psi(z)-\log z+\frac1{2z} \;=\; -\int_{0}^{\infty}\frac{B_2 - B_2(\{x\})}{(x+z)^3}\,dx,
\]
где \(B_2(t)=t^2-t+\tfrac16\) и \(\{x\}=\mathrm{fract}(x)\in[0,1)\).  
В ваших обозначениях:
```lean
Q3.digamma z - Complex.log z + (1/2:ℂ) * z⁻¹
  = - ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3
```

**Статус:** стандартный анализ/комплексный анализ; в Lean реализуемо через FTC на каждом `[n,n+1]` + предел.

---

## 1. Формально: объекты/гипотезы/форма

- Объект: `z : ℂ`
- Гипотеза: `hz : 0 < z.re`
- Интеграл: Лебег по `ℝ` на `Set.Ioi 0`
- Никаких ветвевых условий на `Gamma` (и вообще без `log ∘ Gamma`)

---

## 2. Определения и нотация

У вас уже есть (см. текущий `DigammaRemainder.lean` и заметки) fileciteturn0file12:

- `bernoulli2 (t:ℝ) = t^2 - t + 1/6`
- `bernoulli2Diff (x:ℝ) = 1/6 - bernoulli2 (Int.fract x)`
- Важно: `bernoulli2Diff x = fract(x)*(1-fract(x))` (у тебя уже есть лемма `bernoulli2Diff_eq_mul` и bounds).

Добавь (если нет):
- `bernoulli1Diff x := Int.fract x - (1/2:ℝ)` — это “B1(fract x)” на каждом unit‑интервале.

---

## 3. Зависимости (что реально нужно)

Минимальный набор:

1) **FTC на интервале** (удобнее через `intervalIntegral.integral_deriv_eq_sub` или эквивалент), примененный к двум функциям:
- \(G_n(x) = \frac{x-(n+\frac12)}{x+z}\)
- \(F(x) = \frac{B_2-\!B_2(\{x\})}{2(x+z)^2} = \frac{\texttt{bernoulli2Diff}(x)}{2(x+z)^2}\)

2) Кусочно‑формулы для `Int.fract` на \(x\in(n,n+1)\): там `Int.floor x = n`, значит `fract x = x-n`. Это нужно только для леммы о производной `bernoulli2Diff` на `(n,n+1)`.

3) Пределы:
- `(fun N => (z + (N:ℂ))⁻¹)` на `atTop` → `0` (элементарно)
- `∫_{(0,N]}` → `∫_{(0,∞)}` для интегрируемой функции (есть готовые леммы в `MeasureTheory`, либо делается через dominated convergence).
- `digammaSeq z N` → `digamma z` (у вас уже есть “digammaSeq → digamma” пайплайн; это критично).

---

## 4. Roadmap (коротко)

1) На каждом `[n,n+1]` вывести “трапецоидное” тождество:
   \[
   \int_n^{n+1}\frac{dx}{x+z}
   =\frac12\Big(\frac1{z+n}+\frac1{z+n+1}\Big)
   -\int_n^{n+1}\frac{\{x\}-1/2}{(x+z)^2}\,dx.
   \]
2) На каждом `[n,n+1]` вывести “B1→B2”:
   \[
   \int_n^{n+1}\frac{\{x\}-1/2}{(x+z)^2}\,dx
   =-\int_n^{n+1}\frac{B_2-\!B_2(\{x\})}{(x+z)^3}\,dx
   \]
   через FTC для \(x\mapsto \frac{B_2-\!B_2(\{x\})}{2(x+z)^2}\); граничные члены 0, т.к. `fract n=0`.
3) Суммировать по `n=0..N-1` → финитная формула:
   \[
   \sum_{k=0}^{N-1}\frac1{z+k}
   =\log(z+N)-\log z +\frac1{2z}-\frac1{2(z+N)}
     +\int_0^N\frac{B_2-\!B_2(\{x\})}{(x+z)^3}\,dx.
   \]
4) Переписать как формулу для `digammaSeq` (которая у вас определена как `log(z+N) - ∑_{k<N} 1/(z+k)`), взять предел `N→∞`:
   - `digammaSeq → digamma`
   - `1/(z+N) → 0`
   - `∫_0^N → ∫_0^∞`  
   Получить целевое равенство.

---

## 5. Две “Lean bits” (то, что ты просил по kernel‑proof)

### 5.1 Tendsto `1/(x+σ)^2 → 0` (чистая цепочка)

```lean
open scoped Topology
open Filter

lemma tendsto_one_div_add_sq_atTop (σ : ℝ) :
    Tendsto (fun x : ℝ => 1 / (x + σ)^2) atTop (𝓝 (0 : ℝ)) := by
  -- use: (x+σ)^2 → ∞, then inv → 0
  have h1 : Tendsto (fun x : ℝ => (x + σ)^2) atTop atTop := by
    -- (x+σ) → ∞, then square → ∞
    have : Tendsto (fun x : ℝ => x + σ) atTop atTop := by
      simpa [add_comm, add_left_comm, add_assoc] using (tendsto_add_const_atTop_iff (a := σ))
      -- If this lemma name doesn't match in your Mathlib: use `tendsto_atTop_add_const_right`.
    exact (tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1:ℕ) < 2) this)
  -- now invert
  simpa [one_div] using (tendsto_inv_atTop_zero.comp h1)
```

**Примечание:** имена `tendsto_add_const_atTop_iff`/`tendsto_atTop_add_const_right` могут отличаться; концепт: `(fun x => x+σ)` `atTop→atTop`, затем `pow`, затем `tendsto_inv_atTop_zero`.

### 5.2 Оценка `sqrt((x+σ)^2+τ^2) ≥ x+σ`

Lean‑стиль:

```lean
lemma sqrt_sq_add_le (x σ τ : ℝ) (hx : 0 ≤ x) (hσ : 0 < σ) :
    x + σ ≤ Real.sqrt ((x + σ)^2 + τ^2) := by
  have hxσ : 0 ≤ x + σ := by nlinarith [hx, hσ.le]
  -- use: (x+σ)^2 ≤ (x+σ)^2 + τ^2
  have hsq : (x + σ)^2 ≤ (x + σ)^2 + τ^2 := by nlinarith
  -- lemma name you want: `Real.le_sqrt_of_sq_le`
  exact Real.le_sqrt_of_sq_le hxσ hsq
```

И сразу из этого:

```lean
lemma inv_prod_sqrt_le_inv_sq (x σ τ : ℝ) (hx : 0 ≤ x) (hσ : 0 < σ) :
    1 / (Real.sqrt ((x+σ)^2 + τ^2) * (Real.sqrt ((x+σ)^2 + τ^2) + (x+σ)))
      ≤ 1 / (x+σ)^2 := by
  have hA : x+σ ≤ Real.sqrt ((x+σ)^2 + τ^2) := sqrt_sq_add_le x σ τ hx hσ
  have hxσ : 0 < x+σ := by nlinarith [hx, hσ]
  have hpos1 : 0 < Real.sqrt ((x+σ)^2 + τ^2) := lt_of_lt_of_le hxσ hA
  have hpos2 : 0 < Real.sqrt ((x+σ)^2 + τ^2) + (x+σ) := by nlinarith [hpos1, hxσ]
  -- lower bound for denominator:
  have hden : (x+σ)^2 ≤ Real.sqrt ((x+σ)^2 + τ^2) * (Real.sqrt ((x+σ)^2 + τ^2) + (x+σ)) := by
    -- use monotonicity: sqrt ≥ x+σ and (sqrt+(x+σ)) ≥ (x+σ)
    have hB : x+σ ≤ Real.sqrt ((x+σ)^2 + τ^2) + (x+σ) := by nlinarith [hA]
    nlinarith [hA, hB]
  -- invert inequality
  have hposDen : 0 < Real.sqrt ((x+σ)^2 + τ^2) * (Real.sqrt ((x+σ)^2 + τ^2) + (x+σ)) := by
    nlinarith [hpos1, hpos2]
  have hposSq : 0 < (x+σ)^2 := by nlinarith [hxσ]
  exact one_div_le_one_div_of_le hposSq (by simpa using hden)
```

---

## 6. Основная лемма `digamma_stieltjes_identity`: как резать в Lean

### Ключевой “сертификат” (финитный шаг)

Вот точная финитная формула, которую надо сделать основной промежуточной леммой (в ℂ‑значных интегралах по ℝ):

\[
\sum_{k=0}^{N-1}\frac{1}{z+k}
=
\log(z+N)-\log z + \frac{1}{2z}-\frac{1}{2(z+N)}
+ \int_{0}^{N}\frac{\texttt{bernoulli2Diff}(x)}{(x+z)^3}\,dx.
\]

В Lean я бы делал так:

- Лемма A (`trap_unit_interval`): для каждого `n : ℕ` на `[n,n+1]`.
- Лемма B (`b1_to_b2_unit_interval`): на `[n,n+1]`.
- Лемма C (`sum_trap`): суммирование по `n=0..N-1` с телескопированием `log(z+n+1)-log(z+n)` и граничными членами.
- Лемма D (`digammaSeq_finite`): переписать в форме `digammaSeq z N = ...`.
- Лемма E (`tendsto_integral_trunc`): `∫_{(0,N]}` → `∫_{(0,∞)}`.
- Финал: `tendsto_digammaSeq` + `tendsto_inv` + `tendsto_integral_trunc`.

### Практический “patch‑skeleton” (вставка в `Q3/DigammaRemainder.lean`)

Ниже — скелет, который обычно “садится” в проект сразу. Тебе останется:
1) подправить имена 1–2 готовых лемм про `intervalIntegral`/`tendsto_integral_Ioc` (если у вас другие),
2) подключить правильное имя вашей леммы `tendsto_digammaSeq` (она точно есть, раз “digammaSeq → digamma” уже используется).

```lean
import Mathlib
import Q3.Basic.Defs

open scoped Real Topology BigOperators
open Filter MeasureTheory Real

noncomputable section
namespace Q3

/-- B1(fract x) = fract x - 1/2. -/
def bernoulli1Diff (x : ℝ) : ℝ := Int.fract x - (1/2 : ℝ)

-- You already have `bernoulli2Diff_eq_mul` and bounds.

/-- On each unit interval, FTC for `x ↦ (x-(n+1/2))/(x+z)` gives trapezoid identity. -/
lemma trap_unit_interval (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    (∫ x in Set.Ioc (n : ℝ) (n+1 : ℝ), (1 : ℂ) / (x + z))
      =
    (1/2:ℂ) * ((1 / (z + n)) + (1 / (z + (n+1))))
      - ∫ x in Set.Ioc (n : ℝ) (n+1 : ℝ), (bernoulli1Diff x : ℂ) / (x+z)^2 := by
  -- Recommended: use intervalIntegral over (n)..(n+1) and then switch to Set.Ioc by aeEq.
  -- Define G(x) = (x - (n+1/2)) / (x+z), prove HasDerivAt on Ioo, apply FTC:
  --   ∫ G' = G(b)-G(a).
  -- Then rearrange.
  --
  -- In the derivative, `x-(n+1/2)` is exactly `bernoulli1Diff x` on Ioc(n,n+1)
  -- because on that interval `Int.fract x = x-n`. Use `Int.floor_eq_iff` to rewrite.
  --
  -- (This is the one place where you do piecewise-floor reasoning.)
  --
  -- After that, it is pure algebra + simp.
  admit  -- <-- you must fill; don't keep `admit` in final!

/-- On each unit interval, FTC for `x ↦ bernoulli2Diff x / (2*(x+z)^2)` gives B1→B2. -/
lemma b1_to_b2_unit_interval (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    (∫ x in Set.Ioc (n : ℝ) (n+1 : ℝ), (bernoulli1Diff x : ℂ) / (x+z)^2)
      =
    - ∫ x in Set.Ioc (n : ℝ) (n+1 : ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3 := by
  -- Define F(x) = (bernoulli2Diff x) / (2*(x+z)^2).
  -- On Ioo(n,n+1): (bernoulli2Diff)' = -2*bernoulli1Diff.
  -- Also (1/(2*(x+z)^2))' = -(x+z)^(-3).
  -- So F' = -(bernoulli1Diff)/(x+z)^2 - (bernoulli2Diff)/(x+z)^3.
  -- Apply FTC on (n,n+1), boundary terms vanish because bernoulli2Diff(integer)=0.
  admit

/-- Summed finite-N identity on (0,N]. -/
lemma sum_inv_eq_log_plus_integral (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    (∑ k in Finset.range N, (1 : ℂ) / (z + k))
      =
    Complex.log (z + (N : ℂ)) - Complex.log z
      + (1/2:ℂ) * z⁻¹ - (1/2:ℂ) * (z + (N : ℂ))⁻¹
      + ∫ x in Set.Ioc (0 : ℝ) (N : ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3 := by
  -- Sum trap_unit_interval for n=0..N-1, telescope the log integral:
  -- ∫ (1/(x+z)) over Ioc(0,N) = log(z+N)-log(z)
  -- and use b1_to_b2_unit_interval to rewrite the B1 integral as -B2 integral.
  admit

/-- Final: take N→∞ using digammaSeq → digamma. -/
lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
    Q3.digamma z - Complex.log z + (1/2:ℂ) * z⁻¹
      = - ∫ x in Set.Ioi (0:ℝ), (bernoulli2Diff x : ℂ) / (x+z)^3 := by
  -- 1) Start from finite identity and rewrite into digammaSeq form:
  --    digammaSeq z N = log(z+N) - ∑_{k<N} 1/(z+k).
  -- 2) Take Tendsto as N→∞:
  --    digammaSeq z N → digamma z   (existing lemma in your project)
  --    (z+N)⁻¹ → 0                  (elementary)
  --    ∫_{(0,N]} → ∫_{(0,∞)}       (integrable kernel; dominated convergence)
  admit

end Q3
```

Да, тут стоят `admit` — **это маркеры мест**, где нужен ваш локальный API по `intervalIntegral`/`ae_eq_of_subset` и (главное) имя леммы про `digammaSeq → digamma`. Я *не* могу честно гарантировать “без единого admit” без доступа к вашему текущему `Q3.Basic.Defs` и уже имеющимся helper‑леммам (особенно для телескопирования и перехода `Set.Ioc` ↔ `intervalIntegral`).  
Но сама структура — та, которую реально закрывают за вечер в Lean, и она полностью соответствует “finite‑N + N→∞” без logGamma.

Если хочешь **сразу закрыть без pain**, я бы делал так:
- `trap_unit_interval` и `b1_to_b2_unit_interval` писать через `intervalIntegral` (где есть FTC и `integral_deriv_eq_sub`) и в конце `simp`‑ом заменить на `∫ x in Set.Ioc ...` используя `ae_eq_of_subset`/“measure of endpoints = 0”.
- `sum_inv_eq_log_plus_integral` — чистая алгебра + `Finset.sum_range` + телескопирование.
- В `digamma_stieltjes_identity`: опираешься на уже имеющийся `tendsto_digammaSeq` (у вас это точно есть по пайплайну “digammaSeq → digamma”).

---

## 7. “Самый быстрый план закрытия проекта” (в терминах твоей схемы)

1) **Закрыть `integral_kernel_eq`** (у тебя сейчас WIP) — это механическая аналитика; две “Lean bits” выше уже закрывают 80% боли. Далее остаётся:
   - split `τ=0`/`τ≠0`,
   - `integral_Ioi_of_hasDerivAt_of_tendsto'` для примитива.
2) **Вместо DLMF‑axiom** — добавить `digamma_stieltjes_identity` + простую bound‑лемму:
   - `|bernoulli2Diff| ≤ 1/4` (у вас уже `bernoulli2Diff_bounds`),
   - `∫ |x+z|^{-3} ≤ 1/(|z|(|z|+Re z)) ≤ 1/|z|^2` (kernel lemma).
   Это даёт вашу новую remainder‑оценку `≤ 1/(4|z|^2)` и дальше ваш хвост `log(1+ξ^2)+1/10` точно идёт тем же путём (см. “Consequences” в summary) fileciteturn0file12.
3) После этого **Stage 3 становится unconditional** → вся A3_FLOOR цепочка unconditional → дальше можно идти по Weil‑пайплайну.

---

Если ты хочешь, чтобы я реально “прибил” эти `admit`‑места до конца, мне нужен один кусок: *как именно в вашем коде называется лемма `digammaSeq → digamma` и как у вас определён `digammaSeq`* (1–2 строки из `Q3.Basic.Defs`). Тогда я могу дать уже **конкретный** final‑код без дыр под ваши имена/конверсии (и без logGamma).

