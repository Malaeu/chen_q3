# Proshka Briefing A1

https://chat.openai.com/c/6966ba7f-97dc-8330-8096-46e1d6d9faae

## USER
# PROSHKA BRIEFING — A1_density Definitional Issue (URGENT)

## USER
2. **h_approx** — approximation bound (needs triangle inequality chain)1. **hg_supp** — support containment (BLOCKED by definitional issue)## Two Remaining Sorries:✅ Zero case — handled via n=0 representation✅ hg_nonneg — nonnegativity (nonneg weights × nonneg atoms)✅ hg_even — evenness (atoms are even in x)  ✅ hg_cont — continuity of sum of atoms## What's Already Proven in A1_density.lean (807 lines):- The Fejér kernel F_B(x-τ) is nonzero when |x-τ| < B- But: Atom with center τ ∈ [-K, K] and width B ≤ K has support in `[-K-B, K+B] ⊆ [-2K, 2K]`- AtomCone_K requires: `support g ⊆ [-K, K]`**THE CONTRADICTION:**```  FejerKernel B (x + τ) * HeatKernel t (x + τ)  FejerKernel B (x - τ) * HeatKernel t (x - τ) +noncomputable def Atom (B t τ : ℝ) (x : ℝ) : ℝ :=```lean**Definition of Atom:**```       Q3.IsNonneg Φ}       Q3.IsEven Φ ∧       Function.support Φ ⊆ Set.Icc (-K) K ∧  {Φ | ContinuousOn Φ (Set.Icc (-K) K) ∧def W_K (K : ℝ) : Set (ℝ → ℝ) :=```lean**Definition of W_K:**We're proving: Fejér×heat atoms are dense in W_K (test functions).## The Problem: A1_density_WK_axiom- **Target:** Close remaining 4 Level-2 axioms- **Axiom count:** 11 (was 12, arch/prime Lipschitz bridges CLOSED)6-01-13)

## USER
- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
- c_* = 11/10 (A3 floor)## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
2. Complete proof sketch for the chosen option1. Mathematical analysis (which option is best)## Deliverables:- t_sym = 3/50 (symbol heat parameter)- C_SB = 4 (Szegő-Böttcher)- c_* = 11/10 (A3 floor)## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
- t_sym = 3/50 (symbol heat parameter)- C_SB = 4 (Szegő-Böttcher)- c_* = 11/10 (A3 floor)## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
3. Lean-style theorem statements2. Complete proof sketch for the chosen option1. Mathematical analysis (which option is best)## Deliverables:- t_sym = 3/50 (symbol heat parameter)- C_SB = 4 (Szegő-Böttcher)- c_* = 11/10 (A3 floor)## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
 Error bounds if truncation is used

## USER
1. Mathematical analysis (which option is best)## Deliverables:- t_sym = 3/50 (symbol heat parameter)- C_SB = 4 (Szegő-Böttcher)- c_* = 11/10 (A3 floor)## Constants:- The approximation uses: Φ ≈ Φ * H_t (heat smoothing) then Riemann sum discretization- Fejér kernel F_B(x) = max(0, 1 - |x|/B) — compact support [-B, B]- Heat kernel H_t(x) ∝ exp(-x²/4t) — decays Gaussian, technically infinite support but negligible outside [-C√t, C√t]## Key Mathematical Facts:4. **Provide Lean-ready lemma statements** for the chosen approach3. **For Option 3:** Design the truncation and bound the error2. **For Option 2:** Prove that atoms with B + |τ| ≤ K are still dense in W_K- Con: Loses some atoms,t in [-K,K]ves the density theorem

## USER
 Error bounds if truncation is used

## ASSISTANT
According to a document from **January 1, 2026**, твоя “support leak” — это не баг в доказательстве, а **ошибка в параметризации конуса**: в фиксированном‑\(t_0\) варианте плотности конус должен генерироваться атомами с **запасом до границы**  
\[
B>0,\qquad |\tau|+B\le K,
\]
а не просто \(\tau\in[-K,K]\) и \(B\le K\). Это ровно так сформулировано в Lemma 6.4 (Fixed‑\(t_0\) cone density).【116:4†RH_Q3.pdf†L63-L66】

Ниже — “досье” в твоём формате: что именно сломано, какое минимальное исправление, и как этим закрыть `hg_supp` и `h_approx`.

---

## 0. Теорема: Atom support fix для W_K — Статус
**Точная формулировка:**  
Для \(K>0\), если атом \(\mathrm{Atom}(B,t,\tau)\) использует Fejér‑hat ширины \(B>0\) (нулевой вне \(|x|\le B\)) и параметр удовлетворяет \(|\tau|+B\le K\), то
\[
\operatorname{supp}(\mathrm{Atom}(B,t,\tau))\subseteq [-K,K].
\]
Следовательно, всякая конечная неотрицательная комбинация таких атомов имеет поддержку в \([-K,K]\) и может лежать в \(W_K\) (в частности, снимается блокер `hg_supp`).

**Статус:** стандартная математика (ZFC), это чистая геометрия поддержки.

---

## 1. Формальное утверждение (в Lean‑смысле)
- **Объекты:** функции \( \Phi : \mathbb R \to \mathbb R\).  
- **Цель:** доказать `Function.support Φ ⊆ Set.Icc (-K) K`.
- **Логическая форма:**  
  \[
  \forall x,\ (x\notin[-K,K]\Rightarrow \Phi(x)=0).
  \]
  (Это эквивалентно `support ⊆` через стандартную лемму `support_subset_iff`/`support_subset_iff'`.)

---

## 2. Определения и нотация
- \(W_K\) в Lean у тебя включает требование `Function.support Φ ⊆ Icc (-K) K` (то есть **функции реально нулевые вне окна**).
- Атом (по твоему описанию) имеет вид “even symmetrization”:
  \[
  \mathrm{Atom}(B,t,\tau)(x)=
  \Lambda_B(x-\tau)\rho_t(x-\tau)\;+\;\Lambda_B(x+\tau)\rho_t(x+\tau),
  \]
  где \(\Lambda_B\) — Fejér‑hat (поддержка \(\subseteq[-B,B]\)), \(\rho_t\) — heat kernel (положительная, но это не важно для поддержки: она не обнуляет).  
- “Плохая” текущая параметризация: \(\tau\in[-K,K],\,B\le K\) ⇒ поддержка может попасть в \([-K-B,K+B]\subset[-2K,2K]\), что **не** равно \([-K,K]\).

---

## 3. Зависимости
Нужно только:
1) \(\Lambda_B(u)=0\) при \(|u|\ge B\).  
2) Неравенство: \(|x\pm\tau|\ge |x|-|\tau|\).  
3) Если \(|x|>K\) и \(|\tau|+B\le K\), то \(|x|-|\tau|>B\), значит \(|x\pm\tau|\ge B\).  

---

## 4. Roadmap
1) Исправить определение/параметры генераторов конуса: **вместо** “\(\tau\in[-K,K]\) и \(B\le K\)” использовать **маржу** \(|\tau|+B\le K\).  
2) Доказать лемму “атом нулевой вне \([-K,K]\)”.  
3) Для `hg_supp`: вне окна каждый слагаемый =0 ⇒ сумма =0 ⇒ `support ⊆ Icc`.  
4) Для `h_approx`: собрать оценку суп‑нормы через треугольник (это Step 4 в бумаге).【116:4†RH_Q3.pdf†L32-L44】

---

## 5. Леммы

### Лемма 1. Правильное ограничение параметров (сигнал‑аномалия)
**Феномен/аномалия:** “support вылезает на ±B”.  
**Измерение:** при \(\tau\approx K\) поддержка \([\tau-B,\tau+B]\) даёт правый хвост \(K+B\).  
**Решение:** добавь запас: \(\tau+B\le K\) и \(-K\le \tau-B\), то есть
\[
|\tau|+B\le K.
\]
Это именно то условие, которое используется в фикс‑\(t_0\) плотности (Lemma 6.4): атомы берутся с \(|\tau|+B\le K\).【116:4†RH_Q3.pdf†L63-L66】

**Применение:** это условие прямо “разблокирует” `hg_supp`.

---

### Лемма 2. Atom support inside window
**Формулировка:** Пусть \(B>0\) и \(|\tau|+B\le K\). Тогда при любом \(x\notin[-K,K]\) имеем \(\mathrm{Atom}(B,t,\tau)(x)=0\).

**Доказательство:**
1) Возьми \(x\notin[-K,K]\). Тогда \(|x|>K\).  
2) Из \(|\tau|+B\le K\) следует \(B\le K-|\tau|\).  
3) Тогда \(|x|-|\tau|>K-|\tau|\ge B\).  
4) По треугольнику: \(|x\pm\tau|\ge |x|-|\tau|>B\), значит \(|x\pm\tau|\ge B\).  
5) Следовательно, \(\Lambda_B(x\pm\tau)=0\). Значит оба слагаемых в атоме равны 0, и \(\mathrm{Atom}(B,t,\tau)(x)=0\). ∎

---

### Лемма 3. Support of finite sum
Если \(g=\sum_i c_i\,\mathrm{Atom}(B_i,t,\tau_i)\), \(c_i\ge0\), и для всех \(i\) выполнено \(|\tau_i|+B_i\le K\), то \(g(x)=0\) при \(x\notin[-K,K]\) (потому что каждое слагаемое нулевое), значит  
\(\operatorname{supp}(g)\subseteq[-K,K]\). ∎

---

## 6. Основное “исправление” в Lean

### 6.1 Минимальный патч: **не трогай Atom**, трогай **AtomCone_K**
Тебе нужно заменить генераторные условия на “маржинальные”:

- Было (условно):  
  `τ ∈ Icc (-K) K` и `B ≤ K`
- Должно быть (правильно для W_K):  
  `0 < B` и `|τ| + B ≤ K` (эквивалентно `τ ∈ Icc (-K + B) (K - B)` при `0 ≤ B`)

Это ровно соответствует бумажной формулировке фикс‑\(t_0\) конуса.【116:4†RH_Q3.pdf†L63-L66】

### 6.2 Как именно закрыть `hg_supp`
**Стратегия в Lean:** доказывай `support ⊆ Icc (-K) K` через “вне окна функция = 0”.

Скелет (подставь свои имена лемм про Fejér):
```lean
-- Предикат "атом допустим в окне"
def GoodShift (K B τ : ℝ) : Prop := 0 < B ∧ |τ| + B ≤ K

lemma atom_eq_zero_of_not_mem_Icc
    {K B t τ x : ℝ} (h : GoodShift K B τ) (hx : x ∉ Set.Icc (-K) K) :
    Atom B t τ x = 0 := by
  -- 1) из hx получаем |x| > K
  have hxabs : K < |x| := by
    -- стандартное преобразование `x ∉ Icc` -> (x < -K ∨ K < x) -> K < |x|
    sorry
  -- 2) получаем B ≤ |x ± τ|
  have hB : B ≤ |x| - |τ| := by
    -- из h.2 : |τ| + B ≤ K и hxabs : K < |x|
    -- вывод: B < |x| - |τ|, значит B ≤ ...
    sorry
  have hxmt : B ≤ |x - τ| := le_trans hB (by simpa [sub_eq_add_neg] using (abs_sub_abs_le_abs_sub _ _).trans? ) -- по сути |x-τ| ≥ |x|-|τ|
  have hxpt : B ≤ |x + τ| := le_trans hB (by simpa using (abs_add _ _)) -- |x+τ| ≥ |x|-|τ|
  -- 3) FejerKernel = 0 если B ≤ |·|
  -- 4) simp [Atom, FejerKernel_eq_zero_of_abs_ge ..., hxmt, hxpt]
  sorry

lemma hg_supp ... :
  Function.support h_g ⊆ Set.Icc (-K) K := by
  -- `support_subset_iff` и pointwise =0 вне окна
  refine (Function.support_subset_iff).2 ?_
  intro x hx
  -- вне окна каждый атом =0 -> сумма =0
  -- simp [h_g, atom_eq_zero_of_not_mem_Icc ...]
  sorry
```

Главная идея: **вне окна каждый атом ноль ⇒ сумма ноль**. Это самый “дешёвый” путь: никаких тяжёлых лемм про support‑algebra.

---

## 7. `h_approx`: треугольник уже прямо в бумаге
В бумажном доказательстве это обозначено как Step 4: собираем ошибки тройным треугольником
\[
\sup_{|ξ|\le R}|h-f|\le \sup|h-g_R^{sym}| + \sup|g_R^{sym}-g| + \sup|g-f| < \varepsilon.
\]
【116:4†RH_Q3.pdf†L32-L44】

То есть Lean‑цель `h_approx` закрывается так:

1) получаешь pointwise:
\[
|h(x)-f(x)| \le |h(x)-g_1(x)| + |g_1(x)-g_2(x)| + |g_2(x)-f(x)|.
\]
2) берёшь `sup` по \(x\in[-K,K]\) и используешь `sup_le_sup`/`csSup_le`‑стиль леммы.
3) подставляешь твои уже имеющиеся оценки каждого супа \(< \varepsilon/3\).

Lean‑скелет (идея):
```lean
have tri_pointwise (x) :
    |h x - f x| ≤ |h x - gsymR x| + |gsymR x - g x| + |g x - f x| := by
  -- два раза `by nlinarith [abs_sub_le ...]` или `calc` с `abs_sub_le`
  sorry

have tri_sup :
    supOnIcc (fun x => |h x - f x|)
      ≤ supOnIcc (fun x => |h x - gsymR x|)
        + supOnIcc (fun x => |gsymR x - g x|)
        + supOnIcc (fun x => |g x - f x|) := by
  -- `refine sup_le ?_` и применить tri_pointwise
  sorry

-- дальше: три уже доказанные ε/3 bound -> ε
```

---

## 8. Edge check
- **Граница τ≈±K**: это и есть причина провала. Лечится только “маржой” \(|\tau|+B\le K\) (или эквивалентом \(\tau\in[-K+B,K-B]\)).  
- **HeatKernel не портит поддержку**: произведение с Fejér‑hat остаётся нулём там, где hat ноль.  
- **Если не хочешь менять определение AtomCone_K (плохой вариант):** можно временно перейти на \(W_{2K}\), потому что ты реально доказываешь поддержку в \([-2K,2K]\). Но это потянет K‑shift по всему пайплайну, и это хуже, чем аккуратно поправить параметры.

---

## Практический бонус: у тебя уже где-то есть “правильный” Lean‑вариант
В task‑трекере явно отмечено, что **A1_density_final** закрыт и есть компилируемый файл `A1_density_final_aristotle.lean`.【108:11†ARISTOTLE_TASKS.md†L5-L12】【108:11†ARISTOTLE_TASKS.md†L29-L33】  
Если он у тебя в репо, сравни именно **условие на (B,τ)** — там почти наверняка уже стоит `|τ| + B ≤ K`.

---

### Файлы-источники (чтобы ты мог ткнуть и сверить формулировки)
Секция с Step 4 и Lemma 6.4 в pdf: fileciteturn3file4  
Спека Tier‑2 модулей: fileciteturn2file5  
Трекер с упоминанием `A1_density_final_aristotle.lean`: fileciteturn1file11

## ASSISTANT
## 0. Теорема: A1\_density — фиксация “support ⊆ [-K,K]” через truncation (выбор: Option 3)

**Точная формулировка (на уровне идеи):**  
Для любого \(K\ge 0\) и любой \(\Phi\in W_K\), если \(g\) аппроксимирует \(\Phi\) **равномерно на** \([-K,K]\), то функция
\[
\operatorname{trunc}_K(g)(x):=\begin{cases}
g(x), & x\in[-K,K],\\
0, & x\notin[-K,K]
\end{cases}
\]
лежит в \(W_K\) и аппроксимирует \(\Phi\) **равномерно на всей** \(\mathbb R\) с той же (или лучшей) ошибкой.

**Статус:** стандартная математика; это чисто дефиниционное исправление кодировки “функции на отрезке” как “функции на \(\mathbb R\) с support”.

---

## 1. Контекст и феномен (аномалия)

### Феномен (сигнал)
Ты сейчас доказываешь плотность конуса Fejér×heat-атомов в \(W_K\), где в Lean:

- \(W_K\subset (\mathbb R\to\mathbb R)\) включает условие  
  `Function.support Φ ⊆ Set.Icc (-K) K`.
- Атом (даже без heat-фактора по support) имеет поддержку порядка  
  \([-|τ|-B,\;|τ|+B]\).
- При твоих текущих ограничениях \(τ\in[-K,K], B\le K\) получаешь лишь  
  \(\mathrm{supp}(\mathrm{Atom})\subseteq[-2K,2K]\), но **не** \(\subseteq[-K,K]\).

Это не “матем. ошибка” в доказательстве плотности на отрезке — это **несовпадение моделей**:

- В тексте A1’ фактически работают в \(C^+_{\mathrm{even}}([-K,K])\) (функции *на отрезке* с \(\|\cdot\|_\infty\)).  
- В Lean ты закодировал то же как *глобальные* функции с `support ⊆ [-K,K]`.

### Измерение
- Локальная аппроксимация у тебя строится на \([-K,K]\).  
- Условие support в \(W_K\) требует глобального нуля вне \([-K,K]\).
- Отсюда блок `hg_supp`.

### Решение/применение
Надо добавить **одну стандартную операцию**: “обнуление вне компакта”.  
Это Option 3 (truncation). Она минимально вторгается в существующий Lean-скелет и не ломает остальные Tier-2 модули (A2 Lipschitz, closure), потому что все они уже живут на \(W_K\) с support-условием. А1’ по спекам действительно нужен при фиксированном \(t_{\mathrm{sym}}\). fileciteturn0file21

---

## 2. Анализ вариантов (что лучше)

### Option 1: “ослабить W_K / поменять support-условие”
- **Минус:** это потянет рефакторинг всего: A2 Lipschitz, Main_closure и т.д.  
- **Риск:** непредсказуемые новые дыры.
- **Вердикт:** плохо.

### Option 2: “ограничить параметры атомов: \(|τ|+B\le K\)”
- **Математически корректно** и даже естественно (в A1prime.tex у тебя уже явно фигурирует такая форма в fixed-\(t_0\) лемме).
- **Минус в Lean:** надо переписать дискретизацию/сетки у границы, аккуратно таскать \(|τ|+B\le K\) через все построения.
- **Вердикт:** возможно, но дороже в реализации.

### Option 3: “truncation (indicator)” — **лучший выбор**
- **Плюсы:**
  - Почти нулевой рефакторинг: ты оставляешь текущий `hg` как сумму атомов, *а потом* берёшь `trunc_K hg`.
  - `hg_supp` становится тривиальным.
  - Ошибка аппроксимации **не ухудшается**, а вне \([-K,K]\) вообще становится 0 (что идеально, ведь \(\Phi=0\) там из support-условия).
- **Вердикт:** берём Option 3.

---

## 3. План доказательства (Roadmap) для Option 3

1) Введи оператор truncation:
\[
\operatorname{trunc}_K(f)=\mathbf 1_{[-K,K]} \cdot f
\]
в Lean — через `Set.indicator (Set.Icc (-K) K) f`.

2) Замени в финальном шаге A1_density:
- вместо `hg` используешь `hgK := trunc K hg`.

3) Докажи для `hgK` четыре свойства \(W_K\):
- `support ⊆ Icc (-K) K` — автоматом,
- `ContinuousOn` на `Icc` — потому что на `Icc` trunc совпадает с `hg`,
- `IsEven` — из симметрии `Icc (-K) K` + evenness `hg`,
- `IsNonneg` — потому что trunc либо `hg x ≥ 0`, либо `0`.

4) Аппроксимация:
- на `Icc` ошибка та же: `hgK = hg`,
- вне `Icc` ошибка ноль, т.к. \(\Phi=0\) (из `support Φ ⊆ Icc`).

5) (Если нужно для “cone membership”) покажи, что trunc линейна:
\[
\operatorname{trunc}(f+g)=\operatorname{trunc}(f)+\operatorname{trunc}(g),\quad
\operatorname{trunc}(c\cdot f)=c\cdot \operatorname{trunc}(f)
\]
=> `hgK` — конечная неотрицательная комбинация **truncated-atoms**.

---

## 4. Полный proof sketch (как закрыть оба оставшихся sorry)

### 4.1. Закрываем `hg_supp` (BLOCKED сейчас)
**Новая конструкция:**
- Пусть твой текущий аппроксимант:  
  `hg : ℝ → ℝ := ∑ j, w j * Atom (B j) t_sym (τ j)`
- Определи
  \[
  hg_K := \operatorname{trunc}_K(hg).
  \]

**Тогда:**
- По определению truncation, \(hg_K(x)=0\) при \(x\notin[-K,K]\).
- Следовательно `Function.support hg_K ⊆ Set.Icc (-K) K`.

Это в Lean делается одной леммой `support_indicator_subset`.

### 4.2. Закрываем `h_approx` (triangle inequality chain)
Ты уже построил цепочку аппроксимаций (по твоему описанию):
\[
\Phi \approx g \approx g_R \approx h \quad\text{на }[-K,K].
\]
Где (типично):
- \(g\) — “сглаженная/модифицированная” версия,
- \(g_R\) — положительная риманова сумма,
- \(h\) — Fejér×heat смесь (конечная сумма атомов), т.е. твой `hg`.

Тогда на \([-K,K]\):
\[
|h-\Phi|\le |h-g_R| + |g_R-g| + |g-\Phi|.
\]
Берёшь `sup` по \(x\in[-K,K]\), получаешь:
\[
\|h-\Phi\|_{\infty,[-K,K]}
\le \|h-g_R\|_{\infty,[-K,K]}+\|g_R-g\|_{\infty,[-K,K]}+\|g-\Phi\|_{\infty,[-K,K]}.
\]
Это и есть “triangle inequality chain”.

**Новый финальный ход с truncation:**
\[
hg_K := \operatorname{trunc}_K(h).
\]
Тогда глобально на \(\mathbb R\):
- если \(x\in[-K,K]\): \(hg_K(x)=h(x)\),
- если \(x\notin[-K,K]\): \(hg_K(x)=0=\Phi(x)\) (из `support Φ ⊆ Icc (-K) K`).

Значит:
\[
\|hg_K-\Phi\|_{\infty,\mathbb R}=\|h-\Phi\|_{\infty,[-K,K]}.
\]
И вся твоя уже-доказанная оценка на отрезке переносится на “глобальную” метрику, которая у тебя стоит в формулировке `W_K`.

---

## 5. Lean-style theorem statements (уровень “что в итоге должно стоять”)

Ниже — максимально Lean-friendly наброски. Твои имена (`Q3.IsEven`, `Q3.IsNonneg`, `W_K`) подставь как в файле.

### 5.1. Truncation definition

```lean
open Set

noncomputable def trunc (K : ℝ) (f : ℝ → ℝ) : ℝ → ℝ :=
  (Set.Icc (-K) K).indicator f
```

### 5.2. Вариант “атом в W_K”

```lean
noncomputable def AtomK (K B t τ : ℝ) : ℝ → ℝ :=
  trunc K (Atom B t τ)
```

### 5.3. Основная “density” цель (схематично)

```lean
-- примерная форма: для любого Φ ∈ W_K и ε>0 есть g в (конусе) с sup-ошибкой < ε
theorem A1_density_WK
  (t_sym : ℝ) (ht : 0 < t_sym) :
  ∀ {K : ℝ}, 0 ≤ K →
  ∀ {Φ : ℝ → ℝ}, Φ ∈ W_K K →
  ∀ ε : ℝ, 0 < ε →
    ∃ g : ℝ → ℝ, g ∈ AtomCone_K K t_sym ∧
      supNorm (fun x => |g x - Φ x|) < ε := by
  -- proof: build hg on Icc, then let g := trunc K hg
  sorry
```

(Тут `supNorm`/метрику подставь свою; я показываю структуру.)

---

## 6. Lean-ready lemma statements (минимальный пакет для Option 3)

### 6.1. База: indicator совпадает с f на set

```lean
lemma trunc_eq_on_Icc {K : ℝ} {f : ℝ → ℝ} :
  Set.EqOn (trunc K f) f (Set.Icc (-K) K) := by
  intro x hx
  simp [trunc, hx]
```

### 6.2. Support containment (закрывает hg_supp)

```lean
lemma support_trunc_subset (K : ℝ) (f : ℝ → ℝ) :
  Function.support (trunc K f) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- contrapositive: if x ∉ Icc then trunc=0, hence x ∉ support
  by_contra hxI
  have : trunc K f x = 0 := by
    simp [trunc, hxI]
  exact hx (by simpa [Function.support] using this)
```

*(Если `simp` ругнётся на `Function.support`, можно развернуть: `x ∈ Function.support g` ↔ `g x ≠ 0`.)*

### 6.3. ContinuousOn on Icc

```lean
lemma continuousOn_trunc {K : ℝ} {f : ℝ → ℝ}
  (hf : ContinuousOn f (Set.Icc (-K) K)) :
  ContinuousOn (trunc K f) (Set.Icc (-K) K) := by
  -- use congr on the set, since trunc=f on the set
  refine hf.congr ?_
  exact trunc_eq_on_Icc
```

### 6.4. Evenness preserved by truncation

Нужна симметрия `Icc (-K) K`:

```lean
lemma neg_mem_Icc_iff {K x : ℝ} (hK : 0 ≤ K) :
  (-x) ∈ Set.Icc (-K) K ↔ x ∈ Set.Icc (-K) K := by
  constructor <;> intro hx <;> rcases hx with ⟨hx1, hx2⟩
  · -- -x ∈ [-K,K] => x ∈ [-K,K]
    have : -K ≤ x := by linarith
    have : x ≤ K := by linarith
    exact ⟨this, this_1⟩
  · -- x ∈ [-K,K] => -x ∈ [-K,K]
    have : -K ≤ -x := by linarith
    have : -x ≤ K := by linarith
    exact ⟨this, this_1⟩
```

И сама evenness:

```lean
lemma isEven_trunc {K : ℝ} (hK : 0 ≤ K) {f : ℝ → ℝ}
  (hf : Q3.IsEven f) :
  Q3.IsEven (trunc K f) := by
  intro x
  by_cases hx : x ∈ Set.Icc (-K) K
  · have hnx : (-x) ∈ Set.Icc (-K) K := (neg_mem_Icc_iff (K:=K) (x:=x) hK).2 hx
    simp [trunc, hx, hnx, hf x]
  · have hnx : (-x) ∉ Set.Icc (-K) K := by
      -- from symmetry
      intro hnx'
      exact hx ((neg_mem_Icc_iff (K:=K) (x:=x) hK).1 hnx')
    simp [trunc, hx, hnx]
```

(Если `Q3.IsEven` у тебя определён как `∀ x, f (-x)=f x`, то proof ровно такой.)

### 6.5. Nonneg preserved

```lean
lemma isNonneg_trunc {K : ℝ} {f : ℝ → ℝ}
  (hf : Q3.IsNonneg f) :
  Q3.IsNonneg (trunc K f) := by
  intro x
  by_cases hx : x ∈ Set.Icc (-K) K
  · simp [trunc, hx, hf x]
  · simp [trunc, hx]
```

### 6.6. Key approximation lemma: truncation doesn’t worsen error (global)

Это “мост” между аппроксимацией на отрезке и глобальной нормой, когда цель имеет support ⊆ Icc.

```lean
lemma trunc_sub_eq_sub_on_Icc {K : ℝ} {f Φ : ℝ → ℝ}
  (hΦsupp : Function.support Φ ⊆ Set.Icc (-K) K) :
  Set.EqOn (fun x => trunc K f x - Φ x) (fun x => f x - Φ x) (Set.Icc (-K) K) := by
  intro x hx
  simp [trunc, hx]
```

И “вне отрезка разность = 0”:

```lean
lemma trunc_sub_eq_zero_off_Icc {K : ℝ} {f Φ : ℝ → ℝ}
  (hΦsupp : Function.support Φ ⊆ Set.Icc (-K) K) :
  ∀ x, x ∉ Set.Icc (-K) K → trunc K f x - Φ x = 0 := by
  intro x hx
  have hΦ : Φ x = 0 := by
    -- x ∉ Icc and support Φ ⊆ Icc => x ∉ support Φ => Φ x = 0
    have : x ∉ Function.support Φ := by
      intro hxSupp
      exact hx (hΦsupp hxSupp)
    simpa [Function.support] using this
  simp [trunc, hx, hΦ]
```

Дальше из этих двух лемм ты уже легко выводишь равенство/оценку для `sup`-нормы (в том виде, как она у тебя определена).

### 6.7. Линейность truncation (если надо для “cone membership”)

```lean
lemma trunc_add (K : ℝ) (f g : ℝ → ℝ) :
  trunc K (fun x => f x + g x) = fun x => trunc K f x + trunc K g x := by
  funext x
  by_cases hx : x ∈ Set.Icc (-K) K <;> simp [trunc, hx]

lemma trunc_smul (K c : ℝ) (f : ℝ → ℝ) :
  trunc K (fun x => c * f x) = fun x => c * trunc K f x := by
  funext x
  by_cases hx : x ∈ Set.Icc (-K) K <;> simp [trunc, hx]
```

---

## 7. Аудит: edge-cases / подводные камни

1) **Нужен `0 ≤ K`** (или `0 < K`) для симметрии `Icc (-K) K`.  
   Иначе `Icc (-K) K` может быть пустым/странным, и evenness-лемма потребует доп. ветку.

2) `ContinuousOn` — это continuity в относительной топологии отрезка.  
   Поэтому discontinuity на границе вне отрезка **не мешает**: truncation безопасна.

3) Если твоя “норма” реально глобальная `sup` по ℝ, то ключевой мост — что и \(\Phi\), и `trunc`-аппроксимант равны 0 вне `Icc`. Тогда глобальный `sup` редуцируется к `sup` на отрезке.

---

## 8. Итог (что делать прямо сейчас в A1_density.lean)

1) Добавь `trunc` (или используй прямо `Set.indicator`) и докажи 5–7 лемм из §6.  
2) Переопредели финальный `hg` как `hgK := trunc K hg`.  
3) `hg_supp` закрывается одной строкой через `support_trunc_subset`.  
4) `h_approx`:  
   - сначала закрываешь error chain на \([-K,K]\) (как у тебя задумано),  
   - потом “переносишь” на ℝ через леммы §6.6 (вне отрезка разность ноль).  
5) Если `AtomCone_K` у тебя требует **буквально** “равно сумме атомов” (без trunc), тогда просто поменяй генераторы на `AtomK` (truncated atoms). Это косметическая, но правильная правка: конус по-прежнему тот же “на отрезке”, и теперь он реально лежит в \(W_K\).

Если хочешь, я могу прямо под твою текущую сигнатуру `AtomCone_K`/`supNorm` переписать формулировки лемм из §6 в точных именах твоего файла (но даже без этого ты уже видишь, как закрыть оба sorries одним ходом).

## ASSISTANT
## 0. Теорема: исправление “A1_density support” через правильный параметрический класс

**Точная формулировка:**  
Для фиксированного \(K>0\) и \(t_0>0\), если в генераторах Fejér×heat-атомов требовать **ограничение параметров**
\[
|\tau|+B \le K,
\]
то (i) каждый атом имеет `Function.support ⊆ Icc (-K) K`, и (ii) конус, порождённый такими атомами (и even-sym), остаётся **плотным** в тестовом классе на окне \([-K,K]\). Это ровно “Fixed-\(t_0\) cone density” в тексте. 【171:12†RH_Q3.pdf†L23-L63】

**Статус:** стандартный анализ/аппроксимация (и совпадает с Lemma 6.4 документа).【171:12†RH_Q3.pdf†L23-L63】

---

## 1. Формальное утверждение (Lean-ориентированно)

### Универсум
Функции \(\Phi : \mathbb R \to \mathbb R\).

### Что ломается сейчас
Ты сейчас берёшь \(\tau \in [-K,K]\) и \(B \le K\). Тогда support атома попадает в \([-(K+B), K+B]\subseteq[-2K,2K]\), но **не обязательно** в \([-K,K]\). Это и блокирует `hg_supp`.

### Исправление
Вместо “\(\tau \in [-K,K]\) и \(B\le K\)” сделать **ровно то, что требует support**:
\[
|\tau| + B \le K.
\]
Это гарантирует, что обе шапки (в точках \(\pm\tau\)) целиком сидят внутри \([-K,K]\).

И это не убивает плотность: в документе прямо введён конус с таким ограничением и доказано, что он даёт всю \(C^+_{\mathrm{even}}([-K,K])\) при фиксированном \(t_0\).【171:12†RH_Q3.pdf†L23-L63】

---

## 2. Определения и нотация (что именно надо синхронизировать)

### Атом (как в тексте)
\[
\Phi_{B,t,\tau}(\xi) := \tfrac12\big[\Lambda_B(\xi-\tau)\rho_t(\xi-\tau) + \Lambda_B(\xi+\tau)\rho_t(\xi+\tau)\big],
\]
где \(\Lambda_B(x)=(1-|x|/B)_+\) и \(\rho_t\) — гаусс. 【171:9†RH_Q3.pdf†L39-L56】

В Lean у тебя аналогично (Atom B t τ x) как сумма двух сдвигов `FejerKernel B (x±τ) * HeatKernel t (x±τ)` (масштаб 1/2 роли не играет).

### Ключевой факт про support
Т.к. \(\rho_t(x)\neq 0\) для всех \(x\), **нулевость продукта определяется Fejér-фактором**:
\[
\Lambda_B(x\pm \tau)=0 \ \text{при}\ |x\pm\tau|\ge B.
\]
То есть support каждого слагаемого — в интервале \([\tau-B,\tau+B]\) (и симметрично для \(-\tau\)).

---

## 3. Зависимости (что нужно в Lean)

Минимальный набор:
1. Лемма “Fejér zero outside”: `|u| ≥ B → FejerKernel B u = 0` (или эквивалент через `mem_support`).  
2. Треугольное неравенство для `abs` (для `h_approx`): `|a-c| ≤ |a-b| + |b-c|`.  
3. Связка “support ⊆ S” ↔ “x∉S → f x = 0” (обычно `Function.support_subset_iff` или доказывается вручную через определение `Function.support` как `{x | f x ≠ 0}`).

---

## 4. Roadmap (как закрыть два sorries)

1. **Меняем определение генераторного класса AtomCone_K**: разрешаем только параметры `(B,τ)` с `|τ|+B ≤ K` (и `0 < B`, если нужно).
2. Доказываем `atom_support`: при этом условии каждый атом равен 0 вне `Icc (-K) K`.
3. `hg_supp`: из `atom_support` для каждого слагаемого выводим поддержку суммы.
4. `h_approx`: применяем “Step 4 collect errors via triangle inequality” из текста: сумма трёх суп-норм \(\varepsilon/3\) даёт \(\varepsilon\).【171:3†RH_Q3.pdf†L32-L45】

---

## 5. Леммы (Lean-ready формулировки)

Ниже — **готовые формулировки**. Названия подстрой под свой файл.

### 5.1. Ключевое условие параметров
```lean
def AtomOK (K B τ : ℝ) : Prop :=
  0 ≤ B ∧ |τ| + B ≤ K
```
(Если у тебя Fejér делит на `B`, лучше `0 < B`.)

### 5.2. Геометрическая лемма: вне окна Fejér-аргумент слишком большой
Идея: если `|x| > K` и `|τ| + B ≤ K`, то `|x ± τ| ≥ B`.

```lean
lemma abs_add_ge_B_of_abs_ge_K
  {K B τ x : ℝ} (hτB : |τ| + B ≤ K) (hx : K < |x|) :
  B ≤ |x - τ| ∧ B ≤ |x + τ| := by
  -- outline:
  -- have h1 : |x| ≤ |x - τ| + |τ| := by simpa [sub_eq_add_neg, add_assoc] using abs_add (x - τ) τ
  -- from hx and hτB derive |x| - |τ| > B and hence B ≤ |x - τ|
  -- similarly with x = (x + τ) + (-τ)
  sorry
```

### 5.3. `Atom` обнуляется вне `[-K,K]`
Это то, что тебе реально нужно для `Function.support ⊆ Icc (-K) K`.

```lean
lemma Atom_eq_zero_of_not_mem_Icc
  {K B t τ x : ℝ} (hτB : |τ| + B ≤ K)
  (hx : x ∉ Set.Icc (-K) K) :
  Atom B t τ x = 0 := by
  -- from hx get K < |x| (or at least K ≤ |x| with ≠)
  -- then use abs_add_ge_B_of_abs_ge_K to get B ≤ |x±τ|
  -- then FejerKernel B (x±τ) = 0, so each term is 0, so Atom = 0
  sorry
```

### 5.4. Support containment для одного атома
```lean
lemma support_Atom_subset_Icc
  {K B t τ : ℝ} (hτB : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- hx : x ∈ support means Atom ... x ≠ 0
  -- contrapose: if x ∉ Icc then Atom = 0 contradiction
  -- easiest: by_contra hxI; have := Atom_eq_zero_of_not_mem_Icc (K:=K) (B:=B) (t:=t) (τ:=τ) (x:=x) hτB hxI; exact hx (by simpa [this])
  sorry
```

### 5.5. Support для конечной суммы (твой `hg_supp`)
Пусть `hg = ∑ᶠ c_i • Atom ...`. Тогда вне `Icc` каждый атом 0 ⇒ сумма 0 ⇒ support ⊆ Icc.

```lean
lemma support_finset_sum_subset_Icc
  {K : ℝ} {ι : Type} [DecidableEq ι]
  (s : Finset ι)
  (g : ι → (ℝ → ℝ))
  (hg : ∀ i ∈ s, Function.support (g i) ⊆ Set.Icc (-K) K) :
  Function.support (∑ i in s, g i) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- show x ∈ Icc; contrapose with x ∉ Icc → each g i x = 0 → sum = 0 contradiction
  sorry
```

В твоём случае `g i` — это “коэффициент * Atom …”.

---

## 6. `h_approx`: готовый треугольный “ε/3 + ε/3 + ε/3”

В документе это отдельный шаг: “collect errors via triangle inequality”.【171:3†RH_Q3.pdf†L32-L45】  
Ты можешь прямо повторить структуру.

### 6.1. Абсолютная версия для трёх промежуточных функций
```lean
lemma abs_sub_le_three (a b c d : ℝ) :
  |a - d| ≤ |a - b| + |b - c| + |c - d| := by
  -- a-d = (a-b) + (b-c) + (c-d)
  -- apply abs_add twice
  -- ring_nf may help for rewriting
  sorry
```

### 6.2. Суп-норма на окне
Если твой `h_approx` формулируется как:
`∀ x ∈ Icc (-K) K, |h x - f x| ≤ ε`, то делай так:

```lean
have htri :
  ∀ x ∈ Set.Icc (-K) K,
    |h x - f x| ≤ |h x - g2 x| + |g2 x - g1 x| + |g1 x - f x| := by
  intro x hx
  simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using
    abs_sub_le_three (h x) (g2 x) (g1 x) (f x)

-- then bound each term by ε/3 and finish with linarith
```

Это ровно то, что в тексте записано как
\(\sup|h-f|\le \sup|h-g|+\sup|g-f|\) в три шага.【171:3†RH_Q3.pdf†L32-L45】

---

## 7. Аудит (edge check)

- **Критическая аномалия/сигнал:** твоя текущая гипотеза “\(\tau \in [-K,K]\), \(B\le K\)” *слишком слабая* для `support ⊆ [-K,K]`. Это не баг доказательства, это баг спецификации параметров.  
  **Измерение:** support атома — \([\tau-B,\tau+B]\cup[-\tau-B,-\tau+B]\). Чтобы он лежал в \([-K,K]\), нужно и достаточно `|τ| + B ≤ K`.
- **Соответствие документу:** именно такое ограничение параметров используется в “Fixed-\(t_0\) cone density”.【171:12†RH_Q3.pdf†L23-L63】
- **`h_approx`**: в тексте прямо прописан нужный “ε/3-сборщик”.【171:3†RH_Q3.pdf†L32-L45】

---

### Итоговое действие (что делать прямо сейчас в Lean)

1) В `AtomCone_K` (или в генераторном множестве параметров) замени условие на:
- `0 < B` (или `0 ≤ B` если у тебя безопасное определение при B=0),
- `|τ| + B ≤ K`.

2) Закрой `hg_supp` через `Atom_eq_zero_of_not_mem_Icc` + “вне Icc все слагаемые нули”.

3) Закрой `h_approx` леммой `abs_sub_le_three` + `linarith` (или `nlinarith`) с тремя оценками `< ε/3`.

Если хочешь — могу написать **точечный скелет** под твои конкретные имена (`hg`, `AtomCone_K`, `W_K`, `FejerKernel_eq_zero_of_abs_ge`, …), но даже без этого выше — это прямой, совместимый с текстом патч, который убирает оба sorries.

## ASSISTANT
Вот что реально сломано и как чинить с минимальным радиусом взрыва.

---

## 0. Теорема и статус

**Тезис (формально, с кванторами).**  
Для каждого \(K>0\) и фиксированного \(t_0>0\) conoid, порождённый атомами Fejér×heat с параметрами  
\[
B>0,\qquad |\,\tau\,|+B\le K,
\]
(и их even-симметризациями) плотен в \(C^+_{\mathrm{even}}([-K,K])\) в \(\|\cdot\|_\infty\); в частности, каждый такой атом имеет `support ⊆ [-K,K]`.

**Статус:** стандартный анализ (ZFC). В тексте проекта это прямо зафиксировано как “Fixed-\(t_0\) cone density” (Лемма 6.4).【169:5†RH_Q3.pdf†L23-L63】

---

## 1. Что именно “противоречит” в Lean

### 1.1. Важный феномен (и он полезен)
Ты пишешь: *Heat kernel бесконечной поддержки → проблема.*  
На самом деле для **`Function.support`** (точечная поддержка) это не источник проблемы:

- `HeatKernel t x > 0` для всех \(x\), значит `Function.support (HeatKernel t)` = `Set.univ`.  
- Для произведения: `support (f * g) ⊆ support f ∩ support g`. Если `support g = univ`, то `support (f*g) ⊆ support f`.

То есть **поддержка произведения Fejér×heat контролируется Fejér-фактором**, а не “хвостами” heat.

### 1.2. Реальная причина блока `hg_supp`
Проблема чисто геометрическая: сдвиг и ширина шляпы.

Если атом содержит `FejerKernel B (x - τ)`, то его (точечная) поддержка лежит в \([\,\tau-B,\tau+B\,]\).  
Если \(\tau\in[-K,K]\) и \(B\le K\), то получаем только  
\[
[\,\tau-B,\tau+B\,]\subseteq[-K-B,K+B]\subseteq[-2K,2K],
\]
но **не** \(\subseteq[-K,K]\). Ровно это у тебя и вылезло.

---

## 2. Анализ вариантов — какой лучше

### Option 1: расширить \(W_K\) или окно поддержки
**Плохо**: это расползётся по A2/A3/closure: константы, “окна”, continuity budgets, и вообще смысл \(W=\bigcup_K W_K\). Очень высокий риск каскадных правок.

### Option 3: truncate heat kernel / cutoff и оценить ошибку
**Тяжело**: понадобится аккуратно:
- определить гладкий cutoff,
- доказать, что ты остаёшься в нужном конусе,
- оценить ошибку в \(\|\cdot\|_\infty\),
- следить, чтобы не убить неотрицательность/чётность/контроль модулей.

Это реально можно сделать, но Lean-стоимость высокая.

### ✅ Option 2: ограничить параметры атомов `|τ| + B ≤ K`
**Лучший** вариант по трём причинам:

1) Это **точно** решает `hg_supp` (поддержка шляпы не вылезает).  
2) Плотность **не ломается**: в тексте проекта это отдельная лемма “Fixed-\(t_0\) cone density”【169:5†RH_Q3.pdf†L23-L63】.  
3) Это минимальная правка: ты трогаешь только “какие атомы допускаются внутри \(W_K\)”, а не весь смысл \(W_K\).

---

## 3. Полный proof sketch для Option 2

Здесь я даю схему, которую можно прямо переносить в Lean-структуру.

### 3.1. Цель (в терминах Lean-логики)
Для фиксированных \(K>0\), \(t_0>0\) и любого \(f\in W_K\), \(\varepsilon>0\) нужно построить \(g\) как конечную неотрицательную комбинацию атомов `Atom B t0 τ`, где **везде** \(|\tau|+B\le K\), и получить
\[
\sup_{|x|\le K} |g(x)-f(x)| < \varepsilon,
\]
а также `support g ⊆ [-K,K]`.

Это ровно “Fixed-\(t_0\) cone density”.【169:5†RH_Q3.pdf†L23-L63】

---

### 3.2. Шаг A: положительная “hat”-аппроксимация (без heat)
Берём равномерную сетку \(\tau_j\) на \([-K,K]\) с шагом \(\delta\). Определяем “шляпы”
\[
H_j(\xi):=\Lambda_\delta(\xi-\tau_j) = \max\!\bigl(0,1-|\xi-\tau_j|/\delta\bigr).
\]
Строим
\[
h(\xi):=\sum_j f(\tau_j)\,H_j(\xi).
\]

Факты:
- \(h\ge 0\) (коэффициенты \(\ge0\), шляпы \(\ge0\)).
- При достаточно малом \(\delta\): \(\|h-f\|_\infty<\varepsilon/3\) на \([-K,K]\).  
  (Это стандартная piecewise-linear interpolation; в Lean обычно идёт через равномерную непрерывность \(f\) на компактном `Icc`.)

---

### 3.3. Шаг B: заменить каждую шляпу на Fejér×heat-атом с фиксированным \(t_0\)
Ключ: на маленьком интервале \(|\xi-\tau_j|\le\delta\) heat-фактор почти константа, поэтому
\[
\Lambda_\delta(\xi-\tau_j)\rho_{t_0}(\xi-\tau_j)\approx \rho_{t_0}(0)\,\Lambda_\delta(\xi-\tau_j).
\]

В тексте используется Lipschitz/равномерная непрерывность \(\rho_{t_0}\) на \([-2K,2K]\).【169:5†RH_Q3.pdf†L34-L56】

Строим
\[
g(\xi):=\sum_j c_j\,\Phi_{\delta,t_0,\tau_j}(\xi),
\]
где \(\Phi_{\delta,t_0,\tau}\) — твой even-атом (с \(\pm\tau\)), а \(c_j\ge0\) выбираются так, чтобы \(g\) был “почти” \(h\). В тексте предложен выбор \(c_j=f(\tau_j)/\rho_{t_0}(\tau_j)\) и оценка через Lipschitz.【169:5†RH_Q3.pdf†L35-L63】

**Практически для Lean** часто ещё удобнее брать нормировку через \(\rho_{t_0}(0)\) (она точно положительна и константа), и оценивать
\[
|g-h|\le \text{(модуль непрерывности }\rho_{t_0}\text{)}.
\]
Но это уже деталь реализации.

Итог: выбираешь \(\delta\) настолько малым, что \(\|g-h\|_\infty<\varepsilon/3\) на \([-K,K]\).

---

### 3.4. Шаг C: треугольник (это твой `h_approx`)
\[
\|g-f\|_\infty \le \|g-h\|_\infty + \|h-f\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
В тексте это делается именно как “collect errors via triangle inequality”.【169:8†RH_Q3.pdf†L32-L44】

---

### 3.5. Шаг D: поддержка (это твой `hg_supp`)
Если ты **ограничиваешь параметры** так, что \(|\tau|+B\le K\), то для каждого атома
\[
\mathrm{support}(\Phi_{B,t_0,\tau})\subseteq[-K,K].
\]
Дальше:
- `support (sum)` ⊆ `⋃ support(summands)`  
- `support (c • f)` = `support f` если \(c\ne0\) (или ⊆, если не хочется делить случаи),
- finite union внутри `Icc (-K) K` остаётся внутри.

---

## 4. Lean-стейтменты (скелеты), которые тебе прямо сейчас нужны

Я пишу “Lean-style” максимально близко к mathlib, но без знания твоих exact namespaces.

### 4.1. Поддержка Fejér и атома (закрывает `hg_supp`)

```lean
/-- Fejér hat: zero outside [-B,B] (translated version). -/
lemma fejerKernel_eq_zero_of_abs_sub_ge
  {B τ x : ℝ} (hB : 0 < B) (hx : B ≤ |x - τ|) :
  FejerKernel B (x - τ) = 0 := by
  -- unfold FejerKernel; by cases on max(0, ...)
  sorry

lemma support_fejer_translate_subset_Icc
  {B τ : ℝ} (hB : 0 < B) :
  Function.support (fun x => FejerKernel B (x - τ))
    ⊆ Set.Icc (τ - B) (τ + B) := by
  -- show: if x ∉ Icc(τ-B, τ+B) then value = 0
  -- use |x-τ| ≥ B
  sorry

/-- Main support fix: if |τ|+B ≤ K then the even atom is supported in [-K,K]. -/
lemma support_atom_subset_Icc
  {K B t τ : ℝ} (hB : 0 < B) (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- Atom = (term (x-τ)) + (term (x+τ)) (maybe /2)
  -- support_add_subset; support_mul_subset; then use the Fejér translate support lemma
  -- and interval arithmetic: if x ∈ support then |x| ≤ |τ| + B ≤ K
  sorry
```

### 4.2. Поддержка конечной суммы атомов (если `g` строится через `Finset.sum`)

```lean
lemma support_finset_sum_subset
  {ι : Type*} [DecidableEq ι] (s : Finset ι) (f : ι → ℝ → ℝ) :
  Function.support (fun x => ∑ i in s, f i x)
    ⊆ ⋃ i ∈ s, Function.support (f i) := by
  -- standard lemma exists in mathlib; otherwise prove by `by classical`
  sorry

lemma support_g_subset_Icc
  {K t : ℝ} {s : Finset ℝ} {c : ℝ → ℝ} {B : ℝ}
  (hB : 0 < B)
  (hτ : ∀ τ ∈ s, |τ| + B ≤ K) :
  Function.support (fun x => ∑ τ in s, (c τ) * Atom B t τ x)
    ⊆ Set.Icc (-K) K := by
  -- use support_sum_subset + support_atom_subset_Icc
  sorry
```

### 4.3. Треугольник для `h_approx`

```lean
/-- Generic triangle-inequality packaging for sup bounds on Icc(-K,K). -/
lemma sup_Icc_triangle
  {K : ℝ} {f g h : ℝ → ℝ} {ε : ℝ}
  (hfg : ∀ x ∈ Set.Icc (-K) K, |f x - g x| ≤ ε)
  (hgh : ∀ x ∈ Set.Icc (-K) K, |g x - h x| ≤ ε) :
  ∀ x ∈ Set.Icc (-K) K, |f x - h x| ≤ 2*ε := by
  intro x hx
  -- |f-h| ≤ |f-g| + |g-h|
  nlinarith [abs_sub_le_iff.1 ?_] -- or `by simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using ...`
  sorry

/-- If each stage is < ε/3, the total is < ε (your h_approx). -/
lemma h_approx_from_three
  {K : ℝ} {f g₁ g₂ g₃ : ℝ → ℝ} {ε : ℝ}
  (h1 : ∀ x ∈ Set.Icc (-K) K, |g₁ x - f x| < ε/3)
  (h2 : ∀ x ∈ Set.Icc (-K) K, |g₂ x - g₁ x| < ε/3)
  (h3 : ∀ x ∈ Set.Icc (-K) K, |g₃ x - g₂ x| < ε/3) :
  ∀ x ∈ Set.Icc (-K) K, |g₃ x - f x| < ε := by
  intro x hx
  -- chain: |g₃-f| ≤ |g₃-g₂| + |g₂-g₁| + |g₁-f|
  have := lt_of_le_of_lt (by
    -- abs_sub_le ... twice
    sorry) (by nlinarith [h1 x hx, h2 x hx, h3 x hx])
  exact this
```

### 4.4. Формулировка “Fixed-\(t_0\) density” в Lean-стиле (ядро Option 2)

```lean
/-- Restricted generator parameters: keep support inside [-K,K]. -/
def AtomParamOK (K B τ : ℝ) : Prop := 0 < B ∧ |τ| + B ≤ K

/-- Density statement (one explicit ε-form). -/
theorem atomCone_dense_fixed_t
  {K t0 : ℝ} (hK : 0 < K) (ht0 : 0 < t0) :
  ∀ {f : ℝ → ℝ}, f ∈ W_K K → ∀ ε > 0,
    ∃ g : ℝ → ℝ,
      g ∈ AtomCone_K_restricted K t0 ∧
      (∀ x ∈ Set.Icc (-K) K, |g x - f x| < ε) := by
  -- follow Lemma 6.4 structure: hats → replace by atoms → triangle
  sorry
```

**Почему это корректно относительно проекта:** это буквально то, что записано как Лемма 6.4 (Fixed-\(t_0\) cone density): атомы берутся с условием \(|\tau|+B\le K\), и получаем плотность в \(C^+_{\mathrm{even}}([-K,K])\).【169:5†RH_Q3.pdf†L23-L63】

---

## 5. Audit: где может быть тонкая “антиподдержка”

### 5.1. `Function.support` vs topological support
У тебя в определении \(W_K\) стоит `Function.support Φ ⊆ Icc (-K) K`. Это **точечная** поддержка `{x | Φ x ≠ 0}`.  
Это нормально, но будь внимателен: если ты где-то используешь аналитическое свойство “компактная поддержка + глобальная непрерывность ⇒ значения на границе = 0”, это уже про `tsupport`/непрерывность на ℝ. В твоём фрагменте `ContinuousOn` только на `Icc`, так что “граница” может вести себя не так, как в классическом `Cc(ℝ)`.

**Практическое решение:** для A1/A2 обычно всё-таки используют глобальную непрерывность или `tsupport`. Если в Lean у тебя реально только `ContinuousOn` на `Icc`, то безопаснее не опираться на “f(K)=0” и строить аппроксимации, которые умеют попадать в значения на концах (это возможно, но шляпы надо ставить аккуратно).  
Но если у тебя уже доказано `Φ ∈ Cc` или `Continuous` глобально, то всё ок.

---

## 6. Что именно делать в A1_density.lean прямо сейчас

1) **Ввести ограничение параметров атомов внутри окна:**
   - либо в определении `AtomCone_K` (генераторное множество),
   - либо в лемме “каждый генератор ∈ WK”: потребовать `|τ| + B ≤ K`.

2) Закрыть `hg_supp` через `support_atom_subset_Icc` + support-суммирование.

3) Закрыть `h_approx` как чистую “triangle chain” (шаблон выше), ровно как в Step 4 текста.【169:8†RH_Q3.pdf†L32-L44】

---

Если хочешь, я могу в следующем сообщении переписать “Fixed-\(t_0\) cone density” строго под твою текущую сигнатуру `W_K`/`AtomCone_K` (какие у тебя именно нормы/closure/Dense). Но по сути: **Option 2 — канонический патч, и он уже заложен в проектной математике**.【169:5†RH_Q3.pdf†L23-L63】

## ASSISTANT
Ниже — разбор “дефиниционного клина” и самый прямой способ закрыть `hg_supp` (и затем `h_approx`) так, чтобы это **не разносило A2/A3** и не требовало “хвостов/усечений” тепла.

---

## 0. Феномен: где именно противоречие и почему это НЕ про бесконечный support HeatKernel

### Сигнал (аномалия)
Ты сейчас одновременно держишь:

- `W_K`: требует **строгий** `Function.support Φ ⊆ Icc (-K) K` (то есть Φ=0 вне окна).
- `AtomCone_K`: требует то же самое для элементов конуса.
- Атомы параметризованы примерно как `τ ∈ [-K,K]`, `B ≤ K`.

Но для “шляпы” (triangular) верно:

\[
\operatorname{supp}(\Lambda_B(\cdot-\tau)) \subset [\tau-B,\tau+B].
\]

Значит, при `|τ|≤K` и `B≤K` получаешь в худшем случае поддержку до `K+B ≤ 2K`. Это **структурно** несовместимо с требованием поддержки в `[-K,K]`.

### Важное уточнение
Бесконечная поддержка **теплового** ядра тут не виновата: в твоих генераторах оно умножено на компактно поддержанную Fejér/hat‑шляпу, значит окно всё равно компактно поддержано (поддержка задаётся шляпой). В статье это прямо используется: окно вида  
\[
\Phi_{B,t}(\xi)=\Bigl(1-\frac{|\xi|}{B}\Bigr)_+\,e^{-4\pi^2 t\xi^2}
\]
имеет компактную поддержку по \(\xi\) (ограничение задаёт \((\cdot)_+\)).【205:2†RH_Q3.pdf†L92-L129】  
И именно потому prime‑сумма конечна: “prime sum is finite because Φ is supported in [−B,B]”.【205:2†RH_Q3.pdf†L60-L63】

**Вывод феномена:** баг — чисто геометрия интервалов \(\tau\pm B\), не “хвосты гауссианы”.

---

## 1. Выбор опции: что лучше (и почему)

У тебя три направления (как ты и перечислил):

### Option 1: “расширить” `W_K`/support‑окно до `[-2K,2K]` или менять K‑семантику  
**Плюсы:** минимальная правка в A1_density.lean, если нынешний конструктор уже работает.  
**Минусы (критично):** ломает смысл `W_K` как компакта “радиуса K” во всей Tier‑2 цепочке: A2 “континуитет на каждом W_K” и перенос на \(W=\cup_K W_K\) используют именно этот компакт-by-компакт интерфейс【205:14†RH_Q3.pdf†L15-L27】. Начнёшь скейлить окно — полезут коэффициенты в Lipschitz‑оценках и в местах, где K завязан на “сколько узлов ξ_n попадает внутрь”.

### Option 3: truncation/tails (усечение тепла, контроль ошибки)  
**Плюсы:** можно формально оставить “широкие” атомы.  
**Минусы:** ты сам себе добавляешь новый слой техники (усечение + оценка ошибки + совместимость с конусом). При этом, повторюсь, **тепло не порождает поддержку** в твоей модели — всё задаётся Fejér/hat, так что truncation тут по сути лишний.

### ✅ Option 2: **правильная геометрическая правка** — требовать `|τ| + B ≤ K`  
Это ровно то, что нужно, чтобы каждый атом жил в `[-K,K]` и чтобы `AtomCone_K ⊆ W_K` стало истинным без магии.

**Почему это “самое правильное” для всей программы:**
- Совпадает с концептом “компактно поддержанных тестов” в Weil‑классе【205:4†RH_Q3.pdf†L5-L15】.
- Не требует менять определение `W_K`, а значит не трогает A2/A3 интерфейс переноса “генераторы → весь W_K → W”【205:14†RH_Q3.pdf†L15-L27】【205:5†PROSHKA_REQUEST_3.md†L34-L38】.
- В Lean это самая короткая дорога: `hg_supp` превращается в чистую арифметику интервалов + лемму про support суммы.

**Итог:** бери **Option 2**.

---

## 2. Теорема, которую ты реально хочешь (под Option 2)

### 0. Теорема: “Restricted-atom cone density on \(W_K\)”  
**Точная формулировка (в словах):**  
Для любого \(K>0\) и фиксированного \(t=t_{\mathrm{sym}}>0\), конус конечных неотрицательных линейных комбинаций атомов `Atom(B,t,τ)` с ограничением \(|\tau|+B\le K\) плотен в \(W_K\) по \(\|\cdot\|_\infty\) на \(\mathbb R\) (эквивалентно на `Icc (-K) K`, т.к. у обеих функций support внутри).

**Статус:** стандартная математика (ZFC), конструктивная аппроксимация через “hat partition” + малость вариации гауссианы на малом носителе.

---

## 3. Дорожная карта доказательства Option 2

1) **Support‑геометрия:**  
\[
\operatorname{supp}(\text{Atom}(B,t,\tau))\subset[-(|\tau|+B),\;|\tau|+B]
\]
⇒ при \(|\tau|+B\le K\) получаем support ⊆ `[-K,K]`.

2) **Позитивная аппроксимация Φ “шляпами” (без тепла):**  
берём мелкий шаг `B` и строим неотрицательную кусочно‑линейную аппроксимацию \(h_0\) вида суммы шляп, так что  
\(\|h_0-\Phi\|_\infty\le \omega_\Phi(B)\).

3) **Замена каждой шляпы на Fejér×heat‑атом:**  
на носителе шляпы \(|x-\tau|\le B\), а heat‑фактор \(H_t(x-\tau)\) почти константа \(H_t(0)\).  
Отсюда нормированный атом \(\frac1{H_t(0)}\Lambda_B(x-\tau)H_t(x-\tau)\) близок к \(\Lambda_B(x-\tau)\) по \(\|\cdot\|_\infty\).  
Ошибка контролируется гладкостью heat‑ядра и даёт \(O(B^2/t)\) (см. ниже).

4) **Triangle inequality:**  
\[
\|\Phi-h\|_\infty \le \|\Phi-h_0\|_\infty+\|h_0-h\|_\infty
\]
⇒ выбираем B так, чтобы обе части < ε/2.

---

## 4. Ключевые леммы (математически) + как ими закрыть `hg_supp` и `h_approx`

### Лемма A: support одного атома
Если `FejerKernel B u = 0` при `|u| ≥ B`, то:

\[
\text{Atom}(B,t,\tau)(x)\neq 0 \Rightarrow (|x-\tau|<B)\ \text{или}\ (|x+\tau|<B)
\]
⇒ \(|x|\le |\tau|+B\).

**Следствие:**  
если `|τ| + B ≤ K`, то `Function.support (Atom B t τ) ⊆ Icc (-K) K`.

➡️ Это **прямо закрывает** твой `hg_supp` после правки параметров конуса.

---

### Лемма B: support конечной суммы
Если для всех слагаемых `support fi ⊆ Icc (-K) K`, то и у суммы то же.  
В терминах `Function.support` это очень просто: вне `Icc (-K) K` все `fi x = 0`, значит сумма тоже 0.

➡️ Тоже часть `hg_supp`, если `hg` — finset‑сумма атомов.

---

### Лемма C: heat почти константа на малом интервале
Пусть \(H_t(u)=c(t)\,e^{-u^2/(4t)}\) (нормировка не важна, она сокращается). Тогда:

- \(H_t(0)>0\).
- Производная: \(H_t'(u)=-(u/(2t))H_t(u)\).
- На \(|u|\le B\): \(|H_t'(u)|\le (B/(2t))H_t(0)\) (так как \(H_t(u)\le H_t(0)\)).

По MVT:
\[
|H_t(u)-H_t(0)|\le \frac{B^2}{2t}\,H_t(0)\quad (|u|\le B).
\]
Эквивалентно:
\[
\left|\frac{H_t(u)}{H_t(0)}-1\right|\le \frac{B^2}{2t}.
\]

➡️ Это “ядро” для оценки \(\|h-h_0\|_\infty\).

---

### Лемма D: `h_approx` как чистая triangle-цепочка
Если ты строишь `h0` (hat‑аппрокс) и `h` (атом‑аппрокс), то:

\[
\|h-\Phi\|_\infty \le \|h-h_0\|_\infty + \|h_0-\Phi\|_\infty.
\]

Это то, что ты описал как “needs triangle inequality chain”. В Lean это либо:
- просто `by simpa [sub_eq_add_neg, add_assoc] using norm_sub_le ...`, если ты в `ContinuousMap`,
- либо через `iSup`/`sSup`‑леммы на `Set.Icc`.

---

## 5. Lean‑style statements (готовые формулировки под Option 2)

Я пишу “Lean‑стилем”, но тебе придётся подогнать имена (`FejerKernel`, `HeatKernel`, `AtomCone_K` и т.п.) под твой файл.

### 5.1. Правка определения конуса (ключ)
**Вместо** условий типа `|τ| ≤ K` и `B ≤ K`  
**введи**:

```lean
def AtomParamsInK (K B τ : ℝ) : Prop :=
  0 ≤ B ∧ |τ| + B ≤ K
```

и используй это в генераторах.

---

### 5.2. Support атома

```lean
lemma support_atom_subset_Icc
  {B t τ K : ℝ} (hB : 0 ≤ B) (hK : 0 ≤ K) (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- show: x ∉ Icc (-K) K → Atom B t τ x = 0
  -- use: FejerKernel is zero when |x ± τ| ≥ B
  -- infer: if Atom ≠ 0 then |x| ≤ |τ| + B ≤ K
  sorry
```

Более “точная” промежуточная версия (удобнее для арифметики):

```lean
lemma support_atom_subset_abs
  {B t τ : ℝ} (hB : 0 ≤ B) :
  Function.support (Atom B t τ) ⊆ {x : ℝ | |x| ≤ |τ| + B} := by
  sorry
```

---

### 5.3. Support суммы

```lean
lemma support_finset_sum_subset_Icc
  {ι : Type} (s : Finset ι) (f : ι → ℝ → ℝ) (K : ℝ) :
  (∀ i ∈ s, Function.support (f i) ⊆ Set.Icc (-K) K) →
  Function.support (∑ i in s, f i) ⊆ Set.Icc (-K) K := by
  intro hsupp
  -- x outside Icc -> each f i x = 0 -> sum = 0 -> x not in support
  sorry
```

Если у тебя веса:

```lean
lemma support_finset_weighted_sum_subset_Icc
  {ι : Type} (s : Finset ι) (c : ι → ℝ) (f : ι → ℝ → ℝ) (K : ℝ) :
  (∀ i ∈ s, Function.support (f i) ⊆ Set.Icc (-K) K) →
  Function.support (∑ i in s, fun x => c i * f i x) ⊆ Set.Icc (-K) K := by
  intro hsupp
  -- multiplication doesn't enlarge Function.support if scalar ≠ 0; easiest is pointwise: outside Icc, f i x = 0
  sorry
```

---

### 5.4. Heat variation bound (универсальная)

```lean
lemma heatKernel_rel_one_sub_le
  {t B : ℝ} (ht : 0 < t) (hB : 0 ≤ B) :
  ∀ {u : ℝ}, |u| ≤ B →
    |(HeatKernel t u) / (HeatKernel t 0) - 1| ≤ B^2 / (2*t) := by
  intro u hu
  -- use derivative bound + mean value theorem
  sorry
```

(Если у тебя `HeatKernel` уже нормирован иначе — эта лемма всё равно обычно доказывается без проблем, потому что нормировка сократится в отношении.)

---

### 5.5. `h_approx` triangle chain (если работаешь с sup on Icc)

```lean
lemma supOn_Icc_sub_le_triangle
  (K : ℝ) (f g h : ℝ → ℝ) :
  (⨆ x : Set.Icc (-K) K, |f x - h x|)
    ≤ (⨆ x : Set.Icc (-K) K, |f x - g x|)
    + (⨆ x : Set.Icc (-K) K, |g x - h x|) := by
  -- standard: abs_sub_le + iSup_le_iSup_of_le
  sorry
```

Если ты вместо `iSup` используешь `‖·‖` в `ContinuousMap` на `Icc`, то ещё проще:

```lean
lemma norm_sub_le_triangle
  {α : Type} [NormedAddCommGroup α]
  (f g h : α) : ‖f - h‖ ≤ ‖f - g‖ + ‖g - h‖ := by
  simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using norm_add_le (f - g) (g - h)
```

---

### 5.6. Финальная “плотность” (скелет)

```lean
theorem atomCone_dense_WK
  (K : ℝ) (hK : 0 < K) :
  -- choose your exact topology/norm; schematic:
  Dense (AtomCone_K K) (W_K K) := by
  -- construct h from Φ, ε
  sorry
```

На практике у тебя это будет в форме:
`∀ Φ ∈ W_K K, ∀ ε>0, ∃ h ∈ AtomCone_K K, ‖h-Φ‖∞ < ε`.

---

## 6. Как именно это закрывает твои 2 оставшиеся `sorry`

### `hg_supp`
После правки параметров конуса (`|τ| + B ≤ K`), доказательство становится:

1) `support_atom_subset_Icc` для каждого атома.  
2) `support_finset_sum_subset_Icc` для суммы/линейной комбинации.  
3) Готово.

Это короткая чистая цепочка.

### `h_approx`
Тут действительно чаще всего остаётся “вплести” уже доказанные локальные оценки в одну:

- `‖Φ - h0‖∞ ≤ ε/2` (из uniform continuity / modulus continuity).
- `‖h0 - h‖∞ ≤ ε/2` (из heat‑variation bound и контроля перекрытий шляп).
- Тогда `‖Φ - h‖∞ ≤ ε` по triangle inequality.

---

## 7. Error bounds “если всё-таки делать truncation” (Option 3, на всякий)

### 7.1. Главный факт: в твоих атомах truncation тепла даёт **нулевую** ошибку
Если ты определишь усечённое тепло
\[
H_t^{(R)}(u)=\begin{cases}
H_t(u), & |u|\le R\\
0, & |u|>R
\end{cases}
\]
и возьмёшь \(R\ge B\), то на носителе Fejér‑шляпы \(|u|\le B\), значит  
\[
\Lambda_B(u)\,H_t^{(R)}(u)=\Lambda_B(u)\,H_t(u).
\]
То есть **ошибка ровно 0**, пока truncation‑радиус ≥ B.

### 7.2. Если когда‑то понадобится truncation “голой” гауссианы (без шляпы)
Тогда стандартные оценки:

- L∞‑ошибка:  
\[
\|H_t - H_t^{(R)}\|_\infty \le H_t(R) \asymp e^{-R^2/(4t)}.
\]

- L1‑хвост (удобно для интегральных ошибок в функционале):  
\[
\int_{|u|>R} e^{-u^2/(4t)}\,du \le \frac{4t}{R}e^{-R^2/(4t)}.
\]

Но повторюсь: для **Fejér×heat** (hat×gauss) это почти никогда не нужно.

---

## 8. Резюме “что делать прямо сейчас”

1) **Сделай Option 2 дефиниционным**: в генераторах конуса требуй `|τ| + B ≤ K`.  
2) Закрой `hg_supp` через две леммы: “support атома” + “support суммы”.  
3) `h_approx` — это чистый triangle‑склей с двумя ошибками (hat‑аппрокс + heat‑variation).  
4) Truncation тепла **не нужен** и не решает твою реальную проблему.

Если хочешь, я могу в следующем сообщении “под твой стиль файла” набросать **точную структуру** `AtomCone_K` (как у тебя: через `Finset`/`∃ n`/`ConicHull`) — но даже без этого выше у тебя уже есть полный маршрут закрытия двух `sorry`.

И да: всё это идеально согласуется с тем, что A1′+A2 — это именно перенос \(Q\ge0\) с генераторов на весь \(W_K\), а потом на \(W\).【205:5†PROSHKA_REQUEST_3.md†L34-L38】【205:14†RH_Q3.pdf†L15-L27】

## ASSISTANT
## 0. Теорема: «Fix A1_density support» и статус

**Точная формулировка (то, что должно стать истинным в Lean):**  
Для фиксированного \(K>0\) и фиксированного \(t=t_{\mathrm{sym}}\), конус (неотрицательные конечные линейные комбинации) из **Fejér×heat атомов** с параметрами \((B,\tau)\) удовлетворяющими
\[
B>0,\qquad |\tau|+B\le K
\]
лежит в \(W_K\) (в частности, имеет поддержку внутри \([-K,K]\)) и **плотен** в \(W_K\) в \(\|\cdot\|_\infty\) на \([-K,K]\).

**Статус:** это ровно та формула, которая прописана в спецификации как “Fixed-\(t_0\) cone density” (Лемма 6.4): там явно требуется \(|\tau|+B\le K\).【253:9†RH_Q3.pdf†L23-L27】

---

## 1. Контекст: что сломано и почему это сигнал

Ты сейчас пытаешься закрыть `hg_supp` (support containment) в `A1_density.lean`, но у тебя в `AtomCone_K`/`W_K` стоит требование
\[
\operatorname{support}(g)\subseteq [-K,K].
\]
А в текущей версии параметры атома берутся как \(\tau\in[-K,K]\) и \(B\le K\), что даёт только
\[
\operatorname{support}(\text{atom})\subseteq [-K-B,\,K+B]\subseteq [-2K,2K],
\]
и это **не попадает** в требование \([-K,K]\).

**Сигнал:** это не “мелкая лемма про support”, это **несовместимость параметризации**. Правильный параметрический домен должен гарантировать \(|x|\le K\) всякий раз, когда атом может быть ненулевым.

---

## 2. Определения: что именно нужно зафиксировать

У тебя атом (в упрощённой математической форме) выглядит как
\[
\mathrm{Atom}(B,t,\tau)(x)
=
F_B(x-\tau)H_t(x-\tau)+F_B(x+\tau)H_t(x+\tau),
\]
где \(F_B(u)=(1-|u|/B)_+\) и \(H_t\) — гауссиан (или пропорциональный ему).

Ключевая точка:

- \(F_B(u)=0\) при \(|u|\ge B\).
- Значит \(\mathrm{Atom}(B,t,\tau)(x)\neq0\) **только если** \(|x-\tau|<B\) или \(|x+\tau|<B\).
- Следовательно,
  \[
  \mathrm{Atom}(B,t,\tau)(x)\neq 0 \implies |x| < |\tau| + B.
  \]
- Поэтому, чтобы гарантировать \(|x|\le K\) при ненулевости, достаточно требовать
  \[
  |\tau|+B\le K.
  \]

Это ровно и есть “правильная” гипотеза для `hg_supp`.

---

## 3. Выбор опции: что лучше и почему

### Опция 2 (ограничить атомы условием \(|\tau|+B\le K\))
**Это лучшая опция.** Причины:

1. **Совпадает со спецификацией:** Лемма 6.4 в RH_Q3 прямо определяет конус через \(|\tau|+B\le K\).【253:9†RH_Q3.pdf†L23-L27】
2. **Минимальный ремонт в Lean:** ты меняешь только “допустимые параметры” в определении `AtomCone_K` / генераторов; остальные уже доказанные свойства (`even`, `nonneg`, `cont`) остаются без переписывания.
3. **`hg_supp` становится коротким:** поддержка доказуемо внутри \([-K,K]\) прямым вычислением через неравенство \(|x|>|τ|+B \Rightarrow \text{Atom}=0\).

### Опция 3 (трункация + оценка ошибки)
Это резко сложнее: надо вводить новый объект (truncated atom), а потом ещё доказать, что он “достаточно близок” по тому же функционалу/норме и не ломает конус/положительность. Это будет каскад.

**Итог:** берём Опцию 2.

---

## 4. План доказательства (Roadmap) для Opt. 2

1. **(Support fix)** Усилить лемму о поддержке атома: если \(|\tau|+B\le K\), то `Function.support (Atom B t τ) ⊆ Icc (-K) K`.
2. **(hg_supp)** Для твоего `g = ∑ w_i * Atom(B_i,t,τ_i)` с `w_i ≥ 0` и \(|τ_i|+B_i\le K\) доказать: для \(|x|>K\) каждый атом даёт 0, значит и сумма 0 → support внутри.
3. **(Density)** Плотность доказывается стандартно “hat interpolation + small distortion by heat”, как в Lemma 6.4:  
   - аппроксимируешь \(f\) положительной кусочно-линейной интерполяцией через “шляпы” \(H_j(x)=F_\delta(x-\tau_j)\);  
   - заменяешь каждую шляпу на “шляпа×heat” и контролируешь ошибку через липшицевость \(H_t\) на компактном интервале;  
   - симметризуешь для evenness.
4. **(h_approx)** Ошибку собираешь **цепочкой треугольников** (как в Step 4 / (6.7)).【253:8†RH_Q3.pdf†L32-L44】

---

## 5. Ключевые леммы (математика → Lean-скелет)

Ниже — набор **Lean-ready** утверждений (по смыслу). Названия подгони под твою нейминг-схему (`Q3.` / `A1_density`).

### 5.1. Fejér “обнуляется за пределом B”
(это фундамент, обычно уже есть/легко)

```lean
lemma FejerKernel_eq_zero_of_abs_ge {B u : ℝ} (hB : 0 < B) (hu : B ≤ |u|) :
    FejerKernel B u = 0 := by
  -- unfold FejerKernel; simp [max_eq_left, ...]
```

### 5.2. Атом обнуляется вне радиуса \(|τ|+B\)

```lean
lemma Atom_eq_zero_of_abs_gt {B t τ x : ℝ} (hB : 0 < B)
    (hx : |x| > |τ| + B) :
    Atom B t τ x = 0 := by
  -- idea:
  -- have h1 : B ≤ |x - τ| from calc
  --   |x - τ| ≥ |x| - |τ| := by exact abs_sub_abs_le_abs_sub ?  (use `abs_sub_le` rearranged)
  --   ... > B := by linarith
  -- so FejerKernel B (x-τ)=0; similarly for (x+τ)
  -- then simp [Atom, FejerKernel_eq_zero_of_abs_ge, h1, h2]
```

Нужные трюки:  
- `abs_add` / `abs_sub` неравенства: \(|x\pm τ|\ge |x|-|τ|\).  
- `linarith` после превращения `hx` в `|x|-|τ| > B`.

### 5.3. Support атома внутри \([-K,K]\) из условия \(|τ|+B≤K\)

```lean
lemma support_Atom_subset_Icc {K B t τ : ℝ} (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  intro x hx_supp
  -- show -K ≤ x ∧ x ≤ K
  -- use contrapositive:
  -- if |x| > K then Atom = 0 -> contradiction with hx_supp
  have hx_abs : |x| ≤ K := by
    by_contra h
    have : Atom B t τ x = 0 := by
      -- since |x| > K ≥ |τ|+B
      have : |x| > |τ| + B := by linarith
      exact Atom_eq_zero_of_abs_gt (B:=B) (t:=t) (τ:=τ) (x:=x) hB this
    exact hx_supp this
  -- finish: |x| ≤ K -> x ∈ Icc(-K,K)
  exact (abs_le.mp hx_abs)
```

(Тут `hx_supp : x ∈ Function.support f` даёт `f x ≠ 0`, так что `hx_supp this` — противоречие.)

### 5.4. `hg_supp` для конечной суммы атомов

Если `g` задан как `∑ i, w i • Atom (B i) t (τ i)`, то:

```lean
lemma support_hg_subset_Icc {K t : ℝ} {ι : Type} [Fintype ι]
    (w : ι → ℝ) (B τ : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hB : ∀ i, 0 < B i) (hτ : ∀ i, |τ i| + B i ≤ K) :
    Function.support (fun x => ∑ i, w i • Atom (B i) t (τ i) x) ⊆ Set.Icc (-K) K := by
  intro x hx_supp
  -- same contrapositive trick:
  -- assume |x| > K, show sum = 0 (each term is 0), contradiction.
  ...
```

Тут можно не разворачивать support-of-sum леммы: просто докажи “вне \([-K,K]\) сумма равна нулю” через `Fintype.sum_eq_zero` + `Atom_eq_zero_of_abs_gt`.

### 5.5. “Triangle inequality chain” для `h_approx`

Это буквально Step 4 (6.7) из RH_Q3:【253:8†RH_Q3.pdf†L32-L44】

```lean
lemma sup_on_sub_le_add {K : ℝ} (f g h : ℝ → ℝ) :
    supOnIcc K (fun x => |f x - h x|)
      ≤ supOnIcc K (fun x => |f x - g x|) + supOnIcc K (fun x => |g x - h x|) := by
  -- pointwise triangle: |f-h| ≤ |f-g| + |g-h|, then take sup
```

А если у тебя три шага (как в (6.7)), то:

```lean
lemma sup_on_sub_le_three {K : ℝ} (f g h u : ℝ → ℝ) :
    supOnIcc K (fun x => |f x - u x|)
      ≤ supOnIcc K (fun x => |f x - g x|)
      + supOnIcc K (fun x => |g x - h x|)
      + supOnIcc K (fun x => |h x - u x|) := by
  -- apply sup_on_sub_le_add twice, plus `linarith`
```

Этого обычно хватает, чтобы закрыть `h_approx`: ты уже имеешь три оценки `< ε/3`, дальше `linarith`.

---

## 6. Полный proof sketch для плотности (под Opt. 2)

Я дам ровно ту структуру, которая ложится на Lean и совпадает со “Fixed-\(t_0\) cone density” (Lemma 6.4).【253:9†RH_Q3.pdf†L23-L63】

### 6.1. Входные данные
Пусть \(\Phi\in W_K\):  
- even, nonneg, continuous, и “живёт” в \([-K,K]\) (в твоём смысле).

Фиксируем \(\varepsilon>0\). Цель: построить \(g\) — конечную неотрицательную комбинацию атомов с \(|\tau|+B\le K\), такую что
\[
\sup_{|x|\le K}|\Phi(x)-g(x)| < \varepsilon.
\]

### 6.2. Шаг A: кусочно-линейная аппроксимация “шляпами” (Fejér)
Берём сетку шага \(\delta>0\) на \([-K,K]\). Строим положительную “hat interpolation”
\[
h(x)=\sum_j \Phi(\tau_j)\,H_j(x),\qquad H_j(x)=F_\delta(x-\tau_j),
\]
(и потом even-симметризацию, если строишь только на \([0,K]\)).

За счёт равномерной непрерывности \(\Phi\) на компакте получаешь
\[
\|h-\Phi\|_\infty < \varepsilon/3.
\]

(Это стандартный факт; в Lemma 6.4 это именно “positive piecewise-linear interpolation”.【253:9†RH_Q3.pdf†L28-L35】)

### 6.3. Шаг B: замена “шляпы” на “шляпа×heat”
Теперь для фиксированного \(t=t_{\mathrm{sym}}\) определяешь
\[
g(x)=\sum_j c_j\,\mathrm{Atom}(\delta,t,\tau_j)(x)
\]
с подходящими коэффициентами \(c_j\ge 0\).

Смысл коэффициентов: внутри носителя каждой шляпы \(H_j\) heat-фактор почти константа, поэтому можно выбрать \(c_j\) так, чтобы \(c_j\cdot \mathrm{Atom}\) хорошо повторял \(\Phi(\tau_j)H_j\).

Оценка:
- на компакте heat-функция липшицева, значит
  \[
  |H_t(u)-H_t(v)|\le L\,|u-v|
  \]
  для \(u,v\in[-2K,2K]\).
- на носителе \(H_j\) имеем \(|x-\tau_j|\le \delta\), поэтому
  \[
  |H_t(x-\tau_j)-H_t(0)| \le L\delta.
  \]
- значит разность между “чистой шляпой” и “шляпа×heat” контролируется \(\sim L\delta\cdot \|c\|_{\ell^1}\), как в Lemma 6.4.【253:9†RH_Q3.pdf†L34-L63】

Выбираешь \(\delta\) достаточно малым, чтобы
\[
\|g-h\|_\infty < \varepsilon/3.
\]

### 6.4. Шаг C: support-ограничение \(|\tau|+\delta\le K\)
И вот тут твой текущий Lean ломается:  
ты должен изначально выбирать только те \(\tau_j\), для которых \(|\tau_j|+\delta\le K\). Это ровно условие генераторов в Lemma 6.4.【253:9†RH_Q3.pdf†L23-L27】

Тогда каждый атом автоматически нулевой вне \([-K,K]\) → `hg_supp` закрывается.

### 6.5. Шаг D: собрать ошибки треугольником (твой `h_approx`)
Финал — просто Step 4 (6.7):
\[
\|g-\Phi\|_\infty \le \|g-h\|_\infty + \|h-\Phi\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
Если у тебя 3 промежуточных объекта (как в A1’ Step 4), то ровно:
\[
\sup|h-f|\le \sup|h-g^\mathrm{sym}_R|+\sup|g^\mathrm{sym}_R-g|+\sup|g-f|,
\]
и это **один-в-один** твой `h_approx` “triangle inequality chain”.【253:8†RH_Q3.pdf†L32-L44】

---

## 7. Аудит (Edge check)

1. **Ключевой феномен:** условие \(|\tau|+B\le K\) не “косметика”, оно логически необходимо, чтобы атомы попадали в `support ⊆ Icc (-K) K` при неотрицательных весах (нет компенсации снаружи).  
2. **Проверка на границе:** если твой `W_K` допускает функции, которые не обязаны быть 0 на \(\pm K\), то нужно убедиться, что твоя версия “hat interpolation” действительно аппроксимирует их *в суп-норме*. В спецификации это ок, потому что пространство задаётся через равномерную норму и конструкция делается на компакте; в Lean это обычно стабильно, но если ты жёстко требуешь `Function.support ⊆ Icc`, то global-continuity/значение на границе может стать тонким местом (смотри, как именно задан `W_K` у тебя).  
3. **Рутинные шаги:** finite sum continuity/even/nonneg ты уже закрыл — отлично.

---

## 8. Что именно менять в Lean (минимальный diff)

**Ровно одна правка:** в генераторах `AtomCone_K` замени условие  
`τ ∈ Icc (-K) K ∧ B ≤ K`  
на  
`0 < B ∧ |τ| + B ≤ K`  
(или эквивалент `|τ| ≤ K - B`, но первый вариант удобнее для `linarith`).

После этого:

- `hg_supp` закрывается через `support_Atom_subset_Icc` + “вне \([-K,K]\) сумма = 0”.
- `h_approx` закрывается через `sup_on_sub_le_three` и три уже имеющиеся оценки `< ε/3` (структура как в (6.7)).【253:8†RH_Q3.pdf†L32-L44】

---

Если хочешь, я могу написать **конкретные Lean-тактики** для двух мест, которые обычно “болят”:
1) преобразование `|x| > |τ| + B` ⇒ `B ≤ |x-τ|` и `B ≤ |x+τ|`;  
2) лемму “sup of pointwise ≤ sup + sup” (там иногда надо аккуратно с `sSup`/`Real`).

Но по сути: **твоя проблема — не в heat tail, а в неправильном домене параметров \((B,\tau)\)**. Fix: \(|\tau|+B\le K\). Это прямо зафиксировано в спеках.

## ASSISTANT
## 0. Теорема: A1’ density — фикс “support” (статус: стандартная математика / Lean-патч)

**Точная формулировка (в одном предложении):**  
Для любого \(K>0\) и фиксированного \(t>0\), если разрешить **только те Fejér×heat-атомы**, у которых параметр центра \(\tau\) и ширина \(B\) удовлетворяют
\[
|\tau| + B \le K,
\]
то (i) каждый такой атом имеет `Function.support ⊆ Icc (-K) K`, и (ii) конус конечных неотрицательных сумм таких атомов остаётся **плотным** в \(W_K\) (в норме \(\|\cdot\|_\infty\) на \([-K,K]\), а значит и в “глобальной” \(\|\cdot\|_\infty\), поскольку обе функции ноль вне \([-K,K]\)).

**Почему это именно “правильный” фикс:** твоя текущая формулировка `AtomCone_K` требует `support g ⊆ [-K,K]`, но текущие параметры атомов (`τ ∈ [-K,K]`, `B ≤ K`) дают лишь `support ⊆ [-K-B, K+B] ⊆ [-2K,2K]`. Это не баг в лемме — это несовместимость спецификаций.

---

## 1. Контекст: где именно ломается

### Что у тебя сейчас
- `W_K` требует (в Lean)  
  `Function.support Φ ⊆ Set.Icc (-K) K`.
- `Atom` (симметризованный) по сути имеет поддержку примерно
  \[
  \operatorname{supp}(\Phi_{B,t,\tau}) \subset [\tau-B,\tau+B] \cup [-\tau-B,-\tau+B]
  \subset [-|\tau|-B,\ |\tau|+B].
  \]
- При одной лишь гипотезе `|τ| ≤ K` и `B ≤ K` получаешь максимум  
  `support ⊆ [-2K,2K]`, и это *не* достаточно для `W_K`.

### Сигнал/аномалия
**Ключевой факт:** heat kernel \(H_t\) *не обрезает поддержку*, потому что \(H_t(x)\neq 0\) для всех \(x\).  
Значит поддержка произведения “Fejér × heat” задаётся **Fejér-обрезкой**, но она даёт “полосу” ширины \(B\) вокруг \(\pm\tau\). Поэтому условие поддержки внутри \([-K,K]\) *эквивалентно* \( |\tau|+B\le K \).

---

## 2. Определения и нотация

Пишу в терминах твоих Lean-имен:

- `FejerKernel B x = max 0 (1 - |x|/B)` (поддержка внутри \([-B,B]\)).
- `HeatKernel t x ∝ exp(-x^2/(4t))` (строго положительна на \(\mathbb R\)).
- `Atom B t τ x := 1/2 * (FejerKernel B (x-τ) * HeatKernel t (x-τ) + FejerKernel B (x+τ) * HeatKernel t (x+τ))`.

---

## 3. Выбранный подход

Я выбираю **Option 2**:

> **Ограничить параметры атомов условием** `|τ| + B ≤ K` (вместо “τ ∈ [-K,K] и B ≤ K”)  
> и доказывать плотность уже для этого “внутреннего” набора атомов.

Почему это лучше, чем “расширить K до 2K”:
- Закрывает `hg_supp` напрямую (без изменения `W_K` и без каскада правок A2/Main_closure).
- Совместимо с целью Main_closure: тебе нужен конус **внутри** `W_K`, иначе непрерывность/липшицевость \(Q\) на `W_K` не применима как запланировано.
- Это ровно тот режим, который в твоём TeX уже присутствует как отдельная “fixed-\(t_0\)” идея: использовать **малые** \(B\) и центры, не выходящие за границы компакта.

---

## 4. Roadmap: как закрыть два оставшихся sorry

### (A) `hg_supp`
1) Докажи поддержку одного атома:
   \[
   \operatorname{supp}(\text{Atom }B\,t\,\tau) \subset [-|\tau|-B,\ |\tau|+B].
   \]
2) Из `|τ| + B ≤ K` получи `support Atom ⊆ Icc (-K) K`.
3) Для конечной суммы — стандартно: поддержка суммы ⊆ объединение поддержек.

После этого `hg_supp` становится “routine step”.

### (B) `h_approx` (triangle inequality chain)
Останется чисто “нормовая” сборка:
\[
\|h-f\|_{\infty,[-K,K]} \le \|h-g\|_{\infty,[-K,K]}+\|g-f\|_{\infty,[-K,K]},
\]
и аналогично для трёх звеньев, как у тебя в Step 4 TeX.

---

## 5. Lean-ready lemma statements

Ниже — **прямые** формулировки, которые можно вставлять как цели для Aristotle/ручного proof. Я специально делаю их “локальными” и максимально переиспользуемыми.

### 5.1. Поддержка Fejér-обрезки и одного сдвинутого терма

```lean
lemma fejerKernel_eq_zero_of_abs_ge {B x : ℝ} (hB : 0 < B) (hx : B ≤ |x|) :
    FejerKernel B x = 0 := by
  -- unfold FejerKernel; simp [hx, hB.le]  -- depending on your def
  sorry
```

```lean
lemma support_fejer_shift_mul_heat_subset
  {B t τ : ℝ} (hB : 0 < B) :
  Function.support (fun x => FejerKernel B (x - τ) * HeatKernel t (x - τ))
    ⊆ Set.Icc (τ - B) (τ + B) := by
  intro x hx
  -- use support_subset_iff: hx : x ∈ support → term ≠ 0
  -- show |x-τ| < B, hence x ∈ Icc (τ-B) (τ+B)
  sorry
```

**Комментарий:** тут важно использовать “heat kernel ≠ 0” как *не усложняющий* фактор: вне Fejér-окна всё равно ноль.

### 5.2. Поддержка Atom: “полоса вокруг ±τ”

```lean
lemma support_atom_subset_abs_add
  {B t τ : ℝ} (hB : 0 < B) :
  Function.support (Atom B t τ)
    ⊆ Set.Icc (-(|τ| + B)) (|τ| + B) := by
  intro x hx
  -- Atom is sum of two shifted terms; support of add ⊆ union of supports
  -- each term support ⊆ Icc (τ-B) (τ+B) and Icc (-τ-B) (-τ+B)
  -- then show both are ⊆ Icc (-(|τ|+B)) (|τ|+B)
  sorry
```

И “моментальный” королларий, который тебе нужен для `hg_supp`:

```lean
lemma support_atom_subset_Icc
  {K B t τ : ℝ} (hB : 0 < B) (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  have h0 := support_atom_subset_abs_add (B:=B) (t:=t) (τ:=τ) hB
  -- now just squeeze: Icc (-(|τ|+B)) (|τ|+B) ⊆ Icc (-K) K
  -- using hτ
  exact Set.Subset.trans h0 ?_
```

### 5.3. Поддержка конечной суммы атомов

```lean
lemma support_finset_sum_subset_Icc
  {ι : Type*} {K : ℝ} {s : Finset ι}
  {w : ι → ℝ} {f : ι → ℝ → ℝ}
  (hsupp : ∀ i ∈ s, Function.support (f i) ⊆ Set.Icc (-K) K) :
  Function.support (fun x => ∑ i in s, w i * f i x)
    ⊆ Set.Icc (-K) K := by
  -- use support_add/ support_sum_subset; scalar doesn't enlarge support
  sorry
```

Эта лемма — “ключ” для закрытия `hg_supp` сразу после того, как ты поменяешь предикат допустимости параметров атомов.

### 5.4. Треугольник для `h_approx` в supnorm на `Icc`

Если у тебя supnorm оформлен как `sSup` по `Icc`, то удобно иметь лемму:

```lean
lemma supOn_abs_sub_le_add_supOn_abs_sub
  {K : ℝ} {f g h : ℝ → ℝ} :
  (sSup ((fun x => |h x - f x|) '' (Set.Icc (-K) K)))
    ≤ (sSup ((fun x => |h x - g x|) '' (Set.Icc (-K) K)))
    + (sSup ((fun x => |g x - f x|) '' (Set.Icc (-K) K))) := by
  -- pointwise: |h-f| ≤ |h-g| + |g-f|, then sSup_le ...
  sorry
```

Если же у тебя уже есть `‖·‖∞` на restricted domain (например, в `C(Set.Icc ...)`), то можно писать через `norm_sub_le`:

```lean
lemma norm_sub_le_three_chain
  {K : ℝ} {f g h : (Set.Icc (-K) K) → ℝ} :
  ‖h - f‖ ≤ ‖h - g‖ + ‖g - f‖ := by
  simpa using norm_sub_le h g f
```

(Подстрой под то, как именно у тебя закодирован “uniform norm on [-K,K]”.)

### 5.5. Собственно “density” при ограничении `|τ|+B≤K`

Тут лучше сразу формулировать в стиле: “для любого Φ∈W_K и ε>0 найдётся g∈AtomCone_K …”.

```lean
theorem atomCone_dense_in_WK
  {K t0 : ℝ} (hK : 0 < K) (ht0 : 0 < t0) :
  ∀ {Φ : ℝ → ℝ}, Φ ∈ W_K K →
  ∀ ε : ℝ, 0 < ε →
    ∃ g : ℝ → ℝ, g ∈ AtomCone_K K t0 ∧
      (∀ x ∈ Set.Icc (-K) K, |g x - Φ x| < ε) := by
  sorry
```

**Важно:** `AtomCone_K K t0` должен быть переопределён так, чтобы генераторы удовлетворяли `|τ| + B ≤ K` (или чтобы членство содержало эту гипотезу), иначе `hg_supp` снова не получится.

---

## 6. Конкретный минимальный патч в Lean (что именно менять)

### Вариант А (самый чистый)
**Поменять** в определении `AtomCone_K` (или в `AtomParams`) ограничение параметров на:

- `0 < B`
- `0 < t` (или фиксированный `t0`)
- `|τ| + B ≤ K`

и **убрать** требование `support ⊆ Icc (-K) K` из “дано” (оно станет леммой), либо оставить как поле, но теперь оно доказывается.

### Вариант Б (минимум диффа, если ты не хочешь трогать AtomCone_K сильно)
Оставь `AtomCone_K` как есть, но **в плотностной конструкции** выбирай только такие τ, которые удовлетворяют `|τ| + B ≤ K`.  
Тогда `hg_supp` закрывается без изменения API, но тебе придётся поправить выбор сетки/параметров в аппроксимации (чтобы центры не выходили за допустимый “внутренний” интервал).

---

## 7. Аудит edge-cases

1) **B=0**: если в коде допускается, то либо `FejerKernel 0` определён как 0 и поддержка пустая (тривиально), либо нужно жёстко требовать `0 < B` в Atom-параметрах (я бы так и сделал).

2) **`Function.support` vs “топологическая поддержка”**:  
`Function.support` = `{x | f x ≠ 0}`, она не замкнута. Для Fejér-hat это даёт `Ioo` внутри `Icc`, но это ок: `Ioo ⊆ Icc`.

3) **Heat kernel**: строго положительна → *не расширяет поддержку* произведения; это надо использовать как ускорение доказательства.

---

## 8. Итог

- Проблема — не в лемме, а в том, что текущие ограничения на параметры атомов **логически слабее**, чем требование `support ⊆ [-K,K]`.
- Самый прямой фикс: **встроить** ограничение `|τ| + B ≤ K` в “допустимые атомы” и доказать, что плотность не теряется.
- Я дал набор “Lean-ready” лемм, которые напрямую закрывают `hg_supp` и дают нормовую инфраструктуру для `h_approx`.

Если ты пойдёшь этим путём, `hg_supp` превратится в 10–20 строк (в основном `support_subset_iff` + `abs`-алгебра), а `h_approx` станет чистой сборкой треугольником по `sup` на `Icc`.

## ASSISTANT
## 0. Диагноз: где реально ломается `hg_supp`

### Факт 0.1 (важный, снимает ложный след)
**Бесконечная поддержка heat kernel тут НЕ виновата.**  
Ты используешь **произведение** `FejerKernel * HeatKernel`. Для функции
\[
u(x)=F_B(x-\tau)\cdot H_t(x-\tau)
\]
всегда верно:
\[
u(x)=0 \quad \text{везде, где } F_B(x-\tau)=0,
\]
то есть
\[
\operatorname{supp}(u)\subseteq \operatorname{supp}(F_B(\cdot-\tau))\subseteq [\tau-B,\tau+B].
\]
Поэтому **heat не расширяет support** — его “бесконечность” убивается множителем `FejerKernel`.

### Факт 0.2 (истинная причина противоречия)
Проблема — **геометрия сдвига**: если разрешать \(|\tau|\le K\) и \(B\le K\), то атом имеет support примерно в \([\tau-B,\tau+B]\), и при \(\tau\) близком к \(K\) он выходит за \([-K,K]\).  
Именно это и даёт твой текущий вывод: `support ⊆ [-2K,2K]`, а нужно `⊆ [-K,K]`.

---

## 1. Лучший вариант из твоих опций

### Выбор: **Option 2 (ограничить параметры атомов)**
**Точное ограничение:**
\[
|\tau|+B\le K.
\]
Это эквивалентно \(\tau\in[-K+B,\,K-B]\) при фиксированном \(B>0\).

**Почему это лучший вариант**
- ✅ *Минимальная правка*: меняешь только “валидность параметров” генераторов в `AtomCone_K` (или при построении `hg`).
- ✅ `hg_supp` становится прямым: вне \([-K,K]\) оба Fejér-фактора нули ⇒ атом 0 ⇒ сумма 0.
- ✅ Не требует “обрезки” heat, не требует новых оценок хвоста.
- ✅ Совместим с идеей A1′ fixed‑t density (у тебя \(t=t_\mathrm{sym}=3/50\) фиксирован).

### Важная аномалия (надо назвать и закрыть)
Если твой `W_K` в Lean определён как:
- `ContinuousOn Φ (Icc (-K) K)`  
- `Function.support Φ ⊆ Icc (-K) K`

то он **разрешает скачок в точках ±K**: можно иметь \(\Phi(K)\neq 0\), оставаясь `ContinuousOn` на `Icc`, и при этом \(\Phi=0\) вне `Icc`.  
Но **любая** твоя атомарная аппроксимация (как функция на ℝ) непрерывна и равна 0 вне некоторого компакта ⇒ она **обязательно** удовлетворяет \(g(\pm K)=0\) если её support ⊆ `Icc (-K) K`.  
Отсюда:

> **Если в `W_K` допускаются функции с \(\Phi(\pm K)\neq 0\), то плотность в \(\|\cdot\|_\infty\) на `Icc` принципиально ложна.**

**Решение (самое чистое):** усилить `W_K`, чтобы он отражал “Weil tests = C_c(ℝ)”:
- заменить `ContinuousOn` на `Continuous` (глобально на ℝ),  
- и оставить `Function.support ⊆ Icc (-K) K`.  
Тогда автоматически \(\Phi(\pm K)=0\), и плотность становится корректной.

Если перепиливать `W_K` сейчас дорого — временный вариант: в плотности (A1) требовать дополнительно `Φ (-K)=0` и `Φ K=0`. Но системно лучше исправить `W_K`.

---

## 2. Доказательный скетч для Option 2 (с фиксированным `t = t_sym`)

Ниже — схема, которая прямо соответствует тому, что тебе надо для закрытия `hg_supp` и `h_approx`.

### 2.1. Support-лемма (закрывает `hg_supp`)
**Цель:** при \(B>0\) и \(|\tau|+B\le K\) доказать
\[
\operatorname{support}(\mathrm{Atom}(B,t,\tau))\subseteq [-K,K].
\]

**Ключевой шаг:** если \(|x|>K\), то
\[
|x-\tau|\ge |x|-|\tau| > K-|\tau| \ge B,
\]
значит \(F_B(x-\tau)=0\). Аналогично \(F_B(x+\tau)=0\). Тогда оба слагаемых атома равны 0, и `Atom ... x = 0`. Следовательно, `x ∉ Function.support`.

### 2.2. Плотность (закрывает `h_approx` после перестройки сетки)
Пусть \(\Phi\in W_K\) и \(\varepsilon>0\), \(t=t_\mathrm{sym}\) фиксирован.

**Шаг A (подготовка: граничная зона)**  
Так как \(\Phi\) непрерывна на ℝ и support ⊆ [-K,K], то \(\Phi(\pm K)=0\).  
Берём \(\eta>0\) так, чтобы
\[
|x|\in[K-\eta, K] \Rightarrow |\Phi(x)|<\varepsilon/6.
\]

**Шаг B (позитивная “шляпная” интерполяция Fejér-ами)**  
Берём \(B>0\) настолько малым, что \(B\le \eta\) и чтобы на компакте \([-K,K]\) модуль непрерывности даёт:
\[
|x-y|\le B \Rightarrow |\Phi(x)-\Phi(y)| < \varepsilon/6.
\]
Строим равномерную сетку центров \(\tau_j\) **внутри**
\[
\tau_j\in[-K+B,\,K-B],
\]
так что автоматически \(|\tau_j|+B\le K\).  
Определяем “шляпы”:
\[
H_j(x):=\Lambda_B(x-\tau_j).
\]
Делаем стандартную неотрицательную аппроксимацию (кусочно-линейная интерполяция/partition of unity):
\[
h(x):=\sum_j \Phi(\tau_j)\,H_j(x).
\]
Тогда \(\|h-\Phi\|_{\infty,[-K,K]}<\varepsilon/3\) (это ровно то место, где в Lean обычно нужна твоя лемма про модуль непрерывности + свойства hat-функций).

**Шаг C (вкрутить фиксированный heat фактор, не ломая знак)**  
Хотим заменить \(H_j\) на \(H_j\cdot \rho_t(\cdot-\tau_j)\), то есть на “несимметризованный” атом.  
На support каждого \(H_j\) имеем \(|x-\tau_j|\le B\).  
Так как \(\rho_t\) гладкая, то на \([-B,B]\) она Lipschitz:
\[
|\rho_t(u)-\rho_t(0)| \le L_t\,|u| \le L_t B.
\]
Берём коэффициенты
\[
c_j := \frac{\Phi(\tau_j)}{\rho_t(0)} \ge 0,
\]
и ставим
\[
g(x):=\sum_j c_j\,\Lambda_B(x-\tau_j)\,\rho_t(x-\tau_j).
\]
Тогда на [-K,K]:
\[
|g(x)-h(x)| \le \sum_j \Phi(\tau_j)\,H_j(x)\cdot \frac{|\rho_t(x-\tau_j)-\rho_t(0)|}{\rho_t(0)}
\le \frac{L_t B}{\rho_t(0)}\sum_j \Phi(\tau_j)H_j(x).
\]
А сумма \(\sum_j \Phi(\tau_j)H_j(x)\) контролируется сверху чем-то вроде \(C\|\Phi\|_\infty\) (для равномерных hat-ов обычно \(C\le 2\), потому что пересекаются не более двух шляп).  
Берём \(B\) ещё меньше, чтобы \(\|g-h\|_{\infty,[-K,K]}<\varepsilon/3\).

**Шаг D (even-симметризация)**
Если в Lean атом определён уже как сумма сдвигов ±τ (как у тебя), то этот шаг уже встроен. Иначе:  
\[
g_{\mathrm{even}}(x):=\frac{g(x)+g(-x)}{2},
\]
неотрицательность сохраняется, ошибка в sup норме не растёт.

**Шаг E (triangle inequality = твой `h_approx`)**
\[
\|g-\Phi\|_\infty \le \|g-h\|_\infty + \|h-\Phi\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
(Если у тебя в коде 3 шага, то будет сумма из трёх \(\varepsilon/3\).)

**Support-часть:** поскольку каждый центр удовлетворяет \(|\tau_j|+B\le K\), по лемме из 2.1 каждый атом имеет support ⊆ [-K,K], значит и сумма тоже — это и закрывает `hg_supp`.

---

## 3. Lean-ready формулировки (скелеты)

Я пишу максимально “mathlib‑стайл”, но имена твоих дефов могут отличаться — подставишь свои.

### 3.1. Леммы про Fejér kernel
```lean
-- Fejér hat: Λ_B(x) = max 0 (1 - |x|/B)
lemma fejerKernel_eq_zero_of_abs_ge (hB : 0 < B) {x : ℝ}
    (hx : |x| ≥ B) :
    FejerKernel B x = 0 := by
  -- unfold FejerKernel; simp [hx, hB.le]
  sorry

lemma fejerKernel_eq_zero_of_le_sub (hB : 0 < B) {x τ K : ℝ}
    (hx : |x| > K) (hτ : |τ| + B ≤ K) :
    FejerKernel B (x - τ) = 0 := by
  have : |x - τ| ≥ B := by
    -- |x-τ| ≥ |x| - |τ| > K - |τ| ≥ B
    -- use `abs_sub` triangle inequality: `abs_sub_ge_...`
    sorry
  exact fejerKernel_eq_zero_of_abs_ge hB this
```

### 3.2. Атом равен нулю вне окна ⇒ support-лемма (`hg_supp` ядро)
```lean
lemma atom_eq_zero_of_abs_gt (hB : 0 < B) (hτ : |τ| + B ≤ K) {x : ℝ}
    (hx : |x| > K) :
    Atom B t τ x = 0 := by
  -- Atom = F(x+τ)*H(x+τ) + F(x-τ)*H(x-τ)
  -- show both Fejér factors vanish
  have h1 : FejerKernel B (x - τ) = 0 := by
    -- from |x|>K and |τ|+B≤K
    sorry
  have h2 : FejerKernel B (x + τ) = 0 := by
    -- similar, using |x+τ| ≥ |x|-|τ|
    sorry
  simp [Atom, h1, h2]

lemma support_atom_subset_Icc (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- hx : Atom ... x ≠ 0
  by_contra hxIcc
  have hxabs : |x| > K := by
    -- x ∉ Icc(-K,K) ↔ |x| > K  (need K≥0 or prove directly)
    sorry
  have : Atom B t τ x = 0 := atom_eq_zero_of_abs_gt (B:=B) (t:=t) (τ:=τ) (K:=K) hB hτ hxabs
  exact hx (by simpa [this])
```

### 3.3. Support для конечной суммы атомов
```lean
lemma support_finset_sum_subset_Icc {ι : Type*} (s : Finset ι)
    (f : ι → ℝ → ℝ)
    (h : ∀ i ∈ s, Function.support (f i) ⊆ Set.Icc (-K) K) :
    Function.support (∑ i in s, f i) ⊆ Set.Icc (-K) K := by
  -- prove: outside Icc, every f i is 0 ⇒ sum is 0
  -- use `Finset.induction`
  sorry
```

### 3.4. Lipschitz на heat kernel на малом интервале
(это нужно для шага “вкрутить heat”, чтобы контролировать `|ρ_t(u)-ρ_t(0)|`)

```lean
lemma heatKernel_lipschitzOn_Icc (ht : 0 < t) (R : ℝ) :
    ∃ L : ℝ, 0 ≤ L ∧
      LipschitzOnWith L (HeatKernel t) (Set.Icc (-R) R) := by
  -- HeatKernel is C¹, bounded derivative on compact ⇒ Lipschitz
  -- can be done via `ContinuousOn.compact` + `Real.norm_deriv_le_...`
  sorry
```

### 3.5. Главная плотность (вариант “фиксированный t_sym” + параметрное ограничение)
```lean
theorem atomCone_dense_WK_fixed_t
    (hK : 0 < K) (ht : 0 < t_sym) :
    ∀ Φ, Φ ∈ W_K K →
    ∀ ε, 0 < ε →
    ∃ g, g ∈ AtomCone_K K t_sym ∧
      (∀ x ∈ Set.Icc (-K) K, |g x - Φ x| ≤ ε) := by
  -- proof via hat interpolation + heat Lipschitz + triangle inequality
  sorry
```

И отдельно — “локальная” лемма, которая прямо закрывает `hg_supp` в твоём текущем файле:

```lean
lemma hg_supp_of_params
    (hτ : ∀ j, j ∈ J → |τ j| + B ≤ K)
    (hB : 0 < B) :
    Function.support (∑ j in J, w j • Atom B t_sym (τ j))
      ⊆ Set.Icc (-K) K := by
  -- reduce to `support_atom_subset_Icc` + `support_finset_sum_subset_Icc`
  sorry
```

---

## 4. Что конкретно делать в Lean (самый короткий путь)

1) **Поменяй параметрное условие в генераторах**:  
везде где ты сейчас используешь `|τ| ≤ K` (и отдельно `B ≤ K`), замени/усиль на:
```lean
hτ : |τ| + B ≤ K
```

2) **Сетку τ_j при построении `hg` бери не на [-K,K], а на [-K+B, K-B]**.  
Это одна строчка, но именно она и чинит support.

3) **Проверь W_K**: если у тебя только `ContinuousOn` на `Icc`, то ты потенциально доказываешь ложную плотность.  
Если цель — Weil тесты типа `C_c(ℝ)`, то правильно сделать:
- `Continuous Φ` (глобально),
- `Function.support Φ ⊆ Icc (-K) K`,
и тогда всё согласуется с атомами.

---

Если хочешь, я могу также “приземлить” это на твою конкретную пару `hg_supp`/`h_approx`: ты скидываешь точные Lean-стейтменты этих двух `sorry`, и я перепишу их в стиле `by`‑скелета с минимальными правками вокруг (но уже сейчас у тебя есть полный план, что именно менять). fileciteturn0file21

## ASSISTANT
## 0. Теорема: Support‑compatible A1′ density (фиксируем `t_sym`) — **Статус**
**Точная формулировка (одним предложением):**  
Для любого \(K>0\) и любого \(\Phi\in W_K\), для любого \(\varepsilon>0\) существует \(g\) — конечная неотрицательная линейная комбинация Fejér×heat‑атомов с **фиксированным** \(t=t_{\mathrm{sym}}\) и параметрами \((B,\tau)\) удовлетворяющими \(|\tau|+B\le K\), такая что \(\|g-\Phi\|_\infty<\varepsilon\) и \(\mathrm{supp}(g)\subseteq[-K,K]\).

**Статус:** стандартная математика (ZFC), это ровно “Fixed‑\(t_0\) cone density” как отдельная лемма в тексте. 【6:10†RH_Q3.pdf†L23-L63】

---

## 1. Формальное утверждение: объекты, гипотезы, логическая форма

### 1.1 Универсум
- Функции \(\Phi:\mathbb R\to\mathbb R\).
- Норма: \(\|\cdot\|_\infty\) на \([-K,K]\) (а если \(\mathrm{supp}\subseteq[-K,K]\), то это то же самое, что суп по \(\mathbb R\)).

### 1.2 “Правильные” атомы (support‑safe)
Атомы вида (в твоей нотации / в PDF нотации):
\[
\Phi_{B,t,\tau}(\xi)=\tfrac12\Big[\Lambda_B(\xi-\tau)\rho_t(\xi-\tau)+\Lambda_B(\xi+\tau)\rho_t(\xi+\tau)\Big],
\]
где \(\Lambda_B(x)=(1-|x|/B)_+\) — Fejér “hat”, \(\rho_t(x)=(4\pi t)^{-1/2}e^{-x^2/(4t)}\). 【6:12†RH_Q3.pdf†L39-L56】

### 1.3 Целевая логическая форма (для Lean‑аксиомы `h_approx`)
\[
\forall \Phi\in W_K\,\forall\varepsilon>0\,\exists g\in\mathrm{AtomCone}_K(t_{\mathrm{sym}}):\ \|g-\Phi\|_\infty<\varepsilon.
\]
Критически: \(\mathrm{AtomCone}_K\) должен быть построен из атомов с \(|\tau|+B\le K\), иначе `hg_supp` физически ложен.

---

## 2. Определения и нотация (и где именно у тебя конфликт)

### 2.1 Твой феномен/аномалия (signal)
Ты уже измерил: если разрешать \(\tau\in[-K,K]\) и \(B\le K\), то поддержка отдельного сдвинутого “hat” лежит в \([\tau-B,\tau+B]\), и в худшем случае это даёт \([-2K,2K]\). Это *не* помещается в требование `Function.support g ⊆ [-K,K]`.  
**Это не баг доказательства — это баг определения допустимых атомов для конуса.**

### 2.2 Важное уточнение про heat kernel
“У heat kernel бесконечная поддержка” — в данном месте **не проблема**, потому что атом — это *произведение* `FejerKernel B (x±τ)` (компактная поддержка) на `HeatKernel t (x±τ)`. Поддержка произведения ⊆ поддержке Fejér‑фактора. Поэтому support‑проблема на 100% сидит в геометрии \(\tau\pm B\), а не в гауссовом хвосте.

### 2.3 Что такое \(W_K\) в логике main closure
В тексте прямо используется: “\(W_K\)” — конус even/nonneg **Cc tests** поддержанных в \([-K,K]\) для LF‑лимита. 【6:11†RH_Q3.pdf†L40-L44】  
И это согласуется с тем, что в closure нужен конечный prime‑самплер (иначе сумма по \(n\) не обрежется). 【6:10†RH_Q3.pdf†L65-L67】

---

## 3. Dependency list (что тебе реально нужно в Lean)

### 3.1 Support‑леммы
1. \(\Lambda_B(x)=0\) при \(|x|\ge B\), т.е. `support (Λ_B) ⊆ Icc (-B) B` (на самом деле даже ⊆ Ioo).  
2. `support (fun x => f x * g x) ⊆ support f` (и симметрично).
3. Неравенство: \(|x\pm\tau|\ge |x|-|\tau|\).

### 3.2 Lipschitz heat kernel on compact
Нужно ровно то, что в Lemma 6.4: \(\rho_{t_0}\) липшицева на \([-2K,2K]\):  
\(|\rho_{t_0}(x)-\rho_{t_0}(y)|\le L_{t_0}|x-y|\). 【6:10†RH_Q3.pdf†L34-L35】

### 3.3 “Hat interpolation”
Позитивная кусочно‑линейная аппроксимация по сетке:
\(h(\xi)=\sum_j f(\tau_j)\,H_j(\xi)\), \(H_j(\xi)=\Lambda_\delta(\xi-\tau_j)\), и \(\|h-f\|_\infty<\varepsilon/3\). 【6:10†RH_Q3.pdf†L30-L34】

---

## 4. Roadmap (что делать прямо сейчас)

1. **Выбрать Option 2**: переопределить/сузить `AtomCone_K` так, чтобы каждый используемый атом удовлетворял \(|\tau|+B\le K\). Это мгновенно разблокирует `hg_supp`.
2. Доказать `support_atom ⊆ Icc (-(|τ|+B)) (|τ|+B)` и затем королларий `⊆ Icc (-K) K`.
3. Переподключить доказательство плотности к версии “Fixed‑\(t_0\)” (Lemma 6.4): hat‑интерполяция + Lipschitz‑контроль heat‑фактора. 【6:10†RH_Q3.pdf†L23-L63】
4. `h_approx`: просто треугольник \(\|g-f\|\le \|g-h\|+\|h-f\|\) и подбор \(\delta\) чтобы обе части < ε/2 или как в тексте ε/3+ε/3.

---

## 5. Леммы (математика → Lean‑ready формулировки)

Ниже я даю *Lean‑style* заявления. Я не пытаюсь угадать твои точные имена/структуры, но формулировки “под mathlib” и должны лечь почти 1:1.

### 5.1 Support одного атома (ключ к `hg_supp`)
**Математически:** если \(|x|>|τ|+B\), то \(|x\pm τ|>|τ|+B-|τ|=B\), значит \(\Lambda_B(x\pm τ)=0\), значит \(\Phi_{B,t,τ}(x)=0\). Поэтому
\[
\mathrm{supp}(\Phi_{B,t,τ})\subseteq[-(|τ|+B), |τ|+B].
\]

**Lean‑ready:**
```lean
lemma support_Atom_subset_Icc_abs_add
  {B t τ : ℝ} (hB : 0 < B) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-(|τ| + B)) (|τ| + B) := by
  -- idea:
  -- intro x hx; contrapose hx; show Atom B t τ x = 0
  -- use: if |x| > |τ| + B then |x - τ| ≥ |x| - |τ| > B, similarly |x + τ| > B
  -- hence FejerKernel B (x±τ)=0, so Atom=0
  sorry
```

### 5.2 Королларий: support внутри \([-K,K]\) при \(|τ|+B≤K\)
```lean
lemma support_Atom_subset_Icc
  {B t τ K : ℝ} (hB : 0 < B) (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  have h1 := support_Atom_subset_Icc_abs_add (B:=B) (t:=t) (τ:=τ) hB
  -- monotonicity of Icc:
  -- Icc (-(|τ|+B)) (|τ|+B) ⊆ Icc (-K) K
  -- because -(K) ≤ -( |τ|+B ) and (|τ|+B) ≤ K
  exact Set.Subset.trans h1 ?_
```

### 5.3 Support конечной суммы (для `hg_supp`)
Если `hg = ∑ w_i • Atom ...` и каждый атом поддержан в \([-K,K]\), то так же и сумма.
```lean
lemma support_sum_subset_Icc
  {ι : Type*} [DecidableEq ι] {s : Finset ι}
  {f : ι → ℝ → ℝ} {K : ℝ}
  (hs : ∀ i ∈ s, Function.support (f i) ⊆ Set.Icc (-K) K) :
  Function.support (∑ i in s, f i) ⊆ Set.Icc (-K) K := by
  -- use Function.support_sum_subset or prove by elem chase
  sorry
```

### 5.4 Lipschitz heat kernel on compact
В тексте: “ρ_t0 positive and Lipschitz on [−2K,2K]”. 【6:10†RH_Q3.pdf†L34-L35】

Lean‑style (вариант через `LipschitzOnWith`):
```lean
lemma heatKernel_lipschitzOn_Icc
  {t K : ℝ} (ht : 0 < t) :
  ∃ L : ℝ≥0, LipschitzOnWith L (HeatKernel t) (Set.Icc (-2*K) (2*K)) := by
  -- use differentiability of exp + bounded derivative on compact
  sorry
```

### 5.5 Fixed‑t cone density (Option 2 плотность)
Это прямо Lemma 6.4. 【6:10†RH_Q3.pdf†L23-L63】

Lean‑style (приблизительно):
```lean
theorem fixed_t_density_WK
  (K : ℝ) (hK : 0 < K) :
  Dense (AtomConeFixed K t_sym) (W_K K) := by
  -- or: ∀ f ∈ W_K K, ∀ ε>0, ∃ g ∈ AtomConeFixed K t_sym, ‖g - f‖∞ < ε
  sorry
```

Где `AtomConeFixed K t` — конус конечных неотрицательных комбинаций атомов `Atom B t τ` с ограничением `|τ| + B ≤ K`.

---

## 6. Основное доказательство (полный скетч Option 2)

Я даю скетч ровно по Lemma 6.4, потому что она **уже** создана как “правильная” версия под support‑ограничение. 【6:10†RH_Q3.pdf†L23-L63】

### Шаг 0: Опция выбора
**Выбираю Option 2** как единственную “нативную” к твоему `hg_supp`: она решает support без хвостов и без новых truncation‑объектов, и эта версия уже записана как Lemma 6.4 (Fixed‑\(t_0\) cone density)【6:10†RH_Q3.pdf†L23-L63】.

### Шаг 1: Hat‑интерполяция (Fejér без heat)
- Берём \(f\in W_K\) и \(\varepsilon>0\).
- Выбираем равномерную сетку \(\{\tau_j\}\subset[-K,K]\) с шагом \(\delta>0\).
- Определяем “шляпы” \(H_j(\xi)=\Lambda_\delta(\xi-\tau_j)\).
- Определяем \(h(\xi):=\sum_j f(\tau_j)H_j(\xi)\).
- Тогда \(h\ge 0\) и \(\|h-f\|_\infty<\varepsilon/3\) при достаточно мелкой сетке (это стандартная позитивная кусочно‑линейная аппроксимация). 【6:10†RH_Q3.pdf†L30-L34】

**Lean‑заметка:** тебе не нужно всё “теоретически красиво”. Достаточно леммы вида: для непрерывного \(f\) на компакте модуль непрерывности \(\omega_f(\delta)\to 0\), и hat‑интерполяция даёт ошибку ≤ \(\omega_f(\delta)\).  

### Шаг 2: Вставляем heat‑фактор с фиксированным \(t=t_{\mathrm{sym}}\)
В тексте делается:
- \(\rho_{t_0}\) липшицева на \([-2K,2K]\), значит \(|\rho_{t_0}(x)-\rho_{t_0}(y)|\le L_{t_0}|x-y|\) на этом интервале. 【6:10†RH_Q3.pdf†L34-L35】
- Строим
\[
g(\xi)=\sum_j c_j\,\Phi_{\delta,t_0,\tau_j}(\xi)
\]
с коэффициентами \(c_j\) (в PDF стоит \(c_j=f(\tau_j)/\rho_{t_0}(\tau_j)\); по смыслу можно и иначе нормировать, главное — контроль \(|g-h|\) через Lipschitz). 【6:10†RH_Q3.pdf†L35-L41】

Ключевой identity/оценка из текста:
\[
g(\xi)-h(\xi)=\sum_j c_j\,\Lambda_\delta(\xi-\tau_j)\big(\rho_{t_0}(\xi-\tau_j)-\rho_{t_0}(\tau_j)\big),
\]
и тогда
\[
|g(\xi)-h(\xi)|\le L_{t_0}\,\delta \sum_j |c_j|\,\Lambda_\delta(\xi-\tau_j)\le L_{t_0}\,\delta\|c\|_{\ell^1}.
\] 【6:10†RH_Q3.pdf†L42-L61】

Выбираем \(\delta\) так, чтобы \(L_{t_0}\delta\|c\|_{\ell^1}<\varepsilon/3\), получаем \(\|g-h\|_\infty<\varepsilon/3\). 【6:10†RH_Q3.pdf†L55-L63】

### Шаг 3: Треугольник (это твой `h_approx`)
Теперь просто:
\[
\|g-f\|_\infty \le \|g-h\|_\infty+\|h-f\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
Это именно “triangle inequality chain”, которую ты написал как `h_approx`.

### Шаг 4: Support (это твой `hg_supp`)
Ты требуешь `support g ⊆ [-K,K]`.

**Почему это теперь автоматом:**
- Каждый атом \(\Phi_{B,t,\tau}\) имеет поддержку \(\subseteq [-(|\tau|+B), |\tau|+B]\) (лемма 5.1).
- Если ты в конус допускаешь только параметры с \(|\tau|+B\le K\), то каждый атом поддержан в \([-K,K]\) (лемма 5.2).
- Поддержка конечной суммы ⊆ объединение поддержек (лемма 5.3).
- Значит `hg_supp` закрывается без боли.

### Шаг 5: Evenness/nonneg/cont
У тебя это уже закрыто ✅, так что атомы лежат в \(W_K\) по всем полям.

---

## 7. Аудит — edge check (где могут быть мины)

### 7.1 Самая важная мина: что именно значит “\(W_K\)”
В PDF есть два “слоя”:
- Аналитический слой A1′ часто формулируется как плотность на *окне* \([-K,K]\) в \(\|\cdot\|_\infty\)【6:12†RH_Q3.pdf†L1-L5】.
- Но closure/LF‑transfer явно говорит о “Cc tests supported in \([-K,K]\)”【6:11†RH_Q3.pdf†L40-L44】 и про “prime sum finite because supp Φ ⊂ [−K,K]”【6:10†RH_Q3.pdf†L65-L67】.

**Практический вывод для Lean:** если твой `W_K` требует `Function.support Φ ⊆ Icc (-K) K`, то **Option 2 (|τ|+B≤K) — единственная** совместимая версия A1′.

### 7.2 Второй сигнал: “Extend by zero to Cc(R)”
В Theorem 6.3 proof написано “Extend f by zero to a compactly supported \( \tilde f \in C_c(\mathbb R)\)”【6:12†RH_Q3.pdf†L66-L69】.  
Это silently требует, чтобы boundary‑значения не ломали continuity. Если у тебя в Lean `W_K` использует лишь `ContinuousOn` на `Icc (-K) K`, то ты можешь случайно разрешить функции с прыжком в ±K (не Cc). Тогда “плотность в sup‑норме на замкнутом интервале” может стать ложной для конуса непрерывных атомов.

**Если это у тебя реально так:** либо усили `W_K` до `Continuous` (или добавь условия, гарантирующие `ContinuousAt` в ±K), либо работай с нормой/топологией, в которой значения на границе не влияют (но это уже другая игра).

---

## 8. Приложение: минимальный патч‑план в Lean (без философии)

### Patch A (рекомендуемый): сузить AtomCone_K
**Вместо** “\(\tau\in[-K,K]\) и \(B\le K\)”  
**сделай** “\(B>0\) и \(|\tau|+B\le K\)”.

Тогда `hg_supp` закрывается так:
1) `support_Atom_subset_Icc_abs_add`  
2) `support_Atom_subset_Icc`  
3) `support_sum_subset_Icc`

### Patch B (если ты не хочешь менять определение конуса):
Добавь **новый** конус `AtomCone_K_strict` с условием \(|\tau|+B\le K\) и докажи density именно для него (Lemma 6.4). Потом в closure используй этот конус как “generator cone inside WK”.

---

## Ответ на “какой вариант лучший”
**Лучший вариант — Option 2 (restrict atoms by \(|\tau|+B\le K\)).**  
Причины:
- Это уже встроено как отдельная лемма “Fixed‑\(t_0\) cone density”【6:10†RH_Q3.pdf†L23-L63】.
- Сразу решает твой `hg_supp` без truncation/гауссовых хвостов.
- Совместимо с “cone inside WK” и LF‑transfer, где действительно нужны **supported** тесты【6:11†RH_Q3.pdf†L40-L44】.

Если хочешь, я могу в следующем сообщении выдать *прямо Lean‑скелет кода* под твою текущую структуру `A1_density_WK_axiom` (с именами полей `hg_supp`, `h_approx` и т.д.) — но уже сейчас у тебя есть: (i) правильная математическая версия, (ii) ключевые леммы, (iii) куда именно врезать ограничение \(|\tau|+B\le K\).

## ASSISTANT
According to a document from **2026-01-13**, A1′ “density on compacts” is formulated as **uniform approximation on the window** \([-K,K]\): one “works on \(C^+_{\mathrm{even}}([-K,K])\) with the uniform norm \(\|\cdot\|_\infty\)” rather than demanding global support \(\subseteq[-K,K]\).【179:9†RH_Q3.pdf†L64-L73】  
That single definitional mismatch is exactly why your Lean `hg_supp` is **provably unprovable** as stated: you’re asking the approximants to live in a support-restricted space, while the paper-level A1′ atoms/conoids are only controlled **on the compact window** (and can spill outside).

Below I’ll treat the contradiction as the “phenomenon signal”, quantify it, then give **two fixes**. I recommend **Fix A (restriction-to-window via `Set.indicator`)** because it unblocks `hg_supp` immediately *without* reworking the approximation proof; Fix B is the “pure support” route (matches Lemma 6.4 in the doc) but forces you to construct atoms with the extra constraint \(|\tau|+B\le K\).【179:2†RH_Q3.pdf†L23-L26】

---

## 0. Теорема и статус

### Теорема (A1_density support-fix)
Для фиксированного \(K>0\), если \(h:\mathbb R\to\mathbb R\) — конечная неотрицательная комбинация Fejér×heat атомов (возможно с “выбросом” за \([-K,K]\)), то
\[
g := \mathbf{1}_{[-K,K]}\cdot h
\]
имеет **поддержку** \(\subseteq[-K,K]\), совпадает с \(h\) на \([-K,K]\), сохраняет **even/nonneg/continuousOn** на \([-K,K]\), и потому является корректным элементом твоего `W_K` (в Lean-версии с `Function.support ⊆ Icc (-K) K`).

**Статус:** стандартная математика (ZFC), чисто топологически-алгебраический трюк “restriction to a compact window”.

---

## 1. Формальное утверждение

### Объекты
- \(K>0\), \(s := \mathrm{Icc}(-K,K)\subset \mathbb R\).
- \(h:\mathbb R\to\mathbb R\) — твоя “сумма атомов”.
- \(g := \mathrm{indicator}\ s\ h\).

### Требуется показать (в Lean-терминах)
1) `Function.support g ⊆ s` (это и есть `hg_supp`).  
2) `ContinuousOn g s` (у тебя уже было `hg_cont` для суммы атомов; здесь тоже ок).  
3) `IsEven g`, `IsNonneg g` (аналогично).  
4) Аппроксимационная оценка `h_approx` **на s** не портится: на `s` имеем `g = h`, значит все суп-нормы на `s` идентичны.

---

## 2. Определения и нотация

- Fejér×heat атомы в документе (в обозначениях \(\Phi_{B,t,\tau}\)) задаются через Fejér “hat” \(\Lambda_B\) и тепловой гауссиан \(\rho_t\), плюс even-symmetrization.【174:10†RH_Q3.pdf†L39-L47】  
- В A1′ пространство на компакте — это \(C^+_{\mathrm{even}}([-K,K])\) с \(\|\cdot\|_\infty\) на \([-K,K]\).【179:9†RH_Q3.pdf†L64-L73】

**Феномен/аномалия (измерение):**  
если ты берёшь центр \(\tau\in[-K,K]\) и ширину \(B\le K\), то support “hat”-части вокруг \(\tau\) лежит в \([\tau-B,\tau+B]\), а это даёт лишь
\[
\mathrm{supp}(\text{атом}) \subseteq [-K-B, K+B] \subseteq [-2K,2K],
\]
и никак не \([-K,K]\), если \(|\tau|\) близко к \(K\). Это не баг доказательства — это баг **определений**.

---

## 3. Зависимости

Нужны только стандартные леммы про `Set.indicator` и `Function.support`:

- `Set.indicator_of_mem`, `Set.indicator_of_not_mem`
- линейность индикатора (по точкам): `indicator (f+g)=indicator f + indicator g`, `indicator (c•f)=c•indicator f`
- симметрия множества `Icc (-K) K`: \(x\in s \iff -x\in s\)

Для `h_approx` нужна стандартная “цепочка треугольников” как в (6.7): суммарная ошибка ≤ сумма трёх ошибок.【179:2†RH_Q3.pdf†L1-L4】

---

## 4. Roadmap

**Fix A (рекомендую):**
1) Ввести `AtomOn K ... := indicator (Icc (-K) K) (Atom ...)` *или* просто после сборки `h` взять `g := indicator ... h`.
2) `hg_supp` становится тривиальным: вне `Icc` функция равна 0 ⇒ точки вне окна не в `Function.support`.
3) `h_approx` не меняется на `Icc`, потому что `g = h` на `Icc`.
4) Если нужно, показать, что `g` всё ещё лежит в твоём “конусе” (через распределение индикатора по конечной сумме и скалярам).

**Fix B (параметрическое ограничение):**
- Заменить генераторы на \(|\tau|+B\le K\). Это прямо зафиксировано как отдельный вариант плотности (Lemma 6.4).【179:2†RH_Q3.pdf†L23-L26】

---

## 5. Леммы (Lean-ready)

Ниже — формулировки, которые реально удобно вставлять. Я пишу на стандартных `Set.indicator`/`Function.support`; ты подставишь свои `Q3.IsEven`, `Q3.IsNonneg` и т.п.

### 5.1. Fix A: “restriction to window” (индексатор)

```lean
open Set
open scoped BigOperators

-- If you want the generators themselves to live in W_K:
noncomputable def AtomOn (K B t τ : ℝ) (Atom : ℝ → ℝ) : ℝ → ℝ :=
  Set.indicator (Set.Icc (-K) K) Atom

lemma AtomOn_eq_of_mem {K x : ℝ} {f : ℝ → ℝ} (hx : x ∈ Set.Icc (-K) K) :
    (Set.indicator (Set.Icc (-K) K) f) x = f x := by
  simp [Set.indicator_of_mem, hx]

lemma AtomOn_eq_zero_of_not_mem {K x : ℝ} {f : ℝ → ℝ} (hx : x ∉ Set.Icc (-K) K) :
    (Set.indicator (Set.Icc (-K) K) f) x = 0 := by
  simp [Set.indicator_of_not_mem, hx]

-- This is the key one for hg_supp:
lemma support_indicator_Icc_subset (K : ℝ) (f : ℝ → ℝ) :
    Function.support (Set.indicator (Set.Icc (-K) K) f) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- hx : (indicator ...) x ≠ 0
  by_contra hxK
  have : (Set.indicator (Set.Icc (-K) K) f) x = 0 := by
    simp [Set.indicator_of_not_mem, hxK]
  exact hx this
```

**ContinuityOn is preserved on the window** (because restriction agrees with the original function on the window):

```lean
lemma continuousOn_indicator_Icc (K : ℝ) {f : ℝ → ℝ}
    (hf : ContinuousOn f (Set.Icc (-K) K)) :
    ContinuousOn (Set.indicator (Set.Icc (-K) K) f) (Set.Icc (-K) K) := by
  -- same function on the set
  refine hf.congr ?_
  intro x hx
  simp [Set.indicator_of_mem, hx]
```

**Evenness preserved** because `Icc (-K) K` is symmetric:

```lean
lemma mem_Icc_neg {K x : ℝ} :
    (-x ∈ Set.Icc (-K) K) ↔ (x ∈ Set.Icc (-K) K) := by
  constructor <;> intro hx <;> rcases hx with ⟨hx1, hx2⟩
  · -- -K ≤ -x and -x ≤ K
    -- turn into -K ≤ x and x ≤ K
    have : x ≤ K := by linarith
    have : -K ≤ x := by linarith
    exact ⟨this, by linarith⟩
  · have : -K ≤ -x := by linarith
    have : -x ≤ K := by linarith
    exact ⟨this, this_1⟩  -- (rename in your editor; linarith will solve cleanly)
-- In practice: `by simpa [Set.mem_Icc] using hx` is often enough with `linarith`.

lemma even_indicator_Icc {K : ℝ} {f : ℝ → ℝ} (hf : Function.Even f) :
    Function.Even (Set.indicator (Set.Icc (-K) K) f) := by
  intro x
  by_cases hx : x ∈ Set.Icc (-K) K
  · have hnx : -x ∈ Set.Icc (-K) K := (mem_Icc_neg (K := K) (x := x)).2 hx
    simp [Set.indicator_of_mem, hx, hnx, hf x]
  · have hnx : -x ∉ Set.Icc (-K) K := by
      -- contrapositive of symmetry
      intro hnx'
      exact hx ((mem_Icc_neg (K := K) (x := x)).1 hnx')
    simp [Set.indicator_of_not_mem, hx, hnx]
```

**Nonneg preserved** is pointwise trivial:

```lean
lemma nonneg_indicator {s : Set ℝ} {f : ℝ → ℝ}
    (hf : ∀ x, 0 ≤ f x) :
    ∀ x, 0 ≤ (Set.indicator s f) x := by
  intro x; by_cases hx : x ∈ s <;> simp [Set.indicator_of_mem, Set.indicator_of_not_mem, hx, hf]
```

**Indicator distributes over finite sums** (use this if you need to show `g` is still a conic combo of the *truncated* atoms):

```lean
lemma indicator_add (s : Set ℝ) (f g : ℝ → ℝ) :
    Set.indicator s (fun x => f x + g x)
      = fun x => Set.indicator s f x + Set.indicator s g x := by
  funext x; by_cases hx : x ∈ s <;> simp [Set.indicator_of_mem, Set.indicator_of_not_mem, hx]

lemma indicator_smul (s : Set ℝ) (c : ℝ) (f : ℝ → ℝ) :
    Set.indicator s (fun x => c * f x)
      = fun x => c * Set.indicator s f x := by
  funext x; by_cases hx : x ∈ s <;> simp [Set.indicator_of_mem, Set.indicator_of_not_mem, hx]

lemma indicator_finset_sum (s : Set ℝ) {ι : Type*} (t : Finset ι) (f : ι → ℝ → ℝ) :
    Set.indicator s (fun x => ∑ i in t, f i x)
      = fun x => ∑ i in t, Set.indicator s (f i) x := by
  classical
  refine Finset.induction_on t ?base ?step
  · simp
  · intro a t ha ih
    simp [Finset.sum_insert, ha, ih, indicator_add]
```

### 5.2. Fix A: `h_approx` becomes easier

If your approximation is only required on `s = Icc (-K) K`, then cutting off doesn’t change the values on `s`:

```lean
lemma indicator_eq_on_Icc (K : ℝ) (f : ℝ → ℝ) :
    Set.EqOn (Set.indicator (Set.Icc (-K) K) f) f (Set.Icc (-K) K) := by
  intro x hx
  simp [Set.indicator_of_mem, hx]
```

So any lemma of the form  
`∀ x ∈ s, |h x - Φ x| ≤ ε` immediately transfers to `g := indicator s h` without recomputing constants.

And the triangle chain you mentioned is literally the inequality (6.7) in the document: final error ≤ sum of three errors.【179:2†RH_Q3.pdf†L1-L4】  
Lean-ready local version:

```lean
lemma abs_sub_le_three (a b c d : ℝ) :
    |a - d| ≤ |a - b| + |b - c| + |c - d| := by
  -- two-step triangle inequality
  have h1 : |a - d| ≤ |a - c| + |c - d| := by
    simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using
      (abs_sub_le a c d)
  have h2 : |a - c| ≤ |a - b| + |b - c| := by
    simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using
      (abs_sub_le a b c)
  linarith
```

(Если у тебя уже есть `abs_sub_le` в нужной форме, можно сделать короче.)

---

## 6. Fix B (альтернатива): ограничить параметры \(|\tau|+B\le K\)

Это **ровно** то, что в документе выделено отдельной леммой про плотность при фиксированном \(t_0\): конус, порождённый атомами с ограничением \(|\tau|+B\le K\), плотен в \(C^+_{\mathrm{even}}([-K,K])\).【179:2†RH_Q3.pdf†L23-L26】

Тебе нужны две ключевые Lean-леммы:

### 6.1. Поддержка атома внутри \([-K,K]\)

```lean
-- schematic: adapt to your actual Atom definition (with symmetrization)
lemma support_atom_subset_Icc
    (Atom : ℝ → ℝ) {K B τ : ℝ}
    (h : |τ| + B ≤ K) :
    Function.support Atom ⊆ Set.Icc (-K) K := by
  -- proof idea:
  -- x ∈ support → Atom x ≠ 0 → Fejer(...) ≠ 0 → |x-τ| < B
  -- then |x| ≤ |x-τ| + |τ| < B + |τ| ≤ K
  sorry
```

### 6.2. Плотность при этом ограничении

Если ты реально делаешь “hat interpolation” доказательство (как в Lemma 6.4), то в Lean нужен утверждаемый theorem:

```lean
theorem dense_restricted_atoms_fixed_t0
    (K t0 : ℝ) (hK : 0 < K) (ht : 0 < t0) :
    -- closure of conic hull of atoms with |τ|+B ≤ K
    Dense (RestrictedAtomCone K t0) (W_K K) := by
  -- implement the Lemma 6.4 strategy:
  -- (1) positive piecewise-linear hat approximation by Λ_δ(·-τ_j)
  -- (2) replace hats by Fejér×heat atoms using Lipschitz bound of ρ_t0 on [-2K,2K]
  sorry
```

Смысл: Fix B — это “математически чисто” (атомы уже поддержаны внутри окна), но цена — ты обязан перестроить конструкцию `h` так, чтобы **каждый** использованный центр удовлетворял \(|\tau|+B\le K\). В документе это делается через сетку и hats.【179:2†RH_Q3.pdf†L30-L36】

---

## 7. Audit — edge check

- **Главная причина блокировки `hg_supp`:** твоя текущая гипотеза “\(\tau\in[-K,K]\), \(B\le K\)” даёт лишь support \(\subseteq[-2K,2K]\), а не \([-K,K]\). Это не баг тактики; это несоответствие определениям.
- **Heat kernel “infinite support”** в твоём случае *не главный враг*, потому что Fejér фактор обрубает поддержку (атом всё равно компактный). Проблема — именно **сдвиг** центра \(\tau\).
- Если ты в A2 реально используешь “support ⇒ prime sum finite”, то оставлять `support ⊆ Icc` имеет смысл: это ровно Lemma 7.1 локальная конечность.【179:1†RH_Q3.pdf†L30-L66】

---

## Рекомендация, что делать прямо сейчас (минимальный diff)

**Сделай Fix A:**  
1) Определи `AtomOn K ... := indicator (Icc (-K) K) (Atom ...)`.  
2) Замени в `AtomCone_K` генераторы `Atom` на `AtomOn`.  
3) `hg_supp` закрывается `support_indicator_Icc_subset`.  
4) `h_approx` закрывается “на Icc индикатор не меняет” + твоя цепочка треугольников (это (6.7)).【179:2†RH_Q3.pdf†L1-L4】

Если хочешь, я могу в следующем сообщении набросать точечный патч “как вставить это в твою структуру `AtomCone_K` / `A1_density_WK_axiom`” (без вопросов, просто с предполагаемыми именами твоих дефов и `simp`-цепочками).

## ASSISTANT
Нужно резать **не heat**, а **параметры (B, τ)**. У тебя “утечка support” возникает ровно потому, что сейчас допускается `τ ∈ [-K,K]` и `B ≤ K`, что даёт только `supp ⊆ [-K-B, K+B]`. Лечится усилением ограничения до

\[
|τ| + B \le K.
\]

Это **Option 2**. И это не “проигрыш плотности”: в тексте проекта **ровно это условие** используется как правильная “внутриоконная” версия генераторов (см. Lemma 6.4: атомы с \(|τ|+B\le K\) и плотность на \(W_K\)).【195:0†RH_Q3.pdf†L62-L66】

Ниже — нормальный план: (i) что выбрать, (ii) полный скетч доказательства с явными оценками, (iii) Lean-стейтменты, (iv) что с truncation-ошибкой (спойлер: она либо нулевая, либо совсем лишняя).

---

## 0. Теорема: Fix `hg_supp` через ограничение \(|τ|+B\le K\) и сохранение плотности

**Точная формулировка (в терминах твоего Lean):**

Для \(K>0\), \(t>0\), \(B>0\), \(τ\in\mathbb R\), если
\[
|τ|+B\le K,
\]
то для атома
\[
\mathrm{Atom}(B,t,τ)(x)=\tfrac12\big(\Lambda_B(x-τ)\rho_t(x-τ)+\Lambda_B(x+τ)\rho_t(x+τ)\big)
\]
имеем
\[
\mathrm{Function.support}(\mathrm{Atom}(B,t,τ))\subseteq [-K,K].
\]

И если `AtomCone_K` строится из **конечных неотрицательных сумм** таких атомов, то каждый `g ∈ AtomCone_K` удовлетворяет `support g ⊆ [-K,K]` (закрывает `hg_supp`).

**Статус:** стандартная математика (ZFC), ровно соответствует “внутриоконной” версии плотности в RH_Q3: генераторы \(\Phi_{B,t,τ}\) определены именно как Fejér×heat окна【200:0†RH_Q3.pdf†L39-L60】 и далее вводится ограничение \(|τ|+B\le K\) для “cone inside \(W_K\)”【195:0†RH_Q3.pdf†L62-L66】.

---

## 1. Анализ опций: что лучше

### Option 2 — **лучший выбор**
**Суть:** изменить/уточнить параметризацию генераторов в `AtomCone_K`: вместо “τ∈[-K,K], B≤K” требовать
\[
|τ|+B\le K.
\]

**Почему это правильно:**
- Это **точно то**, что нужно, чтобы атом гарантированно был нулём вне \([-K,K]\): Fejér-фактор обрубает support.
- Это минимальный патч: не трогаешь `W_K`, не трогаешь глобальную архитектуру closure.
- И это **не убивает плотность**: в тексте есть отдельная формулировка, где cone с \(|τ|+B\le K\) плотен в \(W_K\) (фиксированное \(t_0\)).【195:0†RH_Q3.pdf†L62-L66】

### Option 1 — менять `W_K` или “K→2K”
Технически можно, но это грязно:
- переносит проблему дальше по цепочке (A2 Lipschitz, prime-cap, etc. привязаны к “окнам”),
- легко сделать несогласованность “что такое WK” и “на каком K работает следующий модуль”.

### Option 3 — truncation heat kernel
Это почти наверняка **лишнее** в твоём сетапе, потому что у тебя атом — **точечное произведение** Fejér×heat, и Fejér уже имеет компактный support; infinite support heat не расширяет support произведения.
- Truncation добавит новые функции, новые леммы про ошибки и нормировку.
- И не решает главный источник утечки: **B и τ**, а не хвост heat.

---

## 2. Контекст и определения (что именно ломается)

### 2.1. Определения из текста проекта
В RH_Q3 атомы (частотные окна) определены как symmetrized Fejér×heat【200:0†RH_Q3.pdf†L39-L60】:
\[
\Phi_{B,t,τ}(\xi)=\tfrac12\big(\Lambda_B(\xi-τ)\rho_t(\xi-τ)+\Lambda_B(\xi+τ)\rho_t(\xi+τ)\big),
\]
где \(\Lambda_B(x)=(1-|x|/B)_+\), а \(\rho_t\) — heat kernel【200:0†RH_Q3.pdf†L54-L56】.

### 2.2. Твой Lean-объект `W_K`
Ты зафиксировал:
- even, nonneg, continuous,
- **и** `Function.support Φ ⊆ Set.Icc (-K) K`.

Значит **любая аппроксимация** в `AtomCone_K` обязана сама лежать в том же `W_K`, иначе ты не можешь закрыть “cone inside WK”.

---

## 3. Главный феномен: “heat infinite support” на самом деле не виноват

Это важно, потому что сейчас тебя тянет в Option 3.

В Lean `Function.support f` — это множество точек, где `f x ≠ 0` (не топологическая support-замыкалка!). Поэтому:

- если \(\rho_t(x)\neq 0\) для всех \(x\), то
  \[
  \mathrm{support}(\Lambda_B(\cdot-τ)\rho_t(\cdot-τ))=\mathrm{support}(\Lambda_B(\cdot-τ)),
  \]
  потому что произведение нулевое **только** там, где нулевой Fejér.

Значит **support атома контролируется Fejér’ом**, и проблема **только** в том, что сейчас разрешено \(B\) слишком большой относительно \(K\) и \(τ\).

---

## 4. План доказательства (Roadmap) для Option 2

1. **Уточнить** определение `AtomCone_K`: генераторы должны удовлетворять `abs τ + B ≤ K`.
2. Доказать лемму `support_atom_subset_Icc`:
   \[
   |τ|+B\le K \implies \mathrm{support}(\mathrm{Atom}(B,t,τ))\subseteq [-K,K].
   \]
3. Из неё вывести `hg_supp` для конечной суммы атомов.
4. Для `h_approx`: построить аппроксимацию, где параметры сразу удовлетворяют `abs τ + B ≤ K`, и закрыть оценку через треугольник.

---

## 5. Леммы и скетчи (математика, без Lean-шума)

### Лемма 1: support одного атома при \(|τ|+B\le K\)
**Формулировка:**
если \(B>0\), \(t>0\), \(K>0\) и \(|τ|+B\le K\), то \(\Phi_{B,t,τ}(x)=0\) для всех \(|x|>K\).

**Доказательство:**
Пусть \(|x|>K\). Тогда по обратному треугольнику
\[
|x-τ|\ge |x|-|τ|>K-|τ|\ge B,
\]
и аналогично \(|x+τ|\ge |x|-|τ|>K-|τ|\ge B\).
Но \(\Lambda_B(u)=0\) при \(|u|\ge B\). Значит обе компоненты symm равны 0, и \(\Phi_{B,t,τ}(x)=0\). ∎

Отсюда сразу `support ⊆ Icc(-K,K)`.

---

### Лемма 2: support конечной суммы
Если каждый слагаемый нулевой вне \([-K,K]\), то и конечная сумма нулевая вне \([-K,K]\). (Routine step.)

---

### Лемма 3: оценка `h_approx` (треугольник)
Если построены промежуточные функции \(f,h,g\) и есть оценки
\[
\|f-h\|_\infty \le \varepsilon_1,\qquad \|h-g\|_\infty \le \varepsilon_2,
\]
то
\[
\|f-g\|_\infty \le \varepsilon_1+\varepsilon_2.
\]
(Routine step: triangle inequality.)

---

## 6. Полный proof sketch плотности под Option 2 (фиксированный `t_sym`)

Тебе нужен **фиксированный** \(t=t_{\mathrm{sym}}\). Это как раз тот режим, где нельзя опираться на “heat approximate identity” (если \(t\) не гоняется к 0), зато работает “hat interpolation + small B”.

### Шаг A: hat-интерполяция (Fejér-атомы без heat)
Возьми \(f\in W_K\). Тогда \(f\) непрерывна на \([-K,K]\) и \(f(\pm K)=0\) (иначе непрерывность + нуль вне окна невозможны).

Возьми мелкую сетку с шагом \(\delta>0\) и центры
\[
τ_j=-K+\delta + j\delta,\quad j=0,\dots,N-1,\quad N\delta=2K-2\delta.
\]
Тогда \(|τ_j|+\delta\le K\) (крайние центры \(\pm(K-\delta)\)).

Пусть “шляпы”
\[
H_j(x)=\Lambda_\delta(x-τ_j)\quad (\ge0,\ \mathrm{supp}\subseteq[τ_j-\delta,τ_j+\delta]\subseteq[-K,K]).
\]
Определи
\[
h(x)=\sum_j f(τ_j)\,H_j(x).
\]
Тогда \(h\ge0\), \(h\) чётна (если сетка симметрична и берёшь симметричные коэффициенты), и
\[
\|f-h\|_{\infty,[-K,K]}\le \omega_f(\delta),
\]
где \(\omega_f\) — модуль равномерной непрерывности на \([-K,K]\). Берёшь \(\delta\) так, чтобы \(\omega_f(\delta)\le \varepsilon/2\).

### Шаг B: вставляем heat-фактор, не нарушая support
Теперь заменяем каждый \(H_j\) на Fejér×heat атом с тем же \((B=\delta, τ=τ_j)\):
\[
A_j(x)=\Lambda_\delta(x-τ_j)\rho_{t_{\mathrm{sym}}}(x-τ_j),
\]
и берём
\[
g(x)=\sum_j f(τ_j)\,A_j(x)\cdot c,
\]
где \(c\) — константа масштаба.

- Если в Lean у тебя `HeatKernel t x = exp(-4π^2 t x^2)`, то \(\rho_t(0)=1\), можно взять \(c=1\).
- Если у тебя нормированная \(\rho_t\) с \(\rho_t(0)\neq1\), бери \(c=1/\rho_t(0)\).

**Ключ:** на support каждого \(H_j\) выполняется \(|x-τ_j|\le\delta\), значит \(\rho_t(x-τ_j)\) близка к \(\rho_t(0)\). Например, для \(\rho_t(u)=e^{-αu^2}\) (как в частотном виде) верно:
\[
0\le 1-e^{-αu^2}\le αu^2,
\]
то есть
\[
|\rho_t(u)-\rho_t(0)| \le α\delta^2\cdot \rho_t(0).
\]
Следовательно,
\[
\|h-g\|_{\infty,[-K,K]}
\le (\sup_{[-K,K]} f)\cdot α\delta^2.
\]
Выбираем \(\delta\) ещё меньше, чтобы это было ≤ ε/2.

### Шаг C: финал
По треугольнику:
\[
\|f-g\|_\infty\le \|f-h\|_\infty+\|h-g\|_\infty\le \varepsilon.
\]
И по Лемме 1 каждая \(A_j\) (а значит и сумма) поддержана внутри \([-K,K]\), потому что \(|τ_j|+\delta\le K\).

**Итог:** \(g\in \mathrm{AtomCone}_K\) и аппроксимирует \(f\) в нужной норме.

---

## 7. Lean-ready: ключевые theorem/lemma statements

Я пишу максимально “под Lean”, но тебе нужно будет подставить реальные имена (`FejerKernel`, `HeatKernel`, `Atom`, `AtomCone_K`, `W_K`) и тип нормы.

### 7.1. Support одного слагаемого (ядро для `hg_supp`)
```lean
/-- If `abs τ + B ≤ K`, the Fejér×heat atom is zero outside `[-K,K]`. -/
lemma atom_eq_zero_of_abs_gt_K
  {B t τ K x : ℝ}
  (hB : 0 < B)
  (hK : 0 ≤ K)
  (hτ : |τ| + B ≤ K)
  (hx : K < |x|) :
  Atom B t τ x = 0 := by
  -- idea: show `B ≤ |x-τ|` and `B ≤ |x+τ|` from reverse triangle,
  -- then use `FejerKernel_eq_zero_of_abs_ge` for both terms.
  sorry
```

```lean
/-- Support containment for one atom under the tight parameter condition. -/
lemma support_atom_subset_Icc
  {B t τ K : ℝ}
  (hB : 0 < B)
  (hK : 0 ≤ K)
  (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- hx : Atom B t τ x ≠ 0
  -- contrapositive via `atom_eq_zero_of_abs_gt_K`
  have hxK : |x| ≤ K := by
    by_contra h
    have : K < |x| := lt_of_not_ge h
    have := atom_eq_zero_of_abs_gt_K (B:=B) (t:=t) (τ:=τ) (K:=K) (x:=x)
      hB hK hτ this
    exact hx this
  -- turn `|x| ≤ K` into membership in Icc
  exact (abs_le.mp hxK)
```

(Если у тебя `W_K` использует `Set.Icc (-K) K` — это ровно то, что нужно.)

### 7.2. Support конечной суммы (закрывает `hg_supp`)
Если `hg` — конечная сумма атомов (через `Finset.sum`), то:

```lean
lemma support_finset_sum_subset
  {ι : Type*} {s : Finset ι} {f : ι → ℝ → ℝ} {K : Set ℝ} :
  (∀ i ∈ s, Function.support (f i) ⊆ K) →
  Function.support (fun x => ∑ i in s, f i x) ⊆ K := by
  intro hsupp
  intro x hx
  -- prove x ∈ K by contradiction: if x ∉ K then each f i x = 0, sum = 0, contradiction
  sorry
```

И дальше `hg_supp` делается одной строкой: применяешь `support_atom_subset_Icc` к каждому атомному слагаемому и затем `support_finset_sum_subset`.

### 7.3. Triangle inequality chain для `h_approx`
Если норма у тебя оформлена как `sup` по `Set.Icc (-K) K`, то типичная заготовка:

```lean
lemma sup_norm_sub_le_add
  (K : Set ℝ) (f g h : ℝ → ℝ) :
  (supNormOn K (f - h)) ≤ (supNormOn K (f - g)) + (supNormOn K (g - h)) := by
  -- unfold supNormOn, use `abs_sub_le` pointwise and `iSup_le` / `csSup_le`
  sorry
```

И затем:

```lean
have h1 : supNormOn (Set.Icc (-K) K) (f - h) ≤ ε/2 := ...
have h2 : supNormOn (Set.Icc (-K) K) (h - g) ≤ ε/2 := ...
have : supNormOn (Set.Icc (-K) K) (f - g) ≤ ε := by
  calc
    supNormOn _ (f - g)
        ≤ supNormOn _ (f - h) + supNormOn _ (h - g) := sup_norm_sub_le_add _ _ _ _
    _ ≤ ε/2 + ε/2 := add_le_add h1 h2
    _ = ε := by ring
```

---

## 8. Если всё же делать truncation: какие error bounds?

Тут два варианта:

### 8.1. В твоём текущем Atom (точечное произведение) truncation даёт **нулевую** ошибку
Если ты определяешь
\[
\tilde\rho_t(u)=\rho_t(u)\cdot 1_{|u|\le R},
\]
то при \(R\ge B\) и везде где \(\Lambda_B(u)\neq0\) выполнено \(|u|<B\le R\), значит \(\tilde\rho_t(u)=\rho_t(u)\).
Следовательно
\[
\Lambda_B(u)\rho_t(u)=\Lambda_B(u)\tilde\rho_t(u),
\]
и **ошибка = 0**. Это ещё один аргумент, почему Option 3 бессмысленен.

### 8.2. Если бы heat стоял без Fejér-обрезки (или был свёрткой), тогда хвост
Для нормализованного heat
\[
\rho_t(u) = (4\pi t)^{-1/2} e^{-u^2/(4t)}
\]
имеешь pointwise:
\[
\sup_{|u|\ge R}\rho_t(u) \le (4\pi t)^{-1/2}e^{-R^2/(4t)}.
\]
А для массы хвоста:
\[
\int_{|u|>R}\rho_t(u)\,du = \mathrm{erfc}\!\left(\frac{R}{2\sqrt t}\right)
\le \frac{2\sqrt t}{R\sqrt\pi}e^{-R^2/(4t)}.
\]
Но повторюсь: при твоём Atom=Fejér·heat эти оценки не нужны.

---

## Резюме (что делать прямо сейчас)

1. **Выбери Option 2.** Перепиши/уточни `AtomCone_K` так, чтобы генераторы удовлетворяли `abs τ + B ≤ K`. Это закрывает `hg_supp` “по смыслу” и соответствует текстовой версии cone inside \(W_K\).【195:0†RH_Q3.pdf†L62-L66】
2. **Перестрой аппроксимацию в A1_density** на “hat interpolation + small B” при фиксированном `t_sym`, а не на “heat smoothing + Riemann sum + large B” (large B как раз рушит support-инвариант).
3. `h_approx` закрывается стандартной тройкой лемм: (i) uniform continuity даёт `‖f-h‖∞`, (ii) heat близок к константе на маленьком носителе даёт `‖h-g‖∞`, (iii) треугольник.

Если хочешь, я могу адаптировать эти statements под **точные** имена твоих дефов (как они реально называются в A1_density.lean) — но даже без этого, патч логики уже полностью определён.

## ASSISTANT
## 0. Теорема: Fix A1_density support mismatch и сохранить плотность

**Точная формулировка (в одном предложении):**  
Для каждого \(K>0\) (и фиксированного \(t_0>0\)) если в определении Fejér×heat‑атомов требовать **параметрическое условие** \(|\tau|+B\le K\), то (i) каждый атом и любая конечная неотрицательная комбинация имеют \(\operatorname{supp}\subseteq[-K,K]\), и (ii) конус таких комбинаций остаётся **плотным** в \(W_K\) (в норме \(\|\cdot\|_\infty\) на \([-K,K]\)).

**Статус:** стандартная математика (анализ на компактах), никаких гипотез сверх гладкости/непрерывности, которая и так в \(W_K\).

---

## 1. Формальное утверждение: что именно сломано сейчас

### 1.1. Факт‑контрпример (почему текущая `hg_supp` не докажется)
Если в `AtomCone_K` разрешено:
- \(\tau\in[-K,K]\),
- \(0<B\le K\),

то поддержка (support) **вообще говоря** выходит за \([-K,K]\). Например:
- \(\tau=K\),
- \(B=K/2\),

тогда поддержка сдвинутого hat‑ядра \(\Lambda_B(x-\tau)\) лежит в \([K-B,\,K+B]=[K/2,\,3K/2]\), то есть правее \(K\).  
А так как коэффициенты в конусе **неотрицательные**, “вырезать” хвосты снаружи \([-K,K]\) **невозможно** (нет компенсации знаками). Значит, `hg_supp` сейчас заблокирован не “техникой Lean”, а **логически неверной спецификацией** множества генераторов.

### 1.2. Важное уточнение (про heat kernel)
Тезис “heat kernel имеет бесконечную поддержку” здесь **не проблема**:  
ты берёшь **произведение** `FejerKernel * HeatKernel`. Раз `FejerKernel` ноль вне \([-B,B]\), то и произведение ноль вне \([-B,B]\) (после сдвига — вне \([\tau-B,\tau+B]\)).  
Значит, поддержка атома контролируется **только** hat‑фактором, а не гауссианом.

---

## 2. Определения и нотация (ровно те, что играют роль)

### 2.1. Hat / “Fejér kernel” в твоём смысле
\[
\Lambda_B(x)=(1-|x|/B)_+,\qquad \operatorname{supp}\Lambda_B=[-B,B].
\]

### 2.2. Heat kernel
\[
\rho_t(x)=C(t)\,e^{-x^2/(4t)},\qquad \rho_t(x)>0\ \forall x.
\]

### 2.3. Атом (как в твоём Lean, симметризованный для чётности)
(масштаб \(1/2\) не важен для support)
\[
\mathrm{Atom}(B,t,\tau)(x)=
\Lambda_B(x-\tau)\rho_t(x-\tau)\;+\;\Lambda_B(x+\tau)\rho_t(x+\tau).
\]

### 2.4. Ключевой параметрический инвариант (то, чего сейчас не хватает)
\[
|\tau|+B\le K.
\]
Эквивалентно: \(\tau\in[-K+B,\,K-B]\) при \(B\ge0\).

---

## 3. Dependencies (что нужно как “опорные факты”)

1. \(\operatorname{supp}(\Lambda_B(\cdot-\tau))\subseteq[\tau-B,\tau+B]\).
2. \(\operatorname{supp}(f\cdot g)\subseteq \operatorname{supp}(f)\) (достаточно, что вне поддержки \(f\) произведение равно 0).
3. \(\operatorname{supp}(f+g)\subseteq \operatorname{supp}(f)\cup\operatorname{supp}(g)\).
4. Замкнутость \(\mathrm{Icc}\) и простая арифметика интервалов:
   если \(|\tau|+B\le K\), то \([-(|\tau|+B),\,|\tau|+B]\subseteq[-K,K]\).
5. Для плотности: непрерывность + компактная поддержка \(\Rightarrow\) “значения малы в пограничной полосе” (если у тебя в \(W_K\) есть глобальная `Continuous`, см. ниже).

---

## 4. Roadmap (как закрыть оба sorries)

### Шаг A — исправить спецификацию генераторов (Option 2)
В `AtomCone_K` (или в параметрическом предикате для допустимых атомов) заменить слабое:
- `τ ∈ Icc (-K) K` и `B ≤ K`

на сильное:
- `0 < B` и `|τ| + B ≤ K`.

Это **минимально необходимое** условие, если ты хочешь автоматически иметь `support ⊆ [-K,K]` при неотрицательных коэффициентах.

### Шаг B — закрыть `hg_supp`
После Шага A `hg_supp` становится прямым: support каждого слагаемого ⊆ Icc(-K)K, значит support суммы ⊆ Icc(-K)K.

### Шаг C — закрыть `h_approx` (triangle inequality chain)
Там чистая “трёхзвенная” треугольная неравенство по точкам, затем переход к суп‑норме/квантору по \(x\in[-K,K]\).

### Шаг D — доказать плотность при новом ограничении \(|\tau|+B\le K\)
Это основной математический кусок Option 2. Рабочий вариант (самый Lean‑friendly) — не через “\(B\) большой, Λ≈1”, а через **hat‑интерполяцию** + “heat почти константа на маленьком окне”.

---

## 5. Леммы (Lean‑ready statements) для Option 2

Ниже я даю формулировки так, чтобы ты мог вставить почти 1‑в‑1. Имена подстрой под свой namespace.

### 5.1. Предикат допустимости параметров
```lean
def AtomParams (K B τ : ℝ) : Prop :=
  0 < B ∧ |τ| + B ≤ K
```

### 5.2. Support одного сдвинутого hat‑фактора
(если у тебя уже есть “FejerKernel = 0 при |x| ≥ B”, то это будет `simp`-proof)
```lean
lemma support_fejer_shift_subset_Icc {B τ : ℝ} (hB : 0 < B) :
    Function.support (fun x => FejerKernel B (x - τ))
      ⊆ Set.Icc (τ - B) (τ + B) := by
  -- idea: {x | ≠0} ⊆ Ioo(τ-B, τ+B), so support ⊆ Icc(τ-B, τ+B)
  -- use closure_subset_iff + FejerKernel properties
  sorry
```

### 5.3. Support hat×heat (основа: support задаётся hat‑фактором)
```lean
lemma support_fejer_mul_heat_shift_subset_Icc {B t τ : ℝ} (hB : 0 < B) :
    Function.support (fun x => FejerKernel B (x - τ) * HeatKernel t (x - τ))
      ⊆ Set.Icc (τ - B) (τ + B) := by
  -- outside Icc, FejerKernel = 0, hence product = 0
  sorry
```

### 5.4. Support симметризованного Atom
```lean
lemma support_Atom_subset_abs {B t τ : ℝ} (hB : 0 < B) :
    Function.support (Atom B t τ)
      ⊆ Set.Icc (-(|τ| + B)) (|τ| + B) := by
  -- Atom = term(x-τ) + term(x+τ)
  -- use support_add_subset + the previous shift lemma for ±τ
  -- then interval arithmetic: Icc(τ-B, τ+B) ∪ Icc(-τ-B, -τ+B) ⊆ Icc(-( |τ|+B), |τ|+B)
  sorry
```

### 5.5. Ключ: Atom ∈ W_K по support
```lean
lemma Atom_support_subset_WK {K B t τ : ℝ} (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  have h1 := support_Atom_subset_abs (B := B) (t := t) (τ := τ) hB
  -- show Set.Icc (-(|τ| + B)) (|τ| + B) ⊆ Set.Icc (-K) K using hτ
  -- then exact Set.Subset.trans h1 h2
  sorry
```

### 5.6. Support конечной суммы атомов (твой `hg_supp`)
Если у тебя `g = ∑ i, w i * Atom ...`, то:
```lean
lemma support_sum_atoms_subset_WK
    {n : ℕ} {K t : ℝ}
    {w : Fin n → ℝ} {B τ : Fin n → ℝ}
    (hB : ∀ i, 0 < B i)
    (hτ : ∀ i, |τ i| + B i ≤ K) :
    Function.support (fun x => ∑ i, w i * Atom (B i) t (τ i) x)
      ⊆ Set.Icc (-K) K := by
  classical
  -- idea: take x ∉ Icc(-K,K), then for each i, Atom(...) x = 0 by Atom_support_subset_WK,
  -- hence sum = 0, so x ∉ support.
  -- There are library lemmas like `support_sum_subset` / `support_mul` / `support_smul` depending on your setup.
  sorry
```

---

## 6. Density under the restriction (Option 2): что нужно доказать и как

### 6.1. Важная проверка спецификации W_K
Если твой `W_K` в Lean *только* `ContinuousOn` на `Icc (-K) K` (без `Continuous` на ℝ), то \(W_K\) допускает функции с “скачком” на границе, т.е. \(\Phi(K)>0\) при \(\Phi(x)=0\) для \(x>K\). Такие функции **невозможно** приблизить неотрицательными комбинациями hat‑атомов, которые всегда дают 0 на границе поддержки.  

Поэтому для истинности A1′ в форме “cone dense in W_K” тебе нужно, чтобы \(W_K\) соответствовал \(C_c([-K,K])\), то есть фактически:
- `Continuous Φ` (глобально) **или**
- `ContinuousOn` + явные условия `Φ (-K)=0` и `Φ K = 0`.

Это *не придирка*, это логическая необходимость для плотности.

### 6.2. Lean‑формулировка плотности (фиксированный t₀)
Суть цели:
```lean
theorem AtomCone_dense_WK_fixed_t
    {K t0 : ℝ} (hK : 0 < K) (ht0 : 0 < t0) :
    ∀ {Φ : ℝ → ℝ}, Φ ∈ W_K K → ∀ ε > 0,
      ∃ g : ℝ → ℝ, g ∈ AtomCone_K K t0 ∧
        (∀ x, x ∈ Set.Icc (-K) K → |g x - Φ x| ≤ ε) := by
  sorry
```

### 6.3. Конструкция аппроксиманта, которая реально совместима с `support ⊆ [-K,K]`
Берёшь маленький \(B\) (mesh) и центры \(\tau_j\) **внутри** \([-K+B, K-B]\).  
Дальше:

1) **Hat‑интерполяция**:  
строишь \(h(x)=\sum_j c_j \Lambda_B(x-\tau_j)\), где \(c_j \ge 0\), так чтобы  
\(\sup_{|x|\le K}|h(x)-\Phi(x)|\) было мало.  
(Это стандартный “positive piecewise linear approximation” на компакте; на практике берёшь равномерную сетку и коэффициенты как значения \(\Phi\) в узлах.)

2) **Вставка heat‑фактора при фиксированном \(t_0\)**:  
заменяешь \(\Lambda_B(x-\tau_j)\) на \(\Lambda_B(x-\tau_j)\rho_{t_0}(x-\tau_j)\).  
На носителе \(|x-\tau_j|\le B\), значит \(\rho_{t_0}(x-\tau_j)\) близка к \(\rho_{t_0}(0)\) при маленьком \(B\).  
Поэтому
\[
\Lambda_B(x-\tau_j)\rho_{t_0}(x-\tau_j)\approx \rho_{t_0}(0)\Lambda_B(x-\tau_j),
\]
и общая ошибка контролируется модулем непрерывности \(\rho_{t_0}\) на \([-B,B]\).

3) **Симметризация** (если у тебя атом уже симметризован) автоматически даёт evenness.

В этой схеме **никакого** “\(B\) большой, Λ≈1” не нужно — а значит support‑ограничение не конфликтует с аппроксимацией.

---

## 7. Triangle inequality chain для `h_approx` (твоя вторая sorry)

Тебе нужна стандартная “3‑звенная” оценка:

### 7.1. Pointwise lemma
```lean
lemma abs_sub_le_three (a b c d : ℝ) :
    |a - d| ≤ |a - b| + |b - c| + |c - d| := by
  -- (a - d) = (a - b) + (b - c) + (c - d)
  -- then `abs_add` twice
  nlinarith [abs_add (a - b) ((b - c) + (c - d)),
             abs_add (b - c) (c - d)]
```

(Возможно придётся чуть подправить под `simp [sub_eq_add_neg, add_assoc, add_left_comm, add_comm]`.)

### 7.2. Версия “на интервале”
Если у тебя есть три промежуточные оценки вида `< ε/3`, то финал:

```lean
lemma approx_chain_on_Icc
    {K ε : ℝ} {f g h u : ℝ → ℝ}
    (h1 : ∀ x, x ∈ Set.Icc (-K) K → |f x - g x| ≤ ε/3)
    (h2 : ∀ x, x ∈ Set.Icc (-K) K → |g x - h x| ≤ ε/3)
    (h3 : ∀ x, x ∈ Set.Icc (-K) K → |h x - u x| ≤ ε/3) :
    ∀ x, x ∈ Set.Icc (-K) K → |f x - u x| ≤ ε := by
  intro x hx
  have := abs_sub_le_three (f x) (g x) (h x) (u x)
  -- combine with h1 h2 h3 and arithmetic
  nlinarith [this, h1 x hx, h2 x hx, h3 x hx]
```

Это, по сути, и есть твой `h_approx`.

---

## 8. Вывод: что я бы сделал прямо сейчас

1) **Меняешь AtomCone_K**: добавляешь/заменяешь constraint на `|τ| + B ≤ K`.  
   Это разблокирует `hg_supp` “по определению”.

2) **Проверяешь W_K**: в нём должна быть глобальная `Continuous` (или явные `Φ(±K)=0`), иначе A1′ в твоей формулировке *математически ложна*.

3) **Аппроксимацию делаешь через hat‑интерполяцию + маленький B**, а не через “B большой, Λ≈1”.  
   Это ровно тот режим, который совместим с `support ⊆ [-K,K]`.

Если хочешь, я могу переписать “proof sketch” плотности в виде одного Lean‑friendly блока шагов (без тактик, но с точными кванторами и объектами) — чтобы ты буквально скопировал в `A1_density.lean` как `-- Roadmap` и разбил на леммы.

## ASSISTANT
# PROSHKA BRIEFING — A1_density: где именно “сломалась” дефиниция и как починить быстро

## 0. Сигнал и статус

**Сигнал (аномалия):** A1′ в спеках требует **плотность Fejér×heat‑конуса при фиксированном \(t_{\mathrm{sym}}\)**, но “A1_density” очень легко формально доказать в *другом* смысле (например, разрешая \(t\to0\) или меняя семейство атомов/пространство), и тогда он **не стыкуется** с A3/Rayleigh‑мостом при склейке.

Доп. контекст: у вас *есть* готовый Lean‑артефакт `A1_density_final` (41KB, компилируется) — но это не гарантирует, что он совпадает с тем, что требуется по PROSHKA‑инвариантам. fileciteturn0file8

---

## 1. Что именно должно совпасть (минимальный “контракт” A1′)

### Требование из PROSHKA‑инвариантов (суть)
Нужно: **для каждого компакта** \(K=[-R,R]\) и **фиксированного** \(t_{\mathrm{sym}}>0\)

> конус, порождённый Fejér×heat‑атомами при этом фиксированном \(t_{\mathrm{sym}}\), плотен в конусе всех чётных неотрицательных непрерывных функций на \(K\) в \(\|\cdot\|_\infty\).

Ключ: **локализация должна идти не через \(t\to0\)** (потому что \(t\) фиксирован), а через **Fejér‑параметр** (ширину/порядок), иначе доказательство “не то”.

---

## 2. Где обычно возникает дефиниционная рассинхронизация

Ниже — три типовые точки, где “A1_density” формально верен, но **не тот**, что нужен в цепочке A1′→A2→A3:

### (D1) “фиксированный \(t_{\mathrm{sym}}\)” vs “существует \(t\)” (критично)
- Если в Lean‑лемме стоит что-то вроде `∃ t, ...` или “в атомах разрешено произвольное \(t>0\)”, то это *другая* плотность.
- Для склейки с A3 нужен конус, где **\(t\) фиксирован ровно равным \(t_{\mathrm{sym}}\)**.

**Почему это реально важно:** при фиксированном \(t\) сглаживание даёт фиксированную “размазанность”, и если Fejér‑часть не умеет делать approximate identity, плотность не доказывается тем же трюком.

---

### (D2) Разные “heat”‑профили: \(e^{-4\pi^2 t\xi^2}\) vs \((4\pi t)^{-1/2}e^{-\xi^2/(4t)}\) (обычно не страшно, но надо нормализовать)
В базе у вас одновременно встречаются две параметризации Гаусса:

- “мультипликативная” (как в A3‑окне):
\[
G_{t}(\xi)=e^{-4\pi^2 t\,\xi^2}
\]
- “тепловое ядро” (нормированное):
\[
\rho_{t}(\xi)=(4\pi t)^{-1/2}e^{-\xi^2/(4t)}.
\]

**Факт‑сшивка:** это одно и то же семейство с заменой параметра  
\[
e^{-\xi^2/(4t)} = e^{-4\pi^2 t'\xi^2}\quad\text{где}\quad t'=\frac{1}{16\pi^2 t},
\]
а префактор \((4\pi t)^{-1/2}\) — просто положительное число.

**Следствие для конуса:** если ваши атомы отличаются от “канонических” из A3 умножением на положительный скаляр (зависит от параметров), это **не меняет** порождённый конус/его замыкание. Это чинится одной короткой “леммой‑перенормировкой” в Lean.

---

### (D3) Пространство/топология: функции на \(K\) vs функции на \(\mathbb R\) с \(\mathrm{supp}\subseteq K\)
Очень частая ловушка:

- В тексте A1′ часто формулируют плотность **на компакте** \(C([-R,R])\) (смотрим только на значения на \(K\)).
- В склейке с A2/Q иногда хочется, чтобы тест‑функции были **на всей \(\mathbb R\)** и имели контролируемую поддержку/хвост.

Если Lean‑определение \(\mathcal W_K\) — это “\(\mathrm{supp}\subseteq K\)”, а A1′ в Lean доказан как плотность среди **ограничений на \(K\)**, то нужно явное мостовое утверждение: *restriction/extension-by-zero* является изометрией для \(\|\cdot\|_\infty\) и не ломает конусность/чётность/неотрицательность.

---

## 3. Каноническая формулировка A1′, которая идеально стыкуется с A3

Вот **чистая** версия, под которую проще всего привести Lean‑определения.

### 0. Теорема: A1′ Fixed-\(t_{\mathrm{sym}}\) Cone Density
**Точная формулировка (одним предложением):**  
\[
\forall R>0,\ \forall t_{\mathrm{sym}}>0,\ \overline{\mathrm{cone}}(\mathcal A_{R,t_{\mathrm{sym}}})=C^+_{\mathrm{even}}([-R,R])
\quad\text{в норме }\|\cdot\|_\infty,
\]
где \(\mathcal A_{R,t_{\mathrm{sym}}}\) — семейство Fejér×heat‑атомов при фиксированном \(t_{\mathrm{sym}}\).

**Статус:** стандартная математика (ZFC).

### 2. Определения
- \(\Lambda_B(x):=(1-|x|/B)_+\) — “шляпка” (Fejér‑hat).
- \(G_{t_{\mathrm{sym}}}(x):=e^{-4\pi^2 t_{\mathrm{sym}}x^2}\).
- Несимметризованный атом:
\[
A_{B,t_{\mathrm{sym}},\tau}(\xi):=\Lambda_B(\xi-\tau)\,G_{t_{\mathrm{sym}}}(\xi-\tau).
\]
- Чётный атом:
\[
\Phi_{B,t_{\mathrm{sym}},\tau}(\xi):=\frac12\Big(A_{B,t_{\mathrm{sym}},\tau}(\xi)+A_{B,t_{\mathrm{sym}},\tau}(-\xi)\Big).
\]
- \(\mathrm{cone}(\cdot)\) — множество конечных сумм \(\sum_i c_i \Phi_i\) с \(c_i\ge0\). Замыкание — в \(\|\cdot\|_\infty\) на \([-R,R]\).

**Наблюдение:** фактор \(1/2\) и любые другие положительные нормировочные множители на атомах *не важны* (конус).

---

## 4. “Быстрый ремонт” в Lean: минимальный набор лемм‑переходников

Если твой `A1_density_final` сейчас “не того типа”, почти всегда хватает одного из следующих патчей:

### Patch P1 — зафиксировать \(t\) (если сейчас в формулировке \(t\) свободен/экзистенциален)
Сделай новой “главной” леммой именно `Fixed-t` вариант, и используй его в Main_closure вместо “variable-t”.

В текстовой базе это прямо соответствует идее “A1′ при фиксированном \(t_{\mathrm{sym}}\)”. (Это тот контракт, который требуется дальше.)

---

### Patch P2 — перенормировка heat‑ядра (если у тебя \(\rho_t\) вместо \(e^{-4\pi^2t\xi^2}\))
Добавь техническую лемму:

> **Лемма (reparam + scalar):**  
> \(\rho_t(x)=c(t)\,e^{-4\pi^2 t'(t)x^2}\) с \(c(t)>0\), \(t'(t)=1/(16\pi^2 t)\).

И затем лемму про конусы:

> **Лемма (positive scalar doesn’t change cone):**  
> если \(\forall p,\ f_p=c_p g_p\) и \(c_p>0\), то  
> \(\overline{\mathrm{cone}}(\{f_p\})=\overline{\mathrm{cone}}(\{g_p\})\).

Это **убивает** 90% “дефиниционных” конфликтов, когда аналитика и Lean по-разному параметризуют гауссиан.

---

### Patch P3 — привести “пространство” к одному и тому же объекту
Если A1 плотность доказана в `ContinuousMap (Icc (-R) R) ℝ`, а A2/Q живут в “функции на ℝ с поддержкой”, то нужен мост:

- restriction: \(f\mapsto f|_{[-R,R]}\)
- extension-by-zero: \(u\mapsto \tilde u\) на \(\mathbb R\)

и проверка, что:
- сохраняются even/≥0,
- норма \(\|\cdot\|_\infty\) на \([-R,R]\) совпадает с глобальной нормой для функций с поддержкой в \([-R,R]\),
- конусные комбинации ведут себя корректно.

---

## 5. Проверка “что именно сломано” — без гаданий, по одному grep

Поскольку `A1_density_final` отмечен как готовый и компилирующийся fileciteturn0file8, твоя задача сейчас — **не переписывать доказательство**, а понять, какая из (D1–D3) у тебя реально произошла.

Практически:

1) Открой `A1_density_final_aristotle.lean` и найди:
   - фигурирует ли `t_sym` как *фиксированный параметр* или есть `∃ t`.
2) Посмотри определение атома:
   - `exp (-4*pi^2*t*x^2)` или `exp (-x^2/(4*t))` или `heatKernel`?
3) В каком пространстве формулируется `Dense` / `closure`?
   - на `Icc` или на `ℝ → ℝ`?

**Что делать сразу после диагностики:**
- если (D1): перепривязать лемму к фиксированному `t_sym` (это реально “красная тревога”);
- если (D2): добавить P2‑переходник (обычно 10–30 строк Lean, и всё);
- если (D3): добавить P3‑изометрию restriction/extension.

---

## 6. Итог

**Самый вероятный корень “A1_density definitional issue”** — несовпадение с контрактом “фиксированный \(t_{\mathrm{sym}}\)” и/или несовпадение семейства heat‑атомов по параметризации (D1/D2). Это *нормальная* поломка: доказательство может быть верным, но **не про тот объект**, который нужен в Main_closure.

Если хочешь сделать это максимально “железно” для дальнейшей сборки:
- объяви канонической именно **Fixed-\(t_{\mathrm{sym}}\)** версию A1′ (как в §3),
- добавь 1–2 короткие леммы‑переходника (P2/P3),
- и только после этого “подцепляй” A1′ в цепь A1′+A2→Main_closure.

(Факт, что `A1_density_final` уже компилируется, означает: **проблема почти наверняка не в доказательстве, а в интерфейсе/дефинициях**.) fileciteturn0file8

## ASSISTANT
According to a document from **January 1, 2026**, the “support‑safe” version of A1′ is *already the intended one*: the fixed‑\(t_0\) density lemma explicitly **restricts atoms to parameters with \(|\tau|+B \le K\)** (so the hat never crosses \([-K,K]\)), and then proves density using **positive piecewise‑linear interpolation** + a **Lipschitz control** for the heat factor. That is exactly your Option 2. 【193:0†RH_Q3.pdf†L68-L87】【193:0†RH_Q3.pdf†L88-L94】

Below is the clean dossier you can implement to close **hg_supp** and **h_approx** without inventing truncations.

---

## 0. Теорема: A1′ density with support‑safe atoms (Option 2) — Status

**Точная формулировка (одной строкой):**  
\[
\forall K>0,\ \forall \Phi\in W_K,\ \forall \varepsilon>0,\ \exists g\in \mathrm{Cone}_K:\ 
\sup_{|x|\le K}|g(x)-\Phi(x)|<\varepsilon,
\]
где \(\mathrm{Cone}_K\) порождён атомами \(\mathrm{Atom}(B,t_0,\tau)\) **только с параметрами** \(B>0\) и \(|\tau|+B\le K\).

**Статус:** стандартная (ZFC) функциональная аппроксимация на компакте; в твоём документе это формально совпадает с Lemma 6.4 “Fixed-\(t_0\) cone density”【185:8†RH_Q3.pdf†L63-L67】.

---

## 1. Формальное утверждение

### Объекты и универсум
- Функции \(\Phi : \mathbb{R}\to\mathbb{R}\).
- Фиксированы \(K>0\) и \(t_0>0\) (в проекте: \(t_0=t_{\mathrm{sym}}=3/50\)).

### Гипотезы (как в твоём Lean `W_K`)
- \(\Phi\) even, nonneg, “continuous on \([-K,K]\)” (или глобально continuous), и `support Φ ⊆ Icc (-K) K`.

### Цель
- Построить \(g\) как конечную неотрицательную линейную комбинацию атомов (то есть \(g\in\) конус атомов), причём **каждый атом** удовлетворяет \(|\tau|+B\le K\), и доказать \(\|g-\Phi\|_\infty<\varepsilon\) на \([-K,K]\).

---

## 2. Определения и нотация

### Fejér hat (твоя `FejerKernel`)
\[
F_B(x)=\max(0,1-|x|/B),\quad \text{(поддержка: }|x|<B\text{ для `Function.support`)}
\]

### Heat kernel (твоя `HeatKernel`)
\[
H_t(x)=c(t)\,e^{-x^2/(4t)} \quad (\text{положительная, гладкая}).
\]

### Atom (твоя `Atom`)
Симметризованный вариант (чтобы автоматически получить evenness):
\[
\mathrm{Atom}(B,t,\tau)(x)=\tfrac12\Big(F_B(x-\tau)H_t(x-\tau)+F_B(x+\tau)H_t(x+\tau)\Big).
\]

**Ключевой момент:** хоть \(H_t\) имеет “бесконечную поддержку”, атом имеет поддержку ровно там, где ненулевой Fejér‑фактор. Поэтому никакая “Gaussian tail truncation” для **hg_supp** не нужна — проблема только в том, что сдвиг \(\tau\) может вылезти за \([-K,K]\).

### Support‑safe constraint (Option 2)
\[
\boxed{|\,\tau\,|+B \le K}
\]
тогда \(\mathrm{supp}(\mathrm{Atom}(B,t,\tau))\subseteq [-K,K]\).

---

## 3. Зависимости

1. **Факт A (Fejér nonzero ⇒ abs bound):**  
   \(F_B(y)\neq 0 \Rightarrow |y|<B\).
2. **Факт B (support of sum/product):**  
   \(\mathrm{support}(fg)\subseteq \mathrm{support}(f)\cap \mathrm{support}(g)\);  
   \(\mathrm{support}(f+g)\subseteq \mathrm{support}(f)\cup \mathrm{support}(g)\).
3. **Факт C (triangle inequality chaining):**  
   \(|a-d|\le |a-b|+|b-c|+|c-d|\).
4. **План аппроксимации из документа:** позитивная кусочно‑линейная интерполяция по равномерной сетке и Lipschitz‑контроль heat‑фактора【193:0†RH_Q3.pdf†L68-L87】.
5. (Если нужно) **Lipschitz/Uniform continuity** heat kernel на компакте \([-2K,2K]\).

---

## 4. Roadmap

1. **(Fix support)** Ввести “good parameter” предикат \(Good(K,B,\tau):= (0<B)\land(|\tau|+B\le K)\).  
   Доказать: `support (Atom B t τ) ⊆ Icc (-K) K`.
2. **(Density)** Для \(\Phi\in W_K\) построить “hat interpolant” \(h\) из Fejér‑шляп, затем заменить каждую шляпу на масштабированный Fejér×heat‑атом \(g\).  
3. **(h_approx)** Треугольником: \(\|g-\Phi\|_\infty \le \|g-h\|_\infty + \|h-\Phi\|_\infty\).  
4. Проверить: nonneg/even/cont уже закрыты; теперь закрываются hg_supp и h_approx.

---

## 5. Леммы

### Лемма 1: Fejér nonzero ⇒ abs < B
**Формально:** \(\forall B>0,\ \forall x,\ F_B(x)\ne 0 \Rightarrow |x|<B\).

**Смысл:** это ключ к поддержке.

**Lean‑ready (шаблон):**
```lean
lemma fejer_ne_zero_iff_abs_lt (hB : 0 < B) :
  (FejerKernel B x ≠ 0) ↔ (|x| < B) := by
  -- unfold FejerKernel; split cases on |x| < B vs ≥ B; use max_eq_left/max_eq_right
  sorry
```

---

### Лемма 2: Support‑safe shift bound
**Формально:** если \(|\tau|+B\le K\) и \(F_B(x-\tau)\ne 0\), то \(x\in[-K,K]\).

**Доказательство (ключевой шаг):**  
\(|x| \le |x-\tau|+|\tau| < B+|\tau| \le K\).

**Lean‑ready:**
```lean
lemma mem_Icc_of_fejer_shift_ne_zero
  (hB : 0 < B) (hτ : |τ| + B ≤ K)
  (hx : FejerKernel B (x - τ) ≠ 0) :
  x ∈ Set.Icc (-K) K := by
  have hxlt : |x - τ| < B := (fejer_ne_zero_iff_abs_lt (B:=B) (x:=x-τ) hB).1 hx
  have habs : |x| < K := by
    -- x = (x - τ) + τ
    have htri : |x| ≤ |x - τ| + |τ| := by
      simpa [sub_eq_add_neg, add_assoc] using (abs_add (x - τ) τ)
    have : |x| < B + |τ| := lt_of_le_of_lt htri (add_lt_add_right hxlt _)
    exact lt_of_lt_of_le this (by simpa [add_comm, add_left_comm, add_assoc] using hτ)
  -- convert |x| < K to membership in Icc
  exact (abs_lt.mp habs).imp le_of_lt le_of_lt
```

---

### Лемма 3: `hg_supp` for one atom
**Формально:** \(Good(K,B,\tau)\Rightarrow \mathrm{support}(\mathrm{Atom}(B,t,\tau))\subseteq [-K,K]\).

**Сигнал/аномалия (твоя блокировка):**  
без \(|\tau|+B\le K\) это ложь (и ровно это тебя и убило).

**Lean‑ready:**
```lean
lemma support_atom_subset_Icc
  (hB : 0 < B) (hτ : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  intro x hx
  -- Atom is (term1 + term2)/2; support of scalar doesn't matter; use support_add
  have : x ∈ Function.support (fun x => FejerKernel B (x - τ) * HeatKernel t (x - τ))
        ∪ Function.support (fun x => FejerKernel B (x + τ) * HeatKernel t (x + τ)) := by
    -- use `Function.support_add` (or `support_add_subset`) and `hx`
    sorry
  rcases this with hx | hx
  · -- term (x - τ)
    -- from support of mul get FejerKernel ≠ 0
    have hfej : FejerKernel B (x - τ) ≠ 0 := by
      -- because HeatKernel never 0 (or use support_mul_subset)
      sorry
    exact mem_Icc_of_fejer_shift_ne_zero (K:=K) (B:=B) (τ:=τ) (x:=x) hB hτ hfej
  · -- term (x + τ): same with τ replaced by (-τ) or direct triangle inequality
    have hfej : FejerKernel B (x + τ) ≠ 0 := by sorry
    -- note x+τ = x - (-τ)
    have : x ∈ Set.Icc (-K) K := by
      -- reuse previous lemma with (-τ)
      have hτ' : |(-τ)| + B ≤ K := by simpa using hτ
      simpa [sub_eq_add_neg] using
        mem_Icc_of_fejer_shift_ne_zero (K:=K) (B:=B) (τ:=-τ) (x:=x) hB hτ' (by simpa using hfej)
    exact this
```

This lemma is the **direct patch** that unblocks your `hg_supp`.

---

### Лемма 4: Triangle chain for `h_approx`
Your document literally does the “sum of three errors < ε” step by **triangle inequality** in Step 4【185:8†RH_Q3.pdf†L32-L45】.

**Lean‑ready micro‑lemma (pointwise):**
```lean
lemma abs_sub_le_three (a b c d : ℝ) :
  |a - d| ≤ |a - b| + |b - c| + |c - d| := by
  -- two applications of abs_sub_le
  calc
    |a - d| ≤ |a - b| + |b - d| := by simpa using abs_sub_le a b d
    _ ≤ |a - b| + (|b - c| + |c - d|) := by
          nlinarith [abs_sub_le b c d]
    _ = |a - b| + |b - c| + |c - d| := by ring
```

Then your `h_approx` becomes a one‑liner:

```lean
-- schematic: h ≈ gR, gR ≈ g, g ≈ Φ each ≤ ε/3
have hx : |h x - Φ x| ≤ |h x - gR x| + |gR x - g x| + |g x - Φ x| :=
  abs_sub_le_three (h x) (gR x) (g x) (Φ x)
-- then `calc ... ≤ ε/3 + ε/3 + ε/3 := by nlinarith`
```

That’s exactly the missing “triangle inequality chain” you flagged.

---

### Лемма 5: Density with the constraint \(|\tau|+B\le K\)
This is exactly the fixed‑\(t_0\) lemma in the pdf: conoid generated by \(\Phi_{B,t_0,\tau}\) with \(|\tau|+B\le K\) is dense, using hat interpolation and Lipschitz control【193:0†RH_Q3.pdf†L63-L94】.

**Lean‑ready statement (high level):**
```lean
theorem atomCone_dense_in_WK_fixed_t
  (hK : 0 < K) (ht : 0 < t0) :
  -- pick your density notion: `Dense` / `DenseWithin` / `closure` equality
  -- below is an ε-approx form on Set.Icc (-K) K
  ∀ ⦃Φ : ℝ → ℝ⦄, Φ ∈ W_K K → ∀ ε > 0,
    ∃ g, g ∈ AtomCone_K_restricted K t0 ∧
      (∀ x ∈ Set.Icc (-K) K, |g x - Φ x| < ε) := by
  -- proof sketch:
  -- 1) choose mesh δ by uniform continuity of Φ on [-K,K]
  -- 2) build hat interpolant h = Σ Φ(τ_j) Λ_δ(·-τ_j)
  -- 3) replace Λ_δ by scaled Atom(δ,t0,τ_j) using Lipschitz of HeatKernel
  -- 4) triangle inequality
  sorry
```

Where `AtomCone_K_restricted` is your cone definition but with the predicate `|τ| + B ≤ K` baked into the generator set.

---

## 6. Основной proof sketch for Option 2

### Step A — Fix the definitional contradiction (hg_supp)
Define the generator set with:
\[
\mathcal{G}_K(t_0)=\{\mathrm{Atom}(B,t_0,\tau)\ :\ B>0,\ |\tau|+B\le K\}.
\]
Then every generator satisfies `support ⊆ Icc(-K)K` by Lemma 3, hence any finite nonneg combination too.

This is exactly the move your pdf makes in Lemma 6.4【185:8†RH_Q3.pdf†L63-L67】.

### Step B — Approximate Φ by hat interpolant h
Pick mesh \(\delta>0\) so small that uniform continuity gives:
\[
\|h-\Phi\|_\infty < \varepsilon/3,
\]
where \(h\) is positive piecewise‑linear interpolation using Fejér hats \(H_j(\xi)=\Lambda_\delta(\xi-\tau_j)\) on a uniform grid inside \([-K,K]\). This is explicitly stated in the document【193:0†RH_Q3.pdf†L68-L76】.

### Step C — Replace hats by Fejér×heat atoms to get g
Define \(g=\sum_j c_j\,\mathrm{Atom}(\delta,t_0,\tau_j)\) with \(c_j\ge 0\) chosen so amplitudes match (depending on your exact Lean atom definition, use \(H_{t_0}(0)\) or whatever value makes \(g\) match \(h\) at gridpoints).

On each hat support, the heat factor varies by at most \(L_{t_0}\delta\) (heat is Lipschitz on \([-2K,2K]\)), so:
\[
\|g-h\|_\infty \le L_{t_0}\delta\cdot\|c\|_{\ell^1} < \varepsilon/3
\]
for δ small enough; this is also exactly in the document proof【193:0†RH_Q3.pdf†L76-L87】.

### Step D — Triangle inequality (this is your `h_approx`)
\[
\|g-\Phi\|_\infty \le \|g-h\|_\infty + \|h-\Phi\|_\infty < \varepsilon.
\]
Or, if you still have three intermediate approximants, use the 3‑term chain (Lemma `abs_sub_le_three`) — this is the Step 4 pattern in the document【185:8†RH_Q3.pdf†L32-L45】.

---

## 7. Audit — Edge Check / Pitfalls

### Phenomenon 1: “Heat kernel has infinite support”
**Diagnosis:** irrelevant for `hg_supp` because in your atom it is multiplied by Fejér; support is controlled by the Fejér factor alone. The real issue is **shifted Fejér support crossing \([-K,K]\)**.

**Fix:** enforce \(|\tau|+B\le K\) at the generator level.

### Phenomenon 2: Boundary values at ±K
If your `W_K` uses only `ContinuousOn` on `Icc`, then functions might not be forced to be continuous at the boundary from outside. But the cone generators with Fejér hats will typically vanish at boundary points when support is enforced.
- If you later discover an approximation obstruction at endpoints, the correct structural fix is: either make `W_K` require global continuity (`Continuous`) + support, or add boundary conditions `Φ(±K)=0`.  
In the intended analytic class \(C_c\), that vanishing is automatic.

### Phenomenon 3: coefficient formula mismatch
The pdf proof uses \(c_j=f(\tau_j)/\rho_{t_0}(\tau_j)\) in its particular atom normalization【193:0†RH_Q3.pdf†L76-L83】.  
If your Lean `Atom` uses \(H_t(x-\tau)\) (shifted), then the “right” denominator is typically \(H_t(0)\). This is not conceptual — it’s just matching the algebra of your chosen `Atom`.

---

## Bottom line decision

**Pick Option 2.** It is the intended spec (Lemma 6.4) and is the only option that:
- makes `hg_supp` *true by construction*,
- avoids any heavy “truncate Gaussian tails” engineering,
- keeps the proof Lean‑friendly (piecewise linear hats + uniform continuity/Lipschitz),
- and matches the document’s fixed‑\(t_0\) density argument【185:8†RH_Q3.pdf†L63-L67】【193:0†RH_Q3.pdf†L68-L87】.

If ты хочешь, я могу also rewrite your `AtomCone_K` predicate as a minimal patch: keep `Atom` unchanged, but change the **parameter admissibility** from “\(τ∈[-K,K]\) and \(B≤K\)” to “\(0<B\) and \(|τ|+B≤K\)”, so that all already‑proved nonneg/even/cont lemmas stay reusable and only `hg_supp`/`h_approx` need the new small lemmas above.

## ASSISTANT
## 0. Теорема и статус

**Точная формулировка (то, что реально закрывает `hg_supp` и не убивает плотность):**  
Для любого \(K>0\) и фиксированного \(t_0>0\) (у тебя это \(t_{\mathrm{sym}}=3/50\)) конус, порождённый *Fejér×heat*-атомами \(\Phi_{B,t_0,\tau}\) при ограничении  
\[
B>0,\qquad |\tau|+B\le K,
\]  
**плотен** в \(C^+_{\mathrm{even}}([-K,K])\) по норме \(\|\cdot\|_\infty\). Это ровно формулируется как “Fixed-\(t_0\) cone density” (Лемма 6.4).【270:1†RH_Q3.pdf†L63-L67】

**Статус:** стандартная математика (ZFC). В твоём проекте это уже записано в документе как Лемма 6.4, то есть именно “Option 2” уже “легализован” текстом доказательства.【270:1†RH_Q3.pdf†L63-L67】

---

## 1. Контекст и почему у тебя сейчас противоречие

Ты сейчас упёрся в:

- атомы вида (в PDF это \(\Phi_{B,t,\tau}\))
\[
\Phi_{B,t,\tau}(\xi)=\tfrac12\bigl[\Lambda_B(\xi-\tau)\rho_t(\xi-\tau)+\Lambda_B(\xi+\tau)\rho_t(\xi+\tau)\bigr],
\]
где \(\Lambda_B(x)=(1-|x|/B)_+\), \(\rho_t(x)=(4\pi t)^{-1/2}e^{-x^2/(4t)}\).【270:13†RH_Q3.pdf†L39-L56】

- и требование \( \mathrm{support}(g)\subseteq[-K,K]\) в `AtomCone_K` / `W_K`.

Если ты разрешаешь \(\tau\in[-K,K]\) и просто \(B\le K\), то носитель *сдвинутого* \(\Lambda_B(\cdot-\tau)\) лежит в \([\tau-B,\tau+B]\), и при \(\tau\approx K\) это вылезает за \([-K,K]\). Это и есть твой `hg_supp`-блокер.

Ключ: **исправление должно быть на уровне допустимых параметров атома**, а не “доказыванием невозможного”.

---

## 2. Анализ вариантов — что лучше

### Option 2 — ограничить параметры атомов: \( |\tau|+B\le K \)
**Это лучший вариант.** Почему:

1. **Мгновенно снимает `hg_supp`.**  
   Если \(|\tau|+B\le K\), то оба интервальных носителя \([\tau-B,\tau+B]\) и \([-\,\tau-B,-\,\tau+B]\) целиком сидят в \([-K,K]\). Следовательно support каждого атома и любой конечной суммы тоже \(\subseteq[-K,K]\).

2. **Плотность не теряется.** Это не догадка — это прямо сформулировано и доказано как Лемма 6.4 (Fixed-\(t_0\) cone density).【270:1†RH_Q3.pdf†L63-L67】

3. **Совместимо с тем, что тебе надо по пайплайну:** дальше в замыкании ты используешь A2-непрерывность и переносишь неотрицательность через предел. В тексте “collect errors via triangle inequality” — ровно та цепочка, которую ты хочешь для `h_approx`.【270:0†RH_Q3.pdf†L72-L84】

**Минус:** придётся перестроить/упростить конструкцию аппроксимации: вместо “\(B\) большой \(\Rightarrow \Lambda_B\approx 1\)” (шаг 3 в Теореме 6.3) тебе нужен режим “\(B=\delta\) маленький” + липшицевость \(\rho_{t_0}\) (как в Лемме 6.4). Но это как раз Lean-дружелюбно.

---

### Option 3 — “трункация” (cutoff) и оценка хвоста
Рабоче-технически возможно, но **хуже для Lean**, потому что:

- добавляешь новый объект (обрезанный heat или обрезанный атом),
- надо доказывать, что обрезка сохраняет нужные свойства,
- и главное — надо тащить отдельную оценку ошибки “обрезка vs оригинал”.

Я дам ниже готовые “error bounds”, но я бы не шёл этим путём, пока Option 2 уже подтверждён Леммой 6.4.【270:1†RH_Q3.pdf†L63-L67】

---

### Option 1 — менять \(W_K\) / менять понятие носителя
Это почти всегда ripple-эффект по всему стеку (A2/A3/RKHS), так что **не советую**, если цель “быстро закрыть сорри”.

---

## 3. Выбранный вариант: Option 2

### 3.1. Что именно надо поправить в Lean (суть)
Тебе нужно, чтобы **в определении “атомов, которыми генерируем конус”** было условие:

\[
\boxed{\,B>0 \ \wedge\ |\tau|+B\le K\,}
\]

И тогда `hg_supp` закрывается прямой леммой про support одного атома + леммой про support суммы.

А плотность ты берёшь не из “Theorem 6.3 Step 3 Fejér truncation с большим \(B\)” (где носитель распухает), а из “Lemma 6.4 Fixed-\(t_0\) cone density” (где \(B=\delta\) маленький и \(|\tau|+B\le K\)).【270:1†RH_Q3.pdf†L63-L75】

---

## 4. Полный proof sketch (Option 2) в стиле A1_density

### 4.1. Цель
Для \(f\in W_K\) (или \(f\in C^+_{\mathrm{even}}([-K,K])\) в твоей реализации) и \(\varepsilon>0\) построить
\[
g=\sum_{j=1}^N c_j\,\Phi_{B,t_0,\tau_j}
\]
так, что:
- \(c_j\ge 0\),
- \(B>0\),
- \(|\tau_j|+B\le K\) для всех \(j\),
- \(\|g-f\|_{\infty,[-K,K]}<\varepsilon\),
- и автоматически: `g ≥ 0`, `g_even`, `g_cont`, `support g ⊆ [-K,K]`.

### 4.2. Шаг A — позитивная “hat”-интерполяция (Fejér только)
Выбираем сетку \(\{\tau_j\}\subset[-K,K]\) с шагом \(\delta\), но **в сумму берём только те \(\tau_j\), для которых \(|\tau_j|+\delta\le K\)** (т.е. внутренние точки). Определяем “шляпки”
\[
H_j(\xi):=\Lambda_\delta(\xi-\tau_j).
\]
Дальше стандартный факт: можно сделать \(h(\xi)=\sum_j f(\tau_j)H_j(\xi)\) так, что \(h\ge 0\) и
\[
\|h-f\|_\infty<\varepsilon/3.
\]
Именно этот шаг указан в доказательстве Леммы 6.4 как “positive piecewise-linear interpolation” через hats \(H_j(\xi):=\Lambda_\delta(\xi-\tau_j)\).【270:1†RH_Q3.pdf†L68-L71】

*(Техническая ремарка, важная для твоего `support`: так как \(|\tau_j|+\delta\le K\), каждая \(H_j\) имеет support \(\subseteq[-K,K]\).)*

### 4.3. Шаг B — замена шляпок на Fejér×heat при фиксированном \(t_0\)
Ключ: \(\rho_{t_0}\) липшицева на компактe \([-2K,2K]\). Это тоже прямо заявлено в Лемме 6.4.【270:1†RH_Q3.pdf†L71-L75】

Берём атомы \(\Phi_{\delta,t_0,\tau_j}\). Идея такая: на носителе \(H_j\) мы имеем \(|\xi-\tau_j|\le \delta\), а значит \(\rho_{t_0}(\xi-\tau_j)\) мало меняется.

Практичный для Lean выбор коэффициентов (избегающий деления на \(\rho_{t_0}(\tau_j)\)):  
положи
\[
c_j := \frac{f(\tau_j)}{\rho_{t_0}(0)}.
\]
Тогда на носителе \(H_j\):
\[
\Big|c_j\,\Lambda_\delta(\xi-\tau_j)\rho_{t_0}(\xi-\tau_j) - f(\tau_j)\Lambda_\delta(\xi-\tau_j)\Big|
\le f(\tau_j)\Lambda_\delta(\xi-\tau_j)\cdot \frac{|\rho_{t_0}(\xi-\tau_j)-\rho_{t_0}(0)|}{\rho_{t_0}(0)}.
\]
По липшицевости:
\[
|\rho_{t_0}(\xi-\tau_j)-\rho_{t_0}(0)| \le L_{t_0}\,|\xi-\tau_j|\le L_{t_0}\delta.
\]
Суммируя по \(j\) и используя неотрицательность:
\[
\|g-h\|_\infty \le \frac{L_{t_0}\delta}{\rho_{t_0}(0)}\cdot \|f\|_\infty.
\]
Выбираем \(\delta\) так, чтобы это было < \(\varepsilon/3\).

*(Ссылка на идею оценки разности в Лемме 6.4 присутствует: там выписывается \(g-h\) как сумма с разностью \(\rho_{t_0}(\cdot)-\rho_{t_0}(\cdot)\) и дальше бьётся липшицевостью.*【270:1†RH_Q3.pdf†L71-L75】)*

### 4.4. Шаг C — evenness
Если твой `Atom` уже симметризован (как в определении \(\Phi_{B,t,\tau}\)), evenness автоматом (ты уже это закрыл как `hg_even`).

Если вдруг у тебя “несимметризованный” атом, то добавляешь \(\mathrm{Sym}(u)=(u(\cdot)+u(-\cdot))/2\). В PDF фактор \(1/2\) и комментарий про Sym — уже включены в определение атома.【270:13†RH_Q3.pdf†L39-L60】

### 4.5. Шаг D — собрать ошибки (это твой `h_approx`)
Финальная цепочка — чистая треугольная неравенство:
\[
\|g-f\|_\infty \le \|g-h\|_\infty + \|h-f\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
Если у тебя всё ещё 3-ступенчатая конструкция (как в Теореме 6.3: mollify → Riemann → Fejér), то используешь ровно ту же схему, что записана как “collect errors via triangle inequality”.【270:0†RH_Q3.pdf†L72-L84】

---

## 5. `hg_supp` — как закрывается (сигнал: это именно “definitional issue”)

### 5.1. Локальная лемма (один атом)
Если \(|\tau|+B\le K\), то:
- из \(\Lambda_B(\xi-\tau)\neq 0\) следует \(|\xi-\tau|<B \Rightarrow \xi\in(\tau-B,\tau+B)\subseteq[-K,K]\);
- аналогично для \(\xi+\tau\).

Значит
\[
\mathrm{support}(\Phi_{B,t,\tau})\subseteq[-K,K].
\]

### 5.2. Сумма
Для конечной суммы: support суммы \(\subseteq\) объединение support’ов слагаемых, а каждое \(\subseteq[-K,K]\), значит и сумма \(\subseteq[-K,K]\).

---

## 6. Lean-style statements (скелеты “как это должно выглядеть”)

Ниже — **Lean-стиль**, но я намеренно оставляю некоторые имена (`FejerKernel`, `HeatKernel`, `AtomCone_K`) такими, как у тебя в файле.

### 6.1. Параметры атома “внутри окна”
```lean
def AtomOK (K B τ : ℝ) : Prop :=
  0 < B ∧ |τ| + B ≤ K
```

### 6.2. Support одного атома
```lean
lemma support_Atom_subset_Icc
  {K B t τ : ℝ} (hOK : AtomOK K B τ) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- unfold Atom; use that Atom x ≠ 0 -> one Fejer factor ≠ 0
  -- Fejer nonzero => |x ± τ| < B
  -- conclude -K ≤ x ≤ K from |τ| + B ≤ K
  sorry
```

### 6.3. Support конечной суммы атомов
(если у тебя `g = ∑ i in s, c i • Atom ...`)
```lean
lemma support_finset_sum_subset_Icc
  {K : ℝ} {s : Finset ι} {c : ι → ℝ} {B τ : ι → ℝ} {t : ℝ}
  (hOK : ∀ i ∈ s, AtomOK K (B i) (τ i)) :
  Function.support (fun x => ∑ i in s, c i * Atom (B i) t (τ i) x)
    ⊆ Set.Icc (-K) K := by
  -- use: support_sum_subset / support_add / support_mul
  -- reduce to each term's support, then apply support_Atom_subset_Icc
  sorry
```

### 6.4. Липшицевость heat kernel на компакте
```lean
lemma heatKernel_lipschitzOn_Icc
  {t K : ℝ} (ht : 0 < t) :
  ∃ L ≥ 0, ∀ {x y},
    x ∈ Set.Icc (-K) K → y ∈ Set.Icc (-K) K →
    |HeatKernel t x - HeatKernel t y| ≤ L * |x - y| := by
  -- Mean Value Theorem + bound on derivative on compact
  sorry
```

### 6.5. “Hat → Atom” аппроксимация при фиксированном t
```lean
lemma approx_hat_by_atom_fixed_t
  {t0 δ : ℝ} (ht0 : 0 < t0) (hδ : 0 < δ) :
  ∃ C, 0 ≤ C ∧
    ∀ x, |(1 / HeatKernel t0 0) * (FejerKernel δ x * HeatKernel t0 x) - FejerKernel δ x|
         ≤ C * δ := by
  -- Use Lipschitz of HeatKernel on [-δ, δ]
  sorry
```

### 6.6. Главная “density” теорема (как тебе надо для A1_density_WK_axiom)
```lean
theorem atomCone_dense_WK_fixed_t
  (K : ℝ) (hK : 0 < K) :
  -- t_sym fixed globally
  Dense (AtomCone_K K t_sym) (W_K K) := by
  -- build hat interpolant h
  -- replace hats with atoms using Lipschitz
  -- triangle inequality
  sorry
```

---

## 7. Аудит edge-cases

- **Boundary:** чтобы Option 2 работал без “невозможности аппроксимации на границе”, нужно, чтобы элементы \(W_K\) были *реально компактно поддержанными непрерывными* функциями на \(\mathbb R\) (тогда \(f(\pm K)=0\)). Это стандартно для \(C_c\) и согласуется с тем, как в тексте делается “extend by zero to \(\tilde f\in C_c(\mathbb R)\)”.【270:13†RH_Q3.pdf†L66-L69】  
- **Деление на \(\rho_{t_0}(0)\):** нужно лемма `HeatKernel t0 0 > 0` при `0 < t0`. Это тривиально (экспонента >0, нормировка >0).
- **`h_approx` (triangle chain):** можешь буквально повторить шаблон “collect errors via triangle inequality”, он уже выписан в тексте как (6.7).【270:0†RH_Q3.pdf†L72-L84】

---

## 8. Если всё-таки нужен Option 3: truncation + error bounds

Пусть \( \rho_t(x) = (4\pi t)^{-1/2} e^{-x^2/(4t)}\). Возьми усечённое ядро
\[
\rho_t^{(R)}(x):=\rho_t(x)\cdot \mathbf{1}_{|x|\le R}.
\]
Тогда “хвостовая масса”:
\[
\mathrm{Tail}(t,R):=\int_{|x|>R}\rho_t(x)\,dx
=2\int_R^\infty (4\pi t)^{-1/2}e^{-x^2/(4t)}\,dx.
\]
Стандартная оценка:
\[
\mathrm{Tail}(t,R)\ \le\ \frac{2\sqrt{t}}{R\sqrt{\pi}}\exp\!\Big(-\frac{R^2}{4t}\Big).
\]
Отсюда, для любого ограниченного \(f\) (например \(\|f\|_\infty\le M\)):
\[
\|f*\rho_t - f*\rho_t^{(R)}\|_\infty \le M\cdot \mathrm{Tail}(t,R).
\]
То есть выбирая
\[
R \gtrsim 2\sqrt{t\log(1/\varepsilon)}
\]
ты получаешь \(\varepsilon\)-малую ошибку усечения.

Lean-скелет:
```lean
def HeatKernelTrunc (t R : ℝ) (x : ℝ) : ℝ :=
  if |x| ≤ R then HeatKernel t x else 0

lemma heatKernel_tail_bound
  {t R : ℝ} (ht : 0 < t) (hR : 0 < R) :
  (∫ x in Set.Ioi R, HeatKernel t x) ≤
    (Real.sqrt t) / (R * Real.sqrt Real.pi) * Real.exp (-(R^2) / (4*t)) := by
  -- use Gaussian tail estimate
  sorry

lemma conv_trunc_error_bound
  {f : ℝ → ℝ} {t R : ℝ} (ht : 0 < t) (hR : 0 < R)
  (hf : ∀ x, |f x| ≤ M) :
  ‖(f ⋆ HeatKernel t) - (f ⋆ HeatKernelTrunc t R)‖∞ ≤ M * (2 * tailMass) := by
  sorry
```

---

## Итог (что делать прямо сейчас)

1. **Выбирай Option 2.** Это не “предположение”, это уже зафиксировано как Лемма 6.4: генераторы с \(|\tau|+B\le K\) всё равно дают плотность при фиксированном \(t_0\).【270:1†RH_Q3.pdf†L63-L67】
2. **В Lean:** внеси условие \(|\tau|+B\le K\) в генераторы `AtomCone_K` (или в список допустимых атомов для конкретного `hg`), и `hg_supp` закроется.
3. `h_approx`: собирай ошибки именно как в “collect errors via triangle inequality” (шаблон (6.7)).【270:0†RH_Q3.pdf†L72-L84】

Если хочешь, я могу переписать прямо “минимальный патч” к твоей текущей структуре `A1_density_WK_axiom` (какой тип/структура у `hg` и как именно строится сумма), но уже сейчас у тебя есть чёткий и математически легитимный маршрут, который совпадает с текстом доказательства в проекте.

## ASSISTANT
According to a document from **January 1, 2026**, у тебя в Lean сейчас столкновение ровно того типа, которое в тексте закрывается **переопределением “какие атомы разрешены на окне K”**: в RH_Q3 прямо есть отдельная **Lemma 6.4 (Fixed‑t₀ cone density)** с ограничением **\(|\tau|+B\le K\)**. Это ровно тот патч, который убивает твой `hg_supp` без “тяжёлых” хвостов и без перетряски A2/A3. 【177:5†RH_Q3.pdf†L1-L14】【177:0†RH_Q3.pdf†L63-L67】

Ниже — разбор вариантов, затем компактный proof‑sketch (математика → план → детали), и в конце — Lean‑style формулировки лемм/теорем, которые прямо закрывают `hg_supp` и дают тебе дорожку на `h_approx`.

---

## 0. Теорема: Fix для A1_density support‑issue и статус

**Точная формулировка (выбранный подход / Option 2):**  
Для фиксированных \(K>0\) и \(t_0>0\) (у тебя \(t_0=t_{\mathrm{sym}}=3/50\)), если разрешать только атомы с параметрами \((B,\tau)\) удовлетворяющими \(B>0\) и \(|\tau|+B\le K\), то:
1) каждый такой атом (и любая конечная неотрицательная линейная комбинация атомов) имеет `support ⊆ [-K,K]`;  
2) конус, порождённый такими атомами, **плотен** в классе тестов на окне \([-K,K]\) (в норме \(\|\cdot\|_\infty\)).  

**Статус:** стандартная математика/анализ; в RH_Q3 это оформлено как Lemma 6.4. 【177:0†RH_Q3.pdf†L63-L67】

---

## 1. Контекст: почему текущее определение ломает `hg_supp`

Ты сейчас имеешь:

- **Atom** (в Lean):  
  \[
  \mathrm{Atom}(B,t,\tau)(x)=\mathrm{FejerKernel}(B,x+\tau)\mathrm{HeatKernel}(t,x+\tau)+
  \mathrm{FejerKernel}(B,x-\tau)\mathrm{HeatKernel}(t,x-\tau).
  \]
- Доказано: Fejér “живёт” на \(|x-\tau|<B\).  
- Но у тебя в `AtomCone_K` разрешено \(\tau\in[-K,K]\) и \(B\le K\). Тогда support отдельного атома попадает лишь в
  \[
  [\tau-B,\tau+B]\subset[-K-B,\,K+B]\subset[-2K,2K],
  \]
  а **не** в \([-K,K]\). Поэтому `hg_supp` реально невыполним без изменения определения допустимых параметров.

**Ключевой факт (важно, чтобы не уйти в Option 3 по ошибке):**  
Тепловой множитель *не расширяет support*, потому что support задаётся точками, где функция ≠ 0, а произведение с Fejér остаётся нулём ровно там, где Fejér ноль. То есть проблема не в “инфинитной поддержке Gaussian”, а в геометрии сдвига \(\tau\) и ширины \(B\).

---

## 2. Опции и выбор “лучшая”

### Option 1: расширить окно в W_K (например, требовать `support ⊆ [-2K,2K]`)
**Плюсы:** минимум изменений в A1_density (твой текущий `τ∈[-K,K], B≤K` сразу ок).  
**Минусы:** каскад по стеку: A2 “Lipschitz на компакте K” и локальная конечность прайм-сэмплера завязаны на “support ⊆ [-K,K]” (в RH_Q3 это явно: finiteness prime sum требует `supp Φ ⊂ [-K,K]`). 【177:1†RH_Q3.pdf†L66-L76】  
Т.е. придётся либо менять K→2K везде, либо вводить отдельный “раздув” K’. Это не смертельно, но некрасиво и рисково для остального стека.

### Option 3: обрезать heat kernel и оценить ошибку
**Плюсы:** можно оставить широкий класс атомов.  
**Минусы:** это лишняя тяжёлая аналитика (tail bounds), а у тебя продукт с Fejér уже даёт компактную поддержку, так что “truncation heat” — не туда. Если же ты говоришь о **сглаживании через свёртку** в proof‑pipeline, то обрезание придётся делать на уровне аппроксимации, что ещё сложнее.

### **Option 2 (рекомендую): ограничить параметры атомов \(|\tau|+B\le K\)**
Это буквально то, что в RH_Q3 выделено отдельной леммой “Fixed‑t₀ cone density”. 【177:0†RH_Q3.pdf†L63-L67】

**Плюсы:**
- `hg_supp` становится прямым следствием треугольника \(|x|\le|x-\tau|+|\tau|\).
- Сохраняется “атомы лежат в W_K” ⇒ можно напрямую использовать A2 на том же K без хвостов.
- Есть готовый proof‑template: hat interpolation + контроль замены hat → hat×heat при фиксированном \(t_0\). 【177:1†RH_Q3.pdf†L28-L63】

**Минусы / скрытый край:**  
Если твой `W_K` в Lean допускает функции, не обязанные быть непрерывными на всей ℝ (например только `ContinuousOn` на `Icc`), тогда на границе \(±K\) могут быть ненулевые значения, и конус из “внутренних” hats может плохо аппроксимировать границу. Но если ты реально моделируешь \(C_c(\mathbb R)\) или хотя бы непрерывность “вокруг границы”, это исчезает. В RH_Q3 для прайм-части явно стоит \(Φ∈C_c(\mathbb R)\). 【177:1†RH_Q3.pdf†L66-L76】

**Итог:** выбирай Option 2.

---

## 3. План доказательства (Roadmap) для Option 2

1) Ввести предикат допустимости параметров:
\[
\mathrm{admissible}(K,B,\tau):\quad 0<B\ \wedge\ |\tau|+B\le K.
\]

2) **Support‑лемма для атома:**  
из `FejerKernel B (x-τ) ≠ 0` получаем `|x-τ| < B`, значит \(|x|\le|\tau|+|x-\tau|<|\tau|+B\le K\). Аналогично для \(x+\tau\).  

3) **Support‑лемма для конечной суммы:**  
`support (∑) ⊆ ⋃ support(term_i)`; раз каждый term_i поддержан в `Icc (-K) K`, то и сумма.

4) **Плотность:** использовать RH_Q3 Lemma 6.4: на окне \([-K,K]\) делаем позитивную piecewise-linear интерполяцию hats \(H_j=\Lambda_\delta(\cdot-\tau_j)\), затем заменяем каждый \(H_j\) на атом \(\Phi_{\delta,t_0,\tau_j}\). В RH_Q3 это оформлено как “Fixed‑t₀ cone density” при \(|\tau|+B\le K\). 【177:0†RH_Q3.pdf†L63-L71】

5) **Треугольник для `h_approx`:** стандартная цепочка
\[
\|h-f\|_\infty \le \|h-g\|_\infty + \|g-f\|_\infty
\]
или в варианте с 3 промежуточными аппроксимациями как в Step 4 Theorem 6.3 (ровно твой “triangle inequality chain”). 【177:0†RH_Q3.pdf†L32-L44】

---

## 4. Леммы (математика → Lean‑ready statements)

### 4.1. Support одного сдвинутого произведения Fejér×heat

**Математика:**  
Если \(x\in \mathrm{support}(\Lambda_B(x-\tau)\rho_t(x-\tau))\), то \(\Lambda_B(x-\tau)\neq0\Rightarrow |x-\tau|<B\), и значит \(|x|<|\tau|+B\le K\).

**Lean‑стейтмент (скелет):**
```lean
/-- admissible parameters for staying inside `[-K,K]` -/
def AtomAdmissible (K B τ : ℝ) : Prop := 0 < B ∧ |τ| + B ≤ K

lemma support_fejer_mul_heat_subset_Icc
  {K B t τ : ℝ} (h : AtomAdmissible K B τ) :
  Function.support (fun x ↦ FejerKernel B (x - τ) * HeatKernel t (x - τ))
    ⊆ Set.Icc (-K) K := by
  -- key steps:
  -- 1) x ∈ support → FejerKernel B (x-τ) ≠ 0
  -- 2) FejerKernel_ne_zero → |x-τ| < B
  -- 3) |x| ≤ |x-τ| + |τ| < B + |τ| ≤ K
  -- 4) rewrite to membership in Icc
  sorry
```

### 4.2. Support симметризованного Atom

Используй “support суммы ⊆ union supports” (рутинный шаг) и лемму выше для \(\tau\) и \(-\tau\).

```lean
lemma support_Atom_subset_Icc
  {K B t τ : ℝ} (h : AtomAdmissible K B τ) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- Atom = term(+τ) + term(-τ); each term supported in Icc
  -- use support_add_subset
  sorry
```

### 4.3. `hg_supp` для конуса (finite sum)

Скелет под типичное определение конуса как существование finset/weights:

```lean
lemma support_finset_sum_atoms_subset_Icc
  {K t : ℝ} {ι : Type} [DecidableEq ι]
  (s : Finset ι) (w : ι → ℝ) (B : ι → ℝ) (τ : ι → ℝ)
  (hBτ : ∀ i ∈ s, AtomAdmissible K (B i) (τ i)) :
  Function.support (fun x ↦ ∑ i in s, (w i) * Atom (B i) t (τ i) x)
    ⊆ Set.Icc (-K) K := by
  -- support_sum_subset + support_mul_subset_right + support_Atom_subset_Icc
  sorry
```

И это прямо закрывает твой `hg_supp` после того, как `AtomCone_K` будет требовать `AtomAdmissible`.

---

## 5. Плотность (Option 2): proof sketch, который реально формализуем

В RH_Q3 это Lemma 6.4: конус атомов с \(|\tau|+B\le K\) плотен на \([-K,K]\) при фиксированном \(t_0\). 【177:0†RH_Q3.pdf†L63-L67】

### 5.1. Набросок доказательства (как это реализовать в Lean)

1) **Hat‑интерполяция (Fejér‑hats):**  
Берёшь сетку \(\tau_j\) с шагом \(\delta\), строишь
\[
h(\xi)=\sum_j f(\tau_j)\, \Lambda_\delta(\xi-\tau_j),
\]
где \(\Lambda_\delta = \mathrm{FejerKernel}\ \delta\) (треугольная “шапка”).  
По равномерной непрерывности \(f\) на компакте, при достаточно малом \(\delta\) получаешь \(\|h-f\|_\infty<\varepsilon/3\). RH_Q3 формулирует это как “positive piecewise-linear interpolation”. 【177:1†RH_Q3.pdf†L28-L34】

2) **Замена hat → hat×heat (фиксированный \(t_0\)):**  
Хочешь заменить каждый \(f(\tau_j)\Lambda_\delta(\xi-\tau_j)\) на коэффициент×атом:
\[
g(\xi)=\sum_j c_j\, \Phi_{\delta,t_0,\tau_j}(\xi),
\]
где \(\Phi\) — твой Fejér×heat атом.  
Ключ: на носителе \(\Lambda_\delta(\xi-\tau_j)\) аргумент \(\xi-\tau_j\) мал, значит \(\rho_{t_0}(\xi-\tau_j)\) близка к \(\rho_{t_0}(0)\) (или к другой “опорной” точке, если у тебя другая конвенция). Это даёт контроль \(\|g-h\|_\infty<\varepsilon/3\) при малом \(\delta\), используя Lipschitz/UniformContinuity теплового ядра на \([-2K,2K]\). 【177:1†RH_Q3.pdf†L34-L63】

   **Аномалия (важно!):** в вытащенном кусочке RH_Q3 стоит \(c_j := f(\tau_j)/\rho_{t_0}(\tau_j)\) и разность \(\rho_{t_0}(\xi-\tau_j)-\rho_{t_0}(\tau_j)\). Это согласуется только если “heat‑factor” в атоме зависит от \(\xi\), а не от \(\xi-\tau_j\). У тебя в Lean атом явно от \((x\pm\tau)\), т.е. сдвинутый аргумент. Поэтому в Lean‑версии разумная нормировка — через \(\rho_{t_0}(0)\) и разность \(\rho_{t_0}(\xi-\tau_j)-\rho_{t_0}(0)\) (или просто использовать uniform continuity около 0). Иначе оценка “≤ L δ” не получится по геометрии. 【177:1†RH_Q3.pdf†L34-L63】

3) **Evenization и неотрицательность:**  
Ты уже закрыл `hg_even`, `hg_nonneg`. Evenization не портит неотрицательность. 【177:1†RH_Q3.pdf†L62-L63】

4) **Сбор ошибок треугольником (`h_approx`):**  
Если у тебя три этапа аппроксимации, просто делай ровно как Step 4 Theorem 6.3:
\[
\|h-f\|_\infty \le \|h-g_1\|_\infty + \|g_1-g_2\|_\infty + \|g_2-f\|_\infty.
\]
Это буквально прописано в RH_Q3 (6.7). 【177:0†RH_Q3.pdf†L32-L44】

---

## 6. Lean‑style теоремы, которые ты можешь прямо вставлять

### 6.1. “Правильный” AtomCone_K

Идея: поменять определение конуса так, чтобы параметры удовлетворяли `AtomAdmissible`.

```lean
/-- cone generated by admissible atoms on window `K` at fixed heat `t0` -/
def AtomCone_K (K t0 : ℝ) : Set (ℝ → ℝ) :=
  {g | ∃ (s : Finset (ℕ)) (w B τ : ℕ → ℝ),
        (∀ i ∈ s, 0 ≤ w i) ∧
        (∀ i ∈ s, AtomAdmissible K (B i) (τ i)) ∧
        g = (fun x ↦ ∑ i in s, (w i) * Atom (B i) t0 (τ i) x) }
```

(Форма параметризации через `ℕ`/`Fin n` — как у тебя в файле; важно лишь условие admissible.)

### 6.2. Закрыть `hg_supp`

```lean
lemma hg_supp
  {K t0 : ℝ} {g : ℝ → ℝ}
  (hg : g ∈ AtomCone_K K t0) :
  Function.support g ⊆ Set.Icc (-K) K := by
  rcases hg with ⟨s, w, B, τ, hw, hAdm, rfl⟩
  -- reduce to support_finset_sum_atoms_subset_Icc
  exact support_finset_sum_atoms_subset_Icc (K:=K) (t:=t0) s w B τ hAdm
```

### 6.3. Плотность (A1_density, fixed t_sym)

Тебе нужен вариант “∀f∈W_K, ∀ε>0, ∃g∈AtomCone_K, ‖f-g‖∞<ε”.

```lean
theorem A1_density_fixed_tsym
  (K : ℝ) (hK : 0 < K) :
  ∀ ⦃f : ℝ → ℝ⦄, f ∈ W_K K →
    ∀ ε > 0, ∃ g ∈ AtomCone_K K t_sym, (supOn_Icc K (fun x ↦ |g x - f x|)) < ε := by
  -- implement Lemma 6.4 strategy: hat interpolation + replace hats by atoms + triangle inequality
  sorry
```

Здесь `supOn_Icc K` — твоя уже существующая “uniform” норма/супремум на `Set.Icc (-K) K` (или `Real.sSup`‑обёртка).

### 6.4. Утилита для `h_approx`: тройной треугольник

```lean
lemma sup_abs_sub_le_three
  (K ε : ℝ) {f g h u : ℝ → ℝ}
  (h1 : supOn_Icc K (fun x ↦ |h x - u x|) < ε/3)
  (h2 : supOn_Icc K (fun x ↦ |u x - g x|) < ε/3)
  (h3 : supOn_Icc K (fun x ↦ |g x - f x|) < ε/3) :
  supOn_Icc K (fun x ↦ |h x - f x|) < ε := by
  -- pointwise: |h-f| ≤ |h-u|+|u-g|+|g-f|
  -- then take sup
  sorry
```

Это прямой аналог (6.7) из текста. 【177:0†RH_Q3.pdf†L32-L44】

---

## 7. Аудит: слабые места и что проверить в Lean

1) **Support = Function.support vs “топологический support”:**  
`Function.support` — множество точек где `f x ≠ 0`. Для непрерывных compactly supported функций это нормально, но на границе есть тонкости, если ты не требуешь глобальную `Continuous`. Если W_K сейчас только `ContinuousOn` на `Icc`, ты можешь случайно разрешить “скачок на границе”, и тогда плотность конуса “внутренних” hats может зависнуть.  
Практический фикс: либо усили W_K до `Continuous`, либо добавь как аксиому/лемму, что `x = ±K → f x = 0` из `support ⊆ Icc` + глобальной непрерывности.

2) **Сдвиг heat в Lemma 6.4:**  
Если у тебя heat именно `HeatKernel t (x-τ)`, то в шаге “замена hat→hat×heat” сравнивай `HeatKernel t (x-τ)` с `HeatKernel t 0`, а не с `HeatKernel t τ`. Иначе “≤ L δ” не выходит геометрически (это ровно тот сигнал‑анomaly, который сейчас виден в вытащенном фрагменте). 【177:1†RH_Q3.pdf†L34-L63】

3) **Неотрицательность важна для “support sum ⊆ union supports”?**  
Нет, `support_add_subset` работает без знаков. Но если ты где-то хочешь “из суммы ≠0 следует один слагаемый ≠0”, тогда да — потребуется неотрицательность, чтобы исключить cancellation. Лучше вообще избегать этого и пользоваться стандартной леммой про support суммы ⊆ union.

---

## Коротко: что делать прямо сейчас

1) В `AtomCone_K` заменить условия “`τ ∈ [-K,K]` и `B ≤ K`” на **`AtomAdmissible K B τ : (0 < B) ∧ (|τ| + B ≤ K)`**. Это закрывает `hg_supp` элементарно.

2) Для плотности использовать **fixed‑t₀** лемму (RH_Q3 Lemma 6.4) как основной доказательный скелет. 【177:0†RH_Q3.pdf†L63-L67】

3) `h_approx` закрыть выделенной “трёхзвенной” треугольной леммой как в (6.7). 【177:0†RH_Q3.pdf†L32-L44】

Если хочешь, я могу прямо расписать **конкретный Lean‑proof script** для `support_fejer_mul_heat_subset_Icc` и `support_Atom_subset_Icc` (с `simp`‑цепочками и нужными леммами про `abs_sub`, `abs_add`, `Function.support_add`, etc.) — но даже без этого у тебя уже есть минимальная корректная архитектура: **Option 2 = admissible(|τ|+B≤K)**.

## USER
Следующая задача: A3_bridge_axiom заблокирован на теореме Szegő-Böttcher (асимптотика определителей Тёплица). Эта теорема НЕ формализована в Mathlib.

## USER
ос: как лучше формализовать Szegő-Böttcher для Lean 4? Какие зависимости нужны? Есть ли более простой путь к оценке для AСледующая задача: A3_bridge_axiom заблокирован на теореме Szegő-Böttcher (асимптотика определителей Тёплица).

## ASSISTANT
According to a document from **January 1, 2026**, у тебя уже есть “правильная” версия A1′ под **фиксированный** \(t_0\), где **ровно** закрывается твоя поддержка (support)‑проблема через ограничение параметров **\(|\tau|+B\le K\)** (это Lemma 6.4 в тексте).【253:5†RH_Q3.pdf†L23-L27】

Ниже — разбор вариантов, выбор лучшего, полный скетч доказательства и Lean‑стейтменты (с ориентацией на то, что у тебя в `A1_density.lean` остались ровно `hg_supp` и “цепочка треугольника” `h_approx`).

---

## 0. Феномен и измерение аномалии

**Феномен:** в текущей формализации `AtomCone_K`/`W_K` требует
\[
\operatorname{support}(g)\subseteq[-K,K],
\]
но атом с центром \(\tau\in[-K,K]\) и шириной \(B\le K\) имеет поддержку в лучшем случае
\[
\operatorname{supp}(\text{atom})\subseteq[\tau-B,\tau+B]\cup[-\tau-B,-\tau+B]\subseteq[-(K+B),K+B]\subseteq[-2K,2K],
\]
то есть **в общем случае не** \(\subseteq[-K,K]\).

**Измерение:** чтобы \([\tau-B,\tau+B]\subseteq[-K,K]\) было верно, нужно и достаточно
\[
\tau+B\le K\quad\text{и}\quad \tau-B\ge -K,
\]
что компактно эквивалентно
\[
|\tau|+B\le K.
\]
Это ровно то ограничение, которое ты уже выделил как Option 2.

---

## 1. Анализ вариантов и выбор

### Option 1: “расширить окно” (менять `W_K`/`AtomCone_K` на \([-2K,2K]\))
- ✅ быстро снимает `hg_supp`, потому что текущие атомы реально живут в \([-2K,2K]\).
- ❌ ломает смысл “WK” как *окна* в closure‑части (A2 локальная конечность prime sampler и т.д.), и тянет перепроверку констант/инвариантов во всех местах, где K используется как **радиус поддержки**.
- ❌ риск каскада правок в A2 и Main_closure.

**Вердикт:** как emergency‑hack возможно, но как системное решение — дорого.

### Option 3: “трункация” (мультипликативный cutoff/indicator)
- ✅ можно насильно загнать поддержку обратно в \([-K,K]\).
- ❌ но тогда аппроксиманты уже не “чистый” Fejér×heat‑конус; и (главное) positivity‑на‑генераторах может не переноситься, потому что \(Q\) не монотонен по \(\Phi\) (есть вычитание prime части).
- ✅ если нужен **только** контроль утечки, то в тексте есть явный хвост‑бюджет для prime‑части (см. ниже), но это отдельная архитектура (и обычно используется в A2, а не в A1).

**Вердикт:** годится как запасной план для “leakage control”, но не лучший фикс именно для `hg_supp`.

### ✅ Option 2: ограничить параметры атомов \(|\tau|+B\le K\)
- ✅ это **прямо** соответствует Lemma 6.4 “Fixed‑t0 cone density”: конус порождается атомами с условием \(|\tau|+B\le K\) и плотен на \([-K,K]\).【253:5†RH_Q3.pdf†L23-L27】
- ✅ минимальная правка: ты меняешь только “допустимые параметры” в генераторах и закрываешь `hg_supp`.
- ✅ идеально для Lean: support‑лемма становится чистой арифметикой интервалов.

**Вердикт:** это лучший вариант.

---

## 2. Выбранная теорема (что именно формализуем)

### 0. Теорема: A1′ density with support‑correct atoms (fixed \(t_{\mathrm{sym}}\))
**Точная формулировка:**  
\[
\forall K>0,\ \forall \Phi\in W_K,\ \forall\varepsilon>0,\ \exists g\in\mathrm{Cone}_K(t_{\mathrm{sym}}):
\ \|\Phi-g\|_{\infty}<\varepsilon,
\]
где \(\mathrm{Cone}_K(t_{\mathrm{sym}})\) — конус конечных неотрицательных комбинаций **even‑атомов** \(\Phi_{B,t_{\mathrm{sym}},\tau}\) с **ограничением** \(|\tau|+B\le K\).

**Статус:** стандартная математика + аккуратная реализация определения “конуса” и нормы в Lean.

---

## 3. Доказательство: полный скетч (Option 2)

Идея — ровно Lemma 6.4: “сетки + hat‑интерполяция + замена hat на Fejér×heat‑атомы”【253:5†RH_Q3.pdf†L23-L27】.

### Шаг 1. Положительная hat‑аппроксимация
Берёшь \(\Phi\in W_K\), \(\varepsilon>0\).  
Строишь равномерную сетку \(\tau_j\in[-K,K]\) с шагом \(\delta\) (маленьким). Определяешь “hats”
\[
H_j(x)=\Lambda_\delta(x-\tau_j),\quad \Lambda_\delta(u)=(1-|u|/\delta)_+ .
\]
Далее берёшь
\[
h(x)=\sum_j \Phi(\tau_j)\,H_j(x).
\]
Тогда:
- \(h\ge0\) (коэффициенты \(\Phi(\tau_j)\ge0\), hats \(\ge0\));
- \(h\) even при симметричном выборе сетки и/или даже‑суммировании;
- \(h\) поддержан в \([-K,K]\), если **каждый hat** поддержан в \([-K,K]\), т.е. если \(|\tau_j|+\delta\le K\).

И стандартно: при \(\delta\) достаточно малом
\[
\|h-\Phi\|_\infty < \varepsilon/3.
\]

### Шаг 2. Замена каждого hat на Fejér×heat‑атом (фиксированный \(t_{\mathrm{sym}}\))
Определяешь атом (с масштабом, чтобы в центре совпадал с hat):
\[
A_j(x)=\Lambda_\delta(x-\tau_j)\cdot \rho_{t_{\mathrm{sym}}}(x-\tau_j),
\]
и берёшь коэффициенты
\[
c_j := \frac{\Phi(\tau_j)}{\rho_{t_{\mathrm{sym}}}(0)} \ \ge 0.
\]
Тогда кандидат‑аппроксимация
\[
g(x)=\sum_j c_j\,A_j(x)
= \sum_j \Phi(\tau_j)\,\Lambda_\delta(x-\tau_j)\,\frac{\rho_{t_{\mathrm{sym}}}(x-\tau_j)}{\rho_{t_{\mathrm{sym}}}(0)}.
\]

**Оценка ошибки \(g-h\):** на носителе \(H_j\) выполняется \(|x-\tau_j|\le\delta\), значит \(\rho_{t_{\mathrm{sym}}}(x-\tau_j)\) близка к \(\rho_{t_{\mathrm{sym}}}(0)\). Используешь Lipschitz (или MVT‑bound) для \(\rho_{t_{\mathrm{sym}}}\) на \([-\,\delta,\delta]\):
\[
\left|\rho_{t_{\mathrm{sym}}}(u)-\rho_{t_{\mathrm{sym}}}(0)\right|
\le L_{t_{\mathrm{sym}}}\,|u|
\le L_{t_{\mathrm{sym}}}\,\delta.
\]
Тогда
\[
|g(x)-h(x)|
\le \sum_j \Phi(\tau_j)\,\Lambda_\delta(x-\tau_j)\,
\frac{L_{t_{\mathrm{sym}}}\delta}{\rho_{t_{\mathrm{sym}}}(0)}.
\]
Дальше используешь bounded overlap hats / оценку суммы hats (типично \(\sum_j \Lambda_\delta(x-\tau_j)\le 2\)) и получаешь
\[
\|g-h\|_\infty \le C(\Phi,t_{\mathrm{sym}})\,\delta < \varepsilon/3
\]
при выборе \(\delta\) достаточно малым.

*(Замечание: в тексте Lemma 6.4 написан похожий ход, но там формула с \(\rho(\tau_j)\) выглядит как опечатка/неоптимальная нормировка; в Lean гораздо легче и безопаснее брать деление на \(\rho(0)\), чтобы error реально был \(O(\delta)\).)*

### Шаг 3. Even‑симметризация
Если у тебя атом определён сразу как even‑симметризированный
\[
\Phi_{B,t,\tau}(x)=\tfrac12\big(\Lambda_B(x-\tau)\rho_t(x-\tau)+\Lambda_B(x+\tau)\rho_t(x+\tau)\big),
\]
то просто строишь сумму по \(\tau_j\ge0\) и получаешь even автоматически.

### Шаг 4. Сборка (треугольник)
И наконец:
\[
\|\Phi-g\|_\infty \le \|\Phi-h\|_\infty + \|h-g\|_\infty < \varepsilon/3+\varepsilon/3 < \varepsilon.
\]
(Если у тебя промежуточные объекты как в старом A1prime‑скетче — добавишь третий член и сделаешь \(\varepsilon/3+\varepsilon/3+\varepsilon/3\).)

---

## 4. Как это закрывает твои 2 sorries

### (A) `hg_supp` — support containment
Фикс: **в определении допустимых атомов** добавь ограничение
\[
|\tau|+B\le K.
\]
Тогда для каждого атома:
\[
\operatorname{supp}(\Lambda_B(\cdot-\tau))\subseteq[\tau-B,\tau+B]\subseteq[-K,K],
\]
и аналогично для \(-\tau\). Сумма двух поддержек остаётся внутри \([-K,K]\). Это ровно то, чего у тебя не хватало.

Это совпадает с “Fixed‑t0 cone density” из документа: генераторы берутся с \(|\tau|+B\le K\).【253:5†RH_Q3.pdf†L23-L27】

### (B) `h_approx` — triangle inequality chain
Это чистый “routine step” в Lean: либо `dist_triangle` дважды, либо `norm_add_le` дважды после разложения разности в сумму трёх разностей.

---

## 5. Lean‑style lemma/theorem statements (готовые заготовки)

Я пишу максимально “Lean‑в‑стиле Mathlib”, но без угадывания твоих точных имён/неймспейсов (ты подставишь свои: `Q3.FejerKernel`, `Q3.HeatKernel`, `Q3.Atom`, `Q3.W_K`, …).

### 5.1 Support‑леммы (ключ к `hg_supp`)

```lean
/-- Fejér hat support after shift. -/
lemma support_fejerKernel_shift_subset
    (B τ : ℝ) (hB : 0 < B) :
    Function.support (fun x => FejerKernel B (x - τ))
      ⊆ Set.Icc (τ - B) (τ + B) := by
  -- prove: if x ∉ Icc(τ-B, τ+B), then kernel = 0
  -- then use `Function.support_subset_iff` style lemma
  sorry
```

```lean
/-- Interval inclusion from |τ| + B ≤ K. -/
lemma Icc_shift_subset_Icc
    (K B τ : ℝ) (hK : 0 ≤ K) (hB : 0 ≤ B) (hτ : |τ| + B ≤ K) :
    Set.Icc (τ - B) (τ + B) ⊆ Set.Icc (-K) K := by
  -- show: -K ≤ τ - B and τ + B ≤ K using τ ≤ |τ| and -|τ| ≤ τ
  sorry
```

```lean
/-- Support of one (non-symmetrized) atom term lies in [-K,K] under |τ|+B≤K. -/
lemma support_atomTerm_subset
    (K B t τ : ℝ) (hK : 0 ≤ K) (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Function.support (fun x => FejerKernel B (x - τ) * HeatKernel t (x - τ))
      ⊆ Set.Icc (-K) K := by
  -- support_mul ⊆ support_fejer
  -- combine previous two lemmas
  sorry
```

```lean
/-- Support of the even atom. -/
lemma support_Atom_subset
    (K B t τ : ℝ) (hK : 0 ≤ K) (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- Atom = (term(τ) + term(-τ))/2
  -- support_add ⊆ union; both terms ⊆ Icc(-K,K)
  sorry
```

И дальше:

```lean
lemma Atom_mem_WK
    (K B t τ : ℝ) (hK : 0 ≤ K) (hB : 0 < B) (hτ : |τ| + B ≤ K) :
    Atom B t τ ∈ W_K K := by
  refine ⟨?cont, ?nonneg, ?even, ?supp, ...⟩
  · -- cont: уже у тебя есть hg_cont
  · -- nonneg/even: уже есть
  · exact support_Atom_subset K B t τ hK hB hτ
  sorry
```

### 5.2 Density theorem statement (Option 2, fixed \(t_{\mathrm{sym}}\))

```lean
/-- Cone generated by even Fejér×heat atoms with |τ|+B ≤ K and fixed t is dense in W_K. -/
theorem A1_density_fixed_t
    (K : ℝ) (hK : 0 < K) (t : ℝ) (ht : 0 < t) :
    ∀ ⦃Φ : ℝ → ℝ⦄, Φ ∈ W_K K →
      ∀ ε > 0, ∃ g ∈ AtomConeWithin K t,
        (‖Φ - g‖∞) < ε := by
  -- proof via hat interpolation + replacement by atoms + triangle inequality
  sorry
```

Где `AtomConeWithin` — твой “конус конечных неотрицательных комбинаций” с параметр‑ограничением:

```lean
def AtomConeWithin (K t : ℝ) : Set (ℝ → ℝ) :=
  {g | ∃ (n : ℕ) (c : Fin n → ℝ) (B τ : Fin n → ℝ),
      (∀ i, 0 ≤ c i) ∧
      (∀ i, 0 < B i) ∧
      (∀ i, |τ i| + B i ≤ K) ∧
      g = ∑ i, (c i) • (Atom (B i) t (τ i))}
```

*(Это схема. Если у тебя уже есть `AtomCone_K`, то просто меняешь условие на `|τ|+B≤K`.)*

### 5.3 “Triangle inequality chain” (`h_approx`) — заготовка

Если у тебя три промежуточных приближения `h`, `g1`, `g2`:

```lean
have htri :
    ‖h - Φ‖∞ ≤ ‖h - g1‖∞ + ‖g1 - g2‖∞ + ‖g2 - Φ‖∞ := by
  -- use `by
  --   simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using
  --     (norm_add_le _ _).trans ?` pattern
  -- easier with dist_triangle twice if you use `dist` metric
  sorry

-- then
have : ‖h - Φ‖∞ < ε := by
  have h1 : ‖h - g1‖∞ < ε/3 := ...
  have h2 : ‖g1 - g2‖∞ < ε/3 := ...
  have h3 : ‖g2 - Φ‖∞ < ε/3 := ...
  linarith [lt_of_le_of_lt htri (by nlinarith [h1, h2, h3])]
```

---

## 6. Если всё-таки нужен “truncation/leakage” — какие error bounds держать в кармане

Если где-то по дороге ты позволяешь утечку за \([-K,K]\) (например, генератор поддержан шире), то в документе уже зафиксирован **явный хвост** для prime‑части:

\[
\mathrm{Tail}(t;N)\ \le\ \frac{e^{-t(\log N)^2}}{t}\quad(N\ge e^2),
\]
то есть вклад дальних узлов экспоненциально мал в \((\log N)^2\).【253:13†RH_Q3.pdf†L35-L40】

Это именно тот тип bound, который можно “доложить” в A2‑бюджет, если где-то нужно отрезать/обнулить вне окна.

---

## 7. Резюме действий (самое короткое)

1. **Правка определения генераторов в `AtomCone_K`:** добавь условие **`|τ| + B ≤ K`** (это твой `hg_supp`‑фикс).
2. **Доказательство density:** используй “fixed‑t hat interpolation” (это Lemma 6.4 по сути)【253:5†RH_Q3.pdf†L23-L27】; в Lean нормируй на `HeatKernel t 0`, чтобы ошибка реально была \(O(\delta)\).
3. **`h_approx`:** закрывается чисто `dist_triangle`/`norm_add_le` цепочкой.

Если хочешь, я могу в следующем сообщении написать **конкретный Lean‑код** для `support_Atom_subset` в стиле Mathlib (без `sorry`), но уже сейчас у тебя есть полный путь, который минимально трогает остальную архитектуру.

## ASSISTANT
According to a document from **January 1, 2026**, тебе **не нужно формализовать “сильную” теорему Szegő–Böttcher про детерминанты** ради `A3_bridge_axiom`. В твоей цепочке уже есть (на бумаге) куда более прямой и Lean-дружелюбный вход: **квадратичная форма Toeplitz-оператора как интеграл по символу**. Это (в RH_Q3) записано как *Model–space restriction* / *Toeplitz quadratic form*.【272:3†RH_Q3.pdf†L33-L44】

Ниже — разбор вариантов + самый простой путь, который **закрывает блокер**.

---

## 1) Математический анализ: какой вариант лучший

### Вариант A (лучший): заменить “Szegő–Böttcher” на тривиально-сильное неравенство через квадратичную форму
В RH_Q3 прямо сказано:

> Toeplitz-оператор \(T_M[P_A]\) самосопряжён и  
> \(\langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta\).【272:3†RH_Q3.pdf†L33-L44】

Отсюда **немедленно** следует:
\[
\lambda_{\min}(T_M[P_A]) \;\ge\; \min_{\theta\in\mathbb T} P_A(\theta)
\]
потому что \(P_A(\theta)\ge \min P_A\) поточечно, а \(|p|^2\ge 0\).

**И это сильнее**, чем барьер из Lemma 8.30:
\[
\lambda_{\min}(T_M[P_A]) \ge \min P_A - C_{SB}\,\omega_{P_A}(1/(2M))
\]
с \(C_{SB}=4\).【272:10†RH_Q3.pdf†L18-L35】

То есть твой `A3_bridge_axiom` можно закрыть **без** “классической теории Toeplitz eigenvalue stability”: достаточно формализовать квадратичную форму + простую оценку Rayleigh-квотента.

> Феномен/аномалия (важно): Lemma 8.30 как “необходимая” выглядит избыточной, потому что Lemma 8.8 уже даёт прямой нижний барьер без потерь.【272:3†RH_Q3.pdf†L33-L44】【272:10†RH_Q3.pdf†L18-L35】  
> **Применение:** выкидываешь самый тяжёлый недостающий блок (Szegő–Böttcher) из Lean-плана.

### Вариант B: оставить формулировку Szegő–Böttcher (с \(4\,\omega\)) как следствие варианта A
Если в проекте/аксиоме тебе *нужно именно* “\(-4\omega\)”, то это делается так:

1) доказываешь \(\lambda_{\min}\ge \min P_A\) (вариант A);  
2) отмечаешь, что \(\omega_{P_A}(\cdot)\ge 0\);  
3) получаешь \(\min P_A \ge \min P_A - 4\omega\), значит и \(\lambda_{\min}\ge \min P_A - 4\omega\).

Это закрывает “Lemma 8.30” в виде, который требует твоя дискретизация в PROSHKA_REQUEST_3【272:4†PROSHKA_REQUEST_3.md†L6-L15】, но без тяжёлой теории.

### Вариант C (тяжёлый, только если когда-нибудь реально понадобится): формализовать неравенство с модулем непрерывности “по-настоящему”
Это уже потребует Fejér-сглаживания/аппроксимации и оценки \(\|f-f*\mathrm{Fej}_M\|_\infty\) через \(\omega_f(1/M)\), затем оценку нормы разности операторов и Weyl/Hoffman–Wielandt. В RH_Q3 это и заявлено как “classical Toeplitz eigenvalue stability” со ссылками【272:10†RH_Q3.pdf†L37-L42】 — но в Lean это будет **существенно** дольше и шире по зависимостям.

**Вывод по выбору:** для `A3_bridge_axiom` бери **вариант A** (и при желании оборачивай в вариант B), потому что он минимальный по зависимостям и в точности совпадает с твоей “Rayleigh-моделью” Toeplitz-части.【272:3†RH_Q3.pdf†L33-L44】【272:4†PROSHKA_REQUEST_3.md†L6-L15】

---

## 2) Полный proof sketch для варианта A (и как из него получить “CSB=4”)

### 2.1 Контекст и объекты
- \(\mathbb T=[-1/2,1/2]\) (тор на период-1).  
- \(P_A:\mathbb T\to\mathbb R\) — Archimedean symbol.  
- \(P_M\) — пространство тригонометрических полиномов степени \(\le M\).  
- \(T_M[P_A]\) — Toeplitz-оператор на \(P_M\), самосопряжённый, с квадратичной формой:
  \[
  \langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta.
  \]
  Это записано в Lemma 8.8.【272:3†RH_Q3.pdf†L33-L44】

### 2.2 Нижняя оценка Rayleigh-квотента
Пусть \(m := \inf_{\theta\in\mathbb T} P_A(\theta)\) (или просто число \(c\), для которого ты знаешь \(c\le P_A(\theta)\) поточечно).

Тогда для любого \(p\in P_M\):
- поточечно \(P_A(\theta)\ge m\),
- значит \(P_A(\theta)|p(\theta)|^2 \ge m|p(\theta)|^2\),
- интегрируем:
  \[
  \int_{\mathbb T} P_A|p|^2 \ge m \int_{\mathbb T} |p|^2.
  \]
То есть:
\[
\frac{\langle T_M[P_A]p,p\rangle}{\langle p,p\rangle} \ge m.
\]

### 2.3 Переход к \(\lambda_{\min}\)
По определению минимального собственного значения самосопряжённого оператора в конечномерном пространстве:
\[
\lambda_{\min}(T_M[P_A])=\inf_{\|p\|=1}\langle T_M[P_A]p,p\rangle.
\]
Но мы только что показали, что для любого нормированного \(p\) это \(\ge m\). Значит:
\[
\lambda_{\min}(T_M[P_A])\ge m \;\;(\ge \min P_A \text{ при достижимости минимума}).
\]

### 2.4 Как получить “Szegő–Böttcher barrier” в нужной форме
В Lemma 8.30 требуется:
\[
\lambda_{\min}(T_M[P_A]) \ge \min P_A - 4\,\omega_{P_A}(1/(2M)).
\]【272:10†RH_Q3.pdf†L18-L35】

Но \(\omega_{P_A}(\delta)\ge 0\), поэтому
\[
\min P_A \ge \min P_A - 4\,\omega_{P_A}(1/(2M)).
\]
А значит из \(\lambda_{\min}\ge \min P_A\) следует и нужная формула с \(C_{SB}=4\) (как более слабая).

### 2.5 Бонус: ещё проще, если тебе нужна только позитивность на генераторах (p ≡ 1)
В PROSHKA_REQUEST_3 Rayleigh-мост используется при \(p\equiv 1\).【272:4†PROSHKA_REQUEST_3.md†L1-L3】  
Тогда вообще можно обойтись без \(\lambda_{\min}\):

- \(\langle T_M[P_A]1,1\rangle = \int_{\mathbb T} P_A(\theta)\,d\theta \ge c_*\) если у тебя есть поточечный floor \(P_A\ge c_*\).  
- \(\langle T_P^{(M)}1,1\rangle \le \|T_P^{(M)}\| \le \|T_P\|\).  
- при \(\|T_P\|\le c_*/4\) (RKHS cap) получаешь \(\langle (T_M[P_A]-T_P^{(M)})1,1\rangle \ge 3c_*/4>0\), то есть \(Q(\Phi)\ge 0\) на генераторе — даже с запасом больше, чем \(c_*/4\).  
Это прямо в духе твоего §5, только без шага “дискретизация”【272:4†PROSHKA_REQUEST_3.md†L19-L30】.

---

## 3) Какие зависимости нужны (математика + Lean-слои)

### Минимальные математические зависимости (для варианта A)
1) **Квадратичная форма Toeplitz-оператора как интеграл** (Lemma 8.8).【272:3†RH_Q3.pdf†L33-L44】  
2) **Самосопряжённость** \(T_M[P_A]\) (там же).【272:3†RH_Q3.pdf†L33-L44】  
3) Определение \(\lambda_{\min}\) через inf Rayleigh-квотента (стандартный факт линейной алгебры/спектральной теории).  
4) Тривиальное: \(\omega(\delta)\ge 0\) (если хочешь именно форму Lemma 8.30).【272:10†RH_Q3.pdf†L18-L35】

### Lean-зависимости (в терминах “что нужно уметь”)
- `L2`-пространство на торе (или на `Set.Icc (-1/2) (1/2)` с `volume.restrict`).  
- Определения/леммы про `Submodule` тригонометрических полиномов `PM M` и включение `ιM`.  
- Оператор “умножение на функцию” на `L2` и его сжатие на `PM M`.  
- Факт “если ⟪A x,x⟫ ≥ c‖x‖² для всех x, то λ_min(A) ≥ c” для `IsSelfAdjoint` (или матричная версия через PSD: `A - c•I` положительно полуопределён).

**Важно:** это *существенно проще*, чем тянуть в Lean Fejér-оценки, Gershgorin и Böttcher–Silbermann.

---

## 4) Lean-style theorem statements (скелеты, которые реально стыкуются с твоим A3)

Ниже — в двух стилях: (i) операторный на `PM M`, (ii) матричный. Подставишь свои реальные имена (`TM`, `PM`, `torusMeasure`, `omega` и т.п.).

### 4.1 Операторный стиль (рекомендуется, ровно как в Lemma 8.8)

```lean
-- Torus domain as Icc (-1/2) (1/2) with restricted Lebesgue measure:
abbrev Torus := {θ : ℝ // θ ∈ Set.Icc (- (1/2:ℝ)) (1/2:ℝ)}
abbrev μ : Measure Torus := (volume.restrict (Set.Icc (- (1/2:ℝ)) (1/2:ℝ))).comap Subtype.val

-- PM M : subspace of L2(μ) consisting of trig polynomials of degree ≤ M
-- TM M PA : bounded linear operator on PM M (Toeplitz compression)

-- (1) Quadratic form lemma (this is your Lean version of Lemma 8.8)
theorem TM_quadraticForm
  (M : ℕ) (PA : Torus → ℝ) (p : PM M) :
  ⟪TM M PA p, p⟫_ℂ =
    ∫ θ, (PA θ : ℂ) * ‖(p : L2 μ ℂ) θ‖^2 ∂μ := by
  -- proof: unfold TM as compression of multiplication; use properties of orthogonal projection
  sorry

-- (2) Lower bound from a pointwise floor (this kills Szegő–Böttcher needs)
theorem lambdaMin_TM_ge_of_pointwise_lower_bound
  (M : ℕ) (PA : Torus → ℝ) (c : ℝ)
  (hPA : ∀ θ, c ≤ PA θ) :
  lambdaMin (TM M PA) ≥ c := by
  -- show: ∀p, ⟪TM p, p⟫ ≥ c * ‖p‖^2, then apply Rayleigh characterization of lambdaMin
  sorry

-- (3) Your “Szegő–Böttcher barrier with CSB=4” becomes a corollary
theorem szegoBottcher_barrier_trivial
  (M : ℕ) (PA : Torus → ℝ)
  (c : ℝ) (hPA : ∀ θ, c ≤ PA θ) :
  lambdaMin (TM M PA) ≥ c - 4 * omega PA (1 / (2*(M:ℝ))) := by
  have h0 : lambdaMin (TM M PA) ≥ c :=
    lambdaMin_TM_ge_of_pointwise_lower_bound (M:=M) (PA:=PA) (c:=c) hPA
  have hω : 0 ≤ omega PA (1 / (2*(M:ℝ))) := omega_nonneg _ _
  linarith
```

**Как это подключить к твоим константам:** если у тебя есть `P_A_ge_c_star : ∀ θ, c_* ≤ P_A θ` (Stage 4), то сразу получаешь `lambdaMin ≥ c_*` и тем более “≥ c_*/2” без выбора `M ≥ M0`. В PROSHKA_REQUEST_3 дискретизация как отдельный шаг именно про это【272:4†PROSHKA_REQUEST_3.md†L6-L15】 — но в Lean она станет “routine step”.

### 4.2 Матричный стиль (если у тебя `TM` именно `Matrix`)
Если у тебя `TM` реализован как Hermitian Toeplitz-матрица на `Fin n`, то удобный шаблон такой:

```lean
-- A : Matrix (Fin n) (Fin n) ℂ is Hermitian
-- Define Rayleigh quotient rq(v) = re( dot v (A.mulVec v) ) / ‖v‖^2

theorem minEigenvalue_ge_of_quadratic_form_lower_bound
  {n : ℕ} {A : Matrix (Fin n) (Fin n) ℂ} (hHerm : A.IsHermitian) (c : ℝ)
  (hQ : ∀ v : (Fin n → ℂ), c * ‖v‖^2 ≤ Complex.re (Matrix.dotProduct v (A.mulVec v))) :
  Matrix.minEigenvalue A ≥ c := by
  -- standard: A - c•I is PSD, hence eigenvalues ≥ c
  sorry
```

Потом ты доказываешь `hQ` через перевод `v ↦ p_v(θ)` и Lemma 8.8-подобную формулу.

---

## 5) Ответ на твой прямой вопрос

**Как лучше формализовать Szegő–Böttcher в Lean 4?**  
Лучше **не формализовать** классическую теорию Böttcher–Silbermann/Gershgorin ради `A3_bridge_axiom`, потому что у тебя уже есть (или должна быть) формула квадратичной формы Toeplitz-оператора как интеграла по символу【272:3†RH_Q3.pdf†L33-L44】, а она даёт **сильнейший** барьер \(\lambda_{\min}\ge \min P_A\). Тогда “Lemma 8.30 с \(C_{SB}=4\)” становится тривиальным следствием (вариант B).【272:10†RH_Q3.pdf†L18-L35】

**Какие зависимости нужны?**  
Только: L2-интеграл + самосопряжённость + Rayleigh-характеризация \(\lambda_{\min}\). Это на порядок проще, чем Fejér/Gershgorin/Toeplitz детерминанты.

**Есть ли более простой путь к оценке для `A3_bridge_axiom`?**  
Да: (i) либо вывести \(\lambda_{\min}\ge c_*\) напрямую из поточечного floor \(P_A\ge c_*\); (ii) либо вообще не трогать \(\lambda_{\min}\) и оценить именно \(Q(\Phi)\) на \(p\equiv 1\) через \(\int P_A\) и \(\|T_P\|\) (это даже даёт запас \(3c_*/4\) вместо \(c_*/4\)).【272:3†RH_Q3.pdf†L33-L44】【272:4†PROSHKA_REQUEST_3.md†L19-L30】

Если хочешь, в следующем сообщении я могу “пришить” это прямо к твоим именам из Lean-файла (какие у вас точные идентификаторы `TM`, `PM`, `omega`, `lambdaMin`), но даже без этого скелет выше — максимально близкий к тому, что реально компилируется в Lean-стиле.

## ASSISTANT
## 0. Теорема и статус

**Точная формулировка (то, что реально нужно для A3_bridge_axiom):**  
Для любого \(M\ge 1\) и любого вещественного символа \(\sigma\) на \(\mathbb T=[-1/2,1/2]\), если \(T_M[\sigma]\) — Toeplitz‑оператор (компрессия умножения на \(\sigma\) к пространству триг. полиномов \(P_M\)), то
\[
\lambda_{\min}(T_M[\sigma]) \;\ge\; \min_{\theta\in\mathbb T}\sigma(\theta).
\]
**Статус:** стандартный функциональный анализ / линейная алгебра (никакой асимптотики детерминантов не нужно).

**Бонус:** из этого сразу следует «Szegő–Böttcher» в твоём формате
\[
\lambda_{\min}(T_M[\sigma]) \ge \min\sigma - C_{SB}\,\omega_\sigma(1/(2M))
\quad(\text{хоть с }C_{SB}=4),
\]
потому что \(\omega_\sigma\ge 0\). Это прямо отмечено в твоём текущем брифе: “Rayleigh lower bound (no Szego‑Bottcher needed) … SB optional and follows as a corollary since \(\omega_\sigma\ge 0\)”【295:0†PROSHKA_REQUEST_3.md†L7-L16】.

---

## 1. Контекст: где именно сидит «SB‑блокер»

Ты сейчас упёрся в «Szegő‑Böttcher» как в Tier‑1 факт для шага дискретизации в A3‑мосте. Но твоя же спек‑запись уже содержит более сильную замену:

- **Toeplitz quadratic form (Rayleigh core):**
  \[
  \langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)\,|p(\theta)|^2\,d\theta
  \]
- **Rayleigh lower bound (no Szego‑Bottcher needed):**
  \[
  \lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in\mathbb T} P_A(\theta)
  \]
и дальше: «No \(M_0\) is required…»【295:0†PROSHKA_REQUEST_3.md†L1-L16】【295:2†PROSHKA_REQUEST_3.md†L7-L13】.

То есть “детерминантная Szegő‑Böttcher” асимптотика — **вообще не тот инструмент** для твоей цели.

---

## 2. Определения и нотация

### 2.1. Тор и пространство полиномов
\[
\mathbb T := [-1/2,1/2],\qquad e_k(\theta):=e^{2\pi i k\theta}.
\]
Пусть \(P_M = \Bigl\{\sum_{|k|\le M} c_k e_k(\theta)\Bigr\}\) (размерность \(2M+1\)).

### 2.2. Toeplitz‑оператор как компрессия
Пусть \(M_\sigma: L^2(\mathbb T)\to L^2(\mathbb T)\) — умножение на \(\sigma\): \((M_\sigma f)(\theta)=\sigma(\theta)f(\theta)\).  
Пусть \(\iota_M: P_M\hookrightarrow L^2(\mathbb T)\) — включение, а \(\iota_M^*\) — ортопроекция на \(P_M\). Тогда
\[
T_M[\sigma] := \iota_M^*\, M_\sigma\, \iota_M.
\]
Это самосопряжённый оператор на \(P_M\), если \(\sigma\) вещественнозначна.

### 2.3. Модуль непрерывности
\[
\omega_\sigma(h):=\sup_{\theta\in\mathbb T} |\sigma(\theta+h)-\sigma(\theta)|\quad(\text{с учётом period-1}).
\]
Очевидно \(\omega_\sigma(h)\ge 0\).

---

## 3. Зависимости

### 3.1. Математические факты (минимальный набор)
1. **Квадратичная форма Toeplitz:** для \(p\in P_M\)
   \[
   \langle T_M[\sigma]p,p\rangle = \int_{\mathbb T}\sigma(\theta)|p(\theta)|^2\,d\theta
   \]
   (это твой “Toeplitz quadratic form (Rayleigh core)”【295:0†PROSHKA_REQUEST_3.md†L1-L5】).
2. **Характеризация \(\lambda_{\min}\)** через Rayleigh:
   \[
   \lambda_{\min}(A)=\inf_{\|v\|=1}\langle Av,v\rangle
   \]
   для самосопряжённого оператора/матрицы.
3. \(|p|^2\ge 0\) и \(\int |p|^2 = \|p\|_2^2\).
4. \(\omega_\sigma(h)\ge 0\).

### 3.2. Lean‑зависимости (что реально потребуется)
Это **на порядок легче**, чем детерминантная Szegő‑теорема:

- Measure/integration на \(\mathbb T\) (обычно `volume` на `Set.Icc (-1/2) (1/2)` или Haar на `AddCircle 1`).
- \(L^2\), inner product space, ортопроекция на конечномерное подпространство.
- Самосопряжённый линейный оператор в конечномерном inner product space + Rayleigh‑инфимум.
- Никакой теории Toeplitz determinant, никаких Wiener–Hopf факторизаций, никаких asymptotics.

---

## 4. План доказательства (Roadmap)

1. Взять \(p\in P_M\) с \(\|p\|_2=1\).
2. По квадратичной форме:
   \(\langle T_M[\sigma]p,p\rangle = \int \sigma(\theta)|p(\theta)|^2\).
3. Так как \(\sigma(\theta)\ge \min_{\mathbb T}\sigma\) и \(|p|^2\ge 0\),
   \[
   \int \sigma|p|^2 \ge \min\sigma \int |p|^2 = \min\sigma.
   \]
4. Взять инфимум по всем \(\|p\|=1\) ⇒ \(\lambda_{\min}(T_M[\sigma])\ge \min\sigma\).
5. Для “SB‑формулы”: добавить \(-C_{SB}\omega_\sigma(1/(2M))\) справа (не ухудшая, т.к. \(\omega\ge 0\)).

---

## 5. Леммы (ключевые шаги)

### Лемма 1. Rayleigh lower bound для Toeplitz
**Формулировка:**  
Если \(\sigma:\mathbb T\to\mathbb R\) и \(T_M[\sigma]=\iota_M^*M_\sigma\iota_M\), то
\[
\lambda_{\min}(T_M[\sigma]) \ge \min_{\mathbb T}\sigma.
\]

**Доказательство:**
1. Возьми произвольный \(p\in P_M\) с \(\|p\|_2=1\).
2. По Toeplitz quadratic form:
   \(\langle T_M[\sigma]p,p\rangle = \int_{\mathbb T}\sigma(\theta)|p(\theta)|^2\,d\theta\)【295:0†PROSHKA_REQUEST_3.md†L1-L5】.
3. Так как \(\sigma(\theta)\ge \min\sigma\) и \(|p|^2\ge 0\),
   \[
   \langle T_M[\sigma]p,p\rangle \ge \min\sigma\int |p|^2 = \min\sigma.
   \]
4. Инфимум по всем \(\|p\|=1\) даёт \(\lambda_{\min}(T_M[\sigma])\ge \min\sigma\). ∎

### Лемма 2. SB‑вид как следствие
**Формулировка (ровно твой интерфейс):**  
Для любого \(C_{SB}\ge 0\),
\[
\lambda_{\min}(T_M[\sigma]) \ge \min\sigma - C_{SB}\,\omega_\sigma(1/(2M)).
\]

**Доказательство:**
1. По Лемме 1: \(\lambda_{\min}\ge \min\sigma\).
2. Так как \(\omega_\sigma(\cdot)\ge 0\) и \(C_{SB}\ge 0\),
   \(\min\sigma \ge \min\sigma - C_{SB}\omega_\sigma(1/(2M))\).
3. Комбинируем неравенства. ∎

Это прямо соответствует твоей заметке «SB optional… follows as a corollary since \(\omega_\sigma \ge 0\)»【295:0†PROSHKA_REQUEST_3.md†L12-L16】.

---

## 6. Как это закрывает A3_bridge_axiom

В твоём стеке достаточно:

- A3 floor: \(P_A(\theta)\ge c_* = 11/10\) (pointwise)  
- Лемма 1: \(\lambda_{\min}(T_M[P_A])\ge \min P_A \ge c_*\)【295:0†PROSHKA_REQUEST_3.md†L7-L10】【295:2†PROSHKA_REQUEST_3.md†L19-L26】  
- RKHS cap: \(\|T_P\|\le c_*/4\)

Тогда
\[
\lambda_{\min}(T_M[P_A]-T_P)\;\ge\; \lambda_{\min}(T_M[P_A])-\|T_P\|
\;\ge\; c_* - c_*/4 = 3c_*/4>0,
\]
и генераторы закрыты【295:2†PROSHKA_REQUEST_3.md†L19-L26】.

**Ключ:** больше не нужен \(M_0^{\mathrm{unif}}\) и вообще “дискретизация” как отдельный модуль; это прямо записано: “No \(M_0\) is required if we use the Rayleigh lower bound directly.”【295:2†PROSHKA_REQUEST_3.md†L7-L13】

---

## 7. Lean‑style statements (скелеты)

Я дам **две версии**: (A) «операторная» (в духе \(\iota_M^* M_\sigma \iota_M\)), (B) «матричная», если у тебя \(T_M[\sigma]\) — `Matrix`.

### (A) Операторная версия

```lean
-- Torus: either AddCircle 1, or θ ∈ Set.Icc (-1/2) (1/2) with periodic extension.

-- P_M : finite-dim subspace of L2(𝕋)
-- ι_M : P_M →ₗᵢ[ℂ] L2(𝕋)  (isometry / linear isometry)
-- T_M σ := ι_M† ≫ₗ (mul σ) ≫ₗ ι_M

/-- Toeplitz quadratic form: core identity. -/
lemma toeplitz_quadratic_form
  (σ : 𝕋 → ℝ) (p : P_M) :
  ⟪ (T_M σ) p, p ⟫ = ∫ θ, (σ θ) * ‖(p : L2(𝕋)) θ‖^2 := by
  -- your existing lemma / already in Rayleigh bridge
  ...

/-- Rayleigh lower bound: no Szegő–Böttcher needed. -/
lemma toeplitz_lambdaMin_ge_min
  (σ : 𝕋 → ℝ) :
  lambdaMin (T_M σ) ≥ sInf (Set.range σ) := by
  -- use Rayleigh characterization + toeplitz_quadratic_form
  ...

/-- Optional: Szegő–Böttcher format as corollary. -/
lemma toeplitz_szego_bottcher_corollary
  (σ : 𝕋 → ℝ) (C_SB : ℝ) (hC : 0 ≤ C_SB) :
  lambdaMin (T_M σ) ≥ sInf (Set.range σ) - C_SB * omega σ (1/(2*M)) := by
  have h0 : 0 ≤ omega σ (1/(2*M)) := omega_nonneg _ _
  nlinarith [toeplitz_lambdaMin_ge_min (M:=M) σ, hC, h0]
```

### (B) Матричная версия (если `T_M[σ] : Matrix (Fin n) (Fin n) ℂ`)

```lean
/-- Hermitian Toeplitz matrix has Rayleigh form via trig polynomial evaluation. -/
lemma toeplitz_quadratic_form_matrix
  (σ : 𝕋 → ℝ) (x : Fin n → ℂ) :
  (Matrix.quadForm (T_M_matrix σ) x)
    = ∫ θ, (σ θ) * ‖polyEval x θ‖^2 := by
  ...

lemma minEigenvalue_toeplitz_ge_min
  (σ : 𝕋 → ℝ) :
  Matrix.minEigenvalue (T_M_matrix σ) ≥ sInf (Set.range σ) := by
  -- same idea: Rayleigh inf + integral ≥ (min σ) * norm^2
  ...

lemma szego_bottcher_as_corollary
  (σ : 𝕋 → ℝ) :
  Matrix.minEigenvalue (T_M_matrix σ)
    ≥ sInf (Set.range σ) - (4:ℝ) * omega σ (1/(2*M)) := by
  have hω : 0 ≤ omega σ (1/(2*M)) := omega_nonneg _ _
  nlinarith [minEigenvalue_toeplitz_ge_min (M:=M) σ, hω]
```

**Замечание:** я специально пишу `sInf (Set.range σ)` вместо `min σ`, потому что в Lean “\(\min\)” требует компактность+непрерывность (или finset). Если у тебя уже `Continuous` и `IsCompact` на \(\mathbb T\), то можешь получить `∃θ0, σ θ0 = sInf (range σ)` и переписать в привычный `min`.

---

## 8. Итог: что делать прямо сейчас

- **Лучший путь:** не формализуй “Szegő–Böttcher determinant asymptotics” вообще.  
  Закрой A3_bridge_axiom через **Rayleigh lower bound** (который естественно следует из Toeplitz quadratic form) — это на два порядка проще и уже согласовано в спеках【295:0†PROSHKA_REQUEST_3.md†L7-L16】【295:2†PROSHKA_REQUEST_3.md†L7-L13】.
- Если тебе нужно сохранить интерфейс “SB с \(C_{SB}=4\)”, просто докажи более сильное \(\lambda_{\min}\ge \min\sigma\) и добей \(\omega\ge 0\) (SB станет тривиальным следствием)【295:0†PROSHKA_REQUEST_3.md†L12-L16】.

Если хочешь, я могу в следующем сообщении разложить “минимальный Lean‑порт” именно под твою текущую реализацию \(T_M[P_A]\) (оператор vs матрица, `AddCircle 1` vs `Icc (-1/2) (1/2)`), но по сути доказательство всегда одно и то же: **Rayleigh + неотрицательная плотность \(|p|^2\)**.

## USER
Чувак, посмотри на это, ты скорее всего найдешь ответ. То есть идея такая, если просто информальные вещи пихать в Аристотель, он очень долго работает и может сломаться. Наша задача максимально облегчить ему работу. Поэтому мы проверили его API и поняли, что можно делать такую штуку, что давать ему уже линовские файлы. Потом оказалось, что с этими линовскими файлами он может работать только если они есть в матле библиотеки. Точка. Что правильно, потому что сообщество полагается на проверенные факты. И это считается проверенными. Окей. Наша задача построить такой зонбокс, который можно будет послать в Аристотель, чтобы доказывать еще не доказанные вещи, но максимально облегчить ему работу. Как ты думаешь, может быть есть какие-то другие подходы? Или ты думаешь, можно писать ему информальщину, информальный языковой ввод? Но мне кажется почему-то, что вот этот аппроч с языковым вводом и какими-то линовскими файлами, вот именно с анбокс аппроч, то есть он должен работать лучше. Как ты думаешь?

## ASSISTANT
У тебя тут реально **не тот блокер**.

## 1) Анализ: что лучше делать с Szegő–Böttcher в Lean

### Ключевой факт (и он сильнее SB)
В актуальной спека‑версии `PROSHKA_REQUEST v4` прямо зафиксировано:

- **Toeplitz quadratic form**:  
  \(\langle T_M[P_A]p,p\rangle = \int_{\mathbb{T}} P_A(\theta)\,|p(\theta)|^2\,d\theta\).  
- **Rayleigh lower bound**:  
  \(\lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in\mathbb{T}} P_A(\theta)\).  
- И **Szegő–Böttcher объявлен опциональным**, потому что он следует как слабое следствие из \(\omega\ge 0\).  
  Это буквально написано в спеках. 【288:3†PROSHKA_REQUEST_3.md†L45-L60】【288:4†PROSHKA_REQUEST_3.md†L7-L13】【288:5†PROSHKA_REQUEST_3.md†L51-L55】

То есть: **формализовывать “настоящий” Szegő–Böttcher (асимптотику детерминантов Тёплица) НЕ НУЖНО**, чтобы закрыть `A3_bridge_axiom`. В твоей архитектуре мост A3 закрывается через **Rayleigh bound** + **A3 floor** + **prime cap**.

### Почему это ещё и важно именно для Aristotle
Ты сам это уже зафиксировал в `SANDBOX_CHALLENGE`:  
Aristotle **отвергает пользовательские axioms**, так что “временно аксиоматизировать SB” нельзя. 【288:8†SANDBOX_CHALLENGE.md†L9-L16】【288:6†SANDBOX_CHALLENGE.md†L18-L23】

Следствие: если SB не в Mathlib, то “формализовать SB” = реально тащить большой кусок Toeplitz theory. Это долго и рискованно. А Rayleigh‑путь — короткий и *Mathlib‑friendly*.

**Вывод (жёстко):** лучшая стратегия — **выкинуть SB как требование** из `A3_bridge_axiom` и заменить его на Rayleigh lower bound. SB можно оставить как “лемму‑ярлык”, но доказать её тривиально (см. ниже).

---

## 2) Полный proof sketch: как закрыть A3_bridge_axiom без SB

Ниже — логическая цепочка в терминах твоих модулей.

### 2.1. Model–space restriction / Toeplitz quadratic form
Из “Toeplitz bridge” у тебя есть стандартный факт (в статье это Lemma 8.8):

\[
\langle T_M[P_A]p,p\rangle_{L^2(\mathbb{T})}
= \int_{-1/2}^{1/2} P_A(\theta)\,|p(\theta)|^2\,d\theta,
\quad p\in P_M.
\]

Это ровно то, что в спеке названо “Toeplitz quadratic form (Rayleigh core)”. 【288:3†PROSHKA_REQUEST_3.md†L45-L49】  
В pdf это тоже явно сформулировано (Lemma 8.8). 【288:9†RH_Q3.pdf†L25-L44】

### 2.2. Rayleigh lower bound (главный удар)
Дальше всё “школьно”:

Если \(m := \min_{\theta} P_A(\theta)\), то \(P_A(\theta)\ge m\) для всех \(\theta\). Значит для любого \(p\neq 0\):

\[
\frac{\langle T_M[P_A]p,p\rangle}{\langle p,p\rangle}
= \frac{\int P_A |p|^2}{\int |p|^2}
\ge \frac{\int m |p|^2}{\int |p|^2} = m.
\]

Берём инф по \(p\) → получаем:

\[
\lambda_{\min}(T_M[P_A]) \ge \min_{\theta} P_A(\theta).
\]

Именно это уже записано в `PROSHKA_REQUEST v4` как Tier‑1 факт “Rayleigh lower bound (no SB needed)”. 【288:3†PROSHKA_REQUEST_3.md†L51-L55】

### 2.3. A3 floor → численная нижняя грань
У тебя есть pointwise floor:

\[
P_A(\theta) \ge c_* = 11/10 \quad \forall \theta\in[-1/2,1/2].
\]

Следовательно \(\min P_A \ge c_*\), и значит

\[
\lambda_{\min}(T_M[P_A]) \ge c_*.
\]

Это опять‑таки прописано в спеках как модуль A3 floor. 【288:5†PROSHKA_REQUEST_3.md†L32-L35】

### 2.4. Prime cap + разность операторов
Prime‑часть (компрессия \(T_P\)) удовлетворяет:

\[
\|T_P\| \le c_*/4
\]

(в спеках стоит более сильное \(\rho(1) < 1/25\), но тебе достаточно \(c_*/4\)). 【288:5†PROSHKA_REQUEST_3.md†L37-L41】

Тогда для любого \(p\):

\[
\langle (T_M[P_A]-T_P)p,p\rangle
\ge \langle T_M[P_A]p,p\rangle - \|T_P\|\|p\|^2
\ge (c_*-\|T_P\|)\|p\|^2
\ge \frac{3c_*}{4}\|p\|^2 > 0.
\]

Эта финальная оценка в спеках тоже прямо указана: **никакого \(M_0\) не нужно**, и получается \(\ge 3c_*/4\). 【288:4†PROSHKA_REQUEST_3.md†L19-L26】

### 2.5. Связь с \(Q(\Phi)\) (Rayleigh identification)
Дальше: \(Q(\Phi_{B,t_{\mathrm{sym}}})\) совпадает с Rayleigh‑квотентом \((T_M[P_A]-T_P)\) на \(p\equiv 1\). Это у тебя отдельно фиксируется (“Rayleigh bridge (p=1)”). 【288:4†PROSHKA_REQUEST_3.md†L1-L4】  
В pdf это Theorem 8.10 / Lemma 8.9 блок. 【288:12†RH_Q3.pdf†L40-L75】

Отсюда \(Q(\Phi_{B,t_{\mathrm{sym}}})\ge 0\). Готово.

---

## 3) Lean‑style theorem statements (реально применимые)

Я дам **две линии**: (A) “как надо” для закрытия A3_bridge_axiom, и (B) “как сохранить имя Szegő–Böttcher”, но доказать его тривиально.

### 3.A. Минимальный набор лемм, который закрывает мост

#### (A1) Toeplitz quadratic form
Скелет (на уровне твоей спеки):

```lean
/-- Toeplitz quadratic form on P_M. -/
theorem toeplitz_quadratic_form
  (M : ℕ) (PA : ℝ → ℝ) (p : PM M) :
  ⟪TM PA p, p⟫_ℂ = ∫ θ in Set.Icc (-(1/2:ℝ)) (1/2:ℝ),
      (PA θ : ℂ) * Complex.abs (p θ)^2 := by
  -- this is the "Model–space restriction" lemma
  ...
```

(Где `PM M` — твой тип/подпространство триг. полиномов степени ≤ M, `TM PA` — Toeplitz operator.)

#### (A2) Rayleigh lower bound
```lean
/-- Rayleigh lower bound: no Szego–Bottcher needed. -/
theorem toeplitz_minRayleigh_ge_min_symbol
  (M : ℕ) (PA : ℝ → ℝ)
  (hmin : ∀ θ ∈ Set.Icc (-(1/2:ℝ)) (1/2:ℝ), m ≤ PA θ) :
  ∀ p : PM M, m * ‖p‖^2 ≤ Complex.re ⟪TM PA p, p⟫_ℂ := by
  -- use toeplitz_quadratic_form + pointwise inequality under the integral
  ...
```

#### (A3) Отсюда λ_min ≥ m (если тебе именно eigenvalue)
Если у тебя `λ_min` уже определён как инф Rayleigh‑квотента:

```lean
theorem toeplitz_lambdaMin_ge
  (M : ℕ) (PA : ℝ → ℝ) :
  lambdaMin (TM PA) ≥ sInf (Set.range fun θ => PA θ) := by
  -- unfold lambdaMin as inf over unit vectors, apply previous lemma
  ...
```

Но я бы **вообще не трогал eigenvalues**, а сразу работал с формой:
\(\langle (T_M[P_A]-T_P)p,p\rangle \ge 0\). Это проще.

#### (A4) Финальная “A3 bridge positivity” лемма без eigenvalues
```lean
theorem a3_bridge_quadratic_form_nonneg
  (M : ℕ) (PA : ℝ → ℝ) (TP : PM M →ₗ[ℂ] PM M)
  (hPA : ∀ θ ∈ Icc (-1/2:ℝ) (1/2:ℝ), (c_* : ℝ) ≤ PA θ)
  (hTP : ‖TP‖ ≤ c_*/4) :
  ∀ p : PM M, 0 ≤ Complex.re ⟪(TM PA - TP) p, p⟫_ℂ := by
  -- (1) ⟪TM PA p,p⟫ ≥ c_* ‖p‖^2 from toeplitz_quadratic_form + hPA
  -- (2) re ⟪TP p,p⟫ ≤ ‖TP‖ ‖p‖^2 (Cauchy-Schwarz / operator norm bound)
  -- (3) combine
  ...
```

Это ровно то, что нужно для `Q(Φ) ≥ 0` (а дальше A1′+A2 уже “переносят” на весь конус).

### 3.B. Если тебе *нужно* иметь лемму с именем “Szegő–Böttcher”
Согласно спекам v4, SB — **слабая короллария**, потому что \(\omega_\sigma\ge 0\). 【288:3†PROSHKA_REQUEST_3.md†L56-L60】

Ты можешь формально оставить требуемое API:

```lean
/-- (Optional) Szego–Bottcher style bound as a trivial corollary of Rayleigh + ω ≥ 0. -/
theorem szego_bottcher_corollary
  (M : ℕ) (PA : ℝ → ℝ) (C_SB : ℝ)
  (hC : 0 ≤ C_SB) :
  lambdaMin (TM PA) ≥ minPA - C_SB * omega PA (1/(2*M:ℝ)) := by
  have hRay : lambdaMin (TM PA) ≥ minPA := by
    -- from toeplitz quadratic form
    ...
  have hweak : minPA ≥ minPA - C_SB * omega PA (1/(2*M:ℝ)) := by
    -- since omega ≥ 0
    nlinarith [hC, omega_nonneg (PA := PA) (h := (1/(2*M:ℝ)))]
  exact ge_trans hRay hweak
```

**Важное:** так ты “формализуешь SB” без Toeplitz determinant theory вообще — просто как слабый следствие более сильной Rayleigh‑оценки. Это ровно то, что у тебя написано в спеках. 【288:4†PROSHKA_REQUEST_3.md†L9-L13】

---

## 4) Про “sandbox для Aristotle”: что реально работает

Ты правильно чувствуешь: “Lean‑sandbox” лучше, чем чистая информальщина… **но только если sandbox не содержит новых axioms**.

Твои же эксперименты показывают:

- `import Q3.Axioms` не работает (нет доступа к проекту)
- `axiom my_fact : ...` не работает (падает на verification)  
  【288:8†SANDBOX_CHALLENGE.md†L9-L16】

Поэтому рабочая стратегия такая:

1) **Mathlib‑only sandbox**: один файл, который импортит `Mathlib` и в нём же *доказывает* вспомогательные леммы (никаких `axiom`, `constant` и т.п.). 【288:6†SANDBOX_CHALLENGE.md†L1-L9】

2) В `problem.md` ты даёшь Aristotle:
   - точную цель
   - список конкретных лемм Mathlib, которые стоит использовать (как hints)
   - минимальные определения/аббревиатуры, которые не конфликтуют с Mathlib

3) Самое ценное: **перестраивать задачу так, чтобы не требовать недоформализованных теорем**.  
   В точности как здесь: вместо SB берём Rayleigh bound.

---

## Bottom line

- **Не формализуй Szegő–Böttcher как “Toeplitz determinant asymptotics”.** Это реально тяжёлая ветка и не совместима с ограничениями Aristotle (нельзя подсунуть аксиому). 【288:8†SANDBOX_CHALLENGE.md†L13-L16】
- **Снимай блокировку A3_bridge_axiom через Toeplitz quadratic form ⇒ Rayleigh lower bound.** Это уже зафиксировано в ваших спеках v4 как правильный путь. 【288:3†PROSHKA_REQUEST_3.md†L45-L55】
- Если хочешь “лемму SB” для совместимости — **докажи её тривиально** как королларию из Rayleigh + \(\omega\ge 0\). 【288:3†PROSHKA_REQUEST_3.md†L56-L60】

Если кинешь сигнатуры твоих текущих Lean‑объектов (`TM`, `PM`, как у тебя задан тор/меры, и как выражен prime operator), я подгоню эти statement’ы *в точности* под ваш namespace, без “псевдо‑Lean”.

## USER
 ⎿  Wrote 154 lines to /Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotle/aristotle_input/A3_bridge_closure_v1.md                                            
     # A3 Bridge Axiom Closure                                                                                                                                           
                                                                                                                                                                         
     ## Goal                                                                                                                                                             
                                                                                                                                                                         
     Prove the A3 bridge theorem: for Toeplitz matrix T with symbol P_A minus RKHS kernel matrix T_P, the Rayleigh quotient is bounded below by c*/4 where c* =          
     11/10.                                                                                                                                                              
                                                                                                                                                                         
     ## What We Have (Already Proven)                                                                                                                                    
                                                                                                                                                                         
     ### 1. Rayleigh Lower Bound for Toeplitz Matrices                                                                                                                   
                                                                                                                                                                         
     For a Toeplitz matrix T with symbol P : ℝ → ℝ, if P(θ) ≥ m for all θ ∈ [-1/2, 1/2], then the Rayleigh quotient satisfies:                                           
                                                                                                                                                                         
     ```                                                                                                                                                                 
     (∑ᵢ ∑ⱼ vᵢ Tᵢⱼ vⱼ) / (∑ᵢ vᵢ²) ≥ m                                                                                                                                    
     ```                                                                                                                                                                 
                                                                                                                                                                         
     This was proven in `rayleigh_v1.lean` using:                                                                                                                        
     - Toeplitz quadratic form = ∫ P(θ) |p(θ)|² dθ where p is the trig polynomial                                                                                        
     - Parseval identity: ∫ |p(θ)|² dθ = ∑ vₖ²                                                                                                                           
     - Pointwise bound P(θ) ≥ m gives integral bound                                                                                                                     
                                                                                                                                                                         
     ### 2. A3_FLOOR: Symbol Lower Bound                                                                                                                                 
                                                                                                                                                                         
     The archimedean symbol P_A satisfies:                                                                                                                               
     ```                                                                                                                                                                 
     P_A(θ) ≥ c* = 11/10 for all θ ∈ [-1/2, 1/2]                                                                                                                         
     ```                                                                                                                                                                 
                                                                                                                                                                         
     This is proven in `A3_FLOOR_v22_stage4_floor.lean`.                                                                                                                 
                                                                                                                                                                         
     ### 3. RKHS Kernel Properties                                                                                                                                       
                                                                                                                                                                         
     The RKHS kernel matrix T_P with entries:                                                                                                                            
     ```                                                                                                                                                                 
     T_P[i,j] = √(w_RKHS(i)) √(w_RKHS(j)) exp(-(ξᵢ - ξⱼ)² / (4t))                                                                                                        
     ```                                                                                                                                                                 
                                                                                                                                                                         
     where:                                                                                                                                                              
     - w_RKHS(n) = Λ(n) / √n (von Mangoldt / sqrt)                                                                                                                       
     - ξₙ = log n (node positions)                                                                                                                                       
     - t > 0 is heat parameter                                                                                                                                           
                                                                                                                                                                         
     Key bound: w_RKHS(n) ≤ w_max = 2/e for all n.                                                                                                                       
                                                                                                                                                                         
     ## What to Prove                                                                                                                                                    
                                                                                                                                                                         
     ### Main Theorem: A3_bridge_data_uniform                                                                                                                            
                                                                                                                                                                         
     ```lean                                                                                                                                                             
     theorem A3_bridge_closure :                                                                                                                                         
       ∃ M₀ : ℕ, ∃ t > 0, ∀ M ≥ M₀,                                                                                                                                      
         ∀ (v : Fin M → ℝ), v ≠ 0 →                                                                                                                                      
         (∑ i, ∑ j, v i * v j * (ToeplitzEntry_a_star i j - T_P i j t)) /                                                                                                
         (∑ i, v i ^ 2) ≥ c_star / 4                                                                                                                                     
     ```                                                                                                                                                                 
                                                                                                                                                                         
     where c_star = 11/10.                                                                                                                                               
                                                                                                                                                                         
     ## Proof Strategy                                                                                                                                                   
                                                                                                                                                                         
     **Step 1: Toeplitz Term**                                                                                                                                           
     By Rayleigh lower bound + A3_FLOOR:                                                                                                                                 
     ```                                                                                                                                                                 
     (Toeplitz(a_star) form) / ‖v‖² ≥ min(P_A) ≥ c* = 11/10                                                                                                              
     ```                                                                                                                                                                 
                                                                                                                                                                         
     **Step 2: RKHS Term Upper Bound**                                                                                                                                   
     Choose t large enough so that the RKHS kernel is very small.                                                                                                        
                                                                                                                                                                         
     For the heat kernel exp(-(ξᵢ - ξⱼ)² / (4t)):                                                                                                                        
     - As t → ∞, off-diagonal terms → 0 exponentially slow                                                                                                               
     - Diagonal terms = w_RKHS(i) (since exp(0) = 1)                                                                                                                     
                                                                                                                                                                         
     Quadratic form bound:                                                                                                                                               
     ```                                                                                                                                                                 
     (RKHS form) / ‖v‖² ≤ ‖T_P‖_op                                                                                                                                       
     ```                                                                                                                                                                 
                                                                                                                                                                         
     We need: ‖T_P‖_op ≤ 3c*/4 = 33/40 ≈ 0.825                                                                                                                           
                                                                                                                                                                         
     **Step 3: Combined**                                                                                                                                                
     ```                                                                                                                                                                 
     (Toeplitz - RKHS) / ‖v‖² ≥ c* - 3c*/4 = c*/4                                                                                                                        
     ```                                                                                                                                                                 
                                                                                                                                                                         
     ## Key Lemmas to Prove                                                                                                                                              
                                                                                                                                                                         
     ### Lemma 1: RKHS Row Sum Bound                                                                                                                                     
                                                                                                                                                                         
     For the RKHS matrix T_P:                                                                                                                                            
     ```                                                                                                                                                                 
     ∑ⱼ |T_P[i,j]| ≤ w_max * (1 + S(t))                                                                                                                                  
     ```                                                                                                                                                                 
     where S(t) = ∑_{k≠0} exp(-δ²k² / (4t)) is a convergent series.                                                                                                      
                                                                                                                                                                         
     For t large: S(t) → 0.                                                                                                                                              
                                                                                                                                                                         
     ### Lemma 2: RKHS Operator Norm                                                                                                                                     
                                                                                                                                                                         
     By Schur test (row/column sum bound):                                                                                                                               
     ```                                                                                                                                                                 
     ‖T_P‖_op ≤ max_row ∑ⱼ |T_P[i,j]| ≤ w_max * (1 + S(t))                                                                                                               
     ```                                                                                                                                                                 
                                                                                                                                                                         
     Choose t such that w_max * (1 + S(t)) ≤ 3c*/4.                                                                                                                      
                                                                                                                                                                         
     Since w_max = 2/e ≈ 0.735 and c* = 1.1:                                                                                                                             
     - 3c*/4 = 0.825                                                                                                                                                     
     - Need: 0.735 * (1 + S(t)) ≤ 0.825                                                                                                                                  
     - Need: 1 + S(t) ≤ 1.122                                                                                                                                            
     - Need: S(t) ≤ 0.122                                                                                                                                                
                                                                                                                                                                         
     This is achievable for large enough t.                                                                                                                              
                                                                                                                                                                         
     ### Lemma 3: Difference of Quadratic Forms                                                                                                                          
                                                                                                                                                                         
     For positive semidefinite A with λ_min(A) ≥ a and B with ‖B‖_op ≤ b:                                                                                                
     ```                                                                                                                                                                 
     ⟨v, (A - B)v⟩ / ⟨v,v⟩ ≥ a - b                                                                                                                                       
     ```                                                                                                                                                                 
                                                                                                                                                                         
     ## Definitions Needed                                                                                                                                               
                                                                                                                                                                         
     ```lean                                                                                                                                                             
     -- Toeplitz entry from archimedean symbol                                                                                                                           
     def ToeplitzEntry_a_star (i j : ℕ) : ℝ :=                                                                                                                           
       ∫ θ in Set.Icc (-1/2 : ℝ) (1/2), a_star θ * Real.cos (2 * π * (i - j) * θ)                                                                                        
                                                                                                                                                                         
     -- RKHS kernel matrix entry                                                                                                                                         
     def T_P (i j : ℕ) (t : ℝ) : ℝ :=                                                                                                                                    
       Real.sqrt (w_RKHS i) * Real.sqrt (w_RKHS j) *                                                                                                                     
       Real.exp (-(Real.log i - Real.log j)^2 / (4 * t))                                                                                                                 
                                                                                                                                                                         
     -- c* constant                                                                                                                                                      
     def c_star : ℝ := 11 / 10                                                                                                                                           
     ```                                                                                                                                                                 
                                                                                                                                                                         
     ## Mathlib Lemmas to Use                                                                                                                                            
                                                                                                                                                                         
     - `Matrix.norm_le_iff` - operator norm bounds                                                                                                                       
     - `MeasureTheory.integral_mono` - integral monotonicity                                                                                                             
     - `Real.exp_neg_sq_tendsto_zero` - heat kernel decay                                                                                                                
     - Schur test for operator norm bounds                                                                                                                               
     - `Finset.sum_le_sum` - sum bounds                                                                                                                                  
                                                                                                                                                                         
     ## Notes                                                                                                                                                            
                                                                                                                                                                         
     This proof combines:                                                                                                                                                
     1. Rayleigh theory (already proven in rayleigh_v1.lean)                                                                                                             
     2. A3_FLOOR (P_A ≥ c*)                                                                                                                                              
     3. RKHS operator norm control via heat parameter t                                                                                                                  
                                                                                                                                                                         
     The key insight is choosing t LARGE to make RKHS term small, not just showing ‖T_P‖ < 1.                                                                            
                                                                                                

## USER
  ⎿  PreToolUse:Write hook succeeded: Success                                                                                                                            
  ⎿  Wrote 111 lines to /Users/emalam/Documents/GitHub/chen_q3/full/q3.lean.aristotle/docs/INSIGHTS.md                                                                   
     # Project Insights                                                                                                                                                  
                                                                                                                                                                         
     Важные находки которые нельзя забывать.                                                                                                                             
                                                                                                                                                                         
     ---                                                                                                                                                                 
                                                                                                                                                                         
     ## Aristotle Strategy                                                                                                                                               
                                                                                                                                                                         
     ### Insight: Pure Informal > Sandbox                                                                                                                                
                                                                                                                                                                         
     **Дата:** 2026-01-14                                                                                                                                                
                                                                                                                                                                         
     **Эксперимент:** Отправили одну задачу (Rayleigh lower bound) двумя способами:                                                                                      
     - V1: pure informal markdown                                                                                                                                        
     - V2: sandbox с готовыми сигнатурами                                                                                                                                
                                                                                                                                                                         
     **Результат:**                                                                                                                                                      
     - V1: **ПОЛНОЕ доказательство**, 0 sorry                                                                                                                            
     - V2: только helper lemmas, main theorem sorry                                                                                                                      
                                                                                                                                                                         
     **Причина:** Sandbox заставляет Aristotle работать с ФИКСИРОВАННЫМИ сигнатурами.                                                                                    
     Если сигнатура не оптимальна — он застревает.                                                                                                                       
     Pure informal даёт свободу ПЕРЕФОРМУЛИРОВАТЬ теорему как удобнее.                                                                                                   
                                                                                                                                                                         
     **Правило:** Для сложных теорем использовать pure informal, sandbox только для                                                                                      
     простых/изолированных лемм.                                                                                                                                         
                                                                                                                                                                         
     ---                                                                                                                                                                 
                                                                                                                                                                         
     ## A3 Bridge Mathematics                                                                                                                                            
                                                                                                                                                                         
     ### Insight: RKHS bound недостаточен "из коробки"                                                                                                                   
                                                                                                                                                                         
     **Дата:** 2026-01-14                                                                                                                                                
                                                                                                                                                                         
     **Проблема:**                                                                                                                                                       
     ```                                                                                                                                                                 
     A3_bridge требует: (Toeplitz - RKHS) / ||v||² ≥ c*/4                                                                                                                
                                                                                                                                                                         
     Наивный подход:                                                                                                                                                     
     - Toeplitz / ||v||² ≥ c* = 1.1 (из Rayleigh + A3_FLOOR)                                                                                                             
     - RKHS / ||v||² ≤ ρ (из RKHS_contraction)                                                                                                                           
     - Разница ≥ c* - ρ                                                                                                                                                  
                                                                                                                                                                         
     Но RKHS_contraction.lean даёт:                                                                                                                                      
       ρ = (1 + w_max)/2 = (1 + 2/e)/2 ≈ 0.868                                                                                                                           
                                                                                                                                                                         
     Нужно: c* - ρ ≥ c*/4                                                                                                                                                
            1.1 - ρ ≥ 0.275                                                                                                                                              
            ρ ≤ 0.825                                                                                                                                                    
                                                                                                                                                                         
     Но 0.868 > 0.825 — НЕ СХОДИТСЯ!                                                                                                                                     
     ```                                                                                                                                                                 
                                                                                                                                                                         
     **Решение:** Не использовать готовый ρ из RKHS_contraction!                                                                                                         
                                                                                                                                                                         
     Вместо этого: ВЫБРАТЬ t большое так чтобы ||T_P(t)|| ≤ c*/4 напрямую.                                                                                               
                                                                                                                                                                         
     При t → ∞:                                                                                                                                                          
     - Heat kernel exp(-(ξᵢ-ξⱼ)²/(4t)) → 0 для i≠j                                                                                                                       
     - Off-diagonal terms → 0                                                                                                                                            
     - ||T_P|| можно сделать сколь угодно малым                                                                                                                          
                                                                                                                                                                         
     **Математика:**                                                                                                                                                     
     ```                                                                                                                                                                 
     ||T_P|| ≤ w_max * (1 + S(t))                                                                                                                                        
                                                                                                                                                                         
     где S(t) = ∑_{k≠0} exp(-δ²k²/(4t)) → 0 при t → ∞                                                                                                                    
                                                                                                                                                                         
     Нужно: w_max * (1 + S(t)) ≤ c*/4 = 0.275                                                                                                                            
            0.735 * (1 + S(t)) ≤ 0.275                                                                                                                                   
                                                                                                                                                                         
     Это достижимо при достаточно большом t!                                                                                                                             
     ```                                                                                                                                                                 
                                                                                                                                                                         
     **Правило:** Для A3_bridge нужен СВОЙ выбор t, не из RKHS_contraction.                                                                                              
                                                                                                                                                                         
     ---                                                                                                                                                                 
                                                                                                                                                                         
     ## Key Constants Reference                                                                                                                                          
                                                                                                                                                                         
     | Constant | Value | Decimal | Source |                                                                                                                             
     |----------|-------|---------|--------|                                                                                                                             
     | c* | 11/10 | 1.1 | A3_FLOOR |                                                                                                                                     
     | c*/4 | 11/40 | 0.275 | A3_bridge target |                                                                                                                         
     | 3c*/4 | 33/40 | 0.825 | Max RKHS bound |                                                                                                                          
     | w_max | 2/e | 0.735 | RKHS weight bound |                                                                                                                         
     | ρ (RKHS) | (1+2/e)/2 | 0.868 | RKHS_contraction.lean |                                                                                                            
                                                                                                                                                                         
     **Warning:** ρ = 0.868 > 3c*/4 = 0.825, поэтому готовый ρ НЕ подходит!                                                                                              
                                                                                                                                                                         
     ---                                                                                                                                                                 
                                                                                                                                                                         
     ## File Organization                                                                                                                                                
                                                                                                                                                                         
     ### Insight: aristotle_input/ structure                                                                                                                             
                                                                                                                                                                         
     - `*_v1.md`, `*_v2.md` — версии одного запроса                                                                                                                      
     - `project_ids.txt` — трекинг UUID проектов                                                                                                                         
     - Pure informal файлы работают лучше чем sandbox                                                                                                                    
                                                                                                                                                                         
     ### Insight: aristotle_output/ naming                                                                                                                               
                                                                                                                                                                         
     - `rayleigh_v1.lean` — winner (полное доказательство)                                                                                                               
     - `rayleigh_v2.lean` — backup (только helpers)                                                                                                                      
     - Коммитить оба, в commit message указывать какой winner                                                                                                            
                                                                                                                                                                         
     ---                                                                                                                                                                 
                                                                                                                                                                         
     *Обновляй этот файл когда находишь новые insights!*                                                                     

## ASSISTANT
Феномен/аномалия, который тут реально важен: ты говоришь “Szegő–Böttcher (асимптотика определителей Тёплица)”, но **в A3_bridge (по твоей же спеки) у тебя на самом деле нужен не strong Szegő про детерминанты**, а **барьер снизу для спектрального дна Toeplitz-блока** — и даже он **не должен быть блокером**. В `PROSHKA_REQUEST_3` это прямо зафиксировано: *Rayleigh lower bound (no Szegő–Böttcher needed)*, а SB — “optional / weaker corollary”.【287:0†PROSHKA_REQUEST_3.md†L1-L16】【287:2†PROSHKA_REQUEST_3.md†L26-L32】

Ниже даю: (1) какой вариант лучше, (2) полный скетч доказательства выбранного варианта, (3) Lean-стейтменты, и отдельно — что делать, если ты **всё равно** хочешь SB-оценку как отдельную лемму.

---

## 0. Теорема и статус

### Вариант А (лучший для Lean / для Aristotle)
**Точная формулировка (с кванторами):**  
Пусть \(P:\mathbb{T}\to\mathbb{R}\) измерима и ограничена, и \(T_M[P]\) — Toeplitz-сжатие “Fourier multiplier with symbol \(P\)” на пространство тригонометрических многочленов \(P_M\). Тогда
\[
\forall M\in\mathbb{N}:\quad \lambda_{\min}(T_M[P])\ \ge\ \inf_{\theta\in\mathbb{T}} P(\theta).
\]
**Статус:** стандартная математика; это прямое следствие точной формулы квадратичной формы Toeplitz (Rayleigh core).【287:0†PROSHKA_REQUEST_3.md†L1-L10】【287:4†RH_Q3.pdf†L33-L44】

### Вариант B (если уж очень нужен “SB-barrier” с модулем)
**Формулировка:**  
\[
\lambda_{\min}(T_M[\sigma]) \ge \min\sigma - C_{SB}\,\omega_\sigma(1/(2M)), \quad C_{SB}=4.
\]
**Статус:** “optional” в спеках (можно вывести как слабый королларий, но для A3_bridge не требуется).【287:0†PROSHKA_REQUEST_3.md†L12-L16】【287:0†PROSHKA_REQUEST_3.md†L49-L55】

---

## 1. Контекст A3_bridge_axiom

В твоей текущей спеки (PROSHKA_REQUEST_3) A3-цепочка такая:

- Toeplitz quadratic form (Rayleigh):  
  \(\langle T_M[P_A]p,p\rangle = \int_{\mathbb{T}} P_A(\theta)|p(\theta)|^2\,d\theta\).【287:0†PROSHKA_REQUEST_3.md†L1-L5】【287:4†RH_Q3.pdf†L33-L44】
- Отсюда Rayleigh lower bound: \(\lambda_{\min}(T_M[P_A]) \ge \min P_A\).【287:0†PROSHKA_REQUEST_3.md†L7-L10】
- A3 floor: \(P_A(\theta)\ge c_* = 11/10\) (pointwise).【287:0†PROSHKA_REQUEST_3.md†L32-L35】
- RKHS cap: \(\|T_P\|\le c_*/4\).【287:0†PROSHKA_REQUEST_3.md†L37-L41】
- Тогда \(\lambda_{\min}(T_M[P_A]-T_P)\ge c_*-\|T_P\|\ge 3c_*/4>0\).【287:0†PROSHKA_REQUEST_3.md†L61-L69】

Ключ: **никакой \(M_0\) и никакой SB тебе здесь не нужны**, если ты используешь Rayleigh lower bound напрямую — это явно прописано.【287:0†PROSHKA_REQUEST_3.md†L49-L55】

---

## 2. Определения и нотация

- \(\mathbb{T}=[-1/2,1/2]\) с мерой \(d\theta\), период-1 (это важно: не \(2\pi\)-тор).【287:1†PROSHKA_REQUEST_3.md†L25-L28】
- \(P_M = \{p(\theta)=\sum_{|k|\le M} c_k e^{2\pi i k\theta}\}\).【287:4†RH_Q3.pdf†L25-L31】
- \(T_M[P]\) — **сжатие** Fourier multiplier с символом \(P\) на \(P_M\) (self-adjoint).【287:4†RH_Q3.pdf†L33-L44】【287:4†RH_Q3.pdf†L86-L89】
- Prime operator \(T_P^{(M)}\) — PSD, и есть тривиальная норма-оценка по сумме весов (в тексте это через треугольник по сумме rank-1).【287:4†RH_Q3.pdf†L69-L80】【287:4†RH_Q3.pdf†L95-L100】

---

## 3. Математический анализ: какой вариант лучше

### Почему **не** стоит формализовать “strong Szegő / детерминанты” ради A3_bridge
Это другой зверь: факторизации, Hardy spaces, log det, тонкие пределы. Даже если бы это было нужно (а тут нет), это месяцы работы.

### Почему вариант А (Rayleigh) — лучший
1) Он **ровно соответствует** твоей “Rayleigh core” спецификации.【287:0†PROSHKA_REQUEST_3.md†L1-L10】  
2) Он уже фигурирует как “no Szegő–Böttcher needed” (и прямо в “DO NOT DO” сказано не делать SB блокером).【287:2†PROSHKA_REQUEST_3.md†L26-L32】  
3) Lean-формализация сводится к **квадратичной форме** + **интегральной монотонности**, без спектральной теории детерминантов.  
4) Для Aristotle это огромный выигрыш: меньше API-магии, меньше глобальных импортах, меньше сложных “asymptotics”.

**Вывод:** для закрытия `A3_bridge_axiom` в Lean 4 оптимально **выкинуть SB из критического пути** и закрыть мост через Rayleigh + RKHS cap. Это согласовано с PROSHKA_REQUEST_3.【287:0†PROSHKA_REQUEST_3.md†L49-L69】

---

## 4. План доказательства (Roadmap) — выбранный вариант А

1) Использовать лемму “Toeplitz quadratic form”:  
   \(\langle T_M[P_A]p,p\rangle=\int P_A|p|^2\).【287:4†RH_Q3.pdf†L33-L44】  
2) Из pointwise floor \(P_A\ge c_*\) получить нижнюю оценку квадратичной формы:  
   \(\langle T_M[P_A]p,p\rangle \ge c_* \|p\|_2^2\).  
3) Для PSD оператора \(T_P^{(M)}\) использовать \(\langle T_P^{(M)}p,p\rangle\le \|T_P^{(M)}\|\,\|p\|^2\).  
4) Комбинировать:  
   \(\langle (T_M[P_A]-T_P^{(M)})p,p\rangle \ge (c_*-\|T_P^{(M)}\|)\|p\|^2\).  
5) При \(\|T_P^{(M)}\|\le c_*/4\) получить запас \(\ge 3c_*/4\), значит Rayleigh-квотент \(\ge 0\).【287:0†PROSHKA_REQUEST_3.md†L61-L69】

---

## 5. Леммы (минимальный набор)

### Лемма 1: Toeplitz quadratic form
**Формулировка (по сути Lemma 8.8):** для \(p\in P_M\),
\[
\langle T_M[P]p,p\rangle = \int_{\mathbb{T}} P(\theta)|p(\theta)|^2\,d\theta.
\]
**Источник в твоём пакете:** это прямо записано как “Toeplitz quadratic form (Rayleigh core)” и в pdf как Lemma 8.8.【287:0†PROSHKA_REQUEST_3.md†L1-L5】【287:4†RH_Q3.pdf†L33-L44】

### Лемма 2: Rayleigh lower bound от pointwise floor
Если \(P(\theta)\ge c\) для всех \(\theta\), то \(\forall p\neq 0\):
\[
\frac{\langle T_M[P]p,p\rangle}{\|p\|^2} \ge c.
\]
**Доказательство:**  
из Леммы 1: \(\langle T_M[P]p,p\rangle=\int P|p|^2 \ge \int c|p|^2 = c\|p\|^2\). ∎

### Лемма 3: Вычитание PSD оператора через op-norm
Если \(S\) — самосопр. оператор с \(\langle Sp,p\rangle \ge c\|p\|^2\), и \(R\) — самосопр. PSD, то
\[
\langle (S-R)p,p\rangle \ge (c-\|R\|)\|p\|^2.
\]
**Доказательство:**  
\(\langle Rp,p\rangle\le \|R\|\,\|p\|^2\) по определению op-norm; значит  
\(\langle (S-R)p,p\rangle = \langle Sp,p\rangle - \langle Rp,p\rangle \ge c\|p\|^2 - \|R\|\|p\|^2\). ∎

---

## 6. Основное доказательство A3_bridge без SB

### Цель
Закрыть мост “позитивность на генераторах”:

- \(P_A(\theta)\ge c_*=11/10\) (A3 floor).【287:0†PROSHKA_REQUEST_3.md†L32-L35】
- \(\|T_P\|\le c_*/4\) (RKHS cap).【287:0†PROSHKA_REQUEST_3.md†L37-L41】

### Доказательство
1) Для любого \(p\in P_M\) по Лемме 1:
\[
\langle T_M[P_A]p,p\rangle=\int_{\mathbb{T}} P_A(\theta)|p(\theta)|^2d\theta.
\]【287:4†RH_Q3.pdf†L33-L44】

2) Из \(P_A\ge c_*\) получаем:
\[
\langle T_M[P_A]p,p\rangle \ge c_* \|p\|^2.
\]
(Лемма 2)

3) Для \(T_P^{(M)}\) (PSD) применяем Лемму 3:
\[
\langle (T_M[P_A]-T_P^{(M)})p,p\rangle \ge (c_*-\|T_P^{(M)}\|)\|p\|^2.
\]

4) По cap \(\|T_P^{(M)}\|\le \|T_P\|\le c_*/4\), значит
\[
\langle (T_M[P_A]-T_P^{(M)})p,p\rangle \ge (c_* - c_*/4)\|p\|^2 = \frac{3c_*}{4}\|p\|^2>0.
\]
Это ровно тот вывод, который прописан у тебя в спеках.【287:0†PROSHKA_REQUEST_3.md†L61-L69】

5) В частности, для \(p\equiv 1\) Rayleigh pairing даёт \(Q(\Phi_{B,t_{\mathrm{sym}}})\ge 0\) (см. Theorem 8.10 / Rayleigh bridge).【287:0†PROSHKA_REQUEST_3.md†L43-L46】【287:8†RH_Q3.pdf†L6-L35】

∎

---

## 7. Lean-style theorem statements (минимально “Lean-ready” по смыслу)

Я напишу “стейтменты”, которые удобно положить в sandbox (Mathlib only), и которые Aristotle реально сможет закрывать маленькими шагами.

### (A) Rayleigh core (квадратичная форма Toeplitz)
```lean
/-- Period-1 torus as interval [-1/2, 1/2]. -/
def torusI : Set ℝ := Set.Icc (-(1/2 : ℝ)) (1/2 : ℝ)

-- Abstract version: you already have a concrete `T_M[P]` in your codebase.
-- In a sandbox you can model it as a selfAdjoint operator on a finite-dimensional inner product space.

theorem toeplitz_quadratic_form
  {M : ℕ} {P : ℝ → ℝ} {p : ℝ → ℂ}
  (hp : p ∈ P_M M) :
  ⟪T_M P p, p⟫_ℂ = ∫ θ in torusI, (P θ) * Complex.abs (p θ) ^ 2 := by
  -- proof: standard Toeplitz form identity
  sorry
```

### (B) Rayleigh lower bound from pointwise floor (без SB)
```lean
theorem toeplitz_rayleigh_lower_bound
  {M : ℕ} {P : ℝ → ℝ} {c : ℝ}
  (hP : ∀ θ ∈ torusI, c ≤ P θ) :
  ∀ p ∈ P_M M, p ≠ 0 →
    (Real.re (⟪T_M P p, p⟫_ℂ)) / (Real.re (⟪p, p⟫_ℂ)) ≥ c := by
  -- use `toeplitz_quadratic_form` + `MeasureTheory.integral_mono` (or `integral_mul_le_integral_mul`)
  sorry
```

### (C) Operator subtraction via op-norm
```lean
theorem quadform_sub_lower_bound
  {E : Type} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [FiniteDimensional ℂ E]
  {S R : E →L[ℂ] E} {c : ℝ}
  (hS : IsSelfAdjoint S)
  (hR : IsSelfAdjoint R)
  (hR_psd : 0 ≤ᵢ R) -- or your preferred PSD predicate
  (hS_floor : ∀ x : E, Real.re ⟪S x, x⟫_ℂ ≥ c * ‖x‖^2) :
  ∀ x : E, Real.re ⟪(S - R) x, x⟫_ℂ ≥ (c - ‖R‖) * ‖x‖^2 := by
  -- use `Real.re ⟪R x, x⟫ ≤ ‖R‖ * ‖x‖^2`
  sorry
```

### (D) Финальный A3_bridge (как в спеках)
```lean
theorem A3_bridge_closure
  {M : ℕ}
  (h_floor : ∀ θ ∈ torusI, (11/10 : ℝ) ≤ P_A θ)
  (h_cap : ‖T_P_M‖ ≤ (11/10 : ℝ) / 4) :
  ∀ p ∈ P_M M, p ≠ 0 →
    Real.re ⟪(T_M P_A - T_P_M) p, p⟫_ℂ ≥ (3*(11/10 : ℝ)/4) * ‖p‖^2 := by
  -- combine (B) + (C)
  sorry
```

Смысл совпадает с твоей спеки “no SB needed” и тем, что в конце получается запас \(3c_*/4\).【287:0†PROSHKA_REQUEST_3.md†L61-L69】

---

## 8. Если ты всё же хочешь SB-оценку (как отдельный модуль)

Тут важно: **в твоих спеках SB уже объявлен “optional”** и даже прописано, что это “weaker corollary” и можно просто написать  
\(\min P_A \ge \min P_A - 4\omega(\cdot)\) как тривиальную вещь.【287:0†PROSHKA_REQUEST_3.md†L49-L55】

Но если тебе хочется *реально* доказать нетривиальный SB-барьер (с модулем непрерывности и константой 4), то самый “Lean-friendly” путь — **не через детерминанты**, а через:

1) Fejér approximation \( \sigma_M = \mathrm{Fej}_M * \sigma\) и оценку
   \(\|\sigma - \sigma_M\|_\infty \le 2\,\omega_\sigma(1/(2M))\) (это аналитическая лемма про Fejér kernel).
2) Оценку нормы Toeplitz-оператора от sup-нормы символа:
   \(\|T_M[\sigma-\sigma_M]\| \le \|\sigma-\sigma_M\|_\infty\) (это прямо следует из Toeplitz quadratic form).
3) Спектральное неравенство:
   \(\lambda_{\min}(A+B)\ge \lambda_{\min}(A)-\|B\|\).

Собираешь:
\[
\lambda_{\min}(T_M[\sigma])
\ge \lambda_{\min}(T_M[\sigma_M]) - \|T_M[\sigma-\sigma_M]\|
\ge \min\sigma_M - \|\sigma-\sigma_M\|_\infty
\ge \min\sigma - 2\|\sigma-\sigma_M\|_\infty
\ge \min\sigma - 4\omega_\sigma(1/(2M)).
\]

Это **намного** легче для Lean, чем “асимптотика det Toeplitz”.

---

## 9. Про sandbox-стратегию для Aristotle

То, что ты описал, совпадает с тем, что уже зафиксировано: Aristotle не видит project imports и отвергает новые `axiom`; рабочий путь — “self-contained .lean with Mathlib only”.【287:5†SANDBOX_CHALLENGE.md†L1-L23】【287:6†SANDBOX_CHALLENGE.md†L9-L21】

Практический совет (жёстко):  
- **Да, sandbox-аппроч лучше**, чем “информальщина”, *если* sandbox содержит маленькие, чёткие, Mathlib-only леммы (типа Rayleigh + op-norm).  
- “opaque/constant вместо axiom” как хак почти наверняка бесполезен: это всё равно добавляет непроверенный факт в среду проверки и будет отстрелен тем же “Unexpected axioms”.【287:6†SANDBOX_CHALLENGE.md†L13-L16】【287:6†SANDBOX_CHALLENGE.md†L58-L63】

Если твоя цель — “максимально облегчить ему работу”, то идеальный sandbox для A3_bridge — это **ровно** набор из лемм (A)-(D) выше и никаких SB/детерминантов.

---

### Bottom line
Для `A3_bridge_axiom` **лучший путь** — не формализовать Szegő–Böttcher вообще, а закрыть мост через Rayleigh lower bound + RKHS cap, как это прямо записано в `PROSHKA_REQUEST_3` (“no SB needed” + “Do NOT require SB as a blocker”).【287:0†PROSHKA_REQUEST_3.md†L49-L69】【287:2†PROSHKA_REQUEST_3.md†L26-L32】

Если хочешь, я могу следом разложить именно в терминах твоих текущих Lean-определений (какие у тебя сейчас `T_M`, `P_M`, `T_P_M`) и дать “точечный” список `import` + где какие `simp`/`linarith` обычно проходят — но логика уже готова и максимально лёгкая для формализации.

## ASSISTANT
Вижу **две разные “блокировки”**, и обе на самом деле решаются проще, чем кажется:

1) **A3_bridge_axiom “заблокирован на Szegő–Böttcher”** — это *анахронизм/рассинхрон*: в актуальном плане SB прямо помечен как **optional** и *не должен быть блокером*.  
2) **A1_density (hg_supp)** — это *реальная* дефиниционная проблема, но её “правильное” решение тоже уже зафиксировано: **margin condition** \(|\tau|+B\le K\).

Ниже дам: (i) разбор “какой вариант лучший”, (ii) полный скетч, (iii) Lean-стейтменты, и (iv) если вдруг всё равно хочется “настоящий SB”, то какой путь и какие зависимости.

---

## A3_bridge: почему Szegő–Böttcher НЕ нужен (и как закрыть без него)

### Феномен/аномалия
Ты говоришь: “A3_bridge_axiom заблокирован, потому что Szegő–Böttcher не в Mathlib”.

Но в **PROSHKA REQUEST v4** это прямо зафиксировано как **DO NOT DO**: “не требовать Szegő–Böttcher как блокер, использовать Rayleigh bound”.  
Смотри формулировку Tier‑1:  
- есть **Toeplitz quadratic form (Rayleigh core)**  
- и сразу **Rayleigh lower bound (no Szego‑Bottcher needed)**  
- а SB отмечен как **optional** и “следует как королларий, т.к. \(\omega_\sigma\ge 0\)”【293:2†PROSHKA_REQUEST_3.md†L45-L60】【285:0†PROSHKA_REQUEST_3.md†L12-L16】.

**Вывод:** SB не только не нужен — его можно оставить как “косметическую” лемму, доказываемую из Rayleigh за 3 строки.

---

## 1. Математический выбор: какой вариант лучший для A3_bridge

### Вариант A (рекомендуемый): выкинуть SB из критического пути
Используем цепочку, которая уже записана в v4:

- \(\langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)\,|p(\theta)|^2 d\theta\)【293:2†PROSHKA_REQUEST_3.md†L45-L49】  
- \(\lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in \mathbb T}P_A(\theta)\) (Rayleigh)【293:2†PROSHKA_REQUEST_3.md†L51-L54】  
- floor: \(P_A(\theta)\ge c_* = 11/10\) (pointwise)【293:2†PROSHKA_REQUEST_3.md†L76-L79】  
- RKHS cap: при \(t_{\mathrm{rkhs}}\ge 1\) имеем \(\|T_P\|\le\rho(1)<1/25\)【293:2†PROSHKA_REQUEST_3.md†L81-L85】  
- значит \(\lambda_{\min}(T_M[P_A]-T_P)\ge c_*-\|T_P\|\ge 3c_*/4>0\)【293:6†PROSHKA_REQUEST_3.md†L17-L27】.

Это **самый короткий** и **самый Lean-дружелюбный** путь: никакой глубокой теории Toeplitz-спектра, только квадратичная форма + элементарная оценка нормы.

### Вариант B: “формализовать SB”, но тривиально (как королларий)
SB-неравенство в плане записано так:
\[
\lambda_{\min}(T_M[\sigma]) \ge \min\sigma - C_{SB}\,\omega_\sigma(1/(2M)).
\]
Если у тебя уже есть более сильное:
\[
\lambda_{\min}(T_M[\sigma])\ge \min\sigma,
\]
то SB следует мгновенно, потому что \(\omega_\sigma(\cdot)\ge 0\)【285:0†PROSHKA_REQUEST_3.md†L12-L16】:
\[
\min\sigma \ge \min\sigma - C_{SB}\,\omega_\sigma(1/(2M)).
\]
То есть “формализация SB” превращается в **лемму “ω≥0” + монотонность ≥**.

### Вариант C: “настоящий SB с константой 4 и модулем” (тяжёлый)
Это уже отдельный проект (см. ниже): циркулянты/DFT или Fejér-локализация. Для A3_bridge — **оверкилл**.

**Итог выбора:** лучший вариант — **A**. SB не нужен как зависимость для A3_bridge вообще【293:6†PROSHKA_REQUEST_3.md†L7-L13】.

---

## 2. Скетч доказательства A3_bridge по варианту A

### 0. Теорема и статус
**Теорема (A3 bridge closure без SB):**  
\[
\forall M,\quad \lambda_{\min}(T_M[P_A]-T_P)\ge c_*-\|T_P\|
\]
и при \(P_A\ge c_*\) и \(\|T_P\|\le c_*/4\) получаем \(\lambda_{\min}\ge 3c_*/4>0\).  
**Статус:** стандартная линейная алгебра + базовая Fourier/Toeplitz идентификация (у вас это “Rayleigh core”).

### 1. Контекст
- \(P_A\) — arch symbol на \(\mathbb T=[-1/2,1/2]\), период 1【293:2†PROSHKA_REQUEST_3.md†L25-L34】  
- \(T_M[P_A]\) — Toeplitz-оператор/матрица на \(P_M\)  
- \(T_P\) — prime sampling operator (RKHS)  
- \(c_* = 11/10\) (важно: **не 1.5**)【293:2†PROSHKA_REQUEST_3.md†L76-L79】.

### 2. Основные шаги
1) Для любого \(p\in P_M\):
\[
\langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta
\]
(Rayleigh core)【293:2†PROSHKA_REQUEST_3.md†L45-L49】.

2) Если \(P_A(\theta)\ge c_*\) pointwise, то:
\[
\langle T_M[P_A]p,p\rangle \ge c_* \int_{\mathbb T}|p(\theta)|^2 d\theta = c_* \|p\|_{L^2}^2.
\]
Отсюда Rayleigh quotient \(\ge c_*\) для всех \(p\ne 0\), значит \(\lambda_{\min}(T_M[P_A])\ge c_*\)【293:2†PROSHKA_REQUEST_3.md†L51-L54】【293:2†PROSHKA_REQUEST_3.md†L76-L79】.

3) Для самосопряжённых \(A,B\):  
\[
\lambda_{\min}(A-B)\ge \lambda_{\min}(A)-\|B\|.
\]
(обычно доказывается через Rayleigh quotient и факт \(|\langle Bv,v\rangle|\le \|B\|\|v\|^2\)).

4) Применяем с \(A=T_M[P_A]\), \(B=T_P\). Используем RKHS cap: при \(t_{\mathrm{rkhs}}\ge 1\),
\[
\|T_P\|\le \rho(1)<1/25.
\]
Это автоматически \(\le c_*/4\), потому что \(1/25=0.04<0.275=11/40\) (и \(c_*/4=11/40\)). Сама cap-формулировка в плане:【293:2†PROSHKA_REQUEST_3.md†L81-L85】.

5) Заключаем:
\[
\lambda_{\min}(T_M[P_A]-T_P)\ge c_*-\|T_P\|\ge 3c_*/4>0
\]
и, в частности, \(Q(\Phi_{B,t_{\mathrm{sym}}})\ge 0\) через Rayleigh bridge (p=1)【285:0†PROSHKA_REQUEST_3.md†L43-L46】【293:6†PROSHKA_REQUEST_3.md†L23-L27】.

---

## 3. Lean-стейтменты для варианта A

Ниже я даю **Lean-стиль** (скорее “скелет”): ты подставишь ваши реальные определения `ToeplitzMatrix`, `T_P`, `rayleighQuotient` и т.п.

### (A) Rayleigh core → lower bound
```lean
-- Rayleigh quotient on Fin n vectors
noncomputable def rayleighQuotient {n : ℕ} (A : Matrix (Fin n) (Fin n) ℝ)
  (v : Fin n → ℝ) : ℝ :=
  (∑ i, ∑ j, v i * A i j * v j) / (∑ i, (v i)^2)

-- If quadratic form dominates m * ‖v‖^2, then Rayleigh quotient ≥ m
lemma rayleighQuotient_ge_of_quad_ge {n : ℕ} {A : Matrix (Fin n) (Fin n) ℝ} {m : ℝ}
  (hA : ∀ v : Fin n → ℝ, (∑ i, ∑ j, v i * A i j * v j) ≥ m * (∑ i, (v i)^2)) :
  ∀ v, v ≠ 0 → rayleighQuotient A v ≥ m := by
  -- standard algebra; use `field_simp` + positivity of denominator
  sorry
```

### (B) Toeplitz quadratic form identity (у вас уже есть)
```lean
-- Abstract form: Toeplitz form = integral of symbol times |p|^2
-- You already have this as "Toeplitz quadratic form (Rayleigh core)".
theorem toeplitz_quad_form_eq_integral
  (M : ℕ) (P_A : ℝ → ℝ) (p : TrigPoly) :
  ⟪T_M P_A p, p⟫ = ∫ θ in (Set.Icc (-1/2:ℝ) (1/2)), P_A θ * ‖p.eval θ‖^2 := by
  sorry
```

### (C) From pointwise floor to eigenvalue/Rayleigh lower bound
Если тебе не хочется вводить `λ_min`, можно везде работать на уровне Rayleigh quotient:

```lean
-- Pointwise bound implies lower bound on Toeplitz Rayleigh quotients
theorem toeplitz_rayleigh_ge_of_symbol_ge
  (M : ℕ) (P_A : ℝ → ℝ) (c : ℝ)
  (hP : ∀ θ ∈ Set.Icc (-1/2:ℝ) (1/2), c ≤ P_A θ) :
  ∀ v, v ≠ 0 → rayleighQuotient (ToeplitzMatrix P_A M) v ≥ c := by
  -- rewrite quadratic form as integral and use `integral_mono` + `hP`
  sorry
```

### (D) Weyl-type step via operator norm (matrix bound)
```lean
-- Generic inequality: |⟪Bv,v⟫| ≤ ‖B‖ * ‖v‖^2, hence Rayleigh(A-B) ≥ Rayleigh(A) - ‖B‖
theorem rayleigh_sub_ge
  {n : ℕ} (A B : Matrix (Fin n) (Fin n) ℝ) :
  ∀ v, v ≠ 0 →
    rayleighQuotient (A - B) v ≥ rayleighQuotient A v - ‖(Matrix.toLinearMap B)‖ := by
  sorry
```

### (E) A3 bridge closure (конкретно под ваши константы)
```lean
noncomputable def c_star : ℝ := (11:ℝ) / 10

theorem A3_bridge_closure_no_SB
  (M : ℕ) (P_A : ℝ → ℝ) (T_P : Matrix (Fin M) (Fin M) ℝ)
  (h_floor : ∀ θ ∈ Set.Icc (-1/2:ℝ) (1/2), c_star ≤ P_A θ)
  (h_cap : ‖(Matrix.toLinearMap T_P)‖ ≤ c_star/4) :
  ∀ v, v ≠ 0 →
    rayleighQuotient (ToeplitzMatrix P_A M - T_P) v ≥ (3*c_star)/4 := by
  -- combine toeplitz_rayleigh_ge + rayleigh_sub_ge
  -- finish with `nlinarith`
  sorry
```

Если по API вам удобнее цель `≥ c_star/4`, просто ослабь конец через `have : (3*c_star)/4 ≥ c_star/4 := by nlinarith`.

---

## 4. Если ты всё равно хочешь “формализовать SB”: два уровня

### Уровень 0 (тривиальный SB как королларий — рекомендую, если нужен просто чекбокс)
Это буквально то, что написано в v4: SB optional и следует из Rayleigh, так как \(\omega_\sigma\ge 0\)【293:2†PROSHKA_REQUEST_3.md†L56-L60】【285:0†PROSHKA_REQUEST_3.md†L12-L16】.

Lean-идея:

```lean
def modulus (σ : ℝ → ℝ) (h : ℝ) : ℝ := sSup (Set.range (fun θ => |σ (θ+h) - σ θ|))

lemma modulus_nonneg (σ : ℝ → ℝ) (h : ℝ) : 0 ≤ modulus σ h := by
  -- sSup of a set of nonnegative reals is nonnegative
  sorry

theorem szego_bottcher_trivial
  (M : ℕ) (σ : ℝ → ℝ) :
  lambda_min (ToeplitzMatrix σ M)
    ≥ (min_on_torus σ) - (4:ℝ) * modulus σ (1/(2*M)) := by
  have hRay : lambda_min (ToeplitzMatrix σ M) ≥ min_on_torus σ := by sorry
  have hmod : 0 ≤ modulus σ (1/(2*M)) := modulus_nonneg _ _
  -- then min σ ≥ min σ - 4*modulus ...
  nlinarith
```

### Уровень 1 (настоящий SB с константой 4 и оценкой через модуль)
Это уже **не про A3_bridge**, а про “правильную” Toeplitz‑теорию.

**Самый Lean-реалистичный маршрут:** *через аппроксимацию циркулянтом* (Strang-type):
1) Определяешь циркулянт \(C_M[\sigma]\), чьи собственные значения равны \(\sigma\) на равномерной сетке.  
2) Доказываешь \(\|T_M[\sigma]-C_M[\sigma]\|\le 4\,\omega_\sigma(1/(2M))\).  
3) Weyl: \(\lambda_{\min}(T)\ge \lambda_{\min}(C)-\|T-C\|\).  
4) \(\lambda_{\min}(C)=\min_{\text{grid}}\sigma\ge \min\sigma\).

**Зависимости, которые реально понадобятся:**
- `LinearAlgebra` (матрицы, нормы, спектр/самосопряжённость)  
- конструкция и свойства DFT/унитарной матрицы (если нет готового — придётся пилить)  
- оценка нормы разности по модулю непрерывности (аналитика).

Это большой кусок, и он точно тяжелее, чем весь A3_bridge по варианту A.

---

## A1_density: поддержка (hg_supp) — правильный фикс

Теперь про твою исходную “URGENT” проблему.

### Феномен
AtomCone_K требует `support g ⊆ [-K,K]`, а твой Atom с центром τ и шириной B имеет поддержку примерно на \([τ-B,τ+B]\cup[-τ-B,-τ+B]\).  
Если разрешать просто τ∈[-K,K] и B≤K, то поддержка уедет в \([-K-B,K+B]\). Это **реально** ломает `hg_supp`.

### Лучший вариант: Option 2 (margin condition)
И это уже зафиксировано в v4:  
Atoms в A1′ ограничиваются условием **\(|\tau|+B\le K\)**, чтобы support оставался в \([-K,K]\)【293:2†PROSHKA_REQUEST_3.md†L66-L71】.

**Почему это лучший вариант:**
- он чистый (без “технических хвостов” типа truncation heat kernel),
- он совместим с вашей структурой W_K,
- он ровно то, что стоит в “current plan”.

### Ключевой факт, который спасает плотность при margin
Если \(\Phi\in W_K\) и \(\Phi\) непрерывна и `support ⊆ Icc(-K,K)`, то автоматически  
\(\Phi(-K)=\Phi(K)=0\) (континуальность + вне интервала всё 0).  
Значит тебе **не нужна** масса “центрированных у границы” атомов: можно аппроксимировать значимые места функциями, чья поддержка доходит до границы, но не вылезает.

### Lean-стейтменты для `hg_supp`
Ты хочешь закрыть `hg_supp` (support containment). Минимальный набор лемм:

```lean
-- Fejer hat (compact support)
lemma fejer_eq_zero_of_abs_ge {B x : ℝ} (hB : 0 < B) (hx : B ≤ |x|) :
  FejerKernel B x = 0 := by
  -- from definition max(0, 1 - |x|/B)
  sorry

lemma support_fejer_shift_subset {B τ : ℝ} (hB : 0 < B) :
  Function.support (fun x => FejerKernel B (x - τ))
    ⊆ Set.Icc (τ - B) (τ + B) := by
  intro x hx
  -- contrapositive: if x < τ-B or τ+B < x then |x-τ| ≥ B → kernel=0
  sorry

-- product support ⊆ intersection; heat has full support so just keep fejer
lemma support_mul_subset_left {f g : ℝ → ℝ} :
  Function.support (fun x => f x * g x) ⊆ Function.support f := by
  intro x hx
  -- if product ≠0 then f x ≠0
  exact fun hf => hx (by simp [hf])

-- support of sum ⊆ union (always true)
lemma support_add_subset {f g : ℝ → ℝ} :
  Function.support (fun x => f x + g x) ⊆ Function.support f ∪ Function.support g := by
  intro x hx
  by_contra h
  -- if f x =0 and g x =0 then sum=0
  have hf : f x = 0 := by
    have : x ∉ Function.support f := by
      -- extract from h
      sorry
    simpa [Function.support] using this
  have hg : g x = 0 := by sorry
  exact hx (by simp [hf, hg])

-- the margin lemma you really need:
lemma support_atom_subset_Icc
  {K B t τ : ℝ} (hB : 0 < B) (hmargin : |τ| + B ≤ K) :
  Function.support (Atom B t τ) ⊆ Set.Icc (-K) K := by
  -- Atom = term(τ) + term(-τ)
  -- each term support ⊆ Icc(±τ-B, ±τ+B)
  -- margin gives ±τ±B ∈ [-K,K]
  sorry
```

### Про “Option 3: truncation” и error bounds
Скажу жёстко: **тебе это не нужно** для `hg_supp`, потому что поддержка задаётся Fejér-частью, не heat-частью (умножение не расширяет support).  
Option 3 только добавит:
- дополнительный параметр `R`,
- леммы про ошибку \(\|H_t - H_t\mathbf 1_{|x|\le R}\|\),
- перенос ошибки в норму аппроксимации.

Если всё-таки хочешь оценку (например, для будущих задач), стандартный суп-норм bound такой:  
если \(\tilde H_t(x)=H_t(x)\mathbf 1_{|x|\le R}\), то для атома вида \(\Lambda_B(\cdot-\tau)H_t(\cdot-\tau)\):
\[
\|\Lambda_B(\cdot-\tau)(H_t(\cdot-\tau)-\tilde H_t(\cdot-\tau))\|_\infty
\le \|\Lambda_B\|_\infty \sup_{|x-\tau|>R} H_t(x-\tau).
\]
А \(\|\Lambda_B\|_\infty=1\) и \(H_t(y)\le C_t e^{-y^2/(4t)}\). Значит:
\[
\le C_t e^{-R^2/(4t)}.
\]
Но повторюсь: это вообще не нужно, чтобы “попасть” в `support ⊆ [-K,K]`.

---

## Про Aristotle: “информальщина vs sandbox”

Твои наблюдения совпадают с тем, что у вас уже записано: sandbox с фиксированными сигнатурами может “зажать” решение, а pure informal даёт свободу переформулировать цель. Это прямо коррелирует с тем, что Aristotle принимает только Mathlib и не принимает project-imports/axioms【293:4†SANDBOX_CHALLENGE.md†L9-L21】.

Практическое правило (жёсткое, но рабочее):
- **Большие мосты / архитектурные теоремы** (типа “SB”, “A1 density главный итог”) → *pure informal* + чёткий список инвариантов/DO NOT DO (как у вас в PROSHKA_REQUEST).  
- **Маленькие изолированные леммы** (support, triangle inequality chain, comparisons типа `1/25 ≤ 11/40`) → sandbox на Mathlib-only.

---

## Конкретный план действий (минимум движений)

1) Для **A3_bridge_axiom**:  
   - выкинь SB из обязательных зависимостей (он optional)【293:2†PROSHKA_REQUEST_3.md†L56-L60】;  
   - докажи `λ_min(T_M[P_A]) ≥ c_*` через Rayleigh + floor;  
   - докажи `‖T_P‖ ≤ c_*/4` из cap `ρ(1)<1/25` + `norm_num`;  
   - склей через `λ_min(A-B) ≥ λ_min(A) - ‖B‖`.  
   Это ровно то, что у вас в §5 плана【293:6†PROSHKA_REQUEST_3.md†L17-L27】.

2) Для **A1_density hg_supp**:  
   - внедри margin condition \(|\tau|+B\le K\) в определение AtomCone_K / генераторов (это уже в v4)【293:2†PROSHKA_REQUEST_3.md†L66-L71】;  
   - закрой `support_atom_subset_Icc` как выше.

Если хочешь, я могу следующим сообщением прямо набросать *супер-конкретный “Lean proof skeleton”* для `support_atom_subset_Icc` (с `simp`, `by_cases`, `linarith`) — это обычно закрывается быстро и стабильно.

## USER
 Запрос к Прошке                                                                                                                                                        
                                                                                                                                                                         
  Контекст:                                                                                                                                                              
  V3 Aristotle доказал A3_bridge с placeholder'ами:                                                                                                                      
  - P_A := fun _ => c_star (константа)                                                                                                                                   
  - T_P := 0 (нулевая матрица)                                                                                                                                           
                                                                                                                                                                         
  Общие леммы доказаны:                                                                                                                                                  
  1. rayleigh_lower_bound: Toeplitz с символом P ≥ m даёт Rayleigh ≥ m                                                                                                   
  2. quadform_sub_ge: если S ≥ c×||v||² и R ≤ (c/4)×||v||², то S-R ≥ (3c/4)×||v||²                                                                                       
                                                                                                                                                                         
  Реальные определения Q3:                                                                                                                                               
  -- Toeplitz (a_star это символ)                                                                                                                                        
  ToeplitzMatrix M a_star i j = a_star ((i-j) * π / M)                                                                                                                   
                                                                                                                                                                         
  -- RKHS matrix T_P                                                                                                                                                     
  T_P t i j = sqrt(w_RKHS i) * sqrt(w_RKHS j) * exp(-(xi_n i - xi_n j)² / (4t))                                                                                          
                                                                                                                                                                         
  -- Weights                                                                                                                                                             
  w_RKHS n = vonMangoldt(n) / sqrt(n)                                                                                                                                    
  w_max = 2/e ≈ 0.7358                                                                                                                                                   
                                                                                                                                                                         
  -- Floor                                                                                                                                                               
  c_star = 11/10 = 1.1                                                                                                                                                   
                                                                                                                                                                         
  Проблема:                                                                                                                                                              
  A3_bridge_uniform аксиома использует индексы i, j : Fin M, но w_RKHS и xi_n определены для ℕ. Для большинства i ∈ {0,1,...,M-1}, vonMangoldt(i) = 0 (не prime power).  
                                                                                                                                                                         
  Вопросы к Прошке:                                                                                                                                                      
  1. Как правильно интерпретировать T_P матрицу в A3_bridge? Она должна быть над Nodes (prime powers) или над Fin M?                                                     
  2. Если Toeplitz над Fin M а T_P имеет sparse structure (большинство w_i = 0), как это влияет на bound?                                                                
  3. Какой минимальный результат нужно доказать чтобы закрыть A3_bridge_uniform?                                                                                         
                                                                                                                                      

## ASSISTANT
Смотрю на твой стек — и тут есть **очень важный “сигнал-анома́лия”**: ты говоришь “A3_bridge заблокирован на Szegő–Böttcher”, но в актуальном пакете требований прямо написано *не делать SB блокером* и закрываться через **Rayleigh**. Это кардинально меняет план формализации. 【303:0†PROSHKA_REQUEST_3.md†L11-L14】【303:9†PROSHKA_REQUEST_3.md†L49-L55】

Ниже — разбор и практический маршрут: **как закрыть A3_bridge без SB**, что делать если SB всё же нужен “для формы”, и как лучше жить с Aristotle (informal vs sandbox) без того, чтобы он застревал на сигнатурах.

---

## 1) Контекст и феномены

### Феномен A: “SB как блокер” vs “SB опционален”
В PROSHKA_REQUEST v4 зафиксировано:

- Rayleigh core: \(\lambda_{\min}(T_M[P_A]) \ge \min P_A\) **и SB не нужен**. 【303:4†PROSHKA_REQUEST_3.md†L45-L60】
- Более того, там прямо стоит запрет “не требовать SB как блокер”. 【303:0†PROSHKA_REQUEST_3.md†L26-L33】【303:3†PROSHKA_REQUEST_3.md†L61-L67】

То есть твоя “блокировка” — почти наверняка **артефакт неправильной формулировки цели/сигнатуры** в Lean (или наследие старого плана).

### Феномен B: sandbox vs pure informal
Ты уже поймал правильную эмпирику: sandbox фиксирует сигнатуру → если сигнатура не “по зубам” тактикам/поиску, Aristotle стагнирует.

Фактические ограничения системы тоже жёсткие:

- Aristotle **не может импортировать твой проект**, только Mathlib. 【303:8†SANDBOX_CHALLENGE.md†L9-L16】
- Он **отвергает пользовательские axioms** (и любые “замаскированные” `constant/opaque` без тела будут тем же по сути). 【303:8†SANDBOX_CHALLENGE.md†L13-L16】
- Разрешены только стандартные axioms вроде `propext`, `Classical.choice`, `Quot.sound`. 【303:6†SANDBOX_CHALLENGE.md†L18-L23】

---

## 2) Определения (минимум, чтобы не было скрытых допущений)

### 2.1. Что реально нужно для A3_bridge (по текущему плану)
Нужна связка:

1) **Floor:** \(P_A(\theta) \ge c_* = 11/10\) на \(\mathbb T=[-1/2,1/2]\). 【303:4†PROSHKA_REQUEST_3.md†L76-L79】

2) **Rayleigh:** \(\lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in\mathbb T} P_A(\theta)\). 【303:4†PROSHKA_REQUEST_3.md†L51-L60】

3) **RKHS cap:** \(\|T_P\| \le c_*/4\). В v4 даже сильнее: при \(t_{\mathrm{rkhs}}\ge 1\) уже \(\|T_P\|\le \rho(1) < 1/25\). 【303:4†PROSHKA_REQUEST_3.md†L81-L85】【303:9†PROSHKA_REQUEST_3.md†L37-L41】

Тогда
\[
\lambda_{\min}(T_M[P_A]-T_P)\ \ge\ c_* - \|T_P\|\ \ge\ 3c_*/4 > 0.
\]
Это прямо написано как целевой вывод. 【303:3†PROSHKA_REQUEST_3.md†L19-L27】

### 2.2. Что такое “SB” в вашем контексте
В тексте статьи есть SB-барьер с модулем непрерывности (как “контроль дрейфа”). 【303:1†RH_Q3.pdf†L49-L66】  
Но в рабочем запросе v4 он помечен как **optional** и даже как *слабое следствие* Rayleigh, потому что \(\omega_\sigma\ge 0\). 【303:3†PROSHKA_REQUEST_3.md†L7-L14】【303:4†PROSHKA_REQUEST_3.md†L56-L61】

---

## 3) Вывод по математике: **SB в Lean лучше не формализовать**, если цель — закрыть A3_bridge

### 3.1. Самый дешёвый маршрут закрытия A3_bridge
**Не трогай Szegő–Böttcher.** Делай так:

- Доказываешь/используешь (у тебя уже есть) Rayleigh-лемму “Toeplitz quadratic form → integral → lower bound”. 【303:4†PROSHKA_REQUEST_3.md†L45-L54】
- Подключаешь A3_FLOOR \(P_A \ge 11/10\). 【303:4†PROSHKA_REQUEST_3.md†L76-L79】
- Подключаешь RKHS cap \(\|T_P\| \le 1/25\) при \(t_{\mathrm{rkhs}}\ge 1\). 【303:4†PROSHKA_REQUEST_3.md†L81-L85】

И дальше одна строка:
\[
\frac{\langle v,(T_M[P_A]-T_P)v\rangle}{\langle v,v\rangle}
\ge c_* - \|T_P\| \ge c_* - 1/25.
\]
А \(c_* - 1/25 = 11/10 - 1/25 = 275/250 - 10/250 = 265/250 = 1.06\), что намного больше \(c_*/4=11/40=0.275\).

**То есть “запас” гигантский** — это ещё один сигнал: если в Lean это не закрывается, значит проблема почти наверняка не в анализе, а в **сигнатуре/типах/определениях** (например, Fin vs Nat или неправильная Toeplitz-дефиниция).  

### 3.2. Если тебе “нужно SB” только чтобы соответствовать бумаге
Тогда делай **формально тривиальную** версию:

\[
\lambda_{\min}(T_M[\sigma]) \ge \min \sigma \ge \min \sigma - 4\,\omega_\sigma(1/(2M)).
\]

Это ровно то, что в v4 предлагается: считать SB “слабым королларием” Rayleigh. 【303:3†PROSHKA_REQUEST_3.md†L7-L14】【303:9†PROSHKA_REQUEST_3.md†L49-L55】

То есть SB-лемма в Lean становится *однострочной*: применяешь Rayleigh, потом `linarith` с неотрицательностью модуля.

---

## 4) Lean-заготовки: какие теоремы реально писать

Я дам **Lean-ready statements** в стиле “минимум, чтобы закрыть мост”. Подстрой имена под ваши реальные defs, но форма должна быть такая.

### 4.1. Rayleigh lower bound (ядро, без SB)
```lean
-- σ : 𝕋 → ℝ, Toeplitz matrix built from σ (your definition)
theorem rayleigh_lower_bound
  {M : ℕ} (hM : 0 < M)
  {σ : ℝ → ℝ} {m : ℝ}
  (hσ : ∀ θ ∈ Set.Icc (- (1/2:ℝ)) (1/2), m ≤ σ θ) :
  ∀ v : Fin M → ℝ, v ≠ 0 →
    (∑ i, ∑ j, v i * (Tσ M i j) * v j) / (∑ i, (v i)^2) ≥ m := by
  -- uses toeplitz_quadform = ∫ σ |p|^2 and Parseval
  ...
```

Ключевой момент: **Tσ должно быть тем Toeplitz**, для которого уже есть “Toeplitz quadratic form = integral” (Rayleigh core). 【303:4†PROSHKA_REQUEST_3.md†L45-L54】

### 4.2. “SB optional” как королларий
```lean
def modulus (σ : ℝ → ℝ) (h : ℝ) : ℝ := -- ω_σ(h)
  sSup {r | ∃ x y, x ∈ Icc (-1/2) (1/2) ∧ y ∈ Icc (-1/2) (1/2) ∧ |x-y| ≤ h ∧ r = |σ x - σ y|}

lemma modulus_nonneg (σ) (h) : 0 ≤ modulus σ h := by
  -- by definition: supremum of nonneg set
  ...

theorem szego_bottcher_optional
  {M : ℕ} (hM : 0 < M) {σ : ℝ → ℝ} :
  λmin (Tσ M) ≥ (sInf (Set.range σ)) - (4:ℝ) * modulus σ (1/(2*M)) := by
  have hRay : λmin (Tσ M) ≥ sInf (Set.range σ) := by
    -- from rayleigh_lower_bound
    ...
  have hω : 0 ≤ modulus σ (1/(2*M)) := modulus_nonneg σ _
  linarith
```

Если у вас \(\min\) реализован не через `sInf (Set.range σ)`, а через `∀θ, ...` — аналогично.

### 4.3. A3_bridge closure (как оно должно выглядеть по сути)
```lean
theorem A3_bridge_uniform
  (c_star : ℝ) (hc : 0 < c_star)
  (hPA : ∀ θ ∈ Icc (-1/2:ℝ) (1/2), c_star ≤ P_A θ)
  (hTP : ‖T_P t_rkhs M‖ ≤ c_star/4) :
  ∀ v : Fin M → ℝ, v ≠ 0 →
    (quadform (T_PA M - T_P t_rkhs M) v) / (∑ i, (v i)^2) ≥ c_star/4 := by
  -- rayleigh gives ≥ c_star for Toeplitz part
  -- operator norm gives ≤ c_star/4 for prime part
  -- combine by inequality ⟨v,Av⟩ ≥ a‖v‖² and |⟨v,Bv⟩| ≤ ‖B‖‖v‖²
  ...
```

И тут важно: RKHS cap можно брать как \(\rho(1) < 1/25\), если у вас это уже в Tier-2. 【303:4†PROSHKA_REQUEST_3.md†L81-L85】

---

## 5) “Fin M vs ℕ” в T_P: как это правильно интерпретировать

Ты описал проблему точно: Toeplitz матрица у вас над `Fin M`, а веса/узлы для RKHS определены над `ℕ`. Это типовая “просадка” в Lean.

Самый простой интерфейс (без философии “узлы = prime powers”):

1) **Определяешь** функции на `Fin M` через коэрцию в `ℕ`:
```lean
def wFin (M : ℕ) (i : Fin M) : ℝ := w_RKHS (i.1)      -- или (i.1+1), зависит от вашей индексации
def xiFin (M : ℕ) (i : Fin M) : ℝ := xi_n (i.1)
```

2) **Тогда**:
```lean
def T_P_fin (t : ℝ) (M : ℕ) : Matrix (Fin M) (Fin M) ℝ :=
fun i j => Real.sqrt (wFin M i) * Real.sqrt (wFin M j) *
  Real.exp (-(xiFin M i - xiFin M j)^2 / (4*t))
```

3) И дальше RKHS cap доказываешь для этой `T_P_fin`.  
То, что большинство `w_RKHS n = 0` для не-prime-power, **помогает**, но даже если не использовать разреженность, cap из \(\rho(1)\) уже достаточно сильный. 【303:4†PROSHKA_REQUEST_3.md†L81-L85】

Если ты хочешь “чисто математически” узлы = prime powers, это отдельный тип `Node M` и биекция `Node M ↪ ℕ`. Но это усложнение не нужно, если цель — операторная норма/квадратичная форма.

---

## 6) Что делать с Aristotle: мой практический совет

### 6.1. Да, pure informal часто лучше — и это объяснимо
Когда задача сложная, **главная трудность — правильно выбрать формулировку** (сигнатуру, нужные леммы, уровень абстракции). Pure informal даёт Aristotle свободу сам выбрать удобный statement и даже поменять типы (`ℝ`↔`ℂ`, `Fin`↔`Nat`, `Matrix`↔`LinearMap`) и потом уже доказать.

Sandbox фиксирует всё — и если хоть один выбор “неудачный”, он будет выколачивать вспомогательные леммы и не сможет сомкнуть “main theorem”.

### 6.2. Но sandbox всё равно нужен — только в другом режиме
Вот рабочая схема:

**Режим 1: “поиск формулировки” (pure informal)**  
- Попроси: “дай Lean-формулировку + proof, можешь менять вспомогательные определения, но не переопределяй Q3-defs”.  
(про “не переопределяй” у вас уже есть явная ловушка) 【303:12†PROWKA_BRIEF.md†L7-L13】

**Режим 2: “производство” (sandbox, но с минимальными фиксациями)**  
- Ты сам выбираешь *одну* удачную сигнатуру и просишь доказать ровно её.
- Sandbox должен быть **Mathlib-only** без своих axioms, иначе verification режет. 【303:8†SANDBOX_CHALLENGE.md†L13-L16】

### 6.3. “Хак: opaque/constant вместо axiom” — почти наверняка мимо
С точки зрения kernel/verification, `constant my_fact : P` и `axiom my_fact : P` — это одно и то же: новая недоказанная декларация. В вашем собственном документе это уже как гипотеза/эксперимент, но ожидаемый исход: тоже будет “Unexpected axioms”. 【303:6†SANDBOX_CHALLENGE.md†L52-L57】【303:8†SANDBOX_CHALLENGE.md†L13-L16】

---

## 7) Быстрая ремарка по A1_density (раз уж это тоже блокер)
В актуальном плане **дефиниционную проблему поддержки закрывают margin condition**:
\[
|\tau| + B \le K
\]
чтобы support оставался в \([-K,K]\). 【303:4†PROSHKA_REQUEST_3.md†L66-L71】【303:9†PROSHKA_REQUEST_3.md†L22-L27】

То есть твой `hg_supp` реально должен стать тривиальным после замены множества атомов.

---

## 8) Если вдруг реально нужна “нетривиальная” SB/дискретизация (редкий случай)
Тогда не лезь в детерминанты. Делай “matrix guard” в стиле:

1) Определи **идеальную** Toeplitz-матрицу \(T^{\mathrm{ideal}}\) (через Fourier/integral), где Rayleigh работает.

2) Докажи оценку нормы дрейфа:
\[
\|T^{\mathrm{actual}} - T^{\mathrm{ideal}}\| \le C_{SB}\,\omega(1/(2M)).
\]

3) Применяй Weyl:
\[
\lambda_{\min}(T^{\mathrm{actual}}) \ge \lambda_{\min}(T^{\mathrm{ideal}}) - \|T^{\mathrm{actual}} - T^{\mathrm{ideal}}\|.
\]

Но повторюсь: по текущему v4 это **не должно быть блокером**. 【303:3†PROSHKA_REQUEST_3.md†L7-L14】

---

## Bottom line
- **Лучшее решение для Lean сейчас:** выкинуть SB из критического пути и закрывать A3_bridge через Rayleigh + floor + RKHS cap (с огромным запасом). 【303:4†PROSHKA_REQUEST_3.md†L45-L54】【303:4†PROSHKA_REQUEST_3.md†L81-L85】
- **SB можно оставить “для бумаги” как тривиальный королларий**, без реальной теории Toeplitz-детерминантов. 【303:9†PROSHKA_REQUEST_3.md†L49-L55】
- **Про Aristotle:** pure informal для сложных штук, sandbox — только для “узких” лемм и уже оптимальных сигнатур; никаких axioms/constant/opaque без тела он не примет. 【303:8†SANDBOX_CHALLENGE.md†L9-L16】【303:6†SANDBOX_CHALLENGE.md†L18-L23】

Если хочешь, я могу прямо “причесать” одну целевую сигнатуру `A3_bridge_uniform` так, чтобы она:
1) не использовала `λmin` (чтобы не тащить спектральную теорию),
2) работала через “∀ v, quadform ≥ …”,
3) минимально затрагивала `Fin M` vs `Nat` (через `wFin/xiFin` как выше).

## USER
Запрос к Прошке: Uniform t — возможен или нет?                                                                                                                         
                                                                                                                                                                         
  Контекст                                                                                                                                                               
                                                                                                                                                                         
  Aristotle V1 (A3_bridge_closure_v1.lean, project 4c2ed336) завершился и доказал:                                                                                       
                                                                                                                                                                         
  lemma exists_t_max_row_sum_le_for_M (M : ℕ) :                                                                                                                          
    ∃ t > 0, max_row_sum M t ≤ 3 * c_star / 4                                                                                                                            
                                                                                                                                                                         
  Интерпретация: Для каждого ФИКСИРОВАННОГО M существует свой t(M) такой что ||T_P(t(M))|| ≤ 3c*/4.                                                                      
                                                                                                                                                                         
  V1 также написал в комментариях:                                                                                                                                       
  "numerical and analytical evidence suggests the operator norm of T_P is unbounded for fixed t as M grows, making the main theorem likely false as stated"              
                                                                                                                                                                         
  Проблема                                                                                                                                                               
                                                                                                                                                                         
  Аксиома A3_bridge_data K сформулирована так:                                                                                                                           
  def A3_bridge_data (K : ℝ) : Prop :=                                                                                                                                   
    ∃ M₀ : ℕ, ∃ t > 0, ∀ M ≥ M₀,  -- ОДИН t для ВСЕХ M ≥ M₀                                                                                                              
      ∀ (v : Fin M → ℝ), v ≠ 0 →                                                                                                                                         
      (Toeplitz - T_P) / ||v||² ≥ c_arch K / 4                                                                                                                           
                                                                                                                                                                         
  Здесь требуется UNIFORM t — один t который работает для всех M ≥ M₀.                                                                                                   
                                                                                                                                                                         
  Противоречие:                                                                                                                                                          
  - Аксиома требует: ∃ t, ∀ M ≥ M₀: bound                                                                                                                                
  - V1 доказал: ∀ M, ∃ t(M): bound                                                                                                                                       
  - V1 утверждает: для fixed t, ||T_P|| → ∞ при M → ∞                                                                                                                    
                                                                                                                                                                         
  Вопросы к Прошке                                                                                                                                                       
                                                                                                                                                                         
  1. Uniform t возможен или нет?                                                                                                                                         
    - V1 говорит что нет (norm unbounded for fixed t)                                                                                                                    
    - Но может V1 использует неоптимальный подход?                                                                                                                       
    - Есть ли другой способ получить uniform bound?                                                                                                                      
  2. Почему t(M) → 0 при M → ∞?                                                                                                                                          
    - Это из-за количества off-diagonal terms?                                                                                                                           
    - Или из-за spacing между nodes?                                                                                                                                     
    - Можно ли это обойти?                                                                                                                                               
  3. Аксиома неправильно сформулирована?                                                                                                                                 
    - Может правильная формулировка: ∀ M, ∃ t(M): bound?                                                                                                                 
    - Это уже доказано в V1!                                                                                                                                             
  4. Как M связан с K в реальном применении?                                                                                                                             
    - В T5_Transfer аксиома применяется для фиксированного K                                                                                                             
    - Размер Toeplitz матрицы M связан с количеством nodes в [-K, K]?                                                                                                    
    - Если M = |Nodes(K)| для фиксированного K, то M фиксирован?                                                                                                         
  5. Backup plan: можно ли переформулировать?                                                                                                                            
    - Если uniform невозможен, как изменить аксиому?                                                                                                                     
    - ∀ K ≥ 1, ∀ M : ℕ, ∃ t > 0: bound — достаточно для main proof?                                                                                                      
                                                                                                                                                                         
  Имеющиеся результаты (для справки)                                                                                                                                     
                                                                                                                                                                         
  Из V1:                                                                                                                                                                 
  - w_RKHS_le_w_max: w_RKHS(n) ≤ w_max = 2/e ✓                                                                                                                           
  - w_max_lt_three_quarters_c_star: w_max < 3c*/4 ✓                                                                                                                      
  - T_P_tendsto_zero_of_ne: T_P(i,j,t) → 0 as t → 0 for i≠j ✓                                                                                                            
  - exists_t_max_row_sum_le_for_M: ∀ M, ∃ t: bound ✓                                                                                                                     
                                                                                                                                                                         
  Из V3:                                                                                                                                                                 
  - rayleigh_lower_bound: Toeplitz ≥ c* (с placeholder P_A = const) ✓                                                                                                    
  - quadform_sub_ge: разность операторов ✓                                                                                                                               
                                                                                                                                                                         
  Суть вопроса                                                                                                                                                           
                                                                                                                                                                         
  Аксиома написана с uniform t, но V1 показывает что uniform t невозможен. Что делать?                                                                                   
                                                                                                     

## ASSISTANT
Смотри: **тебе почти наверняка НЕ нужно формализовывать “настоящую” Szegő–Böttcher (тем более про определители)**, чтобы закрыть `A3_bridge_axiom`.

В вашем актуальном протоколе (PROSHKA_REQUEST v4) это прямо зафиксировано:

- есть **Toeplitz quadratic form** (ядро Rayleigh‑моста),
- из него сразу следует **Rayleigh lower bound**  
  \(\lambda_{\min}(T_M[P_A]) \ge \min_{\theta\in\mathbb T} P_A(\theta)\),
- а классическая Szegő–Böttcher‑оценка с модулем непрерывности объявлена **optional** и «следует как королларий, потому что \(\omega_\sigma\ge0\)».【4:0†PROSHKA_REQUEST_3.md†L45-L60】【4:2†PROSHKA_REQUEST_3.md†L12-L16】

То есть **SB не блокер по дизайну**: “Do NOT require Szego‑Bottcher as a blocker (use Rayleigh bound)”【4:7†PROSHKA_REQUEST_3.md†L26-L33】.

Ниже — аккуратный разбор + что именно писать в Lean.

---

## 0. Теорема и статус

**Точная цель (в терминах bridge):**  
\[
\forall M\ \text{(достаточно большие, если хочешь)},\quad
\lambda_{\min}(T_M[P_A] - T_P^{(M)}) \ge c_*/4,
\]
где \(c_*=11/10\).

**Статус:** стандартная математика; **для Lean предлагаю обход без Szegő–Böttcher**: через Rayleigh‑представление Toeplitz‑формы.

---

## 1. Контекст: почему “Szegő–Böttcher” вообще всплыл

В статье (RH_Q3.pdf) действительно есть “Szegő–Böttcher barrier” с \(C_{SB}=4\) и модулем непрерывности【4:3†RH_Q3.pdf†L55-L79】 — но она используется как **один из путей** к нижней оценке \(\lambda_{\min}(T_M[P_A])\).

Однако у вас в PROSHKA_REQUEST_3 схема специально упрощена: **нижняя оценка Toeplitz‑блока берётся напрямую Rayleigh‑неравенством**, без дискретизационного “барьера”【4:0†PROSHKA_REQUEST_3.md†L51-L60】【4:2†PROSHKA_REQUEST_3.md†L49-L55】.

---

## 2. Ключевое определение: как правильно понимать \(T_P\) (и почему у вас “Fin M vs ℕ” ломает всё)

Твоя текущая боль (“в A3_bridge индексы `i j : Fin M`, а веса `w_RKHS` и узлы `ξ_n` заданы на ℕ; большинство i не prime power”) — это **сигнал**, что вы смешали два разных пространства индексов.

Правильная модель в тексте статьи такая:

- Toeplitz‑оператор \(T_M[P_A]\) действует **на пространстве тригонометрических многочленов \(P_M\)** (Fourier‑моды \(|k|\le M\)), как **компрессия** оператора умножения на символ \(P_A\).  
- “Prime operator” — это не матрица “по индексам n”, а **оператор на том же \(P_M\)**, полученный компрессией глобального \(T_P\).  
- И он записан как **сумма rank‑one проекторов** \(|v_n^{(M)}\rangle\langle v_n^{(M)}|\) с нормировкой \(1/\sqrt{2M+1}\).【4:4†RH_Q3.pdf†L33-L100】

Цитата по сути (без дословного цитирования): \(v_n^{(M)}(\theta)\) — нормированная Dirichlet‑пачка; тогда каждый rank‑one имеет норму 1, и **норма \(T_P^{(M)}\)** сразу ограничивается суммой весов (или трассой). Это прямо написано в Lemma 8.8 (norm bound “immediate from triangle inequality”).【4:4†RH_Q3.pdf†L69-L100】

### Почему это важно (анализ “аномалии”)
Если ты вместо нормированного \(v_n^{(M)}\) берёшь “сырая” пачка без \(1/\sqrt{2M+1}\), то rank‑one куски будут иметь норму порядка \(2M+1\), и тогда действительно можно “увидеть” рост нормы с M — ровно то, что ваш Aristotle V1 заподозрил. Это **не фундаментальная невозможность uniform‑t**, а дефект реализации/нормировки.

---

## 3. Выбор варианта: что лучше формализовать в Lean

### Вариант A (лучший): **вообще не формализовать Szegő–Böttcher**
**Почему это оптимально:**
- У вас уже зафиксировано: Rayleigh‑представление Toeplitz формы и Rayleigh lower bound дают \(\lambda_{\min}(T_M[P_A]) \ge \min P_A\).【4:0†PROSHKA_REQUEST_3.md†L45-L54】
- Дискретизация / SB — optional: “No \(M_0\) required… treat SB as weaker corollary”.【4:2†PROSHKA_REQUEST_3.md†L49-L55】
- Дальше A3 bridge закрывается просто:  
  A3 floor \(P_A\ge c_*\), RKHS cap \(\|T_P\|\le c_*/4\) ⇒ \(\lambda_{\min}(T_M[P_A]-T_P)\ge 3c_*/4\) и тем более \(\ge c_*/4\).【4:2†PROSHKA_REQUEST_3.md†L59-L69】

Это самый короткий и “Lean‑friendly” путь.

### Вариант B: “Сохранить вид SB‑леммы”, но доказать её **как королларий из Rayleigh**
Если кому-то в цепочке “очень хочется” видеть именно строку вида
\[
\lambda_{\min}(T_M[\sigma]) \ge \min\sigma - 4\omega_\sigma(1/(2M)),
\]
то это делается без “настоящего SB”:

- из Rayleigh: \(\lambda_{\min}(T_M[\sigma]) \ge \min\sigma\),
- \(\omega_\sigma(\cdot)\ge0\),
- значит \(\min\sigma \ge \min\sigma - 4\omega_\sigma(\cdot)\).

И всё. Это ровно указано в PROSHKA_REQUEST_3 как допустимая тактика【4:2†PROSHKA_REQUEST_3.md†L49-L55】.

### Вариант C (не рекомендую): формализовать “реальный” SB (Böttcher–Silbermann / Grenander–Szegő)
Это огромная задача: нужно строить инфраструктуру Toeplitz‑матриц/операторов, модуль непрерывности, аппроксимацию Fejér ядром, оценку спектра через circulant/Fejér/Гершгорин, и затем аккуратно выводить константу 4. Для проекта “закрыть аксиомы” — это оверкилл.

---

## 4. Полный proof sketch для выбранного пути (Rayleigh-only)

### 4.1. Toeplitz‑часть
1) Из A3_FLOOR:  
\[
\forall \theta\in\mathbb T,\quad P_A(\theta)\ge c_*.
\]【4:0†PROSHKA_REQUEST_3.md†L76-L80】

2) Из Toeplitz quadratic form:
\[
\langle T_M[P_A]p,p\rangle = \int_{\mathbb T} P_A(\theta)|p(\theta)|^2\,d\theta.
\]【4:0†PROSHKA_REQUEST_3.md†L45-L49】

3) Тогда
\[
\langle T_M[P_A]p,p\rangle \ge c_* \int_{\mathbb T}|p(\theta)|^2\,d\theta = c_*\,\|p\|_{L^2}^2.
\]

Следовательно \(\lambda_{\min}(T_M[P_A]) \ge c_*\).【4:0†PROSHKA_REQUEST_3.md†L51-L54】

### 4.2. Prime/RKHS‑часть
У вас в протоколе записано:

Для \(t_{\mathrm{rkhs}}\ge 1\),
\[
\|T_P\|\le \rho(1) < 1/25.
\]【4:0†PROSHKA_REQUEST_3.md†L81-L85】

И это именно **uniform**, без зависимости от M (смысл “uniform RKHS cap”).

### 4.3. Склейка
Для самосопряжённого \(A\) и PSD‑оператора \(B\):
\[
\lambda_{\min}(A-B) \ge \lambda_{\min}(A) - \|B\|.
\]

Берём \(A=T_M[P_A]\), \(B=T_P^{(M)}\) (компрессия/или тот же оператор на \(P_M\)).

Тогда
\[
\lambda_{\min}(T_M[P_A]-T_P^{(M)}) \ge c_* - \rho(1).
\]

Так как \(\rho(1) < 1/25\) и \(c_*=11/10\), то \(c_* - \rho(1)\) намного больше \(c_*/4=11/40\). В частности получаем требуемое \( \ge c_*/4\). (В PROSHKA_REQUEST_3 это записано ещё проще через \(\|T_P\|\le c_*/4\) ⇒ \(\lambda_{\min}\ge 3c_*/4\).)【4:2†PROSHKA_REQUEST_3.md†L59-L69】

---

## 5. Lean‑style формулировки (готовые “кирпичи”)

Ниже — именно то, что стоит дать Aristotle/внести в вашу codebase. Я пишу “Lean‑ready” (с максимально простыми типами), но без привязки к вашим точным именам.

### 5.1. Toeplitz quadratic form ⇒ Rayleigh

```lean
-- Torus as Icc (-1/2) (1/2), with Lebesgue measure
def Torus : Set ℝ := Set.Icc (- (1/2 : ℝ)) (1/2 : ℝ)

-- Abstract: T_M[P] is the Toeplitz operator on P_M with quadratic form representation
axiom toeplitz_quadform
  (M : ℕ) (P : ℝ → ℝ) (p : ???) :
  ⟪T_M P p, p⟫ = ∫ θ in Torus, P θ * ‖p θ‖^2

-- Rayleigh lower bound (this is the only thing you actually need)
theorem rayleigh_lower_bound
  (M : ℕ) (P : ℝ → ℝ) (m : ℝ)
  (hP : ∀ θ ∈ Torus, m ≤ P θ) :
  λ_min (T_M P) ≥ m := by
  -- standard: from quadform ≥ m‖p‖²
  ...
```

Но если у тебя уже есть `rayleigh_lower_bound` в `rayleigh_v1.lean`, **просто переиспользуй его** — и не раздувай инфраструктуру. (Это ровно “Toeplitz quadratic form + Rayleigh core” из протокола.)【4:0†PROSHKA_REQUEST_3.md†L45-L54】

### 5.2. “Szegő–Böttcher” как королларий (если нужен по форме)

```lean
-- modulus of continuity ωσ(δ) ≥ 0 (definition implies nonneg)
lemma modulus_nonneg (σ : ℝ → ℝ) (δ : ℝ) : 0 ≤ omega σ δ := by
  ...

-- SB-looking lemma with CSB = 4, derived trivially from Rayleigh
theorem szego_bottcher_corollary
  (M : ℕ) (σ : ℝ → ℝ) :
  λ_min (T_M σ) ≥ (sInf (Set.range σ)) - 4 * omega σ (1/(2*M)) := by
  have hR : λ_min (T_M σ) ≥ sInf (Set.range σ) := by
    -- from rayleigh_lower_bound with m = inf σ
    ...
  have hω : 0 ≤ 4 * omega σ (1/(2*M)) := by nlinarith [modulus_nonneg σ (1/(2*M))]
  linarith
```

Именно это написано как допустимое “weak corollary” в запросе【4:2†PROSHKA_REQUEST_3.md†L49-L55】.

### 5.3. Правильная модель \(T_P^{(M)}\) и norm bound

Если вы моделируете \(T_P^{(M)}\) как сумму rank‑one проекторов, то в Lean удобна лемма:

```lean
-- rank-one operator on an inner product space
def rankOne (v : H) : (H →L[ℂ] H) := ...

lemma opNorm_rankOne (v : H) :
  ‖rankOne v‖ = ‖v‖^2 := ...

-- If ‖v_n‖ = 1, then ‖∑ a_n rankOne v_n‖ ≤ ∑ |a_n|
theorem opNorm_sum_rankOne_le
  (s : Finset ι) (a : ι → ℝ) (v : ι → H)
  (hv : ∀ i ∈ s, ‖v i‖ = 1) :
  ‖∑ i in s, (a i) • (rankOne (v i))‖ ≤ ∑ i in s, |a i| := by
  -- triangle inequality + opNorm_rankOne
  ...
```

Это соответствует Lemma 8.8: “norm bound is immediate from triangle inequality applied to sum of rank-one projections”【4:4†RH_Q3.pdf†L69-L100】.

Но если у вас уже есть RKHS cap как отдельный доказанный модуль (“\(\|T_P\|\le\rho(1)<1/25\)”), то вообще можно не раскрывать rank‑one структуру в A3 bridge — просто использовать cap.【4:0†PROSHKA_REQUEST_3.md†L81-L85】

### 5.4. Склейка Toeplitz − Prime

```lean
-- General spectral inequality: λ_min(A - B) ≥ λ_min(A) - ‖B‖
theorem lambdaMin_sub_ge
  {A B : selfAdjointOperator H}
  (hB : 0 ≤ B) :
  λ_min (A - B) ≥ λ_min A - ‖B‖ := by
  ...

-- A3 bridge closure (simplified, no M0, uniform t from RKHS cap)
theorem A3_bridge_closure
  (M : ℕ)
  (h_floor : ∀ θ ∈ Torus, c_star ≤ P_A θ)
  (h_cap : ‖T_P‖ ≤ c_star / 4) :
  λ_min (T_M P_A - T_P) ≥ c_star / 4 := by
  have h_toep : λ_min (T_M P_A) ≥ c_star := rayleigh_lower_bound M P_A c_star h_floor
  have : λ_min (T_M P_A - T_P) ≥ c_star - ‖T_P‖ := by
    -- lambdaMin_sub_ge
    ...
  nlinarith
```

Ровно эта схема “A3 floor + Rayleigh + RKHS cap ⇒ positivity on generators” зафиксирована у вас в PROSHKA_REQUEST_3【4:2†PROSHKA_REQUEST_3.md†L59-L69】.

---

## 6. Минимальные зависимости в Mathlib (что реально нужно)

Если ты идёшь **Rayleigh-only**:

- интеграл по \([-1/2,1/2]\) (MeasureTheory),
- конечные суммы / тригонометрические многочлены (можно руками, без “богатой” Fourier‑машины),
- элементарная линейная алгебра/квадратичные формы и `‖·‖` операторов,
- `linarith/nlinarith` для числовых склеек.

Если захочешь “rank‑one decomposition” в Lean — нужна инфраструктура bounded linear operators на Hilbert space.

Если пытаться “настоящий SB” — это уже отдельный проект уровня “писать библиотеку Toeplitz theory”, я бы это **не делал**, пока есть прямой мост.

---

## 7. Про Aristotle: sandbox vs pure informal (и что делать)

Твой инсайт уже верный: **sandbox с фиксированными сигнатурами может убить поиск**, потому что он привязывает solver к неудачной формулировке. Pure informal даёт ему свободу переформулировать цель так, как proof search проходит легче.

С учётом того, что verification пропускает только Mathlib‑аксиомы, и новые axioms нельзя【4:12†SANDBOX_CHALLENGE.md†L16-L23】, я бы рекомендовал такой режим:

1) **Pure informal для “главных мостов”** (A3_bridge, A1′ density, etc).  
   Внутри markdown **не фиксируй** сигнатуру до `Fin M → ℝ` и т.п. — пусть он выберет удобный тип, а ты потом напишешь “adapter lemma”.

2) **Sandbox только для микро‑лемм**, которые:
   - изолированы,
   - не требуют тонкой постановки (типа `‖∑ rankOne‖ ≤ ∑ ‖rankOne‖`, `λ_min(A-B) ≥ ...`, неотрицательность модуля и т.д.).

3) Самое важное: **не давай Aristotle неправильные определения** (типа “T_P[i,j] = sqrt(w_i)sqrt(w_j)exp(-(...)/(4t))” на `Fin M`).  
   Это порождает “неравномерность по M” и ломает uniform‑t, хотя математически проблема должна решаться компрессией на \(P_M\).【4:4†RH_Q3.pdf†L33-L100】

---

## Итог (коротко)

- **Лучший путь:** закрывать A3_bridge через **Rayleigh lower bound + A3 floor + RKHS cap**, SB выкинуть как обязательную зависимость. Это прямо в вашем PROSHKA_REQUEST_3.【4:0†PROSHKA_REQUEST_3.md†L51-L60】【4:2†PROSHKA_REQUEST_3.md†L59-L69】
- Если тебе надо “SB‑строка” для совместимости — докажи её в Lean **трёхстрочным corollary** из Rayleigh, потому что \(\omega\ge0\).【4:2†PROSHKA_REQUEST_3.md†L12-L16】
- **Uniform t** не “невозможен”, а ломается при неверной модели \(T_P\); правильная модель — компрессия на \(P_M\) с нормировкой \(1/\sqrt{2M+1}\).【4:4†RH_Q3.pdf†L33-L100】【4:0†PROSHKA_REQUEST_3.md†L81-L85】

Если хочешь, я могу прямо переписать вашу текущую формулировку `A3_bridge_data` в “Rayleigh-first” виде так, чтобы она совпадала с PROSHKA_REQUEST_3 (и не требовала ни SB, ни `M₀`), и дать набор точечных лемм‑адаптеров между вашим текущим `Fin M`‑описанием и \(P_M\)‑описанием.

## USER
da переписать вашу текущую формулировку A3_bridge_data в “Rayleigh-first” виде так, чтобы она совпадала с PROSHKA_REQUEST_3 (и не требовала ни SB, ни M₀), и дать набор точечных лемм‑адаптеров между вашим текущим Fin M‑описанием и 
𝑃
𝑀
P
M
	​

‑описанием.

## ASSISTANT
According to a document from **2026-01-14**, для A3_bridge **Szegő–Böttcher реально не нужен**: достаточно “Rayleigh lower bound” (Toeplitz quadratic form), и тогда **никакого `M₀` не требуется**. fileciteturn8file4 fileciteturn8file0

Ниже — ровно то, что ты просишь:

1) **какая формулировка A3_bridge_data должна быть (Rayleigh‑first, без SB и без M₀)**  
2) **какой скелет доказательства** (чтобы Aristotle/Lean не задыхались)  
3) **набор “адаптер‑лемм” между `Fin M`‑матрицами и “P_M” (триг‑полиномы) в духе Q3 tex / PROSHKA_REQUEST_3**  

---

## 0. Сигнал/аномалия, которую надо исправить в формулировке

### Аномалия
Сейчас у тебя было две несовместимые “версии” \(T_P\):

- **Direct indexing (плохо для uniform)**:  
  \(T_P(i,j)=\sqrt{w_i}\sqrt{w_j}\exp\!\big(-(\xi_i-\xi_j)^2/(4t)\big)\) — и тогда норма растёт с \(M\), uniform‑\(t\) ломается. fileciteturn8file9  
- **Compression (как в Q3 tex, правильно)**:  
  \(T_P^{(M)}\) — **ранг‑один сумма по Nodes \(K\)** (компрессия глобального оператора), и тогда  
  \(\|T_P^{(M)}\|\le \|T_P\|\) ⇒ uniform‑\(t\) возможен. fileciteturn8file1 fileciteturn8file7 fileciteturn8file10

### Решение
Переписать `T_P_matrix` в Axioms/Defs **на compression‑версию** (как в INSIGHTS/PROJECT_ORCHESTRATOR), а `A3_bridge_data` переписать в Rayleigh‑first, чтобы:

- опираться на **Toeplitz quadratic form** и **Rayleigh lower bound** (без SB) fileciteturn8file0  
- убрать квантор `∃ M₀, ∀ M ≥ M₀` вообще (он нужен только если ты идёшь через дискретизацию/SB) fileciteturn8file6  
- использовать **RKHS cap** в форме \(\|T_P\|\le \rho(1)<1/25\) при \(t_{\rm rkhs}\ge1\) fileciteturn8file0 fileciteturn8file6  

---

## 1. Новая формулировка A3_bridge_data в стиле Rayleigh‑first

### 1.1. Что говорит PROSHKA_REQUEST_3 (логика)
Там прямо дан “пакет”:

- **Toeplitz quadratic form**: \(\langle T_M[P_A]p,p\rangle=\int_{\mathbb T}P_A(\theta)|p(\theta)|^2d\theta\) fileciteturn8file0  
- **Rayleigh lower bound**: \(\lambda_{\min}(T_M[P_A])\ge \min_{\theta\in\mathbb T}P_A(\theta)\) (SB optional) fileciteturn8file0  
- **A3 floor**: \(P_A(\theta)\ge c_*=11/10\) fileciteturn8file0  
- **RKHS cap**: при \(t_{\rm rkhs}\ge1\): \(\|T_P\|\le \rho(1)<1/25\) fileciteturn8file0  
- **Rayleigh bridge (p=1)**: \(Q(\Phi_{B,t_{\rm sym}})\) = Rayleigh‑квота \((T_M[P_A]-T_P)\) на \(p\equiv1\) (без лишнего \(2\pi\)) fileciteturn8file6  

Отсюда:  
\[
\lambda_{\min}(T_M[P_A]-T_P)\ge c_*-\|T_P\|\ge 3c_*/4>0
\]
и значит \(Q(\Phi_{B,t_{\rm sym}})\ge0\). fileciteturn8file6  

---

## 2. Конкретный Lean‑скелет: как переписать `A3_bridge_data`

Дам две версии: **минимальную (ровно для \(p\equiv1\))** и **сильную (для всех \(v\), как “matrix PSD bound”)**.

### 2.1. Минимальная версия (идеально “по тексту”: нужно только для генераторов)
Это прямое совпадение с “Rayleigh bridge (p=1)”:

```lean
/-- Rayleigh-first A3 bridge: positivity on the generator (p ≡ 1). -/
def A3_bridge_data_rayleigh_p1 (B : ℝ) : Prop :=
  ∀ M : ℕ, 0 < M →
    ⟪(T_toeplitz M (P_A B t_sym) - T_P_comp M B t_rkhs) (p_one M),
      (p_one M)⟫_ℂ ≥ 0
```

Где:
- `P_A` — символ из §1 PROSHKA_REQUEST_3 (period‑1 тор, \(2\pi\) уже внутри) fileciteturn8file0  
- `T_P_comp` — **compression prime operator** (см. ниже) fileciteturn8file10  
- `p_one M` — константный полином \(p\equiv1\) в \(P_M\). fileciteturn8file10  

Это реально самое лёгкое для “закрыть A3_bridge_axiom”, потому что downstream тебе нужен \(Q(\Phi)\ge0\), а \(Q(\Phi)\) = pairing на \(p\equiv1\). fileciteturn8file10 fileciteturn8file6

### 2.2. Сильная версия (ближе к твоей старой “∀ v : Fin M → ℝ”)
Это “без M₀, без SB”: сразу для всех M.

```lean
/-- Strong Rayleigh-first A3 bridge: uniform lower bound for all vectors. -/
def A3_bridge_data_rayleigh (B : ℝ) : Prop :=
  ∃ t_rkhs : ℝ, 1 ≤ t_rkhs ∧
    ∀ M : ℕ, 0 < M →
      ∀ v : P_M M, v ≠ 0 →
        (⟪(T_toeplitz M (P_A B t_sym) - T_P_comp M B t_rkhs) v, v⟫_ℂ) /
          (‖v‖^2)
        ≥ (3/4) * c_star
```

**Ключ**: `∀ M` (никакого M₀) — это легально именно потому, что используем Rayleigh bound напрямую. fileciteturn8file6  

---

## 3. Доказательство (короткий скетч, который реально проходит в Lean)

### 3.1. Зависимости (у тебя уже есть/должны быть)
- `toeplitz_quadratic_form` и `rayleigh_lower_bound` уже доказаны в “Rayleigh core”. fileciteturn8file13 fileciteturn8file11  
- `A3_FLOOR`: \(P_A(\theta)\ge c_*=11/10\). fileciteturn8file0  
- RKHS cap: \(\|T_P\|\le\rho(1)<1/25\) при \(t_{\rm rkhs}\ge1\). fileciteturn8file0  
- Compression inequality: \(\|T_P^{(M)}\|\le \|T_P\|\). fileciteturn8file1 fileciteturn8file10  

### 3.2. Roadmap (2–4 шага)
1) Из A3 floor + Rayleigh: для любого \(v\neq0\)  
   \[
   \frac{\langle T_M[P_A]v,v\rangle}{\|v\|^2}\ge c_*
   \]
   fileciteturn8file0  
2) Из RKHS cap + compression:  
   \[
   \|T_P^{(M)}\|\le \rho(1) < 1/25 < c_*/4
   \]
   fileciteturn8file0 fileciteturn8file10  
3) “вычитание”:  
   \[
   \frac{\langle (T_M[P_A]-T_P^{(M)})v,v\rangle}{\|v\|^2}
   \ge c_* - \|T_P^{(M)}\|
   \ge 3c_*/4
   \]
   fileciteturn8file6  

---

## 4. “Точечные адаптер‑леммы” между `Fin M` и `P_M`

Сейчас тебе нужно *не философия*, а **точные леммы‑переходники**, чтобы (а) оставить матричный слой на `Fin`, и (б) совпасть с `P_M`‑описанием из текста.

Я дам пакет в 4 блока.

### Блок A. Коэффициентный вектор ↔ триг‑полином (P_M)

Если ты хочешь буквально “P_M = trig polynomials degree ≤ M”, то в Lean самый дешёвый путь — **считать P_M коэффициентным пространством** и отдельно дать функцию‑интерпретацию.

```lean
/-- Coefficient model of P_M (dimension 2M+1). -/
abbrev P_M (M : ℕ) := Fin (2*M+1) → ℂ

/-- index k ∈ [-M, M] associated to i : Fin(2M+1) -/
def kOfFin (M : ℕ) (i : Fin (2*M+1)) : ℤ := (i.1 : ℤ) - (M : ℤ)

/-- trig polynomial from coefficients -/
def trigPoly (M : ℕ) (v : P_M M) : ℝ → ℂ :=
  fun θ =>
    ∑ i : Fin (2*M+1),
      v i * Complex.exp (2*Real.pi*Complex.I * (kOfFin M i) * θ)
```

**Адаптер‑леммы:**

```lean
lemma trigPoly_linear (M) : IsLinearMap ℂ (fun v => trigPoly M v) := by
  -- routine

lemma trigPoly_one (M) : trigPoly M (p_one M) = fun _ => (1 : ℂ) := by
  -- p_one = coefficient vector with v(M-shift)=1, else 0
```

### Блок B. Toeplitz matrix on Fin ↔ Toeplitz pairing on P_M

Это прямое содержание “Toeplitz quadratic form” из PROSHKA_REQUEST_3. fileciteturn8file0

```lean
def torus : Set ℝ := Set.Icc (-(1/2 : ℝ)) (1/2 : ℝ)

def toeplitzMat (M : ℕ) (P : ℝ → ℝ) : Matrix (Fin (2*M+1)) (Fin (2*M+1)) ℂ :=
  fun i j =>
    ∫ θ in torus,
      (P θ : ℂ) *
      Complex.exp (2*Real.pi*Complex.I * ((kOfFin M i - kOfFin M j) : ℤ) * θ)

def quadFormC {n : ℕ} (A : Matrix (Fin n) (Fin n) ℂ) (v : Fin n → ℂ) : ℂ :=
  ∑ i, ∑ j, Complex.conj (v i) * A i j * v j

lemma toeplitz_quadratic_form
  (P : ℝ → ℝ) (M : ℕ) (v : P_M M) :
  quadFormC (toeplitzMat M P) v
    =
  ∫ θ in torus, (P θ : ℂ) * ‖trigPoly M v θ‖^2 := by
  -- this is your already-proven "toeplitz_quadratic_form" style lemma
```

И как следствие:

```lean
theorem rayleigh_lower_bound
  (P : ℝ → ℝ) (m : ℝ) (hP : ∀ θ ∈ torus, m ≤ P θ)
  (M : ℕ) (v : P_M M) (hv : v ≠ 0) :
  (quadFormC (toeplitzMat M P) v).re / ‖v‖^2 ≥ m := by
  -- standard: integral_mono + parseval (already in your rayleigh_v1.lean)
```

### Блок C. Prime compression: матрица на Fin ↔ сумма по нодам

Это ключевой адаптер, который лечит uniform‑t. Он прямо в RH_Q3.pdf: \(T_P^{(M)} = \iota_M^* T_P \iota_M\) и PSD + norm bound. fileciteturn8file10

Сначала *коэффициентная форма* в стиле INSIGHTS/PROJECT_ORCHESTRATOR:

```lean
/-- The “evaluation kernel” coefficient vector at ξ (normalized). -/
def vKernel (M : ℕ) (ξ : ℝ) : P_M M :=
  fun i => (1 / Real.sqrt (2*M+1 : ℝ)) *
    Complex.exp (-2*Real.pi*Complex.I * (kOfFin M i) * ξ)

/-- Compression prime matrix (rank-one sum over nodes). -/
def T_P_comp (M : ℕ) (B t : ℝ) : Matrix (Fin (2*M+1)) (Fin (2*M+1)) ℂ :=
  fun i j =>
    ∑ n : Nodes B,
      (w_Q n * Phi_Bt B t (xi_n n) : ℝ) *
        (vKernel M (xi_n n) i) * Complex.conj (vKernel M (xi_n n) j)
```

Две важные “адаптер‑леммы”:

1) **Репродуцирующая формула** \(p(\xi)=\langle p, v^{(M)}_\xi\rangle\) (в RH_Q3.pdf это “identities \(p(\xi_n)=⟨p,v_n^{(M)}⟩\)”). fileciteturn8file10  

```lean
lemma eval_eq_inner_vKernel (M : ℕ) (v : P_M M) (ξ : ℝ) :
  (trigPoly M v ξ) = ⟪v, vKernel M ξ⟫_ℂ := by
  -- unfold; orthonormality of Fourier basis / direct calc
```

2) **Prime quadratic form = sum of |p(ξ_n)|²** (Rayleigh pairing lemma). fileciteturn8file10  

```lean
lemma prime_quadform_eq_sum_eval
  (M : ℕ) (B t : ℝ) (v : P_M M) :
  ⟪(T_P_comp M B t).mulVec v, v⟫_ℂ
    =
  ∑ n : Nodes B, (w_Q n * Phi_Bt B t (xi_n n) : ℝ) * ‖trigPoly M v (xi_n n)‖^2 := by
  -- expand matrix as sum of rank-one; use eval_eq_inner_vKernel
```

### Блок D. Compression inequality (операторная норма: uniform‑t)

Это то, что в INSIGHTS сформулировано как “\(\|T_P^{(M)}\|\le\|T_P\|\) ⇒ uniform t”. fileciteturn8file1  

В Lean‑версии ты можешь оформить либо как:
- “если `T_P_comp = ι* T_P ι`, то opNorm ≤ opNorm” (Hilbert‑space уровень),  
либо просто как готовый bound от RKHS cap:

```lean
lemma opNorm_T_P_comp_le_global (M : ℕ) :
  ‖T_P_comp M B t‖ ≤ ‖T_P_global B t‖ := by
  -- compression lemma for bounded operators

lemma RKHS_op_norm_bound (t : ℝ) (ht : 1 ≤ t) :
  ‖T_P_global B t‖ ≤ rho 1 := by
  -- your RKHS cap module

lemma opNorm_T_P_comp_le_rho1 (M : ℕ) :
  ‖T_P_comp M B t_rkhs‖ ≤ rho 1 := by
  exact le_trans (opNorm_T_P_comp_le_global (M:=M)) (RKHS_op_norm_bound ...)
```

И дальше ты просто делаешь:

```lean
have h_rho : ‖T_P_comp M B t_rkhs‖ ≤ c_star/4 := by
  -- since rho(1) < 1/25 < c_star/4
```

(Это ровно §3 “RKHS cap” и §5 “Positivity on generators” из PROSHKA_REQUEST_3.) fileciteturn8file6  

---

## 5. Итог: как переписать “твою старую” A3_bridge_data без боли

Если у тебя сейчас было что-то вроде:

```lean
def A3_bridge_data_old (K : ℝ) : Prop :=
  ∃ M₀ : ℕ, ∃ t > 0, ∀ M ≥ M₀, ...
```

то заменяешь на:

- **(i)** `T_P_matrix` → `T_P_comp` (compression sum по Nodes) fileciteturn8file1 fileciteturn8file7  
- **(ii)** убираешь `M₀`, делаешь `∀ M` (Rayleigh bound работает для каждого M, SB не нужен) fileciteturn8file6  
- **(iii)** `t` фиксируешь как `t_rkhs := 1` (или `∃ t ≥ 1`), потому что RKHS cap uniform от 1 fileciteturn8file0  
- **(iv)** RHS берёшь хоть `c_star/4`, хоть `3*c_star/4` — у тебя будет запас, потому что \(\rho(1)\ll c_*/4\). fileciteturn8file0 fileciteturn8file6  

---

## 6. Микро‑совет по Aristotle (чтобы не ломался)

INSIGHTS фиксирует, что sandbox с фикс‑сигнатурами часто душит Aristotle, а pure informal даёт ему возможность нормально переформулировать. fileciteturn8file16  

Для этого конкретного шага (перепись A3_bridge_data) лучший формат запроса к Aristotle:

- **не sandbox**,  
- короткий informal,  
- и дать ему ровно эти 4 леммы‑узла:  
  `toeplitz_quadratic_form`, `rayleigh_lower_bound`, `RKHS_op_norm_bound`, `quadform_sub_ge` (они уже “универсальные”). fileciteturn8file11  

---

Если хочешь, я могу прямо в следующем сообщении выдать **готовый “aristotle_input/A3_bridge_RAYLEIGH_FIRST.md”** (в стиле твоих рабочих запросов):  
- с правильным `T_P_comp` (rank‑one sum),  
- с формулировкой `A3_bridge_rayleigh` без `M₀`,  
- и со списком exact lemmas, которые он должен доказать (или использовать уже доказанные).

## USER
da! bylo by super! sdelaj eto готовый “aristotle_input/A3_bridge_RAYLEIGH_FIRST.md” (в стиле твоих рабочих запросов):

с правильным T_P_comp (rank‑one sum),

с формулировкой A3_bridge_rayleigh без M₀,

и со списком exact lemmas, которые он должен доказать (или использовать уже доказанные).

## ASSISTANT
Готово. Я собрал для тебя **готовый** `aristotle_input/A3_bridge_RAYLEIGH_FIRST.md` в “Rayleigh-first” стиле:

- **без Szegő–Böttcher и без `M₀`** (только Rayleigh lower bound для Toeplitz),
- с **правильным `T_P_comp` как rank‑one sum** (compression form),
- с **точным списком Lean‑лемм‑адаптеров** (что уже есть / что добить).

[Download the markdown](sandbox:/mnt/data/A3_bridge_RAYLEIGH_FIRST.md)

Почему именно так: в проектных заметках и оркестраторе прямо фиксируется, что (i) надо уходить от SB+`M₀` к прямому Rayleigh bound, и (ii) `T_P` должен быть **compression** `T_P_comp` (rank‑one sum), иначе uniform‑`t` ломается. 【405:1†PROJECT_ORCHESTRATOR.md†L1-L6】【405:11†PROJECT_ORCHESTRATOR.md†L37-L42】

