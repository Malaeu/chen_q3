# СИНЕРГИЧЕСКИЕ ВОПРОСЫ: КРАТЧАЙШИЙ ПУТЬ К TPC

## ЦЕНТРАЛЬНЫЙ ИНСАЙТ

**Tao доказал:** Chowla (log-averaged, 2-point) ✓
**Tao связал:** TPC ≈ "Chowla restricted to almost-twin-primes" (on GEH)
**Препятствие:** Λ(n) не мультипликативна как λ(n)

---

## КРИТИЧЕСКИЙ ВОПРОС №1

### "Character Multiplicativity Restoration"

**Факт:** λ(n) полностью мультипликативна: λ(ab) = λ(a)λ(b)
**Факт:** Λ(n) НЕ мультипликативна: Λ(ab) ≠ Λ(a)Λ(b)

**Вопрос:**
> Существует ли характер χ такой, что Λ(n)χ(n) становится 
> "достаточно мультипликативной" для entropy decrement?

**Конкретная формулировка:**
```
Определить: f_χ(n) = Λ(n)χ(n)/n^{1/2}

Вопрос: Для какого χ выполняется
Σ_{H/2 < p ≤ H} |Σ_{n∼N} f_χ(n)f_χ(n+p)|² ≤ o(H·N²)?
```

Это условие — ключ к entropy decrement!

---

## КРИТИЧЕСКИЙ ВОПРОС №2

### "AFM Structure as Joint Information"

**Факт:** χ₄(p)·χ₄(p+2) = -1 для всех twin primes p > 3

**Вопрос:**
> Можно ли использовать эту "антиферромагнитную" структуру 
> как ИСТОЧНИК joint information, а не следствие?

**Конкретная формулировка:**
```
Определить: AFM(n) = χ₄(n)·χ₄(n+2)·𝟙[n, n+2 coprime to 2]

Показать: Σ AFM(n)·Λ(n)Λ(n+2) имеет нетривиальную нижнюю оценку

Следствие: Если AFM(n) = -1 для twins, то 
|Σ AFM(n)·Λ(n)Λ(n+2)| = S₂(X)
```

**Проблема:** AFM(n) ≠ -1 для non-twins, так что связь не прямая.

---

## КРИТИЧЕСКИЙ ВОПРОС №3

### "Entropy Decrement Without Full Multiplicativity"

**Вопрос:**
> Что МИНИМАЛЬНО требуется от функции f(n) для 
> применения entropy decrement?

**Hypothesis:**
```
Достаточно: f(np) = f(n)·g(p) + error term для малых p
```

**Для Λ:**
```
Λ(np) = Λ(n) + Λ(p)  (если gcd(n,p)=1)
Λ(p^k) = log p
```

Это АДДИТИВНАЯ структура, не мультипликативная!

**Вопрос:**
> Можно ли построить "additive entropy decrement"?

---

## КРИТИЧЕСКИЙ ВОПРОС №4

### "Secondary Terms in Trace Formula"

**Selberg Trace Formula:**
```
Σ h(γ_j) = main term + Σ_{primes} g(log p) + secondary
```

**Вопрос:**
> Содержат ли secondary terms информацию о prime PAIRS?

**Конкретно:**
```
Исследовать: Secondary ~ Σ_{p,q} f(log p, log q, p-q)?
```

Если да, terms с p-q=2 дают twin information!

---

## КРИТИЧЕСКИЙ ВОПРОС №5

### "GRH + Correlations → Lower Bound"

**Гипотеза-мост:**
> GRH + контроль L(s,χ) correlations ⟹ S₂(X) ≥ X^{1/2+δ}

**Конкретная формулировка:**
```
Предположим GRH. Тогда:
- Zeros ρ = 1/2 + iγ для всех L(s,χ)
- Explicit formula: Σ Λ(n)χ(n) = X - Σ_ρ X^ρ/ρ + ...

Вопрос: Можно ли из correlations между zeros разных L-functions 
вывести lower bound для twin sum?
```

---

## СИНЕРГИЧЕСКАЯ СТРАТЕГИЯ

### Путь A: Character Twist + Entropy

```
[1] Выбрать χ = χ₄ (связь с AFM)
[2] Изучить f(n) = Λ(n)χ₄(n)
[3] Проверить: f(np) = f(n)·χ₄(p) + Λ(p)χ₄(np)?
[4] Применить modified entropy decrement
[5] De-twist к S₂(X)
```

### Путь B: Additive Entropy Decrement

```
[1] Переформулировать entropy decrement для additive functions
[2] Использовать Λ(np) = Λ(n) + Λ(p)
[3] Построить "additive graph" вместо Tao's multiplicative graph
[4] Доказать expansion properties
```

### Путь C: Spectral Joint Information

```
[1] Изучить correlations zeros L(s,χ₄) и L(s+2,χ₄) (?)
[2] Использовать explicit formula для twisted twin sum
[3] Показать: zero correlations ⟹ twin lower bound
```

---

## НЕМЕДЛЕННЫЕ ДЕЙСТВИЯ

### Action 1: Literature Search
- Что известно о character-weighted twin sums?
- Какие результаты есть для Σ Λ(n)Λ(n+2)χ(n)?

### Action 2: Entropy Analysis
- Можно ли модифицировать entropy decrement для аддитивных функций?
- Какие свойства графа Tao критичны?

### Action 3: Explicit Formula
- Выписать explicit formula для Σ Λ(n)Λ(n+2)χ₄(n)
- Изучить вклад zeros L(s,χ₄)

### Action 4: Numerical Experiment
- Вычислить Σ_{n≤X} Λ(n)Λ(n+2)χ₄(n) численно
- Найти паттерн scaling

---

## ФОРМАЛИЗОВАННЫЙ ВОПРОС ДЛЯ ДАЛЬНЕЙШЕГО АНАЛИЗА

**ГЛАВНЫЙ ВОПРОС:**

> Пусть χ — примитивный характер mod 4.
> Определим T_χ(X) = Σ_{n≤X} Λ(n)Λ(n+2)χ(n).
>
> ВОПРОС: Какова асимптотика T_χ(X)?
>
> ГИПОТЕЗА: T_χ(X) ~ -c·X (с некоторой константой c > 0)
> из-за AFM structure χ₄(p)·χ₄(p+2) = -1.
>
> СЛЕДСТВИЕ: |T_χ(X)| ~ c·X ⟹ S₂(X) ≥ c·X (!)

Если эта гипотеза верна, получаем S₂(X) ≥ cX, что НАМНОГО сильнее B2!

---

*Документ для синергического анализа*
*Проект: Q3(RH)/TPC*
