# КАРТА СТРУКТУР-ГЕНЕРАТОРОВ КОРРЕЛЯЦИЙ ДЛЯ TPC

## КЛЮЧЕВОЙ ВОПРОС
**Что ПОРОЖДАЕТ двухточечные корреляции Λ(n)Λ(n+2), а не предполагает их?**

---

## I. ФУНДАМЕНТАЛЬНОЕ ПРЕПЯТСТВИЕ

### Теорема (arxiv:2512.00071)
> **Shifted correlations** Σ Λ(n)Λ(n+h) не имеют полюса при s=1

**Следствие:**
- Классические контурные методы НЕ дают главного члена
- Нет Euler product для shifted Dirichlet series  
- Нет аналитического продолжения

**Вывод:** Нужны НОВЫЕ структуры beyond analytic continuation

---

## II. ИЕРАРХИЯ КОРРЕЛЯЦИОННЫХ СТРУКТУР

```
УРОВЕНЬ 0: PNT-level (marginals)
├── ζ(s) zeros → distribution of ALL primes
├── π(x) ~ x/log x
└── ❌ НЕ различает миры с/без twins (Lemma 3)

УРОВЕНЬ 1: Character correlations  
├── L(s,χ) → primes in residue classes
├── χ₄(p)·χ₄(p+2) = -1 для twins (ФАКТ)
└── ⚠️ Работает ЕСЛИ twins существуют

УРОВЕНЬ 2: Shifted convolutions
├── L(f⊗g,s) Rankin-Selberg → coefficient correlations
├── Shifted convolution sums → subconvexity
└── ⚠️ Нет полюса → нет главного члена

УРОВЕНЬ 3: Multiplicative structure
├── λ(n) Liouville function: λ(p)=-1 always
├── Tao's entropy decrement → breaks parity for Chowla
└── ✅ РАБОТАЕТ для log-averaged Chowla

УРОВЕНЬ 4: Joint structure (ЦЕЛЬ)
├── ??? → generates correlations unconditionally
└── ??? → S₂(X) ≥ X^{1/2+δ}
```

---

## III. МЕТОД TAO: ENTROPY DECREMENT

### Ключевые ингредиенты:
1. **Multiplicativity at small primes**: λ(p)=-1
2. **Matomäki-Radziwiłł**: averages in short intervals
3. **Concentration of measure**
4. **Hardy-Littlewood circle method** + restriction theorem
5. **Entropy decrement argument** (новый!)

### Результат:
```
Σ_{n≤x} λ(a₁n+b₁)λ(a₂n+b₂) = o(x)  [Chowla, log-averaged]
```

### ПРОБЛЕМА для Twins:
> "Recent progress relies heavily on multiplicativity of λ at small primes, 
> which is **completely destroyed** by inserting weight Λ"

**Критическая связь (Tao):**
> "Twin Prime Conjecture ≈ Chowla restricted to almost twin primes" (on GEH)

---

## IV. СТРУКТУРЫ-КАНДИДАТЫ НА ГЕНЕРАТОР

### A. L-функции и χ₄

**Факт:** Для twin primes p > 3:
```
χ₄(p) × χ₄(p+2) = -1  (антикорреляция)
```

**Почему это не достаточно:**
- Это свойство twins, не источник
- Работает только ЕСЛИ twins существуют

**Гипотеза:**
Можно ли показать, что L(s,χ₄) correlations ВЫНУЖДАЮТ бесконечно много twins?

### B. Rankin-Selberg свёртки

**Структура:**
```
L(f⊗g, s) = Σ a_f(n)a_g(n) n^{-s}
```

**Shifted версия:**
```
D_h(s) = Σ a_f(n)a_g(n+h) n^{-s}
```

**Проблема (arxiv:2512.00071):**
- D_h(s) НЕ имеет полюса при s=1
- Нет Euler product
- "Intrinsic obstruction" на границе Re(s)=1

### C. Trace Formula secondary terms

**Selberg Trace Formula:**
```
Σ_γ h(t_γ) = Σ_primes g(log p) + secondary terms
```

**Гипотеза:**
Secondary terms содержат информацию о prime pairs?

### D. Automorphic forms / Hecke operators

**Hecke связь:**
```
a(p)a(q) relates to a(pq) through Hecke algebra
```

**Проблема:**
Это multiplicative structure, не additive (shift by 2)

---

## V. ЦЕНТРАЛЬНАЯ ДИХОТОМИЯ

### Два типа корреляционной информации:

| Тип | Структура | Пример | Для TPC? |
|-----|-----------|--------|----------|
| **Мультипликативный** | f(n)f(m) связано с f(nm) | Liouville λ | ✅ Tao works |
| **Аддитивный** | f(n)f(n+h) при фикс. h | von Mangoldt Λ | ❌ No pole |

**Ключевой инсайт:**
Chowla использует multiplicative structure λ.
TPC требует additive structure (shift by 2).
Нет прямого моста!

---

## VI. ВОЗМОЖНЫЙ ПУТЬ: МОСТ ЧЕРЕЗ ХАРАКТЕРЫ

### Наблюдение:
Twin primes живут в пересечении:
```
{p : p prime} ∩ {p : p+2 prime}
```

Каждое множество контролируется L-функциями:
```
{p prime} ← ζ(s)
{p+2 prime} ← ζ(s) shifted
```

### Идея:
Использовать CHARACTER STRUCTURE для перевода:
```
additive shift → multiplicative через χ
```

**Формализация:**
```
Σ Λ(n)Λ(n+2) = Σ_χ Σ Λ(n)Λ(n+2)χ(n)χ̄(n)  [ортогональность]
             = Σ_χ [character sum with twins]
```

Каждый член — character sum, для которых есть инструменты!

---

## VII. ENTROPY DECREMENT ДЛЯ TWINS?

### Tao's Graph:
- Вершины = integers
- Рёбра = (n, n+p) если p|n и p|n+p (невозможно для p>2!)
- Используется для propagation of correlations

### Модификация для Twins:
**Новый граф:**
- Вершины = integers
- Рёбра = (n, n+2) если оба связаны с простыми

**Проблема:**
В графе Tao корреляции "распространяются" через мультипликативность.
Для twins нет такого механизма распространения.

---

## VIII. СИНЕРГЕТИЧЕСКАЯ ГИПОТЕЗА

### "Character-Entropy Bridge"

**Шаг 1:** Decompose twin sum by characters:
```
S₂(X) = Σ_{n≤X} Λ(n)Λ(n+2) = Σ_χ c_χ · S_χ(X)
```

**Шаг 2:** For each χ, use modified entropy decrement:
```
S_χ(X) = Σ Λ(n)Λ(n+2)χ(n)
```

**Шаг 3:** Exploit that Λ(n)χ(n) is "more multiplicative" than Λ(n) alone

**Шаг 4:** Apply Matomäki-Radziwiłł type results to twisted sums

### Ключевой вопрос:
> Можно ли twist by χ сделать функцию Λ(n)χ(n) достаточно 
> "мультипликативной" для применения entropy decrement?

---

## IX. ФОРМАЛЬНАЯ ПРОГРАММА ДЕЙСТВИЙ

### Этап 1: Исследование L(s,χ₄) × L(s,χ₄)

**Вопрос:** Что известно о:
```
Σ_{n≤X} χ₄(n)χ₄(n+2)Λ(n)Λ(n+2)?
```

Это "character-weighted twin sum".

### Этап 2: Связь с GRH

**Гипотеза:** GRH + L-function correlations ⟹ lower bound for S₂?

### Этап 3: Entropy decrement для twisted sums

**Задача:** Адаптировать entropy decrement для:
```
f(n) = Λ(n)χ(n)/log n  (normalized)
```

### Этап 4: De-twisting

**Задача:** Если работает для twisted sums, как вернуться к S₂(X)?

---

## X. КРИТИЧЕСКИЕ ВОПРОСЫ

1. **Почему мультипликативность критична?**
   - Entropy decrement использует λ(np) = λ(n)λ(p)
   - Это создаёт "propagation" в графе
   - Без этого граф "разваливается"

2. **Можно ли заменить мультипликативность?**
   - Character twist частично восстанавливает структуру
   - Но χ(n+2) ≠ χ(n)·χ(2) в general

3. **Что уникально в shift 2?**
   - 2 = единственное чётное простое
   - χ₄(p)·χ₄(p+2)=-1 — специфично для twins
   - AFM structure специфична для gap 2

4. **GRH достаточна?**
   - GRH контролирует zeros
   - Но zeros → marginals, не joints
   - Нужно что-то beyond GRH

---

## РЕЗЮМЕ

| Подход | Статус | Блокер |
|--------|--------|--------|
| Direct L-function | ❌ | Нет полюса при s=1 |
| Rankin-Selberg shift | ❌ | "Intrinsic obstruction" |
| Tao entropy | ⚠️ | Требует мультипликативность |
| Character twist | 🔍 | Исследовать! |
| Trace formula | 🔍 | Secondary terms? |

**СЛЕДУЮЩИЙ ШАГ:**
Исследовать character-weighted twin sums и возможность применения entropy decrement к twisted функциям.

---

*Документ создан: 2025-12-12*
*Для проекта: Q3(RH)/TPC*
