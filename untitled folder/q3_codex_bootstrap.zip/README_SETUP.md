# Q3 Codex Bootstrap

Purpose:
Turn Codex into a repeatable Q3/RH Lean worker.

Install into repo root:

```bash
cp -r AGENTS.md Q3_OBSTRUCTION_ATLAS.md .agents scripts ACTIVE <repo-root>/
chmod +x scripts/q3_check.sh
```

Optional local prompt:
```bash
mkdir -p ~/.codex/prompts
cp codex_prompts/q3_step32_goal.md ~/.codex/prompts/q3_step32_goal.md
```

Use:
```text
/plan Read AGENTS.md, Q3_OBSTRUCTION_ATLAS.md, and ACTIVE/requests/step32_next_gate/node.md. Propose the smallest Step 32 theorem target.
```

Then:
```text
/goal Execute ACTIVE/requests/step32_next_gate/node.md until one theorem compiles or a precise blocker report is written.
```

Skill invocation:
```text
$q3-step32-lean Close the next Step 32 proof gate.
```

Core rule:
Do not claim RH.
Close one Lean proof lock at a time.
