---
name: q3-step32-lean
description: Close one Step 32 PSD-pd/Q3 B-spline matrix-identification Lean proof gate. Use when the task mentions Q3, RH formalization, PSD-pd, B-spline, WeilForm, FinitePenaltyCert, FiniteWeilMatrixModel, A/P/Q, boundary-null, or Step 32.
---

# q3-step32-lean

You are a local Lean worker for the PSD-pd/Q3 route.

Do not prove RH.
Do not touch Q3.Main.
Close one local Step 32 proof gate.

## Goal

Close the semantic bridge:

```text
finite certified PSD matrix positivity
→ real analytic Weil positivity on B-spline packet space
```

Step 32 target:

```text
A, P, Q = analytic WeilForm matrices
```

Core identities:

```text
h_v = Σ_j v_j ψ_j
WeilForm(h_v) = vᵀ(A - P)v
Qv = (H_v(1/2), H_v(-1/2))
```

## Priority order

Work in this order unless repo state proves another blocker is smaller:

```lean
centeredBSplineArchIntegrand_translatedPacketSum_integrable
centeredBSplinePacketTranslationArchData_ofPairing
centeredBSplinePrimeForm_eq_matrixQF
centeredBSplineBoundaryRows_identify_Q
centeredBSpline_BSplineTranslatedAnalyticContract
CertifiedBSplinePacketBlock.toCertifiedFiniteWeilModel
```

## Required search

Search before editing:

```text
FinitePenaltyCert
FiniteWeilMatrixModel
CertifiedFiniteWeilModel
WeilForm
BSpline
CenteredCardinalBSpline
MatrixIdentification
BoundaryNull
DirectedCertFamily
Gram
endpoint
H_v
A_minus_P
Arch
Prime
PacketTranslationKernelData
BSplineTranslatedAnalyticContract
centeredBSplineArchIntegrand_translatedPacketSum_integrable
centeredBSplinePacketTranslationArchData_ofPairing
centeredBSplinePrimeForm_eq_matrixQF
centeredBSplineBoundaryRows_identify_Q
```

## Proof style

Use structural rewrites.
Avoid brute computation.
Reuse existing scalar profile / tail / autocorrelation lemmas.
Prefer the smallest missing theorem.

## Hard constraints

No new `sorry`.
No new `admit`.
No fake `axiom`.
No fake `constant`.
No theorem weakening.
No numerical PSD as proof.
No raw-coordinate PSD if Gram correction is required.
No Q3.Main before Step 35.

## Theorem comment

Every new theorem needs:

```lean
/-
Q3 obstruction wall:
- wall:
- role:
- input:
- output:
- reviewer question answered:
-/
```

## Validation

Run:

```bash
lake env lean <touched-file>
```

If local compile succeeds:

```bash
lake build
```

Then:

```bash
./scripts/q3_check.sh <touched-file>
```

## Report

Return:

```text
theorem closed:
files touched:
commands run:
compile result:
obstruction wall closed:
remaining Step 32 blockers:
next smallest theorem:
if blocked, exact missing lemma:
```
