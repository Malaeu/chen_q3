---
description: Start Q3 Step 32 goal mode with obstruction gates.
argument-hint: FOCUS=<optional theorem or file>
---

/goal Execute Q3 Step 32 next-gate workflow.

Read first:
- AGENTS.md
- Q3_OBSTRUCTION_ATLAS.md
- ACTIVE/requests/step32_next_gate/node.md

Optional focus:
$FOCUS

Objective:
Close one local Step 32 proof gate or produce a precise blocker report.

Do not claim RH.
Do not touch Q3.Main.
Do not add sorry/admit/axiom/constant.
Do not use numerical PSD as proof.

Priority:
1. centeredBSplineArchIntegrand_translatedPacketSum_integrable
2. centeredBSplinePacketTranslationArchData_ofPairing
3. centeredBSplinePrimeForm_eq_matrixQF
4. centeredBSplineBoundaryRows_identify_Q
5. centeredBSpline_BSplineTranslatedAnalyticContract
6. CertifiedBSplinePacketBlock.toCertifiedFiniteWeilModel

Validation:
- lake env lean <touched-file>
- ./scripts/q3_check.sh <touched-file>

Report:
Write ACTIVE/requests/step32_next_gate/report.md.
