#!/usr/bin/env bash
set -euo pipefail

TARGET_FILE="${1:?usage: ./scripts/q3_check.sh path/to/File.lean}"

echo "[1/6] Checking target Lean file:"
lake env lean "$TARGET_FILE"

echo "[2/6] Searching for proof holes:"
grep -R "sorry\|admit" Q3 RH *.lean 2>/dev/null || true

echo "[3/6] Searching for hidden axioms/constants:"
grep -R "axiom\|constant" Q3 RH *.lean 2>/dev/null || true

echo "[4/6] Searching Step 32-35 theorem names:"
grep -R "Step32\|Step33\|Step34\|Step35\|BSpline_WeilForm\|RH_from_PSD" Q3 RH *.lean 2>/dev/null || true

echo "[5/6] Searching obstruction-wall comments:"
grep -R "Q3 obstruction wall\|wall:\|reviewer question answered" Q3 RH *.lean 2>/dev/null || true

echo "[6/6] Optional full build:"
lake build
