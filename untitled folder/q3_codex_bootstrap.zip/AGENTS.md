# AGENTS.md — Q3/RH Lean Worker Rules

## Mode

Caveman mode.
Short lines.
No philosophy.
No RH claims unless the final Lean chain compiles.

## Project route

RH formalization.
PSD-pd/Q3 route.
Not a full RH proof task.

Current bridge:

```text
finite certified PSD matrix positivity
→ real analytic Weil positivity on B-spline packet space
```

Core bridge:

```text
FinitePenaltyCert
+ FiniteWeilMatrixModel
+ B-spline matrix identification
+ Qv = 0 boundary-null condition
→ finite analytic Weil positivity
```

## Step map

```text
Step 32:
  B-spline matrix identification.

Step 33:
  finite analytic positivity → DirectedFamily + exhaustion.

Step 34:
  global boundary-null Weil positivity.

Step 35:
  Q3.Main / RH export.
```

Do not work outside Step 32–35.
Do not touch Q3.Main before Step 35.

## Current priority

Step 32.

Prove that A, P, Q are the analytic WeilForm matrices on the B-spline packet basis.

Core identities:

```text
h_v = Σ_j v_j ψ_j
WeilForm(h_v) = vᵀ(A - P)v
Qv = (H_v(1/2), H_v(-1/2))
```

## Hard constraints

No new `sorry`.
No new `admit`.
No hidden `axiom`.
No fake `constant`.
No theorem weakening.
No numerical PSD as proof.
No raw-coordinate PSD if Gram correction is required.
No Hilbert–Pólya detour.
No unrelated RH literature review.
No Q3.Main export before Step 35.

## Work loop

1. Read `Q3_OBSTRUCTION_ATLAS.md`.
2. Read the active request under `ACTIVE/requests/.../node.md`.
3. Search repo for required declarations.
4. Build dependency map.
5. Pick smallest missing theorem.
6. Propose exact theorem statement.
7. Implement Lean proof.
8. Prefer structural rewrites over brute force.
9. Run:

```bash
lake env lean <touched-file>
```

10. If local file compiles, run:

```bash
lake build
```

11. Run:

```bash
./scripts/q3_check.sh <touched-file>
```

12. Write report.

## Required theorem comment

Every new theorem must include:

```lean
/-
Q3 obstruction wall:
- wall:
- role:
- input:
- output:
- reviewer question answered:
-/
```

A theorem is useful only if it kills a reviewer-level objection.

## Report format

Return:

```text
1. Files searched.
2. Files touched.
3. Theorems added/modified.
4. Exact commands run.
5. Compile result.
6. Obstruction wall closed.
7. Remaining Step 32 blockers.
8. Next smallest theorem.
9. If blocked: exact missing lemma statement.
```
