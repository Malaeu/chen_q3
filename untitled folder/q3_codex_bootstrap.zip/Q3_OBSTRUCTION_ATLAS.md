# Q3 Obstruction Atlas — Lean Gate Version

## Purpose

This file converts the RH/Q3 obstruction atlas into Lean engineering gates.

Codex must use this file before modifying proofs.

## Core walls

| Wall | Meaning | Lean gate |
|---|---|---|
| Matrix-identification wall | finite matrix may be positive but not analytic WeilForm | prove A,P,Q represent analytic WeilForm |
| Coordinate wall | raw PSD may depend on basis | use Gram-corrected / basis-invariant representation |
| Boundary leakage wall | endpoint terms may leak | prove Qv = endpoint map |
| Prime-side wall | prime contribution may be hidden numerics | prove PrimeForm identity |
| Finite-to-global wall | finite certs do not imply global positivity | use DirectedFamily + exhaustion + closure |
| Scalar mirror wall | s ↔ 1-s is not RH | require Hermitian positivity / negative-direction exclusion |
| Sociological validation wall | claim must be auditable | named theorem + no hidden axioms + no sorry |

## Main route

```text
corrected positive-definite cone
→ Hermitian square
→ Arch − Prime operator difference C = A − P
→ κ-split / penalty guard
→ FinitePenaltyCert
→ boundary-null exactness
→ Step 32 matrix identification
→ Step 33 DirectedFamily/exhaustion
→ Step 34 global boundary-null Weil positivity
→ Step 35 Q3/RH export
```

## Step 32 gate

Step 32 is not closed until Lean proves:

```text
h_v = Σ_j v_j ψ_j
WeilForm(h_v) = vᵀ(A - P)v
Qv = (H_v(1/2), H_v(-1/2))
```

If the basis is non-orthonormal, positivity must be stated via Gram-corrected / basis-invariant representation.

Failure signals:

```text
theorem only proves PSD of a finite matrix
theorem does not identify analytic WeilForm
theorem depends on raw coordinates
theorem bypasses Qv endpoint identity
```

## Step 33 gate

Closed only when:

```text
FinitePenaltyCert
+ Step32_BSpline_matrix_identification
→ finite analytic Weil positivity
→ DirectedFamily compatibility
→ boundary-null exhaustion input
```

Failure signals:

```text
finite-only theorem
no DirectedFamily object
no monotone/dense/exhaustive bridge
```

## Step 34 gate

Closed only when:

```text
directed finite analytic positivity
→ global boundary-null Weil positivity
```

Failure signals:

```text
missing topology
missing closure theorem
missing continuity theorem
hidden compactness assumption
```

## Step 35 gate

Closed only when:

```text
global boundary-null Weil positivity
→ Q3.Main / G6 / Weil criterion route
→ RH theorem export
```

Failure signals:

```text
wrong test class
boundary-null class not sufficient
RH-equivalent positivity used as axiom
```

## Forbidden moves

Do not add speculative spectral operators.
Do not use numerical zeta verification as proof.
Do not treat GUE compatibility as proof.
Do not replace Step 32 with finite-only matrix theorem.
Do not use raw matrix PSD if Gram correction is required.
Do not weaken theorem statements to compile.
