# ACTIVE Request — Step 32 Next Gate

Task:
Close the next local proof gate in Step 32.

Context:
PSD-pd/Q3 route.
Not full RH proof.
Step 32 only.

Problem:
Finite PSD certificate proves matrix positivity only.
We need semantic bridge:

```text
certified matrix = analytic WeilForm matrix
```

Target:
Prove the next missing identity toward:

```text
h_v = Σ_j v_j ψ_j
WeilForm(h_v) = vᵀ(A - P)v
Qv = (H_v(1/2), H_v(-1/2))
```

Priority order:

```lean
centeredBSplineArchIntegrand_translatedPacketSum_integrable
centeredBSplinePacketTranslationArchData_ofPairing
centeredBSplinePrimeForm_eq_matrixQF
centeredBSplineBoundaryRows_identify_Q
centeredBSpline_BSplineTranslatedAnalyticContract
CertifiedBSplinePacketBlock.toCertifiedFiniteWeilModel
```

Work:
1. Search repo.
2. Find smallest missing theorem.
3. Propose exact Lean statement.
4. Prove it.
5. Run Lean.
6. Write report to `ACTIVE/requests/step32_next_gate/report.md`.

Hard rules:
- no sorry/admit
- no fake axiom
- no theorem weakening
- no Q3.Main
- no numerical PSD as proof
- no raw-coordinate PSD if Gram correction is required

Required command:

```bash
lake env lean <touched-file>
```

Preferred command:

```bash
./scripts/q3_check.sh <touched-file>
```
