// Lean compiler output
// Module: ProofWidgets.Demos.Dynkin
// Imports: Init ProofWidgets.Component.HtmlDisplay
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
static lean_object* l_Matrix_toHtml___closed__7;
static lean_object* l_Matrix_get__node__html___closed__9;
static lean_object* l_Matrix_toHtml___closed__5;
static lean_object* l_Matrix_toHtml___closed__18;
static lean_object* l_Matrix_get__node__html___closed__15;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_Matrix_get__node__html___closed__5;
static lean_object* l_cartanMatrix_E_u2088___closed__35;
static lean_object* l_Matrix_toHtml___closed__6;
LEAN_EXPORT lean_object* l_List_product(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__14;
LEAN_EXPORT lean_object* l_Matrix_get__node__pos__E___boxed(lean_object*);
extern lean_object* l_Int_instInhabited;
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__21;
static lean_object* l_Matrix_get__node__html___closed__11;
LEAN_EXPORT lean_object* l_Matrix_get__node__cx___boxed(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__44;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_cartanMatrix_E_u2088(lean_object*, lean_object*);
static lean_object* l_Matrix_toHtml___closed__22;
static lean_object* l_Matrix_toHtml___closed__21;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__36;
static lean_object* l_cartanMatrix_E_u2088___closed__6;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__pos__E___closed__1;
static lean_object* l_cartanMatrix_E_u2088___closed__16;
static lean_object* l_Matrix_get__node__html___closed__17;
static lean_object* l_cartanMatrix_E_u2088___closed__58;
static lean_object* l_cartanMatrix_E_u2088___closed__1;
LEAN_EXPORT lean_object* l_Matrix_nat__index(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_toHtml___closed__8;
static lean_object* l_cartanMatrix_E_u2088___closed__2;
static lean_object* l_cartanMatrix_E_u2088___closed__8;
static lean_object* l_Matrix_get__node__cx___closed__1;
static lean_object* l_cartanMatrix_E_u2088___closed__39;
static lean_object* l_Matrix_get__node__html___closed__3;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__34;
static lean_object* l_cartanMatrix_E_u2088___closed__28;
static lean_object* l_Matrix_get__edge__html___closed__4;
static lean_object* l_cartanMatrix_E_u2088___closed__13;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Matrix_get__node__pos__E(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__23;
LEAN_EXPORT lean_object* l_Matrix_get__node__html(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_toHtml___closed__11;
static lean_object* l_cartanMatrix_E_u2088___closed__22;
lean_object* l_Nat_reprFast(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__46;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__54;
LEAN_EXPORT lean_object* l_Matrix_get__node__pos___boxed(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__10;
LEAN_EXPORT lean_object* l_List_product___redArg(lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__13;
static lean_object* l_cartanMatrix_E_u2088___closed__7;
static lean_object* l_cartanMatrix_E_u2088___closed__19;
static lean_object* l_Matrix_toHtml___closed__16;
static lean_object* l_cartanMatrix_E_u2088___closed__33;
static lean_object* l_Matrix_get__edge__html___closed__0;
LEAN_EXPORT lean_object* l_Matrix_get__node__html___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Matrix_get__edge__html(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Matrix_get__edges__html(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__20;
static lean_object* l_Matrix_toHtml___closed__1;
lean_object* l_List_range(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__32;
static lean_object* l_Matrix_get__node__html___closed__12;
LEAN_EXPORT lean_object* l_Matrix_get__edge__html___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_toHtml___closed__12;
static lean_object* l_Matrix_get__node__html___closed__0;
static lean_object* l_Matrix_toHtml___closed__15;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__15;
static lean_object* l_cartanMatrix_E_u2088___closed__51;
static lean_object* l_Matrix_toHtml___closed__19;
static lean_object* l_Matrix_toHtml___closed__2;
static lean_object* l_Matrix_get__node__html___closed__4;
static lean_object* l_cartanMatrix_E_u2088___closed__3;
static lean_object* l_cartanMatrix_E_u2088___closed__26;
static lean_object* l_cartanMatrix_E_u2088___closed__45;
static lean_object* l_Matrix_nat__index___closed__0;
static lean_object* l_cartanMatrix_E_u2088___closed__17;
static lean_object* l_Matrix_get__edge__html___closed__3;
static lean_object* l_Matrix_toHtml___closed__20;
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__18;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Matrix_get__nodes__html(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__29;
static lean_object* l_Matrix_toHtml___closed__17;
LEAN_EXPORT lean_object* l_Matrix_get__node__cx(lean_object*, lean_object*);
static lean_object* l_Matrix_get__edge__html___closed__5;
static lean_object* l_cartanMatrix_E_u2088___closed__12;
static lean_object* l_cartanMatrix_E_u2088___closed__31;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__pos__E___closed__0;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___List_product_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_abs(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__48;
lean_object* lean_int_mul(lean_object*, lean_object*);
static lean_object* l_Matrix_get__edge__html___closed__1;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___List_product_spec__0___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__16;
static lean_object* l_cartanMatrix_E_u2088___closed__30;
static lean_object* l_Matrix_toHtml___closed__4;
static lean_object* l_Matrix_get__node__html___closed__1;
static lean_object* l_cartanMatrix_E_u2088___closed__42;
static lean_object* l_Matrix_get__node__cx___closed__0;
static lean_object* l_Matrix_toHtml___closed__13;
LEAN_EXPORT lean_object* l_Matrix_nat__index___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__52;
static lean_object* l_cartanMatrix_E_u2088___closed__49;
static lean_object* l_Matrix_toHtml___closed__0;
LEAN_EXPORT lean_object* l_Matrix_get__node__pos(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__6;
static lean_object* l_cartanMatrix_E_u2088___closed__56;
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__27;
static lean_object* l_Matrix_toHtml___closed__9;
static lean_object* l_cartanMatrix_E_u2088___closed__25;
static lean_object* l_cartanMatrix_E_u2088___closed__37;
static lean_object* l_cartanMatrix_E_u2088___closed__5;
LEAN_EXPORT lean_object* l_Matrix_get__node__cy(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
LEAN_EXPORT lean_object* l_Matrix_get__node__cy___boxed(lean_object*, lean_object*);
static lean_object* l_Matrix_get__edge__html___closed__6;
static lean_object* l_Matrix_get__edge__html___closed__2;
static lean_object* l_Matrix_get__node__html___closed__10;
lean_object* lean_int_add(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__24;
static lean_object* l_cartanMatrix_E_u2088___closed__53;
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__0;
static lean_object* l_cartanMatrix_E_u2088___closed__14;
LEAN_EXPORT lean_object* l_Matrix_toHtml(lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__4;
static lean_object* l_cartanMatrix_E_u2088___closed__11;
static lean_object* l_cartanMatrix_E_u2088___closed__18;
static lean_object* l_cartanMatrix_E_u2088___closed__43;
lean_object* lean_int_neg(lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__59;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__50;
static lean_object* l_Matrix_toHtml___closed__3;
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_Matrix_get__node__html___closed__2;
static lean_object* l_cartanMatrix_E_u2088___closed__57;
static lean_object* l_cartanMatrix_E_u2088___closed__55;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__38;
static lean_object* l_cartanMatrix_E_u2088___closed__9;
static lean_object* l_Matrix_get__node__html___closed__8;
static lean_object* l_Matrix_toHtml___closed__10;
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_cartanMatrix_E_u2088___closed__47;
static lean_object* l_Matrix_get__node__html___closed__7;
static lean_object* l_Matrix_toHtml___closed__14;
static lean_object* l_cartanMatrix_E_u2088___closed__40;
static lean_object* l_cartanMatrix_E_u2088___closed__41;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___List_product_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_4; 
lean_dec(x_1);
x_4 = l_List_reverse___redArg(x_3);
return x_4;
}
else
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_2);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_2, 0);
x_7 = lean_ctor_get(x_2, 1);
lean_inc(x_1);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_1);
lean_ctor_set(x_8, 1, x_6);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_8);
{
lean_object* _tmp_1 = x_7;
lean_object* _tmp_2 = x_2;
x_2 = _tmp_1;
x_3 = _tmp_2;
}
goto _start;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_10 = lean_ctor_get(x_2, 0);
x_11 = lean_ctor_get(x_2, 1);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_2);
lean_inc(x_1);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_1);
lean_ctor_set(x_12, 1, x_10);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_3);
x_2 = x_11;
x_3 = x_13;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___List_product_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_List_mapTR_loop___at___List_product_spec__0___redArg(x_3, x_4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_List_product___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
lean_dec(x_2);
x_3 = lean_box(0);
return x_3;
}
else
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
lean_dec_ref(x_1);
x_6 = lean_box(0);
lean_inc(x_2);
x_7 = l_List_mapTR_loop___at___List_product_spec__0___redArg(x_4, x_2, x_6);
x_8 = l_List_product___redArg(x_5, x_2);
x_9 = l_List_appendTR___redArg(x_7, x_8);
return x_9;
}
}
}
LEAN_EXPORT lean_object* l_List_product(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_List_product___redArg(x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_Matrix_nat__index___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(999u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Matrix_nat__index(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_7; 
x_7 = lean_nat_dec_lt(x_3, x_1);
if (x_7 == 0)
{
lean_dec(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
goto block_6;
}
else
{
uint8_t x_8; 
x_8 = lean_nat_dec_lt(x_4, x_1);
if (x_8 == 0)
{
lean_dec(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
goto block_6;
}
else
{
lean_object* x_9; 
x_9 = lean_apply_2(x_2, x_3, x_4);
return x_9;
}
}
block_6:
{
lean_object* x_5; 
x_5 = l_Matrix_nat__index___closed__0;
return x_5;
}
}
}
LEAN_EXPORT lean_object* l_Matrix_nat__index___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Matrix_nat__index(x_1, x_2, x_3, x_4);
lean_dec(x_1);
return x_5;
}
}
static lean_object* _init_l_Matrix_get__node__pos__E___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__pos__E___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_unsigned_to_nat(2u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__pos__E(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_nat_dec_eq(x_1, x_2);
if (x_3 == 1)
{
lean_object* x_4; 
x_4 = l_Matrix_get__node__pos__E___closed__0;
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_5 = lean_unsigned_to_nat(1u);
x_6 = lean_nat_sub(x_1, x_5);
x_7 = lean_nat_dec_eq(x_6, x_2);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_2);
return x_8;
}
else
{
lean_object* x_9; 
lean_dec(x_6);
x_9 = l_Matrix_get__node__pos__E___closed__1;
return x_9;
}
}
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__pos__E___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Matrix_get__node__pos__E(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__pos(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_unsigned_to_nat(6u);
x_4 = lean_nat_dec_lt(x_1, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = l_Matrix_get__node__pos__E(x_2);
lean_dec(x_2);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_2);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__pos___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Matrix_get__node__pos(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__node__cx___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(20u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__cx___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(40u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__cx(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_3 = l_Matrix_get__node__pos(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_Matrix_get__node__cx___closed__0;
x_6 = lean_nat_to_int(x_4);
x_7 = l_Matrix_get__node__cx___closed__1;
x_8 = lean_int_mul(x_6, x_7);
lean_dec(x_6);
x_9 = lean_int_add(x_5, x_8);
lean_dec(x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__cx___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Matrix_get__node__cx(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__cy(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_3 = l_Matrix_get__node__pos(x_1, x_2);
x_4 = lean_ctor_get(x_3, 1);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_Matrix_get__node__cx___closed__0;
x_6 = lean_nat_to_int(x_4);
x_7 = l_Matrix_get__node__cx___closed__1;
x_8 = lean_int_mul(x_6, x_7);
lean_dec(x_6);
x_9 = lean_int_add(x_5, x_8);
lean_dec(x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__cy___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Matrix_get__node__cy(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("circle", 6, 6);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("r", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("10", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_get__node__html___closed__2;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_get__node__html___closed__3;
x_2 = l_Matrix_get__node__html___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fill", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("white", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_get__node__html___closed__6;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_get__node__html___closed__7;
x_2 = l_Matrix_get__node__html___closed__5;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("stroke", 6, 6);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("black", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_get__node__html___closed__10;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_get__node__html___closed__11;
x_2 = l_Matrix_get__node__html___closed__9;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(5u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__15() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("cx", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("cy", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__node__html___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("-", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__html(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_21; lean_object* x_22; lean_object* x_39; lean_object* x_40; uint8_t x_41; 
x_3 = l_Matrix_get__node__html___closed__0;
x_21 = l_Matrix_get__node__html___closed__15;
lean_inc(x_2);
x_39 = l_Matrix_get__node__cx(x_1, x_2);
x_40 = l_Matrix_get__node__html___closed__17;
x_41 = lean_int_dec_lt(x_39, x_40);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_nat_abs(x_39);
lean_dec(x_39);
x_43 = l_Nat_reprFast(x_42);
x_22 = x_43;
goto block_38;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_44 = lean_nat_abs(x_39);
lean_dec(x_39);
x_45 = lean_unsigned_to_nat(1u);
x_46 = lean_nat_sub(x_44, x_45);
lean_dec(x_44);
x_47 = l_Matrix_get__node__html___closed__18;
x_48 = lean_nat_add(x_46, x_45);
lean_dec(x_46);
x_49 = l_Nat_reprFast(x_48);
x_50 = lean_string_append(x_47, x_49);
lean_dec_ref(x_49);
x_22 = x_50;
goto block_38;
}
block_20:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_7 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_7, 0, x_6);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_7);
x_9 = l_Matrix_get__node__html___closed__4;
x_10 = l_Matrix_get__node__html___closed__8;
x_11 = l_Matrix_get__node__html___closed__12;
x_12 = l_Matrix_get__node__html___closed__13;
x_13 = lean_array_push(x_12, x_4);
x_14 = lean_array_push(x_13, x_8);
x_15 = lean_array_push(x_14, x_9);
x_16 = lean_array_push(x_15, x_10);
x_17 = lean_array_push(x_16, x_11);
x_18 = l_Matrix_get__node__html___closed__14;
x_19 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_19, 0, x_3);
lean_ctor_set(x_19, 1, x_17);
lean_ctor_set(x_19, 2, x_18);
return x_19;
}
block_38:
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_23 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_21);
lean_ctor_set(x_24, 1, x_23);
x_25 = l_Matrix_get__node__html___closed__16;
x_26 = l_Matrix_get__node__cy(x_1, x_2);
x_27 = l_Matrix_get__node__html___closed__17;
x_28 = lean_int_dec_lt(x_26, x_27);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; 
x_29 = lean_nat_abs(x_26);
lean_dec(x_26);
x_30 = l_Nat_reprFast(x_29);
x_4 = x_24;
x_5 = x_25;
x_6 = x_30;
goto block_20;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_31 = lean_nat_abs(x_26);
lean_dec(x_26);
x_32 = lean_unsigned_to_nat(1u);
x_33 = lean_nat_sub(x_31, x_32);
lean_dec(x_31);
x_34 = l_Matrix_get__node__html___closed__18;
x_35 = lean_nat_add(x_33, x_32);
lean_dec(x_33);
x_36 = l_Nat_reprFast(x_35);
x_37 = lean_string_append(x_34, x_36);
lean_dec_ref(x_36);
x_4 = x_24;
x_5 = x_25;
x_6 = x_37;
goto block_20;
}
}
}
}
LEAN_EXPORT lean_object* l_Matrix_get__node__html___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Matrix_get__node__html(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("line", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_get__node__html___closed__11;
x_2 = l_Matrix_get__node__html___closed__5;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(6u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("y2", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("x2", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("x1", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Matrix_get__edge__html___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("y1", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__edge__html(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_3, 1);
lean_inc(x_5);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 x_6 = x_3;
} else {
 lean_dec_ref(x_3);
 x_6 = lean_box(0);
}
lean_inc(x_5);
lean_inc(x_4);
x_7 = l_Matrix_nat__index(x_1, x_2, x_4, x_5);
x_8 = l_Matrix_get__node__html___closed__17;
x_9 = lean_int_dec_eq(x_7, x_8);
lean_dec(x_7);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_69; lean_object* x_70; lean_object* x_86; uint8_t x_87; 
x_10 = l_Matrix_get__edge__html___closed__0;
x_69 = l_Matrix_get__edge__html___closed__5;
lean_inc(x_4);
x_86 = l_Matrix_get__node__cx(x_1, x_4);
x_87 = lean_int_dec_lt(x_86, x_8);
if (x_87 == 0)
{
lean_object* x_88; lean_object* x_89; 
x_88 = lean_nat_abs(x_86);
lean_dec(x_86);
x_89 = l_Nat_reprFast(x_88);
x_70 = x_89;
goto block_85;
}
else
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; 
x_90 = lean_nat_abs(x_86);
lean_dec(x_86);
x_91 = lean_unsigned_to_nat(1u);
x_92 = lean_nat_sub(x_90, x_91);
lean_dec(x_90);
x_93 = l_Matrix_get__node__html___closed__18;
x_94 = lean_nat_add(x_92, x_91);
lean_dec(x_92);
x_95 = l_Nat_reprFast(x_94);
x_96 = lean_string_append(x_93, x_95);
lean_dec_ref(x_95);
x_70 = x_96;
goto block_85;
}
block_31:
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_16 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_16, 0, x_15);
if (lean_is_scalar(x_6)) {
 x_17 = lean_alloc_ctor(0, 2, 0);
} else {
 x_17 = x_6;
}
lean_ctor_set(x_17, 0, x_11);
lean_ctor_set(x_17, 1, x_16);
x_18 = l_Matrix_get__edge__html___closed__1;
x_19 = l_Matrix_get__node__html___closed__12;
x_20 = l_Matrix_get__edge__html___closed__2;
x_21 = lean_array_push(x_20, x_13);
x_22 = lean_array_push(x_21, x_14);
x_23 = lean_array_push(x_22, x_12);
x_24 = lean_array_push(x_23, x_17);
x_25 = lean_array_push(x_24, x_18);
x_26 = lean_array_push(x_25, x_19);
x_27 = lean_box(0);
x_28 = l_Matrix_get__node__html___closed__14;
x_29 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_29, 0, x_10);
lean_ctor_set(x_29, 1, x_26);
lean_ctor_set(x_29, 2, x_28);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_29);
lean_ctor_set(x_30, 1, x_27);
return x_30;
}
block_50:
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; 
x_36 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_36, 0, x_35);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_33);
lean_ctor_set(x_37, 1, x_36);
x_38 = l_Matrix_get__edge__html___closed__3;
x_39 = l_Matrix_get__node__cy(x_1, x_5);
x_40 = lean_int_dec_lt(x_39, x_8);
if (x_40 == 0)
{
lean_object* x_41; lean_object* x_42; 
x_41 = lean_nat_abs(x_39);
lean_dec(x_39);
x_42 = l_Nat_reprFast(x_41);
x_11 = x_38;
x_12 = x_37;
x_13 = x_32;
x_14 = x_34;
x_15 = x_42;
goto block_31;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_43 = lean_nat_abs(x_39);
lean_dec(x_39);
x_44 = lean_unsigned_to_nat(1u);
x_45 = lean_nat_sub(x_43, x_44);
lean_dec(x_43);
x_46 = l_Matrix_get__node__html___closed__18;
x_47 = lean_nat_add(x_45, x_44);
lean_dec(x_45);
x_48 = l_Nat_reprFast(x_47);
x_49 = lean_string_append(x_46, x_48);
lean_dec_ref(x_48);
x_11 = x_38;
x_12 = x_37;
x_13 = x_32;
x_14 = x_34;
x_15 = x_49;
goto block_31;
}
}
block_68:
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; uint8_t x_58; 
x_54 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_54, 0, x_53);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_51);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Matrix_get__edge__html___closed__4;
lean_inc(x_5);
x_57 = l_Matrix_get__node__cx(x_1, x_5);
x_58 = lean_int_dec_lt(x_57, x_8);
if (x_58 == 0)
{
lean_object* x_59; lean_object* x_60; 
x_59 = lean_nat_abs(x_57);
lean_dec(x_57);
x_60 = l_Nat_reprFast(x_59);
x_32 = x_52;
x_33 = x_56;
x_34 = x_55;
x_35 = x_60;
goto block_50;
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_61 = lean_nat_abs(x_57);
lean_dec(x_57);
x_62 = lean_unsigned_to_nat(1u);
x_63 = lean_nat_sub(x_61, x_62);
lean_dec(x_61);
x_64 = l_Matrix_get__node__html___closed__18;
x_65 = lean_nat_add(x_63, x_62);
lean_dec(x_63);
x_66 = l_Nat_reprFast(x_65);
x_67 = lean_string_append(x_64, x_66);
lean_dec_ref(x_66);
x_32 = x_52;
x_33 = x_56;
x_34 = x_55;
x_35 = x_67;
goto block_50;
}
}
block_85:
{
lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; uint8_t x_75; 
x_71 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_71, 0, x_70);
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_69);
lean_ctor_set(x_72, 1, x_71);
x_73 = l_Matrix_get__edge__html___closed__6;
x_74 = l_Matrix_get__node__cy(x_1, x_4);
x_75 = lean_int_dec_lt(x_74, x_8);
if (x_75 == 0)
{
lean_object* x_76; lean_object* x_77; 
x_76 = lean_nat_abs(x_74);
lean_dec(x_74);
x_77 = l_Nat_reprFast(x_76);
x_51 = x_73;
x_52 = x_72;
x_53 = x_77;
goto block_68;
}
else
{
lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; 
x_78 = lean_nat_abs(x_74);
lean_dec(x_74);
x_79 = lean_unsigned_to_nat(1u);
x_80 = lean_nat_sub(x_78, x_79);
lean_dec(x_78);
x_81 = l_Matrix_get__node__html___closed__18;
x_82 = lean_nat_add(x_80, x_79);
lean_dec(x_80);
x_83 = l_Nat_reprFast(x_82);
x_84 = lean_string_append(x_81, x_83);
lean_dec_ref(x_83);
x_51 = x_73;
x_52 = x_72;
x_53 = x_84;
goto block_68;
}
}
}
else
{
lean_object* x_97; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_97 = lean_box(0);
return x_97;
}
}
}
LEAN_EXPORT lean_object* l_Matrix_get__edge__html___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Matrix_get__edge__html(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_4; 
x_4 = l_List_reverse___redArg(x_3);
return x_4;
}
else
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_2);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_2, 0);
x_7 = lean_ctor_get(x_2, 1);
x_8 = l_Matrix_get__node__html(x_1, x_6);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_8);
{
lean_object* _tmp_1 = x_7;
lean_object* _tmp_2 = x_2;
x_2 = _tmp_1;
x_3 = _tmp_2;
}
goto _start;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_10 = lean_ctor_get(x_2, 0);
x_11 = lean_ctor_get(x_2, 1);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_2);
x_12 = l_Matrix_get__node__html(x_1, x_10);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_3);
x_2 = x_11;
x_3 = x_13;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Matrix_get__nodes__html(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; 
lean_inc(x_1);
x_2 = l_List_range(x_1);
x_3 = lean_box(0);
x_4 = l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_List_mapTR_loop___at___Matrix_get__nodes__html_spec__0(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_7 = lean_ctor_get(x_4, 1);
x_8 = lean_ctor_get(x_4, 2);
x_9 = lean_nat_dec_lt(x_6, x_7);
if (x_9 == 0)
{
lean_dec(x_6);
lean_dec_ref(x_3);
lean_dec(x_1);
return x_5;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
lean_inc(x_1);
lean_inc(x_6);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_6);
lean_ctor_set(x_10, 1, x_1);
lean_inc_ref(x_3);
x_11 = l_Matrix_get__edge__html(x_2, x_3, x_10);
x_12 = l_List_appendTR___redArg(x_11, x_5);
x_13 = lean_nat_add(x_6, x_8);
lean_dec(x_6);
x_5 = x_12;
x_6 = x_13;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = lean_ctor_get(x_5, 1);
x_9 = lean_ctor_get(x_5, 2);
x_10 = lean_nat_dec_lt(x_7, x_8);
if (x_10 == 0)
{
lean_dec(x_7);
lean_dec_ref(x_4);
lean_dec(x_2);
lean_dec(x_1);
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
lean_inc(x_2);
lean_inc(x_7);
lean_inc(x_1);
x_11 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_11, 0, x_1);
lean_ctor_set(x_11, 1, x_7);
lean_ctor_set(x_11, 2, x_2);
lean_inc(x_1);
lean_inc_ref(x_4);
lean_inc(x_7);
x_12 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(x_7, x_3, x_4, x_11, x_6, x_1);
lean_dec_ref(x_11);
x_13 = lean_nat_add(x_7, x_9);
lean_dec(x_7);
x_6 = x_12;
x_7 = x_13;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
return x_10;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = lean_ctor_get(x_5, 1);
x_9 = lean_ctor_get(x_5, 2);
x_10 = lean_nat_dec_lt(x_7, x_8);
if (x_10 == 0)
{
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
lean_inc(x_4);
lean_inc(x_7);
lean_inc(x_3);
x_11 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_11, 0, x_3);
lean_ctor_set(x_11, 1, x_7);
lean_ctor_set(x_11, 2, x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
lean_inc(x_7);
x_12 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(x_7, x_1, x_2, x_11, x_6, x_3);
lean_dec_ref(x_11);
x_13 = lean_nat_add(x_7, x_9);
lean_dec(x_7);
x_14 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg(x_3, x_4, x_1, x_2, x_5, x_12, x_13);
return x_14;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Matrix_get__edges__html(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = lean_box(0);
x_4 = lean_unsigned_to_nat(0u);
x_5 = lean_unsigned_to_nat(1u);
lean_inc(x_1);
x_6 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_1);
lean_ctor_set(x_6, 2, x_5);
x_7 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg(x_1, x_2, x_4, x_5, x_6, x_3, x_4);
lean_dec_ref(x_6);
lean_dec(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec_ref(x_4);
lean_dec(x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec_ref(x_4);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec_ref(x_5);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at_____private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec_ref(x_5);
lean_dec(x_3);
return x_10;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec_ref(x_5);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Init_Data_Range_Basic_0__Std_Range_forIn_x27_loop___at___Matrix_get__edges__html_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec_ref(x_5);
lean_dec(x_1);
return x_10;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("style", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("height", 6, 6);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("100px", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_toHtml___closed__3;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__4;
x_2 = l_Matrix_toHtml___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("width", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("300px", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_toHtml___closed__7;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__8;
x_2 = l_Matrix_toHtml___closed__6;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("background", 10, 10);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("grey", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_toHtml___closed__11;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__12;
x_2 = l_Matrix_toHtml___closed__10;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Matrix_toHtml___closed__13;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__14;
x_2 = l_Matrix_toHtml___closed__9;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__15;
x_2 = l_Matrix_toHtml___closed__5;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Matrix_toHtml___closed__16;
x_2 = l_Lean_Json_mkObj(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__17;
x_2 = l_Matrix_toHtml___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Matrix_toHtml___closed__18;
x_2 = l_Matrix_toHtml___closed__19;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("svg", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Matrix_toHtml___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Matrix_toHtml(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_3 = l_Matrix_toHtml___closed__0;
x_4 = l_Matrix_toHtml___closed__19;
x_5 = l_Matrix_toHtml___closed__20;
x_6 = l_Matrix_toHtml___closed__21;
x_7 = l_Matrix_toHtml___closed__22;
lean_inc(x_1);
x_8 = l_Matrix_get__edges__html(x_1, x_2);
x_9 = l_Matrix_get__nodes__html(x_1);
x_10 = l_List_appendTR___redArg(x_8, x_9);
x_11 = lean_array_mk(x_10);
x_12 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_12, 0, x_6);
lean_ctor_set(x_12, 1, x_7);
lean_ctor_set(x_12, 2, x_11);
x_13 = lean_array_push(x_4, x_12);
x_14 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_14, 0, x_3);
lean_ctor_set(x_14, 1, x_5);
lean_ctor_set(x_14, 2, x_13);
return x_14;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_cartanMatrix_E_u2088___closed__1;
x_2 = lean_int_neg(x_1);
return x_2;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__3;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__4;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__5;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__6;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__7;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__8;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__9;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__6;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__11;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__12;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__13;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__11;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__15;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__16;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__5;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__18;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__19;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__20;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__21;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__4;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__23;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__24;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__25;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__27() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__26;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__27;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__3;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__29;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__31() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__30;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__31;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__32;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__34() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__33;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__34;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__36() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__36;
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__38() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__37;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__39() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__38;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__40() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__39;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__41() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__40;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__42() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__41;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__43() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__42;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__44() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_cartanMatrix_E_u2088___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__45() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__44;
x_2 = l_cartanMatrix_E_u2088___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__46() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__45;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__47() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__46;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__48() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__47;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__49() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__48;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__50() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__49;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__51() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__50;
x_2 = l_Matrix_get__node__html___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__52() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_cartanMatrix_E_u2088___closed__51;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__53() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__52;
x_2 = l_cartanMatrix_E_u2088___closed__43;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__54() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__53;
x_2 = l_cartanMatrix_E_u2088___closed__35;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__55() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__54;
x_2 = l_cartanMatrix_E_u2088___closed__28;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__56() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__55;
x_2 = l_cartanMatrix_E_u2088___closed__22;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__57() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__56;
x_2 = l_cartanMatrix_E_u2088___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__58() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__57;
x_2 = l_cartanMatrix_E_u2088___closed__14;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_cartanMatrix_E_u2088___closed__59() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_cartanMatrix_E_u2088___closed__58;
x_2 = l_cartanMatrix_E_u2088___closed__10;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_cartanMatrix_E_u2088(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = l_Int_instInhabited;
x_4 = lean_box(0);
x_5 = l_cartanMatrix_E_u2088___closed__59;
x_6 = l_List_get_x21Internal___redArg(x_4, x_5, x_1);
x_7 = l_List_get_x21Internal___redArg(x_3, x_6, x_2);
lean_dec(x_6);
return x_7;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Dynkin(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Matrix_nat__index___closed__0 = _init_l_Matrix_nat__index___closed__0();
lean_mark_persistent(l_Matrix_nat__index___closed__0);
l_Matrix_get__node__pos__E___closed__0 = _init_l_Matrix_get__node__pos__E___closed__0();
lean_mark_persistent(l_Matrix_get__node__pos__E___closed__0);
l_Matrix_get__node__pos__E___closed__1 = _init_l_Matrix_get__node__pos__E___closed__1();
lean_mark_persistent(l_Matrix_get__node__pos__E___closed__1);
l_Matrix_get__node__cx___closed__0 = _init_l_Matrix_get__node__cx___closed__0();
lean_mark_persistent(l_Matrix_get__node__cx___closed__0);
l_Matrix_get__node__cx___closed__1 = _init_l_Matrix_get__node__cx___closed__1();
lean_mark_persistent(l_Matrix_get__node__cx___closed__1);
l_Matrix_get__node__html___closed__0 = _init_l_Matrix_get__node__html___closed__0();
lean_mark_persistent(l_Matrix_get__node__html___closed__0);
l_Matrix_get__node__html___closed__1 = _init_l_Matrix_get__node__html___closed__1();
lean_mark_persistent(l_Matrix_get__node__html___closed__1);
l_Matrix_get__node__html___closed__2 = _init_l_Matrix_get__node__html___closed__2();
lean_mark_persistent(l_Matrix_get__node__html___closed__2);
l_Matrix_get__node__html___closed__3 = _init_l_Matrix_get__node__html___closed__3();
lean_mark_persistent(l_Matrix_get__node__html___closed__3);
l_Matrix_get__node__html___closed__4 = _init_l_Matrix_get__node__html___closed__4();
lean_mark_persistent(l_Matrix_get__node__html___closed__4);
l_Matrix_get__node__html___closed__5 = _init_l_Matrix_get__node__html___closed__5();
lean_mark_persistent(l_Matrix_get__node__html___closed__5);
l_Matrix_get__node__html___closed__6 = _init_l_Matrix_get__node__html___closed__6();
lean_mark_persistent(l_Matrix_get__node__html___closed__6);
l_Matrix_get__node__html___closed__7 = _init_l_Matrix_get__node__html___closed__7();
lean_mark_persistent(l_Matrix_get__node__html___closed__7);
l_Matrix_get__node__html___closed__8 = _init_l_Matrix_get__node__html___closed__8();
lean_mark_persistent(l_Matrix_get__node__html___closed__8);
l_Matrix_get__node__html___closed__9 = _init_l_Matrix_get__node__html___closed__9();
lean_mark_persistent(l_Matrix_get__node__html___closed__9);
l_Matrix_get__node__html___closed__10 = _init_l_Matrix_get__node__html___closed__10();
lean_mark_persistent(l_Matrix_get__node__html___closed__10);
l_Matrix_get__node__html___closed__11 = _init_l_Matrix_get__node__html___closed__11();
lean_mark_persistent(l_Matrix_get__node__html___closed__11);
l_Matrix_get__node__html___closed__12 = _init_l_Matrix_get__node__html___closed__12();
lean_mark_persistent(l_Matrix_get__node__html___closed__12);
l_Matrix_get__node__html___closed__13 = _init_l_Matrix_get__node__html___closed__13();
lean_mark_persistent(l_Matrix_get__node__html___closed__13);
l_Matrix_get__node__html___closed__14 = _init_l_Matrix_get__node__html___closed__14();
lean_mark_persistent(l_Matrix_get__node__html___closed__14);
l_Matrix_get__node__html___closed__15 = _init_l_Matrix_get__node__html___closed__15();
lean_mark_persistent(l_Matrix_get__node__html___closed__15);
l_Matrix_get__node__html___closed__16 = _init_l_Matrix_get__node__html___closed__16();
lean_mark_persistent(l_Matrix_get__node__html___closed__16);
l_Matrix_get__node__html___closed__17 = _init_l_Matrix_get__node__html___closed__17();
lean_mark_persistent(l_Matrix_get__node__html___closed__17);
l_Matrix_get__node__html___closed__18 = _init_l_Matrix_get__node__html___closed__18();
lean_mark_persistent(l_Matrix_get__node__html___closed__18);
l_Matrix_get__edge__html___closed__0 = _init_l_Matrix_get__edge__html___closed__0();
lean_mark_persistent(l_Matrix_get__edge__html___closed__0);
l_Matrix_get__edge__html___closed__1 = _init_l_Matrix_get__edge__html___closed__1();
lean_mark_persistent(l_Matrix_get__edge__html___closed__1);
l_Matrix_get__edge__html___closed__2 = _init_l_Matrix_get__edge__html___closed__2();
lean_mark_persistent(l_Matrix_get__edge__html___closed__2);
l_Matrix_get__edge__html___closed__3 = _init_l_Matrix_get__edge__html___closed__3();
lean_mark_persistent(l_Matrix_get__edge__html___closed__3);
l_Matrix_get__edge__html___closed__4 = _init_l_Matrix_get__edge__html___closed__4();
lean_mark_persistent(l_Matrix_get__edge__html___closed__4);
l_Matrix_get__edge__html___closed__5 = _init_l_Matrix_get__edge__html___closed__5();
lean_mark_persistent(l_Matrix_get__edge__html___closed__5);
l_Matrix_get__edge__html___closed__6 = _init_l_Matrix_get__edge__html___closed__6();
lean_mark_persistent(l_Matrix_get__edge__html___closed__6);
l_Matrix_toHtml___closed__0 = _init_l_Matrix_toHtml___closed__0();
lean_mark_persistent(l_Matrix_toHtml___closed__0);
l_Matrix_toHtml___closed__1 = _init_l_Matrix_toHtml___closed__1();
lean_mark_persistent(l_Matrix_toHtml___closed__1);
l_Matrix_toHtml___closed__2 = _init_l_Matrix_toHtml___closed__2();
lean_mark_persistent(l_Matrix_toHtml___closed__2);
l_Matrix_toHtml___closed__3 = _init_l_Matrix_toHtml___closed__3();
lean_mark_persistent(l_Matrix_toHtml___closed__3);
l_Matrix_toHtml___closed__4 = _init_l_Matrix_toHtml___closed__4();
lean_mark_persistent(l_Matrix_toHtml___closed__4);
l_Matrix_toHtml___closed__5 = _init_l_Matrix_toHtml___closed__5();
lean_mark_persistent(l_Matrix_toHtml___closed__5);
l_Matrix_toHtml___closed__6 = _init_l_Matrix_toHtml___closed__6();
lean_mark_persistent(l_Matrix_toHtml___closed__6);
l_Matrix_toHtml___closed__7 = _init_l_Matrix_toHtml___closed__7();
lean_mark_persistent(l_Matrix_toHtml___closed__7);
l_Matrix_toHtml___closed__8 = _init_l_Matrix_toHtml___closed__8();
lean_mark_persistent(l_Matrix_toHtml___closed__8);
l_Matrix_toHtml___closed__9 = _init_l_Matrix_toHtml___closed__9();
lean_mark_persistent(l_Matrix_toHtml___closed__9);
l_Matrix_toHtml___closed__10 = _init_l_Matrix_toHtml___closed__10();
lean_mark_persistent(l_Matrix_toHtml___closed__10);
l_Matrix_toHtml___closed__11 = _init_l_Matrix_toHtml___closed__11();
lean_mark_persistent(l_Matrix_toHtml___closed__11);
l_Matrix_toHtml___closed__12 = _init_l_Matrix_toHtml___closed__12();
lean_mark_persistent(l_Matrix_toHtml___closed__12);
l_Matrix_toHtml___closed__13 = _init_l_Matrix_toHtml___closed__13();
lean_mark_persistent(l_Matrix_toHtml___closed__13);
l_Matrix_toHtml___closed__14 = _init_l_Matrix_toHtml___closed__14();
lean_mark_persistent(l_Matrix_toHtml___closed__14);
l_Matrix_toHtml___closed__15 = _init_l_Matrix_toHtml___closed__15();
lean_mark_persistent(l_Matrix_toHtml___closed__15);
l_Matrix_toHtml___closed__16 = _init_l_Matrix_toHtml___closed__16();
lean_mark_persistent(l_Matrix_toHtml___closed__16);
l_Matrix_toHtml___closed__17 = _init_l_Matrix_toHtml___closed__17();
lean_mark_persistent(l_Matrix_toHtml___closed__17);
l_Matrix_toHtml___closed__18 = _init_l_Matrix_toHtml___closed__18();
lean_mark_persistent(l_Matrix_toHtml___closed__18);
l_Matrix_toHtml___closed__19 = _init_l_Matrix_toHtml___closed__19();
lean_mark_persistent(l_Matrix_toHtml___closed__19);
l_Matrix_toHtml___closed__20 = _init_l_Matrix_toHtml___closed__20();
lean_mark_persistent(l_Matrix_toHtml___closed__20);
l_Matrix_toHtml___closed__21 = _init_l_Matrix_toHtml___closed__21();
lean_mark_persistent(l_Matrix_toHtml___closed__21);
l_Matrix_toHtml___closed__22 = _init_l_Matrix_toHtml___closed__22();
lean_mark_persistent(l_Matrix_toHtml___closed__22);
l_cartanMatrix_E_u2088___closed__0 = _init_l_cartanMatrix_E_u2088___closed__0();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__0);
l_cartanMatrix_E_u2088___closed__1 = _init_l_cartanMatrix_E_u2088___closed__1();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__1);
l_cartanMatrix_E_u2088___closed__2 = _init_l_cartanMatrix_E_u2088___closed__2();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__2);
l_cartanMatrix_E_u2088___closed__3 = _init_l_cartanMatrix_E_u2088___closed__3();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__3);
l_cartanMatrix_E_u2088___closed__4 = _init_l_cartanMatrix_E_u2088___closed__4();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__4);
l_cartanMatrix_E_u2088___closed__5 = _init_l_cartanMatrix_E_u2088___closed__5();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__5);
l_cartanMatrix_E_u2088___closed__6 = _init_l_cartanMatrix_E_u2088___closed__6();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__6);
l_cartanMatrix_E_u2088___closed__7 = _init_l_cartanMatrix_E_u2088___closed__7();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__7);
l_cartanMatrix_E_u2088___closed__8 = _init_l_cartanMatrix_E_u2088___closed__8();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__8);
l_cartanMatrix_E_u2088___closed__9 = _init_l_cartanMatrix_E_u2088___closed__9();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__9);
l_cartanMatrix_E_u2088___closed__10 = _init_l_cartanMatrix_E_u2088___closed__10();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__10);
l_cartanMatrix_E_u2088___closed__11 = _init_l_cartanMatrix_E_u2088___closed__11();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__11);
l_cartanMatrix_E_u2088___closed__12 = _init_l_cartanMatrix_E_u2088___closed__12();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__12);
l_cartanMatrix_E_u2088___closed__13 = _init_l_cartanMatrix_E_u2088___closed__13();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__13);
l_cartanMatrix_E_u2088___closed__14 = _init_l_cartanMatrix_E_u2088___closed__14();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__14);
l_cartanMatrix_E_u2088___closed__15 = _init_l_cartanMatrix_E_u2088___closed__15();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__15);
l_cartanMatrix_E_u2088___closed__16 = _init_l_cartanMatrix_E_u2088___closed__16();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__16);
l_cartanMatrix_E_u2088___closed__17 = _init_l_cartanMatrix_E_u2088___closed__17();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__17);
l_cartanMatrix_E_u2088___closed__18 = _init_l_cartanMatrix_E_u2088___closed__18();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__18);
l_cartanMatrix_E_u2088___closed__19 = _init_l_cartanMatrix_E_u2088___closed__19();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__19);
l_cartanMatrix_E_u2088___closed__20 = _init_l_cartanMatrix_E_u2088___closed__20();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__20);
l_cartanMatrix_E_u2088___closed__21 = _init_l_cartanMatrix_E_u2088___closed__21();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__21);
l_cartanMatrix_E_u2088___closed__22 = _init_l_cartanMatrix_E_u2088___closed__22();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__22);
l_cartanMatrix_E_u2088___closed__23 = _init_l_cartanMatrix_E_u2088___closed__23();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__23);
l_cartanMatrix_E_u2088___closed__24 = _init_l_cartanMatrix_E_u2088___closed__24();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__24);
l_cartanMatrix_E_u2088___closed__25 = _init_l_cartanMatrix_E_u2088___closed__25();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__25);
l_cartanMatrix_E_u2088___closed__26 = _init_l_cartanMatrix_E_u2088___closed__26();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__26);
l_cartanMatrix_E_u2088___closed__27 = _init_l_cartanMatrix_E_u2088___closed__27();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__27);
l_cartanMatrix_E_u2088___closed__28 = _init_l_cartanMatrix_E_u2088___closed__28();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__28);
l_cartanMatrix_E_u2088___closed__29 = _init_l_cartanMatrix_E_u2088___closed__29();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__29);
l_cartanMatrix_E_u2088___closed__30 = _init_l_cartanMatrix_E_u2088___closed__30();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__30);
l_cartanMatrix_E_u2088___closed__31 = _init_l_cartanMatrix_E_u2088___closed__31();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__31);
l_cartanMatrix_E_u2088___closed__32 = _init_l_cartanMatrix_E_u2088___closed__32();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__32);
l_cartanMatrix_E_u2088___closed__33 = _init_l_cartanMatrix_E_u2088___closed__33();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__33);
l_cartanMatrix_E_u2088___closed__34 = _init_l_cartanMatrix_E_u2088___closed__34();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__34);
l_cartanMatrix_E_u2088___closed__35 = _init_l_cartanMatrix_E_u2088___closed__35();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__35);
l_cartanMatrix_E_u2088___closed__36 = _init_l_cartanMatrix_E_u2088___closed__36();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__36);
l_cartanMatrix_E_u2088___closed__37 = _init_l_cartanMatrix_E_u2088___closed__37();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__37);
l_cartanMatrix_E_u2088___closed__38 = _init_l_cartanMatrix_E_u2088___closed__38();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__38);
l_cartanMatrix_E_u2088___closed__39 = _init_l_cartanMatrix_E_u2088___closed__39();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__39);
l_cartanMatrix_E_u2088___closed__40 = _init_l_cartanMatrix_E_u2088___closed__40();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__40);
l_cartanMatrix_E_u2088___closed__41 = _init_l_cartanMatrix_E_u2088___closed__41();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__41);
l_cartanMatrix_E_u2088___closed__42 = _init_l_cartanMatrix_E_u2088___closed__42();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__42);
l_cartanMatrix_E_u2088___closed__43 = _init_l_cartanMatrix_E_u2088___closed__43();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__43);
l_cartanMatrix_E_u2088___closed__44 = _init_l_cartanMatrix_E_u2088___closed__44();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__44);
l_cartanMatrix_E_u2088___closed__45 = _init_l_cartanMatrix_E_u2088___closed__45();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__45);
l_cartanMatrix_E_u2088___closed__46 = _init_l_cartanMatrix_E_u2088___closed__46();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__46);
l_cartanMatrix_E_u2088___closed__47 = _init_l_cartanMatrix_E_u2088___closed__47();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__47);
l_cartanMatrix_E_u2088___closed__48 = _init_l_cartanMatrix_E_u2088___closed__48();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__48);
l_cartanMatrix_E_u2088___closed__49 = _init_l_cartanMatrix_E_u2088___closed__49();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__49);
l_cartanMatrix_E_u2088___closed__50 = _init_l_cartanMatrix_E_u2088___closed__50();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__50);
l_cartanMatrix_E_u2088___closed__51 = _init_l_cartanMatrix_E_u2088___closed__51();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__51);
l_cartanMatrix_E_u2088___closed__52 = _init_l_cartanMatrix_E_u2088___closed__52();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__52);
l_cartanMatrix_E_u2088___closed__53 = _init_l_cartanMatrix_E_u2088___closed__53();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__53);
l_cartanMatrix_E_u2088___closed__54 = _init_l_cartanMatrix_E_u2088___closed__54();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__54);
l_cartanMatrix_E_u2088___closed__55 = _init_l_cartanMatrix_E_u2088___closed__55();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__55);
l_cartanMatrix_E_u2088___closed__56 = _init_l_cartanMatrix_E_u2088___closed__56();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__56);
l_cartanMatrix_E_u2088___closed__57 = _init_l_cartanMatrix_E_u2088___closed__57();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__57);
l_cartanMatrix_E_u2088___closed__58 = _init_l_cartanMatrix_E_u2088___closed__58();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__58);
l_cartanMatrix_E_u2088___closed__59 = _init_l_cartanMatrix_E_u2088___closed__59();
lean_mark_persistent(l_cartanMatrix_E_u2088___closed__59);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
