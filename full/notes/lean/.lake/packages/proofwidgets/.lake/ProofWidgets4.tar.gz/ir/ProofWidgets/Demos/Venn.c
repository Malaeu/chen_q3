// Lean compiler output
// Module: ProofWidgets.Demos.Venn
// Imports: Init Lean.Elab.Tactic ProofWidgets.Component.Panel.Basic ProofWidgets.Component.PenroseDiagram ProofWidgets.Component.HtmlDisplay ProofWidgets.Component.OfRpcMethod
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
static lean_object* l_VennDisplay_rpc___lam__2___closed__5;
static lean_object* l_VennDisplay_rpc___lam__2___closed__33;
lean_object* l_Lean_Meta_ppExpr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isSubsetPred_x3f___boxed(lean_object*);
lean_object* lean_format_pretty(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1;
lean_object* l_Lean_Json_compress(lean_object*);
static lean_object* l_VennDisplay_rpc___lam__0___closed__0;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2(lean_object*, size_t, size_t, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1;
extern lean_object* l_ProofWidgets_InteractiveCode;
static lean_object* l_VennDisplay_rpc___lam__2___closed__17;
extern lean_object* l_ProofWidgets_Penrose_Diagram;
static lean_object* l_isSetGoal_x3f___closed__0;
uint8_t l_Array_isEmpty___redArg(lean_object*);
static lean_object* l_isSetGoal_x3f___closed__4;
size_t lean_uint64_to_usize(uint64_t);
static lean_object* l_isSetGoal_x3f___closed__2;
uint8_t l_Lean_Expr_isAppOfArity(lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_mkSetDiag___closed__0;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__32;
static lean_object* l_isSetGoal_x3f___closed__6;
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__2___redArg(lean_object*);
lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___rpc__wrapped___closed__3;
static lean_object* l_VennDisplay_rpc___lam__0___closed__4;
static lean_object* l_VennDisplay_rpc___lam__2___closed__16;
static lean_object* l_VennDisplay_rpc___lam__0___closed__2;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_findGoalForLocation___closed__0;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__28;
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_instToJsonGoalsLocation_toJson(lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__34;
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__24;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0;
static lean_object* l_mkSetDiag___closed__1;
static lean_object* l_VennDisplay_rpc___rpc__wrapped___closed__0;
static lean_object* l_VennDisplay___closed__4;
LEAN_EXPORT lean_object* l_mkSetDiag(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_isSubsetPred_x3f___closed__1;
LEAN_EXPORT lean_object* l_isSetGoal_x3f(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0;
LEAN_EXPORT lean_object* l_isSubsetPred_x3f(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__27;
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
static lean_object* l_VennDisplay_rpc___lam__2___closed__10;
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0(size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__1(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___rpc__wrapped___closed__2;
static lean_object* l_VennDisplay_rpc___lam__0___closed__3;
static lean_object* l_VennDisplay_rpc___lam__2___closed__18;
LEAN_EXPORT lean_object* l_VennDisplay;
static lean_object* l_VennDisplay_rpc___lam__2___closed__2;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__22;
static lean_object* l_VennDisplay_rpc___lam__2___closed__29;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__26;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay___closed__3;
static lean_object* l_VennDisplay_rpc___lam__2___closed__25;
static lean_object* l_VennDisplay_rpc___lam__0___closed__1;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_isSetGoal_x3f___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_EStateM_instInhabited___redArg___lam__0(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__12;
static lean_object* l_VennDisplay___closed__0;
uint8_t lean_name_eq(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_VennDisplay_rpc___rpc__wrapped;
static lean_object* l_VennDisplay_rpc___lam__2___closed__15;
uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_contains___at___Lean_Meta_Rewrites_takeListAux_spec__0_spec__0___redArg(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__20;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_Expr_appFn_x21(lean_object*);
LEAN_EXPORT lean_object* l_Set_instLE(lean_object*);
lean_object* l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_addExpr_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_isSetGoal_x3f___closed__5;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isSubsetPred_x3f___closed__2;
static lean_object* l_VennDisplay_rpc___lam__2___closed__35;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2;
static lean_object* l_isSetGoal_x3f___closed__3;
static lean_object* l_VennDisplay_rpc___lam__2___closed__8;
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_Server_instInhabitedRequestError_default;
lean_object* l_Lean_Meta_withLCtx___at___Lean_Meta_withErasedFVars___at_____private_Lean_Meta_Tactic_FunInd_0__Lean_Tactic_FunInd_deriveInductionStructural_doRealize_spec__36_spec__36___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__23;
static lean_object* l_VennDisplay_rpc___lam__2___closed__7;
LEAN_EXPORT lean_object* l_Array_filterMapM___at___VennDisplay_rpc_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3;
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_MVarId_getDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__6;
static lean_object* l_isSubsetPred_x3f___closed__0;
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_buildDiagram_spec__1(lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__19;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
lean_object* l_Lean_instantiateMVars___at___Lean_Tactic_FunInd_rwMatcher_spec__6___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_filterMapM___at___VennDisplay_rpc_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
lean_object* lean_panic_fn(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__13;
static lean_object* l_VennDisplay_rpc___lam__2___closed__14;
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__1;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0;
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1___boxed(lean_object*, lean_object*);
static uint64_t l_VennDisplay___closed__1;
static lean_object* l_VennDisplay_rpc___lam__2___closed__9;
LEAN_EXPORT lean_object* l_panic___at___VennDisplay_rpc_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__30;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_sub(size_t, size_t);
LEAN_EXPORT lean_object* l_VennDisplay_rpc(lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
lean_object* l_Lean_FVarId_getDecl___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_panic___at___VennDisplay_rpc_spec__0___closed__0;
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
static lean_object* l_VennDisplay___closed__2;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
LEAN_EXPORT lean_object* l_Set_instMembership(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__2(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Lean_LocalContext_sanitizeNames(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__11;
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
static lean_object* l_isSetGoal_x3f___closed__1;
static lean_object* l_VennDisplay_rpc___lam__2___closed__21;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1(lean_object*, lean_object*);
lean_object* l_Lean_Json_pretty(lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__0;
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__3;
static lean_object* l_VennDisplay_rpc___lam__2___closed__4;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_Set_instHasSubset(lean_object*);
size_t lean_usize_land(size_t, size_t);
lean_object* l_Lean_Server_RequestError_invalidParams(lean_object*);
static lean_object* l_VennDisplay_rpc___lam__2___closed__31;
lean_object* l_Std_DHashMap_Internal_AssocList_replace___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__5___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Set_instMembership(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Set_instLE(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Set_instHasSubset(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
static lean_object* _init_l_isSubsetPred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("HasSubset", 9, 9);
return x_1;
}
}
static lean_object* _init_l_isSubsetPred_x3f___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Subset", 6, 6);
return x_1;
}
}
static lean_object* _init_l_isSubsetPred_x3f___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isSubsetPred_x3f___closed__1;
x_2 = l_isSubsetPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isSubsetPred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isSubsetPred_x3f___closed__2;
x_3 = lean_unsigned_to_nat(4u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec_ref(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isSubsetPred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isSubsetPred_x3f(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint8_t x_9; 
x_9 = lean_usize_dec_lt(x_2, x_1);
if (x_9 == 0)
{
lean_object* x_10; 
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_3);
lean_ctor_set(x_10, 1, x_8);
return x_10;
}
else
{
lean_object* x_11; uint8_t x_12; 
x_11 = lean_array_uget(x_3, x_2);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_ctor_get(x_11, 0);
x_14 = lean_ctor_get(x_11, 1);
x_15 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0;
lean_inc(x_7);
lean_inc_ref(x_6);
lean_inc(x_5);
lean_inc_ref(x_4);
x_16 = l_Lean_Widget_ppExprTagged(x_14, x_15, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_16) == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; size_t x_24; size_t x_25; lean_object* x_26; 
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_unsigned_to_nat(0u);
x_20 = lean_array_uset(x_3, x_2, x_19);
x_21 = l_ProofWidgets_InteractiveCode;
x_22 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1;
x_23 = l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_addExpr_spec__0(x_21, x_17, x_22);
lean_ctor_set(x_11, 1, x_23);
x_24 = 1;
x_25 = lean_usize_add(x_2, x_24);
x_26 = lean_array_uset(x_20, x_2, x_11);
x_2 = x_25;
x_3 = x_26;
x_8 = x_18;
goto _start;
}
else
{
uint8_t x_28; 
lean_free_object(x_11);
lean_dec(x_13);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
x_28 = !lean_is_exclusive(x_16);
if (x_28 == 0)
{
return x_16;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_29 = lean_ctor_get(x_16, 0);
x_30 = lean_ctor_get(x_16, 1);
lean_inc(x_30);
lean_inc(x_29);
lean_dec(x_16);
x_31 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_31, 0, x_29);
lean_ctor_set(x_31, 1, x_30);
return x_31;
}
}
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_32 = lean_ctor_get(x_11, 0);
x_33 = lean_ctor_get(x_11, 1);
lean_inc(x_33);
lean_inc(x_32);
lean_dec(x_11);
x_34 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0;
lean_inc(x_7);
lean_inc_ref(x_6);
lean_inc(x_5);
lean_inc_ref(x_4);
x_35 = l_Lean_Widget_ppExprTagged(x_33, x_34, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_35) == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; size_t x_44; size_t x_45; lean_object* x_46; 
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
x_37 = lean_ctor_get(x_35, 1);
lean_inc(x_37);
lean_dec_ref(x_35);
x_38 = lean_unsigned_to_nat(0u);
x_39 = lean_array_uset(x_3, x_2, x_38);
x_40 = l_ProofWidgets_InteractiveCode;
x_41 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1;
x_42 = l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_addExpr_spec__0(x_40, x_36, x_41);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_32);
lean_ctor_set(x_43, 1, x_42);
x_44 = 1;
x_45 = lean_usize_add(x_2, x_44);
x_46 = lean_array_uset(x_39, x_2, x_43);
x_2 = x_45;
x_3 = x_46;
x_8 = x_37;
goto _start;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
lean_dec(x_32);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
x_48 = lean_ctor_get(x_35, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_35, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_35)) {
 lean_ctor_release(x_35, 0);
 lean_ctor_release(x_35, 1);
 x_50 = x_35;
} else {
 lean_dec_ref(x_35);
 x_50 = lean_box(0);
}
if (lean_is_scalar(x_50)) {
 x_51 = lean_alloc_ctor(1, 2, 0);
} else {
 x_51 = x_50;
}
lean_ctor_set(x_51, 0, x_48);
lean_ctor_set(x_51, 1, x_49);
return x_51;
}
}
}
}
}
static lean_object* _init_l_mkSetDiag___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("type Set\n\npredicate Not(Prop p1)\npredicate Intersecting(Set s1, Set s2)\npredicate IsSubset(Set s1, Set s2)\n", 107, 107);
return x_1;
}
}
static lean_object* _init_l_mkSetDiag___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("forall Set x {\n  x.icon = Circle {\n    strokeWidth : 0\n  }\n\n  x.textBox = Rectangle {\n    -- string : x.label\n    -- fontSize : \"25px\"\n    cornerRadius : 5\n    width : 50\n    height : 30\n  }\n\n  ensure contains(x.icon, x.textBox)\n  --encourage sameCenter(x.textBox, x.icon)\n  -- x.textLayering = x.textBox above x.icon\n}\n\nforall Set x; Set y\nwhere IsSubset(x, y) {\n  ensure disjoint(y.textBox, x.icon, 10)\n  ensure contains(y.icon, x.icon, 5)\n  x.icon above y.icon\n}\n\nforall Set x; Set y\nwhere Not(Intersecting(x, y)) {\n  ensure disjoint(x.icon, y.icon)\n}\n\nforall Set x; Set y\nwhere Intersecting(x, y) {\n  ensure overlapping(x.icon, y.icon)\n  ensure disjoint(y.textBox, x.icon)\n  ensure disjoint(x.textBox, y.icon)\n}\n", 716, 716);
return x_1;
}
}
LEAN_EXPORT lean_object* l_mkSetDiag(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_array_size(x_2);
x_9 = 0;
x_10 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0(x_8, x_9, x_2, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = l_ProofWidgets_Penrose_Diagram;
x_14 = l_mkSetDiag___closed__0;
x_15 = l_mkSetDiag___closed__1;
x_16 = lean_unsigned_to_nat(500u);
x_17 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_17, 0, x_12);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_1);
lean_ctor_set(x_17, 4, x_16);
x_18 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1;
x_19 = l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_buildDiagram_spec__1(x_13, x_17, x_18);
lean_ctor_set(x_10, 0, x_19);
return x_10;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_20 = lean_ctor_get(x_10, 0);
x_21 = lean_ctor_get(x_10, 1);
lean_inc(x_21);
lean_inc(x_20);
lean_dec(x_10);
x_22 = l_ProofWidgets_Penrose_Diagram;
x_23 = l_mkSetDiag___closed__0;
x_24 = l_mkSetDiag___closed__1;
x_25 = lean_unsigned_to_nat(500u);
x_26 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_26, 0, x_20);
lean_ctor_set(x_26, 1, x_23);
lean_ctor_set(x_26, 2, x_24);
lean_ctor_set(x_26, 3, x_1);
lean_ctor_set(x_26, 4, x_25);
x_27 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1;
x_28 = l_ProofWidgets_Html_ofComponent___at___ProofWidgets_Penrose_DiagramBuilderM_buildDiagram_spec__1(x_22, x_26, x_27);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_21);
return x_29;
}
}
else
{
uint8_t x_30; 
lean_dec_ref(x_1);
x_30 = !lean_is_exclusive(x_10);
if (x_30 == 0)
{
return x_10;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_31 = lean_ctor_get(x_10, 0);
x_32 = lean_ctor_get(x_10, 1);
lean_inc(x_32);
lean_inc(x_31);
lean_dec(x_10);
x_33 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_33, 0, x_31);
lean_ctor_set(x_33, 1, x_32);
return x_33;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
size_t x_9; size_t x_10; lean_object* x_11; 
x_9 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_10 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_11 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0(x_9, x_10, x_3, x_4, x_5, x_6, x_7, x_8);
return x_11;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("IsSubset(", 9, 9);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", ", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")\n", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Set ", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_44; 
x_44 = lean_usize_dec_lt(x_3, x_2);
if (x_44 == 0)
{
lean_object* x_45; 
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_4);
lean_ctor_set(x_45, 1, x_9);
return x_45;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_106; lean_object* x_161; lean_object* x_162; 
x_46 = lean_ctor_get(x_4, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_4, 1);
lean_inc(x_47);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_48 = x_4;
} else {
 lean_dec_ref(x_4);
 x_48 = lean_box(0);
}
x_161 = lean_array_uget(x_1, x_3);
x_162 = lean_ctor_get(x_161, 3);
lean_inc_ref(x_162);
lean_dec_ref(x_161);
x_106 = x_162;
goto block_160;
block_61:
{
uint8_t x_55; 
x_55 = lean_unbox(x_51);
lean_dec(x_51);
if (x_55 == 0)
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_56 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3;
x_57 = lean_string_append(x_56, x_49);
x_58 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4;
x_59 = lean_string_append(x_57, x_58);
x_60 = lean_string_append(x_47, x_59);
lean_dec_ref(x_59);
x_31 = x_54;
x_32 = x_49;
x_33 = x_53;
x_34 = x_52;
x_35 = x_60;
x_36 = x_50;
goto block_43;
}
else
{
x_31 = x_54;
x_32 = x_49;
x_33 = x_53;
x_34 = x_52;
x_35 = x_47;
x_36 = x_50;
goto block_43;
}
}
block_105:
{
lean_object* x_69; uint64_t x_70; uint64_t x_71; uint64_t x_72; uint64_t x_73; uint64_t x_74; uint64_t x_75; uint64_t x_76; size_t x_77; size_t x_78; size_t x_79; size_t x_80; size_t x_81; lean_object* x_82; uint8_t x_83; 
x_69 = lean_array_get_size(x_68);
x_70 = lean_string_hash(x_65);
x_71 = 32;
x_72 = lean_uint64_shift_right(x_70, x_71);
x_73 = lean_uint64_xor(x_70, x_72);
x_74 = 16;
x_75 = lean_uint64_shift_right(x_73, x_74);
x_76 = lean_uint64_xor(x_73, x_75);
x_77 = lean_uint64_to_usize(x_76);
x_78 = lean_usize_of_nat(x_69);
lean_dec(x_69);
x_79 = 1;
x_80 = lean_usize_sub(x_78, x_79);
x_81 = lean_usize_land(x_77, x_80);
x_82 = lean_array_uget(x_68, x_81);
x_83 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_contains___at___Lean_Meta_Rewrites_takeListAux_spec__0_spec__0___redArg(x_65, x_82);
if (x_83 == 0)
{
lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; uint8_t x_93; 
x_84 = lean_unsigned_to_nat(1u);
x_85 = lean_nat_add(x_67, x_84);
lean_dec(x_67);
lean_inc_ref(x_65);
x_86 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_86, 0, x_65);
lean_ctor_set(x_86, 1, x_64);
lean_ctor_set(x_86, 2, x_82);
x_87 = lean_array_uset(x_68, x_81, x_86);
x_88 = lean_unsigned_to_nat(4u);
x_89 = lean_nat_mul(x_85, x_88);
x_90 = lean_unsigned_to_nat(3u);
x_91 = lean_nat_div(x_89, x_90);
lean_dec(x_89);
x_92 = lean_array_get_size(x_87);
x_93 = lean_nat_dec_le(x_91, x_92);
lean_dec(x_92);
lean_dec(x_91);
if (x_93 == 0)
{
lean_object* x_94; lean_object* x_95; lean_object* x_96; 
x_94 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__2___redArg(x_87);
x_95 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_95, 0, x_85);
lean_ctor_set(x_95, 1, x_94);
x_96 = lean_box(x_83);
x_49 = x_62;
x_50 = x_63;
x_51 = x_66;
x_52 = x_65;
x_53 = x_96;
x_54 = x_95;
goto block_61;
}
else
{
lean_object* x_97; lean_object* x_98; 
x_97 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_97, 0, x_85);
lean_ctor_set(x_97, 1, x_87);
x_98 = lean_box(x_83);
x_49 = x_62;
x_50 = x_63;
x_51 = x_66;
x_52 = x_65;
x_53 = x_98;
x_54 = x_97;
goto block_61;
}
}
else
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; 
x_99 = lean_box(0);
x_100 = lean_array_uset(x_68, x_81, x_99);
lean_inc_ref(x_65);
x_101 = l_Std_DHashMap_Internal_AssocList_replace___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__5___redArg(x_65, x_64, x_82);
x_102 = lean_array_uset(x_100, x_81, x_101);
x_103 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_103, 0, x_67);
lean_ctor_set(x_103, 1, x_102);
x_104 = lean_box(x_83);
x_49 = x_62;
x_50 = x_63;
x_51 = x_66;
x_52 = x_65;
x_53 = x_104;
x_54 = x_103;
goto block_61;
}
}
block_160:
{
lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; 
x_107 = l_Lean_instantiateMVars___at___Lean_Tactic_FunInd_rwMatcher_spec__6___redArg(x_106, x_6, x_9);
x_108 = lean_ctor_get(x_107, 0);
lean_inc(x_108);
x_109 = lean_ctor_get(x_107, 1);
lean_inc(x_109);
lean_dec_ref(x_107);
x_110 = l_isSubsetPred_x3f(x_108);
lean_dec(x_108);
if (lean_obj_tag(x_110) == 0)
{
lean_object* x_111; 
if (lean_is_scalar(x_48)) {
 x_111 = lean_alloc_ctor(0, 2, 0);
} else {
 x_111 = x_48;
}
lean_ctor_set(x_111, 0, x_46);
lean_ctor_set(x_111, 1, x_47);
x_10 = x_111;
x_11 = x_109;
goto block_15;
}
else
{
lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; uint64_t x_128; uint64_t x_129; uint64_t x_130; uint64_t x_131; uint64_t x_132; uint64_t x_133; uint64_t x_134; size_t x_135; size_t x_136; size_t x_137; size_t x_138; size_t x_139; lean_object* x_140; uint8_t x_141; 
lean_dec(x_48);
x_112 = lean_ctor_get(x_110, 0);
lean_inc(x_112);
lean_dec_ref(x_110);
x_113 = lean_ctor_get(x_112, 0);
lean_inc(x_113);
x_114 = lean_ctor_get(x_112, 1);
lean_inc(x_114);
lean_dec(x_112);
lean_inc(x_113);
x_115 = l_Lean_Meta_ppExpr(x_113, x_5, x_6, x_7, x_8, x_109);
x_116 = lean_ctor_get(x_115, 0);
lean_inc(x_116);
x_117 = lean_ctor_get(x_115, 1);
lean_inc(x_117);
lean_dec_ref(x_115);
lean_inc(x_114);
x_118 = l_Lean_Meta_ppExpr(x_114, x_5, x_6, x_7, x_8, x_117);
x_119 = lean_ctor_get(x_118, 0);
lean_inc(x_119);
x_120 = lean_ctor_get(x_118, 1);
lean_inc(x_120);
lean_dec_ref(x_118);
x_121 = lean_ctor_get(x_46, 0);
lean_inc(x_121);
x_122 = lean_ctor_get(x_46, 1);
lean_inc_ref(x_122);
lean_dec(x_46);
x_123 = lean_unsigned_to_nat(120u);
x_124 = lean_unsigned_to_nat(0u);
x_125 = lean_format_pretty(x_116, x_123, x_124, x_124);
x_126 = lean_format_pretty(x_119, x_123, x_124, x_124);
x_127 = lean_array_get_size(x_122);
x_128 = lean_string_hash(x_125);
x_129 = 32;
x_130 = lean_uint64_shift_right(x_128, x_129);
x_131 = lean_uint64_xor(x_128, x_130);
x_132 = 16;
x_133 = lean_uint64_shift_right(x_131, x_132);
x_134 = lean_uint64_xor(x_131, x_133);
x_135 = lean_uint64_to_usize(x_134);
x_136 = lean_usize_of_nat(x_127);
lean_dec(x_127);
x_137 = 1;
x_138 = lean_usize_sub(x_136, x_137);
x_139 = lean_usize_land(x_135, x_138);
x_140 = lean_array_uget(x_122, x_139);
x_141 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_contains___at___Lean_Meta_Rewrites_takeListAux_spec__0_spec__0___redArg(x_125, x_140);
if (x_141 == 0)
{
lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; uint8_t x_151; 
x_142 = lean_unsigned_to_nat(1u);
x_143 = lean_nat_add(x_121, x_142);
lean_dec(x_121);
lean_inc_ref(x_125);
x_144 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_144, 0, x_125);
lean_ctor_set(x_144, 1, x_113);
lean_ctor_set(x_144, 2, x_140);
x_145 = lean_array_uset(x_122, x_139, x_144);
x_146 = lean_unsigned_to_nat(4u);
x_147 = lean_nat_mul(x_143, x_146);
x_148 = lean_unsigned_to_nat(3u);
x_149 = lean_nat_div(x_147, x_148);
lean_dec(x_147);
x_150 = lean_array_get_size(x_145);
x_151 = lean_nat_dec_le(x_149, x_150);
lean_dec(x_150);
lean_dec(x_149);
if (x_151 == 0)
{
lean_object* x_152; lean_object* x_153; 
x_152 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__2___redArg(x_145);
x_153 = lean_box(x_141);
x_62 = x_125;
x_63 = x_120;
x_64 = x_114;
x_65 = x_126;
x_66 = x_153;
x_67 = x_143;
x_68 = x_152;
goto block_105;
}
else
{
lean_object* x_154; 
x_154 = lean_box(x_141);
x_62 = x_125;
x_63 = x_120;
x_64 = x_114;
x_65 = x_126;
x_66 = x_154;
x_67 = x_143;
x_68 = x_145;
goto block_105;
}
}
else
{
lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; 
x_155 = lean_box(0);
x_156 = lean_array_uset(x_122, x_139, x_155);
lean_inc_ref(x_125);
x_157 = l_Std_DHashMap_Internal_AssocList_replace___at___Std_DHashMap_Internal_Raw_u2080_insert___at___Lean_Meta_Rewrites_takeListAux_spec__2_spec__5___redArg(x_125, x_113, x_140);
x_158 = lean_array_uset(x_156, x_139, x_157);
x_159 = lean_box(x_141);
x_62 = x_125;
x_63 = x_120;
x_64 = x_114;
x_65 = x_126;
x_66 = x_159;
x_67 = x_121;
x_68 = x_158;
goto block_105;
}
}
}
}
block_15:
{
size_t x_12; size_t x_13; 
x_12 = 1;
x_13 = lean_usize_add(x_3, x_12);
x_3 = x_13;
x_4 = x_10;
x_9 = x_11;
goto _start;
}
block_30:
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_21 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0;
x_22 = lean_string_append(x_21, x_17);
lean_dec_ref(x_17);
x_23 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1;
x_24 = lean_string_append(x_22, x_23);
x_25 = lean_string_append(x_24, x_18);
lean_dec_ref(x_18);
x_26 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2;
x_27 = lean_string_append(x_25, x_26);
x_28 = lean_string_append(x_19, x_27);
lean_dec_ref(x_27);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_16);
lean_ctor_set(x_29, 1, x_28);
x_10 = x_29;
x_11 = x_20;
goto block_15;
}
block_43:
{
uint8_t x_37; 
x_37 = lean_unbox(x_33);
lean_dec(x_33);
if (x_37 == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_38 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3;
x_39 = lean_string_append(x_38, x_34);
x_40 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4;
x_41 = lean_string_append(x_39, x_40);
x_42 = lean_string_append(x_35, x_41);
lean_dec_ref(x_41);
x_16 = x_31;
x_17 = x_32;
x_18 = x_34;
x_19 = x_42;
x_20 = x_36;
goto block_30;
}
else
{
x_16 = x_31;
x_17 = x_32;
x_18 = x_34;
x_19 = x_35;
x_20 = x_36;
goto block_30;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_1;
}
else
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = lean_ctor_get(x_2, 0);
x_4 = lean_ctor_get(x_2, 1);
x_5 = lean_ctor_get(x_2, 2);
lean_inc(x_4);
lean_inc(x_3);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_4);
x_7 = lean_array_push(x_1, x_6);
x_1 = x_7;
x_2 = x_5;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_eq(x_2, x_3);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; 
x_6 = lean_array_uget(x_1, x_2);
x_7 = l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1(x_4, x_6);
lean_dec(x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_2 = x_9;
x_4 = x_7;
goto _start;
}
else
{
return x_4;
}
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("AutoLabel All\n", 14, 14);
return x_1;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_unsigned_to_nat(8u);
x_3 = lean_nat_mul(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = l_isSetGoal_x3f___closed__1;
x_3 = lean_nat_div(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_isSetGoal_x3f___closed__2;
x_2 = l_Nat_nextPowerOfTwo(x_1);
return x_2;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_isSetGoal_x3f___closed__3;
x_3 = lean_mk_array(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isSetGoal_x3f___closed__4;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_isSetGoal_x3f___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isSetGoal_x3f___closed__0;
x_2 = l_isSetGoal_x3f___closed__5;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isSetGoal_x3f(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; size_t x_9; size_t x_10; lean_object* x_11; uint8_t x_12; 
x_7 = lean_unsigned_to_nat(0u);
x_8 = l_isSetGoal_x3f___closed__6;
x_9 = lean_array_size(x_1);
x_10 = 0;
x_11 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg(x_1, x_9, x_10, x_8, x_2, x_3, x_4, x_5, x_6);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_31; lean_object* x_32; uint8_t x_33; 
x_13 = lean_ctor_get(x_11, 0);
x_14 = lean_ctor_get(x_11, 1);
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_31 = lean_ctor_get(x_15, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_15, 1);
lean_inc_ref(x_32);
lean_dec(x_15);
x_33 = lean_nat_dec_eq(x_31, x_7);
if (x_33 == 0)
{
lean_object* x_34; lean_object* x_35; uint8_t x_36; 
lean_free_object(x_11);
x_34 = lean_mk_empty_array_with_capacity(x_31);
lean_dec(x_31);
x_35 = lean_array_get_size(x_32);
x_36 = lean_nat_dec_lt(x_7, x_35);
if (x_36 == 0)
{
lean_dec(x_35);
lean_dec_ref(x_32);
x_17 = x_34;
goto block_30;
}
else
{
uint8_t x_37; 
x_37 = lean_nat_dec_le(x_35, x_35);
if (x_37 == 0)
{
lean_dec(x_35);
lean_dec_ref(x_32);
x_17 = x_34;
goto block_30;
}
else
{
size_t x_38; lean_object* x_39; 
x_38 = lean_usize_of_nat(x_35);
lean_dec(x_35);
x_39 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2(x_32, x_10, x_38, x_34);
lean_dec_ref(x_32);
x_17 = x_39;
goto block_30;
}
}
}
else
{
lean_object* x_40; 
lean_dec_ref(x_32);
lean_dec(x_31);
lean_dec(x_16);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_40 = lean_box(0);
lean_ctor_set(x_11, 0, x_40);
return x_11;
}
block_30:
{
lean_object* x_18; 
x_18 = l_mkSetDiag(x_16, x_17, x_2, x_3, x_4, x_5, x_14);
if (lean_obj_tag(x_18) == 0)
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; 
x_20 = lean_ctor_get(x_18, 0);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_18, 0, x_21);
return x_18;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_22 = lean_ctor_get(x_18, 0);
x_23 = lean_ctor_get(x_18, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_18);
x_24 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_24, 0, x_22);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_23);
return x_25;
}
}
else
{
uint8_t x_26; 
x_26 = !lean_is_exclusive(x_18);
if (x_26 == 0)
{
return x_18;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_27 = lean_ctor_get(x_18, 0);
x_28 = lean_ctor_get(x_18, 1);
lean_inc(x_28);
lean_inc(x_27);
lean_dec(x_18);
x_29 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_29, 0, x_27);
lean_ctor_set(x_29, 1, x_28);
return x_29;
}
}
}
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_57; lean_object* x_58; uint8_t x_59; 
x_41 = lean_ctor_get(x_11, 0);
x_42 = lean_ctor_get(x_11, 1);
lean_inc(x_42);
lean_inc(x_41);
lean_dec(x_11);
x_43 = lean_ctor_get(x_41, 0);
lean_inc(x_43);
x_44 = lean_ctor_get(x_41, 1);
lean_inc(x_44);
lean_dec(x_41);
x_57 = lean_ctor_get(x_43, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_43, 1);
lean_inc_ref(x_58);
lean_dec(x_43);
x_59 = lean_nat_dec_eq(x_57, x_7);
if (x_59 == 0)
{
lean_object* x_60; lean_object* x_61; uint8_t x_62; 
x_60 = lean_mk_empty_array_with_capacity(x_57);
lean_dec(x_57);
x_61 = lean_array_get_size(x_58);
x_62 = lean_nat_dec_lt(x_7, x_61);
if (x_62 == 0)
{
lean_dec(x_61);
lean_dec_ref(x_58);
x_45 = x_60;
goto block_56;
}
else
{
uint8_t x_63; 
x_63 = lean_nat_dec_le(x_61, x_61);
if (x_63 == 0)
{
lean_dec(x_61);
lean_dec_ref(x_58);
x_45 = x_60;
goto block_56;
}
else
{
size_t x_64; lean_object* x_65; 
x_64 = lean_usize_of_nat(x_61);
lean_dec(x_61);
x_65 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2(x_58, x_10, x_64, x_60);
lean_dec_ref(x_58);
x_45 = x_65;
goto block_56;
}
}
}
else
{
lean_object* x_66; lean_object* x_67; 
lean_dec_ref(x_58);
lean_dec(x_57);
lean_dec(x_44);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_66 = lean_box(0);
x_67 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_67, 0, x_66);
lean_ctor_set(x_67, 1, x_42);
return x_67;
}
block_56:
{
lean_object* x_46; 
x_46 = l_mkSetDiag(x_44, x_45, x_2, x_3, x_4, x_5, x_42);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
x_48 = lean_ctor_get(x_46, 1);
lean_inc(x_48);
if (lean_is_exclusive(x_46)) {
 lean_ctor_release(x_46, 0);
 lean_ctor_release(x_46, 1);
 x_49 = x_46;
} else {
 lean_dec_ref(x_46);
 x_49 = lean_box(0);
}
x_50 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_50, 0, x_47);
if (lean_is_scalar(x_49)) {
 x_51 = lean_alloc_ctor(0, 2, 0);
} else {
 x_51 = x_49;
}
lean_ctor_set(x_51, 0, x_50);
lean_ctor_set(x_51, 1, x_48);
return x_51;
}
else
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_52 = lean_ctor_get(x_46, 0);
lean_inc(x_52);
x_53 = lean_ctor_get(x_46, 1);
lean_inc(x_53);
if (lean_is_exclusive(x_46)) {
 lean_ctor_release(x_46, 0);
 lean_ctor_release(x_46, 1);
 x_54 = x_46;
} else {
 lean_dec_ref(x_46);
 x_54 = lean_box(0);
}
if (lean_is_scalar(x_54)) {
 x_55 = lean_alloc_ctor(1, 2, 0);
} else {
 x_55 = x_54;
}
lean_ctor_set(x_55, 0, x_52);
lean_ctor_set(x_55, 1, x_53);
return x_55;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
size_t x_10; size_t x_11; lean_object* x_12; 
x_10 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_11 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_12 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg(x_1, x_10, x_11, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec_ref(x_1);
return x_12;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
size_t x_12; size_t x_13; lean_object* x_14; 
x_12 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_13 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_14 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0(x_1, x_2, x_3, x_12, x_13, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
return x_14;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_AssocList_foldlM___at___isSetGoal_x3f_spec__1(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___isSetGoal_x3f_spec__2(x_1, x_5, x_6, x_4);
lean_dec_ref(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_isSetGoal_x3f___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_isSetGoal_x3f(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec_ref(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; 
x_8 = lean_usize_dec_lt(x_6, x_5);
if (x_8 == 0)
{
lean_dec_ref(x_1);
lean_inc_ref(x_7);
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_uget(x_4, x_6);
x_10 = lean_ctor_get(x_9, 3);
lean_inc(x_10);
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_name_eq(x_10, x_11);
lean_dec(x_10);
if (x_12 == 0)
{
size_t x_13; size_t x_14; 
lean_dec_ref(x_9);
x_13 = 1;
x_14 = lean_usize_add(x_6, x_13);
{
size_t _tmp_5 = x_14;
lean_object* _tmp_6 = x_2;
x_6 = _tmp_5;
x_7 = _tmp_6;
}
goto _start;
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_1);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_17 = lean_ctor_get(x_1, 1);
lean_dec(x_17);
x_18 = lean_ctor_get(x_1, 0);
lean_dec(x_18);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_9);
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_1, 1, x_3);
lean_ctor_set(x_1, 0, x_20);
return x_1;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
lean_dec(x_1);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_9);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_3);
return x_23;
}
}
}
}
}
static lean_object* _init_l_findGoalForLocation___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; size_t x_6; size_t x_7; lean_object* x_8; lean_object* x_9; 
x_3 = lean_box(0);
x_4 = lean_box(0);
x_5 = l_findGoalForLocation___closed__0;
x_6 = lean_array_size(x_1);
x_7 = 0;
x_8 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_2, x_5, x_4, x_1, x_6, x_7, x_5);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
lean_dec_ref(x_8);
if (lean_obj_tag(x_9) == 0)
{
return x_3;
}
else
{
lean_object* x_10; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec_ref(x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_9 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_10 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_1, x_2, x_3, x_4, x_8, x_9, x_7);
lean_dec_ref(x_7);
lean_dec_ref(x_4);
lean_dec_ref(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_findGoalForLocation(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
static lean_object* _init_l_panic___at___VennDisplay_rpc_spec__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_Server_instInhabitedRequestError_default;
x_2 = lean_alloc_closure((void*)(l_EStateM_instInhabited___redArg___lam__0), 2, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_panic___at___VennDisplay_rpc_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = l_panic___at___VennDisplay_rpc_spec__0___closed__0;
x_5 = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = lean_panic_fn(x_5, x_1);
x_7 = lean_apply_2(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_16; lean_object* x_17; uint8_t x_20; 
x_20 = lean_usize_dec_eq(x_3, x_4);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_array_uget(x_2, x_3);
x_22 = lean_ctor_get(x_21, 1);
lean_inc_ref(x_22);
switch (lean_obj_tag(x_22)) {
case 0:
{
lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_23 = lean_ctor_get(x_21, 0);
lean_inc(x_23);
lean_dec_ref(x_21);
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec_ref(x_22);
x_25 = lean_name_eq(x_23, x_1);
lean_dec(x_23);
if (x_25 == 0)
{
lean_dec(x_24);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
else
{
lean_object* x_26; 
lean_inc_ref(x_6);
x_26 = l_Lean_FVarId_getDecl___redArg(x_24, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; 
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_26, 1);
lean_inc(x_28);
lean_dec_ref(x_26);
x_16 = x_27;
x_17 = x_28;
goto block_19;
}
else
{
uint8_t x_29; 
lean_dec_ref(x_6);
lean_dec_ref(x_5);
x_29 = !lean_is_exclusive(x_26);
if (x_29 == 0)
{
return x_26;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_26, 0);
x_31 = lean_ctor_get(x_26, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_26);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
}
case 1:
{
lean_object* x_33; lean_object* x_34; uint8_t x_35; 
x_33 = lean_ctor_get(x_21, 0);
lean_inc(x_33);
lean_dec_ref(x_21);
x_34 = lean_ctor_get(x_22, 0);
lean_inc(x_34);
lean_dec_ref(x_22);
x_35 = lean_name_eq(x_33, x_1);
lean_dec(x_33);
if (x_35 == 0)
{
lean_dec(x_34);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
else
{
lean_object* x_36; 
lean_inc_ref(x_6);
x_36 = l_Lean_FVarId_getDecl___redArg(x_34, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec_ref(x_36);
x_16 = x_37;
x_17 = x_38;
goto block_19;
}
else
{
uint8_t x_39; 
lean_dec_ref(x_6);
lean_dec_ref(x_5);
x_39 = !lean_is_exclusive(x_36);
if (x_39 == 0)
{
return x_36;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_36, 0);
x_41 = lean_ctor_get(x_36, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_36);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
default: 
{
lean_dec_ref(x_22);
lean_dec_ref(x_21);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
}
}
else
{
lean_object* x_43; 
lean_dec_ref(x_6);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_5);
lean_ctor_set(x_43, 1, x_9);
return x_43;
}
block_15:
{
size_t x_12; size_t x_13; 
x_12 = 1;
x_13 = lean_usize_add(x_3, x_12);
x_3 = x_13;
x_5 = x_10;
x_9 = x_11;
goto _start;
}
block_19:
{
lean_object* x_18; 
x_18 = lean_array_push(x_5, x_16);
x_10 = x_18;
x_11 = x_17;
goto block_15;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_8, x_9, x_10);
return x_11;
}
}
static lean_object* _init_l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___VennDisplay_rpc_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; uint8_t x_11; 
x_10 = l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0;
x_11 = lean_nat_dec_lt(x_3, x_4);
if (x_11 == 0)
{
lean_object* x_12; 
lean_dec_ref(x_5);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_9);
return x_12;
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_array_get_size(x_2);
x_14 = lean_nat_dec_le(x_4, x_13);
lean_dec(x_13);
if (x_14 == 0)
{
lean_object* x_15; 
lean_dec_ref(x_5);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_10);
lean_ctor_set(x_15, 1, x_9);
return x_15;
}
else
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = lean_usize_of_nat(x_3);
x_17 = lean_usize_of_nat(x_4);
x_18 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg(x_1, x_2, x_16, x_17, x_10, x_5, x_7, x_8, x_9);
return x_18;
}
}
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("No set goal.", 12, 12);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__0___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__0___closed__1;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__0___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__0___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__0___closed__2;
x_2 = l_VennDisplay_rpc___lam__0___closed__3;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
lean_inc_ref(x_5);
x_10 = l_Array_filterMapM___at___VennDisplay_rpc_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec_ref(x_10);
x_13 = l_isSetGoal_x3f(x_11, x_5, x_6, x_7, x_8, x_12);
lean_dec(x_11);
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
if (lean_obj_tag(x_14) == 0)
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_13);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_16 = lean_ctor_get(x_13, 0);
lean_dec(x_16);
x_17 = l_VennDisplay_rpc___lam__0___closed__0;
x_18 = lean_mk_empty_array_with_capacity(x_3);
x_19 = l_VennDisplay_rpc___lam__0___closed__4;
x_20 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_20, 0, x_17);
lean_ctor_set(x_20, 1, x_18);
lean_ctor_set(x_20, 2, x_19);
lean_ctor_set(x_13, 0, x_20);
return x_13;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_21 = lean_ctor_get(x_13, 1);
lean_inc(x_21);
lean_dec(x_13);
x_22 = l_VennDisplay_rpc___lam__0___closed__0;
x_23 = lean_mk_empty_array_with_capacity(x_3);
x_24 = l_VennDisplay_rpc___lam__0___closed__4;
x_25 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_25, 0, x_22);
lean_ctor_set(x_25, 1, x_23);
lean_ctor_set(x_25, 2, x_24);
x_26 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_21);
return x_26;
}
}
else
{
uint8_t x_27; 
x_27 = !lean_is_exclusive(x_13);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; 
x_28 = lean_ctor_get(x_13, 0);
lean_dec(x_28);
x_29 = lean_ctor_get(x_14, 0);
lean_inc(x_29);
lean_dec_ref(x_14);
lean_ctor_set(x_13, 0, x_29);
return x_13;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_13, 1);
lean_inc(x_30);
lean_dec(x_13);
x_31 = lean_ctor_get(x_14, 0);
lean_inc(x_31);
lean_dec_ref(x_14);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_30);
return x_32;
}
}
}
else
{
uint8_t x_33; 
x_33 = !lean_is_exclusive(x_13);
if (x_33 == 0)
{
return x_13;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_34 = lean_ctor_get(x_13, 0);
x_35 = lean_ctor_get(x_13, 1);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_13);
x_36 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_36, 0, x_34);
lean_ctor_set(x_36, 1, x_35);
return x_36;
}
}
}
else
{
uint8_t x_37; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
x_37 = !lean_is_exclusive(x_10);
if (x_37 == 0)
{
return x_10;
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_38 = lean_ctor_get(x_10, 0);
x_39 = lean_ctor_get(x_10, 1);
lean_inc(x_39);
lean_inc(x_38);
lean_dec(x_10);
x_40 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
return x_40;
}
}
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_MVarId_getDecl(x_1, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec_ref(x_8);
x_11 = lean_ctor_get(x_5, 2);
x_12 = lean_ctor_get(x_9, 1);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_9, 4);
lean_inc_ref(x_13);
lean_dec(x_9);
x_14 = lean_box(1);
lean_inc(x_11);
x_15 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_15, 0, x_11);
lean_ctor_set(x_15, 1, x_14);
lean_ctor_set(x_15, 2, x_14);
x_16 = l_Lean_LocalContext_sanitizeNames(x_12, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
lean_dec_ref(x_16);
x_18 = l_Lean_Meta_withLCtx___at___Lean_Meta_withErasedFVars___at_____private_Lean_Meta_Tactic_FunInd_0__Lean_Tactic_FunInd_deriveInductionStructural_doRealize_spec__36_spec__36___redArg(x_17, x_13, x_2, x_3, x_4, x_5, x_6, x_10);
return x_18;
}
else
{
uint8_t x_19; 
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_19 = !lean_is_exclusive(x_8);
if (x_19 == 0)
{
return x_8;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_8, 0);
x_21 = lean_ctor_get(x_8, 1);
lean_inc(x_21);
lean_inc(x_20);
lean_dec(x_8);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_21);
return x_22;
}
}
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("details", 7, 7);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("open", 4, 4);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("summary", 7, 7);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mv2 pointer", 11, 11);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__5;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__6;
x_2 = l_VennDisplay_rpc___lam__2___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__7;
x_2 = l_VennDisplay_rpc___lam__2___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Venn diagram", 12, 12);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__9;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__10;
x_2 = l_VennDisplay_rpc___lam__2___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_VennDisplay_rpc___lam__2___closed__11;
x_2 = l_VennDisplay_rpc___lam__2___closed__8;
x_3 = l_VennDisplay_rpc___lam__2___closed__3;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ml1", 3, 3);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__14;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__15;
x_2 = l_VennDisplay_rpc___lam__2___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__16;
x_2 = l_VennDisplay_rpc___lam__2___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__12;
x_2 = l_VennDisplay_rpc___lam__2___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets.Demos.Venn", 23, 23);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("VennDisplay.rpc", 15, 15);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unreachable code has been reached", 33, 33);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_VennDisplay_rpc___lam__2___closed__22;
x_2 = lean_unsigned_to_nat(60u);
x_3 = lean_unsigned_to_nat(90u);
x_4 = l_VennDisplay_rpc___lam__2___closed__21;
x_5 = l_VennDisplay_rpc___lam__2___closed__20;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("could not find goal for location ", 33, 33);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__25() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__25;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__27() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__27;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__29() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_VennDisplay_rpc___lam__2___closed__27;
x_4 = l_VennDisplay_rpc___lam__2___closed__28;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(1);
x_2 = l_VennDisplay_rpc___lam__2___closed__29;
x_3 = l_VennDisplay_rpc___lam__2___closed__26;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__31() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__32() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Use shift-click to select hypotheses to include in the diagram.", 63, 63);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_VennDisplay_rpc___lam__2___closed__32;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__34() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___lam__2___closed__33;
x_2 = l_VennDisplay_rpc___lam__0___closed__3;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___lam__2___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_VennDisplay_rpc___lam__2___closed__34;
x_2 = l_VennDisplay_rpc___lam__2___closed__31;
x_3 = l_VennDisplay_rpc___lam__0___closed__0;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__2(uint8_t x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; 
if (x_2 == 0)
{
lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_24 = lean_unsigned_to_nat(0u);
x_25 = lean_array_get_size(x_3);
x_26 = lean_nat_dec_lt(x_24, x_25);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; 
lean_dec(x_25);
lean_dec_ref(x_3);
x_27 = l_VennDisplay_rpc___lam__2___closed__23;
x_28 = l_panic___at___VennDisplay_rpc_spec__0(x_27, x_5, x_6);
if (lean_obj_tag(x_28) == 0)
{
lean_object* x_29; lean_object* x_30; 
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec_ref(x_28);
x_7 = x_29;
x_8 = x_30;
goto block_23;
}
else
{
return x_28;
}
}
else
{
lean_object* x_31; lean_object* x_32; 
lean_dec_ref(x_5);
x_31 = lean_array_fget_borrowed(x_3, x_24);
lean_inc_ref(x_31);
x_32 = l_findGoalForLocation(x_4, x_31);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
lean_inc_ref(x_31);
lean_dec(x_25);
lean_dec_ref(x_3);
x_33 = l_VennDisplay_rpc___lam__2___closed__24;
x_34 = l_Lean_SubExpr_instToJsonGoalsLocation_toJson(x_31);
x_35 = lean_unsigned_to_nat(80u);
x_36 = l_Lean_Json_pretty(x_34, x_35);
x_37 = lean_string_append(x_33, x_36);
lean_dec_ref(x_36);
x_38 = l_Lean_Server_RequestError_invalidParams(x_37);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_6);
return x_39;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_40 = lean_ctor_get(x_32, 0);
lean_inc(x_40);
lean_dec_ref(x_32);
x_41 = lean_ctor_get(x_40, 0);
x_42 = lean_ctor_get(x_41, 2);
lean_inc_ref(x_42);
x_43 = lean_ctor_get(x_40, 3);
lean_inc(x_43);
lean_dec(x_40);
x_44 = lean_ctor_get(x_42, 0);
lean_inc(x_44);
lean_dec_ref(x_42);
lean_inc(x_43);
x_45 = lean_alloc_closure((void*)(l_VennDisplay_rpc___lam__0___boxed), 9, 4);
lean_closure_set(x_45, 0, x_43);
lean_closure_set(x_45, 1, x_3);
lean_closure_set(x_45, 2, x_24);
lean_closure_set(x_45, 3, x_25);
x_46 = lean_alloc_closure((void*)(l_VennDisplay_rpc___lam__1), 7, 2);
lean_closure_set(x_46, 0, x_43);
lean_closure_set(x_46, 1, x_45);
x_47 = l_VennDisplay_rpc___lam__2___closed__30;
x_48 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_44, x_47, x_46, x_6);
if (lean_obj_tag(x_48) == 0)
{
lean_object* x_49; lean_object* x_50; 
x_49 = lean_ctor_get(x_48, 0);
lean_inc(x_49);
x_50 = lean_ctor_get(x_48, 1);
lean_inc(x_50);
lean_dec_ref(x_48);
x_7 = x_49;
x_8 = x_50;
goto block_23;
}
else
{
uint8_t x_51; 
x_51 = !lean_is_exclusive(x_48);
if (x_51 == 0)
{
lean_object* x_52; lean_object* x_53; 
x_52 = lean_ctor_get(x_48, 0);
x_53 = l_Lean_Server_RequestError_ofIoError(x_52);
lean_ctor_set(x_48, 0, x_53);
return x_48;
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_54 = lean_ctor_get(x_48, 0);
x_55 = lean_ctor_get(x_48, 1);
lean_inc(x_55);
lean_inc(x_54);
lean_dec(x_48);
x_56 = l_Lean_Server_RequestError_ofIoError(x_54);
x_57 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_55);
return x_57;
}
}
}
}
}
else
{
lean_object* x_58; 
lean_dec_ref(x_5);
lean_dec_ref(x_3);
x_58 = l_VennDisplay_rpc___lam__2___closed__35;
x_7 = x_58;
x_8 = x_6;
goto block_23;
}
block_23:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_9 = l_VennDisplay_rpc___lam__2___closed__0;
x_10 = l_VennDisplay_rpc___lam__2___closed__1;
x_11 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_11, 0, x_1);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_11);
x_13 = l_VennDisplay_rpc___lam__2___closed__2;
x_14 = lean_array_push(x_13, x_12);
x_15 = l_VennDisplay_rpc___lam__2___closed__13;
x_16 = l_VennDisplay_rpc___lam__2___closed__17;
x_17 = lean_array_push(x_13, x_7);
x_18 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_18, 0, x_15);
lean_ctor_set(x_18, 1, x_16);
lean_ctor_set(x_18, 2, x_17);
x_19 = l_VennDisplay_rpc___lam__2___closed__19;
x_20 = lean_array_push(x_19, x_18);
x_21 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_21, 0, x_9);
lean_ctor_set(x_21, 1, x_14);
lean_ctor_set(x_21, 2, x_20);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_8);
return x_22;
}
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; uint8_t x_6; uint8_t x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_4 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_4);
x_5 = lean_ctor_get(x_1, 3);
lean_inc_ref(x_5);
lean_dec_ref(x_1);
x_6 = l_Array_isEmpty___redArg(x_5);
x_7 = 1;
x_8 = lean_box(x_7);
x_9 = lean_box(x_6);
x_10 = lean_alloc_closure((void*)(l_VennDisplay_rpc___lam__2___boxed), 6, 4);
lean_closure_set(x_10, 0, x_8);
lean_closure_set(x_10, 1, x_9);
lean_closure_set(x_10, 2, x_5);
lean_closure_set(x_10, 3, x_4);
x_11 = l_Lean_Server_RequestM_asTask___redArg(x_10, x_2, x_3);
return x_11;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
size_t x_10; size_t x_11; lean_object* x_12; 
x_10 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_11 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_12 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___redArg(x_1, x_2, x_10, x_11, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_12;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
size_t x_11; size_t x_12; lean_object* x_13; 
x_11 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_12 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_13 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___Array_filterMapM___at___VennDisplay_rpc_spec__1_spec__1(x_1, x_2, x_11, x_12, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec(x_7);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_13;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___VennDisplay_rpc_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Array_filterMapM___at___VennDisplay_rpc_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_VennDisplay_rpc___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_VennDisplay_rpc___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; uint8_t x_8; lean_object* x_9; 
x_7 = lean_unbox(x_1);
x_8 = lean_unbox(x_2);
x_9 = l_VennDisplay_rpc___lam__2(x_7, x_8, x_3, x_4, x_5, x_6);
lean_dec_ref(x_4);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec_ref(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = 9;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
x_17 = lean_ctor_get(x_15, 0);
lean_inc_ref(x_17);
lean_dec(x_15);
lean_inc(x_5);
x_18 = l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1_(x_5, x_17);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; uint8_t x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec_ref(x_18);
x_20 = 3;
x_21 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
x_22 = 1;
x_23 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_22);
x_24 = lean_string_append(x_21, x_23);
lean_dec_ref(x_23);
x_25 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
x_26 = lean_string_append(x_24, x_25);
x_27 = l_Lean_Json_compress(x_5);
x_28 = lean_string_append(x_26, x_27);
lean_dec_ref(x_27);
x_29 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
x_30 = lean_string_append(x_28, x_29);
x_31 = lean_string_append(x_30, x_19);
lean_dec(x_19);
x_32 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set_uint8(x_32, sizeof(void*)*1, x_20);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_32);
return x_13;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_33 = lean_ctor_get(x_18, 0);
lean_inc(x_33);
lean_dec_ref(x_18);
lean_inc_ref(x_6);
x_34 = lean_apply_3(x_2, x_33, x_6, x_16);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec_ref(x_34);
x_37 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_37, 0, x_12);
lean_closure_set(x_37, 1, x_3);
x_38 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_35, x_37, x_6, x_36);
return x_38;
}
else
{
uint8_t x_39; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_39 = !lean_is_exclusive(x_34);
if (x_39 == 0)
{
return x_34;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_34, 0);
x_41 = lean_ctor_get(x_34, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_34);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_43 = lean_ctor_get(x_13, 0);
x_44 = lean_ctor_get(x_13, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_13);
x_45 = lean_ctor_get(x_43, 0);
lean_inc_ref(x_45);
lean_dec(x_43);
lean_inc(x_5);
x_46 = l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1_(x_5, x_45);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; uint8_t x_48; lean_object* x_49; uint8_t x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec_ref(x_46);
x_48 = 3;
x_49 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
x_50 = 1;
x_51 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_50);
x_52 = lean_string_append(x_49, x_51);
lean_dec_ref(x_51);
x_53 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
x_54 = lean_string_append(x_52, x_53);
x_55 = l_Lean_Json_compress(x_5);
x_56 = lean_string_append(x_54, x_55);
lean_dec_ref(x_55);
x_57 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
x_58 = lean_string_append(x_56, x_57);
x_59 = lean_string_append(x_58, x_47);
lean_dec(x_47);
x_60 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set_uint8(x_60, sizeof(void*)*1, x_48);
x_61 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_44);
return x_61;
}
else
{
lean_object* x_62; lean_object* x_63; 
lean_dec(x_5);
lean_dec(x_1);
x_62 = lean_ctor_get(x_46, 0);
lean_inc(x_62);
lean_dec_ref(x_46);
lean_inc_ref(x_6);
x_63 = lean_apply_3(x_2, x_62, x_6, x_44);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_63, 1);
lean_inc(x_65);
lean_dec_ref(x_63);
x_66 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_66, 0, x_12);
lean_closure_set(x_66, 1, x_3);
x_67 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_64, x_66, x_6, x_65);
return x_67;
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_68 = lean_ctor_get(x_63, 0);
lean_inc(x_68);
x_69 = lean_ctor_get(x_63, 1);
lean_inc(x_69);
if (lean_is_exclusive(x_63)) {
 lean_ctor_release(x_63, 0);
 lean_ctor_release(x_63, 1);
 x_70 = x_63;
} else {
 lean_dec_ref(x_63);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(1, 2, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_68);
lean_ctor_set(x_71, 1, x_69);
return x_71;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_VennDisplay_rpc___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("VennDisplay", 11, 11);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rpc", 3, 3);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___rpc__wrapped___closed__1;
x_2 = l_VennDisplay_rpc___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay_rpc___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_VennDisplay_rpc), 3, 0);
return x_1;
}
}
static lean_object* _init_l_VennDisplay_rpc___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay_rpc___rpc__wrapped___closed__2;
x_2 = l_VennDisplay_rpc___rpc__wrapped___closed__3;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l_VennDisplay___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"VennDisplay.rpc\",f='false';var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1875, 1875);
return x_1;
}
}
static uint64_t _init_l_VennDisplay___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_VennDisplay___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_VennDisplay___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay___closed__1;
x_2 = l_VennDisplay___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_VennDisplay___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_VennDisplay___closed__3;
x_2 = l_VennDisplay___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_VennDisplay() {
_start:
{
lean_object* x_1; 
x_1 = l_VennDisplay___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_Tactic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_PenroseDiagram(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Venn(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_Tactic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_PenroseDiagram(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_OfRpcMethod(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_isSubsetPred_x3f___closed__0 = _init_l_isSubsetPred_x3f___closed__0();
lean_mark_persistent(l_isSubsetPred_x3f___closed__0);
l_isSubsetPred_x3f___closed__1 = _init_l_isSubsetPred_x3f___closed__1();
lean_mark_persistent(l_isSubsetPred_x3f___closed__1);
l_isSubsetPred_x3f___closed__2 = _init_l_isSubsetPred_x3f___closed__2();
lean_mark_persistent(l_isSubsetPred_x3f___closed__2);
l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0 = _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__0);
l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1 = _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkSetDiag_spec__0___closed__1);
l_mkSetDiag___closed__0 = _init_l_mkSetDiag___closed__0();
lean_mark_persistent(l_mkSetDiag___closed__0);
l_mkSetDiag___closed__1 = _init_l_mkSetDiag___closed__1();
lean_mark_persistent(l_mkSetDiag___closed__1);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__0);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__1);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__2);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__3);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___isSetGoal_x3f_spec__0___redArg___closed__4);
l_isSetGoal_x3f___closed__0 = _init_l_isSetGoal_x3f___closed__0();
lean_mark_persistent(l_isSetGoal_x3f___closed__0);
l_isSetGoal_x3f___closed__1 = _init_l_isSetGoal_x3f___closed__1();
lean_mark_persistent(l_isSetGoal_x3f___closed__1);
l_isSetGoal_x3f___closed__2 = _init_l_isSetGoal_x3f___closed__2();
lean_mark_persistent(l_isSetGoal_x3f___closed__2);
l_isSetGoal_x3f___closed__3 = _init_l_isSetGoal_x3f___closed__3();
lean_mark_persistent(l_isSetGoal_x3f___closed__3);
l_isSetGoal_x3f___closed__4 = _init_l_isSetGoal_x3f___closed__4();
lean_mark_persistent(l_isSetGoal_x3f___closed__4);
l_isSetGoal_x3f___closed__5 = _init_l_isSetGoal_x3f___closed__5();
lean_mark_persistent(l_isSetGoal_x3f___closed__5);
l_isSetGoal_x3f___closed__6 = _init_l_isSetGoal_x3f___closed__6();
lean_mark_persistent(l_isSetGoal_x3f___closed__6);
l_findGoalForLocation___closed__0 = _init_l_findGoalForLocation___closed__0();
lean_mark_persistent(l_findGoalForLocation___closed__0);
l_panic___at___VennDisplay_rpc_spec__0___closed__0 = _init_l_panic___at___VennDisplay_rpc_spec__0___closed__0();
lean_mark_persistent(l_panic___at___VennDisplay_rpc_spec__0___closed__0);
l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0 = _init_l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0();
lean_mark_persistent(l_Array_filterMapM___at___VennDisplay_rpc_spec__1___closed__0);
l_VennDisplay_rpc___lam__0___closed__0 = _init_l_VennDisplay_rpc___lam__0___closed__0();
lean_mark_persistent(l_VennDisplay_rpc___lam__0___closed__0);
l_VennDisplay_rpc___lam__0___closed__1 = _init_l_VennDisplay_rpc___lam__0___closed__1();
lean_mark_persistent(l_VennDisplay_rpc___lam__0___closed__1);
l_VennDisplay_rpc___lam__0___closed__2 = _init_l_VennDisplay_rpc___lam__0___closed__2();
lean_mark_persistent(l_VennDisplay_rpc___lam__0___closed__2);
l_VennDisplay_rpc___lam__0___closed__3 = _init_l_VennDisplay_rpc___lam__0___closed__3();
lean_mark_persistent(l_VennDisplay_rpc___lam__0___closed__3);
l_VennDisplay_rpc___lam__0___closed__4 = _init_l_VennDisplay_rpc___lam__0___closed__4();
lean_mark_persistent(l_VennDisplay_rpc___lam__0___closed__4);
l_VennDisplay_rpc___lam__2___closed__0 = _init_l_VennDisplay_rpc___lam__2___closed__0();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__0);
l_VennDisplay_rpc___lam__2___closed__1 = _init_l_VennDisplay_rpc___lam__2___closed__1();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__1);
l_VennDisplay_rpc___lam__2___closed__2 = _init_l_VennDisplay_rpc___lam__2___closed__2();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__2);
l_VennDisplay_rpc___lam__2___closed__3 = _init_l_VennDisplay_rpc___lam__2___closed__3();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__3);
l_VennDisplay_rpc___lam__2___closed__4 = _init_l_VennDisplay_rpc___lam__2___closed__4();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__4);
l_VennDisplay_rpc___lam__2___closed__5 = _init_l_VennDisplay_rpc___lam__2___closed__5();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__5);
l_VennDisplay_rpc___lam__2___closed__6 = _init_l_VennDisplay_rpc___lam__2___closed__6();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__6);
l_VennDisplay_rpc___lam__2___closed__7 = _init_l_VennDisplay_rpc___lam__2___closed__7();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__7);
l_VennDisplay_rpc___lam__2___closed__8 = _init_l_VennDisplay_rpc___lam__2___closed__8();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__8);
l_VennDisplay_rpc___lam__2___closed__9 = _init_l_VennDisplay_rpc___lam__2___closed__9();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__9);
l_VennDisplay_rpc___lam__2___closed__10 = _init_l_VennDisplay_rpc___lam__2___closed__10();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__10);
l_VennDisplay_rpc___lam__2___closed__11 = _init_l_VennDisplay_rpc___lam__2___closed__11();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__11);
l_VennDisplay_rpc___lam__2___closed__12 = _init_l_VennDisplay_rpc___lam__2___closed__12();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__12);
l_VennDisplay_rpc___lam__2___closed__13 = _init_l_VennDisplay_rpc___lam__2___closed__13();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__13);
l_VennDisplay_rpc___lam__2___closed__14 = _init_l_VennDisplay_rpc___lam__2___closed__14();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__14);
l_VennDisplay_rpc___lam__2___closed__15 = _init_l_VennDisplay_rpc___lam__2___closed__15();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__15);
l_VennDisplay_rpc___lam__2___closed__16 = _init_l_VennDisplay_rpc___lam__2___closed__16();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__16);
l_VennDisplay_rpc___lam__2___closed__17 = _init_l_VennDisplay_rpc___lam__2___closed__17();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__17);
l_VennDisplay_rpc___lam__2___closed__18 = _init_l_VennDisplay_rpc___lam__2___closed__18();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__18);
l_VennDisplay_rpc___lam__2___closed__19 = _init_l_VennDisplay_rpc___lam__2___closed__19();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__19);
l_VennDisplay_rpc___lam__2___closed__20 = _init_l_VennDisplay_rpc___lam__2___closed__20();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__20);
l_VennDisplay_rpc___lam__2___closed__21 = _init_l_VennDisplay_rpc___lam__2___closed__21();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__21);
l_VennDisplay_rpc___lam__2___closed__22 = _init_l_VennDisplay_rpc___lam__2___closed__22();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__22);
l_VennDisplay_rpc___lam__2___closed__23 = _init_l_VennDisplay_rpc___lam__2___closed__23();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__23);
l_VennDisplay_rpc___lam__2___closed__24 = _init_l_VennDisplay_rpc___lam__2___closed__24();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__24);
l_VennDisplay_rpc___lam__2___closed__25 = _init_l_VennDisplay_rpc___lam__2___closed__25();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__25);
l_VennDisplay_rpc___lam__2___closed__26 = _init_l_VennDisplay_rpc___lam__2___closed__26();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__26);
l_VennDisplay_rpc___lam__2___closed__27 = _init_l_VennDisplay_rpc___lam__2___closed__27();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__27);
l_VennDisplay_rpc___lam__2___closed__28 = _init_l_VennDisplay_rpc___lam__2___closed__28();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__28);
l_VennDisplay_rpc___lam__2___closed__29 = _init_l_VennDisplay_rpc___lam__2___closed__29();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__29);
l_VennDisplay_rpc___lam__2___closed__30 = _init_l_VennDisplay_rpc___lam__2___closed__30();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__30);
l_VennDisplay_rpc___lam__2___closed__31 = _init_l_VennDisplay_rpc___lam__2___closed__31();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__31);
l_VennDisplay_rpc___lam__2___closed__32 = _init_l_VennDisplay_rpc___lam__2___closed__32();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__32);
l_VennDisplay_rpc___lam__2___closed__33 = _init_l_VennDisplay_rpc___lam__2___closed__33();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__33);
l_VennDisplay_rpc___lam__2___closed__34 = _init_l_VennDisplay_rpc___lam__2___closed__34();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__34);
l_VennDisplay_rpc___lam__2___closed__35 = _init_l_VennDisplay_rpc___lam__2___closed__35();
lean_mark_persistent(l_VennDisplay_rpc___lam__2___closed__35);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__2);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__3);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___VennDisplay_rpc___rpc__wrapped_spec__0___lam__3___closed__4);
l_VennDisplay_rpc___rpc__wrapped___closed__0 = _init_l_VennDisplay_rpc___rpc__wrapped___closed__0();
lean_mark_persistent(l_VennDisplay_rpc___rpc__wrapped___closed__0);
l_VennDisplay_rpc___rpc__wrapped___closed__1 = _init_l_VennDisplay_rpc___rpc__wrapped___closed__1();
lean_mark_persistent(l_VennDisplay_rpc___rpc__wrapped___closed__1);
l_VennDisplay_rpc___rpc__wrapped___closed__2 = _init_l_VennDisplay_rpc___rpc__wrapped___closed__2();
lean_mark_persistent(l_VennDisplay_rpc___rpc__wrapped___closed__2);
l_VennDisplay_rpc___rpc__wrapped___closed__3 = _init_l_VennDisplay_rpc___rpc__wrapped___closed__3();
lean_mark_persistent(l_VennDisplay_rpc___rpc__wrapped___closed__3);
l_VennDisplay_rpc___rpc__wrapped = _init_l_VennDisplay_rpc___rpc__wrapped();
lean_mark_persistent(l_VennDisplay_rpc___rpc__wrapped);
l_VennDisplay___closed__0 = _init_l_VennDisplay___closed__0();
lean_mark_persistent(l_VennDisplay___closed__0);
l_VennDisplay___closed__1 = _init_l_VennDisplay___closed__1();
l_VennDisplay___closed__2 = _init_l_VennDisplay___closed__2();
lean_mark_persistent(l_VennDisplay___closed__2);
l_VennDisplay___closed__3 = _init_l_VennDisplay___closed__3();
lean_mark_persistent(l_VennDisplay___closed__3);
l_VennDisplay___closed__4 = _init_l_VennDisplay___closed__4();
lean_mark_persistent(l_VennDisplay___closed__4);
l_VennDisplay = _init_l_VennDisplay();
lean_mark_persistent(l_VennDisplay);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
