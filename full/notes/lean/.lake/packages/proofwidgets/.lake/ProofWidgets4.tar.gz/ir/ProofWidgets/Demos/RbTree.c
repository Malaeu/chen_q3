// Lean compiler output
// Module: ProofWidgets.Demos.RbTree
// Imports: Init ProofWidgets.Presentation.Expr ProofWidgets.Component.Panel.SelectionPanel
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorIdx(lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0;
static lean_object* l_empty_x3f___closed__2;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
static lean_object* l_empty_x3f___closed__0;
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour;
lean_object* l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion(lean_object*, uint8_t, uint8_t, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
static lean_object* l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
static lean_object* l_drawTree_x3f_go___closed__0;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___redArg(lean_object*);
static lean_object* l_instToJsonRBTreeVarsColour___closed__0;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object*);
uint8_t l_Lean_Exception_isInterrupt(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_toCtorIdx___boxed(lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_;
static lean_object* l_RBTreeVarsColour_noConfusion___redArg___closed__0;
uint8_t l_Lean_Expr_isAppOfArity(lean_object*, lean_object*, lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_;
LEAN_EXPORT lean_object* l_RBTree_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket_node____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_RBColour_noConfusion___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(lean_object*, lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1;
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___redArg___boxed(lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0;
LEAN_EXPORT lean_object* l_instRpcEncodableRBDisplayProps_enc____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___closed__3;
LEAN_EXPORT lean_object* l_RBColour_black_elim___redArg___boxed(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
static lean_object* l_node_x3f___closed__1;
LEAN_EXPORT lean_object* l_Lean_Expr_app5_x3f(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_RBColour_toCtorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_node_elim___redArg(lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RBTree_balance___redArg(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_node_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert_makeBlack___redArg(lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert_ins(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RBTree_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_object* l_Lean_stringToMessageData(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Meta_evalExpr_x27___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_var_elim(lean_object*, lean_object*, lean_object*, lean_object*);
static uint64_t l_RBDisplay___closed__1;
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim___redArg(lean_object*, lean_object*);
static lean_object* l_RBDisplay___closed__2;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_;
static lean_object* l_RBTree_presenter___lam__0___closed__0;
LEAN_EXPORT lean_object* l_RBColour_toCtorIdx(uint8_t);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___closed__0;
LEAN_EXPORT lean_object* l_RBColour_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___redArg___boxed(lean_object*, lean_object*);
static lean_object* l_evalColourUnsafe___closed__1;
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_node_x3f(lean_object*);
static lean_object* l_empty_x3f___closed__1;
LEAN_EXPORT lean_object* l_RBColour_red_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_var_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_ctorElim___redArg(lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RBColour_noConfusion(lean_object*, uint8_t, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_node_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_black_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_balance(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1;
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___closed__2;
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableRBTreeVars;
static lean_object* l_instToJsonRBTreeVarsColour_toJson___closed__0;
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___lam__0(lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour___closed__0;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___redArg___boxed(lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBDisplayProps_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_drawTree_x3f(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket_node____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBDisplay;
LEAN_EXPORT lean_object* l_instRpcEncodableRBDisplayProps_dec____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instRpcEncodableRBDisplayProps___closed__2;
lean_object* l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_drawTree_x3f_go(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_;
LEAN_EXPORT lean_object* l_RBColour_red_elim___redArg___boxed(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_instToJsonRBTreeVarsColour_toJson___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket_var____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_empty_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_black_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorIdx___boxed(lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars___closed__0;
static lean_object* l_evalColourUnsafe___closed__0;
LEAN_EXPORT lean_object* l_instToJsonRBTreeVarsColour_toJson(uint8_t);
LEAN_EXPORT lean_object* l_Lean_Expr_app5_x3f___boxed(lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
static lean_object* l_instToJsonRBTreeVarsColour_toJson___closed__2;
lean_object* l_Except_orElseLazy___redArg(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_empty_x3f(lean_object*);
lean_object* l_Lean_Expr_appFn_x21(lean_object*);
LEAN_EXPORT lean_object* l_RBColour_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_empty_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_presenter___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_toCtorIdx(uint8_t);
LEAN_EXPORT lean_object* l_RBColour_red_elim(lean_object*, uint8_t, lean_object*, lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* l_empty_x3f___boxed(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object*);
LEAN_EXPORT uint8_t l_RBTree_contains___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson(lean_object*);
static lean_object* l_RBDisplay___closed__0;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1__ctorIdx(lean_object*);
static lean_object* l_instToJsonRBTreeVarsColour_toJson___closed__1;
LEAN_EXPORT lean_object* l_RBTree_balance___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_object* l_Lean_Json_parseTagged(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_RBTree_presenter___lam__0___closed__1;
static lean_object* l_node_x3f___closed__0;
LEAN_EXPORT lean_object* l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket_empty____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVars_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_node_x3f___boxed(lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1;
LEAN_EXPORT uint8_t l_RBTree_contains(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___redArg___boxed(lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars___closed__1;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_RBDisplay___closed__3;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_RBDisplay___closed__4;
LEAN_EXPORT lean_object* l_RBColour_ctorElim___redArg___boxed(lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_(lean_object*);
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___boxed(lean_object*, lean_object*);
static lean_object* l_RBTree_presenter___closed__0;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert_ins___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_presenter;
LEAN_EXPORT lean_object* l_RBColour_black_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___redArg(lean_object*);
static lean_object* l_drawTree_x3f___closed__0;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_contains___redArg___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_empty_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_;
static lean_object* l_instRpcEncodableRBDisplayProps___closed__1;
static lean_object* l_instRpcEncodableRBDisplayProps___closed__0;
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___closed__1;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RpcEncodablePacket_var____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___redArg(uint8_t, uint8_t);
LEAN_EXPORT lean_object* l_RBTree_node_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Server_instToJsonCodeActionResolveData_toJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(lean_object*);
static lean_object* l_instRpcEncodableRBTreeVars___closed__2;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___redArg(lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_contains___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg(uint8_t, uint8_t);
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBDisplayProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_insert_makeBlack(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_evalColourUnsafe(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_empty_elim___redArg(lean_object*, lean_object*);
static lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0;
LEAN_EXPORT lean_object* l_RBColour_ctorIdx(uint8_t);
uint8_t l_Lean_Exception_isRuntime(lean_object*);
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBTree_balance___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
LEAN_EXPORT lean_object* l_instRpcEncodableRBDisplayProps;
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79____boxed(lean_object*);
LEAN_EXPORT lean_object* l_RBTree_ctorIdx(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_red_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRBTreeVarsColour;
LEAN_EXPORT lean_object* l_RpcEncodablePacket_empty____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RBColour_ctorIdx(uint8_t x_1) {
_start:
{
if (x_1 == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_RBColour_ctorIdx___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_RBColour_ctorIdx(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBColour_toCtorIdx(uint8_t x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBColour_ctorIdx(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBColour_toCtorIdx___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_RBColour_toCtorIdx(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBColour_ctorElim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBColour_ctorElim(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_inc(x_5);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBColour_ctorElim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBColour_ctorElim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBColour_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; lean_object* x_7; 
x_6 = lean_unbox(x_3);
x_7 = l_RBColour_ctorElim(x_1, x_2, x_6, x_4, x_5);
lean_dec(x_5);
lean_dec(x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBColour_red_elim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBColour_red_elim(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_inc(x_4);
return x_4;
}
}
LEAN_EXPORT lean_object* l_RBColour_red_elim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBColour_red_elim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBColour_red_elim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_2);
x_6 = l_RBColour_red_elim(x_1, x_5, x_3, x_4);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBColour_black_elim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBColour_black_elim(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_inc(x_4);
return x_4;
}
}
LEAN_EXPORT lean_object* l_RBColour_black_elim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBColour_black_elim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBColour_black_elim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_2);
x_6 = l_RBColour_black_elim(x_1, x_5, x_3, x_4);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg(uint8_t x_1, uint8_t x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_closure((void*)(l_RBColour_noConfusion___redArg___lam__0___boxed), 1, 0);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion(lean_object* x_1, uint8_t x_2, uint8_t x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBColour_noConfusion___redArg(x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBColour_noConfusion___redArg___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; uint8_t x_4; lean_object* x_5; 
x_3 = lean_unbox(x_1);
x_4 = lean_unbox(x_2);
x_5 = l_RBColour_noConfusion___redArg(x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBColour_noConfusion___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; uint8_t x_6; lean_object* x_7; 
x_5 = lean_unbox(x_2);
x_6 = lean_unbox(x_3);
x_7 = l_RBColour_noConfusion(x_1, x_5, x_6, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___redArg(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorIdx(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTree_ctorIdx___redArg(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTree_ctorIdx___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorIdx___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTree_ctorIdx(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
return x_2;
}
else
{
uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_3 = lean_ctor_get_uint8(x_1, sizeof(void*)*3);
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 2);
lean_inc(x_6);
lean_dec_ref(x_1);
x_7 = lean_box(x_3);
x_8 = lean_apply_4(x_2, x_7, x_4, x_5, x_6);
return x_8;
}
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_RBTree_ctorElim___redArg(x_4, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBTree_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_RBTree_ctorElim(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBTree_empty_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTree_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTree_empty_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RBTree_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTree_node_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTree_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTree_node_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RBTree_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT uint8_t l_RBTree_contains___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
lean_dec(x_2);
lean_dec_ref(x_1);
x_4 = 0;
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_3, 2);
lean_inc(x_7);
lean_dec_ref(x_3);
lean_inc_ref(x_1);
lean_inc(x_2);
x_8 = lean_apply_2(x_1, x_2, x_6);
x_9 = lean_unbox(x_8);
switch (x_9) {
case 0:
{
lean_dec(x_7);
x_3 = x_5;
goto _start;
}
case 1:
{
uint8_t x_11; 
lean_dec(x_7);
lean_dec(x_5);
lean_dec(x_2);
lean_dec_ref(x_1);
x_11 = 1;
return x_11;
}
default: 
{
lean_dec(x_5);
x_3 = x_7;
goto _start;
}
}
}
}
}
LEAN_EXPORT uint8_t l_RBTree_contains(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = l_RBTree_contains___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTree_contains___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; lean_object* x_5; 
x_4 = l_RBTree_contains___redArg(x_1, x_2, x_3);
x_5 = lean_box(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTree_contains___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = l_RBTree_contains(x_1, x_2, x_3, x_4);
x_6 = lean_box(x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTree_balance___redArg(uint8_t x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
if (x_1 == 0)
{
lean_object* x_17; 
x_17 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_17, 0, x_2);
lean_ctor_set(x_17, 1, x_3);
lean_ctor_set(x_17, 2, x_4);
lean_ctor_set_uint8(x_17, sizeof(void*)*3, x_1);
return x_17;
}
else
{
if (lean_obj_tag(x_2) == 0)
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_18; 
x_18 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_18, 0, x_4);
lean_ctor_set(x_18, 1, x_3);
lean_ctor_set(x_18, 2, x_4);
lean_ctor_set_uint8(x_18, sizeof(void*)*3, x_1);
return x_18;
}
else
{
uint8_t x_19; 
x_19 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_19 == 0)
{
lean_object* x_20; 
x_20 = lean_ctor_get(x_4, 0);
lean_inc(x_20);
if (lean_obj_tag(x_20) == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_4, 2);
lean_inc(x_21);
if (lean_obj_tag(x_21) == 0)
{
uint8_t x_22; 
x_22 = !lean_is_exclusive(x_4);
if (x_22 == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_23 = lean_ctor_get(x_4, 2);
lean_dec(x_23);
x_24 = lean_ctor_get(x_4, 0);
lean_dec(x_24);
lean_ctor_set(x_4, 0, x_21);
x_25 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_25, 0, x_21);
lean_ctor_set(x_25, 1, x_3);
lean_ctor_set(x_25, 2, x_4);
lean_ctor_set_uint8(x_25, sizeof(void*)*3, x_1);
return x_25;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_4, 1);
lean_inc(x_26);
lean_dec(x_4);
x_27 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_27, 0, x_21);
lean_ctor_set(x_27, 1, x_26);
lean_ctor_set(x_27, 2, x_21);
lean_ctor_set_uint8(x_27, sizeof(void*)*3, x_19);
x_28 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_28, 0, x_21);
lean_ctor_set(x_28, 1, x_3);
lean_ctor_set(x_28, 2, x_27);
lean_ctor_set_uint8(x_28, sizeof(void*)*3, x_1);
return x_28;
}
}
else
{
uint8_t x_29; 
x_29 = lean_ctor_get_uint8(x_21, sizeof(void*)*3);
if (x_29 == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_30 = lean_ctor_get(x_4, 1);
lean_inc(x_30);
lean_dec_ref(x_4);
x_31 = lean_ctor_get(x_21, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_21, 1);
lean_inc(x_32);
x_33 = lean_ctor_get(x_21, 2);
lean_inc(x_33);
lean_dec_ref(x_21);
x_5 = x_20;
x_6 = x_3;
x_7 = x_20;
x_8 = x_30;
x_9 = x_31;
x_10 = x_32;
x_11 = x_33;
goto block_16;
}
else
{
uint8_t x_34; 
x_34 = !lean_is_exclusive(x_21);
if (x_34 == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_ctor_get(x_21, 2);
lean_dec(x_35);
x_36 = lean_ctor_get(x_21, 1);
lean_dec(x_36);
x_37 = lean_ctor_get(x_21, 0);
lean_dec(x_37);
lean_ctor_set(x_21, 2, x_4);
lean_ctor_set(x_21, 1, x_3);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
else
{
lean_object* x_38; 
lean_dec(x_21);
x_38 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_38, 0, x_20);
lean_ctor_set(x_38, 1, x_3);
lean_ctor_set(x_38, 2, x_4);
lean_ctor_set_uint8(x_38, sizeof(void*)*3, x_29);
return x_38;
}
}
}
}
else
{
uint8_t x_39; 
x_39 = lean_ctor_get_uint8(x_20, sizeof(void*)*3);
if (x_39 == 0)
{
lean_object* x_40; 
x_40 = lean_ctor_get(x_4, 2);
lean_inc(x_40);
if (lean_obj_tag(x_40) == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_41 = lean_ctor_get(x_4, 1);
lean_inc(x_41);
lean_dec_ref(x_4);
x_42 = lean_ctor_get(x_20, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_20, 1);
lean_inc(x_43);
x_44 = lean_ctor_get(x_20, 2);
lean_inc(x_44);
lean_dec_ref(x_20);
x_5 = x_40;
x_6 = x_3;
x_7 = x_42;
x_8 = x_43;
x_9 = x_44;
x_10 = x_41;
x_11 = x_40;
goto block_16;
}
else
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_45 = lean_ctor_get(x_4, 1);
lean_inc(x_45);
lean_dec_ref(x_4);
x_46 = lean_ctor_get(x_20, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_20, 1);
lean_inc(x_47);
x_48 = lean_ctor_get(x_20, 2);
lean_inc(x_48);
lean_dec_ref(x_20);
x_5 = x_2;
x_6 = x_3;
x_7 = x_46;
x_8 = x_47;
x_9 = x_48;
x_10 = x_45;
x_11 = x_40;
goto block_16;
}
}
else
{
lean_object* x_49; 
x_49 = lean_ctor_get(x_4, 2);
lean_inc(x_49);
if (lean_obj_tag(x_49) == 0)
{
uint8_t x_50; 
x_50 = !lean_is_exclusive(x_20);
if (x_50 == 0)
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_51 = lean_ctor_get(x_20, 2);
lean_dec(x_51);
x_52 = lean_ctor_get(x_20, 1);
lean_dec(x_52);
x_53 = lean_ctor_get(x_20, 0);
lean_dec(x_53);
lean_ctor_set(x_20, 2, x_4);
lean_ctor_set(x_20, 1, x_3);
lean_ctor_set(x_20, 0, x_49);
return x_20;
}
else
{
lean_object* x_54; 
lean_dec(x_20);
x_54 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_54, 0, x_49);
lean_ctor_set(x_54, 1, x_3);
lean_ctor_set(x_54, 2, x_4);
lean_ctor_set_uint8(x_54, sizeof(void*)*3, x_39);
return x_54;
}
}
else
{
uint8_t x_55; 
x_55 = lean_ctor_get_uint8(x_49, sizeof(void*)*3);
if (x_55 == 0)
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_56 = lean_ctor_get(x_4, 1);
lean_inc(x_56);
lean_dec_ref(x_4);
x_57 = lean_ctor_get(x_49, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_49, 1);
lean_inc(x_58);
x_59 = lean_ctor_get(x_49, 2);
lean_inc(x_59);
lean_dec_ref(x_49);
x_5 = x_2;
x_6 = x_3;
x_7 = x_20;
x_8 = x_56;
x_9 = x_57;
x_10 = x_58;
x_11 = x_59;
goto block_16;
}
else
{
uint8_t x_60; 
x_60 = !lean_is_exclusive(x_4);
if (x_60 == 0)
{
lean_object* x_61; lean_object* x_62; uint8_t x_63; 
x_61 = lean_ctor_get(x_4, 2);
lean_dec(x_61);
x_62 = lean_ctor_get(x_4, 0);
lean_dec(x_62);
x_63 = !lean_is_exclusive(x_20);
if (x_63 == 0)
{
uint8_t x_64; 
lean_ctor_set_uint8(x_20, sizeof(void*)*3, x_55);
lean_inc_ref(x_49);
x_64 = !lean_is_exclusive(x_49);
if (x_64 == 0)
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_65 = lean_ctor_get(x_49, 2);
lean_dec(x_65);
x_66 = lean_ctor_get(x_49, 1);
lean_dec(x_66);
x_67 = lean_ctor_get(x_49, 0);
lean_dec(x_67);
lean_ctor_set(x_49, 2, x_4);
lean_ctor_set(x_49, 1, x_3);
lean_ctor_set(x_49, 0, x_2);
return x_49;
}
else
{
lean_object* x_68; 
lean_dec(x_49);
x_68 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_68, 0, x_2);
lean_ctor_set(x_68, 1, x_3);
lean_ctor_set(x_68, 2, x_4);
lean_ctor_set_uint8(x_68, sizeof(void*)*3, x_55);
return x_68;
}
}
else
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; 
x_69 = lean_ctor_get(x_20, 0);
x_70 = lean_ctor_get(x_20, 1);
x_71 = lean_ctor_get(x_20, 2);
lean_inc(x_71);
lean_inc(x_70);
lean_inc(x_69);
lean_dec(x_20);
x_72 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_72, 0, x_69);
lean_ctor_set(x_72, 1, x_70);
lean_ctor_set(x_72, 2, x_71);
lean_ctor_set_uint8(x_72, sizeof(void*)*3, x_55);
lean_inc_ref(x_49);
lean_ctor_set(x_4, 0, x_72);
if (lean_is_exclusive(x_49)) {
 lean_ctor_release(x_49, 0);
 lean_ctor_release(x_49, 1);
 lean_ctor_release(x_49, 2);
 x_73 = x_49;
} else {
 lean_dec_ref(x_49);
 x_73 = lean_box(0);
}
if (lean_is_scalar(x_73)) {
 x_74 = lean_alloc_ctor(1, 3, 1);
} else {
 x_74 = x_73;
}
lean_ctor_set(x_74, 0, x_2);
lean_ctor_set(x_74, 1, x_3);
lean_ctor_set(x_74, 2, x_4);
lean_ctor_set_uint8(x_74, sizeof(void*)*3, x_55);
return x_74;
}
}
else
{
lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; 
x_75 = lean_ctor_get(x_4, 1);
lean_inc(x_75);
lean_dec(x_4);
x_76 = lean_ctor_get(x_20, 0);
lean_inc(x_76);
x_77 = lean_ctor_get(x_20, 1);
lean_inc(x_77);
x_78 = lean_ctor_get(x_20, 2);
lean_inc(x_78);
if (lean_is_exclusive(x_20)) {
 lean_ctor_release(x_20, 0);
 lean_ctor_release(x_20, 1);
 lean_ctor_release(x_20, 2);
 x_79 = x_20;
} else {
 lean_dec_ref(x_20);
 x_79 = lean_box(0);
}
if (lean_is_scalar(x_79)) {
 x_80 = lean_alloc_ctor(1, 3, 1);
} else {
 x_80 = x_79;
}
lean_ctor_set(x_80, 0, x_76);
lean_ctor_set(x_80, 1, x_77);
lean_ctor_set(x_80, 2, x_78);
lean_ctor_set_uint8(x_80, sizeof(void*)*3, x_55);
lean_inc_ref(x_49);
x_81 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_81, 0, x_80);
lean_ctor_set(x_81, 1, x_75);
lean_ctor_set(x_81, 2, x_49);
if (lean_is_exclusive(x_49)) {
 lean_ctor_release(x_49, 0);
 lean_ctor_release(x_49, 1);
 lean_ctor_release(x_49, 2);
 x_82 = x_49;
} else {
 lean_dec_ref(x_49);
 x_82 = lean_box(0);
}
lean_ctor_set_uint8(x_81, sizeof(void*)*3, x_19);
if (lean_is_scalar(x_82)) {
 x_83 = lean_alloc_ctor(1, 3, 1);
} else {
 x_83 = x_82;
}
lean_ctor_set(x_83, 0, x_2);
lean_ctor_set(x_83, 1, x_3);
lean_ctor_set(x_83, 2, x_81);
lean_ctor_set_uint8(x_83, sizeof(void*)*3, x_55);
return x_83;
}
}
}
}
}
}
else
{
lean_object* x_84; 
x_84 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_84, 0, x_2);
lean_ctor_set(x_84, 1, x_3);
lean_ctor_set(x_84, 2, x_4);
lean_ctor_set_uint8(x_84, sizeof(void*)*3, x_19);
return x_84;
}
}
}
else
{
uint8_t x_85; 
x_85 = lean_ctor_get_uint8(x_2, sizeof(void*)*3);
if (x_85 == 0)
{
lean_object* x_86; 
x_86 = lean_ctor_get(x_2, 0);
lean_inc(x_86);
if (lean_obj_tag(x_86) == 0)
{
lean_object* x_87; 
x_87 = lean_ctor_get(x_2, 2);
lean_inc(x_87);
if (lean_obj_tag(x_87) == 0)
{
if (lean_obj_tag(x_4) == 0)
{
uint8_t x_88; 
x_88 = !lean_is_exclusive(x_2);
if (x_88 == 0)
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; 
x_89 = lean_ctor_get(x_2, 2);
lean_dec(x_89);
x_90 = lean_ctor_get(x_2, 0);
lean_dec(x_90);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 0, x_4);
x_91 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_91, 0, x_2);
lean_ctor_set(x_91, 1, x_3);
lean_ctor_set(x_91, 2, x_4);
lean_ctor_set_uint8(x_91, sizeof(void*)*3, x_1);
return x_91;
}
else
{
lean_object* x_92; lean_object* x_93; lean_object* x_94; 
x_92 = lean_ctor_get(x_2, 1);
lean_inc(x_92);
lean_dec(x_2);
x_93 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_93, 0, x_4);
lean_ctor_set(x_93, 1, x_92);
lean_ctor_set(x_93, 2, x_4);
lean_ctor_set_uint8(x_93, sizeof(void*)*3, x_85);
x_94 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_94, 0, x_93);
lean_ctor_set(x_94, 1, x_3);
lean_ctor_set(x_94, 2, x_4);
lean_ctor_set_uint8(x_94, sizeof(void*)*3, x_1);
return x_94;
}
}
else
{
uint8_t x_95; 
x_95 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_95 == 0)
{
lean_object* x_96; 
x_96 = lean_ctor_get(x_4, 0);
lean_inc(x_96);
if (lean_obj_tag(x_96) == 0)
{
lean_object* x_97; 
x_97 = lean_ctor_get(x_4, 2);
lean_inc(x_97);
if (lean_obj_tag(x_97) == 0)
{
uint8_t x_98; 
x_98 = !lean_is_exclusive(x_2);
if (x_98 == 0)
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; uint8_t x_102; 
x_99 = lean_ctor_get(x_2, 1);
x_100 = lean_ctor_get(x_2, 2);
lean_dec(x_100);
x_101 = lean_ctor_get(x_2, 0);
lean_dec(x_101);
x_102 = !lean_is_exclusive(x_4);
if (x_102 == 0)
{
lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; 
x_103 = lean_ctor_get(x_4, 1);
x_104 = lean_ctor_get(x_4, 2);
lean_dec(x_104);
x_105 = lean_ctor_get(x_4, 0);
lean_dec(x_105);
lean_ctor_set(x_4, 1, x_99);
lean_ctor_set(x_4, 0, x_97);
lean_ctor_set(x_2, 2, x_97);
lean_ctor_set(x_2, 1, x_103);
lean_ctor_set(x_2, 0, x_97);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_95);
x_106 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_106, 0, x_4);
lean_ctor_set(x_106, 1, x_3);
lean_ctor_set(x_106, 2, x_2);
lean_ctor_set_uint8(x_106, sizeof(void*)*3, x_1);
return x_106;
}
else
{
lean_object* x_107; lean_object* x_108; lean_object* x_109; 
x_107 = lean_ctor_get(x_4, 1);
lean_inc(x_107);
lean_dec(x_4);
x_108 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_108, 0, x_97);
lean_ctor_set(x_108, 1, x_99);
lean_ctor_set(x_108, 2, x_97);
lean_ctor_set_uint8(x_108, sizeof(void*)*3, x_95);
lean_ctor_set(x_2, 2, x_97);
lean_ctor_set(x_2, 1, x_107);
lean_ctor_set(x_2, 0, x_97);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_95);
x_109 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_109, 0, x_108);
lean_ctor_set(x_109, 1, x_3);
lean_ctor_set(x_109, 2, x_2);
lean_ctor_set_uint8(x_109, sizeof(void*)*3, x_1);
return x_109;
}
}
else
{
lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; 
x_110 = lean_ctor_get(x_2, 1);
lean_inc(x_110);
lean_dec(x_2);
x_111 = lean_ctor_get(x_4, 1);
lean_inc(x_111);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_112 = x_4;
} else {
 lean_dec_ref(x_4);
 x_112 = lean_box(0);
}
if (lean_is_scalar(x_112)) {
 x_113 = lean_alloc_ctor(1, 3, 1);
} else {
 x_113 = x_112;
}
lean_ctor_set(x_113, 0, x_97);
lean_ctor_set(x_113, 1, x_110);
lean_ctor_set(x_113, 2, x_97);
lean_ctor_set_uint8(x_113, sizeof(void*)*3, x_95);
x_114 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_114, 0, x_97);
lean_ctor_set(x_114, 1, x_111);
lean_ctor_set(x_114, 2, x_97);
lean_ctor_set_uint8(x_114, sizeof(void*)*3, x_95);
x_115 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_115, 0, x_113);
lean_ctor_set(x_115, 1, x_3);
lean_ctor_set(x_115, 2, x_114);
lean_ctor_set_uint8(x_115, sizeof(void*)*3, x_1);
return x_115;
}
}
else
{
uint8_t x_116; 
x_116 = lean_ctor_get_uint8(x_97, sizeof(void*)*3);
if (x_116 == 0)
{
lean_object* x_117; lean_object* x_118; uint8_t x_119; 
x_117 = lean_ctor_get(x_2, 1);
lean_inc(x_117);
lean_dec_ref(x_2);
x_118 = lean_ctor_get(x_4, 1);
lean_inc(x_118);
lean_dec_ref(x_4);
x_119 = !lean_is_exclusive(x_97);
if (x_119 == 0)
{
lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_120 = lean_ctor_get(x_97, 0);
x_121 = lean_ctor_get(x_97, 1);
x_122 = lean_ctor_get(x_97, 2);
lean_ctor_set(x_97, 2, x_96);
lean_ctor_set(x_97, 1, x_117);
lean_ctor_set(x_97, 0, x_96);
x_5 = x_97;
x_6 = x_3;
x_7 = x_96;
x_8 = x_118;
x_9 = x_120;
x_10 = x_121;
x_11 = x_122;
goto block_16;
}
else
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; 
x_123 = lean_ctor_get(x_97, 0);
x_124 = lean_ctor_get(x_97, 1);
x_125 = lean_ctor_get(x_97, 2);
lean_inc(x_125);
lean_inc(x_124);
lean_inc(x_123);
lean_dec(x_97);
x_126 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_126, 0, x_96);
lean_ctor_set(x_126, 1, x_117);
lean_ctor_set(x_126, 2, x_96);
lean_ctor_set_uint8(x_126, sizeof(void*)*3, x_116);
x_5 = x_126;
x_6 = x_3;
x_7 = x_96;
x_8 = x_118;
x_9 = x_123;
x_10 = x_124;
x_11 = x_125;
goto block_16;
}
}
else
{
uint8_t x_127; 
x_127 = !lean_is_exclusive(x_97);
if (x_127 == 0)
{
lean_object* x_128; lean_object* x_129; lean_object* x_130; uint8_t x_131; 
x_128 = lean_ctor_get(x_97, 2);
lean_dec(x_128);
x_129 = lean_ctor_get(x_97, 1);
lean_dec(x_129);
x_130 = lean_ctor_get(x_97, 0);
lean_dec(x_130);
x_131 = !lean_is_exclusive(x_2);
if (x_131 == 0)
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; 
x_132 = lean_ctor_get(x_2, 1);
x_133 = lean_ctor_get(x_2, 2);
lean_dec(x_133);
x_134 = lean_ctor_get(x_2, 0);
lean_dec(x_134);
lean_ctor_set(x_97, 2, x_96);
lean_ctor_set(x_97, 1, x_132);
lean_ctor_set(x_97, 0, x_96);
lean_ctor_set_uint8(x_97, sizeof(void*)*3, x_95);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_97);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_116);
return x_2;
}
else
{
lean_object* x_135; lean_object* x_136; 
x_135 = lean_ctor_get(x_2, 1);
lean_inc(x_135);
lean_dec(x_2);
lean_ctor_set(x_97, 2, x_96);
lean_ctor_set(x_97, 1, x_135);
lean_ctor_set(x_97, 0, x_96);
lean_ctor_set_uint8(x_97, sizeof(void*)*3, x_95);
x_136 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_136, 0, x_97);
lean_ctor_set(x_136, 1, x_3);
lean_ctor_set(x_136, 2, x_4);
lean_ctor_set_uint8(x_136, sizeof(void*)*3, x_116);
return x_136;
}
}
else
{
lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; 
lean_dec(x_97);
x_137 = lean_ctor_get(x_2, 1);
lean_inc(x_137);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_138 = x_2;
} else {
 lean_dec_ref(x_2);
 x_138 = lean_box(0);
}
x_139 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_139, 0, x_96);
lean_ctor_set(x_139, 1, x_137);
lean_ctor_set(x_139, 2, x_96);
lean_ctor_set_uint8(x_139, sizeof(void*)*3, x_95);
if (lean_is_scalar(x_138)) {
 x_140 = lean_alloc_ctor(1, 3, 1);
} else {
 x_140 = x_138;
}
lean_ctor_set(x_140, 0, x_139);
lean_ctor_set(x_140, 1, x_3);
lean_ctor_set(x_140, 2, x_4);
lean_ctor_set_uint8(x_140, sizeof(void*)*3, x_116);
return x_140;
}
}
}
}
else
{
uint8_t x_141; 
x_141 = lean_ctor_get_uint8(x_96, sizeof(void*)*3);
if (x_141 == 0)
{
lean_object* x_142; 
x_142 = lean_ctor_get(x_4, 2);
lean_inc(x_142);
if (lean_obj_tag(x_142) == 0)
{
lean_object* x_143; lean_object* x_144; uint8_t x_145; 
x_143 = lean_ctor_get(x_2, 1);
lean_inc(x_143);
lean_dec_ref(x_2);
x_144 = lean_ctor_get(x_4, 1);
lean_inc(x_144);
lean_dec_ref(x_4);
x_145 = !lean_is_exclusive(x_96);
if (x_145 == 0)
{
lean_object* x_146; lean_object* x_147; lean_object* x_148; 
x_146 = lean_ctor_get(x_96, 0);
x_147 = lean_ctor_get(x_96, 1);
x_148 = lean_ctor_get(x_96, 2);
lean_ctor_set(x_96, 2, x_142);
lean_ctor_set(x_96, 1, x_143);
lean_ctor_set(x_96, 0, x_142);
x_5 = x_96;
x_6 = x_3;
x_7 = x_146;
x_8 = x_147;
x_9 = x_148;
x_10 = x_144;
x_11 = x_142;
goto block_16;
}
else
{
lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; 
x_149 = lean_ctor_get(x_96, 0);
x_150 = lean_ctor_get(x_96, 1);
x_151 = lean_ctor_get(x_96, 2);
lean_inc(x_151);
lean_inc(x_150);
lean_inc(x_149);
lean_dec(x_96);
x_152 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_152, 0, x_142);
lean_ctor_set(x_152, 1, x_143);
lean_ctor_set(x_152, 2, x_142);
lean_ctor_set_uint8(x_152, sizeof(void*)*3, x_141);
x_5 = x_152;
x_6 = x_3;
x_7 = x_149;
x_8 = x_150;
x_9 = x_151;
x_10 = x_144;
x_11 = x_142;
goto block_16;
}
}
else
{
uint8_t x_153; 
x_153 = lean_ctor_get_uint8(x_142, sizeof(void*)*3);
if (x_153 == 0)
{
lean_object* x_154; lean_object* x_155; uint8_t x_156; 
x_154 = lean_ctor_get(x_2, 1);
lean_inc(x_154);
lean_dec_ref(x_2);
x_155 = lean_ctor_get(x_4, 1);
lean_inc(x_155);
lean_dec_ref(x_4);
x_156 = !lean_is_exclusive(x_96);
if (x_156 == 0)
{
lean_object* x_157; lean_object* x_158; lean_object* x_159; 
x_157 = lean_ctor_get(x_96, 0);
x_158 = lean_ctor_get(x_96, 1);
x_159 = lean_ctor_get(x_96, 2);
lean_ctor_set(x_96, 2, x_87);
lean_ctor_set(x_96, 1, x_154);
lean_ctor_set(x_96, 0, x_87);
lean_ctor_set_uint8(x_96, sizeof(void*)*3, x_153);
x_5 = x_96;
x_6 = x_3;
x_7 = x_157;
x_8 = x_158;
x_9 = x_159;
x_10 = x_155;
x_11 = x_142;
goto block_16;
}
else
{
lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; 
x_160 = lean_ctor_get(x_96, 0);
x_161 = lean_ctor_get(x_96, 1);
x_162 = lean_ctor_get(x_96, 2);
lean_inc(x_162);
lean_inc(x_161);
lean_inc(x_160);
lean_dec(x_96);
x_163 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_163, 0, x_87);
lean_ctor_set(x_163, 1, x_154);
lean_ctor_set(x_163, 2, x_87);
lean_ctor_set_uint8(x_163, sizeof(void*)*3, x_153);
x_5 = x_163;
x_6 = x_3;
x_7 = x_160;
x_8 = x_161;
x_9 = x_162;
x_10 = x_155;
x_11 = x_142;
goto block_16;
}
}
else
{
lean_object* x_164; lean_object* x_165; uint8_t x_166; 
x_164 = lean_ctor_get(x_2, 1);
lean_inc(x_164);
lean_dec_ref(x_2);
x_165 = lean_ctor_get(x_4, 1);
lean_inc(x_165);
lean_dec_ref(x_4);
x_166 = !lean_is_exclusive(x_96);
if (x_166 == 0)
{
lean_object* x_167; lean_object* x_168; lean_object* x_169; 
x_167 = lean_ctor_get(x_96, 0);
x_168 = lean_ctor_get(x_96, 1);
x_169 = lean_ctor_get(x_96, 2);
lean_ctor_set(x_96, 2, x_87);
lean_ctor_set(x_96, 1, x_164);
lean_ctor_set(x_96, 0, x_87);
x_5 = x_96;
x_6 = x_3;
x_7 = x_167;
x_8 = x_168;
x_9 = x_169;
x_10 = x_165;
x_11 = x_142;
goto block_16;
}
else
{
lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; 
x_170 = lean_ctor_get(x_96, 0);
x_171 = lean_ctor_get(x_96, 1);
x_172 = lean_ctor_get(x_96, 2);
lean_inc(x_172);
lean_inc(x_171);
lean_inc(x_170);
lean_dec(x_96);
x_173 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_173, 0, x_87);
lean_ctor_set(x_173, 1, x_164);
lean_ctor_set(x_173, 2, x_87);
lean_ctor_set_uint8(x_173, sizeof(void*)*3, x_141);
x_5 = x_173;
x_6 = x_3;
x_7 = x_170;
x_8 = x_171;
x_9 = x_172;
x_10 = x_165;
x_11 = x_142;
goto block_16;
}
}
}
}
else
{
lean_object* x_174; 
x_174 = lean_ctor_get(x_4, 2);
lean_inc(x_174);
if (lean_obj_tag(x_174) == 0)
{
uint8_t x_175; 
x_175 = !lean_is_exclusive(x_96);
if (x_175 == 0)
{
lean_object* x_176; lean_object* x_177; lean_object* x_178; uint8_t x_179; 
x_176 = lean_ctor_get(x_96, 2);
lean_dec(x_176);
x_177 = lean_ctor_get(x_96, 1);
lean_dec(x_177);
x_178 = lean_ctor_get(x_96, 0);
lean_dec(x_178);
x_179 = !lean_is_exclusive(x_2);
if (x_179 == 0)
{
lean_object* x_180; lean_object* x_181; lean_object* x_182; 
x_180 = lean_ctor_get(x_2, 1);
x_181 = lean_ctor_get(x_2, 2);
lean_dec(x_181);
x_182 = lean_ctor_get(x_2, 0);
lean_dec(x_182);
lean_ctor_set(x_96, 2, x_174);
lean_ctor_set(x_96, 1, x_180);
lean_ctor_set(x_96, 0, x_174);
lean_ctor_set_uint8(x_96, sizeof(void*)*3, x_95);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_96);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_141);
return x_2;
}
else
{
lean_object* x_183; lean_object* x_184; 
x_183 = lean_ctor_get(x_2, 1);
lean_inc(x_183);
lean_dec(x_2);
lean_ctor_set(x_96, 2, x_174);
lean_ctor_set(x_96, 1, x_183);
lean_ctor_set(x_96, 0, x_174);
lean_ctor_set_uint8(x_96, sizeof(void*)*3, x_95);
x_184 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_184, 0, x_96);
lean_ctor_set(x_184, 1, x_3);
lean_ctor_set(x_184, 2, x_4);
lean_ctor_set_uint8(x_184, sizeof(void*)*3, x_141);
return x_184;
}
}
else
{
lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; 
lean_dec(x_96);
x_185 = lean_ctor_get(x_2, 1);
lean_inc(x_185);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_186 = x_2;
} else {
 lean_dec_ref(x_2);
 x_186 = lean_box(0);
}
x_187 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_187, 0, x_174);
lean_ctor_set(x_187, 1, x_185);
lean_ctor_set(x_187, 2, x_174);
lean_ctor_set_uint8(x_187, sizeof(void*)*3, x_95);
if (lean_is_scalar(x_186)) {
 x_188 = lean_alloc_ctor(1, 3, 1);
} else {
 x_188 = x_186;
}
lean_ctor_set(x_188, 0, x_187);
lean_ctor_set(x_188, 1, x_3);
lean_ctor_set(x_188, 2, x_4);
lean_ctor_set_uint8(x_188, sizeof(void*)*3, x_141);
return x_188;
}
}
else
{
uint8_t x_189; 
x_189 = lean_ctor_get_uint8(x_174, sizeof(void*)*3);
if (x_189 == 0)
{
lean_object* x_190; lean_object* x_191; uint8_t x_192; 
x_190 = lean_ctor_get(x_2, 1);
lean_inc(x_190);
lean_dec_ref(x_2);
x_191 = lean_ctor_get(x_4, 1);
lean_inc(x_191);
lean_dec_ref(x_4);
x_192 = !lean_is_exclusive(x_174);
if (x_192 == 0)
{
lean_object* x_193; lean_object* x_194; lean_object* x_195; 
x_193 = lean_ctor_get(x_174, 0);
x_194 = lean_ctor_get(x_174, 1);
x_195 = lean_ctor_get(x_174, 2);
lean_ctor_set(x_174, 2, x_87);
lean_ctor_set(x_174, 1, x_190);
lean_ctor_set(x_174, 0, x_87);
x_5 = x_174;
x_6 = x_3;
x_7 = x_96;
x_8 = x_191;
x_9 = x_193;
x_10 = x_194;
x_11 = x_195;
goto block_16;
}
else
{
lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; 
x_196 = lean_ctor_get(x_174, 0);
x_197 = lean_ctor_get(x_174, 1);
x_198 = lean_ctor_get(x_174, 2);
lean_inc(x_198);
lean_inc(x_197);
lean_inc(x_196);
lean_dec(x_174);
x_199 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_199, 0, x_87);
lean_ctor_set(x_199, 1, x_190);
lean_ctor_set(x_199, 2, x_87);
lean_ctor_set_uint8(x_199, sizeof(void*)*3, x_189);
x_5 = x_199;
x_6 = x_3;
x_7 = x_96;
x_8 = x_191;
x_9 = x_196;
x_10 = x_197;
x_11 = x_198;
goto block_16;
}
}
else
{
uint8_t x_200; 
x_200 = !lean_is_exclusive(x_2);
if (x_200 == 0)
{
lean_object* x_201; lean_object* x_202; lean_object* x_203; uint8_t x_204; 
x_201 = lean_ctor_get(x_2, 1);
x_202 = lean_ctor_get(x_2, 2);
lean_dec(x_202);
x_203 = lean_ctor_get(x_2, 0);
lean_dec(x_203);
x_204 = !lean_is_exclusive(x_4);
if (x_204 == 0)
{
lean_object* x_205; lean_object* x_206; lean_object* x_207; uint8_t x_208; 
x_205 = lean_ctor_get(x_4, 1);
x_206 = lean_ctor_get(x_4, 2);
lean_dec(x_206);
x_207 = lean_ctor_get(x_4, 0);
lean_dec(x_207);
x_208 = !lean_is_exclusive(x_96);
if (x_208 == 0)
{
lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; 
x_209 = lean_ctor_get(x_96, 0);
x_210 = lean_ctor_get(x_96, 1);
x_211 = lean_ctor_get(x_96, 2);
lean_ctor_set(x_96, 2, x_87);
lean_ctor_set(x_96, 1, x_201);
lean_ctor_set(x_96, 0, x_87);
lean_ctor_set_uint8(x_96, sizeof(void*)*3, x_95);
lean_ctor_set(x_4, 2, x_211);
lean_ctor_set(x_4, 1, x_210);
lean_ctor_set(x_4, 0, x_209);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_189);
lean_ctor_set(x_2, 2, x_174);
lean_ctor_set(x_2, 1, x_205);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_95);
x_212 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_212, 0, x_96);
lean_ctor_set(x_212, 1, x_3);
lean_ctor_set(x_212, 2, x_2);
lean_ctor_set_uint8(x_212, sizeof(void*)*3, x_189);
return x_212;
}
else
{
lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; 
x_213 = lean_ctor_get(x_96, 0);
x_214 = lean_ctor_get(x_96, 1);
x_215 = lean_ctor_get(x_96, 2);
lean_inc(x_215);
lean_inc(x_214);
lean_inc(x_213);
lean_dec(x_96);
x_216 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_216, 0, x_87);
lean_ctor_set(x_216, 1, x_201);
lean_ctor_set(x_216, 2, x_87);
lean_ctor_set_uint8(x_216, sizeof(void*)*3, x_95);
lean_ctor_set(x_4, 2, x_215);
lean_ctor_set(x_4, 1, x_214);
lean_ctor_set(x_4, 0, x_213);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_189);
lean_ctor_set(x_2, 2, x_174);
lean_ctor_set(x_2, 1, x_205);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_95);
x_217 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_217, 0, x_216);
lean_ctor_set(x_217, 1, x_3);
lean_ctor_set(x_217, 2, x_2);
lean_ctor_set_uint8(x_217, sizeof(void*)*3, x_189);
return x_217;
}
}
else
{
lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; 
x_218 = lean_ctor_get(x_4, 1);
lean_inc(x_218);
lean_dec(x_4);
x_219 = lean_ctor_get(x_96, 0);
lean_inc(x_219);
x_220 = lean_ctor_get(x_96, 1);
lean_inc(x_220);
x_221 = lean_ctor_get(x_96, 2);
lean_inc(x_221);
if (lean_is_exclusive(x_96)) {
 lean_ctor_release(x_96, 0);
 lean_ctor_release(x_96, 1);
 lean_ctor_release(x_96, 2);
 x_222 = x_96;
} else {
 lean_dec_ref(x_96);
 x_222 = lean_box(0);
}
if (lean_is_scalar(x_222)) {
 x_223 = lean_alloc_ctor(1, 3, 1);
} else {
 x_223 = x_222;
}
lean_ctor_set(x_223, 0, x_87);
lean_ctor_set(x_223, 1, x_201);
lean_ctor_set(x_223, 2, x_87);
lean_ctor_set_uint8(x_223, sizeof(void*)*3, x_95);
x_224 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_224, 0, x_219);
lean_ctor_set(x_224, 1, x_220);
lean_ctor_set(x_224, 2, x_221);
lean_ctor_set_uint8(x_224, sizeof(void*)*3, x_189);
lean_ctor_set(x_2, 2, x_174);
lean_ctor_set(x_2, 1, x_218);
lean_ctor_set(x_2, 0, x_224);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_95);
x_225 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_225, 0, x_223);
lean_ctor_set(x_225, 1, x_3);
lean_ctor_set(x_225, 2, x_2);
lean_ctor_set_uint8(x_225, sizeof(void*)*3, x_189);
return x_225;
}
}
else
{
lean_object* x_226; lean_object* x_227; lean_object* x_228; lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; lean_object* x_234; lean_object* x_235; lean_object* x_236; 
x_226 = lean_ctor_get(x_2, 1);
lean_inc(x_226);
lean_dec(x_2);
x_227 = lean_ctor_get(x_4, 1);
lean_inc(x_227);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_228 = x_4;
} else {
 lean_dec_ref(x_4);
 x_228 = lean_box(0);
}
x_229 = lean_ctor_get(x_96, 0);
lean_inc(x_229);
x_230 = lean_ctor_get(x_96, 1);
lean_inc(x_230);
x_231 = lean_ctor_get(x_96, 2);
lean_inc(x_231);
if (lean_is_exclusive(x_96)) {
 lean_ctor_release(x_96, 0);
 lean_ctor_release(x_96, 1);
 lean_ctor_release(x_96, 2);
 x_232 = x_96;
} else {
 lean_dec_ref(x_96);
 x_232 = lean_box(0);
}
if (lean_is_scalar(x_232)) {
 x_233 = lean_alloc_ctor(1, 3, 1);
} else {
 x_233 = x_232;
}
lean_ctor_set(x_233, 0, x_87);
lean_ctor_set(x_233, 1, x_226);
lean_ctor_set(x_233, 2, x_87);
lean_ctor_set_uint8(x_233, sizeof(void*)*3, x_95);
if (lean_is_scalar(x_228)) {
 x_234 = lean_alloc_ctor(1, 3, 1);
} else {
 x_234 = x_228;
}
lean_ctor_set(x_234, 0, x_229);
lean_ctor_set(x_234, 1, x_230);
lean_ctor_set(x_234, 2, x_231);
lean_ctor_set_uint8(x_234, sizeof(void*)*3, x_189);
x_235 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_235, 0, x_234);
lean_ctor_set(x_235, 1, x_227);
lean_ctor_set(x_235, 2, x_174);
lean_ctor_set_uint8(x_235, sizeof(void*)*3, x_95);
x_236 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_236, 0, x_233);
lean_ctor_set(x_236, 1, x_3);
lean_ctor_set(x_236, 2, x_235);
lean_ctor_set_uint8(x_236, sizeof(void*)*3, x_189);
return x_236;
}
}
}
}
}
}
else
{
uint8_t x_237; 
x_237 = !lean_is_exclusive(x_2);
if (x_237 == 0)
{
lean_object* x_238; lean_object* x_239; lean_object* x_240; 
x_238 = lean_ctor_get(x_2, 2);
lean_dec(x_238);
x_239 = lean_ctor_get(x_2, 0);
lean_dec(x_239);
lean_ctor_set(x_2, 0, x_87);
x_240 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_240, 0, x_2);
lean_ctor_set(x_240, 1, x_3);
lean_ctor_set(x_240, 2, x_4);
lean_ctor_set_uint8(x_240, sizeof(void*)*3, x_95);
return x_240;
}
else
{
lean_object* x_241; lean_object* x_242; lean_object* x_243; 
x_241 = lean_ctor_get(x_2, 1);
lean_inc(x_241);
lean_dec(x_2);
x_242 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_242, 0, x_87);
lean_ctor_set(x_242, 1, x_241);
lean_ctor_set(x_242, 2, x_87);
lean_ctor_set_uint8(x_242, sizeof(void*)*3, x_85);
x_243 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_243, 0, x_242);
lean_ctor_set(x_243, 1, x_3);
lean_ctor_set(x_243, 2, x_4);
lean_ctor_set_uint8(x_243, sizeof(void*)*3, x_95);
return x_243;
}
}
}
}
else
{
uint8_t x_244; 
x_244 = lean_ctor_get_uint8(x_87, sizeof(void*)*3);
if (x_244 == 0)
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_245; lean_object* x_246; lean_object* x_247; lean_object* x_248; 
x_245 = lean_ctor_get(x_2, 1);
lean_inc(x_245);
lean_dec_ref(x_2);
x_246 = lean_ctor_get(x_87, 0);
lean_inc(x_246);
x_247 = lean_ctor_get(x_87, 1);
lean_inc(x_247);
x_248 = lean_ctor_get(x_87, 2);
lean_inc(x_248);
lean_dec_ref(x_87);
x_5 = x_4;
x_6 = x_245;
x_7 = x_246;
x_8 = x_247;
x_9 = x_248;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_249; 
x_249 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_249 == 0)
{
lean_object* x_250; 
x_250 = lean_ctor_get(x_4, 0);
lean_inc(x_250);
if (lean_obj_tag(x_250) == 0)
{
lean_object* x_251; 
x_251 = lean_ctor_get(x_4, 2);
if (lean_obj_tag(x_251) == 0)
{
lean_object* x_252; lean_object* x_253; lean_object* x_254; lean_object* x_255; uint8_t x_256; 
lean_inc(x_251);
x_252 = lean_ctor_get(x_2, 1);
lean_inc(x_252);
lean_dec_ref(x_2);
x_253 = lean_ctor_get(x_87, 0);
lean_inc(x_253);
x_254 = lean_ctor_get(x_87, 1);
lean_inc(x_254);
x_255 = lean_ctor_get(x_87, 2);
lean_inc(x_255);
lean_dec_ref(x_87);
x_256 = !lean_is_exclusive(x_4);
if (x_256 == 0)
{
lean_object* x_257; lean_object* x_258; 
x_257 = lean_ctor_get(x_4, 2);
lean_dec(x_257);
x_258 = lean_ctor_get(x_4, 0);
lean_dec(x_258);
lean_ctor_set(x_4, 0, x_251);
x_5 = x_251;
x_6 = x_252;
x_7 = x_253;
x_8 = x_254;
x_9 = x_255;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_259; lean_object* x_260; 
x_259 = lean_ctor_get(x_4, 1);
lean_inc(x_259);
lean_dec(x_4);
x_260 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_260, 0, x_251);
lean_ctor_set(x_260, 1, x_259);
lean_ctor_set(x_260, 2, x_251);
lean_ctor_set_uint8(x_260, sizeof(void*)*3, x_249);
x_5 = x_251;
x_6 = x_252;
x_7 = x_253;
x_8 = x_254;
x_9 = x_255;
x_10 = x_3;
x_11 = x_260;
goto block_16;
}
}
else
{
uint8_t x_261; 
x_261 = lean_ctor_get_uint8(x_251, sizeof(void*)*3);
if (x_261 == 0)
{
lean_object* x_262; lean_object* x_263; lean_object* x_264; lean_object* x_265; uint8_t x_266; 
lean_inc_ref(x_251);
x_262 = lean_ctor_get(x_2, 1);
lean_inc(x_262);
lean_dec_ref(x_2);
x_263 = lean_ctor_get(x_87, 0);
lean_inc(x_263);
x_264 = lean_ctor_get(x_87, 1);
lean_inc(x_264);
x_265 = lean_ctor_get(x_87, 2);
lean_inc(x_265);
lean_dec_ref(x_87);
x_266 = !lean_is_exclusive(x_4);
if (x_266 == 0)
{
lean_object* x_267; lean_object* x_268; 
x_267 = lean_ctor_get(x_4, 2);
lean_dec(x_267);
x_268 = lean_ctor_get(x_4, 0);
lean_dec(x_268);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_261);
x_5 = x_250;
x_6 = x_262;
x_7 = x_263;
x_8 = x_264;
x_9 = x_265;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_269; lean_object* x_270; 
x_269 = lean_ctor_get(x_4, 1);
lean_inc(x_269);
lean_dec(x_4);
x_270 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_270, 0, x_250);
lean_ctor_set(x_270, 1, x_269);
lean_ctor_set(x_270, 2, x_251);
lean_ctor_set_uint8(x_270, sizeof(void*)*3, x_261);
x_5 = x_250;
x_6 = x_262;
x_7 = x_263;
x_8 = x_264;
x_9 = x_265;
x_10 = x_3;
x_11 = x_270;
goto block_16;
}
}
else
{
lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; 
x_271 = lean_ctor_get(x_2, 1);
lean_inc(x_271);
lean_dec_ref(x_2);
x_272 = lean_ctor_get(x_87, 0);
lean_inc(x_272);
x_273 = lean_ctor_get(x_87, 1);
lean_inc(x_273);
x_274 = lean_ctor_get(x_87, 2);
lean_inc(x_274);
lean_dec_ref(x_87);
x_5 = x_250;
x_6 = x_271;
x_7 = x_272;
x_8 = x_273;
x_9 = x_274;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
else
{
uint8_t x_275; 
x_275 = lean_ctor_get_uint8(x_250, sizeof(void*)*3);
if (x_275 == 0)
{
lean_object* x_276; 
x_276 = lean_ctor_get(x_4, 2);
lean_inc(x_276);
if (lean_obj_tag(x_276) == 0)
{
lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; uint8_t x_281; 
x_277 = lean_ctor_get(x_2, 1);
lean_inc(x_277);
lean_dec_ref(x_2);
x_278 = lean_ctor_get(x_87, 0);
lean_inc(x_278);
x_279 = lean_ctor_get(x_87, 1);
lean_inc(x_279);
x_280 = lean_ctor_get(x_87, 2);
lean_inc(x_280);
lean_dec_ref(x_87);
x_281 = !lean_is_exclusive(x_4);
if (x_281 == 0)
{
lean_object* x_282; lean_object* x_283; 
x_282 = lean_ctor_get(x_4, 2);
lean_dec(x_282);
x_283 = lean_ctor_get(x_4, 0);
lean_dec(x_283);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_275);
x_5 = x_276;
x_6 = x_277;
x_7 = x_278;
x_8 = x_279;
x_9 = x_280;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_284; lean_object* x_285; 
x_284 = lean_ctor_get(x_4, 1);
lean_inc(x_284);
lean_dec(x_4);
x_285 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_285, 0, x_250);
lean_ctor_set(x_285, 1, x_284);
lean_ctor_set(x_285, 2, x_276);
lean_ctor_set_uint8(x_285, sizeof(void*)*3, x_275);
x_5 = x_276;
x_6 = x_277;
x_7 = x_278;
x_8 = x_279;
x_9 = x_280;
x_10 = x_3;
x_11 = x_285;
goto block_16;
}
}
else
{
uint8_t x_286; 
x_286 = lean_ctor_get_uint8(x_276, sizeof(void*)*3);
if (x_286 == 0)
{
lean_object* x_287; lean_object* x_288; lean_object* x_289; lean_object* x_290; uint8_t x_291; 
x_287 = lean_ctor_get(x_2, 1);
lean_inc(x_287);
lean_dec_ref(x_2);
x_288 = lean_ctor_get(x_87, 0);
lean_inc(x_288);
x_289 = lean_ctor_get(x_87, 1);
lean_inc(x_289);
x_290 = lean_ctor_get(x_87, 2);
lean_inc(x_290);
lean_dec_ref(x_87);
x_291 = !lean_is_exclusive(x_4);
if (x_291 == 0)
{
lean_object* x_292; lean_object* x_293; uint8_t x_294; 
x_292 = lean_ctor_get(x_4, 2);
lean_dec(x_292);
x_293 = lean_ctor_get(x_4, 0);
lean_dec(x_293);
x_294 = !lean_is_exclusive(x_250);
if (x_294 == 0)
{
lean_ctor_set_uint8(x_250, sizeof(void*)*3, x_286);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_286);
x_5 = x_86;
x_6 = x_287;
x_7 = x_288;
x_8 = x_289;
x_9 = x_290;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; 
x_295 = lean_ctor_get(x_250, 0);
x_296 = lean_ctor_get(x_250, 1);
x_297 = lean_ctor_get(x_250, 2);
lean_inc(x_297);
lean_inc(x_296);
lean_inc(x_295);
lean_dec(x_250);
x_298 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_298, 0, x_295);
lean_ctor_set(x_298, 1, x_296);
lean_ctor_set(x_298, 2, x_297);
lean_ctor_set_uint8(x_298, sizeof(void*)*3, x_286);
lean_ctor_set(x_4, 0, x_298);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_286);
x_5 = x_86;
x_6 = x_287;
x_7 = x_288;
x_8 = x_289;
x_9 = x_290;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_299; lean_object* x_300; lean_object* x_301; lean_object* x_302; lean_object* x_303; lean_object* x_304; lean_object* x_305; 
x_299 = lean_ctor_get(x_4, 1);
lean_inc(x_299);
lean_dec(x_4);
x_300 = lean_ctor_get(x_250, 0);
lean_inc(x_300);
x_301 = lean_ctor_get(x_250, 1);
lean_inc(x_301);
x_302 = lean_ctor_get(x_250, 2);
lean_inc(x_302);
if (lean_is_exclusive(x_250)) {
 lean_ctor_release(x_250, 0);
 lean_ctor_release(x_250, 1);
 lean_ctor_release(x_250, 2);
 x_303 = x_250;
} else {
 lean_dec_ref(x_250);
 x_303 = lean_box(0);
}
if (lean_is_scalar(x_303)) {
 x_304 = lean_alloc_ctor(1, 3, 1);
} else {
 x_304 = x_303;
}
lean_ctor_set(x_304, 0, x_300);
lean_ctor_set(x_304, 1, x_301);
lean_ctor_set(x_304, 2, x_302);
lean_ctor_set_uint8(x_304, sizeof(void*)*3, x_286);
x_305 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_305, 0, x_304);
lean_ctor_set(x_305, 1, x_299);
lean_ctor_set(x_305, 2, x_276);
lean_ctor_set_uint8(x_305, sizeof(void*)*3, x_286);
x_5 = x_86;
x_6 = x_287;
x_7 = x_288;
x_8 = x_289;
x_9 = x_290;
x_10 = x_3;
x_11 = x_305;
goto block_16;
}
}
else
{
lean_object* x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; uint8_t x_310; 
x_306 = lean_ctor_get(x_2, 1);
lean_inc(x_306);
lean_dec_ref(x_2);
x_307 = lean_ctor_get(x_87, 0);
lean_inc(x_307);
x_308 = lean_ctor_get(x_87, 1);
lean_inc(x_308);
x_309 = lean_ctor_get(x_87, 2);
lean_inc(x_309);
lean_dec_ref(x_87);
x_310 = !lean_is_exclusive(x_4);
if (x_310 == 0)
{
lean_object* x_311; lean_object* x_312; 
x_311 = lean_ctor_get(x_4, 2);
lean_dec(x_311);
x_312 = lean_ctor_get(x_4, 0);
lean_dec(x_312);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_275);
x_5 = x_86;
x_6 = x_306;
x_7 = x_307;
x_8 = x_308;
x_9 = x_309;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_313; lean_object* x_314; 
x_313 = lean_ctor_get(x_4, 1);
lean_inc(x_313);
lean_dec(x_4);
x_314 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_314, 0, x_250);
lean_ctor_set(x_314, 1, x_313);
lean_ctor_set(x_314, 2, x_276);
lean_ctor_set_uint8(x_314, sizeof(void*)*3, x_275);
x_5 = x_86;
x_6 = x_306;
x_7 = x_307;
x_8 = x_308;
x_9 = x_309;
x_10 = x_3;
x_11 = x_314;
goto block_16;
}
}
}
}
else
{
lean_object* x_315; 
x_315 = lean_ctor_get(x_4, 2);
lean_inc(x_315);
if (lean_obj_tag(x_315) == 0)
{
lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_319; 
lean_dec_ref(x_250);
x_316 = lean_ctor_get(x_2, 1);
lean_inc(x_316);
lean_dec_ref(x_2);
x_317 = lean_ctor_get(x_87, 0);
lean_inc(x_317);
x_318 = lean_ctor_get(x_87, 1);
lean_inc(x_318);
x_319 = lean_ctor_get(x_87, 2);
lean_inc(x_319);
lean_dec_ref(x_87);
x_5 = x_315;
x_6 = x_316;
x_7 = x_317;
x_8 = x_318;
x_9 = x_319;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_320; 
x_320 = lean_ctor_get_uint8(x_315, sizeof(void*)*3);
if (x_320 == 0)
{
lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; uint8_t x_325; 
x_321 = lean_ctor_get(x_2, 1);
lean_inc(x_321);
lean_dec_ref(x_2);
x_322 = lean_ctor_get(x_87, 0);
lean_inc(x_322);
x_323 = lean_ctor_get(x_87, 1);
lean_inc(x_323);
x_324 = lean_ctor_get(x_87, 2);
lean_inc(x_324);
lean_dec_ref(x_87);
x_325 = !lean_is_exclusive(x_4);
if (x_325 == 0)
{
lean_object* x_326; lean_object* x_327; 
x_326 = lean_ctor_get(x_4, 2);
lean_dec(x_326);
x_327 = lean_ctor_get(x_4, 0);
lean_dec(x_327);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_320);
x_5 = x_86;
x_6 = x_321;
x_7 = x_322;
x_8 = x_323;
x_9 = x_324;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_328; lean_object* x_329; 
x_328 = lean_ctor_get(x_4, 1);
lean_inc(x_328);
lean_dec(x_4);
x_329 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_329, 0, x_250);
lean_ctor_set(x_329, 1, x_328);
lean_ctor_set(x_329, 2, x_315);
lean_ctor_set_uint8(x_329, sizeof(void*)*3, x_320);
x_5 = x_86;
x_6 = x_321;
x_7 = x_322;
x_8 = x_323;
x_9 = x_324;
x_10 = x_3;
x_11 = x_329;
goto block_16;
}
}
else
{
lean_object* x_330; lean_object* x_331; lean_object* x_332; lean_object* x_333; uint8_t x_334; 
x_330 = lean_ctor_get(x_2, 1);
lean_inc(x_330);
lean_dec_ref(x_2);
x_331 = lean_ctor_get(x_87, 0);
lean_inc(x_331);
x_332 = lean_ctor_get(x_87, 1);
lean_inc(x_332);
x_333 = lean_ctor_get(x_87, 2);
lean_inc(x_333);
lean_dec_ref(x_87);
x_334 = !lean_is_exclusive(x_4);
if (x_334 == 0)
{
lean_object* x_335; lean_object* x_336; uint8_t x_337; 
x_335 = lean_ctor_get(x_4, 2);
lean_dec(x_335);
x_336 = lean_ctor_get(x_4, 0);
lean_dec(x_336);
x_337 = !lean_is_exclusive(x_250);
if (x_337 == 0)
{
lean_ctor_set_uint8(x_250, sizeof(void*)*3, x_320);
x_5 = x_86;
x_6 = x_330;
x_7 = x_331;
x_8 = x_332;
x_9 = x_333;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; 
x_338 = lean_ctor_get(x_250, 0);
x_339 = lean_ctor_get(x_250, 1);
x_340 = lean_ctor_get(x_250, 2);
lean_inc(x_340);
lean_inc(x_339);
lean_inc(x_338);
lean_dec(x_250);
x_341 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_341, 0, x_338);
lean_ctor_set(x_341, 1, x_339);
lean_ctor_set(x_341, 2, x_340);
lean_ctor_set_uint8(x_341, sizeof(void*)*3, x_320);
lean_ctor_set(x_4, 0, x_341);
x_5 = x_86;
x_6 = x_330;
x_7 = x_331;
x_8 = x_332;
x_9 = x_333;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; 
x_342 = lean_ctor_get(x_4, 1);
lean_inc(x_342);
lean_dec(x_4);
x_343 = lean_ctor_get(x_250, 0);
lean_inc(x_343);
x_344 = lean_ctor_get(x_250, 1);
lean_inc(x_344);
x_345 = lean_ctor_get(x_250, 2);
lean_inc(x_345);
if (lean_is_exclusive(x_250)) {
 lean_ctor_release(x_250, 0);
 lean_ctor_release(x_250, 1);
 lean_ctor_release(x_250, 2);
 x_346 = x_250;
} else {
 lean_dec_ref(x_250);
 x_346 = lean_box(0);
}
if (lean_is_scalar(x_346)) {
 x_347 = lean_alloc_ctor(1, 3, 1);
} else {
 x_347 = x_346;
}
lean_ctor_set(x_347, 0, x_343);
lean_ctor_set(x_347, 1, x_344);
lean_ctor_set(x_347, 2, x_345);
lean_ctor_set_uint8(x_347, sizeof(void*)*3, x_320);
x_348 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_348, 0, x_347);
lean_ctor_set(x_348, 1, x_342);
lean_ctor_set(x_348, 2, x_315);
lean_ctor_set_uint8(x_348, sizeof(void*)*3, x_249);
x_5 = x_86;
x_6 = x_330;
x_7 = x_331;
x_8 = x_332;
x_9 = x_333;
x_10 = x_3;
x_11 = x_348;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_349; lean_object* x_350; lean_object* x_351; lean_object* x_352; 
x_349 = lean_ctor_get(x_2, 1);
lean_inc(x_349);
lean_dec_ref(x_2);
x_350 = lean_ctor_get(x_87, 0);
lean_inc(x_350);
x_351 = lean_ctor_get(x_87, 1);
lean_inc(x_351);
x_352 = lean_ctor_get(x_87, 2);
lean_inc(x_352);
lean_dec_ref(x_87);
x_5 = x_86;
x_6 = x_349;
x_7 = x_350;
x_8 = x_351;
x_9 = x_352;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
else
{
if (lean_obj_tag(x_4) == 0)
{
uint8_t x_353; 
x_353 = !lean_is_exclusive(x_2);
if (x_353 == 0)
{
lean_object* x_354; lean_object* x_355; lean_object* x_356; 
x_354 = lean_ctor_get(x_2, 2);
lean_dec(x_354);
x_355 = lean_ctor_get(x_2, 0);
lean_dec(x_355);
lean_ctor_set(x_2, 0, x_4);
x_356 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_356, 0, x_2);
lean_ctor_set(x_356, 1, x_3);
lean_ctor_set(x_356, 2, x_4);
lean_ctor_set_uint8(x_356, sizeof(void*)*3, x_244);
return x_356;
}
else
{
lean_object* x_357; lean_object* x_358; lean_object* x_359; 
x_357 = lean_ctor_get(x_2, 1);
lean_inc(x_357);
lean_dec(x_2);
x_358 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_358, 0, x_4);
lean_ctor_set(x_358, 1, x_357);
lean_ctor_set(x_358, 2, x_87);
lean_ctor_set_uint8(x_358, sizeof(void*)*3, x_85);
x_359 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_359, 0, x_358);
lean_ctor_set(x_359, 1, x_3);
lean_ctor_set(x_359, 2, x_4);
lean_ctor_set_uint8(x_359, sizeof(void*)*3, x_244);
return x_359;
}
}
else
{
uint8_t x_360; 
x_360 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_360 == 0)
{
lean_object* x_361; 
x_361 = lean_ctor_get(x_4, 0);
lean_inc(x_361);
if (lean_obj_tag(x_361) == 0)
{
lean_object* x_362; 
x_362 = lean_ctor_get(x_4, 2);
lean_inc(x_362);
if (lean_obj_tag(x_362) == 0)
{
uint8_t x_363; 
x_363 = !lean_is_exclusive(x_2);
if (x_363 == 0)
{
lean_object* x_364; lean_object* x_365; lean_object* x_366; uint8_t x_367; 
x_364 = lean_ctor_get(x_2, 1);
x_365 = lean_ctor_get(x_2, 2);
lean_dec(x_365);
x_366 = lean_ctor_get(x_2, 0);
lean_dec(x_366);
x_367 = !lean_is_exclusive(x_4);
if (x_367 == 0)
{
lean_object* x_368; lean_object* x_369; lean_object* x_370; uint8_t x_371; 
x_368 = lean_ctor_get(x_4, 1);
x_369 = lean_ctor_get(x_4, 2);
lean_dec(x_369);
x_370 = lean_ctor_get(x_4, 0);
lean_dec(x_370);
lean_inc_ref(x_87);
lean_ctor_set(x_4, 2, x_87);
lean_ctor_set(x_4, 1, x_364);
lean_ctor_set(x_4, 0, x_362);
x_371 = !lean_is_exclusive(x_87);
if (x_371 == 0)
{
lean_object* x_372; lean_object* x_373; lean_object* x_374; 
x_372 = lean_ctor_get(x_87, 2);
lean_dec(x_372);
x_373 = lean_ctor_get(x_87, 1);
lean_dec(x_373);
x_374 = lean_ctor_get(x_87, 0);
lean_dec(x_374);
lean_ctor_set(x_87, 2, x_362);
lean_ctor_set(x_87, 1, x_368);
lean_ctor_set(x_87, 0, x_362);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_244);
return x_2;
}
else
{
lean_object* x_375; 
lean_dec(x_87);
x_375 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_375, 0, x_362);
lean_ctor_set(x_375, 1, x_368);
lean_ctor_set(x_375, 2, x_362);
lean_ctor_set_uint8(x_375, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_375);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_244);
return x_2;
}
}
else
{
lean_object* x_376; lean_object* x_377; lean_object* x_378; lean_object* x_379; 
x_376 = lean_ctor_get(x_4, 1);
lean_inc(x_376);
lean_dec(x_4);
lean_inc_ref(x_87);
x_377 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_377, 0, x_362);
lean_ctor_set(x_377, 1, x_364);
lean_ctor_set(x_377, 2, x_87);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_378 = x_87;
} else {
 lean_dec_ref(x_87);
 x_378 = lean_box(0);
}
lean_ctor_set_uint8(x_377, sizeof(void*)*3, x_360);
if (lean_is_scalar(x_378)) {
 x_379 = lean_alloc_ctor(1, 3, 1);
} else {
 x_379 = x_378;
}
lean_ctor_set(x_379, 0, x_362);
lean_ctor_set(x_379, 1, x_376);
lean_ctor_set(x_379, 2, x_362);
lean_ctor_set_uint8(x_379, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_379);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_377);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_244);
return x_2;
}
}
else
{
lean_object* x_380; lean_object* x_381; lean_object* x_382; lean_object* x_383; lean_object* x_384; lean_object* x_385; lean_object* x_386; 
x_380 = lean_ctor_get(x_2, 1);
lean_inc(x_380);
lean_dec(x_2);
x_381 = lean_ctor_get(x_4, 1);
lean_inc(x_381);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_382 = x_4;
} else {
 lean_dec_ref(x_4);
 x_382 = lean_box(0);
}
lean_inc_ref(x_87);
if (lean_is_scalar(x_382)) {
 x_383 = lean_alloc_ctor(1, 3, 1);
} else {
 x_383 = x_382;
}
lean_ctor_set(x_383, 0, x_362);
lean_ctor_set(x_383, 1, x_380);
lean_ctor_set(x_383, 2, x_87);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_384 = x_87;
} else {
 lean_dec_ref(x_87);
 x_384 = lean_box(0);
}
lean_ctor_set_uint8(x_383, sizeof(void*)*3, x_360);
if (lean_is_scalar(x_384)) {
 x_385 = lean_alloc_ctor(1, 3, 1);
} else {
 x_385 = x_384;
}
lean_ctor_set(x_385, 0, x_362);
lean_ctor_set(x_385, 1, x_381);
lean_ctor_set(x_385, 2, x_362);
lean_ctor_set_uint8(x_385, sizeof(void*)*3, x_360);
x_386 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_386, 0, x_383);
lean_ctor_set(x_386, 1, x_3);
lean_ctor_set(x_386, 2, x_385);
lean_ctor_set_uint8(x_386, sizeof(void*)*3, x_244);
return x_386;
}
}
else
{
uint8_t x_387; 
x_387 = lean_ctor_get_uint8(x_362, sizeof(void*)*3);
if (x_387 == 0)
{
lean_object* x_388; lean_object* x_389; uint8_t x_390; 
x_388 = lean_ctor_get(x_2, 1);
lean_inc(x_388);
lean_dec_ref(x_2);
x_389 = lean_ctor_get(x_4, 1);
lean_inc(x_389);
lean_dec_ref(x_4);
x_390 = !lean_is_exclusive(x_362);
if (x_390 == 0)
{
lean_object* x_391; lean_object* x_392; lean_object* x_393; 
x_391 = lean_ctor_get(x_362, 0);
x_392 = lean_ctor_get(x_362, 1);
x_393 = lean_ctor_get(x_362, 2);
lean_ctor_set(x_362, 2, x_87);
lean_ctor_set(x_362, 1, x_388);
lean_ctor_set(x_362, 0, x_361);
x_5 = x_362;
x_6 = x_3;
x_7 = x_361;
x_8 = x_389;
x_9 = x_391;
x_10 = x_392;
x_11 = x_393;
goto block_16;
}
else
{
lean_object* x_394; lean_object* x_395; lean_object* x_396; lean_object* x_397; 
x_394 = lean_ctor_get(x_362, 0);
x_395 = lean_ctor_get(x_362, 1);
x_396 = lean_ctor_get(x_362, 2);
lean_inc(x_396);
lean_inc(x_395);
lean_inc(x_394);
lean_dec(x_362);
x_397 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_397, 0, x_361);
lean_ctor_set(x_397, 1, x_388);
lean_ctor_set(x_397, 2, x_87);
lean_ctor_set_uint8(x_397, sizeof(void*)*3, x_387);
x_5 = x_397;
x_6 = x_3;
x_7 = x_361;
x_8 = x_389;
x_9 = x_394;
x_10 = x_395;
x_11 = x_396;
goto block_16;
}
}
else
{
uint8_t x_398; 
x_398 = !lean_is_exclusive(x_362);
if (x_398 == 0)
{
lean_object* x_399; lean_object* x_400; lean_object* x_401; uint8_t x_402; 
x_399 = lean_ctor_get(x_362, 2);
lean_dec(x_399);
x_400 = lean_ctor_get(x_362, 1);
lean_dec(x_400);
x_401 = lean_ctor_get(x_362, 0);
lean_dec(x_401);
x_402 = !lean_is_exclusive(x_2);
if (x_402 == 0)
{
lean_object* x_403; lean_object* x_404; lean_object* x_405; uint8_t x_406; 
x_403 = lean_ctor_get(x_2, 1);
x_404 = lean_ctor_get(x_2, 2);
lean_dec(x_404);
x_405 = lean_ctor_get(x_2, 0);
lean_dec(x_405);
x_406 = !lean_is_exclusive(x_87);
if (x_406 == 0)
{
lean_object* x_407; lean_object* x_408; lean_object* x_409; 
x_407 = lean_ctor_get(x_87, 0);
x_408 = lean_ctor_get(x_87, 1);
x_409 = lean_ctor_get(x_87, 2);
lean_ctor_set(x_362, 2, x_409);
lean_ctor_set(x_362, 1, x_408);
lean_ctor_set(x_362, 0, x_407);
lean_ctor_set(x_87, 2, x_362);
lean_ctor_set(x_87, 1, x_403);
lean_ctor_set(x_87, 0, x_361);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_87);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_387);
return x_2;
}
else
{
lean_object* x_410; lean_object* x_411; lean_object* x_412; lean_object* x_413; 
x_410 = lean_ctor_get(x_87, 0);
x_411 = lean_ctor_get(x_87, 1);
x_412 = lean_ctor_get(x_87, 2);
lean_inc(x_412);
lean_inc(x_411);
lean_inc(x_410);
lean_dec(x_87);
lean_ctor_set(x_362, 2, x_412);
lean_ctor_set(x_362, 1, x_411);
lean_ctor_set(x_362, 0, x_410);
x_413 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_413, 0, x_361);
lean_ctor_set(x_413, 1, x_403);
lean_ctor_set(x_413, 2, x_362);
lean_ctor_set_uint8(x_413, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_413);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_387);
return x_2;
}
}
else
{
lean_object* x_414; lean_object* x_415; lean_object* x_416; lean_object* x_417; lean_object* x_418; lean_object* x_419; lean_object* x_420; 
x_414 = lean_ctor_get(x_2, 1);
lean_inc(x_414);
lean_dec(x_2);
x_415 = lean_ctor_get(x_87, 0);
lean_inc(x_415);
x_416 = lean_ctor_get(x_87, 1);
lean_inc(x_416);
x_417 = lean_ctor_get(x_87, 2);
lean_inc(x_417);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_418 = x_87;
} else {
 lean_dec_ref(x_87);
 x_418 = lean_box(0);
}
lean_ctor_set(x_362, 2, x_417);
lean_ctor_set(x_362, 1, x_416);
lean_ctor_set(x_362, 0, x_415);
if (lean_is_scalar(x_418)) {
 x_419 = lean_alloc_ctor(1, 3, 1);
} else {
 x_419 = x_418;
}
lean_ctor_set(x_419, 0, x_361);
lean_ctor_set(x_419, 1, x_414);
lean_ctor_set(x_419, 2, x_362);
lean_ctor_set_uint8(x_419, sizeof(void*)*3, x_360);
x_420 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_420, 0, x_419);
lean_ctor_set(x_420, 1, x_3);
lean_ctor_set(x_420, 2, x_4);
lean_ctor_set_uint8(x_420, sizeof(void*)*3, x_387);
return x_420;
}
}
else
{
lean_object* x_421; lean_object* x_422; lean_object* x_423; lean_object* x_424; lean_object* x_425; lean_object* x_426; lean_object* x_427; lean_object* x_428; lean_object* x_429; 
lean_dec(x_362);
x_421 = lean_ctor_get(x_2, 1);
lean_inc(x_421);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_422 = x_2;
} else {
 lean_dec_ref(x_2);
 x_422 = lean_box(0);
}
x_423 = lean_ctor_get(x_87, 0);
lean_inc(x_423);
x_424 = lean_ctor_get(x_87, 1);
lean_inc(x_424);
x_425 = lean_ctor_get(x_87, 2);
lean_inc(x_425);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_426 = x_87;
} else {
 lean_dec_ref(x_87);
 x_426 = lean_box(0);
}
x_427 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_427, 0, x_423);
lean_ctor_set(x_427, 1, x_424);
lean_ctor_set(x_427, 2, x_425);
lean_ctor_set_uint8(x_427, sizeof(void*)*3, x_387);
if (lean_is_scalar(x_426)) {
 x_428 = lean_alloc_ctor(1, 3, 1);
} else {
 x_428 = x_426;
}
lean_ctor_set(x_428, 0, x_361);
lean_ctor_set(x_428, 1, x_421);
lean_ctor_set(x_428, 2, x_427);
lean_ctor_set_uint8(x_428, sizeof(void*)*3, x_360);
if (lean_is_scalar(x_422)) {
 x_429 = lean_alloc_ctor(1, 3, 1);
} else {
 x_429 = x_422;
}
lean_ctor_set(x_429, 0, x_428);
lean_ctor_set(x_429, 1, x_3);
lean_ctor_set(x_429, 2, x_4);
lean_ctor_set_uint8(x_429, sizeof(void*)*3, x_387);
return x_429;
}
}
}
}
else
{
uint8_t x_430; 
x_430 = lean_ctor_get_uint8(x_361, sizeof(void*)*3);
if (x_430 == 0)
{
lean_object* x_431; 
x_431 = lean_ctor_get(x_4, 2);
lean_inc(x_431);
if (lean_obj_tag(x_431) == 0)
{
lean_object* x_432; lean_object* x_433; uint8_t x_434; 
x_432 = lean_ctor_get(x_2, 1);
lean_inc(x_432);
lean_dec_ref(x_2);
x_433 = lean_ctor_get(x_4, 1);
lean_inc(x_433);
lean_dec_ref(x_4);
x_434 = !lean_is_exclusive(x_361);
if (x_434 == 0)
{
lean_object* x_435; lean_object* x_436; lean_object* x_437; 
x_435 = lean_ctor_get(x_361, 0);
x_436 = lean_ctor_get(x_361, 1);
x_437 = lean_ctor_get(x_361, 2);
lean_ctor_set(x_361, 2, x_87);
lean_ctor_set(x_361, 1, x_432);
lean_ctor_set(x_361, 0, x_431);
x_5 = x_361;
x_6 = x_3;
x_7 = x_435;
x_8 = x_436;
x_9 = x_437;
x_10 = x_433;
x_11 = x_431;
goto block_16;
}
else
{
lean_object* x_438; lean_object* x_439; lean_object* x_440; lean_object* x_441; 
x_438 = lean_ctor_get(x_361, 0);
x_439 = lean_ctor_get(x_361, 1);
x_440 = lean_ctor_get(x_361, 2);
lean_inc(x_440);
lean_inc(x_439);
lean_inc(x_438);
lean_dec(x_361);
x_441 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_441, 0, x_431);
lean_ctor_set(x_441, 1, x_432);
lean_ctor_set(x_441, 2, x_87);
lean_ctor_set_uint8(x_441, sizeof(void*)*3, x_430);
x_5 = x_441;
x_6 = x_3;
x_7 = x_438;
x_8 = x_439;
x_9 = x_440;
x_10 = x_433;
x_11 = x_431;
goto block_16;
}
}
else
{
uint8_t x_442; 
x_442 = lean_ctor_get_uint8(x_431, sizeof(void*)*3);
if (x_442 == 0)
{
lean_object* x_443; lean_object* x_444; uint8_t x_445; 
x_443 = lean_ctor_get(x_2, 1);
lean_inc(x_443);
lean_dec_ref(x_2);
x_444 = lean_ctor_get(x_4, 1);
lean_inc(x_444);
lean_dec_ref(x_4);
x_445 = !lean_is_exclusive(x_361);
if (x_445 == 0)
{
lean_object* x_446; lean_object* x_447; lean_object* x_448; 
x_446 = lean_ctor_get(x_361, 0);
x_447 = lean_ctor_get(x_361, 1);
x_448 = lean_ctor_get(x_361, 2);
lean_ctor_set(x_361, 2, x_87);
lean_ctor_set(x_361, 1, x_443);
lean_ctor_set(x_361, 0, x_86);
lean_ctor_set_uint8(x_361, sizeof(void*)*3, x_442);
x_5 = x_361;
x_6 = x_3;
x_7 = x_446;
x_8 = x_447;
x_9 = x_448;
x_10 = x_444;
x_11 = x_431;
goto block_16;
}
else
{
lean_object* x_449; lean_object* x_450; lean_object* x_451; lean_object* x_452; 
x_449 = lean_ctor_get(x_361, 0);
x_450 = lean_ctor_get(x_361, 1);
x_451 = lean_ctor_get(x_361, 2);
lean_inc(x_451);
lean_inc(x_450);
lean_inc(x_449);
lean_dec(x_361);
x_452 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_452, 0, x_86);
lean_ctor_set(x_452, 1, x_443);
lean_ctor_set(x_452, 2, x_87);
lean_ctor_set_uint8(x_452, sizeof(void*)*3, x_442);
x_5 = x_452;
x_6 = x_3;
x_7 = x_449;
x_8 = x_450;
x_9 = x_451;
x_10 = x_444;
x_11 = x_431;
goto block_16;
}
}
else
{
lean_object* x_453; lean_object* x_454; lean_object* x_455; lean_object* x_456; uint8_t x_457; 
x_453 = lean_ctor_get(x_2, 1);
lean_inc(x_453);
lean_dec_ref(x_2);
x_454 = lean_ctor_get(x_87, 0);
lean_inc(x_454);
x_455 = lean_ctor_get(x_87, 1);
lean_inc(x_455);
x_456 = lean_ctor_get(x_87, 2);
lean_inc(x_456);
lean_dec_ref(x_87);
x_457 = !lean_is_exclusive(x_4);
if (x_457 == 0)
{
lean_object* x_458; lean_object* x_459; lean_object* x_460; uint8_t x_461; 
x_458 = lean_ctor_get(x_4, 1);
x_459 = lean_ctor_get(x_4, 2);
lean_dec(x_459);
x_460 = lean_ctor_get(x_4, 0);
lean_dec(x_460);
x_461 = !lean_is_exclusive(x_361);
if (x_461 == 0)
{
lean_object* x_462; lean_object* x_463; lean_object* x_464; 
x_462 = lean_ctor_get(x_361, 0);
x_463 = lean_ctor_get(x_361, 1);
x_464 = lean_ctor_get(x_361, 2);
lean_ctor_set(x_361, 2, x_456);
lean_ctor_set(x_361, 1, x_455);
lean_ctor_set(x_361, 0, x_454);
lean_ctor_set_uint8(x_361, sizeof(void*)*3, x_442);
lean_ctor_set(x_4, 2, x_361);
lean_ctor_set(x_4, 1, x_453);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_430);
x_5 = x_4;
x_6 = x_3;
x_7 = x_462;
x_8 = x_463;
x_9 = x_464;
x_10 = x_458;
x_11 = x_431;
goto block_16;
}
else
{
lean_object* x_465; lean_object* x_466; lean_object* x_467; lean_object* x_468; 
x_465 = lean_ctor_get(x_361, 0);
x_466 = lean_ctor_get(x_361, 1);
x_467 = lean_ctor_get(x_361, 2);
lean_inc(x_467);
lean_inc(x_466);
lean_inc(x_465);
lean_dec(x_361);
x_468 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_468, 0, x_454);
lean_ctor_set(x_468, 1, x_455);
lean_ctor_set(x_468, 2, x_456);
lean_ctor_set_uint8(x_468, sizeof(void*)*3, x_442);
lean_ctor_set(x_4, 2, x_468);
lean_ctor_set(x_4, 1, x_453);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_430);
x_5 = x_4;
x_6 = x_3;
x_7 = x_465;
x_8 = x_466;
x_9 = x_467;
x_10 = x_458;
x_11 = x_431;
goto block_16;
}
}
else
{
lean_object* x_469; lean_object* x_470; lean_object* x_471; lean_object* x_472; lean_object* x_473; lean_object* x_474; lean_object* x_475; 
x_469 = lean_ctor_get(x_4, 1);
lean_inc(x_469);
lean_dec(x_4);
x_470 = lean_ctor_get(x_361, 0);
lean_inc(x_470);
x_471 = lean_ctor_get(x_361, 1);
lean_inc(x_471);
x_472 = lean_ctor_get(x_361, 2);
lean_inc(x_472);
if (lean_is_exclusive(x_361)) {
 lean_ctor_release(x_361, 0);
 lean_ctor_release(x_361, 1);
 lean_ctor_release(x_361, 2);
 x_473 = x_361;
} else {
 lean_dec_ref(x_361);
 x_473 = lean_box(0);
}
if (lean_is_scalar(x_473)) {
 x_474 = lean_alloc_ctor(1, 3, 1);
} else {
 x_474 = x_473;
}
lean_ctor_set(x_474, 0, x_454);
lean_ctor_set(x_474, 1, x_455);
lean_ctor_set(x_474, 2, x_456);
lean_ctor_set_uint8(x_474, sizeof(void*)*3, x_442);
x_475 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_475, 0, x_86);
lean_ctor_set(x_475, 1, x_453);
lean_ctor_set(x_475, 2, x_474);
lean_ctor_set_uint8(x_475, sizeof(void*)*3, x_430);
x_5 = x_475;
x_6 = x_3;
x_7 = x_470;
x_8 = x_471;
x_9 = x_472;
x_10 = x_469;
x_11 = x_431;
goto block_16;
}
}
}
}
else
{
lean_object* x_476; 
x_476 = lean_ctor_get(x_4, 2);
lean_inc(x_476);
if (lean_obj_tag(x_476) == 0)
{
uint8_t x_477; 
x_477 = !lean_is_exclusive(x_361);
if (x_477 == 0)
{
lean_object* x_478; lean_object* x_479; lean_object* x_480; uint8_t x_481; 
x_478 = lean_ctor_get(x_361, 2);
lean_dec(x_478);
x_479 = lean_ctor_get(x_361, 1);
lean_dec(x_479);
x_480 = lean_ctor_get(x_361, 0);
lean_dec(x_480);
x_481 = !lean_is_exclusive(x_2);
if (x_481 == 0)
{
lean_object* x_482; lean_object* x_483; lean_object* x_484; uint8_t x_485; 
x_482 = lean_ctor_get(x_2, 1);
x_483 = lean_ctor_get(x_2, 2);
lean_dec(x_483);
x_484 = lean_ctor_get(x_2, 0);
lean_dec(x_484);
x_485 = !lean_is_exclusive(x_87);
if (x_485 == 0)
{
lean_object* x_486; lean_object* x_487; lean_object* x_488; 
x_486 = lean_ctor_get(x_87, 0);
x_487 = lean_ctor_get(x_87, 1);
x_488 = lean_ctor_get(x_87, 2);
lean_ctor_set(x_361, 2, x_488);
lean_ctor_set(x_361, 1, x_487);
lean_ctor_set(x_361, 0, x_486);
lean_ctor_set(x_87, 2, x_361);
lean_ctor_set(x_87, 1, x_482);
lean_ctor_set(x_87, 0, x_476);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_87);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_430);
return x_2;
}
else
{
lean_object* x_489; lean_object* x_490; lean_object* x_491; lean_object* x_492; 
x_489 = lean_ctor_get(x_87, 0);
x_490 = lean_ctor_get(x_87, 1);
x_491 = lean_ctor_get(x_87, 2);
lean_inc(x_491);
lean_inc(x_490);
lean_inc(x_489);
lean_dec(x_87);
lean_ctor_set(x_361, 2, x_491);
lean_ctor_set(x_361, 1, x_490);
lean_ctor_set(x_361, 0, x_489);
x_492 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_492, 0, x_476);
lean_ctor_set(x_492, 1, x_482);
lean_ctor_set(x_492, 2, x_361);
lean_ctor_set_uint8(x_492, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_492);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_430);
return x_2;
}
}
else
{
lean_object* x_493; lean_object* x_494; lean_object* x_495; lean_object* x_496; lean_object* x_497; lean_object* x_498; lean_object* x_499; 
x_493 = lean_ctor_get(x_2, 1);
lean_inc(x_493);
lean_dec(x_2);
x_494 = lean_ctor_get(x_87, 0);
lean_inc(x_494);
x_495 = lean_ctor_get(x_87, 1);
lean_inc(x_495);
x_496 = lean_ctor_get(x_87, 2);
lean_inc(x_496);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_497 = x_87;
} else {
 lean_dec_ref(x_87);
 x_497 = lean_box(0);
}
lean_ctor_set(x_361, 2, x_496);
lean_ctor_set(x_361, 1, x_495);
lean_ctor_set(x_361, 0, x_494);
if (lean_is_scalar(x_497)) {
 x_498 = lean_alloc_ctor(1, 3, 1);
} else {
 x_498 = x_497;
}
lean_ctor_set(x_498, 0, x_476);
lean_ctor_set(x_498, 1, x_493);
lean_ctor_set(x_498, 2, x_361);
lean_ctor_set_uint8(x_498, sizeof(void*)*3, x_360);
x_499 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_499, 0, x_498);
lean_ctor_set(x_499, 1, x_3);
lean_ctor_set(x_499, 2, x_4);
lean_ctor_set_uint8(x_499, sizeof(void*)*3, x_430);
return x_499;
}
}
else
{
lean_object* x_500; lean_object* x_501; lean_object* x_502; lean_object* x_503; lean_object* x_504; lean_object* x_505; lean_object* x_506; lean_object* x_507; lean_object* x_508; 
lean_dec(x_361);
x_500 = lean_ctor_get(x_2, 1);
lean_inc(x_500);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_501 = x_2;
} else {
 lean_dec_ref(x_2);
 x_501 = lean_box(0);
}
x_502 = lean_ctor_get(x_87, 0);
lean_inc(x_502);
x_503 = lean_ctor_get(x_87, 1);
lean_inc(x_503);
x_504 = lean_ctor_get(x_87, 2);
lean_inc(x_504);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_505 = x_87;
} else {
 lean_dec_ref(x_87);
 x_505 = lean_box(0);
}
x_506 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_506, 0, x_502);
lean_ctor_set(x_506, 1, x_503);
lean_ctor_set(x_506, 2, x_504);
lean_ctor_set_uint8(x_506, sizeof(void*)*3, x_430);
if (lean_is_scalar(x_505)) {
 x_507 = lean_alloc_ctor(1, 3, 1);
} else {
 x_507 = x_505;
}
lean_ctor_set(x_507, 0, x_476);
lean_ctor_set(x_507, 1, x_500);
lean_ctor_set(x_507, 2, x_506);
lean_ctor_set_uint8(x_507, sizeof(void*)*3, x_360);
if (lean_is_scalar(x_501)) {
 x_508 = lean_alloc_ctor(1, 3, 1);
} else {
 x_508 = x_501;
}
lean_ctor_set(x_508, 0, x_507);
lean_ctor_set(x_508, 1, x_3);
lean_ctor_set(x_508, 2, x_4);
lean_ctor_set_uint8(x_508, sizeof(void*)*3, x_430);
return x_508;
}
}
else
{
uint8_t x_509; 
x_509 = lean_ctor_get_uint8(x_476, sizeof(void*)*3);
if (x_509 == 0)
{
lean_object* x_510; lean_object* x_511; lean_object* x_512; lean_object* x_513; uint8_t x_514; 
x_510 = lean_ctor_get(x_2, 1);
lean_inc(x_510);
lean_dec_ref(x_2);
x_511 = lean_ctor_get(x_87, 0);
lean_inc(x_511);
x_512 = lean_ctor_get(x_87, 1);
lean_inc(x_512);
x_513 = lean_ctor_get(x_87, 2);
lean_inc(x_513);
lean_dec_ref(x_87);
x_514 = !lean_is_exclusive(x_4);
if (x_514 == 0)
{
lean_object* x_515; lean_object* x_516; lean_object* x_517; uint8_t x_518; 
x_515 = lean_ctor_get(x_4, 1);
x_516 = lean_ctor_get(x_4, 2);
lean_dec(x_516);
x_517 = lean_ctor_get(x_4, 0);
lean_dec(x_517);
x_518 = !lean_is_exclusive(x_476);
if (x_518 == 0)
{
lean_object* x_519; lean_object* x_520; lean_object* x_521; 
x_519 = lean_ctor_get(x_476, 0);
x_520 = lean_ctor_get(x_476, 1);
x_521 = lean_ctor_get(x_476, 2);
lean_ctor_set(x_476, 2, x_513);
lean_ctor_set(x_476, 1, x_512);
lean_ctor_set(x_476, 0, x_511);
lean_ctor_set_uint8(x_476, sizeof(void*)*3, x_430);
lean_ctor_set(x_4, 1, x_510);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_509);
x_5 = x_4;
x_6 = x_3;
x_7 = x_361;
x_8 = x_515;
x_9 = x_519;
x_10 = x_520;
x_11 = x_521;
goto block_16;
}
else
{
lean_object* x_522; lean_object* x_523; lean_object* x_524; lean_object* x_525; 
x_522 = lean_ctor_get(x_476, 0);
x_523 = lean_ctor_get(x_476, 1);
x_524 = lean_ctor_get(x_476, 2);
lean_inc(x_524);
lean_inc(x_523);
lean_inc(x_522);
lean_dec(x_476);
x_525 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_525, 0, x_511);
lean_ctor_set(x_525, 1, x_512);
lean_ctor_set(x_525, 2, x_513);
lean_ctor_set_uint8(x_525, sizeof(void*)*3, x_430);
lean_ctor_set(x_4, 2, x_525);
lean_ctor_set(x_4, 1, x_510);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_509);
x_5 = x_4;
x_6 = x_3;
x_7 = x_361;
x_8 = x_515;
x_9 = x_522;
x_10 = x_523;
x_11 = x_524;
goto block_16;
}
}
else
{
lean_object* x_526; lean_object* x_527; lean_object* x_528; lean_object* x_529; lean_object* x_530; lean_object* x_531; lean_object* x_532; 
x_526 = lean_ctor_get(x_4, 1);
lean_inc(x_526);
lean_dec(x_4);
x_527 = lean_ctor_get(x_476, 0);
lean_inc(x_527);
x_528 = lean_ctor_get(x_476, 1);
lean_inc(x_528);
x_529 = lean_ctor_get(x_476, 2);
lean_inc(x_529);
if (lean_is_exclusive(x_476)) {
 lean_ctor_release(x_476, 0);
 lean_ctor_release(x_476, 1);
 lean_ctor_release(x_476, 2);
 x_530 = x_476;
} else {
 lean_dec_ref(x_476);
 x_530 = lean_box(0);
}
if (lean_is_scalar(x_530)) {
 x_531 = lean_alloc_ctor(1, 3, 1);
} else {
 x_531 = x_530;
}
lean_ctor_set(x_531, 0, x_511);
lean_ctor_set(x_531, 1, x_512);
lean_ctor_set(x_531, 2, x_513);
lean_ctor_set_uint8(x_531, sizeof(void*)*3, x_430);
x_532 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_532, 0, x_86);
lean_ctor_set(x_532, 1, x_510);
lean_ctor_set(x_532, 2, x_531);
lean_ctor_set_uint8(x_532, sizeof(void*)*3, x_509);
x_5 = x_532;
x_6 = x_3;
x_7 = x_361;
x_8 = x_526;
x_9 = x_527;
x_10 = x_528;
x_11 = x_529;
goto block_16;
}
}
else
{
uint8_t x_533; 
x_533 = !lean_is_exclusive(x_2);
if (x_533 == 0)
{
lean_object* x_534; lean_object* x_535; lean_object* x_536; uint8_t x_537; 
x_534 = lean_ctor_get(x_2, 1);
x_535 = lean_ctor_get(x_2, 2);
lean_dec(x_535);
x_536 = lean_ctor_get(x_2, 0);
lean_dec(x_536);
x_537 = !lean_is_exclusive(x_87);
if (x_537 == 0)
{
uint8_t x_538; 
x_538 = !lean_is_exclusive(x_4);
if (x_538 == 0)
{
lean_object* x_539; lean_object* x_540; lean_object* x_541; lean_object* x_542; lean_object* x_543; lean_object* x_544; uint8_t x_545; 
x_539 = lean_ctor_get(x_87, 0);
x_540 = lean_ctor_get(x_87, 1);
x_541 = lean_ctor_get(x_87, 2);
x_542 = lean_ctor_get(x_4, 1);
x_543 = lean_ctor_get(x_4, 2);
lean_dec(x_543);
x_544 = lean_ctor_get(x_4, 0);
lean_dec(x_544);
x_545 = !lean_is_exclusive(x_361);
if (x_545 == 0)
{
lean_object* x_546; lean_object* x_547; lean_object* x_548; lean_object* x_549; 
x_546 = lean_ctor_get(x_361, 0);
x_547 = lean_ctor_get(x_361, 1);
x_548 = lean_ctor_get(x_361, 2);
lean_ctor_set(x_361, 2, x_541);
lean_ctor_set(x_361, 1, x_540);
lean_ctor_set(x_361, 0, x_539);
lean_ctor_set_uint8(x_361, sizeof(void*)*3, x_509);
lean_ctor_set(x_4, 2, x_361);
lean_ctor_set(x_4, 1, x_534);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set(x_87, 2, x_548);
lean_ctor_set(x_87, 1, x_547);
lean_ctor_set(x_87, 0, x_546);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_509);
lean_ctor_set(x_2, 2, x_476);
lean_ctor_set(x_2, 1, x_542);
lean_ctor_set(x_2, 0, x_87);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_360);
x_549 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_549, 0, x_4);
lean_ctor_set(x_549, 1, x_3);
lean_ctor_set(x_549, 2, x_2);
lean_ctor_set_uint8(x_549, sizeof(void*)*3, x_509);
return x_549;
}
else
{
lean_object* x_550; lean_object* x_551; lean_object* x_552; lean_object* x_553; lean_object* x_554; 
x_550 = lean_ctor_get(x_361, 0);
x_551 = lean_ctor_get(x_361, 1);
x_552 = lean_ctor_get(x_361, 2);
lean_inc(x_552);
lean_inc(x_551);
lean_inc(x_550);
lean_dec(x_361);
x_553 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_553, 0, x_539);
lean_ctor_set(x_553, 1, x_540);
lean_ctor_set(x_553, 2, x_541);
lean_ctor_set_uint8(x_553, sizeof(void*)*3, x_509);
lean_ctor_set(x_4, 2, x_553);
lean_ctor_set(x_4, 1, x_534);
lean_ctor_set(x_4, 0, x_86);
lean_ctor_set(x_87, 2, x_552);
lean_ctor_set(x_87, 1, x_551);
lean_ctor_set(x_87, 0, x_550);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_509);
lean_ctor_set(x_2, 2, x_476);
lean_ctor_set(x_2, 1, x_542);
lean_ctor_set(x_2, 0, x_87);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_360);
x_554 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_554, 0, x_4);
lean_ctor_set(x_554, 1, x_3);
lean_ctor_set(x_554, 2, x_2);
lean_ctor_set_uint8(x_554, sizeof(void*)*3, x_509);
return x_554;
}
}
else
{
lean_object* x_555; lean_object* x_556; lean_object* x_557; lean_object* x_558; lean_object* x_559; lean_object* x_560; lean_object* x_561; lean_object* x_562; lean_object* x_563; lean_object* x_564; lean_object* x_565; 
x_555 = lean_ctor_get(x_87, 0);
x_556 = lean_ctor_get(x_87, 1);
x_557 = lean_ctor_get(x_87, 2);
x_558 = lean_ctor_get(x_4, 1);
lean_inc(x_558);
lean_dec(x_4);
x_559 = lean_ctor_get(x_361, 0);
lean_inc(x_559);
x_560 = lean_ctor_get(x_361, 1);
lean_inc(x_560);
x_561 = lean_ctor_get(x_361, 2);
lean_inc(x_561);
if (lean_is_exclusive(x_361)) {
 lean_ctor_release(x_361, 0);
 lean_ctor_release(x_361, 1);
 lean_ctor_release(x_361, 2);
 x_562 = x_361;
} else {
 lean_dec_ref(x_361);
 x_562 = lean_box(0);
}
if (lean_is_scalar(x_562)) {
 x_563 = lean_alloc_ctor(1, 3, 1);
} else {
 x_563 = x_562;
}
lean_ctor_set(x_563, 0, x_555);
lean_ctor_set(x_563, 1, x_556);
lean_ctor_set(x_563, 2, x_557);
lean_ctor_set_uint8(x_563, sizeof(void*)*3, x_509);
x_564 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_564, 0, x_86);
lean_ctor_set(x_564, 1, x_534);
lean_ctor_set(x_564, 2, x_563);
lean_ctor_set_uint8(x_564, sizeof(void*)*3, x_360);
lean_ctor_set(x_87, 2, x_561);
lean_ctor_set(x_87, 1, x_560);
lean_ctor_set(x_87, 0, x_559);
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_509);
lean_ctor_set(x_2, 2, x_476);
lean_ctor_set(x_2, 1, x_558);
lean_ctor_set(x_2, 0, x_87);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_360);
x_565 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_565, 0, x_564);
lean_ctor_set(x_565, 1, x_3);
lean_ctor_set(x_565, 2, x_2);
lean_ctor_set_uint8(x_565, sizeof(void*)*3, x_509);
return x_565;
}
}
else
{
lean_object* x_566; lean_object* x_567; lean_object* x_568; lean_object* x_569; lean_object* x_570; lean_object* x_571; lean_object* x_572; lean_object* x_573; lean_object* x_574; lean_object* x_575; lean_object* x_576; lean_object* x_577; lean_object* x_578; 
x_566 = lean_ctor_get(x_87, 0);
x_567 = lean_ctor_get(x_87, 1);
x_568 = lean_ctor_get(x_87, 2);
lean_inc(x_568);
lean_inc(x_567);
lean_inc(x_566);
lean_dec(x_87);
x_569 = lean_ctor_get(x_4, 1);
lean_inc(x_569);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_570 = x_4;
} else {
 lean_dec_ref(x_4);
 x_570 = lean_box(0);
}
x_571 = lean_ctor_get(x_361, 0);
lean_inc(x_571);
x_572 = lean_ctor_get(x_361, 1);
lean_inc(x_572);
x_573 = lean_ctor_get(x_361, 2);
lean_inc(x_573);
if (lean_is_exclusive(x_361)) {
 lean_ctor_release(x_361, 0);
 lean_ctor_release(x_361, 1);
 lean_ctor_release(x_361, 2);
 x_574 = x_361;
} else {
 lean_dec_ref(x_361);
 x_574 = lean_box(0);
}
if (lean_is_scalar(x_574)) {
 x_575 = lean_alloc_ctor(1, 3, 1);
} else {
 x_575 = x_574;
}
lean_ctor_set(x_575, 0, x_566);
lean_ctor_set(x_575, 1, x_567);
lean_ctor_set(x_575, 2, x_568);
lean_ctor_set_uint8(x_575, sizeof(void*)*3, x_509);
if (lean_is_scalar(x_570)) {
 x_576 = lean_alloc_ctor(1, 3, 1);
} else {
 x_576 = x_570;
}
lean_ctor_set(x_576, 0, x_86);
lean_ctor_set(x_576, 1, x_534);
lean_ctor_set(x_576, 2, x_575);
lean_ctor_set_uint8(x_576, sizeof(void*)*3, x_360);
x_577 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_577, 0, x_571);
lean_ctor_set(x_577, 1, x_572);
lean_ctor_set(x_577, 2, x_573);
lean_ctor_set_uint8(x_577, sizeof(void*)*3, x_509);
lean_ctor_set(x_2, 2, x_476);
lean_ctor_set(x_2, 1, x_569);
lean_ctor_set(x_2, 0, x_577);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_360);
x_578 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_578, 0, x_576);
lean_ctor_set(x_578, 1, x_3);
lean_ctor_set(x_578, 2, x_2);
lean_ctor_set_uint8(x_578, sizeof(void*)*3, x_509);
return x_578;
}
}
else
{
lean_object* x_579; lean_object* x_580; lean_object* x_581; lean_object* x_582; lean_object* x_583; lean_object* x_584; lean_object* x_585; lean_object* x_586; lean_object* x_587; lean_object* x_588; lean_object* x_589; lean_object* x_590; lean_object* x_591; lean_object* x_592; lean_object* x_593; lean_object* x_594; 
x_579 = lean_ctor_get(x_2, 1);
lean_inc(x_579);
lean_dec(x_2);
x_580 = lean_ctor_get(x_87, 0);
lean_inc(x_580);
x_581 = lean_ctor_get(x_87, 1);
lean_inc(x_581);
x_582 = lean_ctor_get(x_87, 2);
lean_inc(x_582);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_583 = x_87;
} else {
 lean_dec_ref(x_87);
 x_583 = lean_box(0);
}
x_584 = lean_ctor_get(x_4, 1);
lean_inc(x_584);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_585 = x_4;
} else {
 lean_dec_ref(x_4);
 x_585 = lean_box(0);
}
x_586 = lean_ctor_get(x_361, 0);
lean_inc(x_586);
x_587 = lean_ctor_get(x_361, 1);
lean_inc(x_587);
x_588 = lean_ctor_get(x_361, 2);
lean_inc(x_588);
if (lean_is_exclusive(x_361)) {
 lean_ctor_release(x_361, 0);
 lean_ctor_release(x_361, 1);
 lean_ctor_release(x_361, 2);
 x_589 = x_361;
} else {
 lean_dec_ref(x_361);
 x_589 = lean_box(0);
}
if (lean_is_scalar(x_589)) {
 x_590 = lean_alloc_ctor(1, 3, 1);
} else {
 x_590 = x_589;
}
lean_ctor_set(x_590, 0, x_580);
lean_ctor_set(x_590, 1, x_581);
lean_ctor_set(x_590, 2, x_582);
lean_ctor_set_uint8(x_590, sizeof(void*)*3, x_509);
if (lean_is_scalar(x_585)) {
 x_591 = lean_alloc_ctor(1, 3, 1);
} else {
 x_591 = x_585;
}
lean_ctor_set(x_591, 0, x_86);
lean_ctor_set(x_591, 1, x_579);
lean_ctor_set(x_591, 2, x_590);
lean_ctor_set_uint8(x_591, sizeof(void*)*3, x_360);
if (lean_is_scalar(x_583)) {
 x_592 = lean_alloc_ctor(1, 3, 1);
} else {
 x_592 = x_583;
}
lean_ctor_set(x_592, 0, x_586);
lean_ctor_set(x_592, 1, x_587);
lean_ctor_set(x_592, 2, x_588);
lean_ctor_set_uint8(x_592, sizeof(void*)*3, x_509);
x_593 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_593, 0, x_592);
lean_ctor_set(x_593, 1, x_584);
lean_ctor_set(x_593, 2, x_476);
lean_ctor_set_uint8(x_593, sizeof(void*)*3, x_360);
x_594 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_594, 0, x_591);
lean_ctor_set(x_594, 1, x_3);
lean_ctor_set(x_594, 2, x_593);
lean_ctor_set_uint8(x_594, sizeof(void*)*3, x_509);
return x_594;
}
}
}
}
}
}
else
{
uint8_t x_595; 
x_595 = !lean_is_exclusive(x_2);
if (x_595 == 0)
{
lean_object* x_596; lean_object* x_597; uint8_t x_598; 
x_596 = lean_ctor_get(x_2, 2);
lean_dec(x_596);
x_597 = lean_ctor_get(x_2, 0);
lean_dec(x_597);
x_598 = !lean_is_exclusive(x_87);
if (x_598 == 0)
{
lean_object* x_599; 
lean_ctor_set_uint8(x_87, sizeof(void*)*3, x_360);
x_599 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_599, 0, x_2);
lean_ctor_set(x_599, 1, x_3);
lean_ctor_set(x_599, 2, x_4);
lean_ctor_set_uint8(x_599, sizeof(void*)*3, x_360);
return x_599;
}
else
{
lean_object* x_600; lean_object* x_601; lean_object* x_602; lean_object* x_603; lean_object* x_604; 
x_600 = lean_ctor_get(x_87, 0);
x_601 = lean_ctor_get(x_87, 1);
x_602 = lean_ctor_get(x_87, 2);
lean_inc(x_602);
lean_inc(x_601);
lean_inc(x_600);
lean_dec(x_87);
x_603 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_603, 0, x_600);
lean_ctor_set(x_603, 1, x_601);
lean_ctor_set(x_603, 2, x_602);
lean_ctor_set_uint8(x_603, sizeof(void*)*3, x_360);
lean_ctor_set(x_2, 2, x_603);
x_604 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_604, 0, x_2);
lean_ctor_set(x_604, 1, x_3);
lean_ctor_set(x_604, 2, x_4);
lean_ctor_set_uint8(x_604, sizeof(void*)*3, x_360);
return x_604;
}
}
else
{
lean_object* x_605; lean_object* x_606; lean_object* x_607; lean_object* x_608; lean_object* x_609; lean_object* x_610; lean_object* x_611; lean_object* x_612; 
x_605 = lean_ctor_get(x_2, 1);
lean_inc(x_605);
lean_dec(x_2);
x_606 = lean_ctor_get(x_87, 0);
lean_inc(x_606);
x_607 = lean_ctor_get(x_87, 1);
lean_inc(x_607);
x_608 = lean_ctor_get(x_87, 2);
lean_inc(x_608);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 lean_ctor_release(x_87, 2);
 x_609 = x_87;
} else {
 lean_dec_ref(x_87);
 x_609 = lean_box(0);
}
if (lean_is_scalar(x_609)) {
 x_610 = lean_alloc_ctor(1, 3, 1);
} else {
 x_610 = x_609;
}
lean_ctor_set(x_610, 0, x_606);
lean_ctor_set(x_610, 1, x_607);
lean_ctor_set(x_610, 2, x_608);
lean_ctor_set_uint8(x_610, sizeof(void*)*3, x_360);
x_611 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_611, 0, x_86);
lean_ctor_set(x_611, 1, x_605);
lean_ctor_set(x_611, 2, x_610);
lean_ctor_set_uint8(x_611, sizeof(void*)*3, x_85);
x_612 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_612, 0, x_611);
lean_ctor_set(x_612, 1, x_3);
lean_ctor_set(x_612, 2, x_4);
lean_ctor_set_uint8(x_612, sizeof(void*)*3, x_360);
return x_612;
}
}
}
}
}
}
else
{
uint8_t x_613; 
x_613 = lean_ctor_get_uint8(x_86, sizeof(void*)*3);
if (x_613 == 0)
{
lean_object* x_614; 
x_614 = lean_ctor_get(x_2, 2);
lean_inc(x_614);
if (lean_obj_tag(x_614) == 0)
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_615; lean_object* x_616; lean_object* x_617; lean_object* x_618; 
x_615 = lean_ctor_get(x_2, 1);
lean_inc(x_615);
lean_dec_ref(x_2);
x_616 = lean_ctor_get(x_86, 0);
lean_inc(x_616);
x_617 = lean_ctor_get(x_86, 1);
lean_inc(x_617);
x_618 = lean_ctor_get(x_86, 2);
lean_inc(x_618);
lean_dec_ref(x_86);
x_5 = x_616;
x_6 = x_617;
x_7 = x_618;
x_8 = x_615;
x_9 = x_4;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_619; 
x_619 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_619 == 0)
{
lean_object* x_620; 
x_620 = lean_ctor_get(x_4, 0);
lean_inc(x_620);
if (lean_obj_tag(x_620) == 0)
{
lean_object* x_621; 
x_621 = lean_ctor_get(x_4, 2);
if (lean_obj_tag(x_621) == 0)
{
lean_object* x_622; lean_object* x_623; lean_object* x_624; lean_object* x_625; uint8_t x_626; 
lean_inc(x_621);
x_622 = lean_ctor_get(x_2, 1);
lean_inc(x_622);
lean_dec_ref(x_2);
x_623 = lean_ctor_get(x_86, 0);
lean_inc(x_623);
x_624 = lean_ctor_get(x_86, 1);
lean_inc(x_624);
x_625 = lean_ctor_get(x_86, 2);
lean_inc(x_625);
lean_dec_ref(x_86);
x_626 = !lean_is_exclusive(x_4);
if (x_626 == 0)
{
lean_object* x_627; lean_object* x_628; 
x_627 = lean_ctor_get(x_4, 2);
lean_dec(x_627);
x_628 = lean_ctor_get(x_4, 0);
lean_dec(x_628);
lean_ctor_set(x_4, 0, x_621);
x_5 = x_623;
x_6 = x_624;
x_7 = x_625;
x_8 = x_622;
x_9 = x_621;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_629; lean_object* x_630; 
x_629 = lean_ctor_get(x_4, 1);
lean_inc(x_629);
lean_dec(x_4);
x_630 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_630, 0, x_621);
lean_ctor_set(x_630, 1, x_629);
lean_ctor_set(x_630, 2, x_621);
lean_ctor_set_uint8(x_630, sizeof(void*)*3, x_619);
x_5 = x_623;
x_6 = x_624;
x_7 = x_625;
x_8 = x_622;
x_9 = x_621;
x_10 = x_3;
x_11 = x_630;
goto block_16;
}
}
else
{
uint8_t x_631; 
x_631 = lean_ctor_get_uint8(x_621, sizeof(void*)*3);
if (x_631 == 0)
{
lean_object* x_632; lean_object* x_633; lean_object* x_634; lean_object* x_635; uint8_t x_636; 
lean_inc_ref(x_621);
x_632 = lean_ctor_get(x_2, 1);
lean_inc(x_632);
lean_dec_ref(x_2);
x_633 = lean_ctor_get(x_86, 0);
lean_inc(x_633);
x_634 = lean_ctor_get(x_86, 1);
lean_inc(x_634);
x_635 = lean_ctor_get(x_86, 2);
lean_inc(x_635);
lean_dec_ref(x_86);
x_636 = !lean_is_exclusive(x_4);
if (x_636 == 0)
{
lean_object* x_637; lean_object* x_638; 
x_637 = lean_ctor_get(x_4, 2);
lean_dec(x_637);
x_638 = lean_ctor_get(x_4, 0);
lean_dec(x_638);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_631);
x_5 = x_633;
x_6 = x_634;
x_7 = x_635;
x_8 = x_632;
x_9 = x_620;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_639; lean_object* x_640; 
x_639 = lean_ctor_get(x_4, 1);
lean_inc(x_639);
lean_dec(x_4);
x_640 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_640, 0, x_620);
lean_ctor_set(x_640, 1, x_639);
lean_ctor_set(x_640, 2, x_621);
lean_ctor_set_uint8(x_640, sizeof(void*)*3, x_631);
x_5 = x_633;
x_6 = x_634;
x_7 = x_635;
x_8 = x_632;
x_9 = x_620;
x_10 = x_3;
x_11 = x_640;
goto block_16;
}
}
else
{
lean_object* x_641; lean_object* x_642; lean_object* x_643; lean_object* x_644; 
x_641 = lean_ctor_get(x_2, 1);
lean_inc(x_641);
lean_dec_ref(x_2);
x_642 = lean_ctor_get(x_86, 0);
lean_inc(x_642);
x_643 = lean_ctor_get(x_86, 1);
lean_inc(x_643);
x_644 = lean_ctor_get(x_86, 2);
lean_inc(x_644);
lean_dec_ref(x_86);
x_5 = x_642;
x_6 = x_643;
x_7 = x_644;
x_8 = x_641;
x_9 = x_620;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
else
{
uint8_t x_645; 
x_645 = lean_ctor_get_uint8(x_620, sizeof(void*)*3);
if (x_645 == 0)
{
lean_object* x_646; 
x_646 = lean_ctor_get(x_4, 2);
lean_inc(x_646);
if (lean_obj_tag(x_646) == 0)
{
lean_object* x_647; lean_object* x_648; lean_object* x_649; lean_object* x_650; uint8_t x_651; 
x_647 = lean_ctor_get(x_2, 1);
lean_inc(x_647);
lean_dec_ref(x_2);
x_648 = lean_ctor_get(x_86, 0);
lean_inc(x_648);
x_649 = lean_ctor_get(x_86, 1);
lean_inc(x_649);
x_650 = lean_ctor_get(x_86, 2);
lean_inc(x_650);
lean_dec_ref(x_86);
x_651 = !lean_is_exclusive(x_4);
if (x_651 == 0)
{
lean_object* x_652; lean_object* x_653; 
x_652 = lean_ctor_get(x_4, 2);
lean_dec(x_652);
x_653 = lean_ctor_get(x_4, 0);
lean_dec(x_653);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_645);
x_5 = x_648;
x_6 = x_649;
x_7 = x_650;
x_8 = x_647;
x_9 = x_646;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_654; lean_object* x_655; 
x_654 = lean_ctor_get(x_4, 1);
lean_inc(x_654);
lean_dec(x_4);
x_655 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_655, 0, x_620);
lean_ctor_set(x_655, 1, x_654);
lean_ctor_set(x_655, 2, x_646);
lean_ctor_set_uint8(x_655, sizeof(void*)*3, x_645);
x_5 = x_648;
x_6 = x_649;
x_7 = x_650;
x_8 = x_647;
x_9 = x_646;
x_10 = x_3;
x_11 = x_655;
goto block_16;
}
}
else
{
uint8_t x_656; 
x_656 = lean_ctor_get_uint8(x_646, sizeof(void*)*3);
if (x_656 == 0)
{
lean_object* x_657; lean_object* x_658; lean_object* x_659; lean_object* x_660; uint8_t x_661; 
x_657 = lean_ctor_get(x_2, 1);
lean_inc(x_657);
lean_dec_ref(x_2);
x_658 = lean_ctor_get(x_86, 0);
lean_inc(x_658);
x_659 = lean_ctor_get(x_86, 1);
lean_inc(x_659);
x_660 = lean_ctor_get(x_86, 2);
lean_inc(x_660);
lean_dec_ref(x_86);
x_661 = !lean_is_exclusive(x_4);
if (x_661 == 0)
{
lean_object* x_662; lean_object* x_663; uint8_t x_664; 
x_662 = lean_ctor_get(x_4, 2);
lean_dec(x_662);
x_663 = lean_ctor_get(x_4, 0);
lean_dec(x_663);
x_664 = !lean_is_exclusive(x_620);
if (x_664 == 0)
{
lean_ctor_set_uint8(x_620, sizeof(void*)*3, x_656);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_656);
x_5 = x_658;
x_6 = x_659;
x_7 = x_660;
x_8 = x_657;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_665; lean_object* x_666; lean_object* x_667; lean_object* x_668; 
x_665 = lean_ctor_get(x_620, 0);
x_666 = lean_ctor_get(x_620, 1);
x_667 = lean_ctor_get(x_620, 2);
lean_inc(x_667);
lean_inc(x_666);
lean_inc(x_665);
lean_dec(x_620);
x_668 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_668, 0, x_665);
lean_ctor_set(x_668, 1, x_666);
lean_ctor_set(x_668, 2, x_667);
lean_ctor_set_uint8(x_668, sizeof(void*)*3, x_656);
lean_ctor_set(x_4, 0, x_668);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_656);
x_5 = x_658;
x_6 = x_659;
x_7 = x_660;
x_8 = x_657;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_669; lean_object* x_670; lean_object* x_671; lean_object* x_672; lean_object* x_673; lean_object* x_674; lean_object* x_675; 
x_669 = lean_ctor_get(x_4, 1);
lean_inc(x_669);
lean_dec(x_4);
x_670 = lean_ctor_get(x_620, 0);
lean_inc(x_670);
x_671 = lean_ctor_get(x_620, 1);
lean_inc(x_671);
x_672 = lean_ctor_get(x_620, 2);
lean_inc(x_672);
if (lean_is_exclusive(x_620)) {
 lean_ctor_release(x_620, 0);
 lean_ctor_release(x_620, 1);
 lean_ctor_release(x_620, 2);
 x_673 = x_620;
} else {
 lean_dec_ref(x_620);
 x_673 = lean_box(0);
}
if (lean_is_scalar(x_673)) {
 x_674 = lean_alloc_ctor(1, 3, 1);
} else {
 x_674 = x_673;
}
lean_ctor_set(x_674, 0, x_670);
lean_ctor_set(x_674, 1, x_671);
lean_ctor_set(x_674, 2, x_672);
lean_ctor_set_uint8(x_674, sizeof(void*)*3, x_656);
x_675 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_675, 0, x_674);
lean_ctor_set(x_675, 1, x_669);
lean_ctor_set(x_675, 2, x_646);
lean_ctor_set_uint8(x_675, sizeof(void*)*3, x_656);
x_5 = x_658;
x_6 = x_659;
x_7 = x_660;
x_8 = x_657;
x_9 = x_614;
x_10 = x_3;
x_11 = x_675;
goto block_16;
}
}
else
{
lean_object* x_676; lean_object* x_677; lean_object* x_678; lean_object* x_679; uint8_t x_680; 
x_676 = lean_ctor_get(x_2, 1);
lean_inc(x_676);
lean_dec_ref(x_2);
x_677 = lean_ctor_get(x_86, 0);
lean_inc(x_677);
x_678 = lean_ctor_get(x_86, 1);
lean_inc(x_678);
x_679 = lean_ctor_get(x_86, 2);
lean_inc(x_679);
lean_dec_ref(x_86);
x_680 = !lean_is_exclusive(x_4);
if (x_680 == 0)
{
lean_object* x_681; lean_object* x_682; 
x_681 = lean_ctor_get(x_4, 2);
lean_dec(x_681);
x_682 = lean_ctor_get(x_4, 0);
lean_dec(x_682);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_645);
x_5 = x_677;
x_6 = x_678;
x_7 = x_679;
x_8 = x_676;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_683; lean_object* x_684; 
x_683 = lean_ctor_get(x_4, 1);
lean_inc(x_683);
lean_dec(x_4);
x_684 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_684, 0, x_620);
lean_ctor_set(x_684, 1, x_683);
lean_ctor_set(x_684, 2, x_646);
lean_ctor_set_uint8(x_684, sizeof(void*)*3, x_645);
x_5 = x_677;
x_6 = x_678;
x_7 = x_679;
x_8 = x_676;
x_9 = x_614;
x_10 = x_3;
x_11 = x_684;
goto block_16;
}
}
}
}
else
{
lean_object* x_685; 
x_685 = lean_ctor_get(x_4, 2);
lean_inc(x_685);
if (lean_obj_tag(x_685) == 0)
{
lean_object* x_686; lean_object* x_687; lean_object* x_688; lean_object* x_689; 
lean_dec_ref(x_620);
x_686 = lean_ctor_get(x_2, 1);
lean_inc(x_686);
lean_dec_ref(x_2);
x_687 = lean_ctor_get(x_86, 0);
lean_inc(x_687);
x_688 = lean_ctor_get(x_86, 1);
lean_inc(x_688);
x_689 = lean_ctor_get(x_86, 2);
lean_inc(x_689);
lean_dec_ref(x_86);
x_5 = x_687;
x_6 = x_688;
x_7 = x_689;
x_8 = x_686;
x_9 = x_685;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_690; 
x_690 = lean_ctor_get_uint8(x_685, sizeof(void*)*3);
if (x_690 == 0)
{
lean_object* x_691; lean_object* x_692; lean_object* x_693; lean_object* x_694; uint8_t x_695; 
x_691 = lean_ctor_get(x_2, 1);
lean_inc(x_691);
lean_dec_ref(x_2);
x_692 = lean_ctor_get(x_86, 0);
lean_inc(x_692);
x_693 = lean_ctor_get(x_86, 1);
lean_inc(x_693);
x_694 = lean_ctor_get(x_86, 2);
lean_inc(x_694);
lean_dec_ref(x_86);
x_695 = !lean_is_exclusive(x_4);
if (x_695 == 0)
{
lean_object* x_696; lean_object* x_697; 
x_696 = lean_ctor_get(x_4, 2);
lean_dec(x_696);
x_697 = lean_ctor_get(x_4, 0);
lean_dec(x_697);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_690);
x_5 = x_692;
x_6 = x_693;
x_7 = x_694;
x_8 = x_691;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_698; lean_object* x_699; 
x_698 = lean_ctor_get(x_4, 1);
lean_inc(x_698);
lean_dec(x_4);
x_699 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_699, 0, x_620);
lean_ctor_set(x_699, 1, x_698);
lean_ctor_set(x_699, 2, x_685);
lean_ctor_set_uint8(x_699, sizeof(void*)*3, x_690);
x_5 = x_692;
x_6 = x_693;
x_7 = x_694;
x_8 = x_691;
x_9 = x_614;
x_10 = x_3;
x_11 = x_699;
goto block_16;
}
}
else
{
lean_object* x_700; lean_object* x_701; lean_object* x_702; lean_object* x_703; uint8_t x_704; 
x_700 = lean_ctor_get(x_2, 1);
lean_inc(x_700);
lean_dec_ref(x_2);
x_701 = lean_ctor_get(x_86, 0);
lean_inc(x_701);
x_702 = lean_ctor_get(x_86, 1);
lean_inc(x_702);
x_703 = lean_ctor_get(x_86, 2);
lean_inc(x_703);
lean_dec_ref(x_86);
x_704 = !lean_is_exclusive(x_4);
if (x_704 == 0)
{
lean_object* x_705; lean_object* x_706; uint8_t x_707; 
x_705 = lean_ctor_get(x_4, 2);
lean_dec(x_705);
x_706 = lean_ctor_get(x_4, 0);
lean_dec(x_706);
x_707 = !lean_is_exclusive(x_620);
if (x_707 == 0)
{
lean_ctor_set_uint8(x_620, sizeof(void*)*3, x_690);
x_5 = x_701;
x_6 = x_702;
x_7 = x_703;
x_8 = x_700;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_708; lean_object* x_709; lean_object* x_710; lean_object* x_711; 
x_708 = lean_ctor_get(x_620, 0);
x_709 = lean_ctor_get(x_620, 1);
x_710 = lean_ctor_get(x_620, 2);
lean_inc(x_710);
lean_inc(x_709);
lean_inc(x_708);
lean_dec(x_620);
x_711 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_711, 0, x_708);
lean_ctor_set(x_711, 1, x_709);
lean_ctor_set(x_711, 2, x_710);
lean_ctor_set_uint8(x_711, sizeof(void*)*3, x_690);
lean_ctor_set(x_4, 0, x_711);
x_5 = x_701;
x_6 = x_702;
x_7 = x_703;
x_8 = x_700;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_712; lean_object* x_713; lean_object* x_714; lean_object* x_715; lean_object* x_716; lean_object* x_717; lean_object* x_718; 
x_712 = lean_ctor_get(x_4, 1);
lean_inc(x_712);
lean_dec(x_4);
x_713 = lean_ctor_get(x_620, 0);
lean_inc(x_713);
x_714 = lean_ctor_get(x_620, 1);
lean_inc(x_714);
x_715 = lean_ctor_get(x_620, 2);
lean_inc(x_715);
if (lean_is_exclusive(x_620)) {
 lean_ctor_release(x_620, 0);
 lean_ctor_release(x_620, 1);
 lean_ctor_release(x_620, 2);
 x_716 = x_620;
} else {
 lean_dec_ref(x_620);
 x_716 = lean_box(0);
}
if (lean_is_scalar(x_716)) {
 x_717 = lean_alloc_ctor(1, 3, 1);
} else {
 x_717 = x_716;
}
lean_ctor_set(x_717, 0, x_713);
lean_ctor_set(x_717, 1, x_714);
lean_ctor_set(x_717, 2, x_715);
lean_ctor_set_uint8(x_717, sizeof(void*)*3, x_690);
x_718 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_718, 0, x_717);
lean_ctor_set(x_718, 1, x_712);
lean_ctor_set(x_718, 2, x_685);
lean_ctor_set_uint8(x_718, sizeof(void*)*3, x_619);
x_5 = x_701;
x_6 = x_702;
x_7 = x_703;
x_8 = x_700;
x_9 = x_614;
x_10 = x_3;
x_11 = x_718;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_719; lean_object* x_720; lean_object* x_721; lean_object* x_722; 
x_719 = lean_ctor_get(x_2, 1);
lean_inc(x_719);
lean_dec_ref(x_2);
x_720 = lean_ctor_get(x_86, 0);
lean_inc(x_720);
x_721 = lean_ctor_get(x_86, 1);
lean_inc(x_721);
x_722 = lean_ctor_get(x_86, 2);
lean_inc(x_722);
lean_dec_ref(x_86);
x_5 = x_720;
x_6 = x_721;
x_7 = x_722;
x_8 = x_719;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
else
{
uint8_t x_723; 
x_723 = lean_ctor_get_uint8(x_614, sizeof(void*)*3);
if (x_723 == 0)
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_724; lean_object* x_725; lean_object* x_726; lean_object* x_727; 
x_724 = lean_ctor_get(x_2, 1);
lean_inc(x_724);
lean_dec_ref(x_2);
x_725 = lean_ctor_get(x_86, 0);
lean_inc(x_725);
x_726 = lean_ctor_get(x_86, 1);
lean_inc(x_726);
x_727 = lean_ctor_get(x_86, 2);
lean_inc(x_727);
lean_dec_ref(x_86);
x_5 = x_725;
x_6 = x_726;
x_7 = x_727;
x_8 = x_724;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_728; 
x_728 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_728 == 0)
{
lean_object* x_729; 
x_729 = lean_ctor_get(x_4, 0);
lean_inc(x_729);
if (lean_obj_tag(x_729) == 0)
{
lean_object* x_730; 
x_730 = lean_ctor_get(x_4, 2);
lean_inc(x_730);
if (lean_obj_tag(x_730) == 0)
{
lean_object* x_731; lean_object* x_732; lean_object* x_733; lean_object* x_734; uint8_t x_735; 
x_731 = lean_ctor_get(x_2, 1);
lean_inc(x_731);
lean_dec_ref(x_2);
x_732 = lean_ctor_get(x_86, 0);
lean_inc(x_732);
x_733 = lean_ctor_get(x_86, 1);
lean_inc(x_733);
x_734 = lean_ctor_get(x_86, 2);
lean_inc(x_734);
lean_dec_ref(x_86);
x_735 = !lean_is_exclusive(x_614);
if (x_735 == 0)
{
uint8_t x_736; 
x_736 = !lean_is_exclusive(x_4);
if (x_736 == 0)
{
lean_object* x_737; lean_object* x_738; lean_object* x_739; lean_object* x_740; lean_object* x_741; lean_object* x_742; 
x_737 = lean_ctor_get(x_614, 0);
x_738 = lean_ctor_get(x_614, 1);
x_739 = lean_ctor_get(x_614, 2);
x_740 = lean_ctor_get(x_4, 1);
x_741 = lean_ctor_get(x_4, 2);
lean_dec(x_741);
x_742 = lean_ctor_get(x_4, 0);
lean_dec(x_742);
lean_ctor_set(x_4, 2, x_739);
lean_ctor_set(x_4, 1, x_738);
lean_ctor_set(x_4, 0, x_737);
lean_ctor_set(x_614, 2, x_730);
lean_ctor_set(x_614, 1, x_740);
lean_ctor_set(x_614, 0, x_730);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_728);
x_5 = x_732;
x_6 = x_733;
x_7 = x_734;
x_8 = x_731;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_743; lean_object* x_744; lean_object* x_745; lean_object* x_746; lean_object* x_747; 
x_743 = lean_ctor_get(x_614, 0);
x_744 = lean_ctor_get(x_614, 1);
x_745 = lean_ctor_get(x_614, 2);
x_746 = lean_ctor_get(x_4, 1);
lean_inc(x_746);
lean_dec(x_4);
x_747 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_747, 0, x_743);
lean_ctor_set(x_747, 1, x_744);
lean_ctor_set(x_747, 2, x_745);
lean_ctor_set_uint8(x_747, sizeof(void*)*3, x_728);
lean_ctor_set(x_614, 2, x_730);
lean_ctor_set(x_614, 1, x_746);
lean_ctor_set(x_614, 0, x_730);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_728);
x_5 = x_732;
x_6 = x_733;
x_7 = x_734;
x_8 = x_731;
x_9 = x_747;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_748; lean_object* x_749; lean_object* x_750; lean_object* x_751; lean_object* x_752; lean_object* x_753; lean_object* x_754; 
x_748 = lean_ctor_get(x_614, 0);
x_749 = lean_ctor_get(x_614, 1);
x_750 = lean_ctor_get(x_614, 2);
lean_inc(x_750);
lean_inc(x_749);
lean_inc(x_748);
lean_dec(x_614);
x_751 = lean_ctor_get(x_4, 1);
lean_inc(x_751);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_752 = x_4;
} else {
 lean_dec_ref(x_4);
 x_752 = lean_box(0);
}
if (lean_is_scalar(x_752)) {
 x_753 = lean_alloc_ctor(1, 3, 1);
} else {
 x_753 = x_752;
}
lean_ctor_set(x_753, 0, x_748);
lean_ctor_set(x_753, 1, x_749);
lean_ctor_set(x_753, 2, x_750);
lean_ctor_set_uint8(x_753, sizeof(void*)*3, x_728);
x_754 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_754, 0, x_730);
lean_ctor_set(x_754, 1, x_751);
lean_ctor_set(x_754, 2, x_730);
lean_ctor_set_uint8(x_754, sizeof(void*)*3, x_728);
x_5 = x_732;
x_6 = x_733;
x_7 = x_734;
x_8 = x_731;
x_9 = x_753;
x_10 = x_3;
x_11 = x_754;
goto block_16;
}
}
else
{
uint8_t x_755; 
x_755 = lean_ctor_get_uint8(x_730, sizeof(void*)*3);
if (x_755 == 0)
{
lean_object* x_756; lean_object* x_757; lean_object* x_758; lean_object* x_759; uint8_t x_760; 
x_756 = lean_ctor_get(x_2, 1);
lean_inc(x_756);
lean_dec_ref(x_2);
x_757 = lean_ctor_get(x_86, 0);
lean_inc(x_757);
x_758 = lean_ctor_get(x_86, 1);
lean_inc(x_758);
x_759 = lean_ctor_get(x_86, 2);
lean_inc(x_759);
lean_dec_ref(x_86);
x_760 = !lean_is_exclusive(x_614);
if (x_760 == 0)
{
uint8_t x_761; 
x_761 = !lean_is_exclusive(x_4);
if (x_761 == 0)
{
lean_object* x_762; lean_object* x_763; lean_object* x_764; lean_object* x_765; lean_object* x_766; lean_object* x_767; 
x_762 = lean_ctor_get(x_614, 0);
x_763 = lean_ctor_get(x_614, 1);
x_764 = lean_ctor_get(x_614, 2);
x_765 = lean_ctor_get(x_4, 1);
x_766 = lean_ctor_get(x_4, 2);
lean_dec(x_766);
x_767 = lean_ctor_get(x_4, 0);
lean_dec(x_767);
lean_ctor_set(x_4, 2, x_764);
lean_ctor_set(x_4, 1, x_763);
lean_ctor_set(x_4, 0, x_762);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_755);
lean_ctor_set(x_614, 2, x_730);
lean_ctor_set(x_614, 1, x_765);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_755);
x_5 = x_757;
x_6 = x_758;
x_7 = x_759;
x_8 = x_756;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_768; lean_object* x_769; lean_object* x_770; lean_object* x_771; lean_object* x_772; 
x_768 = lean_ctor_get(x_614, 0);
x_769 = lean_ctor_get(x_614, 1);
x_770 = lean_ctor_get(x_614, 2);
x_771 = lean_ctor_get(x_4, 1);
lean_inc(x_771);
lean_dec(x_4);
x_772 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_772, 0, x_768);
lean_ctor_set(x_772, 1, x_769);
lean_ctor_set(x_772, 2, x_770);
lean_ctor_set_uint8(x_772, sizeof(void*)*3, x_755);
lean_ctor_set(x_614, 2, x_730);
lean_ctor_set(x_614, 1, x_771);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_755);
x_5 = x_757;
x_6 = x_758;
x_7 = x_759;
x_8 = x_756;
x_9 = x_772;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_773; lean_object* x_774; lean_object* x_775; lean_object* x_776; lean_object* x_777; lean_object* x_778; lean_object* x_779; 
x_773 = lean_ctor_get(x_614, 0);
x_774 = lean_ctor_get(x_614, 1);
x_775 = lean_ctor_get(x_614, 2);
lean_inc(x_775);
lean_inc(x_774);
lean_inc(x_773);
lean_dec(x_614);
x_776 = lean_ctor_get(x_4, 1);
lean_inc(x_776);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_777 = x_4;
} else {
 lean_dec_ref(x_4);
 x_777 = lean_box(0);
}
if (lean_is_scalar(x_777)) {
 x_778 = lean_alloc_ctor(1, 3, 1);
} else {
 x_778 = x_777;
}
lean_ctor_set(x_778, 0, x_773);
lean_ctor_set(x_778, 1, x_774);
lean_ctor_set(x_778, 2, x_775);
lean_ctor_set_uint8(x_778, sizeof(void*)*3, x_755);
x_779 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_779, 0, x_729);
lean_ctor_set(x_779, 1, x_776);
lean_ctor_set(x_779, 2, x_730);
lean_ctor_set_uint8(x_779, sizeof(void*)*3, x_755);
x_5 = x_757;
x_6 = x_758;
x_7 = x_759;
x_8 = x_756;
x_9 = x_778;
x_10 = x_3;
x_11 = x_779;
goto block_16;
}
}
else
{
uint8_t x_780; 
x_780 = !lean_is_exclusive(x_730);
if (x_780 == 0)
{
lean_object* x_781; lean_object* x_782; lean_object* x_783; lean_object* x_784; lean_object* x_785; lean_object* x_786; lean_object* x_787; lean_object* x_788; lean_object* x_789; lean_object* x_790; 
x_781 = lean_ctor_get(x_730, 2);
lean_dec(x_781);
x_782 = lean_ctor_get(x_730, 1);
lean_dec(x_782);
x_783 = lean_ctor_get(x_730, 0);
lean_dec(x_783);
x_784 = lean_ctor_get(x_2, 1);
lean_inc(x_784);
lean_dec_ref(x_2);
x_785 = lean_ctor_get(x_86, 0);
lean_inc(x_785);
x_786 = lean_ctor_get(x_86, 1);
lean_inc(x_786);
x_787 = lean_ctor_get(x_86, 2);
lean_inc(x_787);
lean_dec_ref(x_86);
x_788 = lean_ctor_get(x_614, 0);
lean_inc(x_788);
x_789 = lean_ctor_get(x_614, 1);
lean_inc(x_789);
x_790 = lean_ctor_get(x_614, 2);
lean_inc(x_790);
lean_dec_ref(x_614);
lean_ctor_set(x_730, 2, x_790);
lean_ctor_set(x_730, 1, x_789);
lean_ctor_set(x_730, 0, x_788);
lean_ctor_set_uint8(x_730, sizeof(void*)*3, x_728);
x_5 = x_785;
x_6 = x_786;
x_7 = x_787;
x_8 = x_784;
x_9 = x_730;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_791; lean_object* x_792; lean_object* x_793; lean_object* x_794; lean_object* x_795; lean_object* x_796; lean_object* x_797; lean_object* x_798; 
lean_dec(x_730);
x_791 = lean_ctor_get(x_2, 1);
lean_inc(x_791);
lean_dec_ref(x_2);
x_792 = lean_ctor_get(x_86, 0);
lean_inc(x_792);
x_793 = lean_ctor_get(x_86, 1);
lean_inc(x_793);
x_794 = lean_ctor_get(x_86, 2);
lean_inc(x_794);
lean_dec_ref(x_86);
x_795 = lean_ctor_get(x_614, 0);
lean_inc(x_795);
x_796 = lean_ctor_get(x_614, 1);
lean_inc(x_796);
x_797 = lean_ctor_get(x_614, 2);
lean_inc(x_797);
lean_dec_ref(x_614);
x_798 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_798, 0, x_795);
lean_ctor_set(x_798, 1, x_796);
lean_ctor_set(x_798, 2, x_797);
lean_ctor_set_uint8(x_798, sizeof(void*)*3, x_728);
x_5 = x_792;
x_6 = x_793;
x_7 = x_794;
x_8 = x_791;
x_9 = x_798;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
}
else
{
uint8_t x_799; 
x_799 = lean_ctor_get_uint8(x_729, sizeof(void*)*3);
if (x_799 == 0)
{
lean_object* x_800; 
x_800 = lean_ctor_get(x_4, 2);
lean_inc(x_800);
if (lean_obj_tag(x_800) == 0)
{
lean_object* x_801; lean_object* x_802; lean_object* x_803; lean_object* x_804; uint8_t x_805; 
x_801 = lean_ctor_get(x_2, 1);
lean_inc(x_801);
lean_dec_ref(x_2);
x_802 = lean_ctor_get(x_86, 0);
lean_inc(x_802);
x_803 = lean_ctor_get(x_86, 1);
lean_inc(x_803);
x_804 = lean_ctor_get(x_86, 2);
lean_inc(x_804);
lean_dec_ref(x_86);
x_805 = !lean_is_exclusive(x_614);
if (x_805 == 0)
{
uint8_t x_806; 
x_806 = !lean_is_exclusive(x_4);
if (x_806 == 0)
{
lean_object* x_807; lean_object* x_808; lean_object* x_809; lean_object* x_810; lean_object* x_811; lean_object* x_812; 
x_807 = lean_ctor_get(x_614, 0);
x_808 = lean_ctor_get(x_614, 1);
x_809 = lean_ctor_get(x_614, 2);
x_810 = lean_ctor_get(x_4, 1);
x_811 = lean_ctor_get(x_4, 2);
lean_dec(x_811);
x_812 = lean_ctor_get(x_4, 0);
lean_dec(x_812);
lean_ctor_set(x_4, 2, x_809);
lean_ctor_set(x_4, 1, x_808);
lean_ctor_set(x_4, 0, x_807);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_799);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_810);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_799);
x_5 = x_802;
x_6 = x_803;
x_7 = x_804;
x_8 = x_801;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_813; lean_object* x_814; lean_object* x_815; lean_object* x_816; lean_object* x_817; 
x_813 = lean_ctor_get(x_614, 0);
x_814 = lean_ctor_get(x_614, 1);
x_815 = lean_ctor_get(x_614, 2);
x_816 = lean_ctor_get(x_4, 1);
lean_inc(x_816);
lean_dec(x_4);
x_817 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_817, 0, x_813);
lean_ctor_set(x_817, 1, x_814);
lean_ctor_set(x_817, 2, x_815);
lean_ctor_set_uint8(x_817, sizeof(void*)*3, x_799);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_816);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_799);
x_5 = x_802;
x_6 = x_803;
x_7 = x_804;
x_8 = x_801;
x_9 = x_817;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_818; lean_object* x_819; lean_object* x_820; lean_object* x_821; lean_object* x_822; lean_object* x_823; lean_object* x_824; 
x_818 = lean_ctor_get(x_614, 0);
x_819 = lean_ctor_get(x_614, 1);
x_820 = lean_ctor_get(x_614, 2);
lean_inc(x_820);
lean_inc(x_819);
lean_inc(x_818);
lean_dec(x_614);
x_821 = lean_ctor_get(x_4, 1);
lean_inc(x_821);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_822 = x_4;
} else {
 lean_dec_ref(x_4);
 x_822 = lean_box(0);
}
if (lean_is_scalar(x_822)) {
 x_823 = lean_alloc_ctor(1, 3, 1);
} else {
 x_823 = x_822;
}
lean_ctor_set(x_823, 0, x_818);
lean_ctor_set(x_823, 1, x_819);
lean_ctor_set(x_823, 2, x_820);
lean_ctor_set_uint8(x_823, sizeof(void*)*3, x_799);
x_824 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_824, 0, x_729);
lean_ctor_set(x_824, 1, x_821);
lean_ctor_set(x_824, 2, x_800);
lean_ctor_set_uint8(x_824, sizeof(void*)*3, x_799);
x_5 = x_802;
x_6 = x_803;
x_7 = x_804;
x_8 = x_801;
x_9 = x_823;
x_10 = x_3;
x_11 = x_824;
goto block_16;
}
}
else
{
uint8_t x_825; 
x_825 = lean_ctor_get_uint8(x_800, sizeof(void*)*3);
if (x_825 == 0)
{
lean_object* x_826; lean_object* x_827; lean_object* x_828; lean_object* x_829; uint8_t x_830; 
x_826 = lean_ctor_get(x_2, 1);
lean_inc(x_826);
lean_dec_ref(x_2);
x_827 = lean_ctor_get(x_86, 0);
lean_inc(x_827);
x_828 = lean_ctor_get(x_86, 1);
lean_inc(x_828);
x_829 = lean_ctor_get(x_86, 2);
lean_inc(x_829);
lean_dec_ref(x_86);
x_830 = !lean_is_exclusive(x_614);
if (x_830 == 0)
{
uint8_t x_831; 
x_831 = !lean_is_exclusive(x_4);
if (x_831 == 0)
{
lean_object* x_832; lean_object* x_833; lean_object* x_834; lean_object* x_835; lean_object* x_836; lean_object* x_837; uint8_t x_838; 
x_832 = lean_ctor_get(x_614, 0);
x_833 = lean_ctor_get(x_614, 1);
x_834 = lean_ctor_get(x_614, 2);
x_835 = lean_ctor_get(x_4, 1);
x_836 = lean_ctor_get(x_4, 2);
lean_dec(x_836);
x_837 = lean_ctor_get(x_4, 0);
lean_dec(x_837);
x_838 = !lean_is_exclusive(x_729);
if (x_838 == 0)
{
lean_object* x_839; lean_object* x_840; lean_object* x_841; 
x_839 = lean_ctor_get(x_729, 0);
x_840 = lean_ctor_get(x_729, 1);
x_841 = lean_ctor_get(x_729, 2);
lean_ctor_set(x_729, 2, x_834);
lean_ctor_set(x_729, 1, x_833);
lean_ctor_set(x_729, 0, x_832);
lean_ctor_set_uint8(x_729, sizeof(void*)*3, x_825);
lean_ctor_set(x_4, 2, x_841);
lean_ctor_set(x_4, 1, x_840);
lean_ctor_set(x_4, 0, x_839);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_825);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_835);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_825);
x_5 = x_827;
x_6 = x_828;
x_7 = x_829;
x_8 = x_826;
x_9 = x_729;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_842; lean_object* x_843; lean_object* x_844; lean_object* x_845; 
x_842 = lean_ctor_get(x_729, 0);
x_843 = lean_ctor_get(x_729, 1);
x_844 = lean_ctor_get(x_729, 2);
lean_inc(x_844);
lean_inc(x_843);
lean_inc(x_842);
lean_dec(x_729);
x_845 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_845, 0, x_832);
lean_ctor_set(x_845, 1, x_833);
lean_ctor_set(x_845, 2, x_834);
lean_ctor_set_uint8(x_845, sizeof(void*)*3, x_825);
lean_ctor_set(x_4, 2, x_844);
lean_ctor_set(x_4, 1, x_843);
lean_ctor_set(x_4, 0, x_842);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_825);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_835);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_825);
x_5 = x_827;
x_6 = x_828;
x_7 = x_829;
x_8 = x_826;
x_9 = x_845;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_846; lean_object* x_847; lean_object* x_848; lean_object* x_849; lean_object* x_850; lean_object* x_851; lean_object* x_852; lean_object* x_853; lean_object* x_854; lean_object* x_855; 
x_846 = lean_ctor_get(x_614, 0);
x_847 = lean_ctor_get(x_614, 1);
x_848 = lean_ctor_get(x_614, 2);
x_849 = lean_ctor_get(x_4, 1);
lean_inc(x_849);
lean_dec(x_4);
x_850 = lean_ctor_get(x_729, 0);
lean_inc(x_850);
x_851 = lean_ctor_get(x_729, 1);
lean_inc(x_851);
x_852 = lean_ctor_get(x_729, 2);
lean_inc(x_852);
if (lean_is_exclusive(x_729)) {
 lean_ctor_release(x_729, 0);
 lean_ctor_release(x_729, 1);
 lean_ctor_release(x_729, 2);
 x_853 = x_729;
} else {
 lean_dec_ref(x_729);
 x_853 = lean_box(0);
}
if (lean_is_scalar(x_853)) {
 x_854 = lean_alloc_ctor(1, 3, 1);
} else {
 x_854 = x_853;
}
lean_ctor_set(x_854, 0, x_846);
lean_ctor_set(x_854, 1, x_847);
lean_ctor_set(x_854, 2, x_848);
lean_ctor_set_uint8(x_854, sizeof(void*)*3, x_825);
x_855 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_855, 0, x_850);
lean_ctor_set(x_855, 1, x_851);
lean_ctor_set(x_855, 2, x_852);
lean_ctor_set_uint8(x_855, sizeof(void*)*3, x_825);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_849);
lean_ctor_set(x_614, 0, x_855);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_825);
x_5 = x_827;
x_6 = x_828;
x_7 = x_829;
x_8 = x_826;
x_9 = x_854;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_856; lean_object* x_857; lean_object* x_858; lean_object* x_859; lean_object* x_860; lean_object* x_861; lean_object* x_862; lean_object* x_863; lean_object* x_864; lean_object* x_865; lean_object* x_866; lean_object* x_867; 
x_856 = lean_ctor_get(x_614, 0);
x_857 = lean_ctor_get(x_614, 1);
x_858 = lean_ctor_get(x_614, 2);
lean_inc(x_858);
lean_inc(x_857);
lean_inc(x_856);
lean_dec(x_614);
x_859 = lean_ctor_get(x_4, 1);
lean_inc(x_859);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_860 = x_4;
} else {
 lean_dec_ref(x_4);
 x_860 = lean_box(0);
}
x_861 = lean_ctor_get(x_729, 0);
lean_inc(x_861);
x_862 = lean_ctor_get(x_729, 1);
lean_inc(x_862);
x_863 = lean_ctor_get(x_729, 2);
lean_inc(x_863);
if (lean_is_exclusive(x_729)) {
 lean_ctor_release(x_729, 0);
 lean_ctor_release(x_729, 1);
 lean_ctor_release(x_729, 2);
 x_864 = x_729;
} else {
 lean_dec_ref(x_729);
 x_864 = lean_box(0);
}
if (lean_is_scalar(x_864)) {
 x_865 = lean_alloc_ctor(1, 3, 1);
} else {
 x_865 = x_864;
}
lean_ctor_set(x_865, 0, x_856);
lean_ctor_set(x_865, 1, x_857);
lean_ctor_set(x_865, 2, x_858);
lean_ctor_set_uint8(x_865, sizeof(void*)*3, x_825);
if (lean_is_scalar(x_860)) {
 x_866 = lean_alloc_ctor(1, 3, 1);
} else {
 x_866 = x_860;
}
lean_ctor_set(x_866, 0, x_861);
lean_ctor_set(x_866, 1, x_862);
lean_ctor_set(x_866, 2, x_863);
lean_ctor_set_uint8(x_866, sizeof(void*)*3, x_825);
x_867 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_867, 0, x_866);
lean_ctor_set(x_867, 1, x_859);
lean_ctor_set(x_867, 2, x_800);
lean_ctor_set_uint8(x_867, sizeof(void*)*3, x_825);
x_5 = x_827;
x_6 = x_828;
x_7 = x_829;
x_8 = x_826;
x_9 = x_865;
x_10 = x_3;
x_11 = x_867;
goto block_16;
}
}
else
{
lean_object* x_868; lean_object* x_869; lean_object* x_870; lean_object* x_871; uint8_t x_872; 
x_868 = lean_ctor_get(x_2, 1);
lean_inc(x_868);
lean_dec_ref(x_2);
x_869 = lean_ctor_get(x_86, 0);
lean_inc(x_869);
x_870 = lean_ctor_get(x_86, 1);
lean_inc(x_870);
x_871 = lean_ctor_get(x_86, 2);
lean_inc(x_871);
lean_dec_ref(x_86);
x_872 = !lean_is_exclusive(x_614);
if (x_872 == 0)
{
uint8_t x_873; 
x_873 = !lean_is_exclusive(x_4);
if (x_873 == 0)
{
lean_object* x_874; lean_object* x_875; lean_object* x_876; lean_object* x_877; lean_object* x_878; lean_object* x_879; 
x_874 = lean_ctor_get(x_614, 0);
x_875 = lean_ctor_get(x_614, 1);
x_876 = lean_ctor_get(x_614, 2);
x_877 = lean_ctor_get(x_4, 1);
x_878 = lean_ctor_get(x_4, 2);
lean_dec(x_878);
x_879 = lean_ctor_get(x_4, 0);
lean_dec(x_879);
lean_ctor_set(x_4, 2, x_876);
lean_ctor_set(x_4, 1, x_875);
lean_ctor_set(x_4, 0, x_874);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_799);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_877);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_799);
x_5 = x_869;
x_6 = x_870;
x_7 = x_871;
x_8 = x_868;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_880; lean_object* x_881; lean_object* x_882; lean_object* x_883; lean_object* x_884; 
x_880 = lean_ctor_get(x_614, 0);
x_881 = lean_ctor_get(x_614, 1);
x_882 = lean_ctor_get(x_614, 2);
x_883 = lean_ctor_get(x_4, 1);
lean_inc(x_883);
lean_dec(x_4);
x_884 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_884, 0, x_880);
lean_ctor_set(x_884, 1, x_881);
lean_ctor_set(x_884, 2, x_882);
lean_ctor_set_uint8(x_884, sizeof(void*)*3, x_799);
lean_ctor_set(x_614, 2, x_800);
lean_ctor_set(x_614, 1, x_883);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_799);
x_5 = x_869;
x_6 = x_870;
x_7 = x_871;
x_8 = x_868;
x_9 = x_884;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_885; lean_object* x_886; lean_object* x_887; lean_object* x_888; lean_object* x_889; lean_object* x_890; lean_object* x_891; 
x_885 = lean_ctor_get(x_614, 0);
x_886 = lean_ctor_get(x_614, 1);
x_887 = lean_ctor_get(x_614, 2);
lean_inc(x_887);
lean_inc(x_886);
lean_inc(x_885);
lean_dec(x_614);
x_888 = lean_ctor_get(x_4, 1);
lean_inc(x_888);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_889 = x_4;
} else {
 lean_dec_ref(x_4);
 x_889 = lean_box(0);
}
if (lean_is_scalar(x_889)) {
 x_890 = lean_alloc_ctor(1, 3, 1);
} else {
 x_890 = x_889;
}
lean_ctor_set(x_890, 0, x_885);
lean_ctor_set(x_890, 1, x_886);
lean_ctor_set(x_890, 2, x_887);
lean_ctor_set_uint8(x_890, sizeof(void*)*3, x_799);
x_891 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_891, 0, x_729);
lean_ctor_set(x_891, 1, x_888);
lean_ctor_set(x_891, 2, x_800);
lean_ctor_set_uint8(x_891, sizeof(void*)*3, x_799);
x_5 = x_869;
x_6 = x_870;
x_7 = x_871;
x_8 = x_868;
x_9 = x_890;
x_10 = x_3;
x_11 = x_891;
goto block_16;
}
}
}
}
else
{
lean_object* x_892; 
x_892 = lean_ctor_get(x_4, 2);
if (lean_obj_tag(x_892) == 0)
{
uint8_t x_893; 
x_893 = !lean_is_exclusive(x_729);
if (x_893 == 0)
{
lean_object* x_894; lean_object* x_895; lean_object* x_896; lean_object* x_897; lean_object* x_898; lean_object* x_899; lean_object* x_900; lean_object* x_901; lean_object* x_902; lean_object* x_903; 
x_894 = lean_ctor_get(x_729, 2);
lean_dec(x_894);
x_895 = lean_ctor_get(x_729, 1);
lean_dec(x_895);
x_896 = lean_ctor_get(x_729, 0);
lean_dec(x_896);
x_897 = lean_ctor_get(x_2, 1);
lean_inc(x_897);
lean_dec_ref(x_2);
x_898 = lean_ctor_get(x_86, 0);
lean_inc(x_898);
x_899 = lean_ctor_get(x_86, 1);
lean_inc(x_899);
x_900 = lean_ctor_get(x_86, 2);
lean_inc(x_900);
lean_dec_ref(x_86);
x_901 = lean_ctor_get(x_614, 0);
lean_inc(x_901);
x_902 = lean_ctor_get(x_614, 1);
lean_inc(x_902);
x_903 = lean_ctor_get(x_614, 2);
lean_inc(x_903);
lean_dec_ref(x_614);
lean_ctor_set(x_729, 2, x_903);
lean_ctor_set(x_729, 1, x_902);
lean_ctor_set(x_729, 0, x_901);
lean_ctor_set_uint8(x_729, sizeof(void*)*3, x_728);
x_5 = x_898;
x_6 = x_899;
x_7 = x_900;
x_8 = x_897;
x_9 = x_729;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_904; lean_object* x_905; lean_object* x_906; lean_object* x_907; lean_object* x_908; lean_object* x_909; lean_object* x_910; lean_object* x_911; 
lean_dec(x_729);
x_904 = lean_ctor_get(x_2, 1);
lean_inc(x_904);
lean_dec_ref(x_2);
x_905 = lean_ctor_get(x_86, 0);
lean_inc(x_905);
x_906 = lean_ctor_get(x_86, 1);
lean_inc(x_906);
x_907 = lean_ctor_get(x_86, 2);
lean_inc(x_907);
lean_dec_ref(x_86);
x_908 = lean_ctor_get(x_614, 0);
lean_inc(x_908);
x_909 = lean_ctor_get(x_614, 1);
lean_inc(x_909);
x_910 = lean_ctor_get(x_614, 2);
lean_inc(x_910);
lean_dec_ref(x_614);
x_911 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_911, 0, x_908);
lean_ctor_set(x_911, 1, x_909);
lean_ctor_set(x_911, 2, x_910);
lean_ctor_set_uint8(x_911, sizeof(void*)*3, x_728);
x_5 = x_905;
x_6 = x_906;
x_7 = x_907;
x_8 = x_904;
x_9 = x_911;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
uint8_t x_912; 
lean_inc_ref(x_892);
x_912 = lean_ctor_get_uint8(x_892, sizeof(void*)*3);
if (x_912 == 0)
{
lean_object* x_913; lean_object* x_914; lean_object* x_915; lean_object* x_916; uint8_t x_917; 
x_913 = lean_ctor_get(x_2, 1);
lean_inc(x_913);
lean_dec_ref(x_2);
x_914 = lean_ctor_get(x_86, 0);
lean_inc(x_914);
x_915 = lean_ctor_get(x_86, 1);
lean_inc(x_915);
x_916 = lean_ctor_get(x_86, 2);
lean_inc(x_916);
lean_dec_ref(x_86);
x_917 = !lean_is_exclusive(x_614);
if (x_917 == 0)
{
uint8_t x_918; 
x_918 = !lean_is_exclusive(x_4);
if (x_918 == 0)
{
lean_object* x_919; lean_object* x_920; lean_object* x_921; lean_object* x_922; lean_object* x_923; lean_object* x_924; 
x_919 = lean_ctor_get(x_614, 0);
x_920 = lean_ctor_get(x_614, 1);
x_921 = lean_ctor_get(x_614, 2);
x_922 = lean_ctor_get(x_4, 1);
x_923 = lean_ctor_get(x_4, 2);
lean_dec(x_923);
x_924 = lean_ctor_get(x_4, 0);
lean_dec(x_924);
lean_ctor_set(x_4, 2, x_921);
lean_ctor_set(x_4, 1, x_920);
lean_ctor_set(x_4, 0, x_919);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_912);
lean_ctor_set(x_614, 2, x_892);
lean_ctor_set(x_614, 1, x_922);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_912);
x_5 = x_914;
x_6 = x_915;
x_7 = x_916;
x_8 = x_913;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_925; lean_object* x_926; lean_object* x_927; lean_object* x_928; lean_object* x_929; 
x_925 = lean_ctor_get(x_614, 0);
x_926 = lean_ctor_get(x_614, 1);
x_927 = lean_ctor_get(x_614, 2);
x_928 = lean_ctor_get(x_4, 1);
lean_inc(x_928);
lean_dec(x_4);
x_929 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_929, 0, x_925);
lean_ctor_set(x_929, 1, x_926);
lean_ctor_set(x_929, 2, x_927);
lean_ctor_set_uint8(x_929, sizeof(void*)*3, x_912);
lean_ctor_set(x_614, 2, x_892);
lean_ctor_set(x_614, 1, x_928);
lean_ctor_set(x_614, 0, x_729);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_912);
x_5 = x_914;
x_6 = x_915;
x_7 = x_916;
x_8 = x_913;
x_9 = x_929;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_930; lean_object* x_931; lean_object* x_932; lean_object* x_933; lean_object* x_934; lean_object* x_935; lean_object* x_936; 
x_930 = lean_ctor_get(x_614, 0);
x_931 = lean_ctor_get(x_614, 1);
x_932 = lean_ctor_get(x_614, 2);
lean_inc(x_932);
lean_inc(x_931);
lean_inc(x_930);
lean_dec(x_614);
x_933 = lean_ctor_get(x_4, 1);
lean_inc(x_933);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_934 = x_4;
} else {
 lean_dec_ref(x_4);
 x_934 = lean_box(0);
}
if (lean_is_scalar(x_934)) {
 x_935 = lean_alloc_ctor(1, 3, 1);
} else {
 x_935 = x_934;
}
lean_ctor_set(x_935, 0, x_930);
lean_ctor_set(x_935, 1, x_931);
lean_ctor_set(x_935, 2, x_932);
lean_ctor_set_uint8(x_935, sizeof(void*)*3, x_912);
x_936 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_936, 0, x_729);
lean_ctor_set(x_936, 1, x_933);
lean_ctor_set(x_936, 2, x_892);
lean_ctor_set_uint8(x_936, sizeof(void*)*3, x_912);
x_5 = x_914;
x_6 = x_915;
x_7 = x_916;
x_8 = x_913;
x_9 = x_935;
x_10 = x_3;
x_11 = x_936;
goto block_16;
}
}
else
{
lean_object* x_937; lean_object* x_938; lean_object* x_939; lean_object* x_940; uint8_t x_941; 
x_937 = lean_ctor_get(x_2, 1);
lean_inc(x_937);
lean_dec_ref(x_2);
x_938 = lean_ctor_get(x_86, 0);
lean_inc(x_938);
x_939 = lean_ctor_get(x_86, 1);
lean_inc(x_939);
x_940 = lean_ctor_get(x_86, 2);
lean_inc(x_940);
lean_dec_ref(x_86);
x_941 = !lean_is_exclusive(x_614);
if (x_941 == 0)
{
uint8_t x_942; 
x_942 = !lean_is_exclusive(x_4);
if (x_942 == 0)
{
lean_object* x_943; lean_object* x_944; lean_object* x_945; lean_object* x_946; lean_object* x_947; lean_object* x_948; uint8_t x_949; 
x_943 = lean_ctor_get(x_614, 0);
x_944 = lean_ctor_get(x_614, 1);
x_945 = lean_ctor_get(x_614, 2);
x_946 = lean_ctor_get(x_4, 1);
x_947 = lean_ctor_get(x_4, 2);
lean_dec(x_947);
x_948 = lean_ctor_get(x_4, 0);
lean_dec(x_948);
x_949 = !lean_is_exclusive(x_729);
if (x_949 == 0)
{
lean_object* x_950; lean_object* x_951; lean_object* x_952; 
x_950 = lean_ctor_get(x_729, 0);
x_951 = lean_ctor_get(x_729, 1);
x_952 = lean_ctor_get(x_729, 2);
lean_ctor_set(x_729, 2, x_945);
lean_ctor_set(x_729, 1, x_944);
lean_ctor_set(x_729, 0, x_943);
lean_ctor_set_uint8(x_729, sizeof(void*)*3, x_728);
lean_ctor_set(x_4, 2, x_952);
lean_ctor_set(x_4, 1, x_951);
lean_ctor_set(x_4, 0, x_950);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_912);
lean_ctor_set(x_614, 2, x_892);
lean_ctor_set(x_614, 1, x_946);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_728);
x_5 = x_938;
x_6 = x_939;
x_7 = x_940;
x_8 = x_937;
x_9 = x_729;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_953; lean_object* x_954; lean_object* x_955; lean_object* x_956; 
x_953 = lean_ctor_get(x_729, 0);
x_954 = lean_ctor_get(x_729, 1);
x_955 = lean_ctor_get(x_729, 2);
lean_inc(x_955);
lean_inc(x_954);
lean_inc(x_953);
lean_dec(x_729);
x_956 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_956, 0, x_943);
lean_ctor_set(x_956, 1, x_944);
lean_ctor_set(x_956, 2, x_945);
lean_ctor_set_uint8(x_956, sizeof(void*)*3, x_728);
lean_ctor_set(x_4, 2, x_955);
lean_ctor_set(x_4, 1, x_954);
lean_ctor_set(x_4, 0, x_953);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_912);
lean_ctor_set(x_614, 2, x_892);
lean_ctor_set(x_614, 1, x_946);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_728);
x_5 = x_938;
x_6 = x_939;
x_7 = x_940;
x_8 = x_937;
x_9 = x_956;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_957; lean_object* x_958; lean_object* x_959; lean_object* x_960; lean_object* x_961; lean_object* x_962; lean_object* x_963; lean_object* x_964; lean_object* x_965; lean_object* x_966; 
x_957 = lean_ctor_get(x_614, 0);
x_958 = lean_ctor_get(x_614, 1);
x_959 = lean_ctor_get(x_614, 2);
x_960 = lean_ctor_get(x_4, 1);
lean_inc(x_960);
lean_dec(x_4);
x_961 = lean_ctor_get(x_729, 0);
lean_inc(x_961);
x_962 = lean_ctor_get(x_729, 1);
lean_inc(x_962);
x_963 = lean_ctor_get(x_729, 2);
lean_inc(x_963);
if (lean_is_exclusive(x_729)) {
 lean_ctor_release(x_729, 0);
 lean_ctor_release(x_729, 1);
 lean_ctor_release(x_729, 2);
 x_964 = x_729;
} else {
 lean_dec_ref(x_729);
 x_964 = lean_box(0);
}
if (lean_is_scalar(x_964)) {
 x_965 = lean_alloc_ctor(1, 3, 1);
} else {
 x_965 = x_964;
}
lean_ctor_set(x_965, 0, x_957);
lean_ctor_set(x_965, 1, x_958);
lean_ctor_set(x_965, 2, x_959);
lean_ctor_set_uint8(x_965, sizeof(void*)*3, x_728);
x_966 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_966, 0, x_961);
lean_ctor_set(x_966, 1, x_962);
lean_ctor_set(x_966, 2, x_963);
lean_ctor_set_uint8(x_966, sizeof(void*)*3, x_912);
lean_ctor_set(x_614, 2, x_892);
lean_ctor_set(x_614, 1, x_960);
lean_ctor_set(x_614, 0, x_966);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_728);
x_5 = x_938;
x_6 = x_939;
x_7 = x_940;
x_8 = x_937;
x_9 = x_965;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_967; lean_object* x_968; lean_object* x_969; lean_object* x_970; lean_object* x_971; lean_object* x_972; lean_object* x_973; lean_object* x_974; lean_object* x_975; lean_object* x_976; lean_object* x_977; lean_object* x_978; 
x_967 = lean_ctor_get(x_614, 0);
x_968 = lean_ctor_get(x_614, 1);
x_969 = lean_ctor_get(x_614, 2);
lean_inc(x_969);
lean_inc(x_968);
lean_inc(x_967);
lean_dec(x_614);
x_970 = lean_ctor_get(x_4, 1);
lean_inc(x_970);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_971 = x_4;
} else {
 lean_dec_ref(x_4);
 x_971 = lean_box(0);
}
x_972 = lean_ctor_get(x_729, 0);
lean_inc(x_972);
x_973 = lean_ctor_get(x_729, 1);
lean_inc(x_973);
x_974 = lean_ctor_get(x_729, 2);
lean_inc(x_974);
if (lean_is_exclusive(x_729)) {
 lean_ctor_release(x_729, 0);
 lean_ctor_release(x_729, 1);
 lean_ctor_release(x_729, 2);
 x_975 = x_729;
} else {
 lean_dec_ref(x_729);
 x_975 = lean_box(0);
}
if (lean_is_scalar(x_975)) {
 x_976 = lean_alloc_ctor(1, 3, 1);
} else {
 x_976 = x_975;
}
lean_ctor_set(x_976, 0, x_967);
lean_ctor_set(x_976, 1, x_968);
lean_ctor_set(x_976, 2, x_969);
lean_ctor_set_uint8(x_976, sizeof(void*)*3, x_728);
if (lean_is_scalar(x_971)) {
 x_977 = lean_alloc_ctor(1, 3, 1);
} else {
 x_977 = x_971;
}
lean_ctor_set(x_977, 0, x_972);
lean_ctor_set(x_977, 1, x_973);
lean_ctor_set(x_977, 2, x_974);
lean_ctor_set_uint8(x_977, sizeof(void*)*3, x_912);
x_978 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_978, 0, x_977);
lean_ctor_set(x_978, 1, x_970);
lean_ctor_set(x_978, 2, x_892);
lean_ctor_set_uint8(x_978, sizeof(void*)*3, x_728);
x_5 = x_938;
x_6 = x_939;
x_7 = x_940;
x_8 = x_937;
x_9 = x_976;
x_10 = x_3;
x_11 = x_978;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_979; lean_object* x_980; lean_object* x_981; lean_object* x_982; 
x_979 = lean_ctor_get(x_2, 1);
lean_inc(x_979);
lean_dec_ref(x_2);
x_980 = lean_ctor_get(x_86, 0);
lean_inc(x_980);
x_981 = lean_ctor_get(x_86, 1);
lean_inc(x_981);
x_982 = lean_ctor_get(x_86, 2);
lean_inc(x_982);
lean_dec_ref(x_86);
x_5 = x_980;
x_6 = x_981;
x_7 = x_982;
x_8 = x_979;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
else
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_983; lean_object* x_984; lean_object* x_985; lean_object* x_986; 
x_983 = lean_ctor_get(x_2, 1);
lean_inc(x_983);
lean_dec_ref(x_2);
x_984 = lean_ctor_get(x_86, 0);
lean_inc(x_984);
x_985 = lean_ctor_get(x_86, 1);
lean_inc(x_985);
x_986 = lean_ctor_get(x_86, 2);
lean_inc(x_986);
lean_dec_ref(x_86);
x_5 = x_984;
x_6 = x_985;
x_7 = x_986;
x_8 = x_983;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_987; 
x_987 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_987 == 0)
{
lean_object* x_988; 
x_988 = lean_ctor_get(x_4, 0);
lean_inc(x_988);
if (lean_obj_tag(x_988) == 0)
{
lean_object* x_989; 
x_989 = lean_ctor_get(x_4, 2);
lean_inc(x_989);
if (lean_obj_tag(x_989) == 0)
{
lean_object* x_990; lean_object* x_991; lean_object* x_992; lean_object* x_993; uint8_t x_994; 
x_990 = lean_ctor_get(x_2, 1);
lean_inc(x_990);
lean_dec_ref(x_2);
x_991 = lean_ctor_get(x_86, 0);
lean_inc(x_991);
x_992 = lean_ctor_get(x_86, 1);
lean_inc(x_992);
x_993 = lean_ctor_get(x_86, 2);
lean_inc(x_993);
lean_dec_ref(x_86);
x_994 = !lean_is_exclusive(x_4);
if (x_994 == 0)
{
lean_object* x_995; lean_object* x_996; 
x_995 = lean_ctor_get(x_4, 2);
lean_dec(x_995);
x_996 = lean_ctor_get(x_4, 0);
lean_dec(x_996);
lean_ctor_set(x_4, 0, x_989);
x_5 = x_991;
x_6 = x_992;
x_7 = x_993;
x_8 = x_990;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_997; lean_object* x_998; 
x_997 = lean_ctor_get(x_4, 1);
lean_inc(x_997);
lean_dec(x_4);
x_998 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_998, 0, x_989);
lean_ctor_set(x_998, 1, x_997);
lean_ctor_set(x_998, 2, x_989);
lean_ctor_set_uint8(x_998, sizeof(void*)*3, x_987);
x_5 = x_991;
x_6 = x_992;
x_7 = x_993;
x_8 = x_990;
x_9 = x_614;
x_10 = x_3;
x_11 = x_998;
goto block_16;
}
}
else
{
uint8_t x_999; 
x_999 = lean_ctor_get_uint8(x_989, sizeof(void*)*3);
if (x_999 == 0)
{
lean_object* x_1000; lean_object* x_1001; lean_object* x_1002; lean_object* x_1003; uint8_t x_1004; 
x_1000 = lean_ctor_get(x_2, 1);
lean_inc(x_1000);
lean_dec_ref(x_2);
x_1001 = lean_ctor_get(x_86, 0);
lean_inc(x_1001);
x_1002 = lean_ctor_get(x_86, 1);
lean_inc(x_1002);
x_1003 = lean_ctor_get(x_86, 2);
lean_inc(x_1003);
lean_dec_ref(x_86);
x_1004 = !lean_is_exclusive(x_4);
if (x_1004 == 0)
{
lean_object* x_1005; lean_object* x_1006; 
x_1005 = lean_ctor_get(x_4, 2);
lean_dec(x_1005);
x_1006 = lean_ctor_get(x_4, 0);
lean_dec(x_1006);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_999);
x_5 = x_1001;
x_6 = x_1002;
x_7 = x_1003;
x_8 = x_1000;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1007; lean_object* x_1008; 
x_1007 = lean_ctor_get(x_4, 1);
lean_inc(x_1007);
lean_dec(x_4);
x_1008 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1008, 0, x_988);
lean_ctor_set(x_1008, 1, x_1007);
lean_ctor_set(x_1008, 2, x_989);
lean_ctor_set_uint8(x_1008, sizeof(void*)*3, x_999);
x_5 = x_1001;
x_6 = x_1002;
x_7 = x_1003;
x_8 = x_1000;
x_9 = x_614;
x_10 = x_3;
x_11 = x_1008;
goto block_16;
}
}
else
{
uint8_t x_1009; 
x_1009 = !lean_is_exclusive(x_989);
if (x_1009 == 0)
{
lean_object* x_1010; lean_object* x_1011; lean_object* x_1012; lean_object* x_1013; lean_object* x_1014; lean_object* x_1015; lean_object* x_1016; lean_object* x_1017; lean_object* x_1018; lean_object* x_1019; 
x_1010 = lean_ctor_get(x_989, 2);
lean_dec(x_1010);
x_1011 = lean_ctor_get(x_989, 1);
lean_dec(x_1011);
x_1012 = lean_ctor_get(x_989, 0);
lean_dec(x_1012);
x_1013 = lean_ctor_get(x_2, 1);
lean_inc(x_1013);
lean_dec_ref(x_2);
x_1014 = lean_ctor_get(x_86, 0);
lean_inc(x_1014);
x_1015 = lean_ctor_get(x_86, 1);
lean_inc(x_1015);
x_1016 = lean_ctor_get(x_86, 2);
lean_inc(x_1016);
lean_dec_ref(x_86);
x_1017 = lean_ctor_get(x_614, 0);
lean_inc(x_1017);
x_1018 = lean_ctor_get(x_614, 1);
lean_inc(x_1018);
x_1019 = lean_ctor_get(x_614, 2);
lean_inc(x_1019);
lean_dec_ref(x_614);
lean_ctor_set(x_989, 2, x_1019);
lean_ctor_set(x_989, 1, x_1018);
lean_ctor_set(x_989, 0, x_1017);
x_5 = x_1014;
x_6 = x_1015;
x_7 = x_1016;
x_8 = x_1013;
x_9 = x_989;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1020; lean_object* x_1021; lean_object* x_1022; lean_object* x_1023; lean_object* x_1024; lean_object* x_1025; lean_object* x_1026; lean_object* x_1027; 
lean_dec(x_989);
x_1020 = lean_ctor_get(x_2, 1);
lean_inc(x_1020);
lean_dec_ref(x_2);
x_1021 = lean_ctor_get(x_86, 0);
lean_inc(x_1021);
x_1022 = lean_ctor_get(x_86, 1);
lean_inc(x_1022);
x_1023 = lean_ctor_get(x_86, 2);
lean_inc(x_1023);
lean_dec_ref(x_86);
x_1024 = lean_ctor_get(x_614, 0);
lean_inc(x_1024);
x_1025 = lean_ctor_get(x_614, 1);
lean_inc(x_1025);
x_1026 = lean_ctor_get(x_614, 2);
lean_inc(x_1026);
lean_dec_ref(x_614);
x_1027 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1027, 0, x_1024);
lean_ctor_set(x_1027, 1, x_1025);
lean_ctor_set(x_1027, 2, x_1026);
lean_ctor_set_uint8(x_1027, sizeof(void*)*3, x_999);
x_5 = x_1021;
x_6 = x_1022;
x_7 = x_1023;
x_8 = x_1020;
x_9 = x_1027;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
}
else
{
uint8_t x_1028; 
x_1028 = lean_ctor_get_uint8(x_988, sizeof(void*)*3);
if (x_1028 == 0)
{
lean_object* x_1029; 
x_1029 = lean_ctor_get(x_4, 2);
lean_inc(x_1029);
if (lean_obj_tag(x_1029) == 0)
{
lean_object* x_1030; lean_object* x_1031; lean_object* x_1032; lean_object* x_1033; uint8_t x_1034; 
x_1030 = lean_ctor_get(x_2, 1);
lean_inc(x_1030);
lean_dec_ref(x_2);
x_1031 = lean_ctor_get(x_86, 0);
lean_inc(x_1031);
x_1032 = lean_ctor_get(x_86, 1);
lean_inc(x_1032);
x_1033 = lean_ctor_get(x_86, 2);
lean_inc(x_1033);
lean_dec_ref(x_86);
x_1034 = !lean_is_exclusive(x_4);
if (x_1034 == 0)
{
lean_object* x_1035; lean_object* x_1036; 
x_1035 = lean_ctor_get(x_4, 2);
lean_dec(x_1035);
x_1036 = lean_ctor_get(x_4, 0);
lean_dec(x_1036);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1028);
x_5 = x_1031;
x_6 = x_1032;
x_7 = x_1033;
x_8 = x_1030;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1037; lean_object* x_1038; 
x_1037 = lean_ctor_get(x_4, 1);
lean_inc(x_1037);
lean_dec(x_4);
x_1038 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1038, 0, x_988);
lean_ctor_set(x_1038, 1, x_1037);
lean_ctor_set(x_1038, 2, x_1029);
lean_ctor_set_uint8(x_1038, sizeof(void*)*3, x_1028);
x_5 = x_1031;
x_6 = x_1032;
x_7 = x_1033;
x_8 = x_1030;
x_9 = x_614;
x_10 = x_3;
x_11 = x_1038;
goto block_16;
}
}
else
{
uint8_t x_1039; 
x_1039 = lean_ctor_get_uint8(x_1029, sizeof(void*)*3);
if (x_1039 == 0)
{
lean_object* x_1040; lean_object* x_1041; lean_object* x_1042; lean_object* x_1043; uint8_t x_1044; 
x_1040 = lean_ctor_get(x_2, 1);
lean_inc(x_1040);
lean_dec_ref(x_2);
x_1041 = lean_ctor_get(x_86, 0);
lean_inc(x_1041);
x_1042 = lean_ctor_get(x_86, 1);
lean_inc(x_1042);
x_1043 = lean_ctor_get(x_86, 2);
lean_inc(x_1043);
lean_dec_ref(x_86);
x_1044 = !lean_is_exclusive(x_4);
if (x_1044 == 0)
{
lean_object* x_1045; lean_object* x_1046; uint8_t x_1047; 
x_1045 = lean_ctor_get(x_4, 2);
lean_dec(x_1045);
x_1046 = lean_ctor_get(x_4, 0);
lean_dec(x_1046);
x_1047 = !lean_is_exclusive(x_988);
if (x_1047 == 0)
{
lean_ctor_set_uint8(x_988, sizeof(void*)*3, x_1039);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1039);
x_5 = x_1041;
x_6 = x_1042;
x_7 = x_1043;
x_8 = x_1040;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1048; lean_object* x_1049; lean_object* x_1050; lean_object* x_1051; 
x_1048 = lean_ctor_get(x_988, 0);
x_1049 = lean_ctor_get(x_988, 1);
x_1050 = lean_ctor_get(x_988, 2);
lean_inc(x_1050);
lean_inc(x_1049);
lean_inc(x_1048);
lean_dec(x_988);
x_1051 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1051, 0, x_1048);
lean_ctor_set(x_1051, 1, x_1049);
lean_ctor_set(x_1051, 2, x_1050);
lean_ctor_set_uint8(x_1051, sizeof(void*)*3, x_1039);
lean_ctor_set(x_4, 0, x_1051);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1039);
x_5 = x_1041;
x_6 = x_1042;
x_7 = x_1043;
x_8 = x_1040;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_1052; lean_object* x_1053; lean_object* x_1054; lean_object* x_1055; lean_object* x_1056; lean_object* x_1057; lean_object* x_1058; 
x_1052 = lean_ctor_get(x_4, 1);
lean_inc(x_1052);
lean_dec(x_4);
x_1053 = lean_ctor_get(x_988, 0);
lean_inc(x_1053);
x_1054 = lean_ctor_get(x_988, 1);
lean_inc(x_1054);
x_1055 = lean_ctor_get(x_988, 2);
lean_inc(x_1055);
if (lean_is_exclusive(x_988)) {
 lean_ctor_release(x_988, 0);
 lean_ctor_release(x_988, 1);
 lean_ctor_release(x_988, 2);
 x_1056 = x_988;
} else {
 lean_dec_ref(x_988);
 x_1056 = lean_box(0);
}
if (lean_is_scalar(x_1056)) {
 x_1057 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1057 = x_1056;
}
lean_ctor_set(x_1057, 0, x_1053);
lean_ctor_set(x_1057, 1, x_1054);
lean_ctor_set(x_1057, 2, x_1055);
lean_ctor_set_uint8(x_1057, sizeof(void*)*3, x_1039);
x_1058 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1058, 0, x_1057);
lean_ctor_set(x_1058, 1, x_1052);
lean_ctor_set(x_1058, 2, x_1029);
lean_ctor_set_uint8(x_1058, sizeof(void*)*3, x_1039);
x_5 = x_1041;
x_6 = x_1042;
x_7 = x_1043;
x_8 = x_1040;
x_9 = x_614;
x_10 = x_3;
x_11 = x_1058;
goto block_16;
}
}
else
{
lean_object* x_1059; lean_object* x_1060; lean_object* x_1061; lean_object* x_1062; uint8_t x_1063; 
x_1059 = lean_ctor_get(x_2, 1);
lean_inc(x_1059);
lean_dec_ref(x_2);
x_1060 = lean_ctor_get(x_86, 0);
lean_inc(x_1060);
x_1061 = lean_ctor_get(x_86, 1);
lean_inc(x_1061);
x_1062 = lean_ctor_get(x_86, 2);
lean_inc(x_1062);
lean_dec_ref(x_86);
x_1063 = !lean_is_exclusive(x_614);
if (x_1063 == 0)
{
uint8_t x_1064; 
x_1064 = !lean_is_exclusive(x_4);
if (x_1064 == 0)
{
lean_object* x_1065; lean_object* x_1066; lean_object* x_1067; lean_object* x_1068; lean_object* x_1069; lean_object* x_1070; 
x_1065 = lean_ctor_get(x_614, 0);
x_1066 = lean_ctor_get(x_614, 1);
x_1067 = lean_ctor_get(x_614, 2);
x_1068 = lean_ctor_get(x_4, 1);
x_1069 = lean_ctor_get(x_4, 2);
lean_dec(x_1069);
x_1070 = lean_ctor_get(x_4, 0);
lean_dec(x_1070);
lean_ctor_set(x_4, 2, x_1067);
lean_ctor_set(x_4, 1, x_1066);
lean_ctor_set(x_4, 0, x_1065);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1039);
lean_ctor_set(x_614, 2, x_1029);
lean_ctor_set(x_614, 1, x_1068);
lean_ctor_set(x_614, 0, x_988);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_1028);
x_5 = x_1060;
x_6 = x_1061;
x_7 = x_1062;
x_8 = x_1059;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_1071; lean_object* x_1072; lean_object* x_1073; lean_object* x_1074; lean_object* x_1075; 
x_1071 = lean_ctor_get(x_614, 0);
x_1072 = lean_ctor_get(x_614, 1);
x_1073 = lean_ctor_get(x_614, 2);
x_1074 = lean_ctor_get(x_4, 1);
lean_inc(x_1074);
lean_dec(x_4);
x_1075 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1075, 0, x_1071);
lean_ctor_set(x_1075, 1, x_1072);
lean_ctor_set(x_1075, 2, x_1073);
lean_ctor_set_uint8(x_1075, sizeof(void*)*3, x_1039);
lean_ctor_set(x_614, 2, x_1029);
lean_ctor_set(x_614, 1, x_1074);
lean_ctor_set(x_614, 0, x_988);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_1028);
x_5 = x_1060;
x_6 = x_1061;
x_7 = x_1062;
x_8 = x_1059;
x_9 = x_1075;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_1076; lean_object* x_1077; lean_object* x_1078; lean_object* x_1079; lean_object* x_1080; lean_object* x_1081; lean_object* x_1082; 
x_1076 = lean_ctor_get(x_614, 0);
x_1077 = lean_ctor_get(x_614, 1);
x_1078 = lean_ctor_get(x_614, 2);
lean_inc(x_1078);
lean_inc(x_1077);
lean_inc(x_1076);
lean_dec(x_614);
x_1079 = lean_ctor_get(x_4, 1);
lean_inc(x_1079);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1080 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1080 = lean_box(0);
}
if (lean_is_scalar(x_1080)) {
 x_1081 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1081 = x_1080;
}
lean_ctor_set(x_1081, 0, x_1076);
lean_ctor_set(x_1081, 1, x_1077);
lean_ctor_set(x_1081, 2, x_1078);
lean_ctor_set_uint8(x_1081, sizeof(void*)*3, x_1039);
x_1082 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1082, 0, x_988);
lean_ctor_set(x_1082, 1, x_1079);
lean_ctor_set(x_1082, 2, x_1029);
lean_ctor_set_uint8(x_1082, sizeof(void*)*3, x_1028);
x_5 = x_1060;
x_6 = x_1061;
x_7 = x_1062;
x_8 = x_1059;
x_9 = x_1081;
x_10 = x_3;
x_11 = x_1082;
goto block_16;
}
}
}
}
else
{
lean_object* x_1083; 
x_1083 = lean_ctor_get(x_4, 2);
if (lean_obj_tag(x_1083) == 0)
{
uint8_t x_1084; 
x_1084 = !lean_is_exclusive(x_988);
if (x_1084 == 0)
{
lean_object* x_1085; lean_object* x_1086; lean_object* x_1087; lean_object* x_1088; lean_object* x_1089; lean_object* x_1090; lean_object* x_1091; lean_object* x_1092; lean_object* x_1093; lean_object* x_1094; 
x_1085 = lean_ctor_get(x_988, 2);
lean_dec(x_1085);
x_1086 = lean_ctor_get(x_988, 1);
lean_dec(x_1086);
x_1087 = lean_ctor_get(x_988, 0);
lean_dec(x_1087);
x_1088 = lean_ctor_get(x_2, 1);
lean_inc(x_1088);
lean_dec_ref(x_2);
x_1089 = lean_ctor_get(x_86, 0);
lean_inc(x_1089);
x_1090 = lean_ctor_get(x_86, 1);
lean_inc(x_1090);
x_1091 = lean_ctor_get(x_86, 2);
lean_inc(x_1091);
lean_dec_ref(x_86);
x_1092 = lean_ctor_get(x_614, 0);
lean_inc(x_1092);
x_1093 = lean_ctor_get(x_614, 1);
lean_inc(x_1093);
x_1094 = lean_ctor_get(x_614, 2);
lean_inc(x_1094);
lean_dec_ref(x_614);
lean_ctor_set(x_988, 2, x_1094);
lean_ctor_set(x_988, 1, x_1093);
lean_ctor_set(x_988, 0, x_1092);
x_5 = x_1089;
x_6 = x_1090;
x_7 = x_1091;
x_8 = x_1088;
x_9 = x_988;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1095; lean_object* x_1096; lean_object* x_1097; lean_object* x_1098; lean_object* x_1099; lean_object* x_1100; lean_object* x_1101; lean_object* x_1102; 
lean_dec(x_988);
x_1095 = lean_ctor_get(x_2, 1);
lean_inc(x_1095);
lean_dec_ref(x_2);
x_1096 = lean_ctor_get(x_86, 0);
lean_inc(x_1096);
x_1097 = lean_ctor_get(x_86, 1);
lean_inc(x_1097);
x_1098 = lean_ctor_get(x_86, 2);
lean_inc(x_1098);
lean_dec_ref(x_86);
x_1099 = lean_ctor_get(x_614, 0);
lean_inc(x_1099);
x_1100 = lean_ctor_get(x_614, 1);
lean_inc(x_1100);
x_1101 = lean_ctor_get(x_614, 2);
lean_inc(x_1101);
lean_dec_ref(x_614);
x_1102 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1102, 0, x_1099);
lean_ctor_set(x_1102, 1, x_1100);
lean_ctor_set(x_1102, 2, x_1101);
lean_ctor_set_uint8(x_1102, sizeof(void*)*3, x_1028);
x_5 = x_1096;
x_6 = x_1097;
x_7 = x_1098;
x_8 = x_1095;
x_9 = x_1102;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
uint8_t x_1103; 
lean_inc_ref(x_1083);
x_1103 = lean_ctor_get_uint8(x_1083, sizeof(void*)*3);
if (x_1103 == 0)
{
lean_object* x_1104; lean_object* x_1105; lean_object* x_1106; lean_object* x_1107; uint8_t x_1108; 
x_1104 = lean_ctor_get(x_2, 1);
lean_inc(x_1104);
lean_dec_ref(x_2);
x_1105 = lean_ctor_get(x_86, 0);
lean_inc(x_1105);
x_1106 = lean_ctor_get(x_86, 1);
lean_inc(x_1106);
x_1107 = lean_ctor_get(x_86, 2);
lean_inc(x_1107);
lean_dec_ref(x_86);
x_1108 = !lean_is_exclusive(x_614);
if (x_1108 == 0)
{
uint8_t x_1109; 
x_1109 = !lean_is_exclusive(x_4);
if (x_1109 == 0)
{
lean_object* x_1110; lean_object* x_1111; lean_object* x_1112; lean_object* x_1113; lean_object* x_1114; lean_object* x_1115; 
x_1110 = lean_ctor_get(x_614, 0);
x_1111 = lean_ctor_get(x_614, 1);
x_1112 = lean_ctor_get(x_614, 2);
x_1113 = lean_ctor_get(x_4, 1);
x_1114 = lean_ctor_get(x_4, 2);
lean_dec(x_1114);
x_1115 = lean_ctor_get(x_4, 0);
lean_dec(x_1115);
lean_ctor_set(x_4, 2, x_1112);
lean_ctor_set(x_4, 1, x_1111);
lean_ctor_set(x_4, 0, x_1110);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1028);
lean_ctor_set(x_614, 2, x_1083);
lean_ctor_set(x_614, 1, x_1113);
lean_ctor_set(x_614, 0, x_988);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_1103);
x_5 = x_1105;
x_6 = x_1106;
x_7 = x_1107;
x_8 = x_1104;
x_9 = x_4;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_1116; lean_object* x_1117; lean_object* x_1118; lean_object* x_1119; lean_object* x_1120; 
x_1116 = lean_ctor_get(x_614, 0);
x_1117 = lean_ctor_get(x_614, 1);
x_1118 = lean_ctor_get(x_614, 2);
x_1119 = lean_ctor_get(x_4, 1);
lean_inc(x_1119);
lean_dec(x_4);
x_1120 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1120, 0, x_1116);
lean_ctor_set(x_1120, 1, x_1117);
lean_ctor_set(x_1120, 2, x_1118);
lean_ctor_set_uint8(x_1120, sizeof(void*)*3, x_1028);
lean_ctor_set(x_614, 2, x_1083);
lean_ctor_set(x_614, 1, x_1119);
lean_ctor_set(x_614, 0, x_988);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_1103);
x_5 = x_1105;
x_6 = x_1106;
x_7 = x_1107;
x_8 = x_1104;
x_9 = x_1120;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_1121; lean_object* x_1122; lean_object* x_1123; lean_object* x_1124; lean_object* x_1125; lean_object* x_1126; lean_object* x_1127; 
x_1121 = lean_ctor_get(x_614, 0);
x_1122 = lean_ctor_get(x_614, 1);
x_1123 = lean_ctor_get(x_614, 2);
lean_inc(x_1123);
lean_inc(x_1122);
lean_inc(x_1121);
lean_dec(x_614);
x_1124 = lean_ctor_get(x_4, 1);
lean_inc(x_1124);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1125 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1125 = lean_box(0);
}
if (lean_is_scalar(x_1125)) {
 x_1126 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1126 = x_1125;
}
lean_ctor_set(x_1126, 0, x_1121);
lean_ctor_set(x_1126, 1, x_1122);
lean_ctor_set(x_1126, 2, x_1123);
lean_ctor_set_uint8(x_1126, sizeof(void*)*3, x_1028);
x_1127 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1127, 0, x_988);
lean_ctor_set(x_1127, 1, x_1124);
lean_ctor_set(x_1127, 2, x_1083);
lean_ctor_set_uint8(x_1127, sizeof(void*)*3, x_1103);
x_5 = x_1105;
x_6 = x_1106;
x_7 = x_1107;
x_8 = x_1104;
x_9 = x_1126;
x_10 = x_3;
x_11 = x_1127;
goto block_16;
}
}
else
{
lean_object* x_1128; lean_object* x_1129; lean_object* x_1130; lean_object* x_1131; uint8_t x_1132; 
x_1128 = lean_ctor_get(x_2, 1);
lean_inc(x_1128);
lean_dec_ref(x_2);
x_1129 = lean_ctor_get(x_86, 0);
lean_inc(x_1129);
x_1130 = lean_ctor_get(x_86, 1);
lean_inc(x_1130);
x_1131 = lean_ctor_get(x_86, 2);
lean_inc(x_1131);
lean_dec_ref(x_86);
x_1132 = !lean_is_exclusive(x_614);
if (x_1132 == 0)
{
uint8_t x_1133; 
x_1133 = !lean_is_exclusive(x_4);
if (x_1133 == 0)
{
lean_object* x_1134; lean_object* x_1135; lean_object* x_1136; lean_object* x_1137; lean_object* x_1138; lean_object* x_1139; uint8_t x_1140; 
x_1134 = lean_ctor_get(x_614, 0);
x_1135 = lean_ctor_get(x_614, 1);
x_1136 = lean_ctor_get(x_614, 2);
x_1137 = lean_ctor_get(x_4, 1);
x_1138 = lean_ctor_get(x_4, 2);
lean_dec(x_1138);
x_1139 = lean_ctor_get(x_4, 0);
lean_dec(x_1139);
x_1140 = !lean_is_exclusive(x_988);
if (x_1140 == 0)
{
lean_object* x_1141; lean_object* x_1142; lean_object* x_1143; 
x_1141 = lean_ctor_get(x_988, 0);
x_1142 = lean_ctor_get(x_988, 1);
x_1143 = lean_ctor_get(x_988, 2);
lean_ctor_set(x_988, 2, x_1136);
lean_ctor_set(x_988, 1, x_1135);
lean_ctor_set(x_988, 0, x_1134);
lean_ctor_set_uint8(x_988, sizeof(void*)*3, x_1103);
lean_ctor_set(x_4, 2, x_1143);
lean_ctor_set(x_4, 1, x_1142);
lean_ctor_set(x_4, 0, x_1141);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1103);
lean_ctor_set(x_614, 2, x_1083);
lean_ctor_set(x_614, 1, x_1137);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_987);
x_5 = x_1129;
x_6 = x_1130;
x_7 = x_1131;
x_8 = x_1128;
x_9 = x_988;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
else
{
lean_object* x_1144; lean_object* x_1145; lean_object* x_1146; lean_object* x_1147; 
x_1144 = lean_ctor_get(x_988, 0);
x_1145 = lean_ctor_get(x_988, 1);
x_1146 = lean_ctor_get(x_988, 2);
lean_inc(x_1146);
lean_inc(x_1145);
lean_inc(x_1144);
lean_dec(x_988);
x_1147 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1147, 0, x_1134);
lean_ctor_set(x_1147, 1, x_1135);
lean_ctor_set(x_1147, 2, x_1136);
lean_ctor_set_uint8(x_1147, sizeof(void*)*3, x_1103);
lean_ctor_set(x_4, 2, x_1146);
lean_ctor_set(x_4, 1, x_1145);
lean_ctor_set(x_4, 0, x_1144);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1103);
lean_ctor_set(x_614, 2, x_1083);
lean_ctor_set(x_614, 1, x_1137);
lean_ctor_set(x_614, 0, x_4);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_987);
x_5 = x_1129;
x_6 = x_1130;
x_7 = x_1131;
x_8 = x_1128;
x_9 = x_1147;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_1148; lean_object* x_1149; lean_object* x_1150; lean_object* x_1151; lean_object* x_1152; lean_object* x_1153; lean_object* x_1154; lean_object* x_1155; lean_object* x_1156; lean_object* x_1157; 
x_1148 = lean_ctor_get(x_614, 0);
x_1149 = lean_ctor_get(x_614, 1);
x_1150 = lean_ctor_get(x_614, 2);
x_1151 = lean_ctor_get(x_4, 1);
lean_inc(x_1151);
lean_dec(x_4);
x_1152 = lean_ctor_get(x_988, 0);
lean_inc(x_1152);
x_1153 = lean_ctor_get(x_988, 1);
lean_inc(x_1153);
x_1154 = lean_ctor_get(x_988, 2);
lean_inc(x_1154);
if (lean_is_exclusive(x_988)) {
 lean_ctor_release(x_988, 0);
 lean_ctor_release(x_988, 1);
 lean_ctor_release(x_988, 2);
 x_1155 = x_988;
} else {
 lean_dec_ref(x_988);
 x_1155 = lean_box(0);
}
if (lean_is_scalar(x_1155)) {
 x_1156 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1156 = x_1155;
}
lean_ctor_set(x_1156, 0, x_1148);
lean_ctor_set(x_1156, 1, x_1149);
lean_ctor_set(x_1156, 2, x_1150);
lean_ctor_set_uint8(x_1156, sizeof(void*)*3, x_1103);
x_1157 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1157, 0, x_1152);
lean_ctor_set(x_1157, 1, x_1153);
lean_ctor_set(x_1157, 2, x_1154);
lean_ctor_set_uint8(x_1157, sizeof(void*)*3, x_1103);
lean_ctor_set(x_614, 2, x_1083);
lean_ctor_set(x_614, 1, x_1151);
lean_ctor_set(x_614, 0, x_1157);
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_987);
x_5 = x_1129;
x_6 = x_1130;
x_7 = x_1131;
x_8 = x_1128;
x_9 = x_1156;
x_10 = x_3;
x_11 = x_614;
goto block_16;
}
}
else
{
lean_object* x_1158; lean_object* x_1159; lean_object* x_1160; lean_object* x_1161; lean_object* x_1162; lean_object* x_1163; lean_object* x_1164; lean_object* x_1165; lean_object* x_1166; lean_object* x_1167; lean_object* x_1168; lean_object* x_1169; 
x_1158 = lean_ctor_get(x_614, 0);
x_1159 = lean_ctor_get(x_614, 1);
x_1160 = lean_ctor_get(x_614, 2);
lean_inc(x_1160);
lean_inc(x_1159);
lean_inc(x_1158);
lean_dec(x_614);
x_1161 = lean_ctor_get(x_4, 1);
lean_inc(x_1161);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1162 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1162 = lean_box(0);
}
x_1163 = lean_ctor_get(x_988, 0);
lean_inc(x_1163);
x_1164 = lean_ctor_get(x_988, 1);
lean_inc(x_1164);
x_1165 = lean_ctor_get(x_988, 2);
lean_inc(x_1165);
if (lean_is_exclusive(x_988)) {
 lean_ctor_release(x_988, 0);
 lean_ctor_release(x_988, 1);
 lean_ctor_release(x_988, 2);
 x_1166 = x_988;
} else {
 lean_dec_ref(x_988);
 x_1166 = lean_box(0);
}
if (lean_is_scalar(x_1166)) {
 x_1167 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1167 = x_1166;
}
lean_ctor_set(x_1167, 0, x_1158);
lean_ctor_set(x_1167, 1, x_1159);
lean_ctor_set(x_1167, 2, x_1160);
lean_ctor_set_uint8(x_1167, sizeof(void*)*3, x_1103);
if (lean_is_scalar(x_1162)) {
 x_1168 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1168 = x_1162;
}
lean_ctor_set(x_1168, 0, x_1163);
lean_ctor_set(x_1168, 1, x_1164);
lean_ctor_set(x_1168, 2, x_1165);
lean_ctor_set_uint8(x_1168, sizeof(void*)*3, x_1103);
x_1169 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1169, 0, x_1168);
lean_ctor_set(x_1169, 1, x_1161);
lean_ctor_set(x_1169, 2, x_1083);
lean_ctor_set_uint8(x_1169, sizeof(void*)*3, x_987);
x_5 = x_1129;
x_6 = x_1130;
x_7 = x_1131;
x_8 = x_1128;
x_9 = x_1167;
x_10 = x_3;
x_11 = x_1169;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_1170; lean_object* x_1171; lean_object* x_1172; lean_object* x_1173; uint8_t x_1174; 
x_1170 = lean_ctor_get(x_2, 1);
lean_inc(x_1170);
lean_dec_ref(x_2);
x_1171 = lean_ctor_get(x_86, 0);
lean_inc(x_1171);
x_1172 = lean_ctor_get(x_86, 1);
lean_inc(x_1172);
x_1173 = lean_ctor_get(x_86, 2);
lean_inc(x_1173);
lean_dec_ref(x_86);
x_1174 = !lean_is_exclusive(x_614);
if (x_1174 == 0)
{
lean_ctor_set_uint8(x_614, sizeof(void*)*3, x_987);
x_5 = x_1171;
x_6 = x_1172;
x_7 = x_1173;
x_8 = x_1170;
x_9 = x_614;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1175; lean_object* x_1176; lean_object* x_1177; lean_object* x_1178; 
x_1175 = lean_ctor_get(x_614, 0);
x_1176 = lean_ctor_get(x_614, 1);
x_1177 = lean_ctor_get(x_614, 2);
lean_inc(x_1177);
lean_inc(x_1176);
lean_inc(x_1175);
lean_dec(x_614);
x_1178 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1178, 0, x_1175);
lean_ctor_set(x_1178, 1, x_1176);
lean_ctor_set(x_1178, 2, x_1177);
lean_ctor_set_uint8(x_1178, sizeof(void*)*3, x_987);
x_5 = x_1171;
x_6 = x_1172;
x_7 = x_1173;
x_8 = x_1170;
x_9 = x_1178;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_1179; 
x_1179 = lean_ctor_get(x_2, 2);
lean_inc(x_1179);
if (lean_obj_tag(x_1179) == 0)
{
if (lean_obj_tag(x_4) == 0)
{
uint8_t x_1180; 
x_1180 = !lean_is_exclusive(x_2);
if (x_1180 == 0)
{
lean_object* x_1181; lean_object* x_1182; lean_object* x_1183; 
x_1181 = lean_ctor_get(x_2, 2);
lean_dec(x_1181);
x_1182 = lean_ctor_get(x_2, 0);
lean_dec(x_1182);
lean_ctor_set(x_2, 2, x_4);
x_1183 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1183, 0, x_2);
lean_ctor_set(x_1183, 1, x_3);
lean_ctor_set(x_1183, 2, x_4);
lean_ctor_set_uint8(x_1183, sizeof(void*)*3, x_613);
return x_1183;
}
else
{
lean_object* x_1184; lean_object* x_1185; lean_object* x_1186; 
x_1184 = lean_ctor_get(x_2, 1);
lean_inc(x_1184);
lean_dec(x_2);
x_1185 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1185, 0, x_86);
lean_ctor_set(x_1185, 1, x_1184);
lean_ctor_set(x_1185, 2, x_4);
lean_ctor_set_uint8(x_1185, sizeof(void*)*3, x_85);
x_1186 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1186, 0, x_1185);
lean_ctor_set(x_1186, 1, x_3);
lean_ctor_set(x_1186, 2, x_4);
lean_ctor_set_uint8(x_1186, sizeof(void*)*3, x_613);
return x_1186;
}
}
else
{
uint8_t x_1187; 
x_1187 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_1187 == 0)
{
lean_object* x_1188; 
x_1188 = lean_ctor_get(x_4, 0);
lean_inc(x_1188);
if (lean_obj_tag(x_1188) == 0)
{
lean_object* x_1189; 
x_1189 = lean_ctor_get(x_4, 2);
lean_inc(x_1189);
if (lean_obj_tag(x_1189) == 0)
{
uint8_t x_1190; 
x_1190 = !lean_is_exclusive(x_2);
if (x_1190 == 0)
{
lean_object* x_1191; lean_object* x_1192; lean_object* x_1193; uint8_t x_1194; 
x_1191 = lean_ctor_get(x_2, 1);
x_1192 = lean_ctor_get(x_2, 2);
lean_dec(x_1192);
x_1193 = lean_ctor_get(x_2, 0);
lean_dec(x_1193);
x_1194 = !lean_is_exclusive(x_4);
if (x_1194 == 0)
{
lean_object* x_1195; lean_object* x_1196; lean_object* x_1197; uint8_t x_1198; 
x_1195 = lean_ctor_get(x_4, 1);
x_1196 = lean_ctor_get(x_4, 2);
lean_dec(x_1196);
x_1197 = lean_ctor_get(x_4, 0);
lean_dec(x_1197);
lean_inc_ref(x_86);
lean_ctor_set(x_4, 1, x_1191);
lean_ctor_set(x_4, 0, x_86);
x_1198 = !lean_is_exclusive(x_86);
if (x_1198 == 0)
{
lean_object* x_1199; lean_object* x_1200; lean_object* x_1201; 
x_1199 = lean_ctor_get(x_86, 2);
lean_dec(x_1199);
x_1200 = lean_ctor_get(x_86, 1);
lean_dec(x_1200);
x_1201 = lean_ctor_get(x_86, 0);
lean_dec(x_1201);
lean_ctor_set(x_86, 2, x_1189);
lean_ctor_set(x_86, 1, x_1195);
lean_ctor_set(x_86, 0, x_1189);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_86);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_613);
return x_2;
}
else
{
lean_object* x_1202; 
lean_dec(x_86);
x_1202 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1202, 0, x_1189);
lean_ctor_set(x_1202, 1, x_1195);
lean_ctor_set(x_1202, 2, x_1189);
lean_ctor_set_uint8(x_1202, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_1202);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_613);
return x_2;
}
}
else
{
lean_object* x_1203; lean_object* x_1204; lean_object* x_1205; lean_object* x_1206; 
x_1203 = lean_ctor_get(x_4, 1);
lean_inc(x_1203);
lean_dec(x_4);
lean_inc_ref(x_86);
x_1204 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1204, 0, x_86);
lean_ctor_set(x_1204, 1, x_1191);
lean_ctor_set(x_1204, 2, x_1189);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1205 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1205 = lean_box(0);
}
lean_ctor_set_uint8(x_1204, sizeof(void*)*3, x_1187);
if (lean_is_scalar(x_1205)) {
 x_1206 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1206 = x_1205;
}
lean_ctor_set(x_1206, 0, x_1189);
lean_ctor_set(x_1206, 1, x_1203);
lean_ctor_set(x_1206, 2, x_1189);
lean_ctor_set_uint8(x_1206, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_1206);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_1204);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_613);
return x_2;
}
}
else
{
lean_object* x_1207; lean_object* x_1208; lean_object* x_1209; lean_object* x_1210; lean_object* x_1211; lean_object* x_1212; lean_object* x_1213; 
x_1207 = lean_ctor_get(x_2, 1);
lean_inc(x_1207);
lean_dec(x_2);
x_1208 = lean_ctor_get(x_4, 1);
lean_inc(x_1208);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1209 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1209 = lean_box(0);
}
lean_inc_ref(x_86);
if (lean_is_scalar(x_1209)) {
 x_1210 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1210 = x_1209;
}
lean_ctor_set(x_1210, 0, x_86);
lean_ctor_set(x_1210, 1, x_1207);
lean_ctor_set(x_1210, 2, x_1189);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1211 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1211 = lean_box(0);
}
lean_ctor_set_uint8(x_1210, sizeof(void*)*3, x_1187);
if (lean_is_scalar(x_1211)) {
 x_1212 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1212 = x_1211;
}
lean_ctor_set(x_1212, 0, x_1189);
lean_ctor_set(x_1212, 1, x_1208);
lean_ctor_set(x_1212, 2, x_1189);
lean_ctor_set_uint8(x_1212, sizeof(void*)*3, x_1187);
x_1213 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1213, 0, x_1210);
lean_ctor_set(x_1213, 1, x_3);
lean_ctor_set(x_1213, 2, x_1212);
lean_ctor_set_uint8(x_1213, sizeof(void*)*3, x_613);
return x_1213;
}
}
else
{
uint8_t x_1214; 
x_1214 = lean_ctor_get_uint8(x_1189, sizeof(void*)*3);
if (x_1214 == 0)
{
lean_object* x_1215; lean_object* x_1216; uint8_t x_1217; 
x_1215 = lean_ctor_get(x_2, 1);
lean_inc(x_1215);
lean_dec_ref(x_2);
x_1216 = lean_ctor_get(x_4, 1);
lean_inc(x_1216);
lean_dec_ref(x_4);
x_1217 = !lean_is_exclusive(x_1189);
if (x_1217 == 0)
{
lean_object* x_1218; lean_object* x_1219; lean_object* x_1220; 
x_1218 = lean_ctor_get(x_1189, 0);
x_1219 = lean_ctor_get(x_1189, 1);
x_1220 = lean_ctor_get(x_1189, 2);
lean_ctor_set(x_1189, 2, x_1188);
lean_ctor_set(x_1189, 1, x_1215);
lean_ctor_set(x_1189, 0, x_86);
x_5 = x_1189;
x_6 = x_3;
x_7 = x_1188;
x_8 = x_1216;
x_9 = x_1218;
x_10 = x_1219;
x_11 = x_1220;
goto block_16;
}
else
{
lean_object* x_1221; lean_object* x_1222; lean_object* x_1223; lean_object* x_1224; 
x_1221 = lean_ctor_get(x_1189, 0);
x_1222 = lean_ctor_get(x_1189, 1);
x_1223 = lean_ctor_get(x_1189, 2);
lean_inc(x_1223);
lean_inc(x_1222);
lean_inc(x_1221);
lean_dec(x_1189);
x_1224 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1224, 0, x_86);
lean_ctor_set(x_1224, 1, x_1215);
lean_ctor_set(x_1224, 2, x_1188);
lean_ctor_set_uint8(x_1224, sizeof(void*)*3, x_1214);
x_5 = x_1224;
x_6 = x_3;
x_7 = x_1188;
x_8 = x_1216;
x_9 = x_1221;
x_10 = x_1222;
x_11 = x_1223;
goto block_16;
}
}
else
{
uint8_t x_1225; 
x_1225 = !lean_is_exclusive(x_1189);
if (x_1225 == 0)
{
lean_object* x_1226; lean_object* x_1227; lean_object* x_1228; uint8_t x_1229; 
x_1226 = lean_ctor_get(x_1189, 2);
lean_dec(x_1226);
x_1227 = lean_ctor_get(x_1189, 1);
lean_dec(x_1227);
x_1228 = lean_ctor_get(x_1189, 0);
lean_dec(x_1228);
x_1229 = !lean_is_exclusive(x_2);
if (x_1229 == 0)
{
lean_object* x_1230; lean_object* x_1231; lean_object* x_1232; uint8_t x_1233; 
x_1230 = lean_ctor_get(x_2, 1);
x_1231 = lean_ctor_get(x_2, 2);
lean_dec(x_1231);
x_1232 = lean_ctor_get(x_2, 0);
lean_dec(x_1232);
x_1233 = !lean_is_exclusive(x_86);
if (x_1233 == 0)
{
lean_object* x_1234; lean_object* x_1235; lean_object* x_1236; 
x_1234 = lean_ctor_get(x_86, 0);
x_1235 = lean_ctor_get(x_86, 1);
x_1236 = lean_ctor_get(x_86, 2);
lean_ctor_set(x_1189, 2, x_1236);
lean_ctor_set(x_1189, 1, x_1235);
lean_ctor_set(x_1189, 0, x_1234);
lean_ctor_set(x_86, 2, x_1188);
lean_ctor_set(x_86, 1, x_1230);
lean_ctor_set(x_86, 0, x_1189);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1214);
return x_2;
}
else
{
lean_object* x_1237; lean_object* x_1238; lean_object* x_1239; lean_object* x_1240; 
x_1237 = lean_ctor_get(x_86, 0);
x_1238 = lean_ctor_get(x_86, 1);
x_1239 = lean_ctor_get(x_86, 2);
lean_inc(x_1239);
lean_inc(x_1238);
lean_inc(x_1237);
lean_dec(x_86);
lean_ctor_set(x_1189, 2, x_1239);
lean_ctor_set(x_1189, 1, x_1238);
lean_ctor_set(x_1189, 0, x_1237);
x_1240 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1240, 0, x_1189);
lean_ctor_set(x_1240, 1, x_1230);
lean_ctor_set(x_1240, 2, x_1188);
lean_ctor_set_uint8(x_1240, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_1240);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1214);
return x_2;
}
}
else
{
lean_object* x_1241; lean_object* x_1242; lean_object* x_1243; lean_object* x_1244; lean_object* x_1245; lean_object* x_1246; lean_object* x_1247; 
x_1241 = lean_ctor_get(x_2, 1);
lean_inc(x_1241);
lean_dec(x_2);
x_1242 = lean_ctor_get(x_86, 0);
lean_inc(x_1242);
x_1243 = lean_ctor_get(x_86, 1);
lean_inc(x_1243);
x_1244 = lean_ctor_get(x_86, 2);
lean_inc(x_1244);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1245 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1245 = lean_box(0);
}
lean_ctor_set(x_1189, 2, x_1244);
lean_ctor_set(x_1189, 1, x_1243);
lean_ctor_set(x_1189, 0, x_1242);
if (lean_is_scalar(x_1245)) {
 x_1246 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1246 = x_1245;
}
lean_ctor_set(x_1246, 0, x_1189);
lean_ctor_set(x_1246, 1, x_1241);
lean_ctor_set(x_1246, 2, x_1188);
lean_ctor_set_uint8(x_1246, sizeof(void*)*3, x_1187);
x_1247 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1247, 0, x_1246);
lean_ctor_set(x_1247, 1, x_3);
lean_ctor_set(x_1247, 2, x_4);
lean_ctor_set_uint8(x_1247, sizeof(void*)*3, x_1214);
return x_1247;
}
}
else
{
lean_object* x_1248; lean_object* x_1249; lean_object* x_1250; lean_object* x_1251; lean_object* x_1252; lean_object* x_1253; lean_object* x_1254; lean_object* x_1255; lean_object* x_1256; 
lean_dec(x_1189);
x_1248 = lean_ctor_get(x_2, 1);
lean_inc(x_1248);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_1249 = x_2;
} else {
 lean_dec_ref(x_2);
 x_1249 = lean_box(0);
}
x_1250 = lean_ctor_get(x_86, 0);
lean_inc(x_1250);
x_1251 = lean_ctor_get(x_86, 1);
lean_inc(x_1251);
x_1252 = lean_ctor_get(x_86, 2);
lean_inc(x_1252);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1253 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1253 = lean_box(0);
}
x_1254 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1254, 0, x_1250);
lean_ctor_set(x_1254, 1, x_1251);
lean_ctor_set(x_1254, 2, x_1252);
lean_ctor_set_uint8(x_1254, sizeof(void*)*3, x_1214);
if (lean_is_scalar(x_1253)) {
 x_1255 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1255 = x_1253;
}
lean_ctor_set(x_1255, 0, x_1254);
lean_ctor_set(x_1255, 1, x_1248);
lean_ctor_set(x_1255, 2, x_1188);
lean_ctor_set_uint8(x_1255, sizeof(void*)*3, x_1187);
if (lean_is_scalar(x_1249)) {
 x_1256 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1256 = x_1249;
}
lean_ctor_set(x_1256, 0, x_1255);
lean_ctor_set(x_1256, 1, x_3);
lean_ctor_set(x_1256, 2, x_4);
lean_ctor_set_uint8(x_1256, sizeof(void*)*3, x_1214);
return x_1256;
}
}
}
}
else
{
uint8_t x_1257; 
x_1257 = lean_ctor_get_uint8(x_1188, sizeof(void*)*3);
if (x_1257 == 0)
{
lean_object* x_1258; 
x_1258 = lean_ctor_get(x_4, 2);
lean_inc(x_1258);
if (lean_obj_tag(x_1258) == 0)
{
lean_object* x_1259; lean_object* x_1260; uint8_t x_1261; 
x_1259 = lean_ctor_get(x_2, 1);
lean_inc(x_1259);
lean_dec_ref(x_2);
x_1260 = lean_ctor_get(x_4, 1);
lean_inc(x_1260);
lean_dec_ref(x_4);
x_1261 = !lean_is_exclusive(x_1188);
if (x_1261 == 0)
{
lean_object* x_1262; lean_object* x_1263; lean_object* x_1264; 
x_1262 = lean_ctor_get(x_1188, 0);
x_1263 = lean_ctor_get(x_1188, 1);
x_1264 = lean_ctor_get(x_1188, 2);
lean_ctor_set(x_1188, 2, x_1258);
lean_ctor_set(x_1188, 1, x_1259);
lean_ctor_set(x_1188, 0, x_86);
x_5 = x_1188;
x_6 = x_3;
x_7 = x_1262;
x_8 = x_1263;
x_9 = x_1264;
x_10 = x_1260;
x_11 = x_1258;
goto block_16;
}
else
{
lean_object* x_1265; lean_object* x_1266; lean_object* x_1267; lean_object* x_1268; 
x_1265 = lean_ctor_get(x_1188, 0);
x_1266 = lean_ctor_get(x_1188, 1);
x_1267 = lean_ctor_get(x_1188, 2);
lean_inc(x_1267);
lean_inc(x_1266);
lean_inc(x_1265);
lean_dec(x_1188);
x_1268 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1268, 0, x_86);
lean_ctor_set(x_1268, 1, x_1259);
lean_ctor_set(x_1268, 2, x_1258);
lean_ctor_set_uint8(x_1268, sizeof(void*)*3, x_1257);
x_5 = x_1268;
x_6 = x_3;
x_7 = x_1265;
x_8 = x_1266;
x_9 = x_1267;
x_10 = x_1260;
x_11 = x_1258;
goto block_16;
}
}
else
{
uint8_t x_1269; 
x_1269 = lean_ctor_get_uint8(x_1258, sizeof(void*)*3);
if (x_1269 == 0)
{
lean_object* x_1270; lean_object* x_1271; uint8_t x_1272; 
x_1270 = lean_ctor_get(x_2, 1);
lean_inc(x_1270);
lean_dec_ref(x_2);
x_1271 = lean_ctor_get(x_4, 1);
lean_inc(x_1271);
lean_dec_ref(x_4);
x_1272 = !lean_is_exclusive(x_1188);
if (x_1272 == 0)
{
lean_object* x_1273; lean_object* x_1274; lean_object* x_1275; 
x_1273 = lean_ctor_get(x_1188, 0);
x_1274 = lean_ctor_get(x_1188, 1);
x_1275 = lean_ctor_get(x_1188, 2);
lean_ctor_set(x_1188, 2, x_1179);
lean_ctor_set(x_1188, 1, x_1270);
lean_ctor_set(x_1188, 0, x_86);
lean_ctor_set_uint8(x_1188, sizeof(void*)*3, x_1269);
x_5 = x_1188;
x_6 = x_3;
x_7 = x_1273;
x_8 = x_1274;
x_9 = x_1275;
x_10 = x_1271;
x_11 = x_1258;
goto block_16;
}
else
{
lean_object* x_1276; lean_object* x_1277; lean_object* x_1278; lean_object* x_1279; 
x_1276 = lean_ctor_get(x_1188, 0);
x_1277 = lean_ctor_get(x_1188, 1);
x_1278 = lean_ctor_get(x_1188, 2);
lean_inc(x_1278);
lean_inc(x_1277);
lean_inc(x_1276);
lean_dec(x_1188);
x_1279 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1279, 0, x_86);
lean_ctor_set(x_1279, 1, x_1270);
lean_ctor_set(x_1279, 2, x_1179);
lean_ctor_set_uint8(x_1279, sizeof(void*)*3, x_1269);
x_5 = x_1279;
x_6 = x_3;
x_7 = x_1276;
x_8 = x_1277;
x_9 = x_1278;
x_10 = x_1271;
x_11 = x_1258;
goto block_16;
}
}
else
{
lean_object* x_1280; lean_object* x_1281; lean_object* x_1282; lean_object* x_1283; uint8_t x_1284; 
x_1280 = lean_ctor_get(x_2, 1);
lean_inc(x_1280);
lean_dec_ref(x_2);
x_1281 = lean_ctor_get(x_86, 0);
lean_inc(x_1281);
x_1282 = lean_ctor_get(x_86, 1);
lean_inc(x_1282);
x_1283 = lean_ctor_get(x_86, 2);
lean_inc(x_1283);
lean_dec_ref(x_86);
x_1284 = !lean_is_exclusive(x_4);
if (x_1284 == 0)
{
lean_object* x_1285; lean_object* x_1286; lean_object* x_1287; uint8_t x_1288; 
x_1285 = lean_ctor_get(x_4, 1);
x_1286 = lean_ctor_get(x_4, 2);
lean_dec(x_1286);
x_1287 = lean_ctor_get(x_4, 0);
lean_dec(x_1287);
x_1288 = !lean_is_exclusive(x_1188);
if (x_1288 == 0)
{
lean_object* x_1289; lean_object* x_1290; lean_object* x_1291; 
x_1289 = lean_ctor_get(x_1188, 0);
x_1290 = lean_ctor_get(x_1188, 1);
x_1291 = lean_ctor_get(x_1188, 2);
lean_ctor_set(x_1188, 2, x_1283);
lean_ctor_set(x_1188, 1, x_1282);
lean_ctor_set(x_1188, 0, x_1281);
lean_ctor_set_uint8(x_1188, sizeof(void*)*3, x_1269);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1280);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1257);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1289;
x_8 = x_1290;
x_9 = x_1291;
x_10 = x_1285;
x_11 = x_1258;
goto block_16;
}
else
{
lean_object* x_1292; lean_object* x_1293; lean_object* x_1294; lean_object* x_1295; 
x_1292 = lean_ctor_get(x_1188, 0);
x_1293 = lean_ctor_get(x_1188, 1);
x_1294 = lean_ctor_get(x_1188, 2);
lean_inc(x_1294);
lean_inc(x_1293);
lean_inc(x_1292);
lean_dec(x_1188);
x_1295 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1295, 0, x_1281);
lean_ctor_set(x_1295, 1, x_1282);
lean_ctor_set(x_1295, 2, x_1283);
lean_ctor_set_uint8(x_1295, sizeof(void*)*3, x_1269);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1280);
lean_ctor_set(x_4, 0, x_1295);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1257);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1292;
x_8 = x_1293;
x_9 = x_1294;
x_10 = x_1285;
x_11 = x_1258;
goto block_16;
}
}
else
{
lean_object* x_1296; lean_object* x_1297; lean_object* x_1298; lean_object* x_1299; lean_object* x_1300; lean_object* x_1301; lean_object* x_1302; 
x_1296 = lean_ctor_get(x_4, 1);
lean_inc(x_1296);
lean_dec(x_4);
x_1297 = lean_ctor_get(x_1188, 0);
lean_inc(x_1297);
x_1298 = lean_ctor_get(x_1188, 1);
lean_inc(x_1298);
x_1299 = lean_ctor_get(x_1188, 2);
lean_inc(x_1299);
if (lean_is_exclusive(x_1188)) {
 lean_ctor_release(x_1188, 0);
 lean_ctor_release(x_1188, 1);
 lean_ctor_release(x_1188, 2);
 x_1300 = x_1188;
} else {
 lean_dec_ref(x_1188);
 x_1300 = lean_box(0);
}
if (lean_is_scalar(x_1300)) {
 x_1301 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1301 = x_1300;
}
lean_ctor_set(x_1301, 0, x_1281);
lean_ctor_set(x_1301, 1, x_1282);
lean_ctor_set(x_1301, 2, x_1283);
lean_ctor_set_uint8(x_1301, sizeof(void*)*3, x_1269);
x_1302 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1302, 0, x_1301);
lean_ctor_set(x_1302, 1, x_1280);
lean_ctor_set(x_1302, 2, x_1179);
lean_ctor_set_uint8(x_1302, sizeof(void*)*3, x_1257);
x_5 = x_1302;
x_6 = x_3;
x_7 = x_1297;
x_8 = x_1298;
x_9 = x_1299;
x_10 = x_1296;
x_11 = x_1258;
goto block_16;
}
}
}
}
else
{
lean_object* x_1303; 
x_1303 = lean_ctor_get(x_4, 2);
lean_inc(x_1303);
if (lean_obj_tag(x_1303) == 0)
{
uint8_t x_1304; 
x_1304 = !lean_is_exclusive(x_1188);
if (x_1304 == 0)
{
lean_object* x_1305; lean_object* x_1306; lean_object* x_1307; uint8_t x_1308; 
x_1305 = lean_ctor_get(x_1188, 2);
lean_dec(x_1305);
x_1306 = lean_ctor_get(x_1188, 1);
lean_dec(x_1306);
x_1307 = lean_ctor_get(x_1188, 0);
lean_dec(x_1307);
x_1308 = !lean_is_exclusive(x_2);
if (x_1308 == 0)
{
lean_object* x_1309; lean_object* x_1310; lean_object* x_1311; uint8_t x_1312; 
x_1309 = lean_ctor_get(x_2, 1);
x_1310 = lean_ctor_get(x_2, 2);
lean_dec(x_1310);
x_1311 = lean_ctor_get(x_2, 0);
lean_dec(x_1311);
x_1312 = !lean_is_exclusive(x_86);
if (x_1312 == 0)
{
lean_object* x_1313; lean_object* x_1314; lean_object* x_1315; 
x_1313 = lean_ctor_get(x_86, 0);
x_1314 = lean_ctor_get(x_86, 1);
x_1315 = lean_ctor_get(x_86, 2);
lean_ctor_set(x_1188, 2, x_1315);
lean_ctor_set(x_1188, 1, x_1314);
lean_ctor_set(x_1188, 0, x_1313);
lean_ctor_set(x_86, 2, x_1303);
lean_ctor_set(x_86, 1, x_1309);
lean_ctor_set(x_86, 0, x_1188);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1257);
return x_2;
}
else
{
lean_object* x_1316; lean_object* x_1317; lean_object* x_1318; lean_object* x_1319; 
x_1316 = lean_ctor_get(x_86, 0);
x_1317 = lean_ctor_get(x_86, 1);
x_1318 = lean_ctor_get(x_86, 2);
lean_inc(x_1318);
lean_inc(x_1317);
lean_inc(x_1316);
lean_dec(x_86);
lean_ctor_set(x_1188, 2, x_1318);
lean_ctor_set(x_1188, 1, x_1317);
lean_ctor_set(x_1188, 0, x_1316);
x_1319 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1319, 0, x_1188);
lean_ctor_set(x_1319, 1, x_1309);
lean_ctor_set(x_1319, 2, x_1303);
lean_ctor_set_uint8(x_1319, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_1319);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1257);
return x_2;
}
}
else
{
lean_object* x_1320; lean_object* x_1321; lean_object* x_1322; lean_object* x_1323; lean_object* x_1324; lean_object* x_1325; lean_object* x_1326; 
x_1320 = lean_ctor_get(x_2, 1);
lean_inc(x_1320);
lean_dec(x_2);
x_1321 = lean_ctor_get(x_86, 0);
lean_inc(x_1321);
x_1322 = lean_ctor_get(x_86, 1);
lean_inc(x_1322);
x_1323 = lean_ctor_get(x_86, 2);
lean_inc(x_1323);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1324 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1324 = lean_box(0);
}
lean_ctor_set(x_1188, 2, x_1323);
lean_ctor_set(x_1188, 1, x_1322);
lean_ctor_set(x_1188, 0, x_1321);
if (lean_is_scalar(x_1324)) {
 x_1325 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1325 = x_1324;
}
lean_ctor_set(x_1325, 0, x_1188);
lean_ctor_set(x_1325, 1, x_1320);
lean_ctor_set(x_1325, 2, x_1303);
lean_ctor_set_uint8(x_1325, sizeof(void*)*3, x_1187);
x_1326 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1326, 0, x_1325);
lean_ctor_set(x_1326, 1, x_3);
lean_ctor_set(x_1326, 2, x_4);
lean_ctor_set_uint8(x_1326, sizeof(void*)*3, x_1257);
return x_1326;
}
}
else
{
lean_object* x_1327; lean_object* x_1328; lean_object* x_1329; lean_object* x_1330; lean_object* x_1331; lean_object* x_1332; lean_object* x_1333; lean_object* x_1334; lean_object* x_1335; 
lean_dec(x_1188);
x_1327 = lean_ctor_get(x_2, 1);
lean_inc(x_1327);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_1328 = x_2;
} else {
 lean_dec_ref(x_2);
 x_1328 = lean_box(0);
}
x_1329 = lean_ctor_get(x_86, 0);
lean_inc(x_1329);
x_1330 = lean_ctor_get(x_86, 1);
lean_inc(x_1330);
x_1331 = lean_ctor_get(x_86, 2);
lean_inc(x_1331);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1332 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1332 = lean_box(0);
}
x_1333 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1333, 0, x_1329);
lean_ctor_set(x_1333, 1, x_1330);
lean_ctor_set(x_1333, 2, x_1331);
lean_ctor_set_uint8(x_1333, sizeof(void*)*3, x_1257);
if (lean_is_scalar(x_1332)) {
 x_1334 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1334 = x_1332;
}
lean_ctor_set(x_1334, 0, x_1333);
lean_ctor_set(x_1334, 1, x_1327);
lean_ctor_set(x_1334, 2, x_1303);
lean_ctor_set_uint8(x_1334, sizeof(void*)*3, x_1187);
if (lean_is_scalar(x_1328)) {
 x_1335 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1335 = x_1328;
}
lean_ctor_set(x_1335, 0, x_1334);
lean_ctor_set(x_1335, 1, x_3);
lean_ctor_set(x_1335, 2, x_4);
lean_ctor_set_uint8(x_1335, sizeof(void*)*3, x_1257);
return x_1335;
}
}
else
{
uint8_t x_1336; 
x_1336 = lean_ctor_get_uint8(x_1303, sizeof(void*)*3);
if (x_1336 == 0)
{
lean_object* x_1337; lean_object* x_1338; lean_object* x_1339; lean_object* x_1340; uint8_t x_1341; 
x_1337 = lean_ctor_get(x_2, 1);
lean_inc(x_1337);
lean_dec_ref(x_2);
x_1338 = lean_ctor_get(x_86, 0);
lean_inc(x_1338);
x_1339 = lean_ctor_get(x_86, 1);
lean_inc(x_1339);
x_1340 = lean_ctor_get(x_86, 2);
lean_inc(x_1340);
lean_dec_ref(x_86);
x_1341 = !lean_is_exclusive(x_4);
if (x_1341 == 0)
{
lean_object* x_1342; lean_object* x_1343; lean_object* x_1344; uint8_t x_1345; 
x_1342 = lean_ctor_get(x_4, 1);
x_1343 = lean_ctor_get(x_4, 2);
lean_dec(x_1343);
x_1344 = lean_ctor_get(x_4, 0);
lean_dec(x_1344);
x_1345 = !lean_is_exclusive(x_1303);
if (x_1345 == 0)
{
lean_object* x_1346; lean_object* x_1347; lean_object* x_1348; 
x_1346 = lean_ctor_get(x_1303, 0);
x_1347 = lean_ctor_get(x_1303, 1);
x_1348 = lean_ctor_get(x_1303, 2);
lean_ctor_set(x_1303, 2, x_1340);
lean_ctor_set(x_1303, 1, x_1339);
lean_ctor_set(x_1303, 0, x_1338);
lean_ctor_set_uint8(x_1303, sizeof(void*)*3, x_1257);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1337);
lean_ctor_set(x_4, 0, x_1303);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1336);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1188;
x_8 = x_1342;
x_9 = x_1346;
x_10 = x_1347;
x_11 = x_1348;
goto block_16;
}
else
{
lean_object* x_1349; lean_object* x_1350; lean_object* x_1351; lean_object* x_1352; 
x_1349 = lean_ctor_get(x_1303, 0);
x_1350 = lean_ctor_get(x_1303, 1);
x_1351 = lean_ctor_get(x_1303, 2);
lean_inc(x_1351);
lean_inc(x_1350);
lean_inc(x_1349);
lean_dec(x_1303);
x_1352 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1352, 0, x_1338);
lean_ctor_set(x_1352, 1, x_1339);
lean_ctor_set(x_1352, 2, x_1340);
lean_ctor_set_uint8(x_1352, sizeof(void*)*3, x_1257);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1337);
lean_ctor_set(x_4, 0, x_1352);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1336);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1188;
x_8 = x_1342;
x_9 = x_1349;
x_10 = x_1350;
x_11 = x_1351;
goto block_16;
}
}
else
{
lean_object* x_1353; lean_object* x_1354; lean_object* x_1355; lean_object* x_1356; lean_object* x_1357; lean_object* x_1358; lean_object* x_1359; 
x_1353 = lean_ctor_get(x_4, 1);
lean_inc(x_1353);
lean_dec(x_4);
x_1354 = lean_ctor_get(x_1303, 0);
lean_inc(x_1354);
x_1355 = lean_ctor_get(x_1303, 1);
lean_inc(x_1355);
x_1356 = lean_ctor_get(x_1303, 2);
lean_inc(x_1356);
if (lean_is_exclusive(x_1303)) {
 lean_ctor_release(x_1303, 0);
 lean_ctor_release(x_1303, 1);
 lean_ctor_release(x_1303, 2);
 x_1357 = x_1303;
} else {
 lean_dec_ref(x_1303);
 x_1357 = lean_box(0);
}
if (lean_is_scalar(x_1357)) {
 x_1358 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1358 = x_1357;
}
lean_ctor_set(x_1358, 0, x_1338);
lean_ctor_set(x_1358, 1, x_1339);
lean_ctor_set(x_1358, 2, x_1340);
lean_ctor_set_uint8(x_1358, sizeof(void*)*3, x_1257);
x_1359 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1359, 0, x_1358);
lean_ctor_set(x_1359, 1, x_1337);
lean_ctor_set(x_1359, 2, x_1179);
lean_ctor_set_uint8(x_1359, sizeof(void*)*3, x_1336);
x_5 = x_1359;
x_6 = x_3;
x_7 = x_1188;
x_8 = x_1353;
x_9 = x_1354;
x_10 = x_1355;
x_11 = x_1356;
goto block_16;
}
}
else
{
uint8_t x_1360; 
x_1360 = !lean_is_exclusive(x_2);
if (x_1360 == 0)
{
lean_object* x_1361; lean_object* x_1362; lean_object* x_1363; uint8_t x_1364; 
x_1361 = lean_ctor_get(x_2, 1);
x_1362 = lean_ctor_get(x_2, 2);
lean_dec(x_1362);
x_1363 = lean_ctor_get(x_2, 0);
lean_dec(x_1363);
x_1364 = !lean_is_exclusive(x_86);
if (x_1364 == 0)
{
uint8_t x_1365; 
x_1365 = !lean_is_exclusive(x_4);
if (x_1365 == 0)
{
lean_object* x_1366; lean_object* x_1367; lean_object* x_1368; lean_object* x_1369; lean_object* x_1370; lean_object* x_1371; uint8_t x_1372; 
x_1366 = lean_ctor_get(x_86, 0);
x_1367 = lean_ctor_get(x_86, 1);
x_1368 = lean_ctor_get(x_86, 2);
x_1369 = lean_ctor_get(x_4, 1);
x_1370 = lean_ctor_get(x_4, 2);
lean_dec(x_1370);
x_1371 = lean_ctor_get(x_4, 0);
lean_dec(x_1371);
x_1372 = !lean_is_exclusive(x_1188);
if (x_1372 == 0)
{
lean_object* x_1373; lean_object* x_1374; lean_object* x_1375; lean_object* x_1376; 
x_1373 = lean_ctor_get(x_1188, 0);
x_1374 = lean_ctor_get(x_1188, 1);
x_1375 = lean_ctor_get(x_1188, 2);
lean_ctor_set(x_1188, 2, x_1368);
lean_ctor_set(x_1188, 1, x_1367);
lean_ctor_set(x_1188, 0, x_1366);
lean_ctor_set_uint8(x_1188, sizeof(void*)*3, x_1336);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1361);
lean_ctor_set(x_86, 2, x_1375);
lean_ctor_set(x_86, 1, x_1374);
lean_ctor_set(x_86, 0, x_1373);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1336);
lean_ctor_set(x_2, 2, x_1303);
lean_ctor_set(x_2, 1, x_1369);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1187);
x_1376 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1376, 0, x_4);
lean_ctor_set(x_1376, 1, x_3);
lean_ctor_set(x_1376, 2, x_2);
lean_ctor_set_uint8(x_1376, sizeof(void*)*3, x_1336);
return x_1376;
}
else
{
lean_object* x_1377; lean_object* x_1378; lean_object* x_1379; lean_object* x_1380; lean_object* x_1381; 
x_1377 = lean_ctor_get(x_1188, 0);
x_1378 = lean_ctor_get(x_1188, 1);
x_1379 = lean_ctor_get(x_1188, 2);
lean_inc(x_1379);
lean_inc(x_1378);
lean_inc(x_1377);
lean_dec(x_1188);
x_1380 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1380, 0, x_1366);
lean_ctor_set(x_1380, 1, x_1367);
lean_ctor_set(x_1380, 2, x_1368);
lean_ctor_set_uint8(x_1380, sizeof(void*)*3, x_1336);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1361);
lean_ctor_set(x_4, 0, x_1380);
lean_ctor_set(x_86, 2, x_1379);
lean_ctor_set(x_86, 1, x_1378);
lean_ctor_set(x_86, 0, x_1377);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1336);
lean_ctor_set(x_2, 2, x_1303);
lean_ctor_set(x_2, 1, x_1369);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1187);
x_1381 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1381, 0, x_4);
lean_ctor_set(x_1381, 1, x_3);
lean_ctor_set(x_1381, 2, x_2);
lean_ctor_set_uint8(x_1381, sizeof(void*)*3, x_1336);
return x_1381;
}
}
else
{
lean_object* x_1382; lean_object* x_1383; lean_object* x_1384; lean_object* x_1385; lean_object* x_1386; lean_object* x_1387; lean_object* x_1388; lean_object* x_1389; lean_object* x_1390; lean_object* x_1391; lean_object* x_1392; 
x_1382 = lean_ctor_get(x_86, 0);
x_1383 = lean_ctor_get(x_86, 1);
x_1384 = lean_ctor_get(x_86, 2);
x_1385 = lean_ctor_get(x_4, 1);
lean_inc(x_1385);
lean_dec(x_4);
x_1386 = lean_ctor_get(x_1188, 0);
lean_inc(x_1386);
x_1387 = lean_ctor_get(x_1188, 1);
lean_inc(x_1387);
x_1388 = lean_ctor_get(x_1188, 2);
lean_inc(x_1388);
if (lean_is_exclusive(x_1188)) {
 lean_ctor_release(x_1188, 0);
 lean_ctor_release(x_1188, 1);
 lean_ctor_release(x_1188, 2);
 x_1389 = x_1188;
} else {
 lean_dec_ref(x_1188);
 x_1389 = lean_box(0);
}
if (lean_is_scalar(x_1389)) {
 x_1390 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1390 = x_1389;
}
lean_ctor_set(x_1390, 0, x_1382);
lean_ctor_set(x_1390, 1, x_1383);
lean_ctor_set(x_1390, 2, x_1384);
lean_ctor_set_uint8(x_1390, sizeof(void*)*3, x_1336);
x_1391 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1391, 0, x_1390);
lean_ctor_set(x_1391, 1, x_1361);
lean_ctor_set(x_1391, 2, x_1179);
lean_ctor_set_uint8(x_1391, sizeof(void*)*3, x_1187);
lean_ctor_set(x_86, 2, x_1388);
lean_ctor_set(x_86, 1, x_1387);
lean_ctor_set(x_86, 0, x_1386);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1336);
lean_ctor_set(x_2, 2, x_1303);
lean_ctor_set(x_2, 1, x_1385);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1187);
x_1392 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1392, 0, x_1391);
lean_ctor_set(x_1392, 1, x_3);
lean_ctor_set(x_1392, 2, x_2);
lean_ctor_set_uint8(x_1392, sizeof(void*)*3, x_1336);
return x_1392;
}
}
else
{
lean_object* x_1393; lean_object* x_1394; lean_object* x_1395; lean_object* x_1396; lean_object* x_1397; lean_object* x_1398; lean_object* x_1399; lean_object* x_1400; lean_object* x_1401; lean_object* x_1402; lean_object* x_1403; lean_object* x_1404; lean_object* x_1405; 
x_1393 = lean_ctor_get(x_86, 0);
x_1394 = lean_ctor_get(x_86, 1);
x_1395 = lean_ctor_get(x_86, 2);
lean_inc(x_1395);
lean_inc(x_1394);
lean_inc(x_1393);
lean_dec(x_86);
x_1396 = lean_ctor_get(x_4, 1);
lean_inc(x_1396);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1397 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1397 = lean_box(0);
}
x_1398 = lean_ctor_get(x_1188, 0);
lean_inc(x_1398);
x_1399 = lean_ctor_get(x_1188, 1);
lean_inc(x_1399);
x_1400 = lean_ctor_get(x_1188, 2);
lean_inc(x_1400);
if (lean_is_exclusive(x_1188)) {
 lean_ctor_release(x_1188, 0);
 lean_ctor_release(x_1188, 1);
 lean_ctor_release(x_1188, 2);
 x_1401 = x_1188;
} else {
 lean_dec_ref(x_1188);
 x_1401 = lean_box(0);
}
if (lean_is_scalar(x_1401)) {
 x_1402 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1402 = x_1401;
}
lean_ctor_set(x_1402, 0, x_1393);
lean_ctor_set(x_1402, 1, x_1394);
lean_ctor_set(x_1402, 2, x_1395);
lean_ctor_set_uint8(x_1402, sizeof(void*)*3, x_1336);
if (lean_is_scalar(x_1397)) {
 x_1403 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1403 = x_1397;
}
lean_ctor_set(x_1403, 0, x_1402);
lean_ctor_set(x_1403, 1, x_1361);
lean_ctor_set(x_1403, 2, x_1179);
lean_ctor_set_uint8(x_1403, sizeof(void*)*3, x_1187);
x_1404 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1404, 0, x_1398);
lean_ctor_set(x_1404, 1, x_1399);
lean_ctor_set(x_1404, 2, x_1400);
lean_ctor_set_uint8(x_1404, sizeof(void*)*3, x_1336);
lean_ctor_set(x_2, 2, x_1303);
lean_ctor_set(x_2, 1, x_1396);
lean_ctor_set(x_2, 0, x_1404);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1187);
x_1405 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1405, 0, x_1403);
lean_ctor_set(x_1405, 1, x_3);
lean_ctor_set(x_1405, 2, x_2);
lean_ctor_set_uint8(x_1405, sizeof(void*)*3, x_1336);
return x_1405;
}
}
else
{
lean_object* x_1406; lean_object* x_1407; lean_object* x_1408; lean_object* x_1409; lean_object* x_1410; lean_object* x_1411; lean_object* x_1412; lean_object* x_1413; lean_object* x_1414; lean_object* x_1415; lean_object* x_1416; lean_object* x_1417; lean_object* x_1418; lean_object* x_1419; lean_object* x_1420; lean_object* x_1421; 
x_1406 = lean_ctor_get(x_2, 1);
lean_inc(x_1406);
lean_dec(x_2);
x_1407 = lean_ctor_get(x_86, 0);
lean_inc(x_1407);
x_1408 = lean_ctor_get(x_86, 1);
lean_inc(x_1408);
x_1409 = lean_ctor_get(x_86, 2);
lean_inc(x_1409);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1410 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1410 = lean_box(0);
}
x_1411 = lean_ctor_get(x_4, 1);
lean_inc(x_1411);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1412 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1412 = lean_box(0);
}
x_1413 = lean_ctor_get(x_1188, 0);
lean_inc(x_1413);
x_1414 = lean_ctor_get(x_1188, 1);
lean_inc(x_1414);
x_1415 = lean_ctor_get(x_1188, 2);
lean_inc(x_1415);
if (lean_is_exclusive(x_1188)) {
 lean_ctor_release(x_1188, 0);
 lean_ctor_release(x_1188, 1);
 lean_ctor_release(x_1188, 2);
 x_1416 = x_1188;
} else {
 lean_dec_ref(x_1188);
 x_1416 = lean_box(0);
}
if (lean_is_scalar(x_1416)) {
 x_1417 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1417 = x_1416;
}
lean_ctor_set(x_1417, 0, x_1407);
lean_ctor_set(x_1417, 1, x_1408);
lean_ctor_set(x_1417, 2, x_1409);
lean_ctor_set_uint8(x_1417, sizeof(void*)*3, x_1336);
if (lean_is_scalar(x_1412)) {
 x_1418 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1418 = x_1412;
}
lean_ctor_set(x_1418, 0, x_1417);
lean_ctor_set(x_1418, 1, x_1406);
lean_ctor_set(x_1418, 2, x_1179);
lean_ctor_set_uint8(x_1418, sizeof(void*)*3, x_1187);
if (lean_is_scalar(x_1410)) {
 x_1419 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1419 = x_1410;
}
lean_ctor_set(x_1419, 0, x_1413);
lean_ctor_set(x_1419, 1, x_1414);
lean_ctor_set(x_1419, 2, x_1415);
lean_ctor_set_uint8(x_1419, sizeof(void*)*3, x_1336);
x_1420 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1420, 0, x_1419);
lean_ctor_set(x_1420, 1, x_1411);
lean_ctor_set(x_1420, 2, x_1303);
lean_ctor_set_uint8(x_1420, sizeof(void*)*3, x_1187);
x_1421 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1421, 0, x_1418);
lean_ctor_set(x_1421, 1, x_3);
lean_ctor_set(x_1421, 2, x_1420);
lean_ctor_set_uint8(x_1421, sizeof(void*)*3, x_1336);
return x_1421;
}
}
}
}
}
}
else
{
uint8_t x_1422; 
x_1422 = !lean_is_exclusive(x_2);
if (x_1422 == 0)
{
lean_object* x_1423; lean_object* x_1424; uint8_t x_1425; 
x_1423 = lean_ctor_get(x_2, 2);
lean_dec(x_1423);
x_1424 = lean_ctor_get(x_2, 0);
lean_dec(x_1424);
x_1425 = !lean_is_exclusive(x_86);
if (x_1425 == 0)
{
lean_object* x_1426; 
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1187);
x_1426 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1426, 0, x_2);
lean_ctor_set(x_1426, 1, x_3);
lean_ctor_set(x_1426, 2, x_4);
lean_ctor_set_uint8(x_1426, sizeof(void*)*3, x_1187);
return x_1426;
}
else
{
lean_object* x_1427; lean_object* x_1428; lean_object* x_1429; lean_object* x_1430; lean_object* x_1431; 
x_1427 = lean_ctor_get(x_86, 0);
x_1428 = lean_ctor_get(x_86, 1);
x_1429 = lean_ctor_get(x_86, 2);
lean_inc(x_1429);
lean_inc(x_1428);
lean_inc(x_1427);
lean_dec(x_86);
x_1430 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1430, 0, x_1427);
lean_ctor_set(x_1430, 1, x_1428);
lean_ctor_set(x_1430, 2, x_1429);
lean_ctor_set_uint8(x_1430, sizeof(void*)*3, x_1187);
lean_ctor_set(x_2, 0, x_1430);
x_1431 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1431, 0, x_2);
lean_ctor_set(x_1431, 1, x_3);
lean_ctor_set(x_1431, 2, x_4);
lean_ctor_set_uint8(x_1431, sizeof(void*)*3, x_1187);
return x_1431;
}
}
else
{
lean_object* x_1432; lean_object* x_1433; lean_object* x_1434; lean_object* x_1435; lean_object* x_1436; lean_object* x_1437; lean_object* x_1438; lean_object* x_1439; 
x_1432 = lean_ctor_get(x_2, 1);
lean_inc(x_1432);
lean_dec(x_2);
x_1433 = lean_ctor_get(x_86, 0);
lean_inc(x_1433);
x_1434 = lean_ctor_get(x_86, 1);
lean_inc(x_1434);
x_1435 = lean_ctor_get(x_86, 2);
lean_inc(x_1435);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1436 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1436 = lean_box(0);
}
if (lean_is_scalar(x_1436)) {
 x_1437 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1437 = x_1436;
}
lean_ctor_set(x_1437, 0, x_1433);
lean_ctor_set(x_1437, 1, x_1434);
lean_ctor_set(x_1437, 2, x_1435);
lean_ctor_set_uint8(x_1437, sizeof(void*)*3, x_1187);
x_1438 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1438, 0, x_1437);
lean_ctor_set(x_1438, 1, x_1432);
lean_ctor_set(x_1438, 2, x_1179);
lean_ctor_set_uint8(x_1438, sizeof(void*)*3, x_85);
x_1439 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1439, 0, x_1438);
lean_ctor_set(x_1439, 1, x_3);
lean_ctor_set(x_1439, 2, x_4);
lean_ctor_set_uint8(x_1439, sizeof(void*)*3, x_1187);
return x_1439;
}
}
}
}
else
{
uint8_t x_1440; 
x_1440 = lean_ctor_get_uint8(x_1179, sizeof(void*)*3);
if (x_1440 == 0)
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_1441; lean_object* x_1442; lean_object* x_1443; lean_object* x_1444; 
x_1441 = lean_ctor_get(x_2, 1);
lean_inc(x_1441);
lean_dec_ref(x_2);
x_1442 = lean_ctor_get(x_1179, 0);
lean_inc(x_1442);
x_1443 = lean_ctor_get(x_1179, 1);
lean_inc(x_1443);
x_1444 = lean_ctor_get(x_1179, 2);
lean_inc(x_1444);
lean_dec_ref(x_1179);
x_5 = x_86;
x_6 = x_1441;
x_7 = x_1442;
x_8 = x_1443;
x_9 = x_1444;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
uint8_t x_1445; 
x_1445 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_1445 == 0)
{
lean_object* x_1446; 
x_1446 = lean_ctor_get(x_4, 0);
lean_inc(x_1446);
if (lean_obj_tag(x_1446) == 0)
{
lean_object* x_1447; 
x_1447 = lean_ctor_get(x_4, 2);
lean_inc(x_1447);
if (lean_obj_tag(x_1447) == 0)
{
lean_object* x_1448; lean_object* x_1449; lean_object* x_1450; lean_object* x_1451; uint8_t x_1452; 
x_1448 = lean_ctor_get(x_2, 1);
lean_inc(x_1448);
lean_dec_ref(x_2);
x_1449 = lean_ctor_get(x_1179, 0);
lean_inc(x_1449);
x_1450 = lean_ctor_get(x_1179, 1);
lean_inc(x_1450);
x_1451 = lean_ctor_get(x_1179, 2);
lean_inc(x_1451);
lean_dec_ref(x_1179);
x_1452 = !lean_is_exclusive(x_4);
if (x_1452 == 0)
{
lean_object* x_1453; lean_object* x_1454; 
x_1453 = lean_ctor_get(x_4, 2);
lean_dec(x_1453);
x_1454 = lean_ctor_get(x_4, 0);
lean_dec(x_1454);
lean_ctor_set(x_4, 0, x_1447);
x_5 = x_86;
x_6 = x_1448;
x_7 = x_1449;
x_8 = x_1450;
x_9 = x_1451;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1455; lean_object* x_1456; 
x_1455 = lean_ctor_get(x_4, 1);
lean_inc(x_1455);
lean_dec(x_4);
x_1456 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1456, 0, x_1447);
lean_ctor_set(x_1456, 1, x_1455);
lean_ctor_set(x_1456, 2, x_1447);
lean_ctor_set_uint8(x_1456, sizeof(void*)*3, x_1445);
x_5 = x_86;
x_6 = x_1448;
x_7 = x_1449;
x_8 = x_1450;
x_9 = x_1451;
x_10 = x_3;
x_11 = x_1456;
goto block_16;
}
}
else
{
uint8_t x_1457; 
x_1457 = lean_ctor_get_uint8(x_1447, sizeof(void*)*3);
if (x_1457 == 0)
{
lean_object* x_1458; lean_object* x_1459; lean_object* x_1460; lean_object* x_1461; uint8_t x_1462; 
x_1458 = lean_ctor_get(x_2, 1);
lean_inc(x_1458);
lean_dec_ref(x_2);
x_1459 = lean_ctor_get(x_1179, 0);
lean_inc(x_1459);
x_1460 = lean_ctor_get(x_1179, 1);
lean_inc(x_1460);
x_1461 = lean_ctor_get(x_1179, 2);
lean_inc(x_1461);
lean_dec_ref(x_1179);
x_1462 = !lean_is_exclusive(x_4);
if (x_1462 == 0)
{
lean_object* x_1463; lean_object* x_1464; 
x_1463 = lean_ctor_get(x_4, 2);
lean_dec(x_1463);
x_1464 = lean_ctor_get(x_4, 0);
lean_dec(x_1464);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1457);
x_5 = x_86;
x_6 = x_1458;
x_7 = x_1459;
x_8 = x_1460;
x_9 = x_1461;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1465; lean_object* x_1466; 
x_1465 = lean_ctor_get(x_4, 1);
lean_inc(x_1465);
lean_dec(x_4);
x_1466 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1466, 0, x_1446);
lean_ctor_set(x_1466, 1, x_1465);
lean_ctor_set(x_1466, 2, x_1447);
lean_ctor_set_uint8(x_1466, sizeof(void*)*3, x_1457);
x_5 = x_86;
x_6 = x_1458;
x_7 = x_1459;
x_8 = x_1460;
x_9 = x_1461;
x_10 = x_3;
x_11 = x_1466;
goto block_16;
}
}
else
{
uint8_t x_1467; 
x_1467 = !lean_is_exclusive(x_1447);
if (x_1467 == 0)
{
lean_object* x_1468; lean_object* x_1469; lean_object* x_1470; lean_object* x_1471; lean_object* x_1472; lean_object* x_1473; lean_object* x_1474; lean_object* x_1475; lean_object* x_1476; lean_object* x_1477; 
x_1468 = lean_ctor_get(x_1447, 2);
lean_dec(x_1468);
x_1469 = lean_ctor_get(x_1447, 1);
lean_dec(x_1469);
x_1470 = lean_ctor_get(x_1447, 0);
lean_dec(x_1470);
x_1471 = lean_ctor_get(x_2, 1);
lean_inc(x_1471);
lean_dec_ref(x_2);
x_1472 = lean_ctor_get(x_86, 0);
lean_inc(x_1472);
x_1473 = lean_ctor_get(x_86, 1);
lean_inc(x_1473);
x_1474 = lean_ctor_get(x_86, 2);
lean_inc(x_1474);
lean_dec_ref(x_86);
x_1475 = lean_ctor_get(x_1179, 0);
lean_inc(x_1475);
x_1476 = lean_ctor_get(x_1179, 1);
lean_inc(x_1476);
x_1477 = lean_ctor_get(x_1179, 2);
lean_inc(x_1477);
lean_dec_ref(x_1179);
lean_ctor_set(x_1447, 2, x_1474);
lean_ctor_set(x_1447, 1, x_1473);
lean_ctor_set(x_1447, 0, x_1472);
x_5 = x_1447;
x_6 = x_1471;
x_7 = x_1475;
x_8 = x_1476;
x_9 = x_1477;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1478; lean_object* x_1479; lean_object* x_1480; lean_object* x_1481; lean_object* x_1482; lean_object* x_1483; lean_object* x_1484; lean_object* x_1485; 
lean_dec(x_1447);
x_1478 = lean_ctor_get(x_2, 1);
lean_inc(x_1478);
lean_dec_ref(x_2);
x_1479 = lean_ctor_get(x_86, 0);
lean_inc(x_1479);
x_1480 = lean_ctor_get(x_86, 1);
lean_inc(x_1480);
x_1481 = lean_ctor_get(x_86, 2);
lean_inc(x_1481);
lean_dec_ref(x_86);
x_1482 = lean_ctor_get(x_1179, 0);
lean_inc(x_1482);
x_1483 = lean_ctor_get(x_1179, 1);
lean_inc(x_1483);
x_1484 = lean_ctor_get(x_1179, 2);
lean_inc(x_1484);
lean_dec_ref(x_1179);
x_1485 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1485, 0, x_1479);
lean_ctor_set(x_1485, 1, x_1480);
lean_ctor_set(x_1485, 2, x_1481);
lean_ctor_set_uint8(x_1485, sizeof(void*)*3, x_1457);
x_5 = x_1485;
x_6 = x_1478;
x_7 = x_1482;
x_8 = x_1483;
x_9 = x_1484;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
}
else
{
uint8_t x_1486; 
x_1486 = lean_ctor_get_uint8(x_1446, sizeof(void*)*3);
if (x_1486 == 0)
{
lean_object* x_1487; 
x_1487 = lean_ctor_get(x_4, 2);
lean_inc(x_1487);
if (lean_obj_tag(x_1487) == 0)
{
lean_object* x_1488; lean_object* x_1489; lean_object* x_1490; lean_object* x_1491; uint8_t x_1492; 
x_1488 = lean_ctor_get(x_2, 1);
lean_inc(x_1488);
lean_dec_ref(x_2);
x_1489 = lean_ctor_get(x_1179, 0);
lean_inc(x_1489);
x_1490 = lean_ctor_get(x_1179, 1);
lean_inc(x_1490);
x_1491 = lean_ctor_get(x_1179, 2);
lean_inc(x_1491);
lean_dec_ref(x_1179);
x_1492 = !lean_is_exclusive(x_4);
if (x_1492 == 0)
{
lean_object* x_1493; lean_object* x_1494; 
x_1493 = lean_ctor_get(x_4, 2);
lean_dec(x_1493);
x_1494 = lean_ctor_get(x_4, 0);
lean_dec(x_1494);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1486);
x_5 = x_86;
x_6 = x_1488;
x_7 = x_1489;
x_8 = x_1490;
x_9 = x_1491;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1495; lean_object* x_1496; 
x_1495 = lean_ctor_get(x_4, 1);
lean_inc(x_1495);
lean_dec(x_4);
x_1496 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1496, 0, x_1446);
lean_ctor_set(x_1496, 1, x_1495);
lean_ctor_set(x_1496, 2, x_1487);
lean_ctor_set_uint8(x_1496, sizeof(void*)*3, x_1486);
x_5 = x_86;
x_6 = x_1488;
x_7 = x_1489;
x_8 = x_1490;
x_9 = x_1491;
x_10 = x_3;
x_11 = x_1496;
goto block_16;
}
}
else
{
uint8_t x_1497; 
x_1497 = lean_ctor_get_uint8(x_1487, sizeof(void*)*3);
if (x_1497 == 0)
{
lean_object* x_1498; lean_object* x_1499; lean_object* x_1500; lean_object* x_1501; uint8_t x_1502; 
x_1498 = lean_ctor_get(x_2, 1);
lean_inc(x_1498);
lean_dec_ref(x_2);
x_1499 = lean_ctor_get(x_1179, 0);
lean_inc(x_1499);
x_1500 = lean_ctor_get(x_1179, 1);
lean_inc(x_1500);
x_1501 = lean_ctor_get(x_1179, 2);
lean_inc(x_1501);
lean_dec_ref(x_1179);
x_1502 = !lean_is_exclusive(x_4);
if (x_1502 == 0)
{
lean_object* x_1503; lean_object* x_1504; uint8_t x_1505; 
x_1503 = lean_ctor_get(x_4, 2);
lean_dec(x_1503);
x_1504 = lean_ctor_get(x_4, 0);
lean_dec(x_1504);
x_1505 = !lean_is_exclusive(x_1446);
if (x_1505 == 0)
{
lean_ctor_set_uint8(x_1446, sizeof(void*)*3, x_1497);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1497);
x_5 = x_86;
x_6 = x_1498;
x_7 = x_1499;
x_8 = x_1500;
x_9 = x_1501;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1506; lean_object* x_1507; lean_object* x_1508; lean_object* x_1509; 
x_1506 = lean_ctor_get(x_1446, 0);
x_1507 = lean_ctor_get(x_1446, 1);
x_1508 = lean_ctor_get(x_1446, 2);
lean_inc(x_1508);
lean_inc(x_1507);
lean_inc(x_1506);
lean_dec(x_1446);
x_1509 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1509, 0, x_1506);
lean_ctor_set(x_1509, 1, x_1507);
lean_ctor_set(x_1509, 2, x_1508);
lean_ctor_set_uint8(x_1509, sizeof(void*)*3, x_1497);
lean_ctor_set(x_4, 0, x_1509);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1497);
x_5 = x_86;
x_6 = x_1498;
x_7 = x_1499;
x_8 = x_1500;
x_9 = x_1501;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
lean_object* x_1510; lean_object* x_1511; lean_object* x_1512; lean_object* x_1513; lean_object* x_1514; lean_object* x_1515; lean_object* x_1516; 
x_1510 = lean_ctor_get(x_4, 1);
lean_inc(x_1510);
lean_dec(x_4);
x_1511 = lean_ctor_get(x_1446, 0);
lean_inc(x_1511);
x_1512 = lean_ctor_get(x_1446, 1);
lean_inc(x_1512);
x_1513 = lean_ctor_get(x_1446, 2);
lean_inc(x_1513);
if (lean_is_exclusive(x_1446)) {
 lean_ctor_release(x_1446, 0);
 lean_ctor_release(x_1446, 1);
 lean_ctor_release(x_1446, 2);
 x_1514 = x_1446;
} else {
 lean_dec_ref(x_1446);
 x_1514 = lean_box(0);
}
if (lean_is_scalar(x_1514)) {
 x_1515 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1515 = x_1514;
}
lean_ctor_set(x_1515, 0, x_1511);
lean_ctor_set(x_1515, 1, x_1512);
lean_ctor_set(x_1515, 2, x_1513);
lean_ctor_set_uint8(x_1515, sizeof(void*)*3, x_1497);
x_1516 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1516, 0, x_1515);
lean_ctor_set(x_1516, 1, x_1510);
lean_ctor_set(x_1516, 2, x_1487);
lean_ctor_set_uint8(x_1516, sizeof(void*)*3, x_1497);
x_5 = x_86;
x_6 = x_1498;
x_7 = x_1499;
x_8 = x_1500;
x_9 = x_1501;
x_10 = x_3;
x_11 = x_1516;
goto block_16;
}
}
else
{
lean_object* x_1517; lean_object* x_1518; lean_object* x_1519; lean_object* x_1520; uint8_t x_1521; 
x_1517 = lean_ctor_get(x_2, 1);
lean_inc(x_1517);
lean_dec_ref(x_2);
x_1518 = lean_ctor_get(x_86, 0);
lean_inc(x_1518);
x_1519 = lean_ctor_get(x_86, 1);
lean_inc(x_1519);
x_1520 = lean_ctor_get(x_86, 2);
lean_inc(x_1520);
lean_dec_ref(x_86);
x_1521 = !lean_is_exclusive(x_1179);
if (x_1521 == 0)
{
uint8_t x_1522; 
x_1522 = !lean_is_exclusive(x_4);
if (x_1522 == 0)
{
lean_object* x_1523; lean_object* x_1524; lean_object* x_1525; lean_object* x_1526; lean_object* x_1527; lean_object* x_1528; 
x_1523 = lean_ctor_get(x_1179, 0);
x_1524 = lean_ctor_get(x_1179, 1);
x_1525 = lean_ctor_get(x_1179, 2);
x_1526 = lean_ctor_get(x_4, 1);
x_1527 = lean_ctor_get(x_4, 2);
lean_dec(x_1527);
x_1528 = lean_ctor_get(x_4, 0);
lean_dec(x_1528);
lean_ctor_set(x_4, 2, x_1520);
lean_ctor_set(x_4, 1, x_1519);
lean_ctor_set(x_4, 0, x_1518);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1497);
lean_ctor_set(x_1179, 2, x_1487);
lean_ctor_set(x_1179, 1, x_1526);
lean_ctor_set(x_1179, 0, x_1446);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1486);
x_5 = x_4;
x_6 = x_1517;
x_7 = x_1523;
x_8 = x_1524;
x_9 = x_1525;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
else
{
lean_object* x_1529; lean_object* x_1530; lean_object* x_1531; lean_object* x_1532; lean_object* x_1533; 
x_1529 = lean_ctor_get(x_1179, 0);
x_1530 = lean_ctor_get(x_1179, 1);
x_1531 = lean_ctor_get(x_1179, 2);
x_1532 = lean_ctor_get(x_4, 1);
lean_inc(x_1532);
lean_dec(x_4);
x_1533 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1533, 0, x_1518);
lean_ctor_set(x_1533, 1, x_1519);
lean_ctor_set(x_1533, 2, x_1520);
lean_ctor_set_uint8(x_1533, sizeof(void*)*3, x_1497);
lean_ctor_set(x_1179, 2, x_1487);
lean_ctor_set(x_1179, 1, x_1532);
lean_ctor_set(x_1179, 0, x_1446);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1486);
x_5 = x_1533;
x_6 = x_1517;
x_7 = x_1529;
x_8 = x_1530;
x_9 = x_1531;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
}
else
{
lean_object* x_1534; lean_object* x_1535; lean_object* x_1536; lean_object* x_1537; lean_object* x_1538; lean_object* x_1539; lean_object* x_1540; 
x_1534 = lean_ctor_get(x_1179, 0);
x_1535 = lean_ctor_get(x_1179, 1);
x_1536 = lean_ctor_get(x_1179, 2);
lean_inc(x_1536);
lean_inc(x_1535);
lean_inc(x_1534);
lean_dec(x_1179);
x_1537 = lean_ctor_get(x_4, 1);
lean_inc(x_1537);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1538 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1538 = lean_box(0);
}
if (lean_is_scalar(x_1538)) {
 x_1539 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1539 = x_1538;
}
lean_ctor_set(x_1539, 0, x_1518);
lean_ctor_set(x_1539, 1, x_1519);
lean_ctor_set(x_1539, 2, x_1520);
lean_ctor_set_uint8(x_1539, sizeof(void*)*3, x_1497);
x_1540 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1540, 0, x_1446);
lean_ctor_set(x_1540, 1, x_1537);
lean_ctor_set(x_1540, 2, x_1487);
lean_ctor_set_uint8(x_1540, sizeof(void*)*3, x_1486);
x_5 = x_1539;
x_6 = x_1517;
x_7 = x_1534;
x_8 = x_1535;
x_9 = x_1536;
x_10 = x_3;
x_11 = x_1540;
goto block_16;
}
}
}
}
else
{
lean_object* x_1541; 
x_1541 = lean_ctor_get(x_4, 2);
if (lean_obj_tag(x_1541) == 0)
{
uint8_t x_1542; 
x_1542 = !lean_is_exclusive(x_1446);
if (x_1542 == 0)
{
lean_object* x_1543; lean_object* x_1544; lean_object* x_1545; lean_object* x_1546; lean_object* x_1547; lean_object* x_1548; lean_object* x_1549; lean_object* x_1550; lean_object* x_1551; lean_object* x_1552; 
x_1543 = lean_ctor_get(x_1446, 2);
lean_dec(x_1543);
x_1544 = lean_ctor_get(x_1446, 1);
lean_dec(x_1544);
x_1545 = lean_ctor_get(x_1446, 0);
lean_dec(x_1545);
x_1546 = lean_ctor_get(x_2, 1);
lean_inc(x_1546);
lean_dec_ref(x_2);
x_1547 = lean_ctor_get(x_86, 0);
lean_inc(x_1547);
x_1548 = lean_ctor_get(x_86, 1);
lean_inc(x_1548);
x_1549 = lean_ctor_get(x_86, 2);
lean_inc(x_1549);
lean_dec_ref(x_86);
x_1550 = lean_ctor_get(x_1179, 0);
lean_inc(x_1550);
x_1551 = lean_ctor_get(x_1179, 1);
lean_inc(x_1551);
x_1552 = lean_ctor_get(x_1179, 2);
lean_inc(x_1552);
lean_dec_ref(x_1179);
lean_ctor_set(x_1446, 2, x_1549);
lean_ctor_set(x_1446, 1, x_1548);
lean_ctor_set(x_1446, 0, x_1547);
x_5 = x_1446;
x_6 = x_1546;
x_7 = x_1550;
x_8 = x_1551;
x_9 = x_1552;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1553; lean_object* x_1554; lean_object* x_1555; lean_object* x_1556; lean_object* x_1557; lean_object* x_1558; lean_object* x_1559; lean_object* x_1560; 
lean_dec(x_1446);
x_1553 = lean_ctor_get(x_2, 1);
lean_inc(x_1553);
lean_dec_ref(x_2);
x_1554 = lean_ctor_get(x_86, 0);
lean_inc(x_1554);
x_1555 = lean_ctor_get(x_86, 1);
lean_inc(x_1555);
x_1556 = lean_ctor_get(x_86, 2);
lean_inc(x_1556);
lean_dec_ref(x_86);
x_1557 = lean_ctor_get(x_1179, 0);
lean_inc(x_1557);
x_1558 = lean_ctor_get(x_1179, 1);
lean_inc(x_1558);
x_1559 = lean_ctor_get(x_1179, 2);
lean_inc(x_1559);
lean_dec_ref(x_1179);
x_1560 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1560, 0, x_1554);
lean_ctor_set(x_1560, 1, x_1555);
lean_ctor_set(x_1560, 2, x_1556);
lean_ctor_set_uint8(x_1560, sizeof(void*)*3, x_1486);
x_5 = x_1560;
x_6 = x_1553;
x_7 = x_1557;
x_8 = x_1558;
x_9 = x_1559;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
else
{
uint8_t x_1561; 
lean_inc_ref(x_1541);
x_1561 = lean_ctor_get_uint8(x_1541, sizeof(void*)*3);
if (x_1561 == 0)
{
lean_object* x_1562; lean_object* x_1563; lean_object* x_1564; lean_object* x_1565; uint8_t x_1566; 
x_1562 = lean_ctor_get(x_2, 1);
lean_inc(x_1562);
lean_dec_ref(x_2);
x_1563 = lean_ctor_get(x_86, 0);
lean_inc(x_1563);
x_1564 = lean_ctor_get(x_86, 1);
lean_inc(x_1564);
x_1565 = lean_ctor_get(x_86, 2);
lean_inc(x_1565);
lean_dec_ref(x_86);
x_1566 = !lean_is_exclusive(x_1179);
if (x_1566 == 0)
{
uint8_t x_1567; 
x_1567 = !lean_is_exclusive(x_4);
if (x_1567 == 0)
{
lean_object* x_1568; lean_object* x_1569; lean_object* x_1570; lean_object* x_1571; lean_object* x_1572; lean_object* x_1573; 
x_1568 = lean_ctor_get(x_1179, 0);
x_1569 = lean_ctor_get(x_1179, 1);
x_1570 = lean_ctor_get(x_1179, 2);
x_1571 = lean_ctor_get(x_4, 1);
x_1572 = lean_ctor_get(x_4, 2);
lean_dec(x_1572);
x_1573 = lean_ctor_get(x_4, 0);
lean_dec(x_1573);
lean_ctor_set(x_4, 2, x_1565);
lean_ctor_set(x_4, 1, x_1564);
lean_ctor_set(x_4, 0, x_1563);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1486);
lean_ctor_set(x_1179, 2, x_1541);
lean_ctor_set(x_1179, 1, x_1571);
lean_ctor_set(x_1179, 0, x_1446);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1561);
x_5 = x_4;
x_6 = x_1562;
x_7 = x_1568;
x_8 = x_1569;
x_9 = x_1570;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
else
{
lean_object* x_1574; lean_object* x_1575; lean_object* x_1576; lean_object* x_1577; lean_object* x_1578; 
x_1574 = lean_ctor_get(x_1179, 0);
x_1575 = lean_ctor_get(x_1179, 1);
x_1576 = lean_ctor_get(x_1179, 2);
x_1577 = lean_ctor_get(x_4, 1);
lean_inc(x_1577);
lean_dec(x_4);
x_1578 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1578, 0, x_1563);
lean_ctor_set(x_1578, 1, x_1564);
lean_ctor_set(x_1578, 2, x_1565);
lean_ctor_set_uint8(x_1578, sizeof(void*)*3, x_1486);
lean_ctor_set(x_1179, 2, x_1541);
lean_ctor_set(x_1179, 1, x_1577);
lean_ctor_set(x_1179, 0, x_1446);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1561);
x_5 = x_1578;
x_6 = x_1562;
x_7 = x_1574;
x_8 = x_1575;
x_9 = x_1576;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
}
else
{
lean_object* x_1579; lean_object* x_1580; lean_object* x_1581; lean_object* x_1582; lean_object* x_1583; lean_object* x_1584; lean_object* x_1585; 
x_1579 = lean_ctor_get(x_1179, 0);
x_1580 = lean_ctor_get(x_1179, 1);
x_1581 = lean_ctor_get(x_1179, 2);
lean_inc(x_1581);
lean_inc(x_1580);
lean_inc(x_1579);
lean_dec(x_1179);
x_1582 = lean_ctor_get(x_4, 1);
lean_inc(x_1582);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1583 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1583 = lean_box(0);
}
if (lean_is_scalar(x_1583)) {
 x_1584 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1584 = x_1583;
}
lean_ctor_set(x_1584, 0, x_1563);
lean_ctor_set(x_1584, 1, x_1564);
lean_ctor_set(x_1584, 2, x_1565);
lean_ctor_set_uint8(x_1584, sizeof(void*)*3, x_1486);
x_1585 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1585, 0, x_1446);
lean_ctor_set(x_1585, 1, x_1582);
lean_ctor_set(x_1585, 2, x_1541);
lean_ctor_set_uint8(x_1585, sizeof(void*)*3, x_1561);
x_5 = x_1584;
x_6 = x_1562;
x_7 = x_1579;
x_8 = x_1580;
x_9 = x_1581;
x_10 = x_3;
x_11 = x_1585;
goto block_16;
}
}
else
{
lean_object* x_1586; lean_object* x_1587; lean_object* x_1588; lean_object* x_1589; uint8_t x_1590; 
x_1586 = lean_ctor_get(x_2, 1);
lean_inc(x_1586);
lean_dec_ref(x_2);
x_1587 = lean_ctor_get(x_86, 0);
lean_inc(x_1587);
x_1588 = lean_ctor_get(x_86, 1);
lean_inc(x_1588);
x_1589 = lean_ctor_get(x_86, 2);
lean_inc(x_1589);
lean_dec_ref(x_86);
x_1590 = !lean_is_exclusive(x_1179);
if (x_1590 == 0)
{
uint8_t x_1591; 
x_1591 = !lean_is_exclusive(x_4);
if (x_1591 == 0)
{
lean_object* x_1592; lean_object* x_1593; lean_object* x_1594; lean_object* x_1595; lean_object* x_1596; lean_object* x_1597; uint8_t x_1598; 
x_1592 = lean_ctor_get(x_1179, 0);
x_1593 = lean_ctor_get(x_1179, 1);
x_1594 = lean_ctor_get(x_1179, 2);
x_1595 = lean_ctor_get(x_4, 1);
x_1596 = lean_ctor_get(x_4, 2);
lean_dec(x_1596);
x_1597 = lean_ctor_get(x_4, 0);
lean_dec(x_1597);
x_1598 = !lean_is_exclusive(x_1446);
if (x_1598 == 0)
{
lean_object* x_1599; lean_object* x_1600; lean_object* x_1601; 
x_1599 = lean_ctor_get(x_1446, 0);
x_1600 = lean_ctor_get(x_1446, 1);
x_1601 = lean_ctor_get(x_1446, 2);
lean_ctor_set(x_1446, 2, x_1589);
lean_ctor_set(x_1446, 1, x_1588);
lean_ctor_set(x_1446, 0, x_1587);
lean_ctor_set_uint8(x_1446, sizeof(void*)*3, x_1561);
lean_ctor_set(x_4, 2, x_1601);
lean_ctor_set(x_4, 1, x_1600);
lean_ctor_set(x_4, 0, x_1599);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1561);
lean_ctor_set(x_1179, 2, x_1541);
lean_ctor_set(x_1179, 1, x_1595);
lean_ctor_set(x_1179, 0, x_4);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1445);
x_5 = x_1446;
x_6 = x_1586;
x_7 = x_1592;
x_8 = x_1593;
x_9 = x_1594;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
else
{
lean_object* x_1602; lean_object* x_1603; lean_object* x_1604; lean_object* x_1605; 
x_1602 = lean_ctor_get(x_1446, 0);
x_1603 = lean_ctor_get(x_1446, 1);
x_1604 = lean_ctor_get(x_1446, 2);
lean_inc(x_1604);
lean_inc(x_1603);
lean_inc(x_1602);
lean_dec(x_1446);
x_1605 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1605, 0, x_1587);
lean_ctor_set(x_1605, 1, x_1588);
lean_ctor_set(x_1605, 2, x_1589);
lean_ctor_set_uint8(x_1605, sizeof(void*)*3, x_1561);
lean_ctor_set(x_4, 2, x_1604);
lean_ctor_set(x_4, 1, x_1603);
lean_ctor_set(x_4, 0, x_1602);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1561);
lean_ctor_set(x_1179, 2, x_1541);
lean_ctor_set(x_1179, 1, x_1595);
lean_ctor_set(x_1179, 0, x_4);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1445);
x_5 = x_1605;
x_6 = x_1586;
x_7 = x_1592;
x_8 = x_1593;
x_9 = x_1594;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
}
else
{
lean_object* x_1606; lean_object* x_1607; lean_object* x_1608; lean_object* x_1609; lean_object* x_1610; lean_object* x_1611; lean_object* x_1612; lean_object* x_1613; lean_object* x_1614; lean_object* x_1615; 
x_1606 = lean_ctor_get(x_1179, 0);
x_1607 = lean_ctor_get(x_1179, 1);
x_1608 = lean_ctor_get(x_1179, 2);
x_1609 = lean_ctor_get(x_4, 1);
lean_inc(x_1609);
lean_dec(x_4);
x_1610 = lean_ctor_get(x_1446, 0);
lean_inc(x_1610);
x_1611 = lean_ctor_get(x_1446, 1);
lean_inc(x_1611);
x_1612 = lean_ctor_get(x_1446, 2);
lean_inc(x_1612);
if (lean_is_exclusive(x_1446)) {
 lean_ctor_release(x_1446, 0);
 lean_ctor_release(x_1446, 1);
 lean_ctor_release(x_1446, 2);
 x_1613 = x_1446;
} else {
 lean_dec_ref(x_1446);
 x_1613 = lean_box(0);
}
if (lean_is_scalar(x_1613)) {
 x_1614 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1614 = x_1613;
}
lean_ctor_set(x_1614, 0, x_1587);
lean_ctor_set(x_1614, 1, x_1588);
lean_ctor_set(x_1614, 2, x_1589);
lean_ctor_set_uint8(x_1614, sizeof(void*)*3, x_1561);
x_1615 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1615, 0, x_1610);
lean_ctor_set(x_1615, 1, x_1611);
lean_ctor_set(x_1615, 2, x_1612);
lean_ctor_set_uint8(x_1615, sizeof(void*)*3, x_1561);
lean_ctor_set(x_1179, 2, x_1541);
lean_ctor_set(x_1179, 1, x_1609);
lean_ctor_set(x_1179, 0, x_1615);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1445);
x_5 = x_1614;
x_6 = x_1586;
x_7 = x_1606;
x_8 = x_1607;
x_9 = x_1608;
x_10 = x_3;
x_11 = x_1179;
goto block_16;
}
}
else
{
lean_object* x_1616; lean_object* x_1617; lean_object* x_1618; lean_object* x_1619; lean_object* x_1620; lean_object* x_1621; lean_object* x_1622; lean_object* x_1623; lean_object* x_1624; lean_object* x_1625; lean_object* x_1626; lean_object* x_1627; 
x_1616 = lean_ctor_get(x_1179, 0);
x_1617 = lean_ctor_get(x_1179, 1);
x_1618 = lean_ctor_get(x_1179, 2);
lean_inc(x_1618);
lean_inc(x_1617);
lean_inc(x_1616);
lean_dec(x_1179);
x_1619 = lean_ctor_get(x_4, 1);
lean_inc(x_1619);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1620 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1620 = lean_box(0);
}
x_1621 = lean_ctor_get(x_1446, 0);
lean_inc(x_1621);
x_1622 = lean_ctor_get(x_1446, 1);
lean_inc(x_1622);
x_1623 = lean_ctor_get(x_1446, 2);
lean_inc(x_1623);
if (lean_is_exclusive(x_1446)) {
 lean_ctor_release(x_1446, 0);
 lean_ctor_release(x_1446, 1);
 lean_ctor_release(x_1446, 2);
 x_1624 = x_1446;
} else {
 lean_dec_ref(x_1446);
 x_1624 = lean_box(0);
}
if (lean_is_scalar(x_1624)) {
 x_1625 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1625 = x_1624;
}
lean_ctor_set(x_1625, 0, x_1587);
lean_ctor_set(x_1625, 1, x_1588);
lean_ctor_set(x_1625, 2, x_1589);
lean_ctor_set_uint8(x_1625, sizeof(void*)*3, x_1561);
if (lean_is_scalar(x_1620)) {
 x_1626 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1626 = x_1620;
}
lean_ctor_set(x_1626, 0, x_1621);
lean_ctor_set(x_1626, 1, x_1622);
lean_ctor_set(x_1626, 2, x_1623);
lean_ctor_set_uint8(x_1626, sizeof(void*)*3, x_1561);
x_1627 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1627, 0, x_1626);
lean_ctor_set(x_1627, 1, x_1619);
lean_ctor_set(x_1627, 2, x_1541);
lean_ctor_set_uint8(x_1627, sizeof(void*)*3, x_1445);
x_5 = x_1625;
x_6 = x_1586;
x_7 = x_1616;
x_8 = x_1617;
x_9 = x_1618;
x_10 = x_3;
x_11 = x_1627;
goto block_16;
}
}
}
}
}
}
else
{
lean_object* x_1628; lean_object* x_1629; lean_object* x_1630; lean_object* x_1631; uint8_t x_1632; 
x_1628 = lean_ctor_get(x_2, 1);
lean_inc(x_1628);
lean_dec_ref(x_2);
x_1629 = lean_ctor_get(x_86, 0);
lean_inc(x_1629);
x_1630 = lean_ctor_get(x_86, 1);
lean_inc(x_1630);
x_1631 = lean_ctor_get(x_86, 2);
lean_inc(x_1631);
lean_dec_ref(x_86);
x_1632 = !lean_is_exclusive(x_1179);
if (x_1632 == 0)
{
lean_object* x_1633; lean_object* x_1634; lean_object* x_1635; 
x_1633 = lean_ctor_get(x_1179, 0);
x_1634 = lean_ctor_get(x_1179, 1);
x_1635 = lean_ctor_get(x_1179, 2);
lean_ctor_set(x_1179, 2, x_1631);
lean_ctor_set(x_1179, 1, x_1630);
lean_ctor_set(x_1179, 0, x_1629);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1445);
x_5 = x_1179;
x_6 = x_1628;
x_7 = x_1633;
x_8 = x_1634;
x_9 = x_1635;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
else
{
lean_object* x_1636; lean_object* x_1637; lean_object* x_1638; lean_object* x_1639; 
x_1636 = lean_ctor_get(x_1179, 0);
x_1637 = lean_ctor_get(x_1179, 1);
x_1638 = lean_ctor_get(x_1179, 2);
lean_inc(x_1638);
lean_inc(x_1637);
lean_inc(x_1636);
lean_dec(x_1179);
x_1639 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1639, 0, x_1629);
lean_ctor_set(x_1639, 1, x_1630);
lean_ctor_set(x_1639, 2, x_1631);
lean_ctor_set_uint8(x_1639, sizeof(void*)*3, x_1445);
x_5 = x_1639;
x_6 = x_1628;
x_7 = x_1636;
x_8 = x_1637;
x_9 = x_1638;
x_10 = x_3;
x_11 = x_4;
goto block_16;
}
}
}
}
else
{
if (lean_obj_tag(x_4) == 0)
{
uint8_t x_1640; 
x_1640 = !lean_is_exclusive(x_2);
if (x_1640 == 0)
{
lean_object* x_1641; lean_object* x_1642; uint8_t x_1643; 
x_1641 = lean_ctor_get(x_2, 2);
lean_dec(x_1641);
x_1642 = lean_ctor_get(x_2, 0);
lean_dec(x_1642);
x_1643 = !lean_is_exclusive(x_86);
if (x_1643 == 0)
{
lean_object* x_1644; 
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1440);
x_1644 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1644, 0, x_2);
lean_ctor_set(x_1644, 1, x_3);
lean_ctor_set(x_1644, 2, x_4);
lean_ctor_set_uint8(x_1644, sizeof(void*)*3, x_1440);
return x_1644;
}
else
{
lean_object* x_1645; lean_object* x_1646; lean_object* x_1647; lean_object* x_1648; lean_object* x_1649; 
x_1645 = lean_ctor_get(x_86, 0);
x_1646 = lean_ctor_get(x_86, 1);
x_1647 = lean_ctor_get(x_86, 2);
lean_inc(x_1647);
lean_inc(x_1646);
lean_inc(x_1645);
lean_dec(x_86);
x_1648 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1648, 0, x_1645);
lean_ctor_set(x_1648, 1, x_1646);
lean_ctor_set(x_1648, 2, x_1647);
lean_ctor_set_uint8(x_1648, sizeof(void*)*3, x_1440);
lean_ctor_set(x_2, 0, x_1648);
x_1649 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1649, 0, x_2);
lean_ctor_set(x_1649, 1, x_3);
lean_ctor_set(x_1649, 2, x_4);
lean_ctor_set_uint8(x_1649, sizeof(void*)*3, x_1440);
return x_1649;
}
}
else
{
lean_object* x_1650; lean_object* x_1651; lean_object* x_1652; lean_object* x_1653; lean_object* x_1654; lean_object* x_1655; lean_object* x_1656; lean_object* x_1657; 
x_1650 = lean_ctor_get(x_2, 1);
lean_inc(x_1650);
lean_dec(x_2);
x_1651 = lean_ctor_get(x_86, 0);
lean_inc(x_1651);
x_1652 = lean_ctor_get(x_86, 1);
lean_inc(x_1652);
x_1653 = lean_ctor_get(x_86, 2);
lean_inc(x_1653);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1654 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1654 = lean_box(0);
}
if (lean_is_scalar(x_1654)) {
 x_1655 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1655 = x_1654;
}
lean_ctor_set(x_1655, 0, x_1651);
lean_ctor_set(x_1655, 1, x_1652);
lean_ctor_set(x_1655, 2, x_1653);
lean_ctor_set_uint8(x_1655, sizeof(void*)*3, x_1440);
x_1656 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1656, 0, x_1655);
lean_ctor_set(x_1656, 1, x_1650);
lean_ctor_set(x_1656, 2, x_1179);
lean_ctor_set_uint8(x_1656, sizeof(void*)*3, x_85);
x_1657 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1657, 0, x_1656);
lean_ctor_set(x_1657, 1, x_3);
lean_ctor_set(x_1657, 2, x_4);
lean_ctor_set_uint8(x_1657, sizeof(void*)*3, x_1440);
return x_1657;
}
}
else
{
uint8_t x_1658; 
x_1658 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_1658 == 0)
{
lean_object* x_1659; 
x_1659 = lean_ctor_get(x_4, 0);
lean_inc(x_1659);
if (lean_obj_tag(x_1659) == 0)
{
lean_object* x_1660; 
x_1660 = lean_ctor_get(x_4, 2);
lean_inc(x_1660);
if (lean_obj_tag(x_1660) == 0)
{
uint8_t x_1661; 
x_1661 = !lean_is_exclusive(x_2);
if (x_1661 == 0)
{
lean_object* x_1662; lean_object* x_1663; lean_object* x_1664; uint8_t x_1665; 
x_1662 = lean_ctor_get(x_2, 1);
x_1663 = lean_ctor_get(x_2, 2);
lean_dec(x_1663);
x_1664 = lean_ctor_get(x_2, 0);
lean_dec(x_1664);
x_1665 = !lean_is_exclusive(x_86);
if (x_1665 == 0)
{
uint8_t x_1666; 
x_1666 = !lean_is_exclusive(x_4);
if (x_1666 == 0)
{
lean_object* x_1667; lean_object* x_1668; lean_object* x_1669; lean_object* x_1670; lean_object* x_1671; lean_object* x_1672; lean_object* x_1673; 
x_1667 = lean_ctor_get(x_86, 0);
x_1668 = lean_ctor_get(x_86, 1);
x_1669 = lean_ctor_get(x_86, 2);
x_1670 = lean_ctor_get(x_4, 1);
x_1671 = lean_ctor_get(x_4, 2);
lean_dec(x_1671);
x_1672 = lean_ctor_get(x_4, 0);
lean_dec(x_1672);
lean_ctor_set(x_4, 2, x_1669);
lean_ctor_set(x_4, 1, x_1668);
lean_ctor_set(x_4, 0, x_1667);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1440);
lean_ctor_set(x_86, 2, x_1179);
lean_ctor_set(x_86, 1, x_1662);
lean_ctor_set(x_86, 0, x_4);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_1660);
lean_ctor_set(x_2, 1, x_1670);
lean_ctor_set(x_2, 0, x_1660);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_1673 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1673, 0, x_86);
lean_ctor_set(x_1673, 1, x_3);
lean_ctor_set(x_1673, 2, x_2);
lean_ctor_set_uint8(x_1673, sizeof(void*)*3, x_1440);
return x_1673;
}
else
{
lean_object* x_1674; lean_object* x_1675; lean_object* x_1676; lean_object* x_1677; lean_object* x_1678; lean_object* x_1679; 
x_1674 = lean_ctor_get(x_86, 0);
x_1675 = lean_ctor_get(x_86, 1);
x_1676 = lean_ctor_get(x_86, 2);
x_1677 = lean_ctor_get(x_4, 1);
lean_inc(x_1677);
lean_dec(x_4);
x_1678 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1678, 0, x_1674);
lean_ctor_set(x_1678, 1, x_1675);
lean_ctor_set(x_1678, 2, x_1676);
lean_ctor_set_uint8(x_1678, sizeof(void*)*3, x_1440);
lean_ctor_set(x_86, 2, x_1179);
lean_ctor_set(x_86, 1, x_1662);
lean_ctor_set(x_86, 0, x_1678);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_1660);
lean_ctor_set(x_2, 1, x_1677);
lean_ctor_set(x_2, 0, x_1660);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_1679 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1679, 0, x_86);
lean_ctor_set(x_1679, 1, x_3);
lean_ctor_set(x_1679, 2, x_2);
lean_ctor_set_uint8(x_1679, sizeof(void*)*3, x_1440);
return x_1679;
}
}
else
{
lean_object* x_1680; lean_object* x_1681; lean_object* x_1682; lean_object* x_1683; lean_object* x_1684; lean_object* x_1685; lean_object* x_1686; lean_object* x_1687; 
x_1680 = lean_ctor_get(x_86, 0);
x_1681 = lean_ctor_get(x_86, 1);
x_1682 = lean_ctor_get(x_86, 2);
lean_inc(x_1682);
lean_inc(x_1681);
lean_inc(x_1680);
lean_dec(x_86);
x_1683 = lean_ctor_get(x_4, 1);
lean_inc(x_1683);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1684 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1684 = lean_box(0);
}
if (lean_is_scalar(x_1684)) {
 x_1685 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1685 = x_1684;
}
lean_ctor_set(x_1685, 0, x_1680);
lean_ctor_set(x_1685, 1, x_1681);
lean_ctor_set(x_1685, 2, x_1682);
lean_ctor_set_uint8(x_1685, sizeof(void*)*3, x_1440);
x_1686 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1686, 0, x_1685);
lean_ctor_set(x_1686, 1, x_1662);
lean_ctor_set(x_1686, 2, x_1179);
lean_ctor_set_uint8(x_1686, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_1660);
lean_ctor_set(x_2, 1, x_1683);
lean_ctor_set(x_2, 0, x_1660);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_1687 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1687, 0, x_1686);
lean_ctor_set(x_1687, 1, x_3);
lean_ctor_set(x_1687, 2, x_2);
lean_ctor_set_uint8(x_1687, sizeof(void*)*3, x_1440);
return x_1687;
}
}
else
{
lean_object* x_1688; lean_object* x_1689; lean_object* x_1690; lean_object* x_1691; lean_object* x_1692; lean_object* x_1693; lean_object* x_1694; lean_object* x_1695; lean_object* x_1696; lean_object* x_1697; lean_object* x_1698; 
x_1688 = lean_ctor_get(x_2, 1);
lean_inc(x_1688);
lean_dec(x_2);
x_1689 = lean_ctor_get(x_86, 0);
lean_inc(x_1689);
x_1690 = lean_ctor_get(x_86, 1);
lean_inc(x_1690);
x_1691 = lean_ctor_get(x_86, 2);
lean_inc(x_1691);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1692 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1692 = lean_box(0);
}
x_1693 = lean_ctor_get(x_4, 1);
lean_inc(x_1693);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1694 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1694 = lean_box(0);
}
if (lean_is_scalar(x_1694)) {
 x_1695 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1695 = x_1694;
}
lean_ctor_set(x_1695, 0, x_1689);
lean_ctor_set(x_1695, 1, x_1690);
lean_ctor_set(x_1695, 2, x_1691);
lean_ctor_set_uint8(x_1695, sizeof(void*)*3, x_1440);
if (lean_is_scalar(x_1692)) {
 x_1696 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1696 = x_1692;
}
lean_ctor_set(x_1696, 0, x_1695);
lean_ctor_set(x_1696, 1, x_1688);
lean_ctor_set(x_1696, 2, x_1179);
lean_ctor_set_uint8(x_1696, sizeof(void*)*3, x_1658);
x_1697 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1697, 0, x_1660);
lean_ctor_set(x_1697, 1, x_1693);
lean_ctor_set(x_1697, 2, x_1660);
lean_ctor_set_uint8(x_1697, sizeof(void*)*3, x_1658);
x_1698 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1698, 0, x_1696);
lean_ctor_set(x_1698, 1, x_3);
lean_ctor_set(x_1698, 2, x_1697);
lean_ctor_set_uint8(x_1698, sizeof(void*)*3, x_1440);
return x_1698;
}
}
else
{
uint8_t x_1699; 
x_1699 = lean_ctor_get_uint8(x_1660, sizeof(void*)*3);
if (x_1699 == 0)
{
lean_object* x_1700; lean_object* x_1701; lean_object* x_1702; lean_object* x_1703; uint8_t x_1704; 
x_1700 = lean_ctor_get(x_2, 1);
lean_inc(x_1700);
lean_dec_ref(x_2);
x_1701 = lean_ctor_get(x_86, 0);
lean_inc(x_1701);
x_1702 = lean_ctor_get(x_86, 1);
lean_inc(x_1702);
x_1703 = lean_ctor_get(x_86, 2);
lean_inc(x_1703);
lean_dec_ref(x_86);
x_1704 = !lean_is_exclusive(x_4);
if (x_1704 == 0)
{
lean_object* x_1705; lean_object* x_1706; lean_object* x_1707; uint8_t x_1708; 
x_1705 = lean_ctor_get(x_4, 1);
x_1706 = lean_ctor_get(x_4, 2);
lean_dec(x_1706);
x_1707 = lean_ctor_get(x_4, 0);
lean_dec(x_1707);
x_1708 = !lean_is_exclusive(x_1660);
if (x_1708 == 0)
{
lean_object* x_1709; lean_object* x_1710; lean_object* x_1711; 
x_1709 = lean_ctor_get(x_1660, 0);
x_1710 = lean_ctor_get(x_1660, 1);
x_1711 = lean_ctor_get(x_1660, 2);
lean_ctor_set(x_1660, 2, x_1703);
lean_ctor_set(x_1660, 1, x_1702);
lean_ctor_set(x_1660, 0, x_1701);
lean_ctor_set_uint8(x_1660, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1700);
lean_ctor_set(x_4, 0, x_1660);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1699);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1705;
x_9 = x_1709;
x_10 = x_1710;
x_11 = x_1711;
goto block_16;
}
else
{
lean_object* x_1712; lean_object* x_1713; lean_object* x_1714; lean_object* x_1715; 
x_1712 = lean_ctor_get(x_1660, 0);
x_1713 = lean_ctor_get(x_1660, 1);
x_1714 = lean_ctor_get(x_1660, 2);
lean_inc(x_1714);
lean_inc(x_1713);
lean_inc(x_1712);
lean_dec(x_1660);
x_1715 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1715, 0, x_1701);
lean_ctor_set(x_1715, 1, x_1702);
lean_ctor_set(x_1715, 2, x_1703);
lean_ctor_set_uint8(x_1715, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1700);
lean_ctor_set(x_4, 0, x_1715);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1699);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1705;
x_9 = x_1712;
x_10 = x_1713;
x_11 = x_1714;
goto block_16;
}
}
else
{
lean_object* x_1716; lean_object* x_1717; lean_object* x_1718; lean_object* x_1719; lean_object* x_1720; lean_object* x_1721; lean_object* x_1722; 
x_1716 = lean_ctor_get(x_4, 1);
lean_inc(x_1716);
lean_dec(x_4);
x_1717 = lean_ctor_get(x_1660, 0);
lean_inc(x_1717);
x_1718 = lean_ctor_get(x_1660, 1);
lean_inc(x_1718);
x_1719 = lean_ctor_get(x_1660, 2);
lean_inc(x_1719);
if (lean_is_exclusive(x_1660)) {
 lean_ctor_release(x_1660, 0);
 lean_ctor_release(x_1660, 1);
 lean_ctor_release(x_1660, 2);
 x_1720 = x_1660;
} else {
 lean_dec_ref(x_1660);
 x_1720 = lean_box(0);
}
if (lean_is_scalar(x_1720)) {
 x_1721 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1721 = x_1720;
}
lean_ctor_set(x_1721, 0, x_1701);
lean_ctor_set(x_1721, 1, x_1702);
lean_ctor_set(x_1721, 2, x_1703);
lean_ctor_set_uint8(x_1721, sizeof(void*)*3, x_1440);
x_1722 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1722, 0, x_1721);
lean_ctor_set(x_1722, 1, x_1700);
lean_ctor_set(x_1722, 2, x_1179);
lean_ctor_set_uint8(x_1722, sizeof(void*)*3, x_1699);
x_5 = x_1722;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1716;
x_9 = x_1717;
x_10 = x_1718;
x_11 = x_1719;
goto block_16;
}
}
else
{
uint8_t x_1723; 
x_1723 = !lean_is_exclusive(x_1660);
if (x_1723 == 0)
{
lean_object* x_1724; lean_object* x_1725; lean_object* x_1726; uint8_t x_1727; 
x_1724 = lean_ctor_get(x_1660, 2);
lean_dec(x_1724);
x_1725 = lean_ctor_get(x_1660, 1);
lean_dec(x_1725);
x_1726 = lean_ctor_get(x_1660, 0);
lean_dec(x_1726);
x_1727 = !lean_is_exclusive(x_2);
if (x_1727 == 0)
{
lean_object* x_1728; lean_object* x_1729; lean_object* x_1730; uint8_t x_1731; 
x_1728 = lean_ctor_get(x_2, 1);
x_1729 = lean_ctor_get(x_2, 2);
lean_dec(x_1729);
x_1730 = lean_ctor_get(x_2, 0);
lean_dec(x_1730);
x_1731 = !lean_is_exclusive(x_86);
if (x_1731 == 0)
{
uint8_t x_1732; 
x_1732 = !lean_is_exclusive(x_1179);
if (x_1732 == 0)
{
lean_object* x_1733; lean_object* x_1734; lean_object* x_1735; 
x_1733 = lean_ctor_get(x_86, 0);
x_1734 = lean_ctor_get(x_86, 1);
x_1735 = lean_ctor_get(x_86, 2);
lean_ctor_set(x_1660, 2, x_1735);
lean_ctor_set(x_1660, 1, x_1734);
lean_ctor_set(x_1660, 0, x_1733);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1699);
lean_ctor_set(x_86, 2, x_1179);
lean_ctor_set(x_86, 1, x_1728);
lean_ctor_set(x_86, 0, x_1660);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1699);
return x_2;
}
else
{
lean_object* x_1736; lean_object* x_1737; lean_object* x_1738; lean_object* x_1739; lean_object* x_1740; lean_object* x_1741; lean_object* x_1742; 
x_1736 = lean_ctor_get(x_86, 0);
x_1737 = lean_ctor_get(x_86, 1);
x_1738 = lean_ctor_get(x_86, 2);
x_1739 = lean_ctor_get(x_1179, 0);
x_1740 = lean_ctor_get(x_1179, 1);
x_1741 = lean_ctor_get(x_1179, 2);
lean_inc(x_1741);
lean_inc(x_1740);
lean_inc(x_1739);
lean_dec(x_1179);
lean_ctor_set(x_1660, 2, x_1738);
lean_ctor_set(x_1660, 1, x_1737);
lean_ctor_set(x_1660, 0, x_1736);
x_1742 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1742, 0, x_1739);
lean_ctor_set(x_1742, 1, x_1740);
lean_ctor_set(x_1742, 2, x_1741);
lean_ctor_set_uint8(x_1742, sizeof(void*)*3, x_1699);
lean_ctor_set(x_86, 2, x_1742);
lean_ctor_set(x_86, 1, x_1728);
lean_ctor_set(x_86, 0, x_1660);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1699);
return x_2;
}
}
else
{
lean_object* x_1743; lean_object* x_1744; lean_object* x_1745; lean_object* x_1746; lean_object* x_1747; lean_object* x_1748; lean_object* x_1749; lean_object* x_1750; lean_object* x_1751; 
x_1743 = lean_ctor_get(x_86, 0);
x_1744 = lean_ctor_get(x_86, 1);
x_1745 = lean_ctor_get(x_86, 2);
lean_inc(x_1745);
lean_inc(x_1744);
lean_inc(x_1743);
lean_dec(x_86);
x_1746 = lean_ctor_get(x_1179, 0);
lean_inc(x_1746);
x_1747 = lean_ctor_get(x_1179, 1);
lean_inc(x_1747);
x_1748 = lean_ctor_get(x_1179, 2);
lean_inc(x_1748);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1749 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1749 = lean_box(0);
}
lean_ctor_set(x_1660, 2, x_1745);
lean_ctor_set(x_1660, 1, x_1744);
lean_ctor_set(x_1660, 0, x_1743);
if (lean_is_scalar(x_1749)) {
 x_1750 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1750 = x_1749;
}
lean_ctor_set(x_1750, 0, x_1746);
lean_ctor_set(x_1750, 1, x_1747);
lean_ctor_set(x_1750, 2, x_1748);
lean_ctor_set_uint8(x_1750, sizeof(void*)*3, x_1699);
x_1751 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1751, 0, x_1660);
lean_ctor_set(x_1751, 1, x_1728);
lean_ctor_set(x_1751, 2, x_1750);
lean_ctor_set_uint8(x_1751, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_1751);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1699);
return x_2;
}
}
else
{
lean_object* x_1752; lean_object* x_1753; lean_object* x_1754; lean_object* x_1755; lean_object* x_1756; lean_object* x_1757; lean_object* x_1758; lean_object* x_1759; lean_object* x_1760; lean_object* x_1761; lean_object* x_1762; lean_object* x_1763; 
x_1752 = lean_ctor_get(x_2, 1);
lean_inc(x_1752);
lean_dec(x_2);
x_1753 = lean_ctor_get(x_86, 0);
lean_inc(x_1753);
x_1754 = lean_ctor_get(x_86, 1);
lean_inc(x_1754);
x_1755 = lean_ctor_get(x_86, 2);
lean_inc(x_1755);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1756 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1756 = lean_box(0);
}
x_1757 = lean_ctor_get(x_1179, 0);
lean_inc(x_1757);
x_1758 = lean_ctor_get(x_1179, 1);
lean_inc(x_1758);
x_1759 = lean_ctor_get(x_1179, 2);
lean_inc(x_1759);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1760 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1760 = lean_box(0);
}
lean_ctor_set(x_1660, 2, x_1755);
lean_ctor_set(x_1660, 1, x_1754);
lean_ctor_set(x_1660, 0, x_1753);
if (lean_is_scalar(x_1760)) {
 x_1761 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1761 = x_1760;
}
lean_ctor_set(x_1761, 0, x_1757);
lean_ctor_set(x_1761, 1, x_1758);
lean_ctor_set(x_1761, 2, x_1759);
lean_ctor_set_uint8(x_1761, sizeof(void*)*3, x_1699);
if (lean_is_scalar(x_1756)) {
 x_1762 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1762 = x_1756;
}
lean_ctor_set(x_1762, 0, x_1660);
lean_ctor_set(x_1762, 1, x_1752);
lean_ctor_set(x_1762, 2, x_1761);
lean_ctor_set_uint8(x_1762, sizeof(void*)*3, x_1658);
x_1763 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1763, 0, x_1762);
lean_ctor_set(x_1763, 1, x_3);
lean_ctor_set(x_1763, 2, x_4);
lean_ctor_set_uint8(x_1763, sizeof(void*)*3, x_1699);
return x_1763;
}
}
else
{
lean_object* x_1764; lean_object* x_1765; lean_object* x_1766; lean_object* x_1767; lean_object* x_1768; lean_object* x_1769; lean_object* x_1770; lean_object* x_1771; lean_object* x_1772; lean_object* x_1773; lean_object* x_1774; lean_object* x_1775; lean_object* x_1776; lean_object* x_1777; 
lean_dec(x_1660);
x_1764 = lean_ctor_get(x_2, 1);
lean_inc(x_1764);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_1765 = x_2;
} else {
 lean_dec_ref(x_2);
 x_1765 = lean_box(0);
}
x_1766 = lean_ctor_get(x_86, 0);
lean_inc(x_1766);
x_1767 = lean_ctor_get(x_86, 1);
lean_inc(x_1767);
x_1768 = lean_ctor_get(x_86, 2);
lean_inc(x_1768);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1769 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1769 = lean_box(0);
}
x_1770 = lean_ctor_get(x_1179, 0);
lean_inc(x_1770);
x_1771 = lean_ctor_get(x_1179, 1);
lean_inc(x_1771);
x_1772 = lean_ctor_get(x_1179, 2);
lean_inc(x_1772);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1773 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1773 = lean_box(0);
}
x_1774 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1774, 0, x_1766);
lean_ctor_set(x_1774, 1, x_1767);
lean_ctor_set(x_1774, 2, x_1768);
lean_ctor_set_uint8(x_1774, sizeof(void*)*3, x_1699);
if (lean_is_scalar(x_1773)) {
 x_1775 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1775 = x_1773;
}
lean_ctor_set(x_1775, 0, x_1770);
lean_ctor_set(x_1775, 1, x_1771);
lean_ctor_set(x_1775, 2, x_1772);
lean_ctor_set_uint8(x_1775, sizeof(void*)*3, x_1699);
if (lean_is_scalar(x_1769)) {
 x_1776 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1776 = x_1769;
}
lean_ctor_set(x_1776, 0, x_1774);
lean_ctor_set(x_1776, 1, x_1764);
lean_ctor_set(x_1776, 2, x_1775);
lean_ctor_set_uint8(x_1776, sizeof(void*)*3, x_1658);
if (lean_is_scalar(x_1765)) {
 x_1777 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1777 = x_1765;
}
lean_ctor_set(x_1777, 0, x_1776);
lean_ctor_set(x_1777, 1, x_3);
lean_ctor_set(x_1777, 2, x_4);
lean_ctor_set_uint8(x_1777, sizeof(void*)*3, x_1699);
return x_1777;
}
}
}
}
else
{
uint8_t x_1778; 
x_1778 = lean_ctor_get_uint8(x_1659, sizeof(void*)*3);
if (x_1778 == 0)
{
lean_object* x_1779; 
x_1779 = lean_ctor_get(x_4, 2);
lean_inc(x_1779);
if (lean_obj_tag(x_1779) == 0)
{
lean_object* x_1780; lean_object* x_1781; lean_object* x_1782; lean_object* x_1783; uint8_t x_1784; 
x_1780 = lean_ctor_get(x_2, 1);
lean_inc(x_1780);
lean_dec_ref(x_2);
x_1781 = lean_ctor_get(x_86, 0);
lean_inc(x_1781);
x_1782 = lean_ctor_get(x_86, 1);
lean_inc(x_1782);
x_1783 = lean_ctor_get(x_86, 2);
lean_inc(x_1783);
lean_dec_ref(x_86);
x_1784 = !lean_is_exclusive(x_4);
if (x_1784 == 0)
{
lean_object* x_1785; lean_object* x_1786; lean_object* x_1787; uint8_t x_1788; 
x_1785 = lean_ctor_get(x_4, 1);
x_1786 = lean_ctor_get(x_4, 2);
lean_dec(x_1786);
x_1787 = lean_ctor_get(x_4, 0);
lean_dec(x_1787);
x_1788 = !lean_is_exclusive(x_1659);
if (x_1788 == 0)
{
lean_object* x_1789; lean_object* x_1790; lean_object* x_1791; 
x_1789 = lean_ctor_get(x_1659, 0);
x_1790 = lean_ctor_get(x_1659, 1);
x_1791 = lean_ctor_get(x_1659, 2);
lean_ctor_set(x_1659, 2, x_1783);
lean_ctor_set(x_1659, 1, x_1782);
lean_ctor_set(x_1659, 0, x_1781);
lean_ctor_set_uint8(x_1659, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1780);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1778);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1789;
x_8 = x_1790;
x_9 = x_1791;
x_10 = x_1785;
x_11 = x_1779;
goto block_16;
}
else
{
lean_object* x_1792; lean_object* x_1793; lean_object* x_1794; lean_object* x_1795; 
x_1792 = lean_ctor_get(x_1659, 0);
x_1793 = lean_ctor_get(x_1659, 1);
x_1794 = lean_ctor_get(x_1659, 2);
lean_inc(x_1794);
lean_inc(x_1793);
lean_inc(x_1792);
lean_dec(x_1659);
x_1795 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1795, 0, x_1781);
lean_ctor_set(x_1795, 1, x_1782);
lean_ctor_set(x_1795, 2, x_1783);
lean_ctor_set_uint8(x_1795, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1780);
lean_ctor_set(x_4, 0, x_1795);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1778);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1792;
x_8 = x_1793;
x_9 = x_1794;
x_10 = x_1785;
x_11 = x_1779;
goto block_16;
}
}
else
{
lean_object* x_1796; lean_object* x_1797; lean_object* x_1798; lean_object* x_1799; lean_object* x_1800; lean_object* x_1801; lean_object* x_1802; 
x_1796 = lean_ctor_get(x_4, 1);
lean_inc(x_1796);
lean_dec(x_4);
x_1797 = lean_ctor_get(x_1659, 0);
lean_inc(x_1797);
x_1798 = lean_ctor_get(x_1659, 1);
lean_inc(x_1798);
x_1799 = lean_ctor_get(x_1659, 2);
lean_inc(x_1799);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_1800 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_1800 = lean_box(0);
}
if (lean_is_scalar(x_1800)) {
 x_1801 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1801 = x_1800;
}
lean_ctor_set(x_1801, 0, x_1781);
lean_ctor_set(x_1801, 1, x_1782);
lean_ctor_set(x_1801, 2, x_1783);
lean_ctor_set_uint8(x_1801, sizeof(void*)*3, x_1440);
x_1802 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1802, 0, x_1801);
lean_ctor_set(x_1802, 1, x_1780);
lean_ctor_set(x_1802, 2, x_1179);
lean_ctor_set_uint8(x_1802, sizeof(void*)*3, x_1778);
x_5 = x_1802;
x_6 = x_3;
x_7 = x_1797;
x_8 = x_1798;
x_9 = x_1799;
x_10 = x_1796;
x_11 = x_1779;
goto block_16;
}
}
else
{
uint8_t x_1803; 
x_1803 = lean_ctor_get_uint8(x_1779, sizeof(void*)*3);
if (x_1803 == 0)
{
lean_object* x_1804; lean_object* x_1805; lean_object* x_1806; lean_object* x_1807; uint8_t x_1808; 
x_1804 = lean_ctor_get(x_2, 1);
lean_inc(x_1804);
lean_dec_ref(x_2);
x_1805 = lean_ctor_get(x_86, 0);
lean_inc(x_1805);
x_1806 = lean_ctor_get(x_86, 1);
lean_inc(x_1806);
x_1807 = lean_ctor_get(x_86, 2);
lean_inc(x_1807);
lean_dec_ref(x_86);
x_1808 = !lean_is_exclusive(x_4);
if (x_1808 == 0)
{
lean_object* x_1809; lean_object* x_1810; lean_object* x_1811; uint8_t x_1812; 
x_1809 = lean_ctor_get(x_4, 1);
x_1810 = lean_ctor_get(x_4, 2);
lean_dec(x_1810);
x_1811 = lean_ctor_get(x_4, 0);
lean_dec(x_1811);
x_1812 = !lean_is_exclusive(x_1659);
if (x_1812 == 0)
{
lean_object* x_1813; lean_object* x_1814; lean_object* x_1815; 
x_1813 = lean_ctor_get(x_1659, 0);
x_1814 = lean_ctor_get(x_1659, 1);
x_1815 = lean_ctor_get(x_1659, 2);
lean_ctor_set(x_1659, 2, x_1807);
lean_ctor_set(x_1659, 1, x_1806);
lean_ctor_set(x_1659, 0, x_1805);
lean_ctor_set_uint8(x_1659, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1804);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1803);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1813;
x_8 = x_1814;
x_9 = x_1815;
x_10 = x_1809;
x_11 = x_1779;
goto block_16;
}
else
{
lean_object* x_1816; lean_object* x_1817; lean_object* x_1818; lean_object* x_1819; 
x_1816 = lean_ctor_get(x_1659, 0);
x_1817 = lean_ctor_get(x_1659, 1);
x_1818 = lean_ctor_get(x_1659, 2);
lean_inc(x_1818);
lean_inc(x_1817);
lean_inc(x_1816);
lean_dec(x_1659);
x_1819 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1819, 0, x_1805);
lean_ctor_set(x_1819, 1, x_1806);
lean_ctor_set(x_1819, 2, x_1807);
lean_ctor_set_uint8(x_1819, sizeof(void*)*3, x_1440);
lean_ctor_set(x_4, 2, x_1179);
lean_ctor_set(x_4, 1, x_1804);
lean_ctor_set(x_4, 0, x_1819);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1803);
x_5 = x_4;
x_6 = x_3;
x_7 = x_1816;
x_8 = x_1817;
x_9 = x_1818;
x_10 = x_1809;
x_11 = x_1779;
goto block_16;
}
}
else
{
lean_object* x_1820; lean_object* x_1821; lean_object* x_1822; lean_object* x_1823; lean_object* x_1824; lean_object* x_1825; lean_object* x_1826; 
x_1820 = lean_ctor_get(x_4, 1);
lean_inc(x_1820);
lean_dec(x_4);
x_1821 = lean_ctor_get(x_1659, 0);
lean_inc(x_1821);
x_1822 = lean_ctor_get(x_1659, 1);
lean_inc(x_1822);
x_1823 = lean_ctor_get(x_1659, 2);
lean_inc(x_1823);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_1824 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_1824 = lean_box(0);
}
if (lean_is_scalar(x_1824)) {
 x_1825 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1825 = x_1824;
}
lean_ctor_set(x_1825, 0, x_1805);
lean_ctor_set(x_1825, 1, x_1806);
lean_ctor_set(x_1825, 2, x_1807);
lean_ctor_set_uint8(x_1825, sizeof(void*)*3, x_1440);
x_1826 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1826, 0, x_1825);
lean_ctor_set(x_1826, 1, x_1804);
lean_ctor_set(x_1826, 2, x_1179);
lean_ctor_set_uint8(x_1826, sizeof(void*)*3, x_1803);
x_5 = x_1826;
x_6 = x_3;
x_7 = x_1821;
x_8 = x_1822;
x_9 = x_1823;
x_10 = x_1820;
x_11 = x_1779;
goto block_16;
}
}
else
{
lean_object* x_1827; lean_object* x_1828; lean_object* x_1829; lean_object* x_1830; uint8_t x_1831; 
x_1827 = lean_ctor_get(x_2, 1);
lean_inc(x_1827);
lean_dec_ref(x_2);
x_1828 = lean_ctor_get(x_86, 0);
lean_inc(x_1828);
x_1829 = lean_ctor_get(x_86, 1);
lean_inc(x_1829);
x_1830 = lean_ctor_get(x_86, 2);
lean_inc(x_1830);
lean_dec_ref(x_86);
x_1831 = !lean_is_exclusive(x_1179);
if (x_1831 == 0)
{
uint8_t x_1832; 
x_1832 = !lean_is_exclusive(x_4);
if (x_1832 == 0)
{
lean_object* x_1833; lean_object* x_1834; lean_object* x_1835; lean_object* x_1836; lean_object* x_1837; lean_object* x_1838; uint8_t x_1839; 
x_1833 = lean_ctor_get(x_1179, 0);
x_1834 = lean_ctor_get(x_1179, 1);
x_1835 = lean_ctor_get(x_1179, 2);
x_1836 = lean_ctor_get(x_4, 1);
x_1837 = lean_ctor_get(x_4, 2);
lean_dec(x_1837);
x_1838 = lean_ctor_get(x_4, 0);
lean_dec(x_1838);
x_1839 = !lean_is_exclusive(x_1659);
if (x_1839 == 0)
{
lean_object* x_1840; lean_object* x_1841; lean_object* x_1842; 
x_1840 = lean_ctor_get(x_1659, 0);
x_1841 = lean_ctor_get(x_1659, 1);
x_1842 = lean_ctor_get(x_1659, 2);
lean_ctor_set(x_1659, 2, x_1830);
lean_ctor_set(x_1659, 1, x_1829);
lean_ctor_set(x_1659, 0, x_1828);
lean_ctor_set_uint8(x_1659, sizeof(void*)*3, x_1803);
lean_ctor_set(x_4, 2, x_1835);
lean_ctor_set(x_4, 1, x_1834);
lean_ctor_set(x_4, 0, x_1833);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1803);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1827);
lean_ctor_set(x_1179, 0, x_1659);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1778);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1840;
x_8 = x_1841;
x_9 = x_1842;
x_10 = x_1836;
x_11 = x_1779;
goto block_16;
}
else
{
lean_object* x_1843; lean_object* x_1844; lean_object* x_1845; lean_object* x_1846; 
x_1843 = lean_ctor_get(x_1659, 0);
x_1844 = lean_ctor_get(x_1659, 1);
x_1845 = lean_ctor_get(x_1659, 2);
lean_inc(x_1845);
lean_inc(x_1844);
lean_inc(x_1843);
lean_dec(x_1659);
x_1846 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1846, 0, x_1828);
lean_ctor_set(x_1846, 1, x_1829);
lean_ctor_set(x_1846, 2, x_1830);
lean_ctor_set_uint8(x_1846, sizeof(void*)*3, x_1803);
lean_ctor_set(x_4, 2, x_1835);
lean_ctor_set(x_4, 1, x_1834);
lean_ctor_set(x_4, 0, x_1833);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1803);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1827);
lean_ctor_set(x_1179, 0, x_1846);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1778);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1843;
x_8 = x_1844;
x_9 = x_1845;
x_10 = x_1836;
x_11 = x_1779;
goto block_16;
}
}
else
{
lean_object* x_1847; lean_object* x_1848; lean_object* x_1849; lean_object* x_1850; lean_object* x_1851; lean_object* x_1852; lean_object* x_1853; lean_object* x_1854; lean_object* x_1855; lean_object* x_1856; 
x_1847 = lean_ctor_get(x_1179, 0);
x_1848 = lean_ctor_get(x_1179, 1);
x_1849 = lean_ctor_get(x_1179, 2);
x_1850 = lean_ctor_get(x_4, 1);
lean_inc(x_1850);
lean_dec(x_4);
x_1851 = lean_ctor_get(x_1659, 0);
lean_inc(x_1851);
x_1852 = lean_ctor_get(x_1659, 1);
lean_inc(x_1852);
x_1853 = lean_ctor_get(x_1659, 2);
lean_inc(x_1853);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_1854 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_1854 = lean_box(0);
}
if (lean_is_scalar(x_1854)) {
 x_1855 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1855 = x_1854;
}
lean_ctor_set(x_1855, 0, x_1828);
lean_ctor_set(x_1855, 1, x_1829);
lean_ctor_set(x_1855, 2, x_1830);
lean_ctor_set_uint8(x_1855, sizeof(void*)*3, x_1803);
x_1856 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1856, 0, x_1847);
lean_ctor_set(x_1856, 1, x_1848);
lean_ctor_set(x_1856, 2, x_1849);
lean_ctor_set_uint8(x_1856, sizeof(void*)*3, x_1803);
lean_ctor_set(x_1179, 2, x_1856);
lean_ctor_set(x_1179, 1, x_1827);
lean_ctor_set(x_1179, 0, x_1855);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1778);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1851;
x_8 = x_1852;
x_9 = x_1853;
x_10 = x_1850;
x_11 = x_1779;
goto block_16;
}
}
else
{
lean_object* x_1857; lean_object* x_1858; lean_object* x_1859; lean_object* x_1860; lean_object* x_1861; lean_object* x_1862; lean_object* x_1863; lean_object* x_1864; lean_object* x_1865; lean_object* x_1866; lean_object* x_1867; lean_object* x_1868; 
x_1857 = lean_ctor_get(x_1179, 0);
x_1858 = lean_ctor_get(x_1179, 1);
x_1859 = lean_ctor_get(x_1179, 2);
lean_inc(x_1859);
lean_inc(x_1858);
lean_inc(x_1857);
lean_dec(x_1179);
x_1860 = lean_ctor_get(x_4, 1);
lean_inc(x_1860);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1861 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1861 = lean_box(0);
}
x_1862 = lean_ctor_get(x_1659, 0);
lean_inc(x_1862);
x_1863 = lean_ctor_get(x_1659, 1);
lean_inc(x_1863);
x_1864 = lean_ctor_get(x_1659, 2);
lean_inc(x_1864);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_1865 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_1865 = lean_box(0);
}
if (lean_is_scalar(x_1865)) {
 x_1866 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1866 = x_1865;
}
lean_ctor_set(x_1866, 0, x_1828);
lean_ctor_set(x_1866, 1, x_1829);
lean_ctor_set(x_1866, 2, x_1830);
lean_ctor_set_uint8(x_1866, sizeof(void*)*3, x_1803);
if (lean_is_scalar(x_1861)) {
 x_1867 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1867 = x_1861;
}
lean_ctor_set(x_1867, 0, x_1857);
lean_ctor_set(x_1867, 1, x_1858);
lean_ctor_set(x_1867, 2, x_1859);
lean_ctor_set_uint8(x_1867, sizeof(void*)*3, x_1803);
x_1868 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1868, 0, x_1866);
lean_ctor_set(x_1868, 1, x_1827);
lean_ctor_set(x_1868, 2, x_1867);
lean_ctor_set_uint8(x_1868, sizeof(void*)*3, x_1778);
x_5 = x_1868;
x_6 = x_3;
x_7 = x_1862;
x_8 = x_1863;
x_9 = x_1864;
x_10 = x_1860;
x_11 = x_1779;
goto block_16;
}
}
}
}
else
{
lean_object* x_1869; 
x_1869 = lean_ctor_get(x_4, 2);
lean_inc(x_1869);
if (lean_obj_tag(x_1869) == 0)
{
uint8_t x_1870; 
x_1870 = !lean_is_exclusive(x_1659);
if (x_1870 == 0)
{
lean_object* x_1871; lean_object* x_1872; lean_object* x_1873; uint8_t x_1874; 
x_1871 = lean_ctor_get(x_1659, 2);
lean_dec(x_1871);
x_1872 = lean_ctor_get(x_1659, 1);
lean_dec(x_1872);
x_1873 = lean_ctor_get(x_1659, 0);
lean_dec(x_1873);
x_1874 = !lean_is_exclusive(x_2);
if (x_1874 == 0)
{
lean_object* x_1875; lean_object* x_1876; lean_object* x_1877; uint8_t x_1878; 
x_1875 = lean_ctor_get(x_2, 1);
x_1876 = lean_ctor_get(x_2, 2);
lean_dec(x_1876);
x_1877 = lean_ctor_get(x_2, 0);
lean_dec(x_1877);
x_1878 = !lean_is_exclusive(x_86);
if (x_1878 == 0)
{
uint8_t x_1879; 
x_1879 = !lean_is_exclusive(x_1179);
if (x_1879 == 0)
{
lean_object* x_1880; lean_object* x_1881; lean_object* x_1882; 
x_1880 = lean_ctor_get(x_86, 0);
x_1881 = lean_ctor_get(x_86, 1);
x_1882 = lean_ctor_get(x_86, 2);
lean_ctor_set(x_1659, 2, x_1882);
lean_ctor_set(x_1659, 1, x_1881);
lean_ctor_set(x_1659, 0, x_1880);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1778);
lean_ctor_set(x_86, 2, x_1179);
lean_ctor_set(x_86, 1, x_1875);
lean_ctor_set(x_86, 0, x_1659);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1778);
return x_2;
}
else
{
lean_object* x_1883; lean_object* x_1884; lean_object* x_1885; lean_object* x_1886; lean_object* x_1887; lean_object* x_1888; lean_object* x_1889; 
x_1883 = lean_ctor_get(x_86, 0);
x_1884 = lean_ctor_get(x_86, 1);
x_1885 = lean_ctor_get(x_86, 2);
x_1886 = lean_ctor_get(x_1179, 0);
x_1887 = lean_ctor_get(x_1179, 1);
x_1888 = lean_ctor_get(x_1179, 2);
lean_inc(x_1888);
lean_inc(x_1887);
lean_inc(x_1886);
lean_dec(x_1179);
lean_ctor_set(x_1659, 2, x_1885);
lean_ctor_set(x_1659, 1, x_1884);
lean_ctor_set(x_1659, 0, x_1883);
x_1889 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1889, 0, x_1886);
lean_ctor_set(x_1889, 1, x_1887);
lean_ctor_set(x_1889, 2, x_1888);
lean_ctor_set_uint8(x_1889, sizeof(void*)*3, x_1778);
lean_ctor_set(x_86, 2, x_1889);
lean_ctor_set(x_86, 1, x_1875);
lean_ctor_set(x_86, 0, x_1659);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1778);
return x_2;
}
}
else
{
lean_object* x_1890; lean_object* x_1891; lean_object* x_1892; lean_object* x_1893; lean_object* x_1894; lean_object* x_1895; lean_object* x_1896; lean_object* x_1897; lean_object* x_1898; 
x_1890 = lean_ctor_get(x_86, 0);
x_1891 = lean_ctor_get(x_86, 1);
x_1892 = lean_ctor_get(x_86, 2);
lean_inc(x_1892);
lean_inc(x_1891);
lean_inc(x_1890);
lean_dec(x_86);
x_1893 = lean_ctor_get(x_1179, 0);
lean_inc(x_1893);
x_1894 = lean_ctor_get(x_1179, 1);
lean_inc(x_1894);
x_1895 = lean_ctor_get(x_1179, 2);
lean_inc(x_1895);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1896 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1896 = lean_box(0);
}
lean_ctor_set(x_1659, 2, x_1892);
lean_ctor_set(x_1659, 1, x_1891);
lean_ctor_set(x_1659, 0, x_1890);
if (lean_is_scalar(x_1896)) {
 x_1897 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1897 = x_1896;
}
lean_ctor_set(x_1897, 0, x_1893);
lean_ctor_set(x_1897, 1, x_1894);
lean_ctor_set(x_1897, 2, x_1895);
lean_ctor_set_uint8(x_1897, sizeof(void*)*3, x_1778);
x_1898 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1898, 0, x_1659);
lean_ctor_set(x_1898, 1, x_1875);
lean_ctor_set(x_1898, 2, x_1897);
lean_ctor_set_uint8(x_1898, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_1898);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1778);
return x_2;
}
}
else
{
lean_object* x_1899; lean_object* x_1900; lean_object* x_1901; lean_object* x_1902; lean_object* x_1903; lean_object* x_1904; lean_object* x_1905; lean_object* x_1906; lean_object* x_1907; lean_object* x_1908; lean_object* x_1909; lean_object* x_1910; 
x_1899 = lean_ctor_get(x_2, 1);
lean_inc(x_1899);
lean_dec(x_2);
x_1900 = lean_ctor_get(x_86, 0);
lean_inc(x_1900);
x_1901 = lean_ctor_get(x_86, 1);
lean_inc(x_1901);
x_1902 = lean_ctor_get(x_86, 2);
lean_inc(x_1902);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1903 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1903 = lean_box(0);
}
x_1904 = lean_ctor_get(x_1179, 0);
lean_inc(x_1904);
x_1905 = lean_ctor_get(x_1179, 1);
lean_inc(x_1905);
x_1906 = lean_ctor_get(x_1179, 2);
lean_inc(x_1906);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1907 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1907 = lean_box(0);
}
lean_ctor_set(x_1659, 2, x_1902);
lean_ctor_set(x_1659, 1, x_1901);
lean_ctor_set(x_1659, 0, x_1900);
if (lean_is_scalar(x_1907)) {
 x_1908 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1908 = x_1907;
}
lean_ctor_set(x_1908, 0, x_1904);
lean_ctor_set(x_1908, 1, x_1905);
lean_ctor_set(x_1908, 2, x_1906);
lean_ctor_set_uint8(x_1908, sizeof(void*)*3, x_1778);
if (lean_is_scalar(x_1903)) {
 x_1909 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1909 = x_1903;
}
lean_ctor_set(x_1909, 0, x_1659);
lean_ctor_set(x_1909, 1, x_1899);
lean_ctor_set(x_1909, 2, x_1908);
lean_ctor_set_uint8(x_1909, sizeof(void*)*3, x_1658);
x_1910 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1910, 0, x_1909);
lean_ctor_set(x_1910, 1, x_3);
lean_ctor_set(x_1910, 2, x_4);
lean_ctor_set_uint8(x_1910, sizeof(void*)*3, x_1778);
return x_1910;
}
}
else
{
lean_object* x_1911; lean_object* x_1912; lean_object* x_1913; lean_object* x_1914; lean_object* x_1915; lean_object* x_1916; lean_object* x_1917; lean_object* x_1918; lean_object* x_1919; lean_object* x_1920; lean_object* x_1921; lean_object* x_1922; lean_object* x_1923; lean_object* x_1924; 
lean_dec(x_1659);
x_1911 = lean_ctor_get(x_2, 1);
lean_inc(x_1911);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_1912 = x_2;
} else {
 lean_dec_ref(x_2);
 x_1912 = lean_box(0);
}
x_1913 = lean_ctor_get(x_86, 0);
lean_inc(x_1913);
x_1914 = lean_ctor_get(x_86, 1);
lean_inc(x_1914);
x_1915 = lean_ctor_get(x_86, 2);
lean_inc(x_1915);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_1916 = x_86;
} else {
 lean_dec_ref(x_86);
 x_1916 = lean_box(0);
}
x_1917 = lean_ctor_get(x_1179, 0);
lean_inc(x_1917);
x_1918 = lean_ctor_get(x_1179, 1);
lean_inc(x_1918);
x_1919 = lean_ctor_get(x_1179, 2);
lean_inc(x_1919);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_1920 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_1920 = lean_box(0);
}
x_1921 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1921, 0, x_1913);
lean_ctor_set(x_1921, 1, x_1914);
lean_ctor_set(x_1921, 2, x_1915);
lean_ctor_set_uint8(x_1921, sizeof(void*)*3, x_1778);
if (lean_is_scalar(x_1920)) {
 x_1922 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1922 = x_1920;
}
lean_ctor_set(x_1922, 0, x_1917);
lean_ctor_set(x_1922, 1, x_1918);
lean_ctor_set(x_1922, 2, x_1919);
lean_ctor_set_uint8(x_1922, sizeof(void*)*3, x_1778);
if (lean_is_scalar(x_1916)) {
 x_1923 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1923 = x_1916;
}
lean_ctor_set(x_1923, 0, x_1921);
lean_ctor_set(x_1923, 1, x_1911);
lean_ctor_set(x_1923, 2, x_1922);
lean_ctor_set_uint8(x_1923, sizeof(void*)*3, x_1658);
if (lean_is_scalar(x_1912)) {
 x_1924 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1924 = x_1912;
}
lean_ctor_set(x_1924, 0, x_1923);
lean_ctor_set(x_1924, 1, x_3);
lean_ctor_set(x_1924, 2, x_4);
lean_ctor_set_uint8(x_1924, sizeof(void*)*3, x_1778);
return x_1924;
}
}
else
{
uint8_t x_1925; 
x_1925 = lean_ctor_get_uint8(x_1869, sizeof(void*)*3);
if (x_1925 == 0)
{
lean_object* x_1926; lean_object* x_1927; lean_object* x_1928; lean_object* x_1929; uint8_t x_1930; 
x_1926 = lean_ctor_get(x_2, 1);
lean_inc(x_1926);
lean_dec_ref(x_2);
x_1927 = lean_ctor_get(x_86, 0);
lean_inc(x_1927);
x_1928 = lean_ctor_get(x_86, 1);
lean_inc(x_1928);
x_1929 = lean_ctor_get(x_86, 2);
lean_inc(x_1929);
lean_dec_ref(x_86);
x_1930 = !lean_is_exclusive(x_1179);
if (x_1930 == 0)
{
uint8_t x_1931; 
x_1931 = !lean_is_exclusive(x_4);
if (x_1931 == 0)
{
lean_object* x_1932; lean_object* x_1933; lean_object* x_1934; lean_object* x_1935; lean_object* x_1936; lean_object* x_1937; uint8_t x_1938; 
x_1932 = lean_ctor_get(x_1179, 0);
x_1933 = lean_ctor_get(x_1179, 1);
x_1934 = lean_ctor_get(x_1179, 2);
x_1935 = lean_ctor_get(x_4, 1);
x_1936 = lean_ctor_get(x_4, 2);
lean_dec(x_1936);
x_1937 = lean_ctor_get(x_4, 0);
lean_dec(x_1937);
x_1938 = !lean_is_exclusive(x_1869);
if (x_1938 == 0)
{
lean_object* x_1939; lean_object* x_1940; lean_object* x_1941; 
x_1939 = lean_ctor_get(x_1869, 0);
x_1940 = lean_ctor_get(x_1869, 1);
x_1941 = lean_ctor_get(x_1869, 2);
lean_ctor_set(x_1869, 2, x_1929);
lean_ctor_set(x_1869, 1, x_1928);
lean_ctor_set(x_1869, 0, x_1927);
lean_ctor_set_uint8(x_1869, sizeof(void*)*3, x_1778);
lean_ctor_set(x_4, 2, x_1934);
lean_ctor_set(x_4, 1, x_1933);
lean_ctor_set(x_4, 0, x_1932);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1778);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1926);
lean_ctor_set(x_1179, 0, x_1869);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1925);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1935;
x_9 = x_1939;
x_10 = x_1940;
x_11 = x_1941;
goto block_16;
}
else
{
lean_object* x_1942; lean_object* x_1943; lean_object* x_1944; lean_object* x_1945; 
x_1942 = lean_ctor_get(x_1869, 0);
x_1943 = lean_ctor_get(x_1869, 1);
x_1944 = lean_ctor_get(x_1869, 2);
lean_inc(x_1944);
lean_inc(x_1943);
lean_inc(x_1942);
lean_dec(x_1869);
x_1945 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1945, 0, x_1927);
lean_ctor_set(x_1945, 1, x_1928);
lean_ctor_set(x_1945, 2, x_1929);
lean_ctor_set_uint8(x_1945, sizeof(void*)*3, x_1778);
lean_ctor_set(x_4, 2, x_1934);
lean_ctor_set(x_4, 1, x_1933);
lean_ctor_set(x_4, 0, x_1932);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1778);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1926);
lean_ctor_set(x_1179, 0, x_1945);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1925);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1935;
x_9 = x_1942;
x_10 = x_1943;
x_11 = x_1944;
goto block_16;
}
}
else
{
lean_object* x_1946; lean_object* x_1947; lean_object* x_1948; lean_object* x_1949; lean_object* x_1950; lean_object* x_1951; lean_object* x_1952; lean_object* x_1953; lean_object* x_1954; lean_object* x_1955; 
x_1946 = lean_ctor_get(x_1179, 0);
x_1947 = lean_ctor_get(x_1179, 1);
x_1948 = lean_ctor_get(x_1179, 2);
x_1949 = lean_ctor_get(x_4, 1);
lean_inc(x_1949);
lean_dec(x_4);
x_1950 = lean_ctor_get(x_1869, 0);
lean_inc(x_1950);
x_1951 = lean_ctor_get(x_1869, 1);
lean_inc(x_1951);
x_1952 = lean_ctor_get(x_1869, 2);
lean_inc(x_1952);
if (lean_is_exclusive(x_1869)) {
 lean_ctor_release(x_1869, 0);
 lean_ctor_release(x_1869, 1);
 lean_ctor_release(x_1869, 2);
 x_1953 = x_1869;
} else {
 lean_dec_ref(x_1869);
 x_1953 = lean_box(0);
}
if (lean_is_scalar(x_1953)) {
 x_1954 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1954 = x_1953;
}
lean_ctor_set(x_1954, 0, x_1927);
lean_ctor_set(x_1954, 1, x_1928);
lean_ctor_set(x_1954, 2, x_1929);
lean_ctor_set_uint8(x_1954, sizeof(void*)*3, x_1778);
x_1955 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1955, 0, x_1946);
lean_ctor_set(x_1955, 1, x_1947);
lean_ctor_set(x_1955, 2, x_1948);
lean_ctor_set_uint8(x_1955, sizeof(void*)*3, x_1778);
lean_ctor_set(x_1179, 2, x_1955);
lean_ctor_set(x_1179, 1, x_1926);
lean_ctor_set(x_1179, 0, x_1954);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1925);
x_5 = x_1179;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1949;
x_9 = x_1950;
x_10 = x_1951;
x_11 = x_1952;
goto block_16;
}
}
else
{
lean_object* x_1956; lean_object* x_1957; lean_object* x_1958; lean_object* x_1959; lean_object* x_1960; lean_object* x_1961; lean_object* x_1962; lean_object* x_1963; lean_object* x_1964; lean_object* x_1965; lean_object* x_1966; lean_object* x_1967; 
x_1956 = lean_ctor_get(x_1179, 0);
x_1957 = lean_ctor_get(x_1179, 1);
x_1958 = lean_ctor_get(x_1179, 2);
lean_inc(x_1958);
lean_inc(x_1957);
lean_inc(x_1956);
lean_dec(x_1179);
x_1959 = lean_ctor_get(x_4, 1);
lean_inc(x_1959);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_1960 = x_4;
} else {
 lean_dec_ref(x_4);
 x_1960 = lean_box(0);
}
x_1961 = lean_ctor_get(x_1869, 0);
lean_inc(x_1961);
x_1962 = lean_ctor_get(x_1869, 1);
lean_inc(x_1962);
x_1963 = lean_ctor_get(x_1869, 2);
lean_inc(x_1963);
if (lean_is_exclusive(x_1869)) {
 lean_ctor_release(x_1869, 0);
 lean_ctor_release(x_1869, 1);
 lean_ctor_release(x_1869, 2);
 x_1964 = x_1869;
} else {
 lean_dec_ref(x_1869);
 x_1964 = lean_box(0);
}
if (lean_is_scalar(x_1964)) {
 x_1965 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1965 = x_1964;
}
lean_ctor_set(x_1965, 0, x_1927);
lean_ctor_set(x_1965, 1, x_1928);
lean_ctor_set(x_1965, 2, x_1929);
lean_ctor_set_uint8(x_1965, sizeof(void*)*3, x_1778);
if (lean_is_scalar(x_1960)) {
 x_1966 = lean_alloc_ctor(1, 3, 1);
} else {
 x_1966 = x_1960;
}
lean_ctor_set(x_1966, 0, x_1956);
lean_ctor_set(x_1966, 1, x_1957);
lean_ctor_set(x_1966, 2, x_1958);
lean_ctor_set_uint8(x_1966, sizeof(void*)*3, x_1778);
x_1967 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1967, 0, x_1965);
lean_ctor_set(x_1967, 1, x_1926);
lean_ctor_set(x_1967, 2, x_1966);
lean_ctor_set_uint8(x_1967, sizeof(void*)*3, x_1925);
x_5 = x_1967;
x_6 = x_3;
x_7 = x_1659;
x_8 = x_1959;
x_9 = x_1961;
x_10 = x_1962;
x_11 = x_1963;
goto block_16;
}
}
else
{
uint8_t x_1968; 
x_1968 = !lean_is_exclusive(x_2);
if (x_1968 == 0)
{
lean_object* x_1969; lean_object* x_1970; lean_object* x_1971; uint8_t x_1972; 
x_1969 = lean_ctor_get(x_2, 1);
x_1970 = lean_ctor_get(x_2, 2);
lean_dec(x_1970);
x_1971 = lean_ctor_get(x_2, 0);
lean_dec(x_1971);
x_1972 = !lean_is_exclusive(x_86);
if (x_1972 == 0)
{
uint8_t x_1973; 
x_1973 = !lean_is_exclusive(x_1179);
if (x_1973 == 0)
{
uint8_t x_1974; 
x_1974 = !lean_is_exclusive(x_4);
if (x_1974 == 0)
{
lean_object* x_1975; lean_object* x_1976; lean_object* x_1977; lean_object* x_1978; lean_object* x_1979; lean_object* x_1980; lean_object* x_1981; lean_object* x_1982; lean_object* x_1983; uint8_t x_1984; 
x_1975 = lean_ctor_get(x_86, 0);
x_1976 = lean_ctor_get(x_86, 1);
x_1977 = lean_ctor_get(x_86, 2);
x_1978 = lean_ctor_get(x_1179, 0);
x_1979 = lean_ctor_get(x_1179, 1);
x_1980 = lean_ctor_get(x_1179, 2);
x_1981 = lean_ctor_get(x_4, 1);
x_1982 = lean_ctor_get(x_4, 2);
lean_dec(x_1982);
x_1983 = lean_ctor_get(x_4, 0);
lean_dec(x_1983);
x_1984 = !lean_is_exclusive(x_1659);
if (x_1984 == 0)
{
lean_object* x_1985; lean_object* x_1986; lean_object* x_1987; lean_object* x_1988; 
x_1985 = lean_ctor_get(x_1659, 0);
x_1986 = lean_ctor_get(x_1659, 1);
x_1987 = lean_ctor_get(x_1659, 2);
lean_ctor_set(x_1659, 2, x_1977);
lean_ctor_set(x_1659, 1, x_1976);
lean_ctor_set(x_1659, 0, x_1975);
lean_ctor_set_uint8(x_1659, sizeof(void*)*3, x_1925);
lean_ctor_set(x_4, 2, x_1980);
lean_ctor_set(x_4, 1, x_1979);
lean_ctor_set(x_4, 0, x_1978);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1925);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1969);
lean_ctor_set(x_1179, 0, x_1659);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_1987);
lean_ctor_set(x_86, 1, x_1986);
lean_ctor_set(x_86, 0, x_1985);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1925);
lean_ctor_set(x_2, 2, x_1869);
lean_ctor_set(x_2, 1, x_1981);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_1988 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1988, 0, x_1179);
lean_ctor_set(x_1988, 1, x_3);
lean_ctor_set(x_1988, 2, x_2);
lean_ctor_set_uint8(x_1988, sizeof(void*)*3, x_1925);
return x_1988;
}
else
{
lean_object* x_1989; lean_object* x_1990; lean_object* x_1991; lean_object* x_1992; lean_object* x_1993; 
x_1989 = lean_ctor_get(x_1659, 0);
x_1990 = lean_ctor_get(x_1659, 1);
x_1991 = lean_ctor_get(x_1659, 2);
lean_inc(x_1991);
lean_inc(x_1990);
lean_inc(x_1989);
lean_dec(x_1659);
x_1992 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1992, 0, x_1975);
lean_ctor_set(x_1992, 1, x_1976);
lean_ctor_set(x_1992, 2, x_1977);
lean_ctor_set_uint8(x_1992, sizeof(void*)*3, x_1925);
lean_ctor_set(x_4, 2, x_1980);
lean_ctor_set(x_4, 1, x_1979);
lean_ctor_set(x_4, 0, x_1978);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1925);
lean_ctor_set(x_1179, 2, x_4);
lean_ctor_set(x_1179, 1, x_1969);
lean_ctor_set(x_1179, 0, x_1992);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_1991);
lean_ctor_set(x_86, 1, x_1990);
lean_ctor_set(x_86, 0, x_1989);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1925);
lean_ctor_set(x_2, 2, x_1869);
lean_ctor_set(x_2, 1, x_1981);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_1993 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_1993, 0, x_1179);
lean_ctor_set(x_1993, 1, x_3);
lean_ctor_set(x_1993, 2, x_2);
lean_ctor_set_uint8(x_1993, sizeof(void*)*3, x_1925);
return x_1993;
}
}
else
{
lean_object* x_1994; lean_object* x_1995; lean_object* x_1996; lean_object* x_1997; lean_object* x_1998; lean_object* x_1999; lean_object* x_2000; lean_object* x_2001; lean_object* x_2002; lean_object* x_2003; lean_object* x_2004; lean_object* x_2005; lean_object* x_2006; lean_object* x_2007; 
x_1994 = lean_ctor_get(x_86, 0);
x_1995 = lean_ctor_get(x_86, 1);
x_1996 = lean_ctor_get(x_86, 2);
x_1997 = lean_ctor_get(x_1179, 0);
x_1998 = lean_ctor_get(x_1179, 1);
x_1999 = lean_ctor_get(x_1179, 2);
x_2000 = lean_ctor_get(x_4, 1);
lean_inc(x_2000);
lean_dec(x_4);
x_2001 = lean_ctor_get(x_1659, 0);
lean_inc(x_2001);
x_2002 = lean_ctor_get(x_1659, 1);
lean_inc(x_2002);
x_2003 = lean_ctor_get(x_1659, 2);
lean_inc(x_2003);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_2004 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_2004 = lean_box(0);
}
if (lean_is_scalar(x_2004)) {
 x_2005 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2005 = x_2004;
}
lean_ctor_set(x_2005, 0, x_1994);
lean_ctor_set(x_2005, 1, x_1995);
lean_ctor_set(x_2005, 2, x_1996);
lean_ctor_set_uint8(x_2005, sizeof(void*)*3, x_1925);
x_2006 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2006, 0, x_1997);
lean_ctor_set(x_2006, 1, x_1998);
lean_ctor_set(x_2006, 2, x_1999);
lean_ctor_set_uint8(x_2006, sizeof(void*)*3, x_1925);
lean_ctor_set(x_1179, 2, x_2006);
lean_ctor_set(x_1179, 1, x_1969);
lean_ctor_set(x_1179, 0, x_2005);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_2003);
lean_ctor_set(x_86, 1, x_2002);
lean_ctor_set(x_86, 0, x_2001);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1925);
lean_ctor_set(x_2, 2, x_1869);
lean_ctor_set(x_2, 1, x_2000);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_2007 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2007, 0, x_1179);
lean_ctor_set(x_2007, 1, x_3);
lean_ctor_set(x_2007, 2, x_2);
lean_ctor_set_uint8(x_2007, sizeof(void*)*3, x_1925);
return x_2007;
}
}
else
{
lean_object* x_2008; lean_object* x_2009; lean_object* x_2010; lean_object* x_2011; lean_object* x_2012; lean_object* x_2013; lean_object* x_2014; lean_object* x_2015; lean_object* x_2016; lean_object* x_2017; lean_object* x_2018; lean_object* x_2019; lean_object* x_2020; lean_object* x_2021; lean_object* x_2022; lean_object* x_2023; 
x_2008 = lean_ctor_get(x_86, 0);
x_2009 = lean_ctor_get(x_86, 1);
x_2010 = lean_ctor_get(x_86, 2);
x_2011 = lean_ctor_get(x_1179, 0);
x_2012 = lean_ctor_get(x_1179, 1);
x_2013 = lean_ctor_get(x_1179, 2);
lean_inc(x_2013);
lean_inc(x_2012);
lean_inc(x_2011);
lean_dec(x_1179);
x_2014 = lean_ctor_get(x_4, 1);
lean_inc(x_2014);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_2015 = x_4;
} else {
 lean_dec_ref(x_4);
 x_2015 = lean_box(0);
}
x_2016 = lean_ctor_get(x_1659, 0);
lean_inc(x_2016);
x_2017 = lean_ctor_get(x_1659, 1);
lean_inc(x_2017);
x_2018 = lean_ctor_get(x_1659, 2);
lean_inc(x_2018);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_2019 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_2019 = lean_box(0);
}
if (lean_is_scalar(x_2019)) {
 x_2020 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2020 = x_2019;
}
lean_ctor_set(x_2020, 0, x_2008);
lean_ctor_set(x_2020, 1, x_2009);
lean_ctor_set(x_2020, 2, x_2010);
lean_ctor_set_uint8(x_2020, sizeof(void*)*3, x_1925);
if (lean_is_scalar(x_2015)) {
 x_2021 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2021 = x_2015;
}
lean_ctor_set(x_2021, 0, x_2011);
lean_ctor_set(x_2021, 1, x_2012);
lean_ctor_set(x_2021, 2, x_2013);
lean_ctor_set_uint8(x_2021, sizeof(void*)*3, x_1925);
x_2022 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2022, 0, x_2020);
lean_ctor_set(x_2022, 1, x_1969);
lean_ctor_set(x_2022, 2, x_2021);
lean_ctor_set_uint8(x_2022, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_2018);
lean_ctor_set(x_86, 1, x_2017);
lean_ctor_set(x_86, 0, x_2016);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1925);
lean_ctor_set(x_2, 2, x_1869);
lean_ctor_set(x_2, 1, x_2014);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_2023 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2023, 0, x_2022);
lean_ctor_set(x_2023, 1, x_3);
lean_ctor_set(x_2023, 2, x_2);
lean_ctor_set_uint8(x_2023, sizeof(void*)*3, x_1925);
return x_2023;
}
}
else
{
lean_object* x_2024; lean_object* x_2025; lean_object* x_2026; lean_object* x_2027; lean_object* x_2028; lean_object* x_2029; lean_object* x_2030; lean_object* x_2031; lean_object* x_2032; lean_object* x_2033; lean_object* x_2034; lean_object* x_2035; lean_object* x_2036; lean_object* x_2037; lean_object* x_2038; lean_object* x_2039; lean_object* x_2040; lean_object* x_2041; 
x_2024 = lean_ctor_get(x_86, 0);
x_2025 = lean_ctor_get(x_86, 1);
x_2026 = lean_ctor_get(x_86, 2);
lean_inc(x_2026);
lean_inc(x_2025);
lean_inc(x_2024);
lean_dec(x_86);
x_2027 = lean_ctor_get(x_1179, 0);
lean_inc(x_2027);
x_2028 = lean_ctor_get(x_1179, 1);
lean_inc(x_2028);
x_2029 = lean_ctor_get(x_1179, 2);
lean_inc(x_2029);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_2030 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_2030 = lean_box(0);
}
x_2031 = lean_ctor_get(x_4, 1);
lean_inc(x_2031);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_2032 = x_4;
} else {
 lean_dec_ref(x_4);
 x_2032 = lean_box(0);
}
x_2033 = lean_ctor_get(x_1659, 0);
lean_inc(x_2033);
x_2034 = lean_ctor_get(x_1659, 1);
lean_inc(x_2034);
x_2035 = lean_ctor_get(x_1659, 2);
lean_inc(x_2035);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_2036 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_2036 = lean_box(0);
}
if (lean_is_scalar(x_2036)) {
 x_2037 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2037 = x_2036;
}
lean_ctor_set(x_2037, 0, x_2024);
lean_ctor_set(x_2037, 1, x_2025);
lean_ctor_set(x_2037, 2, x_2026);
lean_ctor_set_uint8(x_2037, sizeof(void*)*3, x_1925);
if (lean_is_scalar(x_2032)) {
 x_2038 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2038 = x_2032;
}
lean_ctor_set(x_2038, 0, x_2027);
lean_ctor_set(x_2038, 1, x_2028);
lean_ctor_set(x_2038, 2, x_2029);
lean_ctor_set_uint8(x_2038, sizeof(void*)*3, x_1925);
if (lean_is_scalar(x_2030)) {
 x_2039 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2039 = x_2030;
}
lean_ctor_set(x_2039, 0, x_2037);
lean_ctor_set(x_2039, 1, x_1969);
lean_ctor_set(x_2039, 2, x_2038);
lean_ctor_set_uint8(x_2039, sizeof(void*)*3, x_1658);
x_2040 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2040, 0, x_2033);
lean_ctor_set(x_2040, 1, x_2034);
lean_ctor_set(x_2040, 2, x_2035);
lean_ctor_set_uint8(x_2040, sizeof(void*)*3, x_1925);
lean_ctor_set(x_2, 2, x_1869);
lean_ctor_set(x_2, 1, x_2031);
lean_ctor_set(x_2, 0, x_2040);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_1658);
x_2041 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2041, 0, x_2039);
lean_ctor_set(x_2041, 1, x_3);
lean_ctor_set(x_2041, 2, x_2);
lean_ctor_set_uint8(x_2041, sizeof(void*)*3, x_1925);
return x_2041;
}
}
else
{
lean_object* x_2042; lean_object* x_2043; lean_object* x_2044; lean_object* x_2045; lean_object* x_2046; lean_object* x_2047; lean_object* x_2048; lean_object* x_2049; lean_object* x_2050; lean_object* x_2051; lean_object* x_2052; lean_object* x_2053; lean_object* x_2054; lean_object* x_2055; lean_object* x_2056; lean_object* x_2057; lean_object* x_2058; lean_object* x_2059; lean_object* x_2060; lean_object* x_2061; lean_object* x_2062; 
x_2042 = lean_ctor_get(x_2, 1);
lean_inc(x_2042);
lean_dec(x_2);
x_2043 = lean_ctor_get(x_86, 0);
lean_inc(x_2043);
x_2044 = lean_ctor_get(x_86, 1);
lean_inc(x_2044);
x_2045 = lean_ctor_get(x_86, 2);
lean_inc(x_2045);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_2046 = x_86;
} else {
 lean_dec_ref(x_86);
 x_2046 = lean_box(0);
}
x_2047 = lean_ctor_get(x_1179, 0);
lean_inc(x_2047);
x_2048 = lean_ctor_get(x_1179, 1);
lean_inc(x_2048);
x_2049 = lean_ctor_get(x_1179, 2);
lean_inc(x_2049);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_2050 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_2050 = lean_box(0);
}
x_2051 = lean_ctor_get(x_4, 1);
lean_inc(x_2051);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_2052 = x_4;
} else {
 lean_dec_ref(x_4);
 x_2052 = lean_box(0);
}
x_2053 = lean_ctor_get(x_1659, 0);
lean_inc(x_2053);
x_2054 = lean_ctor_get(x_1659, 1);
lean_inc(x_2054);
x_2055 = lean_ctor_get(x_1659, 2);
lean_inc(x_2055);
if (lean_is_exclusive(x_1659)) {
 lean_ctor_release(x_1659, 0);
 lean_ctor_release(x_1659, 1);
 lean_ctor_release(x_1659, 2);
 x_2056 = x_1659;
} else {
 lean_dec_ref(x_1659);
 x_2056 = lean_box(0);
}
if (lean_is_scalar(x_2056)) {
 x_2057 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2057 = x_2056;
}
lean_ctor_set(x_2057, 0, x_2043);
lean_ctor_set(x_2057, 1, x_2044);
lean_ctor_set(x_2057, 2, x_2045);
lean_ctor_set_uint8(x_2057, sizeof(void*)*3, x_1925);
if (lean_is_scalar(x_2052)) {
 x_2058 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2058 = x_2052;
}
lean_ctor_set(x_2058, 0, x_2047);
lean_ctor_set(x_2058, 1, x_2048);
lean_ctor_set(x_2058, 2, x_2049);
lean_ctor_set_uint8(x_2058, sizeof(void*)*3, x_1925);
if (lean_is_scalar(x_2050)) {
 x_2059 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2059 = x_2050;
}
lean_ctor_set(x_2059, 0, x_2057);
lean_ctor_set(x_2059, 1, x_2042);
lean_ctor_set(x_2059, 2, x_2058);
lean_ctor_set_uint8(x_2059, sizeof(void*)*3, x_1658);
if (lean_is_scalar(x_2046)) {
 x_2060 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2060 = x_2046;
}
lean_ctor_set(x_2060, 0, x_2053);
lean_ctor_set(x_2060, 1, x_2054);
lean_ctor_set(x_2060, 2, x_2055);
lean_ctor_set_uint8(x_2060, sizeof(void*)*3, x_1925);
x_2061 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2061, 0, x_2060);
lean_ctor_set(x_2061, 1, x_2051);
lean_ctor_set(x_2061, 2, x_1869);
lean_ctor_set_uint8(x_2061, sizeof(void*)*3, x_1658);
x_2062 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2062, 0, x_2059);
lean_ctor_set(x_2062, 1, x_3);
lean_ctor_set(x_2062, 2, x_2061);
lean_ctor_set_uint8(x_2062, sizeof(void*)*3, x_1925);
return x_2062;
}
}
}
}
}
}
else
{
uint8_t x_2063; 
x_2063 = !lean_is_exclusive(x_2);
if (x_2063 == 0)
{
lean_object* x_2064; lean_object* x_2065; uint8_t x_2066; 
x_2064 = lean_ctor_get(x_2, 2);
lean_dec(x_2064);
x_2065 = lean_ctor_get(x_2, 0);
lean_dec(x_2065);
x_2066 = !lean_is_exclusive(x_86);
if (x_2066 == 0)
{
uint8_t x_2067; 
x_2067 = !lean_is_exclusive(x_1179);
if (x_2067 == 0)
{
lean_object* x_2068; lean_object* x_2069; lean_object* x_2070; lean_object* x_2071; lean_object* x_2072; lean_object* x_2073; lean_object* x_2074; 
x_2068 = lean_ctor_get(x_86, 0);
x_2069 = lean_ctor_get(x_86, 1);
x_2070 = lean_ctor_get(x_86, 2);
x_2071 = lean_ctor_get(x_1179, 0);
x_2072 = lean_ctor_get(x_1179, 1);
x_2073 = lean_ctor_get(x_1179, 2);
lean_ctor_set(x_1179, 2, x_2070);
lean_ctor_set(x_1179, 1, x_2069);
lean_ctor_set(x_1179, 0, x_2068);
lean_ctor_set_uint8(x_1179, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_2073);
lean_ctor_set(x_86, 1, x_2072);
lean_ctor_set(x_86, 0, x_2071);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_86);
lean_ctor_set(x_2, 0, x_1179);
x_2074 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2074, 0, x_2);
lean_ctor_set(x_2074, 1, x_3);
lean_ctor_set(x_2074, 2, x_4);
lean_ctor_set_uint8(x_2074, sizeof(void*)*3, x_1658);
return x_2074;
}
else
{
lean_object* x_2075; lean_object* x_2076; lean_object* x_2077; lean_object* x_2078; lean_object* x_2079; lean_object* x_2080; lean_object* x_2081; lean_object* x_2082; 
x_2075 = lean_ctor_get(x_86, 0);
x_2076 = lean_ctor_get(x_86, 1);
x_2077 = lean_ctor_get(x_86, 2);
x_2078 = lean_ctor_get(x_1179, 0);
x_2079 = lean_ctor_get(x_1179, 1);
x_2080 = lean_ctor_get(x_1179, 2);
lean_inc(x_2080);
lean_inc(x_2079);
lean_inc(x_2078);
lean_dec(x_1179);
x_2081 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2081, 0, x_2075);
lean_ctor_set(x_2081, 1, x_2076);
lean_ctor_set(x_2081, 2, x_2077);
lean_ctor_set_uint8(x_2081, sizeof(void*)*3, x_1658);
lean_ctor_set(x_86, 2, x_2080);
lean_ctor_set(x_86, 1, x_2079);
lean_ctor_set(x_86, 0, x_2078);
lean_ctor_set_uint8(x_86, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_86);
lean_ctor_set(x_2, 0, x_2081);
x_2082 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2082, 0, x_2);
lean_ctor_set(x_2082, 1, x_3);
lean_ctor_set(x_2082, 2, x_4);
lean_ctor_set_uint8(x_2082, sizeof(void*)*3, x_1658);
return x_2082;
}
}
else
{
lean_object* x_2083; lean_object* x_2084; lean_object* x_2085; lean_object* x_2086; lean_object* x_2087; lean_object* x_2088; lean_object* x_2089; lean_object* x_2090; lean_object* x_2091; lean_object* x_2092; 
x_2083 = lean_ctor_get(x_86, 0);
x_2084 = lean_ctor_get(x_86, 1);
x_2085 = lean_ctor_get(x_86, 2);
lean_inc(x_2085);
lean_inc(x_2084);
lean_inc(x_2083);
lean_dec(x_86);
x_2086 = lean_ctor_get(x_1179, 0);
lean_inc(x_2086);
x_2087 = lean_ctor_get(x_1179, 1);
lean_inc(x_2087);
x_2088 = lean_ctor_get(x_1179, 2);
lean_inc(x_2088);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_2089 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_2089 = lean_box(0);
}
if (lean_is_scalar(x_2089)) {
 x_2090 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2090 = x_2089;
}
lean_ctor_set(x_2090, 0, x_2083);
lean_ctor_set(x_2090, 1, x_2084);
lean_ctor_set(x_2090, 2, x_2085);
lean_ctor_set_uint8(x_2090, sizeof(void*)*3, x_1658);
x_2091 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2091, 0, x_2086);
lean_ctor_set(x_2091, 1, x_2087);
lean_ctor_set(x_2091, 2, x_2088);
lean_ctor_set_uint8(x_2091, sizeof(void*)*3, x_1658);
lean_ctor_set(x_2, 2, x_2091);
lean_ctor_set(x_2, 0, x_2090);
x_2092 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2092, 0, x_2);
lean_ctor_set(x_2092, 1, x_3);
lean_ctor_set(x_2092, 2, x_4);
lean_ctor_set_uint8(x_2092, sizeof(void*)*3, x_1658);
return x_2092;
}
}
else
{
lean_object* x_2093; lean_object* x_2094; lean_object* x_2095; lean_object* x_2096; lean_object* x_2097; lean_object* x_2098; lean_object* x_2099; lean_object* x_2100; lean_object* x_2101; lean_object* x_2102; lean_object* x_2103; lean_object* x_2104; lean_object* x_2105; 
x_2093 = lean_ctor_get(x_2, 1);
lean_inc(x_2093);
lean_dec(x_2);
x_2094 = lean_ctor_get(x_86, 0);
lean_inc(x_2094);
x_2095 = lean_ctor_get(x_86, 1);
lean_inc(x_2095);
x_2096 = lean_ctor_get(x_86, 2);
lean_inc(x_2096);
if (lean_is_exclusive(x_86)) {
 lean_ctor_release(x_86, 0);
 lean_ctor_release(x_86, 1);
 lean_ctor_release(x_86, 2);
 x_2097 = x_86;
} else {
 lean_dec_ref(x_86);
 x_2097 = lean_box(0);
}
x_2098 = lean_ctor_get(x_1179, 0);
lean_inc(x_2098);
x_2099 = lean_ctor_get(x_1179, 1);
lean_inc(x_2099);
x_2100 = lean_ctor_get(x_1179, 2);
lean_inc(x_2100);
if (lean_is_exclusive(x_1179)) {
 lean_ctor_release(x_1179, 0);
 lean_ctor_release(x_1179, 1);
 lean_ctor_release(x_1179, 2);
 x_2101 = x_1179;
} else {
 lean_dec_ref(x_1179);
 x_2101 = lean_box(0);
}
if (lean_is_scalar(x_2101)) {
 x_2102 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2102 = x_2101;
}
lean_ctor_set(x_2102, 0, x_2094);
lean_ctor_set(x_2102, 1, x_2095);
lean_ctor_set(x_2102, 2, x_2096);
lean_ctor_set_uint8(x_2102, sizeof(void*)*3, x_1658);
if (lean_is_scalar(x_2097)) {
 x_2103 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2103 = x_2097;
}
lean_ctor_set(x_2103, 0, x_2098);
lean_ctor_set(x_2103, 1, x_2099);
lean_ctor_set(x_2103, 2, x_2100);
lean_ctor_set_uint8(x_2103, sizeof(void*)*3, x_1658);
x_2104 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2104, 0, x_2102);
lean_ctor_set(x_2104, 1, x_2093);
lean_ctor_set(x_2104, 2, x_2103);
lean_ctor_set_uint8(x_2104, sizeof(void*)*3, x_85);
x_2105 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2105, 0, x_2104);
lean_ctor_set(x_2105, 1, x_3);
lean_ctor_set(x_2105, 2, x_4);
lean_ctor_set_uint8(x_2105, sizeof(void*)*3, x_1658);
return x_2105;
}
}
}
}
}
}
}
}
else
{
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_2106; 
x_2106 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2106, 0, x_2);
lean_ctor_set(x_2106, 1, x_3);
lean_ctor_set(x_2106, 2, x_4);
lean_ctor_set_uint8(x_2106, sizeof(void*)*3, x_85);
return x_2106;
}
else
{
uint8_t x_2107; 
x_2107 = lean_ctor_get_uint8(x_4, sizeof(void*)*3);
if (x_2107 == 0)
{
lean_object* x_2108; 
x_2108 = lean_ctor_get(x_4, 0);
lean_inc(x_2108);
if (lean_obj_tag(x_2108) == 0)
{
lean_object* x_2109; 
x_2109 = lean_ctor_get(x_4, 2);
lean_inc(x_2109);
if (lean_obj_tag(x_2109) == 0)
{
uint8_t x_2110; 
x_2110 = !lean_is_exclusive(x_4);
if (x_2110 == 0)
{
lean_object* x_2111; lean_object* x_2112; lean_object* x_2113; 
x_2111 = lean_ctor_get(x_4, 2);
lean_dec(x_2111);
x_2112 = lean_ctor_get(x_4, 0);
lean_dec(x_2112);
lean_ctor_set(x_4, 0, x_2109);
x_2113 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2113, 0, x_2);
lean_ctor_set(x_2113, 1, x_3);
lean_ctor_set(x_2113, 2, x_4);
lean_ctor_set_uint8(x_2113, sizeof(void*)*3, x_85);
return x_2113;
}
else
{
lean_object* x_2114; lean_object* x_2115; lean_object* x_2116; 
x_2114 = lean_ctor_get(x_4, 1);
lean_inc(x_2114);
lean_dec(x_4);
x_2115 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2115, 0, x_2109);
lean_ctor_set(x_2115, 1, x_2114);
lean_ctor_set(x_2115, 2, x_2109);
lean_ctor_set_uint8(x_2115, sizeof(void*)*3, x_2107);
x_2116 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2116, 0, x_2);
lean_ctor_set(x_2116, 1, x_3);
lean_ctor_set(x_2116, 2, x_2115);
lean_ctor_set_uint8(x_2116, sizeof(void*)*3, x_85);
return x_2116;
}
}
else
{
uint8_t x_2117; 
x_2117 = lean_ctor_get_uint8(x_2109, sizeof(void*)*3);
if (x_2117 == 0)
{
lean_object* x_2118; lean_object* x_2119; lean_object* x_2120; lean_object* x_2121; 
x_2118 = lean_ctor_get(x_4, 1);
lean_inc(x_2118);
lean_dec_ref(x_4);
x_2119 = lean_ctor_get(x_2109, 0);
lean_inc(x_2119);
x_2120 = lean_ctor_get(x_2109, 1);
lean_inc(x_2120);
x_2121 = lean_ctor_get(x_2109, 2);
lean_inc(x_2121);
lean_dec_ref(x_2109);
x_5 = x_2;
x_6 = x_3;
x_7 = x_2108;
x_8 = x_2118;
x_9 = x_2119;
x_10 = x_2120;
x_11 = x_2121;
goto block_16;
}
else
{
uint8_t x_2122; 
x_2122 = !lean_is_exclusive(x_2109);
if (x_2122 == 0)
{
lean_object* x_2123; lean_object* x_2124; lean_object* x_2125; uint8_t x_2126; 
x_2123 = lean_ctor_get(x_2109, 2);
lean_dec(x_2123);
x_2124 = lean_ctor_get(x_2109, 1);
lean_dec(x_2124);
x_2125 = lean_ctor_get(x_2109, 0);
lean_dec(x_2125);
x_2126 = !lean_is_exclusive(x_2);
if (x_2126 == 0)
{
lean_object* x_2127; lean_object* x_2128; lean_object* x_2129; 
x_2127 = lean_ctor_get(x_2, 0);
x_2128 = lean_ctor_get(x_2, 1);
x_2129 = lean_ctor_get(x_2, 2);
lean_ctor_set(x_2109, 2, x_2129);
lean_ctor_set(x_2109, 1, x_2128);
lean_ctor_set(x_2109, 0, x_2127);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_2109);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2117);
return x_2;
}
else
{
lean_object* x_2130; lean_object* x_2131; lean_object* x_2132; lean_object* x_2133; 
x_2130 = lean_ctor_get(x_2, 0);
x_2131 = lean_ctor_get(x_2, 1);
x_2132 = lean_ctor_get(x_2, 2);
lean_inc(x_2132);
lean_inc(x_2131);
lean_inc(x_2130);
lean_dec(x_2);
lean_ctor_set(x_2109, 2, x_2132);
lean_ctor_set(x_2109, 1, x_2131);
lean_ctor_set(x_2109, 0, x_2130);
x_2133 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2133, 0, x_2109);
lean_ctor_set(x_2133, 1, x_3);
lean_ctor_set(x_2133, 2, x_4);
lean_ctor_set_uint8(x_2133, sizeof(void*)*3, x_2117);
return x_2133;
}
}
else
{
lean_object* x_2134; lean_object* x_2135; lean_object* x_2136; lean_object* x_2137; lean_object* x_2138; lean_object* x_2139; 
lean_dec(x_2109);
x_2134 = lean_ctor_get(x_2, 0);
lean_inc(x_2134);
x_2135 = lean_ctor_get(x_2, 1);
lean_inc(x_2135);
x_2136 = lean_ctor_get(x_2, 2);
lean_inc(x_2136);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_2137 = x_2;
} else {
 lean_dec_ref(x_2);
 x_2137 = lean_box(0);
}
x_2138 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2138, 0, x_2134);
lean_ctor_set(x_2138, 1, x_2135);
lean_ctor_set(x_2138, 2, x_2136);
lean_ctor_set_uint8(x_2138, sizeof(void*)*3, x_2117);
if (lean_is_scalar(x_2137)) {
 x_2139 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2139 = x_2137;
}
lean_ctor_set(x_2139, 0, x_2138);
lean_ctor_set(x_2139, 1, x_3);
lean_ctor_set(x_2139, 2, x_4);
lean_ctor_set_uint8(x_2139, sizeof(void*)*3, x_2117);
return x_2139;
}
}
}
}
else
{
uint8_t x_2140; 
x_2140 = lean_ctor_get_uint8(x_2108, sizeof(void*)*3);
if (x_2140 == 0)
{
lean_object* x_2141; 
x_2141 = lean_ctor_get(x_4, 2);
lean_inc(x_2141);
if (lean_obj_tag(x_2141) == 0)
{
lean_object* x_2142; lean_object* x_2143; lean_object* x_2144; lean_object* x_2145; 
x_2142 = lean_ctor_get(x_4, 1);
lean_inc(x_2142);
lean_dec_ref(x_4);
x_2143 = lean_ctor_get(x_2108, 0);
lean_inc(x_2143);
x_2144 = lean_ctor_get(x_2108, 1);
lean_inc(x_2144);
x_2145 = lean_ctor_get(x_2108, 2);
lean_inc(x_2145);
lean_dec_ref(x_2108);
x_5 = x_2;
x_6 = x_3;
x_7 = x_2143;
x_8 = x_2144;
x_9 = x_2145;
x_10 = x_2142;
x_11 = x_2141;
goto block_16;
}
else
{
uint8_t x_2146; 
x_2146 = lean_ctor_get_uint8(x_2141, sizeof(void*)*3);
if (x_2146 == 0)
{
lean_object* x_2147; lean_object* x_2148; lean_object* x_2149; lean_object* x_2150; 
x_2147 = lean_ctor_get(x_4, 1);
lean_inc(x_2147);
lean_dec_ref(x_4);
x_2148 = lean_ctor_get(x_2108, 0);
lean_inc(x_2148);
x_2149 = lean_ctor_get(x_2108, 1);
lean_inc(x_2149);
x_2150 = lean_ctor_get(x_2108, 2);
lean_inc(x_2150);
lean_dec_ref(x_2108);
x_5 = x_2;
x_6 = x_3;
x_7 = x_2148;
x_8 = x_2149;
x_9 = x_2150;
x_10 = x_2147;
x_11 = x_2141;
goto block_16;
}
else
{
lean_object* x_2151; lean_object* x_2152; lean_object* x_2153; lean_object* x_2154; uint8_t x_2155; 
x_2151 = lean_ctor_get(x_2, 0);
lean_inc(x_2151);
x_2152 = lean_ctor_get(x_2, 1);
lean_inc(x_2152);
x_2153 = lean_ctor_get(x_2, 2);
lean_inc(x_2153);
lean_dec_ref(x_2);
x_2154 = lean_ctor_get(x_4, 1);
lean_inc(x_2154);
lean_dec_ref(x_4);
x_2155 = !lean_is_exclusive(x_2108);
if (x_2155 == 0)
{
lean_object* x_2156; lean_object* x_2157; lean_object* x_2158; 
x_2156 = lean_ctor_get(x_2108, 0);
x_2157 = lean_ctor_get(x_2108, 1);
x_2158 = lean_ctor_get(x_2108, 2);
lean_ctor_set(x_2108, 2, x_2153);
lean_ctor_set(x_2108, 1, x_2152);
lean_ctor_set(x_2108, 0, x_2151);
lean_ctor_set_uint8(x_2108, sizeof(void*)*3, x_2146);
x_5 = x_2108;
x_6 = x_3;
x_7 = x_2156;
x_8 = x_2157;
x_9 = x_2158;
x_10 = x_2154;
x_11 = x_2141;
goto block_16;
}
else
{
lean_object* x_2159; lean_object* x_2160; lean_object* x_2161; lean_object* x_2162; 
x_2159 = lean_ctor_get(x_2108, 0);
x_2160 = lean_ctor_get(x_2108, 1);
x_2161 = lean_ctor_get(x_2108, 2);
lean_inc(x_2161);
lean_inc(x_2160);
lean_inc(x_2159);
lean_dec(x_2108);
x_2162 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2162, 0, x_2151);
lean_ctor_set(x_2162, 1, x_2152);
lean_ctor_set(x_2162, 2, x_2153);
lean_ctor_set_uint8(x_2162, sizeof(void*)*3, x_2146);
x_5 = x_2162;
x_6 = x_3;
x_7 = x_2159;
x_8 = x_2160;
x_9 = x_2161;
x_10 = x_2154;
x_11 = x_2141;
goto block_16;
}
}
}
}
else
{
lean_object* x_2163; 
x_2163 = lean_ctor_get(x_4, 2);
lean_inc(x_2163);
if (lean_obj_tag(x_2163) == 0)
{
uint8_t x_2164; 
x_2164 = !lean_is_exclusive(x_2108);
if (x_2164 == 0)
{
lean_object* x_2165; lean_object* x_2166; lean_object* x_2167; uint8_t x_2168; 
x_2165 = lean_ctor_get(x_2108, 2);
lean_dec(x_2165);
x_2166 = lean_ctor_get(x_2108, 1);
lean_dec(x_2166);
x_2167 = lean_ctor_get(x_2108, 0);
lean_dec(x_2167);
x_2168 = !lean_is_exclusive(x_2);
if (x_2168 == 0)
{
lean_object* x_2169; lean_object* x_2170; lean_object* x_2171; 
x_2169 = lean_ctor_get(x_2, 0);
x_2170 = lean_ctor_get(x_2, 1);
x_2171 = lean_ctor_get(x_2, 2);
lean_ctor_set(x_2108, 2, x_2171);
lean_ctor_set(x_2108, 1, x_2170);
lean_ctor_set(x_2108, 0, x_2169);
lean_ctor_set(x_2, 2, x_4);
lean_ctor_set(x_2, 1, x_3);
lean_ctor_set(x_2, 0, x_2108);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2140);
return x_2;
}
else
{
lean_object* x_2172; lean_object* x_2173; lean_object* x_2174; lean_object* x_2175; 
x_2172 = lean_ctor_get(x_2, 0);
x_2173 = lean_ctor_get(x_2, 1);
x_2174 = lean_ctor_get(x_2, 2);
lean_inc(x_2174);
lean_inc(x_2173);
lean_inc(x_2172);
lean_dec(x_2);
lean_ctor_set(x_2108, 2, x_2174);
lean_ctor_set(x_2108, 1, x_2173);
lean_ctor_set(x_2108, 0, x_2172);
x_2175 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2175, 0, x_2108);
lean_ctor_set(x_2175, 1, x_3);
lean_ctor_set(x_2175, 2, x_4);
lean_ctor_set_uint8(x_2175, sizeof(void*)*3, x_2140);
return x_2175;
}
}
else
{
lean_object* x_2176; lean_object* x_2177; lean_object* x_2178; lean_object* x_2179; lean_object* x_2180; lean_object* x_2181; 
lean_dec(x_2108);
x_2176 = lean_ctor_get(x_2, 0);
lean_inc(x_2176);
x_2177 = lean_ctor_get(x_2, 1);
lean_inc(x_2177);
x_2178 = lean_ctor_get(x_2, 2);
lean_inc(x_2178);
if (lean_is_exclusive(x_2)) {
 lean_ctor_release(x_2, 0);
 lean_ctor_release(x_2, 1);
 lean_ctor_release(x_2, 2);
 x_2179 = x_2;
} else {
 lean_dec_ref(x_2);
 x_2179 = lean_box(0);
}
x_2180 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2180, 0, x_2176);
lean_ctor_set(x_2180, 1, x_2177);
lean_ctor_set(x_2180, 2, x_2178);
lean_ctor_set_uint8(x_2180, sizeof(void*)*3, x_2140);
if (lean_is_scalar(x_2179)) {
 x_2181 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2181 = x_2179;
}
lean_ctor_set(x_2181, 0, x_2180);
lean_ctor_set(x_2181, 1, x_3);
lean_ctor_set(x_2181, 2, x_4);
lean_ctor_set_uint8(x_2181, sizeof(void*)*3, x_2140);
return x_2181;
}
}
else
{
uint8_t x_2182; 
x_2182 = lean_ctor_get_uint8(x_2163, sizeof(void*)*3);
if (x_2182 == 0)
{
lean_object* x_2183; lean_object* x_2184; lean_object* x_2185; lean_object* x_2186; uint8_t x_2187; 
x_2183 = lean_ctor_get(x_2, 0);
lean_inc(x_2183);
x_2184 = lean_ctor_get(x_2, 1);
lean_inc(x_2184);
x_2185 = lean_ctor_get(x_2, 2);
lean_inc(x_2185);
lean_dec_ref(x_2);
x_2186 = lean_ctor_get(x_4, 1);
lean_inc(x_2186);
lean_dec_ref(x_4);
x_2187 = !lean_is_exclusive(x_2163);
if (x_2187 == 0)
{
lean_object* x_2188; lean_object* x_2189; lean_object* x_2190; 
x_2188 = lean_ctor_get(x_2163, 0);
x_2189 = lean_ctor_get(x_2163, 1);
x_2190 = lean_ctor_get(x_2163, 2);
lean_ctor_set(x_2163, 2, x_2185);
lean_ctor_set(x_2163, 1, x_2184);
lean_ctor_set(x_2163, 0, x_2183);
lean_ctor_set_uint8(x_2163, sizeof(void*)*3, x_2140);
x_5 = x_2163;
x_6 = x_3;
x_7 = x_2108;
x_8 = x_2186;
x_9 = x_2188;
x_10 = x_2189;
x_11 = x_2190;
goto block_16;
}
else
{
lean_object* x_2191; lean_object* x_2192; lean_object* x_2193; lean_object* x_2194; 
x_2191 = lean_ctor_get(x_2163, 0);
x_2192 = lean_ctor_get(x_2163, 1);
x_2193 = lean_ctor_get(x_2163, 2);
lean_inc(x_2193);
lean_inc(x_2192);
lean_inc(x_2191);
lean_dec(x_2163);
x_2194 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2194, 0, x_2183);
lean_ctor_set(x_2194, 1, x_2184);
lean_ctor_set(x_2194, 2, x_2185);
lean_ctor_set_uint8(x_2194, sizeof(void*)*3, x_2140);
x_5 = x_2194;
x_6 = x_3;
x_7 = x_2108;
x_8 = x_2186;
x_9 = x_2191;
x_10 = x_2192;
x_11 = x_2193;
goto block_16;
}
}
else
{
uint8_t x_2195; 
x_2195 = !lean_is_exclusive(x_2);
if (x_2195 == 0)
{
uint8_t x_2196; 
x_2196 = !lean_is_exclusive(x_4);
if (x_2196 == 0)
{
lean_object* x_2197; lean_object* x_2198; lean_object* x_2199; lean_object* x_2200; lean_object* x_2201; lean_object* x_2202; uint8_t x_2203; 
x_2197 = lean_ctor_get(x_2, 0);
x_2198 = lean_ctor_get(x_2, 1);
x_2199 = lean_ctor_get(x_2, 2);
x_2200 = lean_ctor_get(x_4, 1);
x_2201 = lean_ctor_get(x_4, 2);
lean_dec(x_2201);
x_2202 = lean_ctor_get(x_4, 0);
lean_dec(x_2202);
x_2203 = !lean_is_exclusive(x_2108);
if (x_2203 == 0)
{
lean_object* x_2204; lean_object* x_2205; lean_object* x_2206; lean_object* x_2207; 
x_2204 = lean_ctor_get(x_2108, 0);
x_2205 = lean_ctor_get(x_2108, 1);
x_2206 = lean_ctor_get(x_2108, 2);
lean_ctor_set(x_2108, 2, x_2199);
lean_ctor_set(x_2108, 1, x_2198);
lean_ctor_set(x_2108, 0, x_2197);
lean_ctor_set_uint8(x_2108, sizeof(void*)*3, x_2182);
lean_ctor_set(x_4, 2, x_2206);
lean_ctor_set(x_4, 1, x_2205);
lean_ctor_set(x_4, 0, x_2204);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_2182);
lean_ctor_set(x_2, 2, x_2163);
lean_ctor_set(x_2, 1, x_2200);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2107);
x_2207 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2207, 0, x_2108);
lean_ctor_set(x_2207, 1, x_3);
lean_ctor_set(x_2207, 2, x_2);
lean_ctor_set_uint8(x_2207, sizeof(void*)*3, x_2182);
return x_2207;
}
else
{
lean_object* x_2208; lean_object* x_2209; lean_object* x_2210; lean_object* x_2211; lean_object* x_2212; 
x_2208 = lean_ctor_get(x_2108, 0);
x_2209 = lean_ctor_get(x_2108, 1);
x_2210 = lean_ctor_get(x_2108, 2);
lean_inc(x_2210);
lean_inc(x_2209);
lean_inc(x_2208);
lean_dec(x_2108);
x_2211 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2211, 0, x_2197);
lean_ctor_set(x_2211, 1, x_2198);
lean_ctor_set(x_2211, 2, x_2199);
lean_ctor_set_uint8(x_2211, sizeof(void*)*3, x_2182);
lean_ctor_set(x_4, 2, x_2210);
lean_ctor_set(x_4, 1, x_2209);
lean_ctor_set(x_4, 0, x_2208);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_2182);
lean_ctor_set(x_2, 2, x_2163);
lean_ctor_set(x_2, 1, x_2200);
lean_ctor_set(x_2, 0, x_4);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2107);
x_2212 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2212, 0, x_2211);
lean_ctor_set(x_2212, 1, x_3);
lean_ctor_set(x_2212, 2, x_2);
lean_ctor_set_uint8(x_2212, sizeof(void*)*3, x_2182);
return x_2212;
}
}
else
{
lean_object* x_2213; lean_object* x_2214; lean_object* x_2215; lean_object* x_2216; lean_object* x_2217; lean_object* x_2218; lean_object* x_2219; lean_object* x_2220; lean_object* x_2221; lean_object* x_2222; lean_object* x_2223; 
x_2213 = lean_ctor_get(x_2, 0);
x_2214 = lean_ctor_get(x_2, 1);
x_2215 = lean_ctor_get(x_2, 2);
x_2216 = lean_ctor_get(x_4, 1);
lean_inc(x_2216);
lean_dec(x_4);
x_2217 = lean_ctor_get(x_2108, 0);
lean_inc(x_2217);
x_2218 = lean_ctor_get(x_2108, 1);
lean_inc(x_2218);
x_2219 = lean_ctor_get(x_2108, 2);
lean_inc(x_2219);
if (lean_is_exclusive(x_2108)) {
 lean_ctor_release(x_2108, 0);
 lean_ctor_release(x_2108, 1);
 lean_ctor_release(x_2108, 2);
 x_2220 = x_2108;
} else {
 lean_dec_ref(x_2108);
 x_2220 = lean_box(0);
}
if (lean_is_scalar(x_2220)) {
 x_2221 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2221 = x_2220;
}
lean_ctor_set(x_2221, 0, x_2213);
lean_ctor_set(x_2221, 1, x_2214);
lean_ctor_set(x_2221, 2, x_2215);
lean_ctor_set_uint8(x_2221, sizeof(void*)*3, x_2182);
x_2222 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2222, 0, x_2217);
lean_ctor_set(x_2222, 1, x_2218);
lean_ctor_set(x_2222, 2, x_2219);
lean_ctor_set_uint8(x_2222, sizeof(void*)*3, x_2182);
lean_ctor_set(x_2, 2, x_2163);
lean_ctor_set(x_2, 1, x_2216);
lean_ctor_set(x_2, 0, x_2222);
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2107);
x_2223 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2223, 0, x_2221);
lean_ctor_set(x_2223, 1, x_3);
lean_ctor_set(x_2223, 2, x_2);
lean_ctor_set_uint8(x_2223, sizeof(void*)*3, x_2182);
return x_2223;
}
}
else
{
lean_object* x_2224; lean_object* x_2225; lean_object* x_2226; lean_object* x_2227; lean_object* x_2228; lean_object* x_2229; lean_object* x_2230; lean_object* x_2231; lean_object* x_2232; lean_object* x_2233; lean_object* x_2234; lean_object* x_2235; lean_object* x_2236; 
x_2224 = lean_ctor_get(x_2, 0);
x_2225 = lean_ctor_get(x_2, 1);
x_2226 = lean_ctor_get(x_2, 2);
lean_inc(x_2226);
lean_inc(x_2225);
lean_inc(x_2224);
lean_dec(x_2);
x_2227 = lean_ctor_get(x_4, 1);
lean_inc(x_2227);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 x_2228 = x_4;
} else {
 lean_dec_ref(x_4);
 x_2228 = lean_box(0);
}
x_2229 = lean_ctor_get(x_2108, 0);
lean_inc(x_2229);
x_2230 = lean_ctor_get(x_2108, 1);
lean_inc(x_2230);
x_2231 = lean_ctor_get(x_2108, 2);
lean_inc(x_2231);
if (lean_is_exclusive(x_2108)) {
 lean_ctor_release(x_2108, 0);
 lean_ctor_release(x_2108, 1);
 lean_ctor_release(x_2108, 2);
 x_2232 = x_2108;
} else {
 lean_dec_ref(x_2108);
 x_2232 = lean_box(0);
}
if (lean_is_scalar(x_2232)) {
 x_2233 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2233 = x_2232;
}
lean_ctor_set(x_2233, 0, x_2224);
lean_ctor_set(x_2233, 1, x_2225);
lean_ctor_set(x_2233, 2, x_2226);
lean_ctor_set_uint8(x_2233, sizeof(void*)*3, x_2182);
if (lean_is_scalar(x_2228)) {
 x_2234 = lean_alloc_ctor(1, 3, 1);
} else {
 x_2234 = x_2228;
}
lean_ctor_set(x_2234, 0, x_2229);
lean_ctor_set(x_2234, 1, x_2230);
lean_ctor_set(x_2234, 2, x_2231);
lean_ctor_set_uint8(x_2234, sizeof(void*)*3, x_2182);
x_2235 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2235, 0, x_2234);
lean_ctor_set(x_2235, 1, x_2227);
lean_ctor_set(x_2235, 2, x_2163);
lean_ctor_set_uint8(x_2235, sizeof(void*)*3, x_2107);
x_2236 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2236, 0, x_2233);
lean_ctor_set(x_2236, 1, x_3);
lean_ctor_set(x_2236, 2, x_2235);
lean_ctor_set_uint8(x_2236, sizeof(void*)*3, x_2182);
return x_2236;
}
}
}
}
}
}
else
{
uint8_t x_2237; 
x_2237 = !lean_is_exclusive(x_2);
if (x_2237 == 0)
{
lean_object* x_2238; 
lean_ctor_set_uint8(x_2, sizeof(void*)*3, x_2107);
x_2238 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2238, 0, x_2);
lean_ctor_set(x_2238, 1, x_3);
lean_ctor_set(x_2238, 2, x_4);
lean_ctor_set_uint8(x_2238, sizeof(void*)*3, x_2107);
return x_2238;
}
else
{
lean_object* x_2239; lean_object* x_2240; lean_object* x_2241; lean_object* x_2242; lean_object* x_2243; 
x_2239 = lean_ctor_get(x_2, 0);
x_2240 = lean_ctor_get(x_2, 1);
x_2241 = lean_ctor_get(x_2, 2);
lean_inc(x_2241);
lean_inc(x_2240);
lean_inc(x_2239);
lean_dec(x_2);
x_2242 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2242, 0, x_2239);
lean_ctor_set(x_2242, 1, x_2240);
lean_ctor_set(x_2242, 2, x_2241);
lean_ctor_set_uint8(x_2242, sizeof(void*)*3, x_2107);
x_2243 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_2243, 0, x_2242);
lean_ctor_set(x_2243, 1, x_3);
lean_ctor_set(x_2243, 2, x_4);
lean_ctor_set_uint8(x_2243, sizeof(void*)*3, x_2107);
return x_2243;
}
}
}
}
}
}
block_16:
{
uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_12 = 0;
x_13 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_13, 0, x_5);
lean_ctor_set(x_13, 1, x_6);
lean_ctor_set(x_13, 2, x_7);
lean_ctor_set_uint8(x_13, sizeof(void*)*3, x_1);
x_14 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_14, 0, x_9);
lean_ctor_set(x_14, 1, x_10);
lean_ctor_set(x_14, 2, x_11);
lean_ctor_set_uint8(x_14, sizeof(void*)*3, x_1);
x_15 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_15, 0, x_13);
lean_ctor_set(x_15, 1, x_8);
lean_ctor_set(x_15, 2, x_14);
lean_ctor_set_uint8(x_15, sizeof(void*)*3, x_12);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_RBTree_balance(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RBTree_balance___redArg(x_2, x_3, x_4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTree_balance___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_1);
x_6 = l_RBTree_balance___redArg(x_5, x_2, x_3, x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTree_balance___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; lean_object* x_7; 
x_6 = lean_unbox(x_2);
x_7 = l_RBTree_balance(x_1, x_6, x_3, x_4, x_5);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBTree_insert_ins___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; lean_object* x_5; 
lean_dec_ref(x_1);
x_4 = 0;
x_5 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_2);
lean_ctor_set(x_5, 2, x_3);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_4);
return x_5;
}
else
{
uint8_t x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_6 = lean_ctor_get_uint8(x_3, sizeof(void*)*3);
x_7 = lean_ctor_get(x_3, 0);
x_8 = lean_ctor_get(x_3, 1);
x_9 = lean_ctor_get(x_3, 2);
lean_inc_ref(x_1);
lean_inc(x_8);
lean_inc(x_2);
x_10 = lean_apply_2(x_1, x_2, x_8);
x_11 = lean_unbox(x_10);
switch (x_11) {
case 0:
{
lean_object* x_12; lean_object* x_13; 
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_dec_ref(x_3);
x_12 = l_RBTree_insert_ins___redArg(x_1, x_2, x_7);
x_13 = l_RBTree_balance___redArg(x_6, x_12, x_8, x_9);
return x_13;
}
case 1:
{
lean_dec(x_2);
lean_dec_ref(x_1);
return x_3;
}
default: 
{
lean_object* x_14; lean_object* x_15; 
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_dec_ref(x_3);
x_14 = l_RBTree_insert_ins___redArg(x_1, x_2, x_9);
x_15 = l_RBTree_balance___redArg(x_6, x_7, x_8, x_14);
return x_15;
}
}
}
}
}
LEAN_EXPORT lean_object* l_RBTree_insert_ins(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTree_insert_ins___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTree_insert_makeBlack___redArg(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
return x_1;
}
else
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
uint8_t x_3; 
x_3 = 1;
lean_ctor_set_uint8(x_1, sizeof(void*)*3, x_3);
return x_1;
}
else
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; lean_object* x_8; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_1, 2);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_dec(x_1);
x_7 = 1;
x_8 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_8, 0, x_4);
lean_ctor_set(x_8, 1, x_5);
lean_ctor_set(x_8, 2, x_6);
lean_ctor_set_uint8(x_8, sizeof(void*)*3, x_7);
return x_8;
}
}
}
}
LEAN_EXPORT lean_object* l_RBTree_insert_makeBlack(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTree_insert_makeBlack___redArg(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTree_insert___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = l_RBTree_insert_ins___redArg(x_1, x_2, x_3);
x_5 = l_RBTree_insert_makeBlack___redArg(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTree_insert(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTree_insert___redArg(x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_empty_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RBTree", 6, 6);
return x_1;
}
}
static lean_object* _init_l_empty_x3f___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("empty", 5, 5);
return x_1;
}
}
static lean_object* _init_l_empty_x3f___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_empty_x3f___closed__1;
x_2 = l_empty_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT uint8_t l_empty_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_empty_x3f___closed__2;
x_3 = lean_unsigned_to_nat(1u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_empty_x3f___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_empty_x3f(x_1);
lean_dec_ref(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Expr_app5_x3f(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_unsigned_to_nat(5u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appFn_x21(x_6);
x_8 = l_Lean_Expr_appFn_x21(x_7);
x_9 = l_Lean_Expr_appFn_x21(x_8);
x_10 = l_Lean_Expr_appArg_x21(x_9);
lean_dec_ref(x_9);
x_11 = l_Lean_Expr_appArg_x21(x_8);
lean_dec_ref(x_8);
x_12 = l_Lean_Expr_appArg_x21(x_7);
lean_dec_ref(x_7);
x_13 = l_Lean_Expr_appArg_x21(x_6);
lean_dec_ref(x_6);
x_14 = l_Lean_Expr_appArg_x21(x_1);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_13);
lean_ctor_set(x_15, 1, x_14);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_12);
lean_ctor_set(x_16, 1, x_15);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_11);
lean_ctor_set(x_17, 1, x_16);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_10);
lean_ctor_set(x_18, 1, x_17);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
return x_19;
}
}
}
LEAN_EXPORT lean_object* l_Lean_Expr_app5_x3f___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Lean_Expr_app5_x3f(x_1, x_2);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_3;
}
}
static lean_object* _init_l_node_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("node", 4, 4);
return x_1;
}
}
static lean_object* _init_l_node_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_node_x3f___closed__0;
x_2 = l_empty_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_node_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_node_x3f___closed__1;
x_3 = lean_unsigned_to_nat(5u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appFn_x21(x_6);
x_8 = l_Lean_Expr_appFn_x21(x_7);
x_9 = l_Lean_Expr_appArg_x21(x_8);
lean_dec_ref(x_8);
x_10 = l_Lean_Expr_appArg_x21(x_7);
lean_dec_ref(x_7);
x_11 = l_Lean_Expr_appArg_x21(x_6);
lean_dec_ref(x_6);
x_12 = l_Lean_Expr_appArg_x21(x_1);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_10);
lean_ctor_set(x_14, 1, x_13);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_9);
lean_ctor_set(x_15, 1, x_14);
x_16 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_16, 0, x_15);
return x_16;
}
}
}
LEAN_EXPORT lean_object* l_node_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_node_x3f(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_evalColourUnsafe___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RBColour", 8, 8);
return x_1;
}
}
static lean_object* _init_l_evalColourUnsafe___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_evalColourUnsafe___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_evalColourUnsafe(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; uint8_t x_8; lean_object* x_9; 
x_7 = l_evalColourUnsafe___closed__1;
x_8 = 1;
x_9 = l_Lean_Meta_evalExpr_x27___redArg(x_7, x_1, x_8, x_2, x_3, x_4, x_5, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorIdx(uint8_t x_1) {
_start:
{
switch (x_1) {
case 0:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
case 1:
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
default: 
{
lean_object* x_4; 
x_4 = lean_unsigned_to_nat(2u);
return x_4;
}
}
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorIdx___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_RBTreeVarsColour_ctorIdx(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_toCtorIdx(uint8_t x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVarsColour_ctorIdx(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_toCtorIdx___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_RBTreeVarsColour_toCtorIdx(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_inc(x_5);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVarsColour_ctorElim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; lean_object* x_7; 
x_6 = lean_unbox(x_3);
x_7 = l_RBTreeVarsColour_ctorElim(x_1, x_2, x_6, x_4, x_5);
lean_dec(x_5);
lean_dec(x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_inc(x_4);
return x_4;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVarsColour_red_elim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_red_elim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_2);
x_6 = l_RBTreeVarsColour_red_elim(x_1, x_5, x_3, x_4);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_inc(x_4);
return x_4;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVarsColour_black_elim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_black_elim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_2);
x_6 = l_RBTreeVarsColour_black_elim(x_1, x_5, x_3, x_4);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___redArg(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_inc(x_4);
return x_4;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVarsColour_blue_elim___redArg(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_blue_elim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; lean_object* x_6; 
x_5 = lean_unbox(x_2);
x_6 = l_RBTreeVarsColour_blue_elim(x_1, x_5, x_3, x_4);
lean_dec(x_4);
return x_6;
}
}
static lean_object* _init_l_RBTreeVarsColour_noConfusion___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_RBColour_noConfusion___redArg___lam__0___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___redArg(uint8_t x_1, uint8_t x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTreeVarsColour_noConfusion___redArg___closed__0;
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion(lean_object* x_1, uint8_t x_2, uint8_t x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTreeVarsColour_noConfusion___redArg(x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; uint8_t x_4; lean_object* x_5; 
x_3 = lean_unbox(x_1);
x_4 = lean_unbox(x_2);
x_5 = l_RBTreeVarsColour_noConfusion___redArg(x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTreeVarsColour_noConfusion___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; uint8_t x_6; lean_object* x_7; 
x_5 = lean_unbox(x_2);
x_6 = lean_unbox(x_3);
x_7 = l_RBTreeVarsColour_noConfusion(x_1, x_5, x_6, x_4);
return x_7;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no inductive constructor matched", 32, 32);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1;
return x_2;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("black", 5, 5);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = lean_box(x_1);
x_3 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_3, 0, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; 
x_6 = l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0;
x_7 = l_Lean_Json_parseTagged(x_1, x_6, x_2, x_3);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; 
x_9 = l_Except_orElseLazy___redArg(x_7, x_4);
lean_dec_ref(x_7);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
x_12 = l_Except_orElseLazy___redArg(x_11, x_4);
lean_dec_ref(x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; 
lean_dec_ref(x_7);
x_13 = l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1;
x_14 = l_Except_orElseLazy___redArg(x_13, x_4);
return x_14;
}
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("red", 3, 3);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 0;
x_2 = lean_box(x_1);
x_3 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_3, 0, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; 
x_6 = l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0;
x_7 = l_Lean_Json_parseTagged(x_1, x_6, x_2, x_3);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; 
x_9 = l_Except_orElseLazy___redArg(x_7, x_4);
lean_dec_ref(x_7);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
x_12 = l_Except_orElseLazy___redArg(x_11, x_4);
lean_dec_ref(x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; 
lean_dec_ref(x_7);
x_13 = l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1;
x_14 = l_Except_orElseLazy___redArg(x_13, x_4);
return x_14;
}
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("blue", 4, 4);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___closed__1;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__3() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 2;
x_2 = lean_box(x_1);
x_3 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_3, 0, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l_instFromJsonRBTreeVarsColour_fromJson___lam__0), 1, 0);
x_3 = l_instFromJsonRBTreeVarsColour_fromJson___closed__0;
x_4 = lean_unsigned_to_nat(0u);
x_5 = l_instFromJsonRBTreeVarsColour_fromJson___closed__2;
lean_inc(x_1);
x_6 = lean_alloc_closure((void*)(l_instFromJsonRBTreeVarsColour_fromJson___lam__1___boxed), 5, 4);
lean_closure_set(x_6, 0, x_1);
lean_closure_set(x_6, 1, x_4);
lean_closure_set(x_6, 2, x_5);
lean_closure_set(x_6, 3, x_2);
lean_inc(x_1);
x_7 = lean_alloc_closure((void*)(l_instFromJsonRBTreeVarsColour_fromJson___lam__2___boxed), 5, 4);
lean_closure_set(x_7, 0, x_1);
lean_closure_set(x_7, 1, x_4);
lean_closure_set(x_7, 2, x_5);
lean_closure_set(x_7, 3, x_6);
x_8 = l_Lean_Json_parseTagged(x_1, x_3, x_4, x_5);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; 
x_10 = l_Except_orElseLazy___redArg(x_8, x_7);
lean_dec_ref(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_8, 0);
lean_inc(x_11);
lean_dec(x_8);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Except_orElseLazy___redArg(x_12, x_7);
lean_dec_ref(x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
lean_dec_ref(x_8);
x_14 = l_instFromJsonRBTreeVarsColour_fromJson___closed__3;
x_15 = l_Except_orElseLazy___redArg(x_14, x_7);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_instFromJsonRBTreeVarsColour_fromJson___lam__1(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRBTreeVarsColour_fromJson___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_instFromJsonRBTreeVarsColour_fromJson___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_3);
return x_6;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRBTreeVarsColour_fromJson), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRBTreeVarsColour() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRBTreeVarsColour___closed__0;
return x_1;
}
}
static lean_object* _init_l_instToJsonRBTreeVarsColour_toJson___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_instToJsonRBTreeVarsColour_toJson___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_instToJsonRBTreeVarsColour_toJson___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRBTreeVarsColour_toJson(uint8_t x_1) {
_start:
{
switch (x_1) {
case 0:
{
lean_object* x_2; 
x_2 = l_instToJsonRBTreeVarsColour_toJson___closed__0;
return x_2;
}
case 1:
{
lean_object* x_3; 
x_3 = l_instToJsonRBTreeVarsColour_toJson___closed__1;
return x_3;
}
default: 
{
lean_object* x_4; 
x_4 = l_instToJsonRBTreeVarsColour_toJson___closed__2;
return x_4;
}
}
}
}
LEAN_EXPORT lean_object* l_instToJsonRBTreeVarsColour_toJson___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_instToJsonRBTreeVarsColour_toJson(x_2);
return x_3;
}
}
static lean_object* _init_l_instToJsonRBTreeVarsColour___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRBTreeVarsColour_toJson___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRBTreeVarsColour() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRBTreeVarsColour___closed__0;
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_ctorIdx(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
case 1:
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
default: 
{
lean_object* x_4; 
x_4 = lean_unsigned_to_nat(2u);
return x_4;
}
}
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBTreeVars_ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
return x_2;
}
case 1:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_3);
lean_dec_ref(x_1);
x_4 = lean_apply_1(x_2, x_3);
return x_4;
}
default: 
{
uint8_t x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_5 = lean_ctor_get_uint8(x_1, sizeof(void*)*3);
x_6 = lean_ctor_get(x_1, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_7);
x_8 = lean_ctor_get(x_1, 2);
lean_inc(x_8);
lean_dec_ref(x_1);
x_9 = lean_box(x_5);
x_10 = lean_apply_4(x_2, x_9, x_6, x_7, x_8);
return x_10;
}
}
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RBTreeVars_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RBTreeVars_ctorElim(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_2);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_empty_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTreeVars_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_empty_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTreeVars_ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_var_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTreeVars_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_var_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTreeVars_ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_node_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RBTreeVars_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RBTreeVars_node_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RBTreeVars_ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
case 1:
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
default: 
{
lean_object* x_4; 
x_4 = lean_unsigned_to_nat(2u);
return x_4;
}
}
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
return x_2;
}
case 1:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
lean_dec_ref(x_1);
x_4 = lean_apply_1(x_2, x_3);
return x_4;
}
default: 
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_ctor_get(x_1, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_1, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 3);
lean_inc(x_8);
lean_dec_ref(x_1);
x_9 = lean_apply_4(x_2, x_5, x_6, x_7, x_8);
return x_9;
}
}
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_2);
return x_6;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_empty____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_empty____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_var____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_var____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_node____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket_node____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1__ctorElim___redArg(x_2, x_4);
return x_5;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("color", 5, 5);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("l", 1, 1);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("a", 1, 1);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("r", 1, 1);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = l_node_x3f___closed__0;
x_8 = lean_unsigned_to_nat(4u);
x_9 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_10 = l_Lean_Json_parseTagged(x_1, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_3);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; 
x_12 = l_Except_orElseLazy___redArg(x_10, x_2);
lean_dec_ref(x_10);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
x_15 = l_Except_orElseLazy___redArg(x_14, x_2);
lean_dec_ref(x_14);
return x_15;
}
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_10);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_17 = lean_ctor_get(x_10, 0);
lean_inc(x_3);
x_18 = lean_array_get(x_3, x_17, x_4);
lean_inc(x_3);
x_19 = lean_array_get(x_3, x_17, x_5);
x_20 = lean_unsigned_to_nat(2u);
lean_inc(x_3);
x_21 = lean_array_get(x_3, x_17, x_20);
x_22 = lean_unsigned_to_nat(3u);
x_23 = lean_array_get(x_3, x_17, x_22);
lean_dec(x_17);
x_24 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_24, 0, x_18);
lean_ctor_set(x_24, 1, x_19);
lean_ctor_set(x_24, 2, x_21);
lean_ctor_set(x_24, 3, x_23);
lean_ctor_set(x_10, 0, x_24);
x_25 = l_Except_orElseLazy___redArg(x_10, x_2);
lean_dec_ref(x_10);
return x_25;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_26 = lean_ctor_get(x_10, 0);
lean_inc(x_26);
lean_dec(x_10);
lean_inc(x_3);
x_27 = lean_array_get(x_3, x_26, x_4);
lean_inc(x_3);
x_28 = lean_array_get(x_3, x_26, x_5);
x_29 = lean_unsigned_to_nat(2u);
lean_inc(x_3);
x_30 = lean_array_get(x_3, x_26, x_29);
x_31 = lean_unsigned_to_nat(3u);
x_32 = lean_array_get(x_3, x_26, x_31);
lean_dec(x_26);
x_33 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_33, 0, x_27);
lean_ctor_set(x_33, 1, x_28);
lean_ctor_set(x_33, 2, x_30);
lean_ctor_set(x_33, 3, x_32);
x_34 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_34, 0, x_33);
x_35 = l_Except_orElseLazy___redArg(x_34, x_2);
lean_dec_ref(x_34);
return x_35;
}
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_7 = lean_unsigned_to_nat(1u);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_1);
x_8 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56____boxed), 6, 5);
lean_closure_set(x_8, 0, x_1);
lean_closure_set(x_8, 1, x_2);
lean_closure_set(x_8, 2, x_3);
lean_closure_set(x_8, 3, x_4);
lean_closure_set(x_8, 4, x_7);
x_9 = lean_box(0);
x_10 = l_Lean_Json_parseTagged(x_1, x_6, x_7, x_9);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_4);
lean_dec(x_3);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; 
x_12 = l_Except_orElseLazy___redArg(x_10, x_8);
lean_dec_ref(x_10);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
x_15 = l_Except_orElseLazy___redArg(x_14, x_8);
lean_dec_ref(x_14);
return x_15;
}
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_10);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_17 = lean_ctor_get(x_10, 0);
x_18 = lean_array_get(x_3, x_17, x_4);
lean_dec(x_4);
lean_dec(x_17);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_10, 0, x_19);
x_20 = l_Except_orElseLazy___redArg(x_10, x_8);
lean_dec_ref(x_10);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_21 = lean_ctor_get(x_10, 0);
lean_inc(x_21);
lean_dec(x_10);
x_22 = lean_array_get(x_3, x_21, x_4);
lean_dec(x_4);
lean_dec(x_21);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_24, 0, x_23);
x_25 = l_Except_orElseLazy___redArg(x_24, x_8);
lean_dec_ref(x_24);
return x_25;
}
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_), 1, 0);
x_3 = lean_box(0);
x_4 = l_empty_x3f___closed__1;
x_5 = lean_unsigned_to_nat(0u);
lean_inc(x_1);
x_6 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson___lam__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_), 5, 4);
lean_closure_set(x_6, 0, x_1);
lean_closure_set(x_6, 1, x_2);
lean_closure_set(x_6, 2, x_3);
lean_closure_set(x_6, 3, x_5);
x_7 = l_instFromJsonRBTreeVarsColour_fromJson___closed__2;
x_8 = l_Lean_Json_parseTagged(x_1, x_4, x_5, x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; 
x_10 = l_Except_orElseLazy___redArg(x_8, x_6);
lean_dec_ref(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_8, 0);
lean_inc(x_11);
lean_dec(x_8);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Except_orElseLazy___redArg(x_12, x_6);
lean_dec_ref(x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
lean_dec_ref(x_8);
x_14 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
x_15 = l_Except_orElseLazy___redArg(x_14, x_6);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_4);
return x_7;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_empty_x3f___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; 
x_2 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_;
return x_2;
}
case 1:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_inc(x_3);
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l_Lean_Json_mkObj(x_7);
return x_8;
}
default: 
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_9 = lean_ctor_get(x_1, 0);
x_10 = lean_ctor_get(x_1, 1);
x_11 = lean_ctor_get(x_1, 2);
x_12 = lean_ctor_get(x_1, 3);
x_13 = l_node_x3f___closed__0;
x_14 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_inc(x_9);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_9);
x_16 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_inc(x_10);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_10);
x_18 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_inc(x_11);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_11);
x_20 = l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_;
lean_inc(x_12);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_12);
x_22 = lean_box(0);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_21);
lean_ctor_set(x_23, 1, x_22);
x_24 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_24, 0, x_19);
lean_ctor_set(x_24, 1, x_23);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_17);
lean_ctor_set(x_25, 1, x_24);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_15);
lean_ctor_set(x_26, 1, x_25);
x_27 = l_Lean_Json_mkObj(x_26);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_13);
lean_ctor_set(x_28, 1, x_27);
x_29 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_22);
x_30 = l_Lean_Json_mkObj(x_29);
return x_30;
}
}
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_;
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_1);
return x_2;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
case 1:
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_1);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_6 = lean_ctor_get(x_1, 0);
x_7 = l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_8 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(x_7, x_6, x_2);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_8, 0);
x_11 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_10);
lean_ctor_set(x_1, 0, x_11);
x_12 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_1);
lean_dec_ref(x_1);
lean_ctor_set(x_8, 0, x_12);
return x_8;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_13 = lean_ctor_get(x_8, 0);
x_14 = lean_ctor_get(x_8, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_8);
x_15 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_13);
lean_ctor_set(x_1, 0, x_15);
x_16 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_1);
lean_dec_ref(x_1);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_14);
return x_17;
}
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_18 = lean_ctor_get(x_1, 0);
lean_inc(x_18);
lean_dec(x_1);
x_19 = l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_20 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(x_19, x_18, x_2);
x_21 = lean_ctor_get(x_20, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_20, 1);
lean_inc(x_22);
if (lean_is_exclusive(x_20)) {
 lean_ctor_release(x_20, 0);
 lean_ctor_release(x_20, 1);
 x_23 = x_20;
} else {
 lean_dec_ref(x_20);
 x_23 = lean_box(0);
}
x_24 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_21);
x_25 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_25, 0, x_24);
x_26 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_25);
lean_dec_ref(x_25);
if (lean_is_scalar(x_23)) {
 x_27 = lean_alloc_ctor(0, 2, 0);
} else {
 x_27 = x_23;
}
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_22);
return x_27;
}
}
default: 
{
uint8_t x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; 
x_28 = lean_ctor_get_uint8(x_1, sizeof(void*)*3);
x_29 = lean_ctor_get(x_1, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_30);
x_31 = lean_ctor_get(x_1, 2);
lean_inc(x_31);
lean_dec_ref(x_1);
x_32 = l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_29, x_2);
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
lean_dec_ref(x_32);
x_35 = l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_36 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(x_35, x_30, x_34);
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec_ref(x_36);
x_39 = l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_31, x_38);
x_40 = !lean_is_exclusive(x_39);
if (x_40 == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_41 = lean_ctor_get(x_39, 0);
x_42 = l_instToJsonRBTreeVarsColour_toJson(x_28);
x_43 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_37);
x_44 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_33);
lean_ctor_set(x_44, 2, x_43);
lean_ctor_set(x_44, 3, x_41);
x_45 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_44);
lean_dec_ref(x_44);
lean_ctor_set(x_39, 0, x_45);
return x_39;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_46 = lean_ctor_get(x_39, 0);
x_47 = lean_ctor_get(x_39, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_39);
x_48 = l_instToJsonRBTreeVarsColour_toJson(x_28);
x_49 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_37);
x_50 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_50, 0, x_48);
lean_ctor_set(x_50, 1, x_33);
lean_ctor_set(x_50, 2, x_49);
lean_ctor_set(x_50, 3, x_46);
x_51 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_(x_50);
lean_dec_ref(x_50);
x_52 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_52, 0, x_51);
lean_ctor_set(x_52, 1, x_47);
return x_52;
}
}
}
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_(x_1);
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
lean_dec_ref(x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
else
{
lean_object* x_7; 
x_7 = lean_ctor_get(x_3, 0);
lean_inc(x_7);
lean_dec_ref(x_3);
switch (lean_obj_tag(x_7)) {
case 0:
{
lean_object* x_8; 
lean_dec_ref(x_2);
x_8 = l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
return x_8;
}
case 1:
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_7);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_7, 0);
x_11 = l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(x_10);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
lean_free_object(x_7);
lean_dec_ref(x_2);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
return x_11;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_11, 0);
lean_inc(x_13);
lean_dec(x_11);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_11, 0);
lean_inc(x_15);
lean_dec_ref(x_11);
x_16 = l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_17 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(x_16, x_15, x_2);
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_18; 
lean_free_object(x_7);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
return x_17;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_17, 0);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_20, 0, x_19);
return x_20;
}
}
else
{
uint8_t x_21; 
x_21 = !lean_is_exclusive(x_17);
if (x_21 == 0)
{
lean_object* x_22; 
x_22 = lean_ctor_get(x_17, 0);
lean_ctor_set(x_7, 0, x_22);
lean_ctor_set(x_17, 0, x_7);
return x_17;
}
else
{
lean_object* x_23; lean_object* x_24; 
x_23 = lean_ctor_get(x_17, 0);
lean_inc(x_23);
lean_dec(x_17);
lean_ctor_set(x_7, 0, x_23);
x_24 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_24, 0, x_7);
return x_24;
}
}
}
}
else
{
lean_object* x_25; lean_object* x_26; 
x_25 = lean_ctor_get(x_7, 0);
lean_inc(x_25);
lean_dec(x_7);
x_26 = l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(x_25);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; 
lean_dec_ref(x_2);
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
if (lean_is_exclusive(x_26)) {
 lean_ctor_release(x_26, 0);
 x_28 = x_26;
} else {
 lean_dec_ref(x_26);
 x_28 = lean_box(0);
}
if (lean_is_scalar(x_28)) {
 x_29 = lean_alloc_ctor(0, 1, 0);
} else {
 x_29 = x_28;
}
lean_ctor_set(x_29, 0, x_27);
return x_29;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_26, 0);
lean_inc(x_30);
lean_dec_ref(x_26);
x_31 = l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
x_32 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(x_31, x_30, x_2);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 x_34 = x_32;
} else {
 lean_dec_ref(x_32);
 x_34 = lean_box(0);
}
if (lean_is_scalar(x_34)) {
 x_35 = lean_alloc_ctor(0, 1, 0);
} else {
 x_35 = x_34;
}
lean_ctor_set(x_35, 0, x_33);
return x_35;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_32, 0);
lean_inc(x_36);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 x_37 = x_32;
} else {
 lean_dec_ref(x_32);
 x_37 = lean_box(0);
}
x_38 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_38, 0, x_36);
if (lean_is_scalar(x_37)) {
 x_39 = lean_alloc_ctor(1, 1, 0);
} else {
 x_39 = x_37;
}
lean_ctor_set(x_39, 0, x_38);
return x_39;
}
}
}
}
default: 
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_40 = lean_ctor_get(x_7, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_7, 1);
lean_inc(x_41);
x_42 = lean_ctor_get(x_7, 2);
lean_inc(x_42);
x_43 = lean_ctor_get(x_7, 3);
lean_inc(x_43);
lean_dec_ref(x_7);
x_44 = l_instFromJsonRBTreeVarsColour_fromJson(x_40);
if (lean_obj_tag(x_44) == 0)
{
uint8_t x_45; 
lean_dec(x_43);
lean_dec(x_42);
lean_dec(x_41);
lean_dec_ref(x_2);
x_45 = !lean_is_exclusive(x_44);
if (x_45 == 0)
{
return x_44;
}
else
{
lean_object* x_46; lean_object* x_47; 
x_46 = lean_ctor_get(x_44, 0);
lean_inc(x_46);
lean_dec(x_44);
x_47 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_47, 0, x_46);
return x_47;
}
}
else
{
lean_object* x_48; lean_object* x_49; 
x_48 = lean_ctor_get(x_44, 0);
lean_inc(x_48);
lean_dec_ref(x_44);
lean_inc_ref(x_2);
x_49 = l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_41, x_2);
if (lean_obj_tag(x_49) == 0)
{
lean_dec(x_48);
lean_dec(x_43);
lean_dec(x_42);
lean_dec_ref(x_2);
return x_49;
}
else
{
lean_object* x_50; lean_object* x_51; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec_ref(x_49);
x_51 = l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(x_42);
if (lean_obj_tag(x_51) == 0)
{
uint8_t x_52; 
lean_dec(x_50);
lean_dec(x_48);
lean_dec(x_43);
lean_dec_ref(x_2);
x_52 = !lean_is_exclusive(x_51);
if (x_52 == 0)
{
return x_51;
}
else
{
lean_object* x_53; lean_object* x_54; 
x_53 = lean_ctor_get(x_51, 0);
lean_inc(x_53);
lean_dec(x_51);
x_54 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_54, 0, x_53);
return x_54;
}
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_55 = lean_ctor_get(x_51, 0);
lean_inc(x_55);
lean_dec_ref(x_51);
x_56 = l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_;
lean_inc_ref(x_2);
x_57 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(x_56, x_55, x_2);
if (lean_obj_tag(x_57) == 0)
{
uint8_t x_58; 
lean_dec(x_50);
lean_dec(x_48);
lean_dec(x_43);
lean_dec_ref(x_2);
x_58 = !lean_is_exclusive(x_57);
if (x_58 == 0)
{
return x_57;
}
else
{
lean_object* x_59; lean_object* x_60; 
x_59 = lean_ctor_get(x_57, 0);
lean_inc(x_59);
lean_dec(x_57);
x_60 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_60, 0, x_59);
return x_60;
}
}
else
{
lean_object* x_61; lean_object* x_62; 
x_61 = lean_ctor_get(x_57, 0);
lean_inc(x_61);
lean_dec_ref(x_57);
x_62 = l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_43, x_2);
if (lean_obj_tag(x_62) == 0)
{
lean_dec(x_61);
lean_dec(x_50);
lean_dec(x_48);
return x_62;
}
else
{
uint8_t x_63; 
x_63 = !lean_is_exclusive(x_62);
if (x_63 == 0)
{
lean_object* x_64; lean_object* x_65; uint8_t x_66; 
x_64 = lean_ctor_get(x_62, 0);
x_65 = lean_alloc_ctor(2, 3, 1);
lean_ctor_set(x_65, 0, x_50);
lean_ctor_set(x_65, 1, x_61);
lean_ctor_set(x_65, 2, x_64);
x_66 = lean_unbox(x_48);
lean_dec(x_48);
lean_ctor_set_uint8(x_65, sizeof(void*)*3, x_66);
lean_ctor_set(x_62, 0, x_65);
return x_62;
}
else
{
lean_object* x_67; lean_object* x_68; uint8_t x_69; lean_object* x_70; 
x_67 = lean_ctor_get(x_62, 0);
lean_inc(x_67);
lean_dec(x_62);
x_68 = lean_alloc_ctor(2, 3, 1);
lean_ctor_set(x_68, 0, x_50);
lean_ctor_set(x_68, 1, x_61);
lean_ctor_set(x_68, 2, x_67);
x_69 = lean_unbox(x_48);
lean_dec(x_48);
lean_ctor_set_uint8(x_68, sizeof(void*)*3, x_69);
x_70 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_70, 0, x_68);
return x_70;
}
}
}
}
}
}
}
}
}
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableRBTreeVars___closed__1;
x_2 = l_instRpcEncodableRBTreeVars___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableRBTreeVars() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableRBTreeVars___closed__2;
return x_1;
}
}
LEAN_EXPORT lean_object* l_RBDisplayProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBDisplayProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RBDisplayProps_ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tree", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
x_7 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_;
x_8 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Server_instToJsonCodeActionResolveData_toJson_spec__0(x_6, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
return x_9;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRBDisplayProps_enc____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = l_instRpcEncodableRBTreeVars_enc____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_(x_5);
lean_ctor_set(x_3, 0, x_6);
return x_3;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = lean_ctor_get(x_3, 0);
x_8 = lean_ctor_get(x_3, 1);
lean_inc(x_8);
lean_inc(x_7);
lean_dec(x_3);
x_9 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_(x_7);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_8);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRBDisplayProps_dec____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_instRpcEncodableRBTreeVars_dec____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_(x_4, x_2);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_5);
if (x_9 == 0)
{
return x_5;
}
else
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_5, 0);
lean_inc(x_10);
lean_dec(x_5);
x_11 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
}
}
static lean_object* _init_l_instRpcEncodableRBDisplayProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRBDisplayProps_enc____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRBDisplayProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRBDisplayProps_dec____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRBDisplayProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableRBDisplayProps___closed__1;
x_2 = l_instRpcEncodableRBDisplayProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableRBDisplayProps() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableRBDisplayProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_RBDisplay___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsx as t,jsxs as e}from\"react/jsx-runtime\";import*as n from\"react\";import r from\"react\";import i from\"react-dom\";import{InteractiveCode as o}from\"@leanprover/infoview\";function a(t){var e=0,n=t.children,r=n&&n.length;if(r)for(;--r>=0;)e+=n[r].value;else e=1;t.value=e}function s(t,e){var n,r,i,o,a,s=new h(t),l=+t.value&&(s.value=t.value),f=[s];for(null==e&&(e=u);n=f.pop();)if(l&&(n.value=+n.data.value),(i=e(n.data))&&(a=i.length))for(n.children=new Array(a),o=a-1;o>=0;--o)f.push(r=n.children[o]=new h(i[o])),r.parent=n,r.depth=n.depth+1;return s.eachBefore(c)}function u(t){return t.children}function l(t){t.data=t.data.data}function c(t){var e=0;do{t.height=e}while((t=t.parent)&&t.height<++e)}function h(t){this.data=t,this.depth=this.height=0,this.parent=null}function f(t,e){return t.parent===e.parent\?1:2}function p(t){var e=t.children;return e\?e[0]:t.t}function d(t){var e=t.children;return e\?e[e.length-1]:t.t}function m(t,e,n){var r=n/(e.i-t.i);e.c-=r,e.s+=n,t.c+=r,e.z+=n,e.m+=n}function y(t,e,n){return t.a.parent===e.parent\?t.a:n}function v(t,e){this._=t,this.parent=null,this.children=null,this.A=null,this.a=this,this.z=0,this.m=0,this.c=0,this.s=0,this.t=null,this.i=e}function g(){var t=f,e=1,n=1,r=null;function i(i){var u=function(t){for(var e,n,r,i,o,a=new v(t,0),s=[a];e=s.pop();)if(r=e._.children)for(e.children=new Array(o=r.length),i=o-1;i>=0;--i)s.push(n=e.children[i]=new v(r[i],i)),n.parent=e;return(a.parent=new v(null,0)).children=[a],a}(i);if(u.eachAfter(o),u.parent.m=-u.z,u.eachBefore(a),r)i.eachBefore(s);else{var l=i,c=i,h=i;i.eachBefore((function(t){t.x<l.x&&(l=t),t.x>c.x&&(c=t),t.depth>h.depth&&(h=t)}));var f=l===c\?1:t(l,c)/2,p=f-l.x,d=e/(c.x+f+p),m=n/(h.depth||1);i.eachBefore((function(t){t.x=(t.x+p)*d,t.y=t.depth*m}))}return i}function o(e){var n=e.children,r=e.parent.children,i=e.i\?r[e.i-1]:null;if(n){!function(t){for(var e,n=0,r=0,i=t.children,o=i.length;--o>=0;)(e=i[o]).z+=n,e.m+=n,n+=e.s+(r+=e.c)}(e);var o=(n[0].z+n[n.length-1].z)/2;i\?(e.z=i.z+t(e._,i._),e.m=e.z-o):e.z=o}else i&&(e.z=i.z+t(e._,i._));e.parent.A=function(e,n,r){if(n){for(var i,o=e,a=e,s=n,u=o.parent.children[0],l=o.m,c=a.m,h=s.m,f=u.m;s=d(s),o=p(o),s&&o;)u=p(u),(a=d(a)).a=e,(i=s.z+h-o.z-l+t(s._,o._))>0&&(m(y(s,e,r),e,i),l+=i,c+=i),h+=s.m,l+=o.m,f+=u.m,c+=a.m;s&&!d(a)&&(a.t=s,a.m+=h-c),o&&!p(u)&&(u.t=o,u.m+=l-f,r=e)}return r}(e,i,e.parent.A||r[0])}function a(t){t._.x=t.z+t.parent.m,t.m+=t.parent.m}function s(t){t.x*=e,t.y=t.depth*n}return i.separation=function(e){return arguments.length\?(t=e,i):t},i.size=function(t){return arguments.length\?(r=!1,e=+t[0],n=+t[1],i):r\?null:[e,n]},i.nodeSize=function(t){return arguments.length\?(r=!0,e=+t[0],n=+t[1],i):r\?[e,n]:null},i}h.prototype=s.prototype={constructor:h,count:function(){return this.eachAfter(a)},each:function(t){var e,n,r,i,o=this,a=[o];do{for(e=a.reverse(),a=[];o=e.pop();)if(t(o),n=o.children)for(r=0,i=n.length;r<i;++r)a.push(n[r])}while(a.length);return this},eachAfter:function(t){for(var e,n,r,i=this,o=[i],a=[];i=o.pop();)if(a.push(i),e=i.children)for(n=0,r=e.length;n<r;++n)o.push(e[n]);for(;i=a.pop();)t(i);return this},eachBefore:function(t){for(var e,n,r=this,i=[r];r=i.pop();)if(t(r),e=r.children)for(n=e.length-1;n>=0;--n)i.push(e[n]);return this},sum:function(t){return this.eachAfter((function(e){for(var n=+t(e.data)||0,r=e.children,i=r&&r.length;--i>=0;)n+=r[i].value;e.value=n}))},sort:function(t){return this.eachBefore((function(e){e.children&&e.children.sort(t)}))},path:function(t){for(var e=this,n=function(t,e){if(t===e)return t;var n=t.ancestors(),r=e.ancestors(),i=null;t=n.pop(),e=r.pop();for(;t===e;)i=t,t=n.pop(),e=r.pop();return i}(e,t),r=[e];e!==n;)e=e.parent,r.push(e);for(var i=r.length;t!==n;)r.splice(i,0,t),t=t.parent;return r},ancestors:function(){for(var t=this,e=[t];t=t.parent;)e.push(t);return e},descendants:function(){var t=[];return this.each((function(e){t.push(e)})),t},leaves:function(){var t=[];return this.eachBefore((function(e){e.children||t.push(e)})),t},links:function(){var t=this,e=[];return t.each((function(n){n!==t&&e.push({source:n.parent,target:n})})),e},copy:function(){return s(this).eachBefore(l)}},v.prototype=Object.create(h.prototype);var _=\"http://www.w3.org/1999/xhtml\",w={svg:\"http://www.w3.org/2000/svg\",xhtml:_,xlink:\"http://www.w3.org/1999/xlink\",xml:\"http://www.w3.org/XML/1998/namespace\",xmlns:\"http://www.w3.org/2000/xmlns/\"};function b(t){var e=t+=\"\",n=e.indexOf(\":\");return n>=0&&\"xmlns\"!==(e=t.slice(0,n))&&(t=t.slice(n+1)),w.hasOwnProperty(e)\?{space:w[e],local:t}:t}function x(t){return function(){var e=this.ownerDocument,n=this.namespaceURI;return n===_&&e.documentElement.namespaceURI===_\?e.createElement(t):e.createElementNS(n,t)}}function N(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function E(t){var e=b(t);return(e.local\?N:x)(e)}function k(){}function T(t){return null==t\?k:function(){return this.querySelector(t)}}function O(){return[]}function M(t){return null==t\?O:function(){return this.querySelectorAll(t)}}function C(t){return function(){return function(t){return null==t\?[]:Array.isArray(t)\?t:Array.from(t)}(t.apply(this,arguments))}}function A(t){return function(){return this.matches(t)}}function S(t){return function(e){return e.matches(t)}}var D=Array.prototype.find;function P(){return this.firstElementChild}var z=Array.prototype.filter;function $(){return Array.from(this.children)}function L(t){return new Array(t.length)}function R(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}function j(t,e,n,r,i,o){for(var a,s=0,u=e.length,l=o.length;s<l;++s)(a=e[s])\?(a.__data__=o[s],r[s]=a):n[s]=new R(t,o[s]);for(;s<u;++s)(a=e[s])&&(i[s]=a)}function I(t,e,n,r,i,o,a){var s,u,l,c=new Map,h=e.length,f=o.length,p=new Array(h);for(s=0;s<h;++s)(u=e[s])&&(p[s]=l=a.call(u,u.__data__,s,e)+\"\",c.has(l)\?i[s]=u:c.set(l,u));for(s=0;s<f;++s)l=a.call(t,o[s],s,o)+\"\",(u=c.get(l))\?(r[s]=u,u.__data__=o[s],c.delete(l)):n[s]=new R(t,o[s]);for(s=0;s<h;++s)(u=e[s])&&c.get(p[s])===u&&(i[s]=u)}function U(t){return t.__data__}function F(t){return\"object\"==typeof t&&\"length\"in t\?t:Array.from(t)}function B(t,e){return t<e\?-1:t>e\?1:t>=e\?0:NaN}function W(t){return function(){this.removeAttribute(t)}}function q(t){return function(){this.removeAttributeNS(t.space,t.local)}}function V(t,e){return function(){this.setAttribute(t,e)}}function X(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function H(t,e){return function(){var n=e.apply(this,arguments);null==n\?this.removeAttribute(t):this.setAttribute(t,n)}}function K(t,e){return function(){var n=e.apply(this,arguments);null==n\?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,n)}}function Y(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function G(t){return function(){this.style.removeProperty(t)}}function Q(t,e,n){return function(){this.style.setProperty(t,e,n)}}function Z(t,e,n){return function(){var r=e.apply(this,arguments);null==r\?this.style.removeProperty(t):this.style.setProperty(t,r,n)}}function J(t,e){return t.style.getPropertyValue(e)||Y(t).getComputedStyle(t,null).getPropertyValue(e)}function tt(t){return function(){delete this[t]}}function et(t,e){return function(){this[t]=e}}function nt(t,e){return function(){var n=e.apply(this,arguments);null==n\?delete this[t]:this[t]=n}}function rt(t){return t.trim().split(/^|\\s+/)}function it(t){return t.classList||new ot(t)}function ot(t){this._node=t,this._names=rt(t.getAttribute(\"class\")||\"\")}function at(t,e){for(var n=it(t),r=-1,i=e.length;++r<i;)n.add(e[r])}function st(t,e){for(var n=it(t),r=-1,i=e.length;++r<i;)n.remove(e[r])}function ut(t){return function(){at(this,t)}}function lt(t){return function(){st(this,t)}}function ct(t,e){return function(){(e.apply(this,arguments)\?at:st)(this,t)}}function ht(){this.textContent=\"\"}function ft(t){return function(){this.textContent=t}}function pt(t){return function(){var e=t.apply(this,arguments);this.textContent=null==e\?\"\":e}}function dt(){this.innerHTML=\"\"}function mt(t){return function(){this.innerHTML=t}}function yt(t){return function(){var e=t.apply(this,arguments);this.innerHTML=null==e\?\"\":e}}function vt(){this.nextSibling&&this.parentNode.appendChild(this)}function gt(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function _t(){return null}function wt(){var t=this.parentNode;t&&t.removeChild(this)}function bt(){var t=this.cloneNode(!1),e=this.parentNode;return e\?e.insertBefore(t,this.nextSibling):t}function xt(){var t=this.cloneNode(!0),e=this.parentNode;return e\?e.insertBefore(t,this.nextSibling):t}function Nt(t){return function(){var e=this.__on;if(e){for(var n,r=0,i=-1,o=e.length;r<o;++r)n=e[r],t.type&&n.type!==t.type||n.name!==t.name\?e[++i]=n:this.removeEventListener(n.type,n.listener,n.options);++i\?e.length=i:delete this.__on}}}function Et(t,e,n){return function(){var r,i=this.__on,o=function(t){return function(e){t.call(this,e,this.__data__)}}(e);if(i)for(var a=0,s=i.length;a<s;++a)if((r=i[a]).type===t.type&&r.name===t.name)return this.removeEventListener(r.type,r.listener,r.options),this.addEventListener(r.type,r.listener=o,r.options=n),void(r.value=e);this.addEventListener(t.type,o,n),r={type:t.type,name:t.name,value:e,listener:o,options:n},i\?i.push(r):this.__on=[r]}}function kt(t,e,n){var r=Y(t),i=r.CustomEvent;\"function\"==typeof i\?i=new i(e,n):(i=r.document.createEvent(\"Event\"),n\?(i.initEvent(e,n.bubbles,n.cancelable),i.detail=n.detail):i.initEvent(e,!1,!1)),t.dispatchEvent(i)}function Tt(t,e){return function(){return kt(this,t,e)}}function Ot(t,e){return function(){return kt(this,t,e.apply(this,arguments))}}R.prototype={constructor:R,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}},ot.prototype={add:function(t){this._names.indexOf(t)<0&&(this._names.push(t),this._node.setAttribute(\"class\",this._names.join(\" \")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute(\"class\",this._names.join(\" \")))},contains:function(t){return this._names.indexOf(t)>=0}};var Mt=[null];function Ct(t,e){this._groups=t,this._parents=e}function At(){return new Ct([[document.documentElement]],Mt)}function St(t){return\"string\"==typeof t\?new Ct([[document.querySelector(t)]],[document.documentElement]):new Ct([[t]],Mt)}function Dt(t,e){if(t=function(t){let e;for(;e=t.sourceEvent;)t=e;return t}(t),void 0===e&&(e=t.currentTarget),e){var n=e.ownerSVGElement||e;if(n.createSVGPoint){var r=n.createSVGPoint();return r.x=t.clientX,r.y=t.clientY,[(r=r.matrixTransform(e.getScreenCTM().inverse())).x,r.y]}if(e.getBoundingClientRect){var i=e.getBoundingClientRect();return[t.clientX-i.left-e.clientLeft,t.clientY-i.top-e.clientTop]}}return[t.pageX,t.pageY]}Ct.prototype=At.prototype={constructor:Ct,select:function(t){\"function\"!=typeof t&&(t=T(t));for(var e=this._groups,n=e.length,r=new Array(n),i=0;i<n;++i)for(var o,a,s=e[i],u=s.length,l=r[i]=new Array(u),c=0;c<u;++c)(o=s[c])&&(a=t.call(o,o.__data__,c,s))&&(\"__data__\"in o&&(a.__data__=o.__data__),l[c]=a);return new Ct(r,this._parents)},selectAll:function(t){t=\"function\"==typeof t\?C(t):M(t);for(var e=this._groups,n=e.length,r=[],i=[],o=0;o<n;++o)for(var a,s=e[o],u=s.length,l=0;l<u;++l)(a=s[l])&&(r.push(t.call(a,a.__data__,l,s)),i.push(a));return new Ct(r,i)},selectChild:function(t){return this.select(null==t\?P:function(t){return function(){return D.call(this.children,t)}}(\"function\"==typeof t\?t:S(t)))},selectChildren:function(t){return this.selectAll(null==t\?$:function(t){return function(){return z.call(this.children,t)}}(\"function\"==typeof t\?t:S(t)))},filter:function(t){\"function\"!=typeof t&&(t=A(t));for(var e=this._groups,n=e.length,r=new Array(n),i=0;i<n;++i)for(var o,a=e[i],s=a.length,u=r[i]=[],l=0;l<s;++l)(o=a[l])&&t.call(o,o.__data__,l,a)&&u.push(o);return new Ct(r,this._parents)},data:function(t,e){if(!arguments.length)return Array.from(this,U);var n=e\?I:j,r=this._parents,i=this._groups;\"function\"!=typeof t&&(t=function(t){return function(){return t}}(t));for(var o=i.length,a=new Array(o),s=new Array(o),u=new Array(o),l=0;l<o;++l){var c=r[l],h=i[l],f=h.length,p=F(t.call(c,c&&c.__data__,l,r)),d=p.length,m=s[l]=new Array(d),y=a[l]=new Array(d);n(c,h,m,y,u[l]=new Array(f),p,e);for(var v,g,_=0,w=0;_<d;++_)if(v=m[_]){for(_>=w&&(w=_+1);!(g=y[w])&&++w<d;);v._next=g||null}}return(a=new Ct(a,r))._enter=s,a._exit=u,a},enter:function(){return new Ct(this._enter||this._groups.map(L),this._parents)},exit:function(){return new Ct(this._exit||this._groups.map(L),this._parents)},join:function(t,e,n){var r=this.enter(),i=this,o=this.exit();return\"function\"==typeof t\?(r=t(r))&&(r=r.selection()):r=r.append(t+\"\"),null!=e&&(i=e(i))&&(i=i.selection()),null==n\?o.remove():n(o),r&&i\?r.merge(i).order():i},merge:function(t){for(var e=t.selection\?t.selection():t,n=this._groups,r=e._groups,i=n.length,o=r.length,a=Math.min(i,o),s=new Array(i),u=0;u<a;++u)for(var l,c=n[u],h=r[u],f=c.length,p=s[u]=new Array(f),d=0;d<f;++d)(l=c[d]||h[d])&&(p[d]=l);for(;u<i;++u)s[u]=n[u];return new Ct(s,this._parents)},selection:function(){return this},order:function(){for(var t=this._groups,e=-1,n=t.length;++e<n;)for(var r,i=t[e],o=i.length-1,a=i[o];--o>=0;)(r=i[o])&&(a&&4^r.compareDocumentPosition(a)&&a.parentNode.insertBefore(r,a),a=r);return this},sort:function(t){function e(e,n){return e&&n\?t(e.__data__,n.__data__):!e-!n}t||(t=B);for(var n=this._groups,r=n.length,i=new Array(r),o=0;o<r;++o){for(var a,s=n[o],u=s.length,l=i[o]=new Array(u),c=0;c<u;++c)(a=s[c])&&(l[c]=a);l.sort(e)}return new Ct(i,this._parents).order()},call:function(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this},nodes:function(){return Array.from(this)},node:function(){for(var t=this._groups,e=0,n=t.length;e<n;++e)for(var r=t[e],i=0,o=r.length;i<o;++i){var a=r[i];if(a)return a}return null},size:function(){let t=0;for(const e of this)++t;return t},empty:function(){return!this.node()},each:function(t){for(var e=this._groups,n=0,r=e.length;n<r;++n)for(var i,o=e[n],a=0,s=o.length;a<s;++a)(i=o[a])&&t.call(i,i.__data__,a,o);return this},attr:function(t,e){var n=b(t);if(arguments.length<2){var r=this.node();return n.local\?r.getAttributeNS(n.space,n.local):r.getAttribute(n)}return this.each((null==e\?n.local\?q:W:\"function\"==typeof e\?n.local\?K:H:n.local\?X:V)(n,e))},style:function(t,e,n){return arguments.length>1\?this.each((null==e\?G:\"function\"==typeof e\?Z:Q)(t,e,null==n\?\"\":n)):J(this.node(),t)},property:function(t,e){return arguments.length>1\?this.each((null==e\?tt:\"function\"==typeof e\?nt:et)(t,e)):this.node()[t]},classed:function(t,e){var n=rt(t+\"\");if(arguments.length<2){for(var r=it(this.node()),i=-1,o=n.length;++i<o;)if(!r.contains(n[i]))return!1;return!0}return this.each((\"function\"==typeof e\?ct:e\?ut:lt)(n,e))},text:function(t){return arguments.length\?this.each(null==t\?ht:(\"function\"==typeof t\?pt:ft)(t)):this.node().textContent},html:function(t){return arguments.length\?this.each(null==t\?dt:(\"function\"==typeof t\?yt:mt)(t)):this.node().innerHTML},raise:function(){return this.each(vt)},lower:function(){return this.each(gt)},append:function(t){var e=\"function\"==typeof t\?t:E(t);return this.select((function(){return this.appendChild(e.apply(this,arguments))}))},insert:function(t,e){var n=\"function\"==typeof t\?t:E(t),r=null==e\?_t:\"function\"==typeof e\?e:T(e);return this.select((function(){return this.insertBefore(n.apply(this,arguments),r.apply(this,arguments)||null)}))},remove:function(){return this.each(wt)},clone:function(t){return this.select(t\?xt:bt)},datum:function(t){return arguments.length\?this.property(\"__data__\",t):this.node().__data__},on:function(t,e,n){var r,i,o=function(t){return t.trim().split(/^|\\s+/).map((function(t){var e=\"\",n=t.indexOf(\".\");return n>=0&&(e=t.slice(n+1),t=t.slice(0,n)),{type:t,name:e}}))}(t+\"\"),a=o.length;if(!(arguments.length<2)){for(s=e\?Et:Nt,r=0;r<a;++r)this.each(s(o[r],e,n));return this}var s=this.node().__on;if(s)for(var u,l=0,c=s.length;l<c;++l)for(r=0,u=s[l];r<a;++r)if((i=o[r]).type===u.type&&i.name===u.name)return u.value},dispatch:function(t,e){return this.each((\"function\"==typeof e\?Ot:Tt)(t,e))},[Symbol.iterator]:function*(){for(var t=this._groups,e=0,n=t.length;e<n;++e)for(var r,i=t[e],o=0,a=i.length;o<a;++o)(r=i[o])&&(yield r)}};var Pt={value:()=>{}};function zt(){for(var t,e=0,n=arguments.length,r={};e<n;++e){if(!(t=arguments[e]+\"\")||t in r||/[\\s.]/.test(t))throw new Error(\"illegal type: \"+t);r[t]=[]}return new $t(r)}function $t(t){this._=t}function Lt(t,e){for(var n,r=0,i=t.length;r<i;++r)if((n=t[r]).name===e)return n.value}function Rt(t,e,n){for(var r=0,i=t.length;r<i;++r)if(t[r].name===e){t[r]=Pt,t=t.slice(0,r).concat(t.slice(r+1));break}return null!=n&&t.push({name:e,value:n}),t}$t.prototype=zt.prototype={constructor:$t,on:function(t,e){var n,r,i=this._,o=(r=i,(t+\"\").trim().split(/^|\\s+/).map((function(t){var e=\"\",n=t.indexOf(\".\");if(n>=0&&(e=t.slice(n+1),t=t.slice(0,n)),t&&!r.hasOwnProperty(t))throw new Error(\"unknown type: \"+t);return{type:t,name:e}}))),a=-1,s=o.length;if(!(arguments.length<2)){if(null!=e&&\"function\"!=typeof e)throw new Error(\"invalid callback: \"+e);for(;++a<s;)if(n=(t=o[a]).type)i[n]=Rt(i[n],t.name,e);else if(null==e)for(n in i)i[n]=Rt(i[n],t.name,null);return this}for(;++a<s;)if((n=(t=o[a]).type)&&(n=Lt(i[n],t.name)))return n},copy:function(){var t={},e=this._;for(var n in e)t[n]=e[n].slice();return new $t(t)},call:function(t,e){if((n=arguments.length-2)>0)for(var n,r,i=new Array(n),o=0;o<n;++o)i[o]=arguments[o+2];if(!this._.hasOwnProperty(t))throw new Error(\"unknown type: \"+t);for(o=0,n=(r=this._[t]).length;o<n;++o)r[o].value.apply(e,i)},apply:function(t,e,n){if(!this._.hasOwnProperty(t))throw new Error(\"unknown type: \"+t);for(var r=this._[t],i=0,o=r.length;i<o;++i)r[i].value.apply(e,n)}};const jt={capture:!0,passive:!1};function It(t){t.preventDefault(),t.stopImmediatePropagation()}function Ut(t,e,n){t.prototype=e.prototype=n,n.constructor=t}function Ft(t,e){var n=Object.create(t.prototype);for(var r in e)n[r]=e[r];return n}function Bt(){}var Wt=.7,qt=1/Wt,Vt=\"\\\\s*([+-]\?\\\\d+)\\\\s*\",Xt=\"\\\\s*([+-]\?(\?:\\\\d*\\\\.)\?\\\\d+(\?:[eE][+-]\?\\\\d+)\?)\\\\s*\",Ht=\"\\\\s*([+-]\?(\?:\\\\d*\\\\.)\?\\\\d+(\?:[eE][+-]\?\\\\d+)\?)%\\\\s*\",Kt=/^#([0-9a-f]{3,8})$/,Yt=new RegExp(`^rgb\\\\(${Vt},${Vt},${Vt}\\\\)$`),Gt=new RegExp(`^rgb\\\\(${Ht},${Ht},${Ht}\\\\)$`),Qt=new RegExp(`^rgba\\\\(${Vt},${Vt},${Vt},${Xt}\\\\)$`),Zt=new RegExp(`^rgba\\\\(${Ht},${Ht},${Ht},${Xt}\\\\)$`),Jt=new RegExp(`^hsl\\\\(${Xt},${Ht},${Ht}\\\\)$`),te=new RegExp(`^hsla\\\\(${Xt},${Ht},${Ht},${Xt}\\\\)$`),ee={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};function ne(){return this.rgb().formatHex()}function re(){return this.rgb().formatRgb()}function ie(t){var e,n;return t=(t+\"\").trim().toLowerCase(),(e=Kt.exec(t))\?(n=e[1].length,e=parseInt(e[1],16),6===n\?oe(e):3===n\?new ue(e>>8&15|e>>4&240,e>>4&15|240&e,(15&e)<<4|15&e,1):8===n\?ae(e>>24&255,e>>16&255,e>>8&255,(255&e)/255):4===n\?ae(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|240&e,((15&e)<<4|15&e)/255):null):(e=Yt.exec(t))\?new ue(e[1],e[2],e[3],1):(e=Gt.exec(t))\?new ue(255*e[1]/100,255*e[2]/100,255*e[3]/100,1):(e=Qt.exec(t))\?ae(e[1],e[2],e[3],e[4]):(e=Zt.exec(t))\?ae(255*e[1]/100,255*e[2]/100,255*e[3]/100,e[4]):(e=Jt.exec(t))\?de(e[1],e[2]/100,e[3]/100,1):(e=te.exec(t))\?de(e[1],e[2]/100,e[3]/100,e[4]):ee.hasOwnProperty(t)\?oe(ee[t]):\"transparent\"===t\?new ue(NaN,NaN,NaN,0):null}function oe(t){return new ue(t>>16&255,t>>8&255,255&t,1)}function ae(t,e,n,r){return r<=0&&(t=e=n=NaN),new ue(t,e,n,r)}function se(t,e,n,r){return 1===arguments.length\?((i=t)instanceof Bt||(i=ie(i)),i\?new ue((i=i.rgb()).r,i.g,i.b,i.opacity):new ue):new ue(t,e,n,null==r\?1:r);var i}function ue(t,e,n,r){this.r=+t,this.g=+e,this.b=+n,this.opacity=+r}function le(){return`#${pe(this.r)}${pe(this.g)}${pe(this.b)}`}function ce(){const t=he(this.opacity);return`${1===t\?\"rgb(\":\"rgba(\"}${fe(this.r)}, ${fe(this.g)}, ${fe(this.b)}${1===t\?\")\":`, ${t})`}`}function he(t){return isNaN(t)\?1:Math.max(0,Math.min(1,t))}function fe(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function pe(t){return((t=fe(t))<16\?\"0\":\"\")+t.toString(16)}function de(t,e,n,r){return r<=0\?t=e=n=NaN:n<=0||n>=1\?t=e=NaN:e<=0&&(t=NaN),new ye(t,e,n,r)}function me(t){if(t instanceof ye)return new ye(t.h,t.s,t.l,t.opacity);if(t instanceof Bt||(t=ie(t)),!t)return new ye;if(t instanceof ye)return t;var e=(t=t.rgb()).r/255,n=t.g/255,r=t.b/255,i=Math.min(e,n,r),o=Math.max(e,n,r),a=NaN,s=o-i,u=(o+i)/2;return s\?(a=e===o\?(n-r)/s+6*(n<r):n===o\?(r-e)/s+2:(e-n)/s+4,s/=u<.5\?o+i:2-o-i,a*=60):s=u>0&&u<1\?0:a,new ye(a,s,u,t.opacity)}function ye(t,e,n,r){this.h=+t,this.s=+e,this.l=+n,this.opacity=+r}function ve(t){return(t=(t||0)%360)<0\?t+360:t}function ge(t){return Math.max(0,Math.min(1,t||0))}function _e(t,e,n){return 255*(t<60\?e+(n-e)*t/60:t<180\?n:t<240\?e+(n-e)*(240-t)/60:e)}Ut(Bt,ie,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:ne,formatHex:ne,formatHex8:function(){return this.rgb().formatHex8()},formatHsl:function(){return me(this).formatHsl()},formatRgb:re,toString:re}),Ut(ue,se,Ft(Bt,{brighter(t){return t=null==t\?qt:Math.pow(qt,t),new ue(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=null==t\?Wt:Math.pow(Wt,t),new ue(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new ue(fe(this.r),fe(this.g),fe(this.b),he(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:le,formatHex:le,formatHex8:function(){return`#${pe(this.r)}${pe(this.g)}${pe(this.b)}${pe(255*(isNaN(this.opacity)\?1:this.opacity))}`},formatRgb:ce,toString:ce})),Ut(ye,(function(t,e,n,r){return 1===arguments.length\?me(t):new ye(t,e,n,null==r\?1:r)}),Ft(Bt,{brighter(t){return t=null==t\?qt:Math.pow(qt,t),new ye(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=null==t\?Wt:Math.pow(Wt,t),new ye(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+360*(this.h<0),e=isNaN(t)||isNaN(this.s)\?0:this.s,n=this.l,r=n+(n<.5\?n:1-n)*e,i=2*n-r;return new ue(_e(t>=240\?t-240:t+120,i,r),_e(t,i,r),_e(t<120\?t+240:t-120,i,r),this.opacity)},clamp(){return new ye(ve(this.h),ge(this.s),ge(this.l),he(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){const t=he(this.opacity);return`${1===t\?\"hsl(\":\"hsla(\"}${ve(this.h)}, ${100*ge(this.s)}%, ${100*ge(this.l)}%${1===t\?\")\":`, ${t})`}`}}));var we=t=>()=>t;function be(t){return 1==(t=+t)\?xe:function(e,n){return n-e\?function(t,e,n){return t=Math.pow(t,n),e=Math.pow(e,n)-t,n=1/n,function(r){return Math.pow(t+r*e,n)}}(e,n,t):we(isNaN(e)\?n:e)}}function xe(t,e){var n=e-t;return n\?function(t,e){return function(n){return t+n*e}}(t,n):we(isNaN(t)\?e:t)}var Ne=function t(e){var n=be(e);function r(t,e){var r=n((t=se(t)).r,(e=se(e)).r),i=n(t.g,e.g),o=n(t.b,e.b),a=xe(t.opacity,e.opacity);return function(e){return t.r=r(e),t.g=i(e),t.b=o(e),t.opacity=a(e),t+\"\"}}return r.gamma=t,r}(1);function Ee(t,e){return t=+t,e=+e,function(n){return t*(1-n)+e*n}}var ke=/[-+]\?(\?:\\d+\\.\?\\d*|\\.\?\\d+)(\?:[eE][-+]\?\\d+)\?/g,Te=new RegExp(ke.source,\"g\");function Oe(t,e){var n,r,i,o=ke.lastIndex=Te.lastIndex=0,a=-1,s=[],u=[];for(t+=\"\",e+=\"\";(n=ke.exec(t))&&(r=Te.exec(e));)(i=r.index)>o&&(i=e.slice(o,i),s[a]\?s[a]+=i:s[++a]=i),(n=n[0])===(r=r[0])\?s[a]\?s[a]+=r:s[++a]=r:(s[++a]=null,u.push({i:a,x:Ee(n,r)})),o=Te.lastIndex;return o<e.length&&(i=e.slice(o),s[a]\?s[a]+=i:s[++a]=i),s.length<2\?u[0]\?function(t){return function(e){return t(e)+\"\"}}(u[0].x):function(t){return function(){return t}}(e):(e=u.length,function(t){for(var n,r=0;r<e;++r)s[(n=u[r]).i]=n.x(t);return s.join(\"\")})}var Me,Ce=180/Math.PI,Ae={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Se(t,e,n,r,i,o){var a,s,u;return(a=Math.sqrt(t*t+e*e))&&(t/=a,e/=a),(u=t*n+e*r)&&(n-=t*u,r-=e*u),(s=Math.sqrt(n*n+r*r))&&(n/=s,r/=s,u/=s),t*r<e*n&&(t=-t,e=-e,u=-u,a=-a),{translateX:i,translateY:o,rotate:Math.atan2(e,t)*Ce,skewX:Math.atan(u)*Ce,scaleX:a,scaleY:s}}function De(t,e,n,r){function i(t){return t.length\?t.pop()+\" \":\"\"}return function(o,a){var s=[],u=[];return o=t(o),a=t(a),function(t,r,i,o,a,s){if(t!==i||r!==o){var u=a.push(\"translate(\",null,e,null,n);s.push({i:u-4,x:Ee(t,i)},{i:u-2,x:Ee(r,o)})}else(i||o)&&a.push(\"translate(\"+i+e+o+n)}(o.translateX,o.translateY,a.translateX,a.translateY,s,u),function(t,e,n,o){t!==e\?(t-e>180\?e+=360:e-t>180&&(t+=360),o.push({i:n.push(i(n)+\"rotate(\",null,r)-2,x:Ee(t,e)})):e&&n.push(i(n)+\"rotate(\"+e+r)}(o.rotate,a.rotate,s,u),function(t,e,n,o){t!==e\?o.push({i:n.push(i(n)+\"skewX(\",null,r)-2,x:Ee(t,e)}):e&&n.push(i(n)+\"skewX(\"+e+r)}(o.skewX,a.skewX,s,u),function(t,e,n,r,o,a){if(t!==n||e!==r){var s=o.push(i(o)+\"scale(\",null,\",\",null,\")\");a.push({i:s-4,x:Ee(t,n)},{i:s-2,x:Ee(e,r)})}else 1===n&&1===r||o.push(i(o)+\"scale(\"+n+\",\"+r+\")\")}(o.scaleX,o.scaleY,a.scaleX,a.scaleY,s,u),o=a=null,function(t){for(var e,n=-1,r=u.length;++n<r;)s[(e=u[n]).i]=e.x(t);return s.join(\"\")}}}var Pe=De((function(t){const e=new(\"function\"==typeof DOMMatrix\?DOMMatrix:WebKitCSSMatrix)(t+\"\");return e.isIdentity\?Ae:Se(e.a,e.b,e.c,e.d,e.e,e.f)}),\"px, \",\"px)\",\"deg)\"),ze=De((function(t){return null==t\?Ae:(Me||(Me=document.createElementNS(\"http://www.w3.org/2000/svg\",\"g\")),Me.setAttribute(\"transform\",t),(t=Me.transform.baseVal.consolidate())\?Se((t=t.matrix).a,t.b,t.c,t.d,t.e,t.f):Ae)}),\", \",\")\",\")\");function $e(t){return((t=Math.exp(t))+1/t)/2}var Le,Re,je=function t(e,n,r){function i(t,i){var o,a,s=t[0],u=t[1],l=t[2],c=i[0],h=i[1],f=i[2],p=c-s,d=h-u,m=p*p+d*d;if(m<1e-12)a=Math.log(f/l)/e,o=function(t){return[s+t*p,u+t*d,l*Math.exp(e*t*a)]};else{var y=Math.sqrt(m),v=(f*f-l*l+r*m)/(2*l*n*y),g=(f*f-l*l-r*m)/(2*f*n*y),_=Math.log(Math.sqrt(v*v+1)-v),w=Math.log(Math.sqrt(g*g+1)-g);a=(w-_)/e,o=function(t){var r=t*a,i=$e(_),o=l/(n*y)*(i*function(t){return((t=Math.exp(2*t))-1)/(t+1)}(e*r+_)-function(t){return((t=Math.exp(t))-1/t)/2}(_));return[s+o*p,u+o*d,l*i/$e(e*r+_)]}}return o.duration=1e3*a*e/Math.SQRT2,o}return i.rho=function(e){var n=Math.max(.001,+e),r=n*n;return t(n,r,r*r)},i}(Math.SQRT2,2,4),Ie=0,Ue=0,Fe=0,Be=0,We=0,qe=0,Ve=\"object\"==typeof performance&&performance.now\?performance:Date,Xe=window.requestAnimationFrame\?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function He(){return We||(Xe(Ke),We=Ve.now()+qe)}function Ke(){We=0}function Ye(){this._call=this._time=this._next=null}function Ge(t,e,n){var r=new Ye;return r.restart(t,e,n),r}function Qe(){We=(Be=Ve.now())+qe,Ie=Ue=0;try{!function(){He(),++Ie;for(var t,e=Le;e;)(t=We-e._time)>=0&&e._call.call(void 0,t),e=e._next;--Ie}()}finally{Ie=0,function(){var t,e,n=Le,r=1/0;for(;n;)n._call\?(r>n._time&&(r=n._time),t=n,n=n._next):(e=n._next,n._next=null,n=t\?t._next=e:Le=e);Re=t,Je(r)}(),We=0}}function Ze(){var t=Ve.now(),e=t-Be;e>1e3&&(qe-=e,Be=t)}function Je(t){Ie||(Ue&&(Ue=clearTimeout(Ue)),t-We>24\?(t<1/0&&(Ue=setTimeout(Qe,t-Ve.now()-qe)),Fe&&(Fe=clearInterval(Fe))):(Fe||(Be=Ve.now(),Fe=setInterval(Ze,1e3)),Ie=1,Xe(Qe)))}function tn(t,e,n){var r=new Ye;return e=null==e\?0:+e,r.restart((n=>{r.stop(),t(n+e)}),e,n),r}Ye.prototype=Ge.prototype={constructor:Ye,restart:function(t,e,n){if(\"function\"!=typeof t)throw new TypeError(\"callback is not a function\");n=(null==n\?He():+n)+(null==e\?0:+e),this._next||Re===this||(Re\?Re._next=this:Le=this,Re=this),this._call=t,this._time=n,Je()},stop:function(){this._call&&(this._call=null,this._time=1/0,Je())}};var en=zt(\"start\",\"end\",\"cancel\",\"interrupt\"),nn=[];function rn(t,e,n,r,i,o){var a=t.__transition;if(a){if(n in a)return}else t.__transition={};!function(t,e,n){var r,i=t.__transition;function o(t){n.state=1,n.timer.restart(a,n.delay,n.time),n.delay<=t&&a(t-n.delay)}function a(o){var l,c,h,f;if(1!==n.state)return u();for(l in i)if((f=i[l]).name===n.name){if(3===f.state)return tn(a);4===f.state\?(f.state=6,f.timer.stop(),f.on.call(\"interrupt\",t,t.__data__,f.index,f.group),delete i[l]):+l<e&&(f.state=6,f.timer.stop(),f.on.call(\"cancel\",t,t.__data__,f.index,f.group),delete i[l])}if(tn((function(){3===n.state&&(n.state=4,n.timer.restart(s,n.delay,n.time),s(o))})),n.state=2,n.on.call(\"start\",t,t.__data__,n.index,n.group),2===n.state){for(n.state=3,r=new Array(h=n.tween.length),l=0,c=-1;l<h;++l)(f=n.tween[l].value.call(t,t.__data__,n.index,n.group))&&(r[++c]=f);r.length=c+1}}function s(e){for(var i=e<n.duration\?n.ease.call(null,e/n.duration):(n.timer.restart(u),n.state=5,1),o=-1,a=r.length;++o<a;)r[o].call(t,i);5===n.state&&(n.on.call(\"end\",t,t.__data__,n.index,n.group),u())}function u(){for(var r in n.state=6,n.timer.stop(),delete i[e],i)return;delete t.__transition}i[e]=n,n.timer=Ge(o,0,n.time)}(t,n,{name:e,index:r,group:i,on:en,tween:nn,time:o.time,delay:o.delay,duration:o.duration,ease:o.ease,timer:null,state:0})}function on(t,e){var n=sn(t,e);if(n.state>0)throw new Error(\"too late; already scheduled\");return n}function an(t,e){var n=sn(t,e);if(n.state>3)throw new Error(\"too late; already running\");return n}function sn(t,e){var n=t.__transition;if(!n||!(n=n[e]))throw new Error(\"transition not found\");return n}function un(t,e){var n,r,i,o=t.__transition,a=!0;if(o){for(i in e=null==e\?null:e+\"\",o)(n=o[i]).name===e\?(r=n.state>2&&n.state<5,n.state=6,n.timer.stop(),n.on.call(r\?\"interrupt\":\"cancel\",t,t.__data__,n.index,n.group),delete o[i]):a=!1;a&&delete t.__transition}}function ln(t,e){var n,r;return function(){var i=an(this,t),o=i.tween;if(o!==n)for(var a=0,s=(r=n=o).length;a<s;++a)if(r[a].name===e){(r=r.slice()).splice(a,1);break}i.tween=r}}function cn(t,e,n){var r,i;if(\"function\"!=typeof n)throw new Error;return function(){var o=an(this,t),a=o.tween;if(a!==r){i=(r=a).slice();for(var s={name:e,value:n},u=0,l=i.length;u<l;++u)if(i[u].name===e){i[u]=s;break}u===l&&i.push(s)}o.tween=i}}function hn(t,e,n){var r=t._id;return t.each((function(){var t=an(this,r);(t.value||(t.value={}))[e]=n.apply(this,arguments)})),function(t){return sn(t,r).value[e]}}function fn(t,e){var n;return(\"number\"==typeof e\?Ee:e instanceof ie\?Ne:(n=ie(e))\?(e=n,Ne):Oe)(t,e)}function pn(t){return function(){this.removeAttribute(t)}}function dn(t){return function(){this.removeAttributeNS(t.space,t.local)}}function mn(t,e,n){var r,i,o=n+\"\";return function(){var a=this.getAttribute(t);return a===o\?null:a===r\?i:i=e(r=a,n)}}function yn(t,e,n){var r,i,o=n+\"\";return function(){var a=this.getAttributeNS(t.space,t.local);return a===o\?null:a===r\?i:i=e(r=a,n)}}function vn(t,e,n){var r,i,o;return function(){var a,s,u=n(this);if(null!=u)return(a=this.getAttribute(t))===(s=u+\"\")\?null:a===r&&s===i\?o:(i=s,o=e(r=a,u));this.removeAttribute(t)}}function gn(t,e,n){var r,i,o;return function(){var a,s,u=n(this);if(null!=u)return(a=this.getAttributeNS(t.space,t.local))===(s=u+\"\")\?null:a===r&&s===i\?o:(i=s,o=e(r=a,u));this.removeAttributeNS(t.space,t.local)}}function _n(t,e){var n,r;function i(){var i=e.apply(this,arguments);return i!==r&&(n=(r=i)&&function(t,e){return function(n){this.setAttributeNS(t.space,t.local,e.call(this,n))}}(t,i)),n}return i._value=e,i}function wn(t,e){var n,r;function i(){var i=e.apply(this,arguments);return i!==r&&(n=(r=i)&&function(t,e){return function(n){this.setAttribute(t,e.call(this,n))}}(t,i)),n}return i._value=e,i}function bn(t,e){return function(){on(this,t).delay=+e.apply(this,arguments)}}function xn(t,e){return e=+e,function(){on(this,t).delay=e}}function Nn(t,e){return function(){an(this,t).duration=+e.apply(this,arguments)}}function En(t,e){return e=+e,function(){an(this,t).duration=e}}var kn=At.prototype.constructor;function Tn(t){return function(){this.style.removeProperty(t)}}var On=0;function Mn(t,e,n,r){this._groups=t,this._parents=e,this._name=n,this._id=r}function Cn(){return++On}var An=At.prototype;Mn.prototype={constructor:Mn,select:function(t){var e=this._name,n=this._id;\"function\"!=typeof t&&(t=T(t));for(var r=this._groups,i=r.length,o=new Array(i),a=0;a<i;++a)for(var s,u,l=r[a],c=l.length,h=o[a]=new Array(c),f=0;f<c;++f)(s=l[f])&&(u=t.call(s,s.__data__,f,l))&&(\"__data__\"in s&&(u.__data__=s.__data__),h[f]=u,rn(h[f],e,n,f,h,sn(s,n)));return new Mn(o,this._parents,e,n)},selectAll:function(t){var e=this._name,n=this._id;\"function\"!=typeof t&&(t=M(t));for(var r=this._groups,i=r.length,o=[],a=[],s=0;s<i;++s)for(var u,l=r[s],c=l.length,h=0;h<c;++h)if(u=l[h]){for(var f,p=t.call(u,u.__data__,h,l),d=sn(u,n),m=0,y=p.length;m<y;++m)(f=p[m])&&rn(f,e,n,m,p,d);o.push(p),a.push(u)}return new Mn(o,a,e,n)},selectChild:An.selectChild,selectChildren:An.selectChildren,filter:function(t){\"function\"!=typeof t&&(t=A(t));for(var e=this._groups,n=e.length,r=new Array(n),i=0;i<n;++i)for(var o,a=e[i],s=a.length,u=r[i]=[],l=0;l<s;++l)(o=a[l])&&t.call(o,o.__data__,l,a)&&u.push(o);return new Mn(r,this._parents,this._name,this._id)},merge:function(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,n=t._groups,r=e.length,i=n.length,o=Math.min(r,i),a=new Array(r),s=0;s<o;++s)for(var u,l=e[s],c=n[s],h=l.length,f=a[s]=new Array(h),p=0;p<h;++p)(u=l[p]||c[p])&&(f[p]=u);for(;s<r;++s)a[s]=e[s];return new Mn(a,this._parents,this._name,this._id)},selection:function(){return new kn(this._groups,this._parents)},transition:function(){for(var t=this._name,e=this._id,n=Cn(),r=this._groups,i=r.length,o=0;o<i;++o)for(var a,s=r[o],u=s.length,l=0;l<u;++l)if(a=s[l]){var c=sn(a,e);rn(a,t,n,l,s,{time:c.time+c.delay+c.duration,delay:0,duration:c.duration,ease:c.ease})}return new Mn(r,this._parents,t,n)},call:An.call,nodes:An.nodes,node:An.node,size:An.size,empty:An.empty,each:An.each,on:function(t,e){var n=this._id;return arguments.length<2\?sn(this.node(),n).on.on(t):this.each(function(t,e,n){var r,i,o=function(t){return(t+\"\").trim().split(/^|\\s+/).every((function(t){var e=t.indexOf(\".\");return e>=0&&(t=t.slice(0,e)),!t||\"start\"===t}))}(e)\?on:an;return function(){var a=o(this,t),s=a.on;s!==r&&(i=(r=s).copy()).on(e,n),a.on=i}}(n,t,e))},attr:function(t,e){var n=b(t),r=\"transform\"===n\?ze:fn;return this.attrTween(t,\"function\"==typeof e\?(n.local\?gn:vn)(n,r,hn(this,\"attr.\"+t,e)):null==e\?(n.local\?dn:pn)(n):(n.local\?yn:mn)(n,r,e))},attrTween:function(t,e){var n=\"attr.\"+t;if(arguments.length<2)return(n=this.tween(n))&&n._value;if(null==e)return this.tween(n,null);if(\"function\"!=typeof e)throw new Error;var r=b(t);return this.tween(n,(r.local\?_n:wn)(r,e))},style:function(t,e,n){var r=\"transform\"==(t+=\"\")\?Pe:fn;return null==e\?this.styleTween(t,function(t,e){var n,r,i;return function(){var o=J(this,t),a=(this.style.removeProperty(t),J(this,t));return o===a\?null:o===n&&a===r\?i:i=e(n=o,r=a)}}(t,r)).on(\"end.style.\"+t,Tn(t)):\"function\"==typeof e\?this.styleTween(t,function(t,e,n){var r,i,o;return function(){var a=J(this,t),s=n(this),u=s+\"\";return null==s&&(this.style.removeProperty(t),u=s=J(this,t)),a===u\?null:a===r&&u===i\?o:(i=u,o=e(r=a,s))}}(t,r,hn(this,\"style.\"+t,e))).each(function(t,e){var n,r,i,o,a=\"style.\"+e,s=\"end.\"+a;return function(){var u=an(this,t),l=u.on,c=null==u.value[a]\?o||(o=Tn(e)):void 0;l===n&&i===c||(r=(n=l).copy()).on(s,i=c),u.on=r}}(this._id,t)):this.styleTween(t,function(t,e,n){var r,i,o=n+\"\";return function(){var a=J(this,t);return a===o\?null:a===r\?i:i=e(r=a,n)}}(t,r,e),n).on(\"end.style.\"+t,null)},styleTween:function(t,e,n){var r=\"style.\"+(t+=\"\");if(arguments.length<2)return(r=this.tween(r))&&r._value;if(null==e)return this.tween(r,null);if(\"function\"!=typeof e)throw new Error;return this.tween(r,function(t,e,n){var r,i;function o(){var o=e.apply(this,arguments);return o!==i&&(r=(i=o)&&function(t,e,n){return function(r){this.style.setProperty(t,e.call(this,r),n)}}(t,o,n)),r}return o._value=e,o}(t,e,null==n\?\"\":n))},text:function(t){return this.tween(\"text\",\"function\"==typeof t\?function(t){return function(){var e=t(this);this.textContent=null==e\?\"\":e}}(hn(this,\"text\",t)):function(t){return function(){this.textContent=t}}(null==t\?\"\":t+\"\"))},textTween:function(t){var e=\"text\";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(null==t)return this.tween(e,null);if(\"function\"!=typeof t)throw new Error;return this.tween(e,function(t){var e,n;function r(){var r=t.apply(this,arguments);return r!==n&&(e=(n=r)&&function(t){return function(e){this.textContent=t.call(this,e)}}(r)),e}return r._value=t,r}(t))},remove:function(){return this.on(\"end.remove\",function(t){return function(){var e=this.parentNode;for(var n in this.__transition)if(+n!==t)return;e&&e.removeChild(this)}}(this._id))},tween:function(t,e){var n=this._id;if(t+=\"\",arguments.length<2){for(var r,i=sn(this.node(),n).tween,o=0,a=i.length;o<a;++o)if((r=i[o]).name===t)return r.value;return null}return this.each((null==e\?ln:cn)(n,t,e))},delay:function(t){var e=this._id;return arguments.length\?this.each((\"function\"==typeof t\?bn:xn)(e,t)):sn(this.node(),e).delay},duration:function(t){var e=this._id;return arguments.length\?this.each((\"function\"==typeof t\?Nn:En)(e,t)):sn(this.node(),e).duration},ease:function(t){var e=this._id;return arguments.length\?this.each(function(t,e){if(\"function\"!=typeof e)throw new Error;return function(){an(this,t).ease=e}}(e,t)):sn(this.node(),e).ease},easeVarying:function(t){if(\"function\"!=typeof t)throw new Error;return this.each(function(t,e){return function(){var n=e.apply(this,arguments);if(\"function\"!=typeof n)throw new Error;an(this,t).ease=n}}(this._id,t))},end:function(){var t,e,n=this,r=n._id,i=n.size();return new Promise((function(o,a){var s={value:a},u={value:function(){0==--i&&o()}};n.each((function(){var n=an(this,r),i=n.on;i!==t&&((e=(t=i).copy())._.cancel.push(s),e._.interrupt.push(s),e._.end.push(u)),n.on=e})),0===i&&o()}))},[Symbol.iterator]:An[Symbol.iterator]};var Sn={time:null,delay:0,duration:250,ease:function(t){return((t*=2)<=1\?t*t*t:(t-=2)*t*t+2)/2}};function Dn(t,e){for(var n;!(n=t.__transition)||!(n=n[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return n}At.prototype.interrupt=function(t){return this.each((function(){un(this,t)}))},At.prototype.transition=function(t){var e,n;t instanceof Mn\?(e=t._id,t=t._name):(e=Cn(),(n=Sn).time=He(),t=null==t\?null:t+\"\");for(var r=this._groups,i=r.length,o=0;o<i;++o)for(var a,s=r[o],u=s.length,l=0;l<u;++l)(a=s[l])&&rn(a,t,e,l,s,n||Dn(a,e));return new Mn(r,this._parents,t,e)};var Pn=t=>()=>t;function zn(t,{sourceEvent:e,target:n,transform:r,dispatch:i}){Object.defineProperties(this,{type:{value:t,enumerable:!0,configurable:!0},sourceEvent:{value:e,enumerable:!0,configurable:!0},target:{value:n,enumerable:!0,configurable:!0},transform:{value:r,enumerable:!0,configurable:!0},_:{value:i}})}function $n(t,e,n){this.k=t,this.x=e,this.y=n}$n.prototype={constructor:$n,scale:function(t){return 1===t\?this:new $n(this.k*t,this.x,this.y)},translate:function(t,e){return 0===t&0===e\?this:new $n(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return\"translate(\"+this.x+\",\"+this.y+\") scale(\"+this.k+\")\"}};var Ln=new $n(1,0,0);function Rn(t){t.stopImmediatePropagation()}function jn(t){t.preventDefault(),t.stopImmediatePropagation()}function In(t){return!(t.ctrlKey&&\"wheel\"!==t.type||t.button)}function Un(){var t=this;return t instanceof SVGElement\?(t=t.ownerSVGElement||t).hasAttribute(\"viewBox\")\?[[(t=t.viewBox.baseVal).x,t.y],[t.x+t.width,t.y+t.height]]:[[0,0],[t.width.baseVal.value,t.height.baseVal.value]]:[[0,0],[t.clientWidth,t.clientHeight]]}function Fn(){return this.__zoom||Ln}function Bn(t){return-t.deltaY*(1===t.deltaMode\?.05:t.deltaMode\?1:.002)*(t.ctrlKey\?10:1)}function Wn(){return navigator.maxTouchPoints||\"ontouchstart\"in this}function qn(t,e,n){var r=t.invertX(e[0][0])-n[0][0],i=t.invertX(e[1][0])-n[1][0],o=t.invertY(e[0][1])-n[0][1],a=t.invertY(e[1][1])-n[1][1];return t.translate(i>r\?(r+i)/2:Math.min(0,r)||Math.max(0,i),a>o\?(o+a)/2:Math.min(0,o)||Math.max(0,a))}function Vn(){var t,e,n,r=In,i=Un,o=qn,a=Bn,s=Wn,u=[0,1/0],l=[[-1/0,-1/0],[1/0,1/0]],c=250,h=je,f=zt(\"start\",\"zoom\",\"end\"),p=0,d=10;function m(t){t.property(\"__zoom\",Fn).on(\"wheel.zoom\",x,{passive:!1}).on(\"mousedown.zoom\",N).on(\"dblclick.zoom\",E).filter(s).on(\"touchstart.zoom\",k).on(\"touchmove.zoom\",T).on(\"touchend.zoom touchcancel.zoom\",O).style(\"-webkit-tap-highlight-color\",\"rgba(0,0,0,0)\")}function y(t,e){return(e=Math.max(u[0],Math.min(u[1],e)))===t.k\?t:new $n(e,t.x,t.y)}function v(t,e,n){var r=e[0]-n[0]*t.k,i=e[1]-n[1]*t.k;return r===t.x&&i===t.y\?t:new $n(t.k,r,i)}function g(t){return[(+t[0][0]+ +t[1][0])/2,(+t[0][1]+ +t[1][1])/2]}function _(t,e,n,r){t.on(\"start.zoom\",(function(){w(this,arguments).event(r).start()})).on(\"interrupt.zoom end.zoom\",(function(){w(this,arguments).event(r).end()})).tween(\"zoom\",(function(){var t=this,o=arguments,a=w(t,o).event(r),s=i.apply(t,o),u=null==n\?g(s):\"function\"==typeof n\?n.apply(t,o):n,l=Math.max(s[1][0]-s[0][0],s[1][1]-s[0][1]),c=t.__zoom,f=\"function\"==typeof e\?e.apply(t,o):e,p=h(c.invert(u).concat(l/c.k),f.invert(u).concat(l/f.k));return function(t){if(1===t)t=f;else{var e=p(t),n=l/e[2];t=new $n(n,u[0]-e[0]*n,u[1]-e[1]*n)}a.zoom(null,t)}}))}function w(t,e,n){return!n&&t.__zooming||new b(t,e)}function b(t,e){this.that=t,this.args=e,this.active=0,this.sourceEvent=null,this.extent=i.apply(t,e),this.taps=0}function x(t,...e){if(r.apply(this,arguments)){var n=w(this,e).event(t),i=this.__zoom,s=Math.max(u[0],Math.min(u[1],i.k*Math.pow(2,a.apply(this,arguments)))),c=Dt(t);if(n.wheel)n.mouse[0][0]===c[0]&&n.mouse[0][1]===c[1]||(n.mouse[1]=i.invert(n.mouse[0]=c)),clearTimeout(n.wheel);else{if(i.k===s)return;n.mouse=[c,i.invert(c)],un(this),n.start()}jn(t),n.wheel=setTimeout((function(){n.wheel=null,n.end()}),150),n.zoom(\"mouse\",o(v(y(i,s),n.mouse[0],n.mouse[1]),n.extent,l))}}function N(t,...e){if(!n&&r.apply(this,arguments)){var i=t.currentTarget,a=w(this,e,!0).event(t),s=St(t.view).on(\"mousemove.zoom\",(function(t){if(jn(t),!a.moved){var e=t.clientX-c,n=t.clientY-h;a.moved=e*e+n*n>p}a.event(t).zoom(\"mouse\",o(v(a.that.__zoom,a.mouse[0]=Dt(t,i),a.mouse[1]),a.extent,l))}),!0).on(\"mouseup.zoom\",(function(t){s.on(\"mousemove.zoom mouseup.zoom\",null),function(t,e){var n=t.document.documentElement,r=St(t).on(\"dragstart.drag\",null);e&&(r.on(\"click.drag\",It,jt),setTimeout((function(){r.on(\"click.drag\",null)}),0)),\"onselectstart\"in n\?r.on(\"selectstart.drag\",null):(n.style.MozUserSelect=n.__noselect,delete n.__noselect)}(t.view,a.moved),jn(t),a.event(t).end()}),!0),u=Dt(t,i),c=t.clientX,h=t.clientY;!function(t){var e=t.document.documentElement,n=St(t).on(\"dragstart.drag\",It,jt);\"onselectstart\"in e\?n.on(\"selectstart.drag\",It,jt):(e.__noselect=e.style.MozUserSelect,e.style.MozUserSelect=\"none\")}(t.view),Rn(t),a.mouse=[u,this.__zoom.invert(u)],un(this),a.start()}}function E(t,...e){if(r.apply(this,arguments)){var n=this.__zoom,a=Dt(t.changedTouches\?t.changedTouches[0]:t,this),s=n.invert(a),u=n.k*(t.shiftKey\?.5:2),h=o(v(y(n,u),a,s),i.apply(this,e),l);jn(t),c>0\?St(this).transition().duration(c).call(_,h,a,t):St(this).call(m.transform,h,a,t)}}function k(n,...i){if(r.apply(this,arguments)){var o,a,s,u,l=n.touches,c=l.length,h=w(this,i,n.changedTouches.length===c).event(n);for(Rn(n),a=0;a<c;++a)u=[u=Dt(s=l[a],this),this.__zoom.invert(u),s.identifier],h.touch0\?h.touch1||h.touch0[2]===u[2]||(h.touch1=u,h.taps=0):(h.touch0=u,o=!0,h.taps=1+!!t);t&&(t=clearTimeout(t)),o&&(h.taps<2&&(e=u[0],t=setTimeout((function(){t=null}),500)),un(this),h.start())}}function T(t,...e){if(this.__zooming){var n,r,i,a,s=w(this,e).event(t),u=t.changedTouches,c=u.length;for(jn(t),n=0;n<c;++n)i=Dt(r=u[n],this),s.touch0&&s.touch0[2]===r.identifier\?s.touch0[0]=i:s.touch1&&s.touch1[2]===r.identifier&&(s.touch1[0]=i);if(r=s.that.__zoom,s.touch1){var h=s.touch0[0],f=s.touch0[1],p=s.touch1[0],d=s.touch1[1],m=(m=p[0]-h[0])*m+(m=p[1]-h[1])*m,g=(g=d[0]-f[0])*g+(g=d[1]-f[1])*g;r=y(r,Math.sqrt(m/g)),i=[(h[0]+p[0])/2,(h[1]+p[1])/2],a=[(f[0]+d[0])/2,(f[1]+d[1])/2]}else{if(!s.touch0)return;i=s.touch0[0],a=s.touch0[1]}s.zoom(\"touch\",o(v(r,i,a),s.extent,l))}}function O(t,...r){if(this.__zooming){var i,o,a=w(this,r).event(t),s=t.changedTouches,u=s.length;for(Rn(t),n&&clearTimeout(n),n=setTimeout((function(){n=null}),500),i=0;i<u;++i)o=s[i],a.touch0&&a.touch0[2]===o.identifier\?delete a.touch0:a.touch1&&a.touch1[2]===o.identifier&&delete a.touch1;if(a.touch1&&!a.touch0&&(a.touch0=a.touch1,delete a.touch1),a.touch0)a.touch0[1]=this.__zoom.invert(a.touch0[0]);else if(a.end(),2===a.taps&&(o=Dt(o,this),Math.hypot(e[0]-o[0],e[1]-o[1])<d)){var l=St(this).on(\"dblclick.zoom\");l&&l.apply(this,arguments)}}}return m.transform=function(t,e,n,r){var i=t.selection\?t.selection():t;i.property(\"__zoom\",Fn),t!==i\?_(t,e,n,r):i.interrupt().each((function(){w(this,arguments).event(r).start().zoom(null,\"function\"==typeof e\?e.apply(this,arguments):e).end()}))},m.scaleBy=function(t,e,n,r){m.scaleTo(t,(function(){return this.__zoom.k*(\"function\"==typeof e\?e.apply(this,arguments):e)}),n,r)},m.scaleTo=function(t,e,n,r){m.transform(t,(function(){var t=i.apply(this,arguments),r=this.__zoom,a=null==n\?g(t):\"function\"==typeof n\?n.apply(this,arguments):n,s=r.invert(a),u=\"function\"==typeof e\?e.apply(this,arguments):e;return o(v(y(r,u),a,s),t,l)}),n,r)},m.translateBy=function(t,e,n,r){m.transform(t,(function(){return o(this.__zoom.translate(\"function\"==typeof e\?e.apply(this,arguments):e,\"function\"==typeof n\?n.apply(this,arguments):n),i.apply(this,arguments),l)}),null,r)},m.translateTo=function(t,e,n,r,a){m.transform(t,(function(){var t=i.apply(this,arguments),a=this.__zoom,s=null==r\?g(t):\"function\"==typeof r\?r.apply(this,arguments):r;return o(Ln.translate(s[0],s[1]).scale(a.k).translate(\"function\"==typeof e\?-e.apply(this,arguments):-e,\"function\"==typeof n\?-n.apply(this,arguments):-n),t,l)}),r,a)},b.prototype={event:function(t){return t&&(this.sourceEvent=t),this},start:function(){return 1==++this.active&&(this.that.__zooming=this,this.emit(\"start\")),this},zoom:function(t,e){return this.mouse&&\"mouse\"!==t&&(this.mouse[1]=e.invert(this.mouse[0])),this.touch0&&\"touch\"!==t&&(this.touch0[1]=e.invert(this.touch0[0])),this.touch1&&\"touch\"!==t&&(this.touch1[1]=e.invert(this.touch1[0])),this.that.__zoom=e,this.emit(\"zoom\"),this},end:function(){return 0==--this.active&&(delete this.that.__zooming,this.emit(\"end\")),this},emit:function(t){var e=St(this.that).datum();f.call(t,this.that,new zn(t,{sourceEvent:this.sourceEvent,target:m,transform:this.that.__zoom,dispatch:f}),e)}},m.wheelDelta=function(t){return arguments.length\?(a=\"function\"==typeof t\?t:Pn(+t),m):a},m.filter=function(t){return arguments.length\?(r=\"function\"==typeof t\?t:Pn(!!t),m):r},m.touchable=function(t){return arguments.length\?(s=\"function\"==typeof t\?t:Pn(!!t),m):s},m.extent=function(t){return arguments.length\?(i=\"function\"==typeof t\?t:Pn([[+t[0][0],+t[0][1]],[+t[1][0],+t[1][1]]]),m):i},m.scaleExtent=function(t){return arguments.length\?(u[0]=+t[0],u[1]=+t[1],m):[u[0],u[1]]},m.translateExtent=function(t){return arguments.length\?(l[0][0]=+t[0][0],l[1][0]=+t[1][0],l[0][1]=+t[0][1],l[1][1]=+t[1][1],m):[[l[0][0],l[0][1]],[l[1][0],l[1][1]]]},m.constrain=function(t){return arguments.length\?(o=t,m):o},m.duration=function(t){return arguments.length\?(c=+t,m):c},m.interpolate=function(t){return arguments.length\?(h=t,m):h},m.on=function(){var t=f.on.apply(f,arguments);return t===f\?m:t},m.clickDistance=function(t){return arguments.length\?(p=(t=+t)*t,m):Math.sqrt(p)},m.tapDistance=function(t){return arguments.length\?(d=+t,m):d},m}$n.prototype;var Xn=Object.prototype.hasOwnProperty;function Hn(t,e){var n,r;if(t===e)return!0;if(t&&e&&(n=t.constructor)===e.constructor){if(n===Date)return t.getTime()===e.getTime();if(n===RegExp)return t.toString()===e.toString();if(n===Array){if((r=t.length)===e.length)for(;r--&&Hn(t[r],e[r]););return-1===r}if(!n||\"object\"==typeof t){for(n in r=0,t){if(Xn.call(t,n)&&++r&&!Xn.call(e,n))return!1;if(!(n in e)||!Hn(t[n],e[n]))return!1}return Object.keys(e).length===r}}return t!=t&&e!=e}function Kn(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,\"default\")\?t.default:t}function Yn(t){if(Object.prototype.hasOwnProperty.call(t,\"__esModule\"))return t;var e=t.default;if(\"function\"==typeof e){var n=function t(){return this instanceof t\?Reflect.construct(e,arguments,this.constructor):e.apply(this,arguments)};n.prototype=e.prototype}else n={};return Object.defineProperty(n,\"__esModule\",{value:!0}),Object.keys(t).forEach((function(e){var r=Object.getOwnPropertyDescriptor(t,e);Object.defineProperty(n,e,r.get\?r:{enumerable:!0,get:function(){return t[e]}})})),n}var Gn,Qn={exports:{}};var Zn,Jn=(Gn||(Gn=1,function(t){var e=function(){function t(t,e){return null!=e&&t instanceof e}var e,n,r;try{e=Map}catch(t){e=function(){}}try{n=Set}catch(t){n=function(){}}try{r=Promise}catch(t){r=function(){}}function i(o,s,u,l,c){\"object\"==typeof s&&(u=s.depth,l=s.prototype,c=s.includeNonEnumerable,s=s.circular);var h=[],f=[],p=\"undefined\"!=typeof Buffer;return void 0===s&&(s=!0),void 0===u&&(u=1/0),function o(u,d){if(null===u)return null;if(0===d)return u;var m,y;if(\"object\"!=typeof u)return u;if(t(u,e))m=new e;else if(t(u,n))m=new n;else if(t(u,r))m=new r((function(t,e){u.then((function(e){t(o(e,d-1))}),(function(t){e(o(t,d-1))}))}));else if(i.__isArray(u))m=[];else if(i.__isRegExp(u))m=new RegExp(u.source,a(u)),u.lastIndex&&(m.lastIndex=u.lastIndex);else if(i.__isDate(u))m=new Date(u.getTime());else{if(p&&Buffer.isBuffer(u))return m=Buffer.allocUnsafe\?Buffer.allocUnsafe(u.length):new Buffer(u.length),u.copy(m),m;t(u,Error)\?m=Object.create(u):void 0===l\?(y=Object.getPrototypeOf(u),m=Object.create(y)):(m=Object.create(l),y=l)}if(s){var v=h.indexOf(u);if(-1!=v)return f[v];h.push(u),f.push(m)}for(var g in t(u,e)&&u.forEach((function(t,e){var n=o(e,d-1),r=o(t,d-1);m.set(n,r)})),t(u,n)&&u.forEach((function(t){var e=o(t,d-1);m.add(e)})),u){var _;y&&(_=Object.getOwnPropertyDescriptor(y,g)),_&&null==_.set||(m[g]=o(u[g],d-1))}if(Object.getOwnPropertySymbols){var w=Object.getOwnPropertySymbols(u);for(g=0;g<w.length;g++){var b=w[g];(!(N=Object.getOwnPropertyDescriptor(u,b))||N.enumerable||c)&&(m[b]=o(u[b],d-1),N.enumerable||Object.defineProperty(m,b,{enumerable:!1}))}}if(c){var x=Object.getOwnPropertyNames(u);for(g=0;g<x.length;g++){var N,E=x[g];(N=Object.getOwnPropertyDescriptor(u,E))&&N.enumerable||(m[E]=o(u[E],d-1),Object.defineProperty(m,E,{enumerable:!1}))}}return m}(o,u)}function o(t){return Object.prototype.toString.call(t)}function a(t){var e=\"\";return t.global&&(e+=\"g\"),t.ignoreCase&&(e+=\"i\"),t.multiline&&(e+=\"m\"),e}return i.clonePrototype=function(t){if(null===t)return null;var e=function(){};return e.prototype=t,new e},i.__objToStr=o,i.__isDate=function(t){return\"object\"==typeof t&&\"[object Date]\"===o(t)},i.__isArray=function(t){return\"object\"==typeof t&&\"[object Array]\"===o(t)},i.__isRegExp=function(t){return\"object\"==typeof t&&\"[object RegExp]\"===o(t)},i.__getRegExpFlags=a,i}();t.exports&&(t.exports=e)}(Qn)),Qn.exports),tr=Kn(Jn),er=new Uint8Array(16);function nr(){if(!Zn&&!(Zn=\"undefined\"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||\"undefined\"!=typeof msCrypto&&\"function\"==typeof msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto)))throw new Error(\"crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported\");return Zn(er)}var rr=/^(\?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;for(var ir=[],or=0;or<256;++or)ir.push((or+256).toString(16).substr(1));function ar(t){var e=arguments.length>1&&void 0!==arguments[1]\?arguments[1]:0,n=(ir[t[e+0]]+ir[t[e+1]]+ir[t[e+2]]+ir[t[e+3]]+\"-\"+ir[t[e+4]]+ir[t[e+5]]+\"-\"+ir[t[e+6]]+ir[t[e+7]]+\"-\"+ir[t[e+8]]+ir[t[e+9]]+\"-\"+ir[t[e+10]]+ir[t[e+11]]+ir[t[e+12]]+ir[t[e+13]]+ir[t[e+14]]+ir[t[e+15]]).toLowerCase();if(!function(t){return\"string\"==typeof t&&rr.test(t)}(n))throw TypeError(\"Stringified UUID is invalid\");return n}function sr(t,e,n){var r=(t=t||{}).random||(t.rng||nr)();return r[6]=15&r[6]|64,r[8]=63&r[8]|128,ar(r)}var ur,lr,cr,hr,fr,pr={exports:{}},dr={exports:{}};function mr(){if(lr)return ur;lr=1;return ur=\"SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED\"}function yr(){if(hr)return cr;hr=1;var t=mr();function e(){}function n(){}return n.resetWarningCache=e,cr=function(){function r(e,n,r,i,o,a){if(a!==t){var s=new Error(\"Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types\");throw s.name=\"Invariant Violation\",s}}function i(){return r}r.isRequired=r;var o={array:r,bigint:r,bool:r,func:r,number:r,object:r,string:r,symbol:r,any:r,arrayOf:i,element:r,elementType:r,instanceOf:i,node:r,objectOf:i,oneOf:i,oneOfType:i,shape:i,exact:i,checkPropTypes:n,resetWarningCache:e};return o.PropTypes=o,o}}function vr(){return fr||(fr=1,dr.exports=yr()()),dr.exports}var gr,_r,wr,br,xr={exports:{}};function Nr(){var t=this.constructor.getDerivedStateFromProps(this.props,this.state);null!=t&&this.setState(t)}function Er(t){this.setState(function(e){var n=this.constructor.getDerivedStateFromProps(t,e);return null!=n\?n:null}.bind(this))}function kr(t,e){try{var n=this.props,r=this.state;this.props=t,this.state=e,this.__reactInternalSnapshotFlag=!0,this.__reactInternalSnapshot=this.getSnapshotBeforeUpdate(n,r)}finally{this.props=n,this.state=r}}Nr.__suppressDeprecationWarning=!0,Er.__suppressDeprecationWarning=!0,kr.__suppressDeprecationWarning=!0;var Tr,Or,Mr=Yn(Object.freeze({__proto__:null,polyfill:function(t){var e=t.prototype;if(!e||!e.isReactComponent)throw new Error(\"Can only polyfill class components\");if(\"function\"!=typeof t.getDerivedStateFromProps&&\"function\"!=typeof e.getSnapshotBeforeUpdate)return t;var n=null,r=null,i=null;if(\"function\"==typeof e.componentWillMount\?n=\"componentWillMount\":\"function\"==typeof e.UNSAFE_componentWillMount&&(n=\"UNSAFE_componentWillMount\"),\"function\"==typeof e.componentWillReceiveProps\?r=\"componentWillReceiveProps\":\"function\"==typeof e.UNSAFE_componentWillReceiveProps&&(r=\"UNSAFE_componentWillReceiveProps\"),\"function\"==typeof e.componentWillUpdate\?i=\"componentWillUpdate\":\"function\"==typeof e.UNSAFE_componentWillUpdate&&(i=\"UNSAFE_componentWillUpdate\"),null!==n||null!==r||null!==i){var o=t.displayName||t.name,a=\"function\"==typeof t.getDerivedStateFromProps\?\"getDerivedStateFromProps()\":\"getSnapshotBeforeUpdate()\";throw Error(\"Unsafe legacy lifecycles will not be called for components using new component APIs.\\n\\n\"+o+\" uses \"+a+\" but also contains the following legacy lifecycles:\"+(null!==n\?\"\\n  \"+n:\"\")+(null!==r\?\"\\n  \"+r:\"\")+(null!==i\?\"\\n  \"+i:\"\")+\"\\n\\nThe above lifecycles should be removed. Learn more about this warning here:\\nhttps://fb.me/react-async-component-lifecycle-hooks\")}if(\"function\"==typeof t.getDerivedStateFromProps&&(e.componentWillMount=Nr,e.componentWillReceiveProps=Er),\"function\"==typeof e.getSnapshotBeforeUpdate){if(\"function\"!=typeof e.componentDidUpdate)throw new Error(\"Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype\");e.componentWillUpdate=kr;var s=e.componentDidUpdate;e.componentDidUpdate=function(t,e,n){var r=this.__reactInternalSnapshotFlag\?this.__reactInternalSnapshot:n;s.call(this,t,e,r)}}return t}})),Cr={};function Ar(){return Or||(Or=1,function(t,e){e.__esModule=!0;var n=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},i=(_r||(_r=1,gr=function(){for(var t=arguments.length,e=[],n=0;n<t;n++)e[n]=arguments[n];if(0!==(e=e.filter((function(t){return null!=t}))).length)return 1===e.length\?e[0]:e.reduce((function(t,e){return function(){t.apply(this,arguments),e.apply(this,arguments)}}))}),gr),o=c(i),a=c(r),s=c(vr());c(br\?wr:(br=1,wr=function(){}));var u=Mr,l=function(){if(Tr)return Cr;Tr=1,Cr.__esModule=!0,Cr.getChildMapping=function(e){if(!e)return e;var n={};return t.Children.map(e,(function(t){return t})).forEach((function(t){n[t.key]=t})),n},Cr.mergeChildMappings=function(t,e){function n(n){return e.hasOwnProperty(n)\?e[n]:t[n]}t=t||{},e=e||{};var r={},i=[];for(var o in t)e.hasOwnProperty(o)\?i.length&&(r[o]=i,i=[]):i.push(o);var a=void 0,s={};for(var u in e){if(r.hasOwnProperty(u))for(a=0;a<r[u].length;a++){var l=r[u][a];s[r[u][a]]=n(l)}s[u]=n(u)}for(a=0;a<i.length;a++)s[i[a]]=n(i[a]);return s};var t=r;return Cr}();function c(t){return t&&t.__esModule\?t:{default:t}}s.default.any,s.default.func,s.default.node;var h=function(t){function e(r,i){!function(t,e){if(!(t instanceof e))throw new TypeError(\"Cannot call a class as a function\")}(this,e);var o=function(t,e){if(!t)throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\");return!e||\"object\"!=typeof e&&\"function\"!=typeof e\?t:e}(this,t.call(this,r,i));return o.performAppear=function(t,e){o.currentlyTransitioningKeys[t]=!0,e.componentWillAppear\?e.componentWillAppear(o._handleDoneAppearing.bind(o,t,e)):o._handleDoneAppearing(t,e)},o._handleDoneAppearing=function(t,e){e&&e.componentDidAppear&&e.componentDidAppear(),delete o.currentlyTransitioningKeys[t];var n=(0,l.getChildMapping)(o.props.children);n&&n.hasOwnProperty(t)||o.performLeave(t,e)},o.performEnter=function(t,e){o.currentlyTransitioningKeys[t]=!0,e.componentWillEnter\?e.componentWillEnter(o._handleDoneEntering.bind(o,t,e)):o._handleDoneEntering(t,e)},o._handleDoneEntering=function(t,e){e&&e.componentDidEnter&&e.componentDidEnter(),delete o.currentlyTransitioningKeys[t];var n=(0,l.getChildMapping)(o.props.children);n&&n.hasOwnProperty(t)||o.performLeave(t,e)},o.performLeave=function(t,e){o.currentlyTransitioningKeys[t]=!0,e&&e.componentWillLeave\?e.componentWillLeave(o._handleDoneLeaving.bind(o,t,e)):o._handleDoneLeaving(t,e)},o._handleDoneLeaving=function(t,e){e&&e.componentDidLeave&&e.componentDidLeave(),delete o.currentlyTransitioningKeys[t];var r=(0,l.getChildMapping)(o.props.children);r&&r.hasOwnProperty(t)\?o.keysToEnter.push(t):o.setState((function(e){var r=n({},e.children);return delete r[t],{children:r}}))},o.childRefs=Object.create(null),o.currentlyTransitioningKeys={},o.keysToEnter=[],o.keysToLeave=[],o.state={children:(0,l.getChildMapping)(r.children)},o}return function(t,e){if(\"function\"!=typeof e&&null!==e)throw new TypeError(\"Super expression must either be null or a function, not \"+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf\?Object.setPrototypeOf(t,e):t.__proto__=e)}(e,t),e.prototype.componentDidMount=function(){var t=this.state.children;for(var e in t)t[e]&&this.performAppear(e,this.childRefs[e])},e.getDerivedStateFromProps=function(t,e){var n=(0,l.getChildMapping)(t.children),r=e.children;return{children:(0,l.mergeChildMappings)(r,n)}},e.prototype.componentDidUpdate=function(t,e){var n=this,r=(0,l.getChildMapping)(this.props.children),i=e.children;for(var o in r){var a=i&&i.hasOwnProperty(o);!r[o]||a||this.currentlyTransitioningKeys[o]||this.keysToEnter.push(o)}for(var s in i){var u=r&&r.hasOwnProperty(s);!i[s]||u||this.currentlyTransitioningKeys[s]||this.keysToLeave.push(s)}var c=this.keysToEnter;this.keysToEnter=[],c.forEach((function(t){return n.performEnter(t,n.childRefs[t])}));var h=this.keysToLeave;this.keysToLeave=[],h.forEach((function(t){return n.performLeave(t,n.childRefs[t])}))},e.prototype.render=function(){var t=this,e=[],r=function(n){var r=t.state.children[n];if(r){var i=\"string\"!=typeof r.ref,s=t.props.childFactory(r),u=function(e){t.childRefs[n]=e};s===r&&i&&(u=(0,o.default)(r.ref,u)),e.push(a.default.cloneElement(s,{key:n,ref:u}))}};for(var i in this.state.children)r(i);var s=n({},this.props);return delete s.transitionLeave,delete s.transitionName,delete s.transitionAppear,delete s.transitionEnter,delete s.childFactory,delete s.transitionLeaveTimeout,delete s.transitionEnterTimeout,delete s.transitionAppearTimeout,delete s.component,a.default.createElement(this.props.component,s,e)},e}(a.default.Component);h.displayName=\"TransitionGroup\",h.propTypes={},h.defaultProps={component:\"span\",childFactory:function(t){return t}},e.default=(0,u.polyfill)(h),t.exports=e.default}(xr,xr.exports)),xr.exports}var Sr,Dr={exports:{}},Pr={exports:{}},zr={exports:{}};function $r(){return Sr||(Sr=1,(t=zr).exports=function(t){return t&&t.__esModule\?t:{default:t}},t.exports.__esModule=!0,t.exports.default=t.exports),zr.exports;var t}var Lr,Rr,jr,Ir,Ur={exports:{}};function Fr(){return Rr||(Rr=1,function(t,e){var n=$r();e.__esModule=!0,e.default=function(t,e){t.classList\?t.classList.add(e):(0,r.default)(t,e)||(\"string\"==typeof t.className\?t.className=t.className+\" \"+e:t.setAttribute(\"class\",(t.className&&t.className.baseVal||\"\")+\" \"+e))};var r=n(function(){return Lr||(Lr=1,t=Ur,(e=Ur.exports).__esModule=!0,e.default=function(t,e){return t.classList\?!!e&&t.classList.contains(e):-1!==(\" \"+(t.className.baseVal||t.className)+\" \").indexOf(\" \"+e+\" \")},t.exports=e.default),Ur.exports;var t,e}());t.exports=e.default}(Pr,Pr.exports)),Pr.exports}var Br,Wr,qr={exports:{}},Vr={exports:{}};function Xr(){return Br||(Br=1,function(t,e){e.__esModule=!0,e.default=void 0;var n=!(!window.document||!window.document.createElement);e.default=n,t.exports=e.default}(Vr,Vr.exports)),Vr.exports}var Hr,Kr={};var Yr,Gr,Qr,Zr,Jr,ti={};function ei(){if(Yr)return ti;Yr=1,ti.__esModule=!0,ti.nameShape=void 0,ti.transitionTimeout=function(t){var e=\"transition\"+t+\"Timeout\",n=\"transition\"+t;return function(t){if(t[n]){if(null==t[e])return new Error(e+\" wasn't supplied to CSSTransitionGroup: this can cause unreliable animations and won't be supported in a future version of React. See https://fb.me/react-animation-transition-group-timeout for more information.\");if(\"number\"!=typeof t[e])return new Error(e+\" must be a number (in milliseconds)\")}return null}},e(r);var t=e(vr());function e(t){return t&&t.__esModule\?t:{default:t}}return ti.nameShape=t.default.oneOfType([t.default.string,t.default.shape({enter:t.default.string,leave:t.default.string,active:t.default.string}),t.default.shape({enter:t.default.string,enterActive:t.default.string,leave:t.default.string,leaveActive:t.default.string,appear:t.default.string,appearActive:t.default.string})]),ti}function ni(){return Gr||(Gr=1,function(t,e){e.__esModule=!0;var n=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=d(Fr()),a=d(function(){if(Ir)return jr;function t(t,e){return t.replace(new RegExp(\"(^|\\\\s)\"+e+\"(\?:\\\\s|$)\",\"g\"),\"$1\").replace(/\\s+/g,\" \").replace(/^\\s*|\\s*$/g,\"\")}return Ir=1,jr=function(e,n){e.classList\?e.classList.remove(n):\"string\"==typeof e.className\?e.className=t(e.className,n):e.setAttribute(\"class\",t(e.className&&e.className.baseVal||\"\",n))}}()),s=(Wr||(Wr=1,function(t,e){var n=$r();e.__esModule=!0,e.default=void 0;var r,i=n(Xr()),o=\"clearTimeout\",a=function(t){var e=(new Date).getTime(),n=Math.max(0,16-(e-u)),r=setTimeout(t,n);return u=e,r},s=function(t,e){return t+(t\?e[0].toUpperCase()+e.substr(1):e)+\"AnimationFrame\"};i.default&&[\"\",\"webkit\",\"moz\",\"o\",\"ms\"].some((function(t){var e=s(t,\"request\");if(e in window)return o=s(t,\"cancel\"),a=function(t){return window[e](t)}}));var u=(new Date).getTime();(r=function(t){return a(t)}).cancel=function(t){window[o]&&\"function\"===\"object\"[o]&&window[o](t)};var l=r;e.default=l,t.exports=e.default}(qr,qr.exports)),qr.exports),u=d(s),l=function(){if(Hr)return Kr;Hr=1;var t=$r();Kr.__esModule=!0,Kr.default=Kr.animationEnd=Kr.animationDelay=Kr.animationTiming=Kr.animationDuration=Kr.animationName=Kr.transitionEnd=Kr.transitionDuration=Kr.transitionDelay=Kr.transitionTiming=Kr.transitionProperty=Kr.transform=void 0;var e,n,r,i,o,a,s,u,l,c,h,f=t(Xr()),p=\"transform\";if(Kr.transform=p,Kr.animationEnd=r,Kr.transitionEnd=n,Kr.transitionDelay=s,Kr.transitionTiming=a,Kr.transitionDuration=o,Kr.transitionProperty=i,Kr.animationDelay=h,Kr.animationTiming=c,Kr.animationDuration=l,Kr.animationName=u,f.default){var d=function(){for(var t,e,n=document.createElement(\"div\").style,r={O:function(t){return\"o\"+t.toLowerCase()},Moz:function(t){return t.toLowerCase()},Webkit:function(t){return\"webkit\"+t},ms:function(t){return\"MS\"+t}},i=Object.keys(r),o=\"\",a=0;a<i.length;a++){var s=i[a];if(s+\"TransitionProperty\"in n){o=\"-\"+s.toLowerCase(),t=r[s](\"TransitionEnd\"),e=r[s](\"AnimationEnd\");break}}return!t&&\"transitionProperty\"in n&&(t=\"transitionend\"),!e&&\"animationName\"in n&&(e=\"animationend\"),n=null,{animationEnd:e,transitionEnd:t,prefix:o}}();e=d.prefix,Kr.transitionEnd=n=d.transitionEnd,Kr.animationEnd=r=d.animationEnd,Kr.transform=p=e+\"-\"+p,Kr.transitionProperty=i=e+\"-transition-property\",Kr.transitionDuration=o=e+\"-transition-duration\",Kr.transitionDelay=s=e+\"-transition-delay\",Kr.transitionTiming=a=e+\"-transition-timing-function\",Kr.animationName=u=e+\"-animation-name\",Kr.animationDuration=l=e+\"-animation-duration\",Kr.animationTiming=c=e+\"-animation-delay\",Kr.animationDelay=h=e+\"-animation-timing-function\"}var m={transform:p,end:n,property:i,timing:a,delay:s,duration:o};return Kr.default=m,Kr}(),c=d(r),h=d(vr()),f=i,p=ei();function d(t){return t&&t.__esModule\?t:{default:t}}var m=[];l.transitionEnd&&m.push(l.transitionEnd),l.animationEnd&&m.push(l.animationEnd),h.default.node,p.nameShape.isRequired,h.default.bool,h.default.bool,h.default.bool,h.default.number,h.default.number,h.default.number;var y=function(t){function e(n,r){!function(t,e){if(!(t instanceof e))throw new TypeError(\"Cannot call a class as a function\")}(this,e);var i=function(t,e){if(!t)throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\");return!e||\"object\"!=typeof e&&\"function\"!=typeof e\?t:e}(this,t.call(this,n,r));return i.componentWillAppear=function(t){i.props.appear\?i.transition(\"appear\",t,i.props.appearTimeout):t()},i.componentWillEnter=function(t){i.props.enter\?i.transition(\"enter\",t,i.props.enterTimeout):t()},i.componentWillLeave=function(t){i.props.leave\?i.transition(\"leave\",t,i.props.leaveTimeout):t()},i.classNameAndNodeQueue=[],i.transitionTimeouts=[],i}return function(t,e){if(\"function\"!=typeof e&&null!==e)throw new TypeError(\"Super expression must either be null or a function, not \"+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf\?Object.setPrototypeOf(t,e):t.__proto__=e)}(e,t),e.prototype.componentWillUnmount=function(){this.unmounted=!0,this.timeout&&clearTimeout(this.timeout),this.transitionTimeouts.forEach((function(t){clearTimeout(t)})),this.classNameAndNodeQueue.length=0},e.prototype.transition=function(t,e,n){var r=(0,f.findDOMNode)(this);if(r){var i=this.props.name[t]||this.props.name+\"-\"+t,s=this.props.name[t+\"Active\"]||i+\"-active\",u=null,c=void 0;(0,o.default)(r,i),this.queueClassAndNode(s,r);var h=function(t){t&&t.target!==r||(clearTimeout(u),c&&c(),(0,a.default)(r,i),(0,a.default)(r,s),c&&c(),e&&e())};n\?(u=setTimeout(h,n),this.transitionTimeouts.push(u)):l.transitionEnd&&(c=function(t,e){return m.length\?m.forEach((function(n){return t.addEventListener(n,e,!1)})):setTimeout(e,0),function(){m.length&&m.forEach((function(n){return t.removeEventListener(n,e,!1)}))}}(r,h))}else e&&e()},e.prototype.queueClassAndNode=function(t,e){var n=this;this.classNameAndNodeQueue.push({className:t,node:e}),this.rafHandle||(this.rafHandle=(0,u.default)((function(){return n.flushClassNameAndNodeQueue()})))},e.prototype.flushClassNameAndNodeQueue=function(){this.unmounted||this.classNameAndNodeQueue.forEach((function(t){t.node.scrollTop,(0,o.default)(t.node,t.className)})),this.classNameAndNodeQueue.length=0,this.rafHandle=null},e.prototype.render=function(){var t=n({},this.props);return delete t.name,delete t.appear,delete t.enter,delete t.leave,delete t.appearTimeout,delete t.enterTimeout,delete t.leaveTimeout,delete t.children,c.default.cloneElement(c.default.Children.only(this.props.children),t)},e}(c.default.Component);y.displayName=\"CSSTransitionGroupChild\",y.propTypes={},e.default=y,t.exports=e.default}(Dr,Dr.exports)),Dr.exports}function ri(){return Qr||(Qr=1,function(t,e){e.__esModule=!0;var n=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},i=l(r),o=l(vr()),a=l(Ar()),s=l(ni()),u=ei();function l(t){return t&&t.__esModule\?t:{default:t}}function c(t,e){if(!t)throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\");return!e||\"object\"!=typeof e&&\"function\"!=typeof e\?t:e}u.nameShape.isRequired,o.default.bool,o.default.bool,o.default.bool,(0,u.transitionTimeout)(\"Appear\"),(0,u.transitionTimeout)(\"Enter\"),(0,u.transitionTimeout)(\"Leave\");var h=function(t){function e(){var n,r;!function(t,e){if(!(t instanceof e))throw new TypeError(\"Cannot call a class as a function\")}(this,e);for(var o=arguments.length,a=Array(o),u=0;u<o;u++)a[u]=arguments[u];return n=r=c(this,t.call.apply(t,[this].concat(a))),r._wrapChild=function(t){return i.default.createElement(s.default,{name:r.props.transitionName,appear:r.props.transitionAppear,enter:r.props.transitionEnter,leave:r.props.transitionLeave,appearTimeout:r.props.transitionAppearTimeout,enterTimeout:r.props.transitionEnterTimeout,leaveTimeout:r.props.transitionLeaveTimeout},t)},c(r,n)}return function(t,e){if(\"function\"!=typeof e&&null!==e)throw new TypeError(\"Super expression must either be null or a function, not \"+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf\?Object.setPrototypeOf(t,e):t.__proto__=e)}(e,t),e.prototype.render=function(){return i.default.createElement(a.default,n({},this.props,{childFactory:this._wrapChild}))},e}(i.default.Component);h.displayName=\"CSSTransitionGroup\",h.propTypes={},h.defaultProps={transitionAppear:!1,transitionEnter:!0,transitionLeave:!0},e.default=h,t.exports=e.default}(pr,pr.exports)),pr.exports}var ii=function(){if(Jr)return Zr;Jr=1;var t=n(ri()),e=n(Ar());function n(t){return t&&t.__esModule\?t:{default:t}}return Zr={TransitionGroup:e.default,CSSTransitionGroup:t.default}}();const oi=t=>t.enableLegacyTransitions\?r.createElement(ii.TransitionGroup,{component:t.component,className:t.className,transform:t.transform},t.children):r.createElement(\"g\",{className:t.className,transform:t.transform},t.children),ai={textAnchor:\"start\",x:40},si={x:40,dy:\"1.2em\"},ui=({nodeDatum:t,toggleNode:e,onNodeClick:n,onNodeMouseOver:i,onNodeMouseOut:o})=>r.createElement(r.Fragment,null,r.createElement(\"circle\",{r:15,onClick:t=>{e(),n(t)},onMouseOver:i,onMouseOut:o}),r.createElement(\"g\",{className:\"rd3t-label\"},r.createElement(\"text\",Object.assign({className:\"rd3t-label__title\"},ai),t.name),r.createElement(\"text\",{className:\"rd3t-label__attributes\"},t.attributes&&Object.entries(t.attributes).map((([t,e],n)=>r.createElement(\"tspan\",Object.assign({key:`${t}-${n}`},si),t,\": \",\"boolean\"==typeof e\?e.toString():e))))));class li extends r.Component{constructor(){super(...arguments),this.nodeRef=null,this.state={transform:this.setTransform(this.props.position,this.props.parent,this.props.orientation,!0),initialStyle:{opacity:0},wasClicked:!1},this.shouldNodeTransform=(t,e,n,r)=>e.subscriptions!==t.subscriptions||e.position.x!==t.position.x||e.position.y!==t.position.y||e.orientation!==t.orientation||r.wasClicked!==n.wasClicked,this.renderNodeElement=()=>{const{data:t,hierarchyPointNode:e,renderCustomNodeElement:n}=this.props;return(\"function\"==typeof n\?n:ui)({hierarchyPointNode:e,nodeDatum:t,toggleNode:this.handleNodeToggle,onNodeClick:this.handleOnClick,onNodeMouseOver:this.handleOnMouseOver,onNodeMouseOut:this.handleOnMouseOut,addChildren:this.handleAddChildren})},this.handleNodeToggle=()=>{this.setState({wasClicked:!0}),this.props.onNodeToggle(this.props.data.__rd3t.id)},this.handleOnClick=t=>{this.setState({wasClicked:!0}),this.props.onNodeClick(this.props.hierarchyPointNode,t)},this.handleOnMouseOver=t=>{this.props.onNodeMouseOver(this.props.hierarchyPointNode,t)},this.handleOnMouseOut=t=>{this.props.onNodeMouseOut(this.props.hierarchyPointNode,t)},this.handleAddChildren=t=>{this.props.handleAddChildrenToNode(this.props.data.__rd3t.id,t)}}componentDidMount(){this.commitTransform()}componentDidUpdate(){this.state.wasClicked&&(this.props.centerNode(this.props.hierarchyPointNode),this.setState({wasClicked:!1})),this.commitTransform()}shouldComponentUpdate(t,e){return this.shouldNodeTransform(this.props,t,this.state,e)}setTransform(t,e,n,r=!1){if(r){const t=null!=e,r=t\?e.x:0,i=t\?e.y:0;return\"horizontal\"===n\?`translate(${i},${r})`:`translate(${r},${i})`}return\"horizontal\"===n\?`translate(${t.y},${t.x})`:`translate(${t.x},${t.y})`}applyTransform(t,e,n=1,r=()=>{}){this.props.enableLegacyTransitions\?St(this.nodeRef).transition().duration(e).attr(\"transform\",t).style(\"opacity\",n).on(\"end\",r):(St(this.nodeRef).attr(\"transform\",t).style(\"opacity\",n),r())}commitTransform(){const{orientation:t,transitionDuration:e,position:n,parent:r}=this.props,i=this.setTransform(n,r,t);this.applyTransform(i,e)}componentWillLeave(t){const{orientation:e,transitionDuration:n,position:r,parent:i}=this.props,o=this.setTransform(r,i,e,!0);this.applyTransform(o,n,0,t)}render(){const{data:t,nodeClassName:e}=this.props;return r.createElement(\"g\",{id:t.__rd3t.id,ref:t=>{this.nodeRef=t},style:this.state.initialStyle,className:[t.children&&t.children.length>0\?\"rd3t-node\":\"rd3t-leaf-node\",e].join(\" \").trim(),transform:this.state.transform},this.renderNodeElement())}}var ci=Math.PI,hi=2*ci,fi=1e-6,pi=hi-fi;function di(){this._x0=this._y0=this._x1=this._y1=null,this._=\"\"}function mi(){return new di}function yi(t){return function(){return t}}function vi(t){return t[0]}function gi(t){return t[1]}di.prototype=mi.prototype={constructor:di,moveTo:function(t,e){this._+=\"M\"+(this._x0=this._x1=+t)+\",\"+(this._y0=this._y1=+e)},closePath:function(){null!==this._x1&&(this._x1=this._x0,this._y1=this._y0,this._+=\"Z\")},lineTo:function(t,e){this._+=\"L\"+(this._x1=+t)+\",\"+(this._y1=+e)},quadraticCurveTo:function(t,e,n,r){this._+=\"Q\"+ +t+\",\"+ +e+\",\"+(this._x1=+n)+\",\"+(this._y1=+r)},bezierCurveTo:function(t,e,n,r,i,o){this._+=\"C\"+ +t+\",\"+ +e+\",\"+ +n+\",\"+ +r+\",\"+(this._x1=+i)+\",\"+(this._y1=+o)},arcTo:function(t,e,n,r,i){t=+t,e=+e,n=+n,r=+r,i=+i;var o=this._x1,a=this._y1,s=n-t,u=r-e,l=o-t,c=a-e,h=l*l+c*c;if(i<0)throw new Error(\"negative radius: \"+i);if(null===this._x1)this._+=\"M\"+(this._x1=t)+\",\"+(this._y1=e);else if(h>fi)if(Math.abs(c*s-u*l)>fi&&i){var f=n-o,p=r-a,d=s*s+u*u,m=f*f+p*p,y=Math.sqrt(d),v=Math.sqrt(h),g=i*Math.tan((ci-Math.acos((d+h-m)/(2*y*v)))/2),_=g/v,w=g/y;Math.abs(_-1)>fi&&(this._+=\"L\"+(t+_*l)+\",\"+(e+_*c)),this._+=\"A\"+i+\",\"+i+\",0,0,\"+ +(c*f>l*p)+\",\"+(this._x1=t+w*s)+\",\"+(this._y1=e+w*u)}else this._+=\"L\"+(this._x1=t)+\",\"+(this._y1=e);else;},arc:function(t,e,n,r,i,o){t=+t,e=+e,o=!!o;var a=(n=+n)*Math.cos(r),s=n*Math.sin(r),u=t+a,l=e+s,c=1^o,h=o\?r-i:i-r;if(n<0)throw new Error(\"negative radius: \"+n);null===this._x1\?this._+=\"M\"+u+\",\"+l:(Math.abs(this._x1-u)>fi||Math.abs(this._y1-l)>fi)&&(this._+=\"L\"+u+\",\"+l),n&&(h<0&&(h=h%hi+hi),h>pi\?this._+=\"A\"+n+\",\"+n+\",0,1,\"+c+\",\"+(t-a)+\",\"+(e-s)+\"A\"+n+\",\"+n+\",0,1,\"+c+\",\"+(this._x1=u)+\",\"+(this._y1=l):h>fi&&(this._+=\"A\"+n+\",\"+n+\",0,\"+ +(h>=ci)+\",\"+c+\",\"+(this._x1=t+n*Math.cos(i))+\",\"+(this._y1=e+n*Math.sin(i))))},rect:function(t,e,n,r){this._+=\"M\"+(this._x0=this._x1=+t)+\",\"+(this._y0=this._y1=+e)+\"h\"+ +n+\"v\"+ +r+\"h\"+-n+\"Z\"},toString:function(){return this._}};var _i=Array.prototype.slice;function wi(t){return t.source}function bi(t){return t.target}function xi(t){var e=wi,n=bi,r=vi,i=gi,o=null;function a(){var a,s=_i.call(arguments),u=e.apply(this,s),l=n.apply(this,s);if(o||(o=a=mi()),t(o,+r.apply(this,(s[0]=u,s)),+i.apply(this,s),+r.apply(this,(s[0]=l,s)),+i.apply(this,s)),a)return o=null,a+\"\"||null}return a.source=function(t){return arguments.length\?(e=t,a):e},a.target=function(t){return arguments.length\?(n=t,a):n},a.x=function(t){return arguments.length\?(r=\"function\"==typeof t\?t:yi(+t),a):r},a.y=function(t){return arguments.length\?(i=\"function\"==typeof t\?t:yi(+t),a):i},a.context=function(t){return arguments.length\?(o=null==t\?null:t,a):o},a}function Ni(t,e,n,r,i){t.moveTo(e,n),t.bezierCurveTo(e=(e+r)/2,n,e,i,r,i)}function Ei(t,e,n,r,i){t.moveTo(e,n),t.bezierCurveTo(e,n=(n+i)/2,r,n,r,i)}class ki extends r.PureComponent{constructor(){super(...arguments),this.linkRef=null,this.state={initialStyle:{opacity:0}},this.handleOnClick=t=>{this.props.onClick(this.props.linkData.source,this.props.linkData.target,t)},this.handleOnMouseOver=t=>{this.props.onMouseOver(this.props.linkData.source,this.props.linkData.target,t)},this.handleOnMouseOut=t=>{this.props.onMouseOut(this.props.linkData.source,this.props.linkData.target,t)}}componentDidMount(){this.applyOpacity(1,this.props.transitionDuration)}componentWillLeave(t){this.applyOpacity(0,this.props.transitionDuration,t)}applyOpacity(t,e,n=()=>{}){this.props.enableLegacyTransitions\?St(this.linkRef).transition().duration(e).style(\"opacity\",t).on(\"end\",n):(St(this.linkRef).style(\"opacity\",t),n())}drawStepPath(t,e){const{source:n,target:r}=t,i=r.y-n.y;return\"horizontal\"===e\?`M${n.y},${n.x} H${n.y+i/2} V${r.x} H${r.y}`:`M${n.x},${n.y} V${n.y+i/2} H${r.x} V${r.y}`}drawDiagonalPath(t,e){const{source:n,target:r}=t;return\"horizontal\"===e\?xi(Ni)({source:[n.y,n.x],target:[r.y,r.x]}):xi(Ei)({source:[n.x,n.y],target:[r.x,r.y]})}drawStraightPath(t,e){const{source:n,target:r}=t;return\"horizontal\"===e\?`M${n.y},${n.x}L${r.y},${r.x}`:`M${n.x},${n.y}L${r.x},${r.y}`}drawElbowPath(t,e){return\"horizontal\"===e\?`M${t.source.y},${t.source.x}V${t.target.x}H${t.target.y}`:`M${t.source.x},${t.source.y}V${t.target.y}H${t.target.x}`}drawPath(){const{linkData:t,orientation:e,pathFunc:n}=this.props;return\"function\"==typeof n\?n(t,e):\"elbow\"===n\?this.drawElbowPath(t,e):\"straight\"===n\?this.drawStraightPath(t,e):\"step\"===n\?this.drawStepPath(t,e):this.drawDiagonalPath(t,e)}getClassNames(){const{linkData:t,orientation:e,pathClassFunc:n}=this.props,r=[\"rd3t-link\"];return\"function\"==typeof n&&r.push(n(t,e)),r.join(\" \").trim()}render(){const{linkData:t}=this.props;return r.createElement(\"path\",{ref:t=>{this.linkRef=t},style:Object.assign({},this.state.initialStyle),className:this.getClassNames(),d:this.drawPath(),onClick:this.handleOnClick,onMouseOver:this.handleOnMouseOver,onMouseOut:this.handleOnMouseOut,\"data-source-id\":t.source.id,\"data-target-id\":t.target.id})}}class Ti extends r.Component{constructor(){super(...arguments),this.state={dataRef:this.props.data,data:Ti.assignInternalProperties(tr(this.props.data)),d3:Ti.calculateD3Geometry(this.props),isTransitioning:!1,isInitialRenderForDataset:!0,dataKey:this.props.dataKey},this.internalState={targetNode:null,isTransitioning:!1},this.svgInstanceRef=`rd3t-svg-${sr()}`,this.gInstanceRef=`rd3t-g-${sr()}`,this.handleNodeToggle=t=>{const e=tr(this.state.data),n=this.findNodesById(t,e,[])[0];this.props.collapsible&&!this.state.isTransitioning&&(n.__rd3t.collapsed\?(Ti.expandNode(n),this.props.shouldCollapseNeighborNodes&&this.collapseNeighborNodes(n,e)):Ti.collapseNode(n),this.props.enableLegacyTransitions\?(this.setState({data:e,isTransitioning:!0}),setTimeout((()=>this.setState({isTransitioning:!1})),this.props.transitionDuration+10)):this.setState({data:e}),this.internalState.targetNode=n)},this.handleAddChildrenToNode=(t,e)=>{const n=tr(this.state.data),r=this.findNodesById(t,n,[]);if(r.length>0){const t=r[0],i=t.__rd3t.depth,o=tr(e).map((t=>Ti.assignInternalProperties([t],i+1)));t.children.push(...o.flat()),this.setState({data:n})}},this.handleOnNodeClickCb=(t,e)=>{const{onNodeClick:n}=this.props;n&&\"function\"==typeof n&&(e.persist(),n(tr(t),e))},this.handleOnLinkClickCb=(t,e,n)=>{const{onLinkClick:r}=this.props;r&&\"function\"==typeof r&&(n.persist(),r(tr(t),tr(e),n))},this.handleOnNodeMouseOverCb=(t,e)=>{const{onNodeMouseOver:n}=this.props;n&&\"function\"==typeof n&&(e.persist(),n(tr(t),e))},this.handleOnLinkMouseOverCb=(t,e,n)=>{const{onLinkMouseOver:r}=this.props;r&&\"function\"==typeof r&&(n.persist(),r(tr(t),tr(e),n))},this.handleOnNodeMouseOutCb=(t,e)=>{const{onNodeMouseOut:n}=this.props;n&&\"function\"==typeof n&&(e.persist(),n(tr(t),e))},this.handleOnLinkMouseOutCb=(t,e,n)=>{const{onLinkMouseOut:r}=this.props;r&&\"function\"==typeof r&&(n.persist(),r(tr(t),tr(e),n))},this.centerNode=t=>{const{dimensions:e,orientation:n,zoom:r,centeringTransitionDuration:i}=this.props;if(e){const o=St(`.${this.gInstanceRef}`),a=St(`.${this.svgInstanceRef}`),s=this.state.d3.scale;let u,l;\"horizontal\"===n\?(l=-t.x*s+e.height/2,u=-t.y*s+e.width/2):(u=-t.x*s+e.width/2,l=-t.y*s+e.height/2),o.transition().duration(i).attr(\"transform\",\"translate(\"+u+\",\"+l+\")scale(\"+s+\")\"),a.call(Vn().transform,Ln.translate(u,l).scale(r))}},this.getNodeClassName=(t,e)=>{const{rootNodeClassName:n,branchNodeClassName:r,leafNodeClassName:i}=this.props;return null!=t\?e.children\?r:i:n}}static getDerivedStateFromProps(t,e){let n=null;const r=!t.dataKey||e.dataKey!==t.dataKey;t.data!==e.dataRef&&r&&(n={dataRef:t.data,data:Ti.assignInternalProperties(tr(t.data)),isInitialRenderForDataset:!0,dataKey:t.dataKey});const i=Ti.calculateD3Geometry(t);return Hn(i,e.d3)||(n=n||{},n.d3=i),n}componentDidMount(){this.bindZoomListener(this.props),this.setState({isInitialRenderForDataset:!1})}componentDidUpdate(t){this.props.data!==t.data&&this.setState({isInitialRenderForDataset:!1}),Hn(this.props.translate,t.translate)&&Hn(this.props.scaleExtent,t.scaleExtent)&&this.props.zoomable===t.zoomable&&this.props.draggable===t.draggable&&this.props.zoom===t.zoom&&this.props.enableLegacyTransitions===t.enableLegacyTransitions||this.bindZoomListener(this.props),\"function\"==typeof this.props.onUpdate&&this.props.onUpdate({node:this.internalState.targetNode\?tr(this.internalState.targetNode):null,zoom:this.state.d3.scale,translate:this.state.d3.translate}),this.internalState.targetNode=null}setInitialTreeDepth(t,e){t.forEach((t=>{t.data.__rd3t.collapsed=t.depth>=e}))}bindZoomListener(t){const{zoomable:e,scaleExtent:n,translate:r,zoom:i,onUpdate:o,hasInteractiveNodes:a}=t,s=St(`.${this.svgInstanceRef}`),u=St(`.${this.gInstanceRef}`);s.call(Vn().transform,Ln.translate(r.x,r.y).scale(i)),s.call(Vn().scaleExtent(e\?[n.min,n.max]:[i,i]).filter((t=>!a||(t.target.classList.contains(this.svgInstanceRef)||t.target.classList.contains(this.gInstanceRef)||t.shiftKey))).on(\"zoom\",(t=>{!this.props.draggable&&[\"mousemove\",\"touchmove\",\"dblclick\"].includes(t.sourceEvent.type)||(u.attr(\"transform\",t.transform),\"function\"==typeof o&&(o({node:null,zoom:t.transform.k,translate:{x:t.transform.x,y:t.transform.y}}),this.state.d3.scale=t.transform.k,this.state.d3.translate={x:t.transform.x,y:t.transform.y}))})))}static assignInternalProperties(t,e=0){return(Array.isArray(t)\?t:[t]).map((t=>{const n=t;return n.__rd3t={id:null,depth:null,collapsed:!1},n.__rd3t.id=sr(),n.__rd3t.depth=e,n.children&&n.children.length>0&&(n.children=Ti.assignInternalProperties(n.children,e+1)),n}))}findNodesById(t,e,n){return n.length>0||(n=n.concat(e.filter((e=>e.__rd3t.id===t))),e.forEach((e=>{e.children&&e.children.length>0&&(n=this.findNodesById(t,e.children,n))}))),n}findNodesAtDepth(t,e,n){return n=n.concat(e.filter((e=>e.__rd3t.depth===t))),e.forEach((e=>{e.children&&e.children.length>0&&(n=this.findNodesAtDepth(t,e.children,n))})),n}static collapseNode(t){t.__rd3t.collapsed=!0,t.children&&t.children.length>0&&t.children.forEach((t=>{Ti.collapseNode(t)}))}static expandNode(t){t.__rd3t.collapsed=!1}collapseNeighborNodes(t,e){this.findNodesAtDepth(t.__rd3t.depth,e,[]).filter((e=>e.__rd3t.id!==t.__rd3t.id)).forEach((t=>Ti.collapseNode(t)))}generateTree(){const{initialDepth:t,depthFactor:e,separation:n,nodeSize:r,orientation:i}=this.props,{isInitialRenderForDataset:o}=this.state,a=g().nodeSize(\"horizontal\"===i\?[r.y,r.x]:[r.x,r.y]).separation(((t,e)=>t.parent.data.__rd3t.id===e.parent.data.__rd3t.id\?n.siblings:n.nonSiblings))(s(this.state.data[0],(t=>t.__rd3t.collapsed\?null:t.children)));let u=a.descendants();const l=a.links();return void 0!==t&&o&&this.setInitialTreeDepth(u,t),e&&u.forEach((t=>{t.y=t.depth*e})),{nodes:u,links:l}}static calculateD3Geometry(t){let e;return e=t.zoom>t.scaleExtent.max\?t.scaleExtent.max:t.zoom<t.scaleExtent.min\?t.scaleExtent.min:t.zoom,{translate:t.translate,scale:e}}render(){const{nodes:t,links:e}=this.generateTree(),{renderCustomNodeElement:n,orientation:i,pathFunc:o,transitionDuration:a,nodeSize:s,depthFactor:u,initialDepth:l,separation:c,enableLegacyTransitions:h,svgClassName:f,pathClassFunc:p}=this.props,{translate:d,scale:m}=this.state.d3,y=Object.assign(Object.assign(Object.assign({},s),c),{depthFactor:u,initialDepth:l});return r.createElement(\"div\",{className:\"rd3t-tree-container rd3t-grabbable\"},r.createElement(\"style\",null,\"\\n/* Tree */\\n.rd3t-tree-container {\\n  width: 100%;\\n  height: 100%;\\n}\\n\\n.rd3t-grabbable {\\n  cursor: move; /* fallback if grab cursor is unsupported */\\n  cursor: grab;\\n  cursor: -moz-grab;\\n  cursor: -webkit-grab;\\n}\\n.rd3t-grabbable:active {\\n    cursor: grabbing;\\n    cursor: -moz-grabbing;\\n    cursor: -webkit-grabbing;\\n}\\n\\n/* Node */\\n.rd3t-node {\\n  cursor: pointer;\\n  fill: #777;\\n  stroke: #000;\\n  stroke-width: 2;\\n}\\n\\n.rd3t-leaf-node {\\n  cursor: pointer;\\n  fill: transparent;\\n  stroke: #000;\\n  stroke-width: 1;\\n}\\n\\n.rd3t-label__title {\\n  fill: #000;\\n  stroke: none;\\n  font-weight: bolder;\\n}\\n\\n.rd3t-label__attributes {\\n  fill: #777;\\n  stroke: none;\\n  font-weight: bolder;\\n  font-size: smaller;\\n}\\n\\n/* Link */\\n.rd3t-link {\\n  fill: none;\\n  stroke: #000;\\n}\\n\"),r.createElement(\"svg\",{className:`rd3t-svg ${this.svgInstanceRef} ${f}`,width:\"100%\",height:\"100%\"},r.createElement(oi,{enableLegacyTransitions:h,component:\"g\",className:`rd3t-g ${this.gInstanceRef}`,transform:`translate(${d.x},${d.y}) scale(${m})`},e.map(((t,e)=>r.createElement(ki,{key:\"link-\"+e,orientation:i,pathFunc:o,pathClassFunc:p,linkData:t,onClick:this.handleOnLinkClickCb,onMouseOver:this.handleOnLinkMouseOverCb,onMouseOut:this.handleOnLinkMouseOutCb,enableLegacyTransitions:h,transitionDuration:a}))),t.map(((t,e)=>{const{data:o,x:u,y:l,parent:c}=t;return r.createElement(li,{key:\"node-\"+e,data:o,position:{x:u,y:l},hierarchyPointNode:t,parent:c,nodeClassName:this.getNodeClassName(c,o),renderCustomNodeElement:n,nodeSize:s,orientation:i,enableLegacyTransitions:h,transitionDuration:a,onNodeToggle:this.handleNodeToggle,onNodeClick:this.handleOnNodeClickCb,onNodeMouseOver:this.handleOnNodeMouseOverCb,onNodeMouseOut:this.handleOnNodeMouseOutCb,handleAddChildrenToNode:this.handleAddChildrenToNode,subscriptions:y,centerNode:this.centerNode})})))))}}function Oi(t){if(\"empty\"===t)return{name:\"empty\",color:\"black\"};if(\"var\"in t)return{name:\"var\",expr:t.var};if(\"node\"in t){const{color:e,l:n,a:r,r:i}=t.node;return{name:\"node\",expr:r,color:e,children:[Oi(n),Oi(i)]}}throw new Error(`unknown RBTreeVars constructor '${JSON.stringify(t)}'`)}function Mi({pos:r,tree:i}){const a={x:40,y:80},s={width:a.x,height:a.y,y:-10,x:-4},u=n.useRef(null),[l,c]=n.useState(null);return n.useLayoutEffect((()=>{const t=u.current;if(null==t)return;if(null!=l)return;const e=t.getBoundingClientRect();e.width&&e.height&&c({x:e.width/2,y:20})})),t(\"div\",{style:{height:\"200px\",display:\"inline-flex\",minWidth:\"50px\",border:\"1px solid rgba(100, 100, 100, 0.2)\"},ref:u,children:t(Ti,{data:Oi(i),translate:l\?\?{x:0,y:0},nodeSize:a,renderCustomNodeElement:n=>function({nodeDatum:n},r,i){const a=n;return e(\"g\",{children:[t(\"circle\",{r:15,stroke:a.color\?\?\"white\",fill:\"white\"}),t(\"foreignObject\",{...i,children:a.expr&&t(o,{fmt:a.expr})})]})}(n,0,s),orientation:\"vertical\"})})}Ti.defaultProps={onNodeClick:void 0,onNodeMouseOver:void 0,onNodeMouseOut:void 0,onLinkClick:void 0,onLinkMouseOver:void 0,onLinkMouseOut:void 0,onUpdate:void 0,orientation:\"horizontal\",translate:{x:0,y:0},pathFunc:\"diagonal\",pathClassFunc:void 0,transitionDuration:500,depthFactor:void 0,collapsible:!0,initialDepth:void 0,zoomable:!0,draggable:!0,zoom:1,scaleExtent:{min:.1,max:1},nodeSize:{x:140,y:140},separation:{siblings:1,nonSiblings:2},shouldCollapseNeighborNodes:!1,svgClassName:\"\",rootNodeClassName:\"\",branchNodeClassName:\"\",leafNodeClassName:\"\",renderCustomNodeElement:void 0,enableLegacyTransitions:!1,hasInteractiveNodes:!1,dimensions:void 0,centeringTransitionDuration:800,dataKey:void 0};export{Mi as default};", 91742, 91742);
return x_1;
}
}
static uint64_t _init_l_RBDisplay___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_RBDisplay___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_RBDisplay___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_RBDisplay___closed__1;
x_2 = l_RBDisplay___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_RBDisplay___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_RBDisplay___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_RBDisplay___closed__3;
x_2 = l_RBDisplay___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_RBDisplay() {
_start:
{
lean_object* x_1; 
x_1 = l_RBDisplay___closed__4;
return x_1;
}
}
static lean_object* _init_l_drawTree_x3f_go___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_drawTree_x3f_go(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_node_x3f(x_1);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = l_empty_x3f(x_1);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; 
x_9 = l_drawTree_x3f_go___closed__0;
x_10 = l_Lean_Widget_ppExprTagged(x_1, x_9, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_10, 0, x_13);
return x_10;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_14 = lean_ctor_get(x_10, 0);
x_15 = lean_ctor_get(x_10, 1);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_10);
x_16 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_16, 0, x_14);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
}
else
{
uint8_t x_18; 
x_18 = !lean_is_exclusive(x_10);
if (x_18 == 0)
{
return x_10;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_10, 0);
x_20 = lean_ctor_get(x_10, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_10);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
return x_21;
}
}
}
else
{
lean_object* x_22; lean_object* x_23; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_22 = lean_box(0);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_6);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; uint8_t x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_57; 
lean_dec_ref(x_1);
x_24 = lean_ctor_get(x_7, 0);
lean_inc(x_24);
lean_dec_ref(x_7);
x_25 = lean_ctor_get(x_24, 1);
lean_inc(x_25);
x_26 = lean_ctor_get(x_25, 1);
lean_inc(x_26);
x_27 = lean_ctor_get(x_24, 0);
lean_inc(x_27);
lean_dec(x_24);
x_28 = lean_ctor_get(x_25, 0);
lean_inc(x_28);
lean_dec(x_25);
x_29 = lean_ctor_get(x_26, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_26, 1);
lean_inc(x_30);
lean_dec(x_26);
lean_inc(x_5);
lean_inc_ref(x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
x_57 = l_evalColourUnsafe(x_27, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_57) == 0)
{
lean_object* x_58; uint8_t x_59; 
x_58 = lean_ctor_get(x_57, 0);
lean_inc(x_58);
x_59 = lean_unbox(x_58);
lean_dec(x_58);
if (x_59 == 0)
{
lean_object* x_60; uint8_t x_61; 
x_60 = lean_ctor_get(x_57, 1);
lean_inc(x_60);
lean_dec_ref(x_57);
x_61 = 0;
x_31 = x_61;
x_32 = x_2;
x_33 = x_3;
x_34 = x_4;
x_35 = x_5;
x_36 = x_60;
goto block_56;
}
else
{
lean_object* x_62; uint8_t x_63; 
x_62 = lean_ctor_get(x_57, 1);
lean_inc(x_62);
lean_dec_ref(x_57);
x_63 = 1;
x_31 = x_63;
x_32 = x_2;
x_33 = x_3;
x_34 = x_4;
x_35 = x_5;
x_36 = x_62;
goto block_56;
}
}
else
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; uint8_t x_67; uint8_t x_71; 
x_64 = lean_ctor_get(x_57, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_57, 1);
lean_inc(x_65);
if (lean_is_exclusive(x_57)) {
 lean_ctor_release(x_57, 0);
 lean_ctor_release(x_57, 1);
 x_66 = x_57;
} else {
 lean_dec_ref(x_57);
 x_66 = lean_box(0);
}
x_71 = l_Lean_Exception_isInterrupt(x_64);
if (x_71 == 0)
{
uint8_t x_72; 
x_72 = l_Lean_Exception_isRuntime(x_64);
x_67 = x_72;
goto block_70;
}
else
{
x_67 = x_71;
goto block_70;
}
block_70:
{
if (x_67 == 0)
{
uint8_t x_68; 
lean_dec(x_66);
lean_dec(x_64);
x_68 = 2;
x_31 = x_68;
x_32 = x_2;
x_33 = x_3;
x_34 = x_4;
x_35 = x_5;
x_36 = x_65;
goto block_56;
}
else
{
lean_object* x_69; 
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_28);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
if (lean_is_scalar(x_66)) {
 x_69 = lean_alloc_ctor(1, 2, 0);
} else {
 x_69 = x_66;
}
lean_ctor_set(x_69, 0, x_64);
lean_ctor_set(x_69, 1, x_65);
return x_69;
}
}
}
block_56:
{
lean_object* x_37; 
lean_inc(x_35);
lean_inc_ref(x_34);
lean_inc(x_33);
lean_inc_ref(x_32);
x_37 = l_drawTree_x3f_go(x_28, x_32, x_33, x_34, x_35, x_36);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec_ref(x_37);
x_40 = l_drawTree_x3f_go___closed__0;
lean_inc(x_35);
lean_inc_ref(x_34);
lean_inc(x_33);
lean_inc_ref(x_32);
x_41 = l_Lean_Widget_ppExprTagged(x_29, x_40, x_32, x_33, x_34, x_35, x_39);
if (lean_obj_tag(x_41) == 0)
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_41, 1);
lean_inc(x_43);
lean_dec_ref(x_41);
x_44 = l_drawTree_x3f_go(x_30, x_32, x_33, x_34, x_35, x_43);
if (lean_obj_tag(x_44) == 0)
{
uint8_t x_45; 
x_45 = !lean_is_exclusive(x_44);
if (x_45 == 0)
{
lean_object* x_46; lean_object* x_47; 
x_46 = lean_ctor_get(x_44, 0);
x_47 = lean_alloc_ctor(2, 3, 1);
lean_ctor_set(x_47, 0, x_38);
lean_ctor_set(x_47, 1, x_42);
lean_ctor_set(x_47, 2, x_46);
lean_ctor_set_uint8(x_47, sizeof(void*)*3, x_31);
lean_ctor_set(x_44, 0, x_47);
return x_44;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_48 = lean_ctor_get(x_44, 0);
x_49 = lean_ctor_get(x_44, 1);
lean_inc(x_49);
lean_inc(x_48);
lean_dec(x_44);
x_50 = lean_alloc_ctor(2, 3, 1);
lean_ctor_set(x_50, 0, x_38);
lean_ctor_set(x_50, 1, x_42);
lean_ctor_set(x_50, 2, x_48);
lean_ctor_set_uint8(x_50, sizeof(void*)*3, x_31);
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_50);
lean_ctor_set(x_51, 1, x_49);
return x_51;
}
}
else
{
lean_dec(x_42);
lean_dec(x_38);
return x_44;
}
}
else
{
uint8_t x_52; 
lean_dec(x_38);
lean_dec(x_35);
lean_dec_ref(x_34);
lean_dec(x_33);
lean_dec_ref(x_32);
lean_dec(x_30);
x_52 = !lean_is_exclusive(x_41);
if (x_52 == 0)
{
return x_41;
}
else
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_53 = lean_ctor_get(x_41, 0);
x_54 = lean_ctor_get(x_41, 1);
lean_inc(x_54);
lean_inc(x_53);
lean_dec(x_41);
x_55 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_55, 0, x_53);
lean_ctor_set(x_55, 1, x_54);
return x_55;
}
}
}
else
{
lean_dec(x_35);
lean_dec_ref(x_34);
lean_dec(x_33);
lean_dec_ref(x_32);
lean_dec(x_30);
lean_dec(x_29);
return x_37;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_string_hash(x_6);
x_8 = lean_alloc_closure((void*)(l_instRpcEncodableRBDisplayProps_enc____x40_ProofWidgets_Demos_RbTree_1901195190____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_8, 0, x_2);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_7);
return x_9;
}
}
static lean_object* _init_l_drawTree_x3f___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_drawTree_x3f(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_node_x3f(x_1);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = l_empty_x3f(x_1);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_9 = lean_box(0);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_6);
return x_10;
}
else
{
lean_object* x_11; 
x_11 = l_drawTree_x3f_go(x_1, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_13 = lean_ctor_get(x_11, 0);
x_14 = l_RBDisplay;
x_15 = l_drawTree_x3f___closed__0;
x_16 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_14, x_13, x_15);
x_17 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_11, 0, x_17);
return x_11;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_18 = lean_ctor_get(x_11, 0);
x_19 = lean_ctor_get(x_11, 1);
lean_inc(x_19);
lean_inc(x_18);
lean_dec(x_11);
x_20 = l_RBDisplay;
x_21 = l_drawTree_x3f___closed__0;
x_22 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_20, x_18, x_21);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_19);
return x_24;
}
}
else
{
uint8_t x_25; 
x_25 = !lean_is_exclusive(x_11);
if (x_25 == 0)
{
return x_11;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_11, 0);
x_27 = lean_ctor_get(x_11, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_11);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
}
else
{
uint8_t x_29; 
x_29 = !lean_is_exclusive(x_7);
if (x_29 == 0)
{
lean_object* x_30; lean_object* x_31; 
x_30 = lean_ctor_get(x_7, 0);
lean_dec(x_30);
x_31 = l_drawTree_x3f_go(x_1, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_31) == 0)
{
uint8_t x_32; 
x_32 = !lean_is_exclusive(x_31);
if (x_32 == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_33 = lean_ctor_get(x_31, 0);
x_34 = l_RBDisplay;
x_35 = l_drawTree_x3f___closed__0;
x_36 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_34, x_33, x_35);
lean_ctor_set(x_7, 0, x_36);
lean_ctor_set(x_31, 0, x_7);
return x_31;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_37 = lean_ctor_get(x_31, 0);
x_38 = lean_ctor_get(x_31, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_31);
x_39 = l_RBDisplay;
x_40 = l_drawTree_x3f___closed__0;
x_41 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_39, x_37, x_40);
lean_ctor_set(x_7, 0, x_41);
x_42 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_42, 0, x_7);
lean_ctor_set(x_42, 1, x_38);
return x_42;
}
}
else
{
uint8_t x_43; 
lean_free_object(x_7);
x_43 = !lean_is_exclusive(x_31);
if (x_43 == 0)
{
return x_31;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_ctor_get(x_31, 0);
x_45 = lean_ctor_get(x_31, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_31);
x_46 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_46, 0, x_44);
lean_ctor_set(x_46, 1, x_45);
return x_46;
}
}
}
else
{
lean_object* x_47; 
lean_dec(x_7);
x_47 = l_drawTree_x3f_go(x_1, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_47) == 0)
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_48 = lean_ctor_get(x_47, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_47, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_47)) {
 lean_ctor_release(x_47, 0);
 lean_ctor_release(x_47, 1);
 x_50 = x_47;
} else {
 lean_dec_ref(x_47);
 x_50 = lean_box(0);
}
x_51 = l_RBDisplay;
x_52 = l_drawTree_x3f___closed__0;
x_53 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_51, x_48, x_52);
x_54 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_54, 0, x_53);
if (lean_is_scalar(x_50)) {
 x_55 = lean_alloc_ctor(0, 2, 0);
} else {
 x_55 = x_50;
}
lean_ctor_set(x_55, 0, x_54);
lean_ctor_set(x_55, 1, x_49);
return x_55;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_56 = lean_ctor_get(x_47, 0);
lean_inc(x_56);
x_57 = lean_ctor_get(x_47, 1);
lean_inc(x_57);
if (lean_is_exclusive(x_47)) {
 lean_ctor_release(x_47, 0);
 lean_ctor_release(x_47, 1);
 x_58 = x_47;
} else {
 lean_dec_ref(x_47);
 x_58 = lean_box(0);
}
if (lean_is_scalar(x_58)) {
 x_59 = lean_alloc_ctor(1, 2, 0);
} else {
 x_59 = x_58;
}
lean_ctor_set(x_59, 0, x_56);
lean_ctor_set(x_59, 1, x_57);
return x_59;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___drawTree_x3f_spec__0(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
static lean_object* _init_l_RBTree_presenter___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("not a tree :(", 13, 13);
return x_1;
}
}
static lean_object* _init_l_RBTree_presenter___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_RBTree_presenter___lam__0___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RBTree_presenter___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
lean_inc(x_5);
lean_inc_ref(x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
x_7 = l_drawTree_x3f(x_1, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_8; 
x_8 = lean_ctor_get(x_7, 0);
lean_inc(x_8);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_7, 1);
lean_inc(x_9);
lean_dec_ref(x_7);
x_10 = l_RBTree_presenter___lam__0___closed__1;
x_11 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_10, x_2, x_3, x_4, x_5, x_9);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_11;
}
else
{
uint8_t x_12; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_12 = !lean_is_exclusive(x_7);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_7, 0);
lean_dec(x_13);
x_14 = lean_ctor_get(x_8, 0);
lean_inc(x_14);
lean_dec_ref(x_8);
lean_ctor_set(x_7, 0, x_14);
return x_7;
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_7, 1);
lean_inc(x_15);
lean_dec(x_7);
x_16 = lean_ctor_get(x_8, 0);
lean_inc(x_16);
lean_dec_ref(x_8);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
}
}
else
{
uint8_t x_18; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_18 = !lean_is_exclusive(x_7);
if (x_18 == 0)
{
return x_7;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_7, 0);
x_20 = lean_ctor_get(x_7, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_7);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
return x_21;
}
}
}
}
static lean_object* _init_l_RBTree_presenter___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Red-black tree", 14, 14);
return x_1;
}
}
static lean_object* _init_l_RBTree_presenter() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; 
x_1 = lean_alloc_closure((void*)(l_RBTree_presenter___lam__0), 6, 0);
x_2 = l_RBTree_presenter___closed__0;
x_3 = 0;
x_4 = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_1);
lean_ctor_set_uint8(x_4, sizeof(void*)*2, x_3);
return x_4;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Presentation_Expr(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_SelectionPanel(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_RbTree(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Presentation_Expr(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_SelectionPanel(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_empty_x3f___closed__0 = _init_l_empty_x3f___closed__0();
lean_mark_persistent(l_empty_x3f___closed__0);
l_empty_x3f___closed__1 = _init_l_empty_x3f___closed__1();
lean_mark_persistent(l_empty_x3f___closed__1);
l_empty_x3f___closed__2 = _init_l_empty_x3f___closed__2();
lean_mark_persistent(l_empty_x3f___closed__2);
l_node_x3f___closed__0 = _init_l_node_x3f___closed__0();
lean_mark_persistent(l_node_x3f___closed__0);
l_node_x3f___closed__1 = _init_l_node_x3f___closed__1();
lean_mark_persistent(l_node_x3f___closed__1);
l_evalColourUnsafe___closed__0 = _init_l_evalColourUnsafe___closed__0();
lean_mark_persistent(l_evalColourUnsafe___closed__0);
l_evalColourUnsafe___closed__1 = _init_l_evalColourUnsafe___closed__1();
lean_mark_persistent(l_evalColourUnsafe___closed__1);
l_RBTreeVarsColour_noConfusion___redArg___closed__0 = _init_l_RBTreeVarsColour_noConfusion___redArg___closed__0();
lean_mark_persistent(l_RBTreeVarsColour_noConfusion___redArg___closed__0);
l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__0);
l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__0___closed__1);
l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__0);
l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__1___closed__1);
l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__0);
l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1 = _init_l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___lam__2___closed__1);
l_instFromJsonRBTreeVarsColour_fromJson___closed__0 = _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__0();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___closed__0);
l_instFromJsonRBTreeVarsColour_fromJson___closed__1 = _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__1();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___closed__1);
l_instFromJsonRBTreeVarsColour_fromJson___closed__2 = _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__2();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___closed__2);
l_instFromJsonRBTreeVarsColour_fromJson___closed__3 = _init_l_instFromJsonRBTreeVarsColour_fromJson___closed__3();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour_fromJson___closed__3);
l_instFromJsonRBTreeVarsColour___closed__0 = _init_l_instFromJsonRBTreeVarsColour___closed__0();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour___closed__0);
l_instFromJsonRBTreeVarsColour = _init_l_instFromJsonRBTreeVarsColour();
lean_mark_persistent(l_instFromJsonRBTreeVarsColour);
l_instToJsonRBTreeVarsColour_toJson___closed__0 = _init_l_instToJsonRBTreeVarsColour_toJson___closed__0();
lean_mark_persistent(l_instToJsonRBTreeVarsColour_toJson___closed__0);
l_instToJsonRBTreeVarsColour_toJson___closed__1 = _init_l_instToJsonRBTreeVarsColour_toJson___closed__1();
lean_mark_persistent(l_instToJsonRBTreeVarsColour_toJson___closed__1);
l_instToJsonRBTreeVarsColour_toJson___closed__2 = _init_l_instToJsonRBTreeVarsColour_toJson___closed__2();
lean_mark_persistent(l_instToJsonRBTreeVarsColour_toJson___closed__2);
l_instToJsonRBTreeVarsColour___closed__0 = _init_l_instToJsonRBTreeVarsColour___closed__0();
lean_mark_persistent(l_instToJsonRBTreeVarsColour___closed__0);
l_instToJsonRBTreeVarsColour = _init_l_instToJsonRBTreeVarsColour();
lean_mark_persistent(l_instToJsonRBTreeVarsColour);
l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__6____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__7____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__8____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__9____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__10____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__11____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__12____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__13____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___lam__2___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_56_);
l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_ = _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3236321518____hygCtx___hyg_79_);
l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_ = _init_l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_();
lean_mark_persistent(l_instRpcEncodableRBTreeVars_enc___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_);
l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_ = _init_l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_();
lean_mark_persistent(l_instRpcEncodableRBTreeVars_enc___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_);
l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_ = _init_l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_();
lean_mark_persistent(l_instRpcEncodableRBTreeVars_dec___closed__0____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_);
l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_ = _init_l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_();
lean_mark_persistent(l_instRpcEncodableRBTreeVars_dec___closed__1____x40_ProofWidgets_Demos_RbTree_2345136221____hygCtx___hyg_1_);
l_instRpcEncodableRBTreeVars___closed__0 = _init_l_instRpcEncodableRBTreeVars___closed__0();
lean_mark_persistent(l_instRpcEncodableRBTreeVars___closed__0);
l_instRpcEncodableRBTreeVars___closed__1 = _init_l_instRpcEncodableRBTreeVars___closed__1();
lean_mark_persistent(l_instRpcEncodableRBTreeVars___closed__1);
l_instRpcEncodableRBTreeVars___closed__2 = _init_l_instRpcEncodableRBTreeVars___closed__2();
lean_mark_persistent(l_instRpcEncodableRBTreeVars___closed__2);
l_instRpcEncodableRBTreeVars = _init_l_instRpcEncodableRBTreeVars();
lean_mark_persistent(l_instRpcEncodableRBTreeVars);
l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_17_);
l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_RbTree_3450233223____hygCtx___hyg_35_);
l_instRpcEncodableRBDisplayProps___closed__0 = _init_l_instRpcEncodableRBDisplayProps___closed__0();
lean_mark_persistent(l_instRpcEncodableRBDisplayProps___closed__0);
l_instRpcEncodableRBDisplayProps___closed__1 = _init_l_instRpcEncodableRBDisplayProps___closed__1();
lean_mark_persistent(l_instRpcEncodableRBDisplayProps___closed__1);
l_instRpcEncodableRBDisplayProps___closed__2 = _init_l_instRpcEncodableRBDisplayProps___closed__2();
lean_mark_persistent(l_instRpcEncodableRBDisplayProps___closed__2);
l_instRpcEncodableRBDisplayProps = _init_l_instRpcEncodableRBDisplayProps();
lean_mark_persistent(l_instRpcEncodableRBDisplayProps);
l_RBDisplay___closed__0 = _init_l_RBDisplay___closed__0();
lean_mark_persistent(l_RBDisplay___closed__0);
l_RBDisplay___closed__1 = _init_l_RBDisplay___closed__1();
l_RBDisplay___closed__2 = _init_l_RBDisplay___closed__2();
lean_mark_persistent(l_RBDisplay___closed__2);
l_RBDisplay___closed__3 = _init_l_RBDisplay___closed__3();
lean_mark_persistent(l_RBDisplay___closed__3);
l_RBDisplay___closed__4 = _init_l_RBDisplay___closed__4();
lean_mark_persistent(l_RBDisplay___closed__4);
l_RBDisplay = _init_l_RBDisplay();
lean_mark_persistent(l_RBDisplay);
l_drawTree_x3f_go___closed__0 = _init_l_drawTree_x3f_go___closed__0();
lean_mark_persistent(l_drawTree_x3f_go___closed__0);
l_drawTree_x3f___closed__0 = _init_l_drawTree_x3f___closed__0();
lean_mark_persistent(l_drawTree_x3f___closed__0);
l_RBTree_presenter___lam__0___closed__0 = _init_l_RBTree_presenter___lam__0___closed__0();
lean_mark_persistent(l_RBTree_presenter___lam__0___closed__0);
l_RBTree_presenter___lam__0___closed__1 = _init_l_RBTree_presenter___lam__0___closed__1();
lean_mark_persistent(l_RBTree_presenter___lam__0___closed__1);
l_RBTree_presenter___closed__0 = _init_l_RBTree_presenter___closed__0();
lean_mark_persistent(l_RBTree_presenter___closed__0);
l_RBTree_presenter = _init_l_RBTree_presenter();
lean_mark_persistent(l_RBTree_presenter);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
