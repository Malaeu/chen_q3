// Lean compiler output
// Module: ProofWidgets.Demos.Plot
// Imports: Init ProofWidgets.Component.HtmlDisplay ProofWidgets.Component.Recharts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
static double l_fn___closed__3;
double lean_float_mul(double, double);
static lean_object* l_Plot___closed__12;
LEAN_EXPORT lean_object* l_AnimatedHtmlProps_ctorIdx(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1__spec__3(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT double l_fn(double, double);
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_Plot___closed__10;
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
double lean_float_div(double, double);
static double l_fn___closed__5;
static lean_object* l_Plot___closed__4;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_(lean_object*);
static lean_object* l_Plot___closed__5;
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_Plot___closed__15;
static double l_fn___closed__1;
LEAN_EXPORT lean_object* l_Plot(lean_object*, lean_object*);
static lean_object* l_Plot___closed__17;
static lean_object* l_Plot___closed__24;
static lean_object* l_instRpcEncodableAnimatedHtmlProps___closed__2;
static double l_fn___closed__2;
uint64_t lean_string_hash(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2(lean_object*, lean_object*, lean_object*);
static lean_object* l_Plot___closed__21;
static lean_object* l_AnimatedHtml___closed__3;
static lean_object* l_Plot___closed__7;
double sin(double);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
static lean_object* l_Plot___closed__0;
lean_object* l_Lean_Json_opt___at___Lean_Widget_instToJsonRpcEncodablePacket_toJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_69__spec__0(lean_object*, lean_object*);
static lean_object* l_Plot___closed__22;
static double l_fn___closed__4;
lean_object* l_Lean_JsonNumber_fromInt(lean_object*);
static lean_object* l_instRpcEncodableAnimatedHtmlProps___closed__0;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
double lean_float_add(double, double);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
static uint64_t l_AnimatedHtml___closed__1;
LEAN_EXPORT lean_object* l_fn___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
static lean_object* l_Plot___closed__25;
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(lean_object*, lean_object*);
double lean_float_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_AnimatedHtmlProps_ctorIdx___boxed(lean_object*);
static lean_object* l_Plot___closed__16;
static lean_object* l_Plot___closed__9;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_Recharts_instToJsonLineChartProps_toJson(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1__spec__2(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1(size_t, size_t, lean_object*);
lean_object* l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0;
static lean_object* l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0(lean_object*, lean_object*);
lean_object* l_ProofWidgets_Recharts_instToJsonLineProps_toJson(lean_object*);
LEAN_EXPORT lean_object* l_mkFrames(lean_object*, lean_object*);
lean_object* l_Array_range(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4(lean_object*, lean_object*, lean_object*);
static lean_object* l_Plot___closed__8;
extern lean_object* l_ProofWidgets_Recharts_YAxis;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_(lean_object*, lean_object*);
double l_Float_ofScientific(lean_object*, uint8_t, lean_object*);
lean_object* l_Array_fromJson_x3f___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_dec____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__0(lean_object*);
static lean_object* l_AnimatedHtml___closed__0;
extern lean_object* l_ProofWidgets_Recharts_LineChart;
static lean_object* l_Plot___closed__1;
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_(lean_object*);
static lean_object* l_Plot___closed__3;
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
static double l_fn___closed__6;
extern lean_object* l_ProofWidgets_Recharts_Line;
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
static lean_object* l_Plot___closed__19;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0___boxed(lean_object*, lean_object*);
static lean_object* l_Plot___closed__6;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instRpcEncodableAnimatedHtmlProps___closed__1;
lean_object* l_Lean_Json_getNat_x3f(lean_object*);
LEAN_EXPORT lean_object* l_AnimatedHtml;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
static lean_object* l_Plot___closed__13;
static lean_object* l_AnimatedHtml___closed__2;
lean_object* lean_array_mk(lean_object*);
size_t lean_usize_add(size_t, size_t);
static lean_object* l_Plot___closed__18;
lean_object* lean_array_uget(lean_object*, size_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2___lam__0(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
static lean_object* l_Plot___closed__11;
static lean_object* l_Plot___closed__23;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
static double l_fn___closed__0;
static lean_object* l_Plot___closed__2;
lean_object* lean_int_neg(lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_enc____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_Plot___closed__26;
extern lean_object* l_ProofWidgets_Recharts_XAxis;
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1__ctorIdx(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
static lean_object* l_AnimatedHtml___closed__4;
static lean_object* l_Plot___closed__14;
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
lean_object* l_ProofWidgets_Recharts_instToJsonAxisProps_toJson(lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static double l_fn___closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4___lam__0(lean_object*, lean_object*);
lean_object* l_Float_toJson(double);
static lean_object* l_Plot___closed__20;
double lean_float_sub(double, double);
static double _init_l_fn___closed__0() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(50u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static double _init_l_fn___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; double x_4; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = 1;
x_3 = lean_unsigned_to_nat(25u);
x_4 = l_Float_ofScientific(x_3, x_2, x_1);
return x_4;
}
}
static double _init_l_fn___closed__2() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; double x_4; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = 1;
x_3 = lean_unsigned_to_nat(5u);
x_4 = l_Float_ofScientific(x_3, x_2, x_1);
return x_4;
}
}
static double _init_l_fn___closed__3() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; double x_4; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = 1;
x_3 = lean_unsigned_to_nat(7u);
x_4 = l_Float_ofScientific(x_3, x_2, x_1);
return x_4;
}
}
static double _init_l_fn___closed__4() {
_start:
{
uint8_t x_1; lean_object* x_2; double x_3; 
x_1 = 1;
x_2 = lean_unsigned_to_nat(1u);
x_3 = l_Float_ofScientific(x_2, x_1, x_2);
return x_3;
}
}
static double _init_l_fn___closed__5() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(40u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static double _init_l_fn___closed__6() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static double _init_l_fn___closed__7() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; double x_4; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = 1;
x_3 = lean_unsigned_to_nat(3141u);
x_4 = l_Float_ofScientific(x_3, x_2, x_1);
return x_4;
}
}
LEAN_EXPORT double l_fn(double x_1, double x_2) {
_start:
{
double x_3; double x_4; double x_5; double x_6; double x_7; double x_8; double x_9; double x_10; double x_11; double x_12; double x_13; double x_14; double x_15; double x_16; double x_17; double x_18; double x_19; double x_20; double x_21; double x_22; double x_23; 
x_3 = l_fn___closed__0;
x_4 = l_fn___closed__1;
x_5 = lean_float_sub(x_2, x_4);
x_6 = lean_float_mul(x_3, x_5);
x_7 = l_fn___closed__2;
x_8 = lean_float_sub(x_2, x_7);
x_9 = lean_float_mul(x_6, x_8);
x_10 = l_fn___closed__3;
x_11 = lean_float_sub(x_2, x_10);
x_12 = lean_float_mul(x_9, x_11);
x_13 = l_fn___closed__4;
x_14 = l_fn___closed__5;
x_15 = lean_float_mul(x_2, x_14);
x_16 = l_fn___closed__6;
x_17 = lean_float_mul(x_1, x_16);
x_18 = l_fn___closed__7;
x_19 = lean_float_mul(x_17, x_18);
x_20 = lean_float_sub(x_15, x_19);
x_21 = sin(x_20);
x_22 = lean_float_mul(x_13, x_21);
x_23 = lean_float_add(x_12, x_22);
return x_23;
}
}
LEAN_EXPORT lean_object* l_fn___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
double x_3; double x_4; double x_5; lean_object* x_6; 
x_3 = lean_unbox_float(x_1);
lean_dec_ref(x_1);
x_4 = lean_unbox_float(x_2);
lean_dec_ref(x_2);
x_5 = l_fn(x_3, x_4);
x_6 = lean_box_float(x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_4, x_3);
if (x_6 == 0)
{
lean_dec_ref(x_2);
lean_dec(x_1);
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; double x_10; double x_11; double x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; size_t x_17; size_t x_18; lean_object* x_19; 
x_7 = lean_array_uget(x_5, x_4);
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_uset(x_5, x_4, x_8);
x_10 = lean_float_of_nat(x_7);
lean_inc(x_1);
x_11 = lean_float_of_nat(x_1);
x_12 = lean_float_div(x_10, x_11);
x_13 = lean_box_float(x_12);
lean_inc_ref(x_2);
x_14 = lean_apply_1(x_2, x_13);
x_15 = lean_box_float(x_12);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_14);
x_17 = 1;
x_18 = lean_usize_add(x_4, x_17);
x_19 = lean_array_uset(x_9, x_4, x_16);
x_4 = x_18;
x_5 = x_19;
goto _start;
}
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("x", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("y", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; uint8_t x_6; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; double x_12; lean_object* x_13; lean_object* x_14; double x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; size_t x_22; size_t x_23; lean_object* x_24; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
x_9 = lean_unsigned_to_nat(0u);
x_10 = lean_array_uset(x_3, x_2, x_9);
x_11 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0;
x_12 = lean_unbox_float(x_7);
lean_dec(x_7);
x_13 = l_Float_toJson(x_12);
lean_ctor_set(x_5, 1, x_13);
lean_ctor_set(x_5, 0, x_11);
x_14 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1;
x_15 = lean_unbox_float(x_8);
lean_dec(x_8);
x_16 = l_Float_toJson(x_15);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_14);
lean_ctor_set(x_17, 1, x_16);
x_18 = lean_box(0);
x_19 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_20, 0, x_5);
lean_ctor_set(x_20, 1, x_19);
x_21 = l_Lean_Json_mkObj(x_20);
x_22 = 1;
x_23 = lean_usize_add(x_2, x_22);
x_24 = lean_array_uset(x_10, x_2, x_21);
x_2 = x_23;
x_3 = x_24;
goto _start;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; double x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; double x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; size_t x_42; size_t x_43; lean_object* x_44; 
x_26 = lean_ctor_get(x_5, 0);
x_27 = lean_ctor_get(x_5, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_5);
x_28 = lean_unsigned_to_nat(0u);
x_29 = lean_array_uset(x_3, x_2, x_28);
x_30 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0;
x_31 = lean_unbox_float(x_26);
lean_dec(x_26);
x_32 = l_Float_toJson(x_31);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_30);
lean_ctor_set(x_33, 1, x_32);
x_34 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1;
x_35 = lean_unbox_float(x_27);
lean_dec(x_27);
x_36 = l_Float_toJson(x_35);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_34);
lean_ctor_set(x_37, 1, x_36);
x_38 = lean_box(0);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
x_40 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_40, 0, x_33);
lean_ctor_set(x_40, 1, x_39);
x_41 = l_Lean_Json_mkObj(x_40);
x_42 = 1;
x_43 = lean_usize_add(x_2, x_42);
x_44 = lean_array_uset(x_29, x_2, x_41);
x_2 = x_43;
x_3 = x_44;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_Recharts_instToJsonAxisProps_toJson(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___Plot_spec__2___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_Recharts_instToJsonLineProps_toJson(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0___boxed), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_Recharts_instToJsonLineChartProps_toJson(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___Plot_spec__4___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
static lean_object* _init_l_Plot___closed__0() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 0;
x_2 = lean_box(x_1);
x_3 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_3, 0, x_2);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(5u);
x_2 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
lean_ctor_set(x_2, 2, x_1);
lean_ctor_set(x_2, 3, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = l_Lean_JsonNumber_fromNat(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__4;
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = l_Lean_JsonNumber_fromNat(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__6;
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Plot___closed__5;
x_2 = l_Plot___closed__8;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Plot___closed__7;
x_2 = l_Plot___closed__9;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__10;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__12() {
_start:
{
uint8_t x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 0;
x_2 = 0;
x_3 = l_Plot___closed__11;
x_4 = l_Plot___closed__3;
x_5 = lean_alloc_ctor(0, 2, 2);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set_uint8(x_5, sizeof(void*)*2, x_2);
lean_ctor_set_uint8(x_5, sizeof(void*)*2 + 1, x_1);
return x_5;
}
}
static lean_object* _init_l_Plot___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__14;
x_2 = lean_int_neg(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__15;
x_2 = l_Lean_JsonNumber_fromInt(x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__16;
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Plot___closed__17;
x_2 = l_Plot___closed__8;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Plot___closed__7;
x_2 = l_Plot___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Plot___closed__19;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__21() {
_start:
{
uint8_t x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 0;
x_2 = 0;
x_3 = l_Plot___closed__20;
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(0, 2, 2);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set_uint8(x_5, sizeof(void*)*2, x_2);
lean_ctor_set_uint8(x_5, sizeof(void*)*2 + 1, x_1);
return x_5;
}
}
static lean_object* _init_l_Plot___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Plot___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("#8884d8", 7, 7);
return x_1;
}
}
static lean_object* _init_l_Plot___closed__24() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 0;
x_2 = lean_box(x_1);
x_3 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_3, 0, x_2);
return x_3;
}
}
static lean_object* _init_l_Plot___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; lean_object* x_5; 
x_1 = l_Plot___closed__24;
x_2 = l_Plot___closed__23;
x_3 = l_Plot___closed__22;
x_4 = 8;
x_5 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_2);
lean_ctor_set(x_5, 2, x_1);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_4);
return x_5;
}
}
static lean_object* _init_l_Plot___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Plot(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; size_t x_6; size_t x_7; lean_object* x_8; size_t x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_3 = lean_unsigned_to_nat(1u);
x_4 = lean_nat_add(x_2, x_3);
x_5 = l_Array_range(x_4);
x_6 = lean_array_size(x_5);
x_7 = 0;
x_8 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0(x_2, x_1, x_6, x_7, x_5);
x_9 = lean_array_size(x_8);
x_10 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1(x_9, x_7, x_8);
x_11 = l_ProofWidgets_Recharts_LineChart;
x_12 = 0;
x_13 = lean_box(0);
x_14 = l_Plot___closed__0;
x_15 = lean_unsigned_to_nat(400u);
x_16 = l_Plot___closed__1;
x_17 = lean_alloc_ctor(0, 6, 1);
lean_ctor_set(x_17, 0, x_13);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_15);
lean_ctor_set(x_17, 4, x_10);
lean_ctor_set(x_17, 5, x_16);
lean_ctor_set_uint8(x_17, sizeof(void*)*6, x_12);
x_18 = l_ProofWidgets_Recharts_XAxis;
x_19 = l_Plot___closed__12;
x_20 = l_Plot___closed__13;
x_21 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__2(x_18, x_19, x_20);
x_22 = l_ProofWidgets_Recharts_YAxis;
x_23 = l_Plot___closed__21;
x_24 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__2(x_22, x_23, x_20);
x_25 = l_ProofWidgets_Recharts_Line;
x_26 = l_Plot___closed__25;
x_27 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__3(x_25, x_26, x_20);
x_28 = l_Plot___closed__26;
x_29 = lean_array_push(x_28, x_21);
x_30 = lean_array_push(x_29, x_24);
x_31 = lean_array_push(x_30, x_27);
x_32 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__4(x_11, x_17, x_31);
return x_32;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_8 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__0(x_1, x_2, x_6, x_7, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__2(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___lam__0(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__3(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___Plot_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___Plot_spec__4(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_4, x_3);
if (x_6 == 0)
{
lean_dec_ref(x_2);
lean_dec(x_1);
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; double x_10; double x_11; double x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; size_t x_17; size_t x_18; lean_object* x_19; 
x_7 = lean_array_uget(x_5, x_4);
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_uset(x_5, x_4, x_8);
x_10 = lean_float_of_nat(x_7);
lean_inc(x_1);
x_11 = lean_float_of_nat(x_1);
x_12 = lean_float_div(x_10, x_11);
x_13 = lean_box_float(x_12);
lean_inc_ref(x_2);
x_14 = lean_apply_1(x_2, x_13);
x_15 = lean_unsigned_to_nat(100u);
x_16 = l_Plot(x_14, x_15);
x_17 = 1;
x_18 = lean_usize_add(x_4, x_17);
x_19 = lean_array_uset(x_9, x_4, x_16);
x_4 = x_18;
x_5 = x_19;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_mkFrames(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; size_t x_7; size_t x_8; lean_object* x_9; 
x_3 = lean_unsigned_to_nat(1u);
x_4 = lean_nat_add(x_2, x_3);
x_5 = l_List_range(x_4);
x_6 = lean_array_mk(x_5);
x_7 = lean_array_size(x_6);
x_8 = 0;
x_9 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0(x_2, x_1, x_7, x_8, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_8 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___mkFrames_spec__0(x_1, x_2, x_6, x_7, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_AnimatedHtmlProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_AnimatedHtmlProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_AnimatedHtmlProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("frames", 6, 6);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("framesPerSecond", 15, 15);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
x_6 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__1(x_1, x_5);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_4);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_6, 0, x_9);
return x_6;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_6, 0);
lean_inc(x_10);
lean_dec(x_6);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_4);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_(lean_object* x_1) {
_start:
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = lean_ctor_get(x_1, 1);
x_5 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
lean_ctor_set(x_1, 1, x_3);
lean_ctor_set(x_1, 0, x_5);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_1);
lean_ctor_set(x_7, 1, x_6);
x_8 = l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
x_9 = l_Lean_Json_opt___at___Lean_Widget_instToJsonRpcEncodablePacket_toJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_69__spec__0(x_8, x_4);
lean_dec(x_4);
x_10 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_6);
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_7);
lean_ctor_set(x_11, 1, x_10);
x_12 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
x_13 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_11, x_12);
x_14 = l_Lean_Json_mkObj(x_13);
return x_14;
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_15 = lean_ctor_get(x_1, 0);
x_16 = lean_ctor_get(x_1, 1);
lean_inc(x_16);
lean_inc(x_15);
lean_dec(x_1);
x_17 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_15);
x_19 = lean_box(0);
x_20 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_20, 0, x_18);
lean_ctor_set(x_20, 1, x_19);
x_21 = l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_;
x_22 = l_Lean_Json_opt___at___Lean_Widget_instToJsonRpcEncodablePacket_toJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_69__spec__0(x_21, x_16);
lean_dec(x_16);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_19);
x_24 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_24, 0, x_20);
lean_ctor_set(x_24, 1, x_23);
x_25 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
x_26 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_24, x_25);
x_27 = l_Lean_Json_mkObj(x_26);
return x_27;
}
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_enc____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; size_t x_6; size_t x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_5 = x_1;
} else {
 lean_dec_ref(x_1);
 x_5 = lean_box(0);
}
x_6 = lean_array_size(x_3);
x_7 = 0;
x_8 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1__spec__2(x_6, x_7, x_3, x_2);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
if (lean_is_exclusive(x_8)) {
 lean_ctor_release(x_8, 0);
 lean_ctor_release(x_8, 1);
 x_11 = x_8;
} else {
 lean_dec_ref(x_8);
 x_11 = lean_box(0);
}
x_12 = l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(x_9);
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_18; 
x_18 = lean_box(0);
x_13 = x_18;
goto block_17;
}
else
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_4);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_4, 0);
x_21 = l_Lean_JsonNumber_fromNat(x_20);
x_22 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_4, 0, x_22);
x_13 = x_4;
goto block_17;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_23 = lean_ctor_get(x_4, 0);
lean_inc(x_23);
lean_dec(x_4);
x_24 = l_Lean_JsonNumber_fromNat(x_23);
x_25 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_25, 0, x_24);
x_26 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_26, 0, x_25);
x_13 = x_26;
goto block_17;
}
}
block_17:
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; 
if (lean_is_scalar(x_5)) {
 x_14 = lean_alloc_ctor(0, 2, 0);
} else {
 x_14 = x_5;
}
lean_ctor_set(x_14, 0, x_12);
lean_ctor_set(x_14, 1, x_13);
x_15 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_(x_14);
if (lean_is_scalar(x_11)) {
 x_16 = lean_alloc_ctor(0, 2, 0);
} else {
 x_16 = x_11;
}
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_10);
return x_16;
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_3 = l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_7 = x_4;
} else {
 lean_dec_ref(x_4);
 x_7 = lean_box(0);
}
x_8 = l_Array_fromJson_x3f___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_dec____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__0(x_5);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
lean_dec(x_7);
lean_dec(x_6);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
return x_8;
}
else
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
lean_object* x_12; size_t x_13; size_t x_14; lean_object* x_15; 
x_12 = lean_ctor_get(x_8, 0);
lean_inc(x_12);
lean_dec_ref(x_8);
x_13 = lean_array_size(x_12);
x_14 = 0;
x_15 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1__spec__3(x_13, x_14, x_12, x_2);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_7);
lean_dec(x_6);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
return x_15;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 x_20 = x_15;
} else {
 lean_dec_ref(x_15);
 x_20 = lean_box(0);
}
if (lean_obj_tag(x_6) == 0)
{
lean_object* x_25; 
x_25 = lean_box(0);
x_21 = x_25;
goto block_24;
}
else
{
uint8_t x_26; 
x_26 = !lean_is_exclusive(x_6);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; 
x_27 = lean_ctor_get(x_6, 0);
x_28 = l_Lean_Json_getNat_x3f(x_27);
if (lean_obj_tag(x_28) == 0)
{
uint8_t x_29; 
lean_free_object(x_6);
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_7);
x_29 = !lean_is_exclusive(x_28);
if (x_29 == 0)
{
return x_28;
}
else
{
lean_object* x_30; lean_object* x_31; 
x_30 = lean_ctor_get(x_28, 0);
lean_inc(x_30);
lean_dec(x_28);
x_31 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_31, 0, x_30);
return x_31;
}
}
else
{
lean_object* x_32; 
x_32 = lean_ctor_get(x_28, 0);
lean_inc(x_32);
lean_dec_ref(x_28);
lean_ctor_set(x_6, 0, x_32);
x_21 = x_6;
goto block_24;
}
}
else
{
lean_object* x_33; lean_object* x_34; 
x_33 = lean_ctor_get(x_6, 0);
lean_inc(x_33);
lean_dec(x_6);
x_34 = l_Lean_Json_getNat_x3f(x_33);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_7);
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
if (lean_is_exclusive(x_34)) {
 lean_ctor_release(x_34, 0);
 x_36 = x_34;
} else {
 lean_dec_ref(x_34);
 x_36 = lean_box(0);
}
if (lean_is_scalar(x_36)) {
 x_37 = lean_alloc_ctor(0, 1, 0);
} else {
 x_37 = x_36;
}
lean_ctor_set(x_37, 0, x_35);
return x_37;
}
else
{
lean_object* x_38; lean_object* x_39; 
x_38 = lean_ctor_get(x_34, 0);
lean_inc(x_38);
lean_dec_ref(x_34);
x_39 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_39, 0, x_38);
x_21 = x_39;
goto block_24;
}
}
}
block_24:
{
lean_object* x_22; lean_object* x_23; 
if (lean_is_scalar(x_7)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_7;
}
lean_ctor_set(x_22, 0, x_19);
lean_ctor_set(x_22, 1, x_21);
if (lean_is_scalar(x_20)) {
 x_23 = lean_alloc_ctor(1, 1, 0);
} else {
 x_23 = x_20;
}
lean_ctor_set(x_23, 0, x_22);
return x_23;
}
}
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableAnimatedHtmlProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableAnimatedHtmlProps_enc____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableAnimatedHtmlProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableAnimatedHtmlProps_dec____x40_ProofWidgets_Demos_Plot_2225017344____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableAnimatedHtmlProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableAnimatedHtmlProps___closed__1;
x_2 = l_instRpcEncodableAnimatedHtmlProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableAnimatedHtmlProps() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableAnimatedHtmlProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_AnimatedHtml___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as o,EnvPosContext as a,useAsyncPersistent as s,mapRpcError as i,importWidgetModule as c}from\"@leanprover/infoview\";async function l(o,a,s){if(\"text\"in s)return t(n,{children:s.text});if(\"element\"in s){const[e,n,i]=s.element,c={};for(const[e,t]of n)c[e]=t;const m=await Promise.all(i.map((async e=>await l(o,a,e))));return\"hr\"===e\?t(\"hr\",{}):0===m.length\?r.createElement(e,c):r.createElement(e,c,m)}if(\"component\"in s){const[e,t,n,i]=s.component,m=await Promise.all(i.map((async e=>await l(o,a,e)))),f={...n,pos:a},d=await c(o,a,e);if(!(t in d))throw new Error(`Module '${e}' does not export '${t}'`);return 0===m.length\?r.createElement(d[t],f):r.createElement(d[t],f,m)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(s)]})}function m({html:c}){const m=o(),f=r.useContext(a),d=s((()=>l(m,f,c)),[m,f,c]);return\"resolved\"===d.state\?d.value:\"rejected\"===d.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",i(d.error).message]}):t(n,{})}function f(e){const{frames:n}=e,o=e.framesPerSecond\?\?10;if(o<=0||o>60)throw new Error(`Invalid fps ${o}. Should be between 0 and 60.`);const[a,s]=r.useState(0);r.useEffect((()=>{const e=window.setInterval((()=>s((e=>e+1))),1e3/o);return()=>window.clearInterval(e)}),[o]);const i=n[a%n.length];return t(m,{html:i})}export{f as default};", 1437, 1437);
return x_1;
}
}
static uint64_t _init_l_AnimatedHtml___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_AnimatedHtml___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_AnimatedHtml___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_AnimatedHtml___closed__1;
x_2 = l_AnimatedHtml___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_AnimatedHtml___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_AnimatedHtml___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_AnimatedHtml___closed__3;
x_2 = l_AnimatedHtml___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_AnimatedHtml() {
_start:
{
lean_object* x_1; 
x_1 = l_AnimatedHtml___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Recharts(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Plot(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Recharts(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_fn___closed__0 = _init_l_fn___closed__0();
l_fn___closed__1 = _init_l_fn___closed__1();
l_fn___closed__2 = _init_l_fn___closed__2();
l_fn___closed__3 = _init_l_fn___closed__3();
l_fn___closed__4 = _init_l_fn___closed__4();
l_fn___closed__5 = _init_l_fn___closed__5();
l_fn___closed__6 = _init_l_fn___closed__6();
l_fn___closed__7 = _init_l_fn___closed__7();
l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0 = _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__0);
l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1 = _init_l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Plot_spec__1___closed__1);
l_Plot___closed__0 = _init_l_Plot___closed__0();
lean_mark_persistent(l_Plot___closed__0);
l_Plot___closed__1 = _init_l_Plot___closed__1();
lean_mark_persistent(l_Plot___closed__1);
l_Plot___closed__2 = _init_l_Plot___closed__2();
lean_mark_persistent(l_Plot___closed__2);
l_Plot___closed__3 = _init_l_Plot___closed__3();
lean_mark_persistent(l_Plot___closed__3);
l_Plot___closed__4 = _init_l_Plot___closed__4();
lean_mark_persistent(l_Plot___closed__4);
l_Plot___closed__5 = _init_l_Plot___closed__5();
lean_mark_persistent(l_Plot___closed__5);
l_Plot___closed__6 = _init_l_Plot___closed__6();
lean_mark_persistent(l_Plot___closed__6);
l_Plot___closed__7 = _init_l_Plot___closed__7();
lean_mark_persistent(l_Plot___closed__7);
l_Plot___closed__8 = _init_l_Plot___closed__8();
lean_mark_persistent(l_Plot___closed__8);
l_Plot___closed__9 = _init_l_Plot___closed__9();
lean_mark_persistent(l_Plot___closed__9);
l_Plot___closed__10 = _init_l_Plot___closed__10();
lean_mark_persistent(l_Plot___closed__10);
l_Plot___closed__11 = _init_l_Plot___closed__11();
lean_mark_persistent(l_Plot___closed__11);
l_Plot___closed__12 = _init_l_Plot___closed__12();
lean_mark_persistent(l_Plot___closed__12);
l_Plot___closed__13 = _init_l_Plot___closed__13();
lean_mark_persistent(l_Plot___closed__13);
l_Plot___closed__14 = _init_l_Plot___closed__14();
lean_mark_persistent(l_Plot___closed__14);
l_Plot___closed__15 = _init_l_Plot___closed__15();
lean_mark_persistent(l_Plot___closed__15);
l_Plot___closed__16 = _init_l_Plot___closed__16();
lean_mark_persistent(l_Plot___closed__16);
l_Plot___closed__17 = _init_l_Plot___closed__17();
lean_mark_persistent(l_Plot___closed__17);
l_Plot___closed__18 = _init_l_Plot___closed__18();
lean_mark_persistent(l_Plot___closed__18);
l_Plot___closed__19 = _init_l_Plot___closed__19();
lean_mark_persistent(l_Plot___closed__19);
l_Plot___closed__20 = _init_l_Plot___closed__20();
lean_mark_persistent(l_Plot___closed__20);
l_Plot___closed__21 = _init_l_Plot___closed__21();
lean_mark_persistent(l_Plot___closed__21);
l_Plot___closed__22 = _init_l_Plot___closed__22();
lean_mark_persistent(l_Plot___closed__22);
l_Plot___closed__23 = _init_l_Plot___closed__23();
lean_mark_persistent(l_Plot___closed__23);
l_Plot___closed__24 = _init_l_Plot___closed__24();
lean_mark_persistent(l_Plot___closed__24);
l_Plot___closed__25 = _init_l_Plot___closed__25();
lean_mark_persistent(l_Plot___closed__25);
l_Plot___closed__26 = _init_l_Plot___closed__26();
lean_mark_persistent(l_Plot___closed__26);
l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_26_);
l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_ = _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_Plot_781805608____hygCtx___hyg_44_);
l_instRpcEncodableAnimatedHtmlProps___closed__0 = _init_l_instRpcEncodableAnimatedHtmlProps___closed__0();
lean_mark_persistent(l_instRpcEncodableAnimatedHtmlProps___closed__0);
l_instRpcEncodableAnimatedHtmlProps___closed__1 = _init_l_instRpcEncodableAnimatedHtmlProps___closed__1();
lean_mark_persistent(l_instRpcEncodableAnimatedHtmlProps___closed__1);
l_instRpcEncodableAnimatedHtmlProps___closed__2 = _init_l_instRpcEncodableAnimatedHtmlProps___closed__2();
lean_mark_persistent(l_instRpcEncodableAnimatedHtmlProps___closed__2);
l_instRpcEncodableAnimatedHtmlProps = _init_l_instRpcEncodableAnimatedHtmlProps();
lean_mark_persistent(l_instRpcEncodableAnimatedHtmlProps);
l_AnimatedHtml___closed__0 = _init_l_AnimatedHtml___closed__0();
lean_mark_persistent(l_AnimatedHtml___closed__0);
l_AnimatedHtml___closed__1 = _init_l_AnimatedHtml___closed__1();
l_AnimatedHtml___closed__2 = _init_l_AnimatedHtml___closed__2();
lean_mark_persistent(l_AnimatedHtml___closed__2);
l_AnimatedHtml___closed__3 = _init_l_AnimatedHtml___closed__3();
lean_mark_persistent(l_AnimatedHtml___closed__3);
l_AnimatedHtml___closed__4 = _init_l_AnimatedHtml___closed__4();
lean_mark_persistent(l_AnimatedHtml___closed__4);
l_AnimatedHtml = _init_l_AnimatedHtml();
lean_mark_persistent(l_AnimatedHtml);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
