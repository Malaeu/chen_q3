// Lean compiler output
// Module: ProofWidgets.Component.FilterDetails
// Imports: Init ProofWidgets.Data.Html
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets_FilterDetails___closed__0;
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_(lean_object*);
static lean_object* l_ProofWidgets_FilterDetails___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_FilterDetails;
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
uint64_t lean_string_hash(lean_object*);
lean_object* l_Lean_Json_getBool_x3f(lean_object*);
static lean_object* l_ProofWidgets_FilterDetails___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_FilterDetailsProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_enc____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59____boxed(lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_;
static lean_object* l_ProofWidgets_FilterDetails___closed__2;
static lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_;
lean_object* l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
static lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_FilterDetailsProps_ctorIdx___boxed(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1__ctorIdx(lean_object*);
static uint64_t l_ProofWidgets_FilterDetails___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
LEAN_EXPORT lean_object* l_ProofWidgets_FilterDetailsProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_FilterDetailsProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_FilterDetailsProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("summary", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("filtered", 8, 8);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("all", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("initiallyFiltered", 17, 17);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_1);
x_6 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec_ref(x_6);
x_8 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_1);
x_9 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec_ref(x_9);
x_11 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
x_12 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_11);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_15, 0, x_4);
lean_ctor_set(x_15, 1, x_7);
lean_ctor_set(x_15, 2, x_10);
lean_ctor_set(x_15, 3, x_14);
lean_ctor_set(x_12, 0, x_15);
return x_12;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_12, 0);
lean_inc(x_16);
lean_dec(x_12);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_4);
lean_ctor_set(x_17, 1, x_7);
lean_ctor_set(x_17, 2, x_10);
lean_ctor_set(x_17, 3, x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = lean_ctor_get(x_1, 3);
x_6 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_2);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_2);
x_8 = lean_box(0);
x_9 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_3);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_3);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
x_13 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_4);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_4);
x_15 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_8);
x_16 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_;
lean_inc(x_5);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_5);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_8);
x_19 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_8);
x_20 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_20, 0, x_15);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_12);
lean_ctor_set(x_21, 1, x_20);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_9);
lean_ctor_set(x_22, 1, x_21);
x_23 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_;
x_24 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_22, x_23);
x_25 = l_Lean_Json_mkObj(x_24);
return x_25;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_enc____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; uint8_t x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_4);
x_5 = lean_ctor_get(x_1, 2);
lean_inc_ref(x_5);
x_6 = lean_ctor_get_uint8(x_1, sizeof(void*)*3);
lean_dec_ref(x_1);
x_7 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_3, x_2);
x_8 = lean_ctor_get(x_7, 0);
lean_inc(x_8);
x_9 = lean_ctor_get(x_7, 1);
lean_inc(x_9);
lean_dec_ref(x_7);
x_10 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_4, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec_ref(x_10);
x_13 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_5, x_12);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_16, 0, x_6);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_8);
lean_ctor_set(x_17, 1, x_11);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_16);
x_18 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_(x_17);
lean_dec_ref(x_17);
lean_ctor_set(x_13, 0, x_18);
return x_13;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_19 = lean_ctor_get(x_13, 0);
x_20 = lean_ctor_get(x_13, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_13);
x_21 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_21, 0, x_6);
x_22 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_22, 0, x_8);
lean_ctor_set(x_22, 1, x_11);
lean_ctor_set(x_22, 2, x_19);
lean_ctor_set(x_22, 3, x_21);
x_23 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_(x_22);
lean_dec_ref(x_22);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_20);
return x_24;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_3 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_4, 3);
lean_inc(x_8);
lean_dec(x_4);
x_9 = l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_5, x_2);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec_ref(x_9);
x_14 = l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_6, x_2);
if (lean_obj_tag(x_14) == 0)
{
uint8_t x_15; 
lean_dec(x_13);
lean_dec(x_8);
lean_dec(x_7);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
return x_14;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
else
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_14, 0);
lean_inc(x_18);
lean_dec_ref(x_14);
x_19 = l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_7, x_2);
if (lean_obj_tag(x_19) == 0)
{
uint8_t x_20; 
lean_dec(x_18);
lean_dec(x_13);
lean_dec(x_8);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
return x_19;
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_19, 0);
lean_inc(x_21);
lean_dec(x_19);
x_22 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_22, 0, x_21);
return x_22;
}
}
else
{
lean_object* x_23; lean_object* x_24; 
x_23 = lean_ctor_get(x_19, 0);
lean_inc(x_23);
lean_dec_ref(x_19);
x_24 = l_Lean_Json_getBool_x3f(x_8);
lean_dec(x_8);
if (lean_obj_tag(x_24) == 0)
{
uint8_t x_25; 
lean_dec(x_23);
lean_dec(x_18);
lean_dec(x_13);
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
return x_24;
}
else
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_24, 0);
lean_inc(x_26);
lean_dec(x_24);
x_27 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_27, 0, x_26);
return x_27;
}
}
else
{
uint8_t x_28; 
x_28 = !lean_is_exclusive(x_24);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; uint8_t x_31; 
x_29 = lean_ctor_get(x_24, 0);
x_30 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_30, 0, x_13);
lean_ctor_set(x_30, 1, x_18);
lean_ctor_set(x_30, 2, x_23);
x_31 = lean_unbox(x_29);
lean_dec(x_29);
lean_ctor_set_uint8(x_30, sizeof(void*)*3, x_31);
lean_ctor_set(x_24, 0, x_30);
return x_24;
}
else
{
lean_object* x_32; lean_object* x_33; uint8_t x_34; lean_object* x_35; 
x_32 = lean_ctor_get(x_24, 0);
lean_inc(x_32);
lean_dec(x_24);
x_33 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_33, 0, x_13);
lean_ctor_set(x_33, 1, x_18);
lean_ctor_set(x_33, 2, x_23);
x_34 = lean_unbox(x_32);
lean_dec(x_32);
lean_ctor_set_uint8(x_33, sizeof(void*)*3, x_34);
x_35 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_35, 0, x_33);
return x_35;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableFilterDetailsProps_enc____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableFilterDetailsProps_dec____x40_ProofWidgets_Component_FilterDetails_2598060976____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_FilterDetails___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as o,EnvPosContext as a,useAsyncPersistent as i,mapRpcError as l,importWidgetModule as c}from\"@leanprover/infoview\";async function s(o,a,i){if(\"text\"in i)return t(n,{children:i.text});if(\"element\"in i){const[e,n,l]=i.element,c={};for(const[e,t]of n)c[e]=t;const m=await Promise.all(l.map((async e=>await s(o,a,e))));return\"hr\"===e\?t(\"hr\",{}):0===m.length\?r.createElement(e,c):r.createElement(e,c,m)}if(\"component\"in i){const[e,t,n,l]=i.component,m=await Promise.all(l.map((async e=>await s(o,a,e)))),d={...n,pos:a},f=await c(o,a,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===m.length\?r.createElement(f[t],d):r.createElement(f[t],d,m)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(i)]})}function m({html:c}){const m=o(),d=r.useContext(a),f=i((()=>s(m,d,c)),[m,d,c]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",l(f.error).message]}):t(n,{})}function d(n){const[o,a]=r.useState(n.initiallyFiltered);return e(\"details\",{open:!0,children:[e(\"summary\",{className:\"mv2 pointer\",children:[t(m,{html:n.summary}),t(\"span\",{className:\"fr\",onClick:e=>{e.preventDefault()},children:t(\"a\",{className:\"link pointer mh2 dim codicon \"+(o\?\"codicon-filter-filled \":\"codicon-filter \"),title:o\?\"Show more content\":\"Show less content\",onClick:e=>{a((e=>!e))}})})]}),t(m,{html:o\?n.filtered:n.all})]})}export{d as default};", 1562, 1562);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_FilterDetails___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_FilterDetails___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_FilterDetails___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_FilterDetails___closed__1;
x_2 = l_ProofWidgets_FilterDetails___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_FilterDetails___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_FilterDetails___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_FilterDetails___closed__3;
x_2 = l_ProofWidgets_FilterDetails___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_FilterDetails() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_FilterDetails___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_FilterDetails(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_41_);
l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_FilterDetails_2933785032____hygCtx___hyg_59_);
l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__0);
l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__1);
l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableFilterDetailsProps___closed__2);
l_ProofWidgets_instRpcEncodableFilterDetailsProps = _init_l_ProofWidgets_instRpcEncodableFilterDetailsProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableFilterDetailsProps);
l_ProofWidgets_FilterDetails___closed__0 = _init_l_ProofWidgets_FilterDetails___closed__0();
lean_mark_persistent(l_ProofWidgets_FilterDetails___closed__0);
l_ProofWidgets_FilterDetails___closed__1 = _init_l_ProofWidgets_FilterDetails___closed__1();
l_ProofWidgets_FilterDetails___closed__2 = _init_l_ProofWidgets_FilterDetails___closed__2();
lean_mark_persistent(l_ProofWidgets_FilterDetails___closed__2);
l_ProofWidgets_FilterDetails___closed__3 = _init_l_ProofWidgets_FilterDetails___closed__3();
lean_mark_persistent(l_ProofWidgets_FilterDetails___closed__3);
l_ProofWidgets_FilterDetails___closed__4 = _init_l_ProofWidgets_FilterDetails___closed__4();
lean_mark_persistent(l_ProofWidgets_FilterDetails___closed__4);
l_ProofWidgets_FilterDetails = _init_l_ProofWidgets_FilterDetails();
lean_mark_persistent(l_ProofWidgets_FilterDetails);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
