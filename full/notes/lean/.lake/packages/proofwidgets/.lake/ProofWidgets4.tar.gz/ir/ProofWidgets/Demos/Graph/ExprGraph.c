// Lean compiler output
// Module: ProofWidgets.Demos.Graph.ExprGraph
// Imports: Init ProofWidgets.Component.GraphDisplay ProofWidgets.Component.HtmlDisplay Lean.Util.FoldConsts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__9;
static lean_object* l_elabExprGraphCmd___lam__1___closed__22;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_elabExprGraphCmd___closed__0;
static lean_object* l_exprGraphCmd___closed__6;
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7(lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_InteractiveCode;
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__25;
static lean_object* l_elabExprGraphCmd___lam__1___closed__13;
uint64_t lean_uint64_mix_hash(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg___boxed(lean_object*, lean_object*);
lean_object* l_Lean_findDocString_x3f(lean_object*, lean_object*, uint8_t, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
lean_object* lean_array_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25;
lean_object* l_Lean_ConstantInfo_getUsedConstantsAsSet(lean_object*);
static lean_object* l_foo___closed__2;
lean_object* lean_mk_array(lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__0;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24;
static lean_object* l_elabExprGraphCmd___lam__1___closed__18;
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__3;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Environment_find_x3f(lean_object*, lean_object*, uint8_t);
static lean_object* l_elabExprGraphCmd___lam__1___closed__12;
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__27;
static lean_object* l_elabExprGraphCmd___lam__0___closed__0;
uint64_t lean_string_hash(lean_object*);
static lean_object* l_foo___closed__1;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__15;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7;
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
static lean_object* l_elabExprGraphCmd___lam__1___closed__11;
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__5;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_foo___boxed(lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__7;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5___boxed(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_exprGraphCmd___closed__10;
lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18;
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
extern lean_object* l_ProofWidgets_MarkdownDisplay;
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_Lean_MessageData_ofSyntax(lean_object*);
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29;
static lean_object* l_exprGraphCmd___closed__7;
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8___redArg(lean_object*);
LEAN_EXPORT lean_object* l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_a;
double lean_float_of_nat(lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_HtmlDisplayPanel;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23;
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28;
static lean_object* l_elabExprGraphCmd___lam__1___closed__8;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(lean_object*, uint8_t, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_realizeGlobalConstNoOverloadWithInfo(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__24;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_foo___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6;
static lean_object* l_exprGraphCmd___closed__3;
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_exprGraphCmd;
static lean_object* l_elabExprGraphCmd___lam__1___closed__14;
static lean_object* l_elabExprGraphCmd___lam__1___closed__17;
LEAN_EXPORT lean_object* l_b;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8(lean_object*, lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__1;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
double l_Float_ofScientific(lean_object*, uint8_t, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__6;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__26;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instBEqProd___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_length(lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_Meta_mkFreshLevelMVarsFor(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__19;
static lean_object* l_elabExprGraphCmd___lam__1___closed__9;
lean_object* l_String_hash___boxed(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__21;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__1;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13;
static lean_object* l_elabExprGraphCmd___lam__1___closed__4;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__10;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
extern lean_object* l_ProofWidgets_GraphDisplay;
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
uint64_t lean_uint64_xor(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11;
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t l_Std_DTreeMap_Internal_Impl_contains___at___Lean_NameMap_contains_spec__0___redArg(lean_object*, lean_object*);
lean_object* l_ProofWidgets_GraphDisplay_instRpcEncodableProps_enc____x40_ProofWidgets_Component_GraphDisplay_1995342541____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_foldlM___at___Std_DTreeMap_Internal_Impl_foldl___at_____private_Lean_Elab_DocString_0__Lean_Doc_codeSuggestionsUnsafe_spec__2_spec__2(lean_object*, lean_object*);
size_t lean_usize_sub(size_t, size_t);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15;
lean_object* l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__16;
size_t lean_usize_add(size_t, size_t);
static lean_object* l_exprGraphCmd___closed__2;
static lean_object* l_exprGraphCmd___closed__8;
static lean_object* l_elabExprGraphCmd___lam__1___closed__23;
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
lean_object* l_instHashableProd___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_foo(lean_object*);
static lean_object* l_elabExprGraphCmd___closed__1;
lean_object* l_Lean_Elab_Command_runTermElabM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_elabExprGraphCmd(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_int_ediv(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(lean_object*, uint8_t, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
static double l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
static lean_object* l_exprGraphCmd___closed__4;
static lean_object* l_elabExprGraphCmd___lam__1___closed__0;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(lean_object*, uint8_t, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__20;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__5;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8___redArg(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_instDecidableEqString___boxed(lean_object*, lean_object*);
size_t lean_usize_land(size_t, size_t);
LEAN_EXPORT lean_object* l_elabExprGraphCmd___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
static lean_object* _init_l_exprGraphCmd___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("exprGraphCmd", 12, 12);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__2;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("#expr_graph", 11, 11);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__4;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ident", 5, 5);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__6;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__7;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_exprGraphCmd___closed__8;
x_2 = l_exprGraphCmd___closed__5;
x_3 = l_exprGraphCmd___closed__3;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_exprGraphCmd___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_exprGraphCmd___closed__9;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_exprGraphCmd___closed__1;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_exprGraphCmd() {
_start:
{
lean_object* x_1; 
x_1 = l_exprGraphCmd___closed__10;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_string_hash(x_6);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_8, 0, x_2);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("g", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ellipse", 7, 7);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fill", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editor-background)", 31, 31);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("stroke", 6, 6);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editorHoverWidget-border)", 38, 38);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rx", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ry", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("10", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("text", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("x", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("-", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("y", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("5", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("font-code", 9, 9);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static double _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(20u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" : ", 3, 3);
return x_1;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(lean_object* x_1, uint8_t x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; uint8_t x_18; 
x_18 = lean_usize_dec_lt(x_5, x_4);
if (x_18 == 0)
{
lean_object* x_19; 
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_1);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_6);
lean_ctor_set(x_19, 1, x_11);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; 
x_20 = lean_ctor_get(x_6, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_6, 1);
lean_inc(x_21);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 lean_ctor_release(x_6, 1);
 x_22 = x_6;
} else {
 lean_dec_ref(x_6);
 x_22 = lean_box(0);
}
x_23 = lean_array_uget(x_3, x_5);
x_24 = 0;
lean_inc(x_23);
lean_inc_ref(x_1);
x_25 = l_Lean_Environment_find_x3f(x_1, x_23, x_24);
if (lean_obj_tag(x_25) == 0)
{
lean_object* x_26; 
lean_dec(x_23);
if (lean_is_scalar(x_22)) {
 x_26 = lean_alloc_ctor(0, 2, 0);
} else {
 x_26 = x_22;
}
lean_ctor_set(x_26, 0, x_20);
lean_ctor_set(x_26, 1, x_21);
x_12 = x_26;
x_13 = x_11;
goto block_17;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_27 = lean_ctor_get(x_25, 0);
lean_inc(x_27);
if (lean_is_exclusive(x_25)) {
 lean_ctor_release(x_25, 0);
 x_28 = x_25;
} else {
 lean_dec_ref(x_25);
 x_28 = lean_box(0);
}
lean_inc(x_23);
lean_inc_ref(x_1);
x_29 = l_Lean_findDocString_x3f(x_1, x_23, x_2, x_11);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_30 = lean_ctor_get(x_29, 0);
lean_inc(x_30);
x_31 = lean_ctor_get(x_29, 1);
lean_inc(x_31);
lean_dec_ref(x_29);
x_32 = l_Lean_ConstantInfo_type(x_27);
x_33 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
lean_inc(x_10);
lean_inc_ref(x_9);
lean_inc(x_8);
lean_inc_ref(x_7);
x_34 = l_Lean_Widget_ppExprTagged(x_32, x_33, x_7, x_8, x_9, x_10, x_31);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec_ref(x_34);
x_37 = l_Lean_Meta_mkFreshLevelMVarsFor(x_27, x_7, x_8, x_9, x_10, x_36);
lean_dec(x_27);
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 x_40 = x_37;
} else {
 lean_dec_ref(x_37);
 x_40 = lean_box(0);
}
lean_inc(x_23);
x_41 = l_Lean_Expr_const___override(x_23, x_38);
lean_inc(x_10);
lean_inc_ref(x_9);
lean_inc(x_8);
lean_inc_ref(x_7);
x_42 = l_Lean_Widget_ppExprTagged(x_41, x_33, x_7, x_8, x_9, x_10, x_39);
if (lean_obj_tag(x_42) == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; uint8_t x_138; 
x_43 = lean_ctor_get(x_42, 0);
lean_inc(x_43);
x_44 = lean_ctor_get(x_42, 1);
lean_inc(x_44);
lean_dec_ref(x_42);
x_45 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_23, x_2);
x_54 = lean_string_length(x_45);
x_55 = lean_unsigned_to_nat(3u);
x_56 = lean_nat_mul(x_54, x_55);
lean_dec(x_54);
x_138 = lean_nat_dec_le(x_20, x_56);
if (x_138 == 0)
{
x_57 = x_20;
goto block_137;
}
else
{
lean_dec(x_20);
lean_inc(x_56);
x_57 = x_56;
goto block_137;
}
block_53:
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_50 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_50, 0, x_45);
lean_ctor_set(x_50, 1, x_46);
lean_ctor_set(x_50, 2, x_47);
lean_ctor_set(x_50, 3, x_49);
x_51 = lean_array_push(x_21, x_50);
if (lean_is_scalar(x_22)) {
 x_52 = lean_alloc_ctor(0, 2, 0);
} else {
 x_52 = x_22;
}
lean_ctor_set(x_52, 0, x_48);
lean_ctor_set(x_52, 1, x_51);
x_12 = x_52;
x_13 = x_44;
goto block_17;
}
block_137:
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; double x_96; double x_97; lean_object* x_98; 
x_58 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
x_59 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_60 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
x_61 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
x_62 = lean_unsigned_to_nat(2u);
x_63 = lean_nat_mul(x_56, x_62);
x_64 = l_Lean_JsonNumber_fromNat(x_63);
x_65 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_65, 0, x_64);
if (lean_is_scalar(x_40)) {
 x_66 = lean_alloc_ctor(0, 2, 0);
} else {
 x_66 = x_40;
}
lean_ctor_set(x_66, 0, x_61);
lean_ctor_set(x_66, 1, x_65);
x_67 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
x_68 = lean_unsigned_to_nat(4u);
x_69 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_70 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
x_71 = lean_array_push(x_70, x_66);
x_72 = lean_array_push(x_71, x_67);
x_73 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_73, 0, x_60);
lean_ctor_set(x_73, 1, x_72);
lean_ctor_set(x_73, 2, x_59);
x_74 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
x_75 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
x_76 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
lean_inc(x_56);
x_77 = l_Nat_reprFast(x_56);
x_78 = lean_string_append(x_76, x_77);
lean_dec_ref(x_77);
x_79 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_79, 0, x_78);
x_80 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_80, 0, x_75);
lean_ctor_set(x_80, 1, x_79);
x_81 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
x_82 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
x_83 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
x_84 = lean_array_push(x_83, x_80);
x_85 = lean_array_push(x_84, x_81);
x_86 = lean_array_push(x_85, x_82);
lean_inc_ref(x_45);
x_87 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_87, 0, x_45);
x_88 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
x_89 = lean_array_push(x_88, x_87);
x_90 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_90, 0, x_74);
lean_ctor_set(x_90, 1, x_86);
lean_ctor_set(x_90, 2, x_89);
x_91 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
x_92 = lean_array_push(x_91, x_73);
x_93 = lean_array_push(x_92, x_90);
x_94 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_94, 0, x_58);
lean_ctor_set(x_94, 1, x_59);
lean_ctor_set(x_94, 2, x_93);
x_95 = lean_nat_mul(x_56, x_68);
lean_dec(x_56);
x_96 = lean_float_of_nat(x_95);
x_97 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
x_98 = lean_alloc_ctor(1, 0, 16);
lean_ctor_set_float(x_98, 0, x_96);
lean_ctor_set_float(x_98, 8, x_97);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; 
x_99 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
x_100 = l_ProofWidgets_InteractiveCode;
x_101 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_100, x_43, x_59);
x_102 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_103 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_100, x_35, x_59);
x_104 = lean_array_push(x_83, x_101);
x_105 = lean_array_push(x_104, x_102);
x_106 = lean_array_push(x_105, x_103);
x_107 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_107, 0, x_99);
lean_ctor_set(x_107, 1, x_59);
lean_ctor_set(x_107, 2, x_106);
if (lean_is_scalar(x_28)) {
 x_108 = lean_alloc_ctor(1, 1, 0);
} else {
 x_108 = x_28;
}
lean_ctor_set(x_108, 0, x_107);
x_46 = x_94;
x_47 = x_98;
x_48 = x_57;
x_49 = x_108;
goto block_53;
}
else
{
uint8_t x_109; 
lean_dec(x_28);
x_109 = !lean_is_exclusive(x_30);
if (x_109 == 0)
{
lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_110 = lean_ctor_get(x_30, 0);
x_111 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_112 = l_ProofWidgets_InteractiveCode;
x_113 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_112, x_43, x_59);
x_114 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_115 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_112, x_35, x_59);
x_116 = l_ProofWidgets_MarkdownDisplay;
x_117 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_116, x_110, x_59);
x_118 = lean_array_push(x_69, x_113);
x_119 = lean_array_push(x_118, x_114);
x_120 = lean_array_push(x_119, x_115);
x_121 = lean_array_push(x_120, x_117);
x_122 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_122, 0, x_111);
lean_ctor_set(x_122, 1, x_59);
lean_ctor_set(x_122, 2, x_121);
lean_ctor_set(x_30, 0, x_122);
x_46 = x_94;
x_47 = x_98;
x_48 = x_57;
x_49 = x_30;
goto block_53;
}
else
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; 
x_123 = lean_ctor_get(x_30, 0);
lean_inc(x_123);
lean_dec(x_30);
x_124 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_125 = l_ProofWidgets_InteractiveCode;
x_126 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_125, x_43, x_59);
x_127 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_128 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_125, x_35, x_59);
x_129 = l_ProofWidgets_MarkdownDisplay;
x_130 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_129, x_123, x_59);
x_131 = lean_array_push(x_69, x_126);
x_132 = lean_array_push(x_131, x_127);
x_133 = lean_array_push(x_132, x_128);
x_134 = lean_array_push(x_133, x_130);
x_135 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_135, 0, x_124);
lean_ctor_set(x_135, 1, x_59);
lean_ctor_set(x_135, 2, x_134);
x_136 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_136, 0, x_135);
x_46 = x_94;
x_47 = x_98;
x_48 = x_57;
x_49 = x_136;
goto block_53;
}
}
}
}
else
{
uint8_t x_139; 
lean_dec(x_40);
lean_dec(x_35);
lean_dec(x_30);
lean_dec(x_28);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_1);
x_139 = !lean_is_exclusive(x_42);
if (x_139 == 0)
{
return x_42;
}
else
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; 
x_140 = lean_ctor_get(x_42, 0);
x_141 = lean_ctor_get(x_42, 1);
lean_inc(x_141);
lean_inc(x_140);
lean_dec(x_42);
x_142 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_142, 0, x_140);
lean_ctor_set(x_142, 1, x_141);
return x_142;
}
}
}
else
{
uint8_t x_143; 
lean_dec(x_30);
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_1);
x_143 = !lean_is_exclusive(x_34);
if (x_143 == 0)
{
return x_34;
}
else
{
lean_object* x_144; lean_object* x_145; lean_object* x_146; 
x_144 = lean_ctor_get(x_34, 0);
x_145 = lean_ctor_get(x_34, 1);
lean_inc(x_145);
lean_inc(x_144);
lean_dec(x_34);
x_146 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_146, 0, x_144);
lean_ctor_set(x_146, 1, x_145);
return x_146;
}
}
}
else
{
uint8_t x_147; 
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_10);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_1);
x_147 = !lean_is_exclusive(x_29);
if (x_147 == 0)
{
lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; 
x_148 = lean_ctor_get(x_29, 0);
x_149 = lean_ctor_get(x_9, 5);
lean_inc(x_149);
lean_dec_ref(x_9);
x_150 = lean_io_error_to_string(x_148);
x_151 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_151, 0, x_150);
x_152 = l_Lean_MessageData_ofFormat(x_151);
x_153 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_153, 0, x_149);
lean_ctor_set(x_153, 1, x_152);
lean_ctor_set(x_29, 0, x_153);
return x_29;
}
else
{
lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; lean_object* x_161; 
x_154 = lean_ctor_get(x_29, 0);
x_155 = lean_ctor_get(x_29, 1);
lean_inc(x_155);
lean_inc(x_154);
lean_dec(x_29);
x_156 = lean_ctor_get(x_9, 5);
lean_inc(x_156);
lean_dec_ref(x_9);
x_157 = lean_io_error_to_string(x_154);
x_158 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_158, 0, x_157);
x_159 = l_Lean_MessageData_ofFormat(x_158);
x_160 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_160, 0, x_156);
lean_ctor_set(x_160, 1, x_159);
x_161 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_161, 0, x_160);
lean_ctor_set(x_161, 1, x_155);
return x_161;
}
}
}
}
block_17:
{
size_t x_14; size_t x_15; 
x_14 = 1;
x_15 = lean_usize_add(x_5, x_14);
x_5 = x_15;
x_6 = x_12;
x_11 = x_13;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(lean_object* x_1, uint8_t x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; 
x_14 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_9, x_10, x_11, x_12, x_13);
return x_14;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(lean_object* x_1, uint8_t x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; lean_object* x_15; uint8_t x_20; 
x_20 = lean_usize_dec_lt(x_5, x_4);
if (x_20 == 0)
{
lean_object* x_21; 
lean_dec(x_12);
lean_dec_ref(x_11);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec_ref(x_1);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_6);
lean_ctor_set(x_21, 1, x_13);
return x_21;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; lean_object* x_27; 
x_22 = lean_ctor_get(x_6, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_6, 1);
lean_inc(x_23);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 lean_ctor_release(x_6, 1);
 x_24 = x_6;
} else {
 lean_dec_ref(x_6);
 x_24 = lean_box(0);
}
x_25 = lean_array_uget(x_3, x_5);
x_26 = 0;
lean_inc(x_25);
lean_inc_ref(x_1);
x_27 = l_Lean_Environment_find_x3f(x_1, x_25, x_26);
if (lean_obj_tag(x_27) == 0)
{
lean_object* x_28; 
lean_dec(x_25);
if (lean_is_scalar(x_24)) {
 x_28 = lean_alloc_ctor(0, 2, 0);
} else {
 x_28 = x_24;
}
lean_ctor_set(x_28, 0, x_22);
lean_ctor_set(x_28, 1, x_23);
x_14 = x_28;
x_15 = x_13;
goto block_19;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_29 = lean_ctor_get(x_27, 0);
lean_inc(x_29);
if (lean_is_exclusive(x_27)) {
 lean_ctor_release(x_27, 0);
 x_30 = x_27;
} else {
 lean_dec_ref(x_27);
 x_30 = lean_box(0);
}
lean_inc(x_25);
lean_inc_ref(x_1);
x_31 = l_Lean_findDocString_x3f(x_1, x_25, x_2, x_13);
if (lean_obj_tag(x_31) == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
lean_dec_ref(x_31);
x_34 = l_Lean_ConstantInfo_type(x_29);
x_35 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
lean_inc(x_12);
lean_inc_ref(x_11);
lean_inc(x_10);
lean_inc_ref(x_9);
x_36 = l_Lean_Widget_ppExprTagged(x_34, x_35, x_9, x_10, x_11, x_12, x_33);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec_ref(x_36);
x_39 = l_Lean_Meta_mkFreshLevelMVarsFor(x_29, x_9, x_10, x_11, x_12, x_38);
lean_dec(x_29);
x_40 = lean_ctor_get(x_39, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_39, 1);
lean_inc(x_41);
if (lean_is_exclusive(x_39)) {
 lean_ctor_release(x_39, 0);
 lean_ctor_release(x_39, 1);
 x_42 = x_39;
} else {
 lean_dec_ref(x_39);
 x_42 = lean_box(0);
}
lean_inc(x_25);
x_43 = l_Lean_Expr_const___override(x_25, x_40);
lean_inc(x_12);
lean_inc_ref(x_11);
lean_inc(x_10);
lean_inc_ref(x_9);
x_44 = l_Lean_Widget_ppExprTagged(x_43, x_35, x_9, x_10, x_11, x_12, x_41);
if (lean_obj_tag(x_44) == 0)
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; uint8_t x_140; 
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
x_46 = lean_ctor_get(x_44, 1);
lean_inc(x_46);
lean_dec_ref(x_44);
x_47 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_25, x_2);
x_56 = lean_string_length(x_47);
x_57 = lean_unsigned_to_nat(3u);
x_58 = lean_nat_mul(x_56, x_57);
lean_dec(x_56);
x_140 = lean_nat_dec_le(x_22, x_58);
if (x_140 == 0)
{
x_59 = x_22;
goto block_139;
}
else
{
lean_dec(x_22);
lean_inc(x_58);
x_59 = x_58;
goto block_139;
}
block_55:
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; 
x_52 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_52, 0, x_47);
lean_ctor_set(x_52, 1, x_49);
lean_ctor_set(x_52, 2, x_50);
lean_ctor_set(x_52, 3, x_51);
x_53 = lean_array_push(x_23, x_52);
if (lean_is_scalar(x_24)) {
 x_54 = lean_alloc_ctor(0, 2, 0);
} else {
 x_54 = x_24;
}
lean_ctor_set(x_54, 0, x_48);
lean_ctor_set(x_54, 1, x_53);
x_14 = x_54;
x_15 = x_46;
goto block_19;
}
block_139:
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; double x_98; double x_99; lean_object* x_100; 
x_60 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
x_61 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_62 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
x_63 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
x_64 = lean_unsigned_to_nat(2u);
x_65 = lean_nat_mul(x_58, x_64);
x_66 = l_Lean_JsonNumber_fromNat(x_65);
x_67 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_67, 0, x_66);
if (lean_is_scalar(x_42)) {
 x_68 = lean_alloc_ctor(0, 2, 0);
} else {
 x_68 = x_42;
}
lean_ctor_set(x_68, 0, x_63);
lean_ctor_set(x_68, 1, x_67);
x_69 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
x_70 = lean_unsigned_to_nat(4u);
x_71 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_72 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
x_73 = lean_array_push(x_72, x_68);
x_74 = lean_array_push(x_73, x_69);
x_75 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_75, 0, x_62);
lean_ctor_set(x_75, 1, x_74);
lean_ctor_set(x_75, 2, x_61);
x_76 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
x_77 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
x_78 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
lean_inc(x_58);
x_79 = l_Nat_reprFast(x_58);
x_80 = lean_string_append(x_78, x_79);
lean_dec_ref(x_79);
x_81 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_81, 0, x_80);
x_82 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_82, 0, x_77);
lean_ctor_set(x_82, 1, x_81);
x_83 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
x_84 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
x_85 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
x_86 = lean_array_push(x_85, x_82);
x_87 = lean_array_push(x_86, x_83);
x_88 = lean_array_push(x_87, x_84);
lean_inc_ref(x_47);
x_89 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_89, 0, x_47);
x_90 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
x_91 = lean_array_push(x_90, x_89);
x_92 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_92, 0, x_76);
lean_ctor_set(x_92, 1, x_88);
lean_ctor_set(x_92, 2, x_91);
x_93 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
x_94 = lean_array_push(x_93, x_75);
x_95 = lean_array_push(x_94, x_92);
x_96 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_96, 0, x_60);
lean_ctor_set(x_96, 1, x_61);
lean_ctor_set(x_96, 2, x_95);
x_97 = lean_nat_mul(x_58, x_70);
lean_dec(x_58);
x_98 = lean_float_of_nat(x_97);
x_99 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
x_100 = lean_alloc_ctor(1, 0, 16);
lean_ctor_set_float(x_100, 0, x_98);
lean_ctor_set_float(x_100, 8, x_99);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; 
x_101 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
x_102 = l_ProofWidgets_InteractiveCode;
x_103 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_102, x_45, x_61);
x_104 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_105 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_102, x_37, x_61);
x_106 = lean_array_push(x_85, x_103);
x_107 = lean_array_push(x_106, x_104);
x_108 = lean_array_push(x_107, x_105);
x_109 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_109, 0, x_101);
lean_ctor_set(x_109, 1, x_61);
lean_ctor_set(x_109, 2, x_108);
if (lean_is_scalar(x_30)) {
 x_110 = lean_alloc_ctor(1, 1, 0);
} else {
 x_110 = x_30;
}
lean_ctor_set(x_110, 0, x_109);
x_48 = x_59;
x_49 = x_96;
x_50 = x_100;
x_51 = x_110;
goto block_55;
}
else
{
uint8_t x_111; 
lean_dec(x_30);
x_111 = !lean_is_exclusive(x_32);
if (x_111 == 0)
{
lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; 
x_112 = lean_ctor_get(x_32, 0);
x_113 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_114 = l_ProofWidgets_InteractiveCode;
x_115 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_114, x_45, x_61);
x_116 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_117 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_114, x_37, x_61);
x_118 = l_ProofWidgets_MarkdownDisplay;
x_119 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_118, x_112, x_61);
x_120 = lean_array_push(x_71, x_115);
x_121 = lean_array_push(x_120, x_116);
x_122 = lean_array_push(x_121, x_117);
x_123 = lean_array_push(x_122, x_119);
x_124 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_124, 0, x_113);
lean_ctor_set(x_124, 1, x_61);
lean_ctor_set(x_124, 2, x_123);
lean_ctor_set(x_32, 0, x_124);
x_48 = x_59;
x_49 = x_96;
x_50 = x_100;
x_51 = x_32;
goto block_55;
}
else
{
lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; 
x_125 = lean_ctor_get(x_32, 0);
lean_inc(x_125);
lean_dec(x_32);
x_126 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_127 = l_ProofWidgets_InteractiveCode;
x_128 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_127, x_45, x_61);
x_129 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_130 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_127, x_37, x_61);
x_131 = l_ProofWidgets_MarkdownDisplay;
x_132 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_131, x_125, x_61);
x_133 = lean_array_push(x_71, x_128);
x_134 = lean_array_push(x_133, x_129);
x_135 = lean_array_push(x_134, x_130);
x_136 = lean_array_push(x_135, x_132);
x_137 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_137, 0, x_126);
lean_ctor_set(x_137, 1, x_61);
lean_ctor_set(x_137, 2, x_136);
x_138 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_138, 0, x_137);
x_48 = x_59;
x_49 = x_96;
x_50 = x_100;
x_51 = x_138;
goto block_55;
}
}
}
}
else
{
uint8_t x_141; 
lean_dec(x_42);
lean_dec(x_37);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_12);
lean_dec_ref(x_11);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec_ref(x_1);
x_141 = !lean_is_exclusive(x_44);
if (x_141 == 0)
{
return x_44;
}
else
{
lean_object* x_142; lean_object* x_143; lean_object* x_144; 
x_142 = lean_ctor_get(x_44, 0);
x_143 = lean_ctor_get(x_44, 1);
lean_inc(x_143);
lean_inc(x_142);
lean_dec(x_44);
x_144 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_144, 0, x_142);
lean_ctor_set(x_144, 1, x_143);
return x_144;
}
}
}
else
{
uint8_t x_145; 
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_12);
lean_dec_ref(x_11);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec_ref(x_1);
x_145 = !lean_is_exclusive(x_36);
if (x_145 == 0)
{
return x_36;
}
else
{
lean_object* x_146; lean_object* x_147; lean_object* x_148; 
x_146 = lean_ctor_get(x_36, 0);
x_147 = lean_ctor_get(x_36, 1);
lean_inc(x_147);
lean_inc(x_146);
lean_dec(x_36);
x_148 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_148, 0, x_146);
lean_ctor_set(x_148, 1, x_147);
return x_148;
}
}
}
else
{
uint8_t x_149; 
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_12);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec_ref(x_1);
x_149 = !lean_is_exclusive(x_31);
if (x_149 == 0)
{
lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; 
x_150 = lean_ctor_get(x_31, 0);
x_151 = lean_ctor_get(x_11, 5);
lean_inc(x_151);
lean_dec_ref(x_11);
x_152 = lean_io_error_to_string(x_150);
x_153 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_153, 0, x_152);
x_154 = l_Lean_MessageData_ofFormat(x_153);
x_155 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_155, 0, x_151);
lean_ctor_set(x_155, 1, x_154);
lean_ctor_set(x_31, 0, x_155);
return x_31;
}
else
{
lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; 
x_156 = lean_ctor_get(x_31, 0);
x_157 = lean_ctor_get(x_31, 1);
lean_inc(x_157);
lean_inc(x_156);
lean_dec(x_31);
x_158 = lean_ctor_get(x_11, 5);
lean_inc(x_158);
lean_dec_ref(x_11);
x_159 = lean_io_error_to_string(x_156);
x_160 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_160, 0, x_159);
x_161 = l_Lean_MessageData_ofFormat(x_160);
x_162 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_162, 0, x_158);
lean_ctor_set(x_162, 1, x_161);
x_163 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_163, 0, x_162);
lean_ctor_set(x_163, 1, x_157);
return x_163;
}
}
}
}
block_19:
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = 1;
x_17 = lean_usize_add(x_5, x_16);
x_18 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_2, x_3, x_4, x_17, x_14, x_9, x_10, x_11, x_12, x_15);
return x_18;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_string_hash(x_6);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_GraphDisplay_instRpcEncodableProps_enc____x40_ProofWidgets_Component_GraphDisplay_1995342541____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_8, 0, x_2);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_1;
}
else
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = lean_ctor_get(x_2, 0);
x_4 = lean_ctor_get(x_2, 2);
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
x_7 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_8 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
x_9 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_6);
lean_ctor_set(x_9, 2, x_7);
lean_ctor_set(x_9, 3, x_8);
lean_ctor_set(x_9, 4, x_8);
x_10 = lean_array_push(x_1, x_9);
x_1 = x_10;
x_2 = x_4;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_eq(x_2, x_3);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; 
x_6 = lean_array_uget(x_1, x_2);
x_7 = l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(x_4, x_6);
lean_dec(x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_2 = x_9;
x_4 = x_7;
goto _start;
}
else
{
return x_4;
}
}
}
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
uint8_t x_3; 
x_3 = 0;
return x_3;
}
else
{
lean_object* x_4; lean_object* x_5; uint8_t x_6; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 2);
x_9 = lean_ctor_get(x_4, 0);
x_10 = lean_ctor_get(x_4, 1);
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_ctor_get(x_1, 1);
x_13 = lean_string_dec_eq(x_9, x_11);
if (x_13 == 0)
{
x_6 = x_13;
goto block_8;
}
else
{
uint8_t x_14; 
x_14 = lean_string_dec_eq(x_10, x_12);
x_6 = x_14;
goto block_8;
}
block_8:
{
if (x_6 == 0)
{
x_2 = x_5;
goto _start;
}
else
{
return x_6;
}
}
}
}
}
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_1;
}
else
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint64_t x_9; uint64_t x_10; uint64_t x_11; uint64_t x_12; uint64_t x_13; uint64_t x_14; uint64_t x_15; uint64_t x_16; uint64_t x_17; size_t x_18; size_t x_19; size_t x_20; size_t x_21; size_t x_22; lean_object* x_23; lean_object* x_24; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 2);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_ctor_get(x_4, 1);
x_8 = lean_array_get_size(x_1);
x_9 = lean_string_hash(x_6);
x_10 = lean_string_hash(x_7);
x_11 = lean_uint64_mix_hash(x_9, x_10);
x_12 = 32;
x_13 = lean_uint64_shift_right(x_11, x_12);
x_14 = lean_uint64_xor(x_11, x_13);
x_15 = 16;
x_16 = lean_uint64_shift_right(x_14, x_15);
x_17 = lean_uint64_xor(x_14, x_16);
x_18 = lean_uint64_to_usize(x_17);
x_19 = lean_usize_of_nat(x_8);
lean_dec(x_8);
x_20 = 1;
x_21 = lean_usize_sub(x_19, x_20);
x_22 = lean_usize_land(x_18, x_21);
x_23 = lean_array_uget(x_1, x_22);
lean_ctor_set(x_2, 2, x_23);
x_24 = lean_array_uset(x_1, x_22, x_2);
x_1 = x_24;
x_2 = x_5;
goto _start;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; uint64_t x_32; uint64_t x_33; uint64_t x_34; uint64_t x_35; uint64_t x_36; uint64_t x_37; uint64_t x_38; uint64_t x_39; uint64_t x_40; size_t x_41; size_t x_42; size_t x_43; size_t x_44; size_t x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_26 = lean_ctor_get(x_2, 0);
x_27 = lean_ctor_get(x_2, 1);
x_28 = lean_ctor_get(x_2, 2);
lean_inc(x_28);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_2);
x_29 = lean_ctor_get(x_26, 0);
x_30 = lean_ctor_get(x_26, 1);
x_31 = lean_array_get_size(x_1);
x_32 = lean_string_hash(x_29);
x_33 = lean_string_hash(x_30);
x_34 = lean_uint64_mix_hash(x_32, x_33);
x_35 = 32;
x_36 = lean_uint64_shift_right(x_34, x_35);
x_37 = lean_uint64_xor(x_34, x_36);
x_38 = 16;
x_39 = lean_uint64_shift_right(x_37, x_38);
x_40 = lean_uint64_xor(x_37, x_39);
x_41 = lean_uint64_to_usize(x_40);
x_42 = lean_usize_of_nat(x_31);
lean_dec(x_31);
x_43 = 1;
x_44 = lean_usize_sub(x_42, x_43);
x_45 = lean_usize_land(x_41, x_44);
x_46 = lean_array_uget(x_1, x_45);
x_47 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_47, 0, x_26);
lean_ctor_set(x_47, 1, x_27);
lean_ctor_set(x_47, 2, x_46);
x_48 = lean_array_uset(x_1, x_45, x_47);
x_1 = x_48;
x_2 = x_28;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = lean_array_get_size(x_2);
x_5 = lean_nat_dec_lt(x_1, x_4);
lean_dec(x_4);
if (x_5 == 0)
{
lean_dec_ref(x_2);
lean_dec(x_1);
return x_3;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = lean_array_fget(x_2, x_1);
x_7 = lean_box(0);
x_8 = lean_array_fset(x_2, x_1, x_7);
x_9 = l_Std_DHashMap_Internal_AssocList_foldlM___at_____private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8_spec__8___redArg(x_3, x_6);
x_10 = lean_unsigned_to_nat(1u);
x_11 = lean_nat_add(x_1, x_10);
lean_dec(x_1);
x_1 = x_11;
x_2 = x_8;
x_3 = x_9;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_array_get_size(x_1);
x_3 = lean_unsigned_to_nat(2u);
x_4 = lean_nat_mul(x_2, x_3);
lean_dec(x_2);
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_box(0);
x_7 = lean_mk_array(x_4, x_6);
x_8 = l___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8_spec__8___redArg(x_5, x_1, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8___redArg(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint64_t x_9; uint64_t x_10; uint64_t x_11; uint64_t x_12; uint64_t x_13; uint64_t x_14; uint64_t x_15; uint64_t x_16; uint64_t x_17; size_t x_18; size_t x_19; size_t x_20; size_t x_21; size_t x_22; lean_object* x_23; uint8_t x_24; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_2, 0);
x_7 = lean_ctor_get(x_2, 1);
x_8 = lean_array_get_size(x_5);
x_9 = lean_string_hash(x_6);
x_10 = lean_string_hash(x_7);
x_11 = lean_uint64_mix_hash(x_9, x_10);
x_12 = 32;
x_13 = lean_uint64_shift_right(x_11, x_12);
x_14 = lean_uint64_xor(x_11, x_13);
x_15 = 16;
x_16 = lean_uint64_shift_right(x_14, x_15);
x_17 = lean_uint64_xor(x_14, x_16);
x_18 = lean_uint64_to_usize(x_17);
x_19 = lean_usize_of_nat(x_8);
lean_dec(x_8);
x_20 = 1;
x_21 = lean_usize_sub(x_19, x_20);
x_22 = lean_usize_land(x_18, x_21);
x_23 = lean_array_uget(x_5, x_22);
x_24 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg(x_2, x_23);
if (x_24 == 0)
{
uint8_t x_25; 
lean_inc_ref(x_5);
lean_inc(x_4);
x_25 = !lean_is_exclusive(x_1);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_37; 
x_26 = lean_ctor_get(x_1, 1);
lean_dec(x_26);
x_27 = lean_ctor_get(x_1, 0);
lean_dec(x_27);
x_28 = lean_unsigned_to_nat(1u);
x_29 = lean_nat_add(x_4, x_28);
lean_dec(x_4);
x_30 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_30, 0, x_2);
lean_ctor_set(x_30, 1, x_3);
lean_ctor_set(x_30, 2, x_23);
x_31 = lean_array_uset(x_5, x_22, x_30);
x_32 = lean_unsigned_to_nat(4u);
x_33 = lean_nat_mul(x_29, x_32);
x_34 = lean_unsigned_to_nat(3u);
x_35 = lean_nat_div(x_33, x_34);
lean_dec(x_33);
x_36 = lean_array_get_size(x_31);
x_37 = lean_nat_dec_le(x_35, x_36);
lean_dec(x_36);
lean_dec(x_35);
if (x_37 == 0)
{
lean_object* x_38; 
x_38 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8___redArg(x_31);
lean_ctor_set(x_1, 1, x_38);
lean_ctor_set(x_1, 0, x_29);
return x_1;
}
else
{
lean_ctor_set(x_1, 1, x_31);
lean_ctor_set(x_1, 0, x_29);
return x_1;
}
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; uint8_t x_48; 
lean_dec(x_1);
x_39 = lean_unsigned_to_nat(1u);
x_40 = lean_nat_add(x_4, x_39);
lean_dec(x_4);
x_41 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_41, 0, x_2);
lean_ctor_set(x_41, 1, x_3);
lean_ctor_set(x_41, 2, x_23);
x_42 = lean_array_uset(x_5, x_22, x_41);
x_43 = lean_unsigned_to_nat(4u);
x_44 = lean_nat_mul(x_40, x_43);
x_45 = lean_unsigned_to_nat(3u);
x_46 = lean_nat_div(x_44, x_45);
lean_dec(x_44);
x_47 = lean_array_get_size(x_42);
x_48 = lean_nat_dec_le(x_46, x_47);
lean_dec(x_47);
lean_dec(x_46);
if (x_48 == 0)
{
lean_object* x_49; lean_object* x_50; 
x_49 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__8___redArg(x_42);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_40);
lean_ctor_set(x_50, 1, x_49);
return x_50;
}
else
{
lean_object* x_51; 
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_40);
lean_ctor_set(x_51, 1, x_42);
return x_51;
}
}
}
else
{
lean_dec(x_23);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_1;
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_1);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_8);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_25; uint8_t x_26; lean_object* x_27; 
x_13 = lean_ctor_get(x_5, 1);
lean_inc(x_13);
x_14 = lean_ctor_get(x_5, 3);
lean_inc(x_14);
x_15 = lean_ctor_get(x_5, 4);
lean_inc(x_15);
lean_dec_ref(x_5);
lean_inc(x_2);
lean_inc_ref(x_1);
x_16 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(x_1, x_2, x_3, x_4, x_14, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
x_25 = lean_ctor_get(x_17, 0);
lean_inc(x_25);
lean_dec(x_17);
x_26 = 0;
lean_inc(x_13);
lean_inc_ref(x_1);
x_27 = l_Lean_Environment_find_x3f(x_1, x_13, x_26);
if (lean_obj_tag(x_27) == 0)
{
lean_dec(x_25);
lean_dec(x_18);
lean_dec(x_13);
x_19 = x_16;
goto block_24;
}
else
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_28 = lean_ctor_get(x_27, 0);
lean_inc(x_28);
lean_dec_ref(x_27);
x_29 = l_Lean_ConstantInfo_getUsedConstantsAsSet(x_28);
x_30 = l_Std_DTreeMap_Internal_Impl_contains___at___Lean_NameMap_contains_spec__0___redArg(x_2, x_29);
lean_dec(x_29);
if (x_30 == 0)
{
lean_dec(x_25);
lean_dec(x_18);
lean_dec(x_13);
x_19 = x_16;
goto block_24;
}
else
{
uint8_t x_31; 
x_31 = !lean_is_exclusive(x_16);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_32 = lean_ctor_get(x_16, 1);
lean_dec(x_32);
x_33 = lean_ctor_get(x_16, 0);
lean_dec(x_33);
lean_inc(x_2);
x_34 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_3);
x_35 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_13, x_3);
lean_ctor_set(x_16, 1, x_35);
lean_ctor_set(x_16, 0, x_34);
x_36 = lean_box(0);
x_37 = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7___redArg(x_25, x_16, x_36);
x_4 = x_37;
x_5 = x_15;
x_12 = x_18;
goto _start;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_16);
lean_inc(x_2);
x_39 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_3);
x_40 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_13, x_3);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
x_42 = lean_box(0);
x_43 = l_Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7___redArg(x_25, x_41, x_42);
x_4 = x_43;
x_5 = x_15;
x_12 = x_18;
goto _start;
}
}
}
block_24:
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_19, 1);
lean_inc(x_21);
lean_dec_ref(x_19);
x_22 = lean_ctor_get(x_20, 0);
lean_inc(x_22);
lean_dec(x_20);
x_4 = x_22;
x_5 = x_15;
x_12 = x_21;
goto _start;
}
}
else
{
lean_object* x_45; lean_object* x_46; 
lean_dec(x_2);
lean_dec_ref(x_1);
x_45 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_45, 0, x_4);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_12);
return x_46;
}
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(x_1, x_2, x_3, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_15 = lean_ctor_get(x_7, 1);
lean_inc(x_15);
x_16 = lean_ctor_get(x_7, 3);
lean_inc(x_16);
x_17 = lean_ctor_get(x_7, 4);
lean_inc(x_17);
lean_dec_ref(x_7);
lean_inc_ref(x_2);
lean_inc(x_1);
x_18 = l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(x_1, x_2, x_3, x_4, x_5, x_6, x_16, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec_ref(x_18);
x_21 = lean_ctor_get(x_19, 0);
lean_inc(x_21);
lean_dec(x_19);
lean_inc(x_1);
lean_inc_ref(x_2);
x_22 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(x_2, x_15, x_3, x_21, x_1, x_8, x_9, x_10, x_11, x_12, x_13, x_20);
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 1);
lean_inc(x_24);
lean_dec_ref(x_22);
x_25 = lean_ctor_get(x_23, 0);
lean_inc(x_25);
lean_dec(x_23);
x_6 = x_25;
x_7 = x_17;
x_14 = x_24;
goto _start;
}
else
{
lean_object* x_27; lean_object* x_28; 
lean_dec_ref(x_2);
lean_dec(x_1);
x_27 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_27, 0, x_6);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_14);
return x_28;
}
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_15 = lean_ctor_get(x_7, 1);
lean_inc(x_15);
x_16 = lean_ctor_get(x_7, 3);
lean_inc(x_16);
x_17 = lean_ctor_get(x_7, 4);
lean_inc(x_17);
lean_dec_ref(x_7);
lean_inc_ref(x_1);
lean_inc(x_5);
x_18 = l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(x_5, x_1, x_2, x_3, x_4, x_6, x_16, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec_ref(x_18);
x_21 = lean_ctor_get(x_19, 0);
lean_inc(x_21);
lean_dec(x_19);
lean_inc(x_5);
lean_inc_ref(x_1);
x_22 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(x_1, x_15, x_2, x_21, x_5, x_8, x_9, x_10, x_11, x_12, x_13, x_20);
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 1);
lean_inc(x_24);
lean_dec_ref(x_22);
x_25 = lean_ctor_get(x_23, 0);
lean_inc(x_25);
lean_dec(x_23);
x_26 = l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(x_5, x_1, x_2, x_3, x_4, x_25, x_17, x_8, x_9, x_10, x_11, x_12, x_13, x_24);
return x_26;
}
else
{
lean_object* x_27; lean_object* x_28; 
lean_dec(x_5);
lean_dec_ref(x_1);
x_27 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_27, 0, x_6);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_14);
return x_28;
}
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("html", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_1, x_3);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_ctor_get(x_4, 1);
x_8 = l_elabExprGraphCmd___lam__0___closed__0;
lean_ctor_set(x_4, 1, x_6);
lean_ctor_set(x_4, 0, x_8);
x_9 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_9, 0, x_4);
lean_ctor_set(x_9, 1, x_2);
x_10 = l_Lean_Json_mkObj(x_9);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_12 = lean_ctor_get(x_4, 0);
x_13 = lean_ctor_get(x_4, 1);
lean_inc(x_13);
lean_inc(x_12);
lean_dec(x_4);
x_14 = l_elabExprGraphCmd___lam__0___closed__0;
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_12);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_2);
x_17 = l_Lean_Json_mkObj(x_16);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_13);
return x_18;
}
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editor-foreground)", 31, 31);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__1;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__1;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("strokeWidth", 11, 11);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = l_Lean_JsonNumber_fromNat(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__5;
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__6;
x_2 = l_elabExprGraphCmd___lam__1___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("markerEnd", 9, 9);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("url(#arrow)", 11, 11);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__10;
x_2 = l_elabExprGraphCmd___lam__1___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__2;
x_2 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__3;
x_2 = l_elabExprGraphCmd___lam__1___closed__12;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__7;
x_2 = l_elabExprGraphCmd___lam__1___closed__13;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__11;
x_2 = l_elabExprGraphCmd___lam__1___closed__14;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("internal error", 14, 14);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__16;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_alloc_closure((void*)(l_instDecidableEqString___boxed), 2, 0);
x_2 = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__18;
x_2 = lean_alloc_closure((void*)(l_instBEqProd___redArg___lam__0___boxed), 4, 2);
lean_closure_set(x_2, 0, x_1);
lean_closure_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_String_hash___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__20;
x_2 = lean_alloc_closure((void*)(l_instHashableProd___redArg___lam__0___boxed), 3, 2);
lean_closure_set(x_2, 0, x_1);
lean_closure_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_unsigned_to_nat(8u);
x_3 = lean_nat_mul(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = l_elabExprGraphCmd___lam__1___closed__22;
x_3 = lean_nat_div(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__23;
x_2 = l_Nat_nextPowerOfTwo(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_elabExprGraphCmd___lam__1___closed__24;
x_3 = lean_mk_array(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__25;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__27() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; 
x_93 = lean_st_ref_get(x_10, x_11);
x_94 = lean_ctor_get(x_93, 0);
lean_inc(x_94);
x_95 = lean_ctor_get(x_93, 1);
lean_inc(x_95);
if (lean_is_exclusive(x_93)) {
 lean_ctor_release(x_93, 0);
 lean_ctor_release(x_93, 1);
 x_96 = x_93;
} else {
 lean_dec_ref(x_93);
 x_96 = lean_box(0);
}
x_97 = lean_box(0);
lean_inc(x_10);
lean_inc_ref(x_9);
x_98 = l_Lean_Elab_realizeGlobalConstNoOverloadWithInfo(x_1, x_97, x_9, x_10, x_95);
if (lean_obj_tag(x_98) == 0)
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; uint8_t x_102; lean_object* x_103; 
x_99 = lean_ctor_get(x_98, 0);
lean_inc(x_99);
x_100 = lean_ctor_get(x_98, 1);
lean_inc(x_100);
lean_dec_ref(x_98);
x_101 = lean_ctor_get(x_94, 0);
lean_inc_ref(x_101);
lean_dec(x_94);
x_102 = 0;
lean_inc_ref(x_101);
x_103 = l_Lean_Environment_find_x3f(x_101, x_99, x_102);
if (lean_obj_tag(x_103) == 0)
{
lean_object* x_104; lean_object* x_105; 
lean_dec_ref(x_101);
lean_dec(x_96);
lean_dec(x_3);
x_104 = l_elabExprGraphCmd___lam__1___closed__17;
x_105 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_104, x_5, x_6, x_7, x_8, x_9, x_10, x_100);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
return x_105;
}
else
{
lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_149; 
x_106 = lean_ctor_get(x_103, 0);
lean_inc(x_106);
lean_dec_ref(x_103);
x_107 = l_Lean_ConstantInfo_getUsedConstantsAsSet(x_106);
x_137 = l_elabExprGraphCmd___lam__1___closed__19;
x_138 = l_elabExprGraphCmd___lam__1___closed__21;
x_139 = lean_unsigned_to_nat(0u);
x_140 = l_elabExprGraphCmd___lam__1___closed__26;
lean_inc_n(x_107, 2);
lean_inc_ref(x_101);
x_141 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13(x_101, x_2, x_137, x_138, x_107, x_140, x_107, x_5, x_6, x_7, x_8, x_9, x_10, x_100);
x_142 = lean_ctor_get(x_141, 0);
lean_inc(x_142);
x_143 = lean_ctor_get(x_141, 1);
lean_inc(x_143);
lean_dec_ref(x_141);
x_149 = lean_ctor_get(x_142, 0);
lean_inc(x_149);
lean_dec(x_142);
x_144 = x_149;
goto block_148;
block_136:
{
lean_object* x_114; lean_object* x_115; lean_object* x_116; size_t x_117; size_t x_118; lean_object* x_119; 
x_114 = lean_mk_empty_array_with_capacity(x_113);
lean_dec(x_113);
x_115 = l_Std_DTreeMap_Internal_Impl_foldlM___at___Std_DTreeMap_Internal_Impl_foldl___at_____private_Lean_Elab_DocString_0__Lean_Doc_codeSuggestionsUnsafe_spec__2_spec__2(x_114, x_107);
if (lean_is_scalar(x_96)) {
 x_116 = lean_alloc_ctor(0, 2, 0);
} else {
 x_116 = x_96;
}
lean_ctor_set(x_116, 0, x_112);
lean_ctor_set(x_116, 1, x_111);
x_117 = lean_array_size(x_115);
x_118 = 0;
lean_inc(x_10);
lean_inc_ref(x_9);
x_119 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(x_101, x_2, x_115, x_117, x_118, x_116, x_5, x_6, x_7, x_8, x_9, x_10, x_108);
lean_dec_ref(x_5);
lean_dec_ref(x_115);
if (lean_obj_tag(x_119) == 0)
{
lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; uint8_t x_128; 
x_120 = lean_ctor_get(x_119, 0);
lean_inc(x_120);
x_121 = lean_ctor_get(x_119, 1);
lean_inc(x_121);
lean_dec_ref(x_119);
x_122 = lean_ctor_get(x_120, 0);
lean_inc(x_122);
x_123 = lean_ctor_get(x_120, 1);
lean_inc(x_123);
lean_dec(x_120);
x_124 = lean_ctor_get(x_110, 1);
lean_inc_ref(x_124);
lean_dec_ref(x_110);
x_125 = l_ProofWidgets_GraphDisplay;
x_126 = lean_mk_empty_array_with_capacity(x_109);
x_127 = lean_array_get_size(x_124);
x_128 = lean_nat_dec_lt(x_109, x_127);
if (x_128 == 0)
{
lean_dec(x_127);
lean_dec_ref(x_124);
x_12 = x_121;
x_13 = x_123;
x_14 = x_109;
x_15 = x_122;
x_16 = x_125;
x_17 = x_126;
goto block_92;
}
else
{
uint8_t x_129; 
x_129 = lean_nat_dec_le(x_127, x_127);
if (x_129 == 0)
{
lean_dec(x_127);
lean_dec_ref(x_124);
x_12 = x_121;
x_13 = x_123;
x_14 = x_109;
x_15 = x_122;
x_16 = x_125;
x_17 = x_126;
goto block_92;
}
else
{
size_t x_130; lean_object* x_131; 
x_130 = lean_usize_of_nat(x_127);
lean_dec(x_127);
x_131 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(x_124, x_118, x_130, x_126);
lean_dec_ref(x_124);
x_12 = x_121;
x_13 = x_123;
x_14 = x_109;
x_15 = x_122;
x_16 = x_125;
x_17 = x_131;
goto block_92;
}
}
}
else
{
uint8_t x_132; 
lean_dec_ref(x_110);
lean_dec(x_109);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_3);
x_132 = !lean_is_exclusive(x_119);
if (x_132 == 0)
{
return x_119;
}
else
{
lean_object* x_133; lean_object* x_134; lean_object* x_135; 
x_133 = lean_ctor_get(x_119, 0);
x_134 = lean_ctor_get(x_119, 1);
lean_inc(x_134);
lean_inc(x_133);
lean_dec(x_119);
x_135 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_135, 0, x_133);
lean_ctor_set(x_135, 1, x_134);
return x_135;
}
}
}
block_148:
{
lean_object* x_145; lean_object* x_146; 
x_145 = l_elabExprGraphCmd___lam__1___closed__27;
x_146 = lean_unsigned_to_nat(10u);
if (lean_obj_tag(x_107) == 0)
{
lean_object* x_147; 
x_147 = lean_ctor_get(x_107, 0);
lean_inc(x_147);
x_108 = x_143;
x_109 = x_139;
x_110 = x_144;
x_111 = x_145;
x_112 = x_146;
x_113 = x_147;
goto block_136;
}
else
{
x_108 = x_143;
x_109 = x_139;
x_110 = x_144;
x_111 = x_145;
x_112 = x_146;
x_113 = x_139;
goto block_136;
}
}
}
}
else
{
uint8_t x_150; 
lean_dec(x_96);
lean_dec(x_94);
lean_dec(x_10);
lean_dec_ref(x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_5);
lean_dec(x_3);
x_150 = !lean_is_exclusive(x_98);
if (x_150 == 0)
{
return x_98;
}
else
{
lean_object* x_151; lean_object* x_152; lean_object* x_153; 
x_151 = lean_ctor_get(x_98, 0);
x_152 = lean_ctor_get(x_98, 1);
lean_inc(x_152);
lean_inc(x_151);
lean_dec(x_98);
x_153 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_153, 0, x_151);
lean_ctor_set(x_153, 1, x_152);
return x_153;
}
}
block_92:
{
lean_object* x_18; uint8_t x_19; 
x_18 = l_ProofWidgets_HtmlDisplayPanel;
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; double x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; double x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; double x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint64_t x_54; lean_object* x_55; 
x_20 = lean_ctor_get(x_18, 0);
x_21 = lean_ctor_get(x_18, 1);
lean_dec(x_21);
x_22 = lean_ctor_get(x_20, 0);
lean_inc_ref(x_22);
lean_dec_ref(x_20);
x_23 = lean_unsigned_to_nat(2u);
x_24 = lean_box(0);
x_25 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_26 = l_elabExprGraphCmd___lam__1___closed__15;
x_27 = lean_nat_mul(x_15, x_23);
x_28 = lean_float_of_nat(x_27);
x_29 = lean_box_float(x_28);
x_30 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_30, 0, x_29);
x_31 = lean_box(0);
x_32 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
lean_ctor_set(x_32, 2, x_31);
x_33 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_33, 0, x_32);
x_34 = lean_float_of_nat(x_15);
x_35 = lean_box_float(x_34);
x_36 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_36, 0, x_35);
x_37 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_37, 0, x_36);
lean_ctor_set(x_37, 1, x_31);
lean_ctor_set(x_37, 2, x_31);
x_38 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_38, 0, x_37);
x_39 = lean_unsigned_to_nat(5u);
x_40 = l_Float_ofScientific(x_39, x_2, x_23);
x_41 = lean_box_float(x_40);
x_42 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_42, 0, x_41);
lean_inc_ref(x_42);
lean_ctor_set(x_18, 1, x_42);
lean_ctor_set(x_18, 0, x_31);
x_43 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_43, 0, x_18);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_31);
lean_ctor_set(x_44, 1, x_42);
x_45 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_45, 0, x_44);
x_46 = lean_array_push(x_25, x_33);
x_47 = lean_array_push(x_46, x_38);
x_48 = lean_array_push(x_47, x_43);
x_49 = lean_array_push(x_48, x_45);
x_50 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_50, 0, x_13);
lean_ctor_set(x_50, 1, x_17);
lean_ctor_set(x_50, 2, x_26);
lean_ctor_set(x_50, 3, x_49);
lean_ctor_set_uint8(x_50, sizeof(void*)*4, x_2);
x_51 = lean_mk_empty_array_with_capacity(x_14);
lean_dec(x_14);
x_52 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_16, x_50, x_51);
lean_dec_ref(x_16);
x_53 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__0), 3, 2);
lean_closure_set(x_53, 0, x_52);
lean_closure_set(x_53, 1, x_24);
x_54 = lean_string_hash(x_22);
lean_dec_ref(x_22);
x_55 = l_Lean_Widget_savePanelWidgetInfo(x_54, x_53, x_3, x_9, x_10, x_12);
lean_dec(x_10);
lean_dec_ref(x_9);
return x_55;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; double x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; double x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; double x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; uint64_t x_90; lean_object* x_91; 
x_56 = lean_ctor_get(x_18, 0);
lean_inc(x_56);
lean_dec(x_18);
x_57 = lean_ctor_get(x_56, 0);
lean_inc_ref(x_57);
lean_dec_ref(x_56);
x_58 = lean_unsigned_to_nat(2u);
x_59 = lean_box(0);
x_60 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_61 = l_elabExprGraphCmd___lam__1___closed__15;
x_62 = lean_nat_mul(x_15, x_58);
x_63 = lean_float_of_nat(x_62);
x_64 = lean_box_float(x_63);
x_65 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_65, 0, x_64);
x_66 = lean_box(0);
x_67 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_67, 0, x_65);
lean_ctor_set(x_67, 1, x_66);
lean_ctor_set(x_67, 2, x_66);
x_68 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_68, 0, x_67);
x_69 = lean_float_of_nat(x_15);
x_70 = lean_box_float(x_69);
x_71 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_71, 0, x_70);
x_72 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_72, 0, x_71);
lean_ctor_set(x_72, 1, x_66);
lean_ctor_set(x_72, 2, x_66);
x_73 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_73, 0, x_72);
x_74 = lean_unsigned_to_nat(5u);
x_75 = l_Float_ofScientific(x_74, x_2, x_58);
x_76 = lean_box_float(x_75);
x_77 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_77, 0, x_76);
lean_inc_ref(x_77);
x_78 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_78, 0, x_66);
lean_ctor_set(x_78, 1, x_77);
x_79 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_79, 0, x_78);
x_80 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_80, 0, x_66);
lean_ctor_set(x_80, 1, x_77);
x_81 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_81, 0, x_80);
x_82 = lean_array_push(x_60, x_68);
x_83 = lean_array_push(x_82, x_73);
x_84 = lean_array_push(x_83, x_79);
x_85 = lean_array_push(x_84, x_81);
x_86 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_86, 0, x_13);
lean_ctor_set(x_86, 1, x_17);
lean_ctor_set(x_86, 2, x_61);
lean_ctor_set(x_86, 3, x_85);
lean_ctor_set_uint8(x_86, sizeof(void*)*4, x_2);
x_87 = lean_mk_empty_array_with_capacity(x_14);
lean_dec(x_14);
x_88 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_16, x_86, x_87);
lean_dec_ref(x_16);
x_89 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__0), 3, 2);
lean_closure_set(x_89, 0, x_88);
lean_closure_set(x_89, 1, x_59);
x_90 = lean_string_hash(x_57);
lean_dec_ref(x_57);
x_91 = l_Lean_Widget_savePanelWidgetInfo(x_90, x_89, x_3, x_9, x_10, x_12);
lean_dec(x_10);
lean_dec_ref(x_9);
return x_91;
}
}
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Unexpected syntax ", 18, 18);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_exprGraphCmd___closed__1;
lean_inc(x_1);
x_6 = l_Lean_Syntax_isOfKind(x_1, x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = l_elabExprGraphCmd___closed__1;
x_8 = l_Lean_MessageData_ofSyntax(x_1);
x_9 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(x_9, x_2, x_3, x_4);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_11 = lean_unsigned_to_nat(1u);
x_12 = l_Lean_Syntax_getArg(x_1, x_11);
x_13 = l_exprGraphCmd___closed__7;
lean_inc(x_12);
x_14 = l_Lean_Syntax_isOfKind(x_12, x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
lean_dec(x_12);
x_15 = l_elabExprGraphCmd___closed__1;
x_16 = l_Lean_MessageData_ofSyntax(x_1);
x_17 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_17, 0, x_15);
lean_ctor_set(x_17, 1, x_16);
x_18 = l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(x_17, x_2, x_3, x_4);
return x_18;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_box(x_14);
x_20 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__1___boxed), 11, 3);
lean_closure_set(x_20, 0, x_12);
lean_closure_set(x_20, 1, x_19);
lean_closure_set(x_20, 2, x_1);
x_21 = l_Lean_Elab_Command_runTermElabM___redArg(x_20, x_2, x_3, x_4);
return x_21;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
uint8_t x_12; size_t x_13; size_t x_14; lean_object* x_15; 
x_12 = lean_unbox(x_2);
x_13 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_14 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_15 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_12, x_3, x_13, x_14, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec_ref(x_3);
return x_15;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
uint8_t x_14; size_t x_15; size_t x_16; lean_object* x_17; 
x_14 = lean_unbox(x_2);
x_15 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_16 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_17 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(x_1, x_14, x_3, x_15, x_16, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_3);
return x_17;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
uint8_t x_14; size_t x_15; size_t x_16; lean_object* x_17; 
x_14 = lean_unbox(x_2);
x_15 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_16 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_17 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(x_1, x_14, x_3, x_15, x_16, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec_ref(x_3);
return x_17;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(x_1, x_5, x_6, x_4);
lean_dec_ref(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___redArg(x_1, x_2);
lean_dec(x_2);
lean_dec_ref(x_1);
x_4 = lean_box(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; lean_object* x_5; 
x_4 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at___elabExprGraphCmd_spec__7_spec__7(x_1, x_2, x_3);
lean_dec(x_3);
lean_dec_ref(x_2);
x_5 = lean_box(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
uint8_t x_13; lean_object* x_14; 
x_13 = lean_unbox(x_3);
x_14 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___redArg(x_1, x_2, x_13, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
lean_dec(x_11);
lean_dec_ref(x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec(x_7);
lean_dec_ref(x_6);
return x_14;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
uint8_t x_15; lean_object* x_16; 
x_15 = lean_unbox(x_3);
x_16 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__12(x_1, x_2, x_15, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_13);
lean_dec_ref(x_12);
lean_dec(x_11);
lean_dec_ref(x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec_ref(x_5);
lean_dec_ref(x_4);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
uint8_t x_15; lean_object* x_16; 
x_15 = lean_unbox(x_3);
x_16 = l_Std_DTreeMap_Internal_Impl_forInStep___at___Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13_spec__13(x_1, x_2, x_15, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_13);
lean_dec_ref(x_12);
lean_dec(x_11);
lean_dec_ref(x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec_ref(x_5);
lean_dec_ref(x_4);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
uint8_t x_15; lean_object* x_16; 
x_15 = lean_unbox(x_2);
x_16 = l_Std_DTreeMap_Internal_Impl_forInStep___at___elabExprGraphCmd_spec__13(x_1, x_15, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_13);
lean_dec_ref(x_12);
lean_dec(x_11);
lean_dec_ref(x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
return x_16;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
uint8_t x_12; lean_object* x_13; 
x_12 = lean_unbox(x_2);
x_13 = l_elabExprGraphCmd___lam__1(x_1, x_12, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_6);
lean_dec_ref(x_4);
return x_13;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_elabExprGraphCmd(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
static lean_object* _init_l_a() {
_start:
{
lean_object* x_1; 
x_1 = lean_unsigned_to_nat(0u);
return x_1;
}
}
static lean_object* _init_l_b() {
_start:
{
lean_object* x_1; 
x_1 = lean_unsigned_to_nat(1u);
return x_1;
}
}
static lean_object* _init_l_foo___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_foo___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_foo___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_foo___closed__1;
x_2 = l_foo___closed__0;
x_3 = lean_int_ediv(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_foo(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_2 = lean_unsigned_to_nat(1u);
x_3 = lean_nat_mul(x_2, x_1);
x_4 = l_foo___closed__2;
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_foo___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_foo(x_1);
lean_dec(x_1);
return x_2;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_GraphDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Util_FoldConsts(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Graph_ExprGraph(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_GraphDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Util_FoldConsts(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_exprGraphCmd___closed__0 = _init_l_exprGraphCmd___closed__0();
lean_mark_persistent(l_exprGraphCmd___closed__0);
l_exprGraphCmd___closed__1 = _init_l_exprGraphCmd___closed__1();
lean_mark_persistent(l_exprGraphCmd___closed__1);
l_exprGraphCmd___closed__2 = _init_l_exprGraphCmd___closed__2();
lean_mark_persistent(l_exprGraphCmd___closed__2);
l_exprGraphCmd___closed__3 = _init_l_exprGraphCmd___closed__3();
lean_mark_persistent(l_exprGraphCmd___closed__3);
l_exprGraphCmd___closed__4 = _init_l_exprGraphCmd___closed__4();
lean_mark_persistent(l_exprGraphCmd___closed__4);
l_exprGraphCmd___closed__5 = _init_l_exprGraphCmd___closed__5();
lean_mark_persistent(l_exprGraphCmd___closed__5);
l_exprGraphCmd___closed__6 = _init_l_exprGraphCmd___closed__6();
lean_mark_persistent(l_exprGraphCmd___closed__6);
l_exprGraphCmd___closed__7 = _init_l_exprGraphCmd___closed__7();
lean_mark_persistent(l_exprGraphCmd___closed__7);
l_exprGraphCmd___closed__8 = _init_l_exprGraphCmd___closed__8();
lean_mark_persistent(l_exprGraphCmd___closed__8);
l_exprGraphCmd___closed__9 = _init_l_exprGraphCmd___closed__9();
lean_mark_persistent(l_exprGraphCmd___closed__9);
l_exprGraphCmd___closed__10 = _init_l_exprGraphCmd___closed__10();
lean_mark_persistent(l_exprGraphCmd___closed__10);
l_exprGraphCmd = _init_l_exprGraphCmd();
lean_mark_persistent(l_exprGraphCmd);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34();
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37);
l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38 = _init_l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38();
lean_mark_persistent(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at_____private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38);
l_elabExprGraphCmd___lam__0___closed__0 = _init_l_elabExprGraphCmd___lam__0___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___lam__0___closed__0);
l_elabExprGraphCmd___lam__1___closed__0 = _init_l_elabExprGraphCmd___lam__1___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__0);
l_elabExprGraphCmd___lam__1___closed__1 = _init_l_elabExprGraphCmd___lam__1___closed__1();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__1);
l_elabExprGraphCmd___lam__1___closed__2 = _init_l_elabExprGraphCmd___lam__1___closed__2();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__2);
l_elabExprGraphCmd___lam__1___closed__3 = _init_l_elabExprGraphCmd___lam__1___closed__3();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__3);
l_elabExprGraphCmd___lam__1___closed__4 = _init_l_elabExprGraphCmd___lam__1___closed__4();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__4);
l_elabExprGraphCmd___lam__1___closed__5 = _init_l_elabExprGraphCmd___lam__1___closed__5();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__5);
l_elabExprGraphCmd___lam__1___closed__6 = _init_l_elabExprGraphCmd___lam__1___closed__6();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__6);
l_elabExprGraphCmd___lam__1___closed__7 = _init_l_elabExprGraphCmd___lam__1___closed__7();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__7);
l_elabExprGraphCmd___lam__1___closed__8 = _init_l_elabExprGraphCmd___lam__1___closed__8();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__8);
l_elabExprGraphCmd___lam__1___closed__9 = _init_l_elabExprGraphCmd___lam__1___closed__9();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__9);
l_elabExprGraphCmd___lam__1___closed__10 = _init_l_elabExprGraphCmd___lam__1___closed__10();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__10);
l_elabExprGraphCmd___lam__1___closed__11 = _init_l_elabExprGraphCmd___lam__1___closed__11();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__11);
l_elabExprGraphCmd___lam__1___closed__12 = _init_l_elabExprGraphCmd___lam__1___closed__12();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__12);
l_elabExprGraphCmd___lam__1___closed__13 = _init_l_elabExprGraphCmd___lam__1___closed__13();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__13);
l_elabExprGraphCmd___lam__1___closed__14 = _init_l_elabExprGraphCmd___lam__1___closed__14();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__14);
l_elabExprGraphCmd___lam__1___closed__15 = _init_l_elabExprGraphCmd___lam__1___closed__15();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__15);
l_elabExprGraphCmd___lam__1___closed__16 = _init_l_elabExprGraphCmd___lam__1___closed__16();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__16);
l_elabExprGraphCmd___lam__1___closed__17 = _init_l_elabExprGraphCmd___lam__1___closed__17();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__17);
l_elabExprGraphCmd___lam__1___closed__18 = _init_l_elabExprGraphCmd___lam__1___closed__18();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__18);
l_elabExprGraphCmd___lam__1___closed__19 = _init_l_elabExprGraphCmd___lam__1___closed__19();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__19);
l_elabExprGraphCmd___lam__1___closed__20 = _init_l_elabExprGraphCmd___lam__1___closed__20();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__20);
l_elabExprGraphCmd___lam__1___closed__21 = _init_l_elabExprGraphCmd___lam__1___closed__21();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__21);
l_elabExprGraphCmd___lam__1___closed__22 = _init_l_elabExprGraphCmd___lam__1___closed__22();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__22);
l_elabExprGraphCmd___lam__1___closed__23 = _init_l_elabExprGraphCmd___lam__1___closed__23();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__23);
l_elabExprGraphCmd___lam__1___closed__24 = _init_l_elabExprGraphCmd___lam__1___closed__24();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__24);
l_elabExprGraphCmd___lam__1___closed__25 = _init_l_elabExprGraphCmd___lam__1___closed__25();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__25);
l_elabExprGraphCmd___lam__1___closed__26 = _init_l_elabExprGraphCmd___lam__1___closed__26();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__26);
l_elabExprGraphCmd___lam__1___closed__27 = _init_l_elabExprGraphCmd___lam__1___closed__27();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__27);
l_elabExprGraphCmd___closed__0 = _init_l_elabExprGraphCmd___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___closed__0);
l_elabExprGraphCmd___closed__1 = _init_l_elabExprGraphCmd___closed__1();
lean_mark_persistent(l_elabExprGraphCmd___closed__1);
l_a = _init_l_a();
lean_mark_persistent(l_a);
l_b = _init_l_b();
lean_mark_persistent(l_b);
l_foo___closed__0 = _init_l_foo___closed__0();
lean_mark_persistent(l_foo___closed__0);
l_foo___closed__1 = _init_l_foo___closed__1();
lean_mark_persistent(l_foo___closed__1);
l_foo___closed__2 = _init_l_foo___closed__2();
lean_mark_persistent(l_foo___closed__2);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
