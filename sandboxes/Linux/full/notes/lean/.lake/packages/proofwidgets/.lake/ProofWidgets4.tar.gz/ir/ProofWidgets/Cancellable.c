// Lean compiler output
// Module: ProofWidgets.Cancellable
// Imports: Init Lean.Data.Json.FromToJson Lean.Server.Rpc.RequestHandling Std.Data.HashMap ProofWidgets.Compat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_io_cancel(lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at_____private_Lean_Meta_Match_Match_0__Lean_Meta_Match_solveCnstrs_go_spec__8_spec__8___redArg(lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest(lean_object*, lean_object*, lean_object*);
size_t lean_uint64_to_usize(uint64_t);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
extern lean_object* l_Lean_Meta_instInhabitedConfigWithKey___private__1;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_dec_lt(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorIdx___boxed(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* lean_mk_array(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___lam__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CancellableTask_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped;
static lean_object* l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_CancellableTask_ctorIdx___boxed(lean_object*);
lean_object* l_Lean_Server_ServerTask_mapCheap___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_running_elim(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Nat_reprFast(lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__2;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(lean_object*);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
static lean_object* l_ProofWidgets_mkCancellable___redArg___closed__0;
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_object* l_instMonadEIO(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_runningRequests;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_running____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Meta_mkAppM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*, lean_object*);
lean_object* l_Lean_Name_num___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancellableSuffix;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_object* l_Lean_Name_append(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_instHashableNat___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorIdx(lean_object*);
static lean_object* l_ProofWidgets_mkCancellable___redArg___closed__1;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Lean_throwError___at___Lean_Server_registerRpcProcedure_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancellableSuffix___closed__0;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_running_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___rpc__wrapped;
lean_object* l_Except_orElseLazy___redArg(lean_object*, lean_object*);
lean_object* lean_task_get_own(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4;
static lean_object* l_ProofWidgets_checkRequest___lam__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_done____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_done____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_;
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_running____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Lean_Json_parseTagged(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_object* l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at_____private_Lean_Meta_Tactic_Simp_Arith_Int_Basic_0__Int_Linear_Expr_applyPerm_go_spec__0___redArg(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ReaderT_bind(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancellableSuffix___closed__1;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse;
lean_object* lean_io_get_task_state(lean_object*, lean_object*);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
lean_object* lean_nat_sub(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
static lean_object* l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1(lean_object*, lean_object*);
lean_object* l_Lean_Json_getNat_x3f(lean_object*);
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__1;
lean_object* l_Lean_registerBuiltinAttribute(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1;
static lean_object* l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
size_t lean_usize_sub(size_t, size_t);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_object* l_Lean_Server_registerRpcProcedure(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_(lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest(lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40____boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_infer_type(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
lean_object* l_Lean_addAndCompile(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_;
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_done_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg___boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_checkRequest___lam__0___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1___boxed(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_object* l_Lean_MessageData_ofName(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_done_elim(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
size_t lean_usize_land(size_t, size_t);
lean_object* l_Lean_Server_RequestError_invalidParams(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_CancellableTask_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CancellableTask_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_CancellableTask_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_unsigned_to_nat(8u);
x_3 = lean_nat_mul(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_3 = lean_nat_div(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_2 = l_Nat_nextPowerOfTwo(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_3 = lean_mk_array(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_;
x_3 = lean_st_mk_ref(x_2, x_1);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
uint8_t x_3; 
lean_dec_ref(x_1);
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
return x_2;
}
else
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
lean_dec(x_2);
x_5 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_5, 0, x_4);
return x_5;
}
}
else
{
lean_object* x_6; uint8_t x_7; 
x_6 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_6);
lean_dec_ref(x_1);
x_7 = !lean_is_exclusive(x_2);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_2, 0);
x_9 = lean_apply_1(x_6, x_8);
lean_ctor_set(x_2, 0, x_9);
return x_2;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_2, 0);
lean_inc(x_10);
lean_dec(x_2);
x_11 = lean_apply_1(x_6, x_10);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_io_cancel(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_runningRequests;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
x_2 = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_6 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_7 = lean_st_ref_take(x_6, x_5);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; uint8_t x_10; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
x_11 = lean_ctor_get(x_7, 1);
x_12 = lean_ctor_get(x_9, 0);
x_13 = lean_ctor_get(x_9, 1);
lean_inc_ref(x_3);
x_14 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_14, 0, x_3);
x_15 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_16 = lean_unsigned_to_nat(1u);
x_17 = lean_nat_add(x_12, x_16);
x_18 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
lean_ctor_set(x_7, 1, x_14);
lean_ctor_set(x_7, 0, x_15);
lean_inc(x_12);
x_19 = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(x_18, x_2, x_13, x_12, x_7);
lean_ctor_set(x_9, 1, x_19);
lean_ctor_set(x_9, 0, x_17);
x_20 = lean_st_ref_set(x_6, x_9, x_11);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; 
x_22 = lean_ctor_get(x_20, 0);
lean_dec(x_22);
lean_ctor_set(x_20, 0, x_12);
return x_20;
}
else
{
lean_object* x_23; lean_object* x_24; 
x_23 = lean_ctor_get(x_20, 1);
lean_inc(x_23);
lean_dec(x_20);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_12);
lean_ctor_set(x_24, 1, x_23);
return x_24;
}
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_25 = lean_ctor_get(x_7, 1);
x_26 = lean_ctor_get(x_9, 0);
x_27 = lean_ctor_get(x_9, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_9);
lean_inc_ref(x_3);
x_28 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_28, 0, x_3);
x_29 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_30 = lean_unsigned_to_nat(1u);
x_31 = lean_nat_add(x_26, x_30);
x_32 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
lean_ctor_set(x_7, 1, x_28);
lean_ctor_set(x_7, 0, x_29);
lean_inc(x_26);
x_33 = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(x_32, x_2, x_27, x_26, x_7);
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_31);
lean_ctor_set(x_34, 1, x_33);
x_35 = lean_st_ref_set(x_6, x_34, x_25);
x_36 = lean_ctor_get(x_35, 1);
lean_inc(x_36);
if (lean_is_exclusive(x_35)) {
 lean_ctor_release(x_35, 0);
 lean_ctor_release(x_35, 1);
 x_37 = x_35;
} else {
 lean_dec_ref(x_35);
 x_37 = lean_box(0);
}
if (lean_is_scalar(x_37)) {
 x_38 = lean_alloc_ctor(0, 2, 0);
} else {
 x_38 = x_37;
}
lean_ctor_set(x_38, 0, x_26);
lean_ctor_set(x_38, 1, x_36);
return x_38;
}
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_39 = lean_ctor_get(x_7, 0);
x_40 = lean_ctor_get(x_7, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_7);
x_41 = lean_ctor_get(x_39, 0);
lean_inc(x_41);
x_42 = lean_ctor_get(x_39, 1);
lean_inc(x_42);
if (lean_is_exclusive(x_39)) {
 lean_ctor_release(x_39, 0);
 lean_ctor_release(x_39, 1);
 x_43 = x_39;
} else {
 lean_dec_ref(x_39);
 x_43 = lean_box(0);
}
lean_inc_ref(x_3);
x_44 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_44, 0, x_3);
x_45 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_46 = lean_unsigned_to_nat(1u);
x_47 = lean_nat_add(x_41, x_46);
x_48 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_45);
lean_ctor_set(x_49, 1, x_44);
lean_inc(x_41);
x_50 = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(x_48, x_2, x_42, x_41, x_49);
if (lean_is_scalar(x_43)) {
 x_51 = lean_alloc_ctor(0, 2, 0);
} else {
 x_51 = x_43;
}
lean_ctor_set(x_51, 0, x_47);
lean_ctor_set(x_51, 1, x_50);
x_52 = lean_st_ref_set(x_6, x_51, x_40);
x_53 = lean_ctor_get(x_52, 1);
lean_inc(x_53);
if (lean_is_exclusive(x_52)) {
 lean_ctor_release(x_52, 0);
 lean_ctor_release(x_52, 1);
 x_54 = x_52;
} else {
 lean_dec_ref(x_52);
 x_54 = lean_box(0);
}
if (lean_is_scalar(x_54)) {
 x_55 = lean_alloc_ctor(0, 2, 0);
} else {
 x_55 = x_54;
}
lean_ctor_set(x_55, 0, x_41);
lean_ctor_set(x_55, 1, x_53);
return x_55;
}
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_instMonadEIO(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instHashableNat___lam__0___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__0), 2, 1);
lean_closure_set(x_6, 0, x_1);
x_7 = l_ProofWidgets_mkCancellable___redArg___closed__0;
x_8 = l_ProofWidgets_mkCancellable___redArg___closed__1;
x_9 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__2___boxed), 5, 2);
lean_closure_set(x_9, 0, x_6);
lean_closure_set(x_9, 1, x_8);
x_10 = lean_apply_1(x_2, x_3);
x_11 = lean_alloc_closure((void*)(l_ReaderT_bind), 8, 7);
lean_closure_set(x_11, 0, lean_box(0));
lean_closure_set(x_11, 1, lean_box(0));
lean_closure_set(x_11, 2, x_7);
lean_closure_set(x_11, 3, lean_box(0));
lean_closure_set(x_11, 4, lean_box(0));
lean_closure_set(x_11, 5, x_10);
lean_closure_set(x_11, 6, x_9);
x_12 = l_Lean_Server_RequestM_asTask___redArg(x_11, x_4, x_5);
return x_12;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_ProofWidgets_mkCancellable___redArg(x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_mkCancellable___redArg___lam__1(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_mkCancellable___redArg___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_2;
}
else
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 1);
x_6 = lean_ctor_get(x_2, 2);
x_7 = lean_nat_dec_eq(x_4, x_1);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_1, x_6);
lean_ctor_set(x_2, 2, x_8);
return x_2;
}
else
{
lean_free_object(x_2);
lean_dec(x_5);
lean_dec(x_4);
return x_6;
}
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_ctor_get(x_2, 0);
x_10 = lean_ctor_get(x_2, 1);
x_11 = lean_ctor_get(x_2, 2);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_2);
x_12 = lean_nat_dec_eq(x_9, x_1);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; 
x_13 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_1, x_11);
x_14 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_14, 0, x_9);
lean_ctor_set(x_14, 1, x_10);
lean_ctor_set(x_14, 2, x_13);
return x_14;
}
else
{
lean_dec(x_10);
lean_dec(x_9);
return x_11;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; uint64_t x_6; uint64_t x_7; uint64_t x_8; uint64_t x_9; uint64_t x_10; uint64_t x_11; uint64_t x_12; size_t x_13; size_t x_14; size_t x_15; size_t x_16; size_t x_17; lean_object* x_18; uint8_t x_19; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = lean_ctor_get(x_1, 1);
x_5 = lean_array_get_size(x_4);
x_6 = lean_uint64_of_nat(x_2);
x_7 = 32;
x_8 = lean_uint64_shift_right(x_6, x_7);
x_9 = lean_uint64_xor(x_6, x_8);
x_10 = 16;
x_11 = lean_uint64_shift_right(x_9, x_10);
x_12 = lean_uint64_xor(x_9, x_11);
x_13 = lean_uint64_to_usize(x_12);
x_14 = lean_usize_of_nat(x_5);
lean_dec(x_5);
x_15 = 1;
x_16 = lean_usize_sub(x_14, x_15);
x_17 = lean_usize_land(x_13, x_16);
x_18 = lean_array_uget(x_4, x_17);
x_19 = l_Std_DHashMap_Internal_AssocList_contains___at___Std_DHashMap_Internal_Raw_u2080_insertIfNew___at_____private_Lean_Meta_Match_Match_0__Lean_Meta_Match_solveCnstrs_go_spec__8_spec__8___redArg(x_2, x_18);
if (x_19 == 0)
{
lean_dec(x_18);
return x_1;
}
else
{
uint8_t x_20; 
lean_inc_ref(x_4);
lean_inc(x_3);
x_20 = !lean_is_exclusive(x_1);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_21 = lean_ctor_get(x_1, 1);
lean_dec(x_21);
x_22 = lean_ctor_get(x_1, 0);
lean_dec(x_22);
x_23 = lean_box(0);
x_24 = lean_array_uset(x_4, x_17, x_23);
x_25 = lean_unsigned_to_nat(1u);
x_26 = lean_nat_sub(x_3, x_25);
lean_dec(x_3);
x_27 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_2, x_18);
x_28 = lean_array_uset(x_24, x_17, x_27);
lean_ctor_set(x_1, 1, x_28);
lean_ctor_set(x_1, 0, x_26);
return x_1;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
lean_dec(x_1);
x_29 = lean_box(0);
x_30 = lean_array_uset(x_4, x_17, x_29);
x_31 = lean_unsigned_to_nat(1u);
x_32 = lean_nat_sub(x_3, x_31);
lean_dec(x_3);
x_33 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_2, x_18);
x_34 = lean_array_uset(x_30, x_17, x_33);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_32);
lean_ctor_set(x_35, 1, x_34);
return x_35;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ok", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_st_ref_take(x_1, x_4);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = !lean_is_exclusive(x_10);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
x_14 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_13, x_2);
lean_ctor_set(x_10, 1, x_14);
x_15 = lean_st_ref_set(x_1, x_10, x_11);
x_16 = lean_ctor_get(x_15, 1);
lean_inc(x_16);
lean_dec_ref(x_15);
x_17 = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at_____private_Lean_Meta_Tactic_Simp_Arith_Int_Basic_0__Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_13, x_2);
lean_dec(x_13);
if (lean_obj_tag(x_17) == 0)
{
x_5 = x_16;
goto block_8;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
lean_dec_ref(x_17);
x_19 = lean_ctor_get(x_18, 1);
lean_inc_ref(x_19);
lean_dec(x_18);
x_20 = lean_apply_1(x_19, x_16);
if (lean_obj_tag(x_20) == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_20, 1);
lean_inc(x_21);
lean_dec_ref(x_20);
x_5 = x_21;
goto block_8;
}
else
{
uint8_t x_22; 
x_22 = !lean_is_exclusive(x_20);
if (x_22 == 0)
{
lean_object* x_23; lean_object* x_24; 
x_23 = lean_ctor_get(x_20, 0);
x_24 = l_Lean_Server_RequestError_ofIoError(x_23);
lean_ctor_set(x_20, 0, x_24);
return x_20;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_25 = lean_ctor_get(x_20, 0);
x_26 = lean_ctor_get(x_20, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_20);
x_27 = l_Lean_Server_RequestError_ofIoError(x_25);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_26);
return x_28;
}
}
}
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_29 = lean_ctor_get(x_10, 0);
x_30 = lean_ctor_get(x_10, 1);
lean_inc(x_30);
lean_inc(x_29);
lean_dec(x_10);
lean_inc(x_30);
x_31 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_30, x_2);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_29);
lean_ctor_set(x_32, 1, x_31);
x_33 = lean_st_ref_set(x_1, x_32, x_11);
x_34 = lean_ctor_get(x_33, 1);
lean_inc(x_34);
lean_dec_ref(x_33);
x_35 = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at_____private_Lean_Meta_Tactic_Simp_Arith_Int_Basic_0__Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_30, x_2);
lean_dec(x_30);
if (lean_obj_tag(x_35) == 0)
{
x_5 = x_34;
goto block_8;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
lean_dec_ref(x_35);
x_37 = lean_ctor_get(x_36, 1);
lean_inc_ref(x_37);
lean_dec(x_36);
x_38 = lean_apply_1(x_37, x_34);
if (lean_obj_tag(x_38) == 0)
{
lean_object* x_39; 
x_39 = lean_ctor_get(x_38, 1);
lean_inc(x_39);
lean_dec_ref(x_38);
x_5 = x_39;
goto block_8;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_40 = lean_ctor_get(x_38, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_38, 1);
lean_inc(x_41);
if (lean_is_exclusive(x_38)) {
 lean_ctor_release(x_38, 0);
 lean_ctor_release(x_38, 1);
 x_42 = x_38;
} else {
 lean_dec_ref(x_38);
 x_42 = lean_box(0);
}
x_43 = l_Lean_Server_RequestError_ofIoError(x_40);
if (lean_is_scalar(x_42)) {
 x_44 = lean_alloc_ctor(1, 2, 0);
} else {
 x_44 = x_42;
}
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_41);
return x_44;
}
}
}
block_8:
{
lean_object* x_6; lean_object* x_7; 
x_6 = l_ProofWidgets_cancelRequest___lam__0___closed__0;
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_cancelRequest___lam__0___boxed), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_1);
x_6 = l_Lean_Server_RequestM_asTask___redArg(x_5, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___redArg(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_erase___at___Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0_spec__0(x_1, x_2, x_3);
lean_dec(x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0(x_1, x_2, x_3);
lean_dec(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_cancelRequest___lam__0(x_1, x_2, x_3, x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object* x_1, uint64_t x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; uint8_t x_8; 
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = lean_ctor_get(x_1, 3);
x_6 = lean_ctor_get(x_1, 4);
x_7 = lean_unbox_uint64(x_3);
x_8 = lean_uint64_dec_lt(x_2, x_7);
if (x_8 == 0)
{
uint64_t x_9; uint8_t x_10; 
x_9 = lean_unbox_uint64(x_3);
x_10 = lean_uint64_dec_eq(x_2, x_9);
if (x_10 == 0)
{
x_1 = x_6;
goto _start;
}
else
{
lean_object* x_12; 
lean_inc(x_4);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_4);
return x_12;
}
}
else
{
x_1 = x_5;
goto _start;
}
}
else
{
lean_object* x_14; 
x_14 = lean_box(0);
return x_14;
}
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(lean_object* x_1, lean_object* x_2, uint64_t x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_3);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = !lean_is_exclusive(x_10);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_13 = lean_ctor_get(x_10, 0);
x_14 = lean_ctor_get(x_10, 1);
x_15 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_15, 0, x_14);
lean_ctor_set_tag(x_3, 3);
lean_ctor_set(x_10, 1, x_13);
lean_ctor_set(x_10, 0, x_3);
x_16 = l_Prod_map___redArg(x_2, x_15, x_10);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_26, 0, x_25);
lean_ctor_set_tag(x_3, 3);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_3);
lean_ctor_set(x_27, 1, x_24);
x_28 = l_Prod_map___redArg(x_2, x_26, x_27);
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec_ref(x_28);
x_31 = lean_st_ref_set(x_1, x_30, x_11);
x_32 = lean_ctor_get(x_31, 1);
lean_inc(x_32);
if (lean_is_exclusive(x_31)) {
 lean_ctor_release(x_31, 0);
 lean_ctor_release(x_31, 1);
 x_33 = x_31;
} else {
 lean_dec_ref(x_31);
 x_33 = lean_box(0);
}
if (lean_is_scalar(x_33)) {
 x_34 = lean_alloc_ctor(0, 2, 0);
} else {
 x_34 = x_33;
}
lean_ctor_set(x_34, 0, x_29);
lean_ctor_set(x_34, 1, x_32);
return x_34;
}
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_35 = lean_ctor_get(x_3, 0);
lean_inc(x_35);
lean_dec(x_3);
x_36 = lean_st_ref_take(x_1, x_5);
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec_ref(x_36);
x_39 = lean_ctor_get(x_37, 0);
lean_inc_ref(x_39);
x_40 = lean_ctor_get(x_37, 1);
lean_inc(x_40);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 x_41 = x_37;
} else {
 lean_dec_ref(x_37);
 x_41 = lean_box(0);
}
x_42 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_42, 0, x_40);
x_43 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_43, 0, x_35);
if (lean_is_scalar(x_41)) {
 x_44 = lean_alloc_ctor(0, 2, 0);
} else {
 x_44 = x_41;
}
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_39);
x_45 = l_Prod_map___redArg(x_2, x_42, x_44);
x_46 = lean_ctor_get(x_45, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_45, 1);
lean_inc(x_47);
lean_dec_ref(x_45);
x_48 = lean_st_ref_set(x_1, x_47, x_38);
x_49 = lean_ctor_get(x_48, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_48)) {
 lean_ctor_release(x_48, 0);
 lean_ctor_release(x_48, 1);
 x_50 = x_48;
} else {
 lean_dec_ref(x_48);
 x_50 = lean_box(0);
}
if (lean_is_scalar(x_50)) {
 x_51 = lean_alloc_ctor(0, 2, 0);
} else {
 x_51 = x_50;
}
lean_ctor_set(x_51, 0, x_46);
lean_ctor_set(x_51, 1, x_49);
return x_51;
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = 9;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_13, 1);
x_16 = lean_ctor_get(x_13, 0);
lean_dec(x_16);
lean_inc(x_5);
x_17 = l_Lean_Json_getNat_x3f(x_5);
if (lean_obj_tag(x_17) == 0)
{
lean_object* x_18; uint8_t x_19; lean_object* x_20; uint8_t x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
lean_dec_ref(x_17);
x_19 = 3;
x_20 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2;
x_21 = 1;
x_22 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_21);
x_23 = lean_string_append(x_20, x_22);
lean_dec_ref(x_22);
x_24 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3;
x_25 = lean_string_append(x_23, x_24);
x_26 = l_Lean_Json_compress(x_5);
x_27 = lean_string_append(x_25, x_26);
lean_dec_ref(x_26);
x_28 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4;
x_29 = lean_string_append(x_27, x_28);
x_30 = lean_string_append(x_29, x_18);
lean_dec(x_18);
x_31 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set_uint8(x_31, sizeof(void*)*1, x_19);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_31);
return x_13;
}
else
{
lean_object* x_32; lean_object* x_33; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_32 = lean_ctor_get(x_17, 0);
lean_inc(x_32);
lean_dec_ref(x_17);
lean_inc_ref(x_6);
x_33 = lean_apply_3(x_2, x_32, x_6, x_15);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec_ref(x_33);
x_36 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_36, 0, x_12);
lean_closure_set(x_36, 1, x_3);
x_37 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_34, x_36, x_6, x_35);
return x_37;
}
else
{
uint8_t x_38; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_38 = !lean_is_exclusive(x_33);
if (x_38 == 0)
{
return x_33;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_39 = lean_ctor_get(x_33, 0);
x_40 = lean_ctor_get(x_33, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_33);
x_41 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
return x_41;
}
}
}
}
else
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_13, 1);
lean_inc(x_42);
lean_dec(x_13);
lean_inc(x_5);
x_43 = l_Lean_Json_getNat_x3f(x_5);
if (lean_obj_tag(x_43) == 0)
{
lean_object* x_44; uint8_t x_45; lean_object* x_46; uint8_t x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_44 = lean_ctor_get(x_43, 0);
lean_inc(x_44);
lean_dec_ref(x_43);
x_45 = 3;
x_46 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2;
x_47 = 1;
x_48 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_47);
x_49 = lean_string_append(x_46, x_48);
lean_dec_ref(x_48);
x_50 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3;
x_51 = lean_string_append(x_49, x_50);
x_52 = l_Lean_Json_compress(x_5);
x_53 = lean_string_append(x_51, x_52);
lean_dec_ref(x_52);
x_54 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4;
x_55 = lean_string_append(x_53, x_54);
x_56 = lean_string_append(x_55, x_44);
lean_dec(x_44);
x_57 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set_uint8(x_57, sizeof(void*)*1, x_45);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_42);
return x_58;
}
else
{
lean_object* x_59; lean_object* x_60; 
lean_dec(x_5);
lean_dec(x_1);
x_59 = lean_ctor_get(x_43, 0);
lean_inc(x_59);
lean_dec_ref(x_43);
lean_inc_ref(x_6);
x_60 = lean_apply_3(x_2, x_59, x_6, x_42);
if (lean_obj_tag(x_60) == 0)
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_61 = lean_ctor_get(x_60, 0);
lean_inc(x_61);
x_62 = lean_ctor_get(x_60, 1);
lean_inc(x_62);
lean_dec_ref(x_60);
x_63 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_63, 0, x_12);
lean_closure_set(x_63, 1, x_3);
x_64 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_61, x_63, x_6, x_62);
return x_64;
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_65 = lean_ctor_get(x_60, 0);
lean_inc(x_65);
x_66 = lean_ctor_get(x_60, 1);
lean_inc(x_66);
if (lean_is_exclusive(x_60)) {
 lean_ctor_release(x_60, 0);
 lean_ctor_release(x_60, 1);
 x_67 = x_60;
} else {
 lean_dec_ref(x_60);
 x_67 = lean_box(0);
}
if (lean_is_scalar(x_67)) {
 x_68 = lean_alloc_ctor(1, 2, 0);
} else {
 x_68 = x_67;
}
lean_ctor_set(x_68, 0, x_65);
lean_ctor_set(x_68, 1, x_66);
return x_68;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("cancelRequest", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_cancelRequest), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint64_t x_3; lean_object* x_4; 
x_3 = lean_unbox_uint64(x_2);
lean_dec(x_2);
x_4 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_1, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint64_t x_4; lean_object* x_5; 
x_4 = lean_unbox_uint64(x_3);
lean_dec(x_3);
x_5 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(x_1, x_2, x_4);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorIdx(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_CheckRequestResponse_ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
return x_2;
}
else
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_3);
lean_dec_ref(x_1);
x_4 = lean_apply_1(x_2, x_3);
return x_4;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_CheckRequestResponse_ctorElim(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_2);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_running_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_running_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_done_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_CheckRequestResponse_done_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_CheckRequestResponse_ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
return x_2;
}
else
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
lean_dec_ref(x_1);
x_4 = lean_apply_1(x_2, x_3);
return x_4;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_2);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_running____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_running____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_done____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket_done____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1__ctorElim___redArg(x_2, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no inductive constructor matched", 32, 32);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("done", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("result", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_6 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_7 = lean_unsigned_to_nat(1u);
x_8 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_9 = l_Lean_Json_parseTagged(x_1, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_3);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; 
x_11 = l_Except_orElseLazy___redArg(x_9, x_2);
lean_dec_ref(x_9);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec(x_9);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
x_14 = l_Except_orElseLazy___redArg(x_13, x_2);
lean_dec_ref(x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_9);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_9, 0);
x_17 = lean_array_get(x_3, x_16, x_4);
lean_dec(x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_9, 0, x_18);
x_19 = l_Except_orElseLazy___redArg(x_9, x_2);
lean_dec_ref(x_9);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_20 = lean_ctor_get(x_9, 0);
lean_inc(x_20);
lean_dec(x_9);
x_21 = lean_array_get(x_3, x_20, x_4);
lean_dec(x_20);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = l_Except_orElseLazy___redArg(x_23, x_2);
lean_dec_ref(x_23);
return x_24;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("running", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_), 1, 0);
x_3 = lean_box(0);
x_4 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_5 = lean_unsigned_to_nat(0u);
lean_inc(x_1);
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21____boxed), 5, 4);
lean_closure_set(x_6, 0, x_1);
lean_closure_set(x_6, 1, x_2);
lean_closure_set(x_6, 2, x_3);
lean_closure_set(x_6, 3, x_5);
x_7 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_8 = l_Lean_Json_parseTagged(x_1, x_4, x_5, x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; 
x_10 = l_Except_orElseLazy___redArg(x_8, x_6);
lean_dec_ref(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_8, 0);
lean_inc(x_11);
lean_dec(x_8);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Except_orElseLazy___redArg(x_12, x_6);
lean_dec_ref(x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
lean_dec_ref(x_8);
x_14 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_15 = l_Except_orElseLazy___redArg(x_14, x_6);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_;
return x_2;
}
else
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
x_5 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_;
lean_inc(x_3);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_3);
x_7 = lean_box(0);
x_8 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_4);
lean_ctor_set(x_10, 1, x_9);
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
x_12 = l_Lean_Json_mkObj(x_11);
return x_12;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_;
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
else
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_1);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_6 = lean_ctor_get(x_1, 0);
x_7 = lean_apply_1(x_6, x_2);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_ctor_set(x_1, 0, x_9);
x_10 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(x_1);
lean_dec_ref(x_1);
lean_ctor_set(x_7, 0, x_10);
return x_7;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_11 = lean_ctor_get(x_7, 0);
x_12 = lean_ctor_get(x_7, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_7);
lean_ctor_set(x_1, 0, x_11);
x_13 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(x_1);
lean_dec_ref(x_1);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_12);
return x_14;
}
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_15 = lean_ctor_get(x_1, 0);
lean_inc(x_15);
lean_dec(x_1);
x_16 = lean_apply_1(x_15, x_2);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
if (lean_is_exclusive(x_16)) {
 lean_ctor_release(x_16, 0);
 lean_ctor_release(x_16, 1);
 x_19 = x_16;
} else {
 lean_dec_ref(x_16);
 x_19 = lean_box(0);
}
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_17);
x_21 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_(x_20);
lean_dec_ref(x_20);
if (lean_is_scalar(x_19)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_19;
}
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_18);
return x_22;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_(x_1);
if (lean_obj_tag(x_2) == 0)
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
return x_2;
}
else
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
lean_dec(x_2);
x_5 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_5, 0, x_4);
return x_5;
}
}
else
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_2);
if (x_6 == 0)
{
lean_object* x_7; 
x_7 = lean_ctor_get(x_2, 0);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_8; 
lean_free_object(x_2);
x_8 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_;
return x_8;
}
else
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_7);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_7, 0);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_11, 0, x_10);
lean_ctor_set(x_7, 0, x_11);
return x_2;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_7, 0);
lean_inc(x_12);
lean_dec(x_7);
x_13 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_13, 0, x_12);
x_14 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_2, 0, x_14);
return x_2;
}
}
}
else
{
lean_object* x_15; 
x_15 = lean_ctor_get(x_2, 0);
lean_inc(x_15);
lean_dec(x_2);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; 
x_16 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_;
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 x_18 = x_15;
} else {
 lean_dec_ref(x_15);
 x_18 = lean_box(0);
}
x_19 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_), 2, 1);
lean_closure_set(x_19, 0, x_17);
if (lean_is_scalar(x_18)) {
 x_20 = lean_alloc_ctor(1, 1, 0);
} else {
 x_20 = x_18;
}
lean_ctor_set(x_20, 0, x_19);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Request '", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___lam__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("' has already finished, or the ID is invalid.", 45, 45);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = lean_st_ref_get(x_1, x_4);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
x_9 = lean_ctor_get(x_7, 1);
lean_inc(x_9);
lean_dec(x_7);
x_10 = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at_____private_Lean_Meta_Tactic_Simp_Arith_Int_Basic_0__Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_9, x_2);
lean_dec(x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_11 = l_ProofWidgets_checkRequest___lam__0___closed__0;
x_12 = l_Nat_reprFast(x_2);
x_13 = lean_string_append(x_11, x_12);
lean_dec_ref(x_12);
x_14 = l_ProofWidgets_checkRequest___lam__0___closed__1;
x_15 = lean_string_append(x_13, x_14);
x_16 = l_Lean_Server_RequestError_invalidParams(x_15);
lean_ctor_set_tag(x_5, 1);
lean_ctor_set(x_5, 0, x_16);
return x_5;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_free_object(x_5);
x_17 = lean_ctor_get(x_10, 0);
lean_inc(x_17);
lean_dec_ref(x_10);
x_18 = lean_ctor_get(x_17, 0);
lean_inc_ref(x_18);
lean_dec(x_17);
x_19 = lean_io_get_task_state(x_18, x_8);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_unbox(x_20);
lean_dec(x_20);
if (x_21 == 2)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec_ref(x_19);
x_23 = lean_st_ref_take(x_1, x_22);
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
x_25 = lean_ctor_get(x_23, 1);
lean_inc(x_25);
lean_dec_ref(x_23);
x_26 = !lean_is_exclusive(x_24);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_27 = lean_ctor_get(x_24, 1);
x_28 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_27, x_2);
lean_dec(x_2);
lean_ctor_set(x_24, 1, x_28);
x_29 = lean_st_ref_set(x_1, x_24, x_25);
x_30 = !lean_is_exclusive(x_29);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_29, 0);
lean_dec(x_31);
x_32 = lean_task_get_own(x_18);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
lean_dec_ref(x_32);
lean_ctor_set_tag(x_29, 1);
lean_ctor_set(x_29, 0, x_33);
return x_29;
}
else
{
uint8_t x_34; 
x_34 = !lean_is_exclusive(x_32);
if (x_34 == 0)
{
lean_ctor_set(x_29, 0, x_32);
return x_29;
}
else
{
lean_object* x_35; lean_object* x_36; 
x_35 = lean_ctor_get(x_32, 0);
lean_inc(x_35);
lean_dec(x_32);
x_36 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_36, 0, x_35);
lean_ctor_set(x_29, 0, x_36);
return x_29;
}
}
}
else
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_29, 1);
lean_inc(x_37);
lean_dec(x_29);
x_38 = lean_task_get_own(x_18);
if (lean_obj_tag(x_38) == 0)
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_38, 0);
lean_inc(x_39);
lean_dec_ref(x_38);
x_40 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_40, 0, x_39);
lean_ctor_set(x_40, 1, x_37);
return x_40;
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_41 = lean_ctor_get(x_38, 0);
lean_inc(x_41);
if (lean_is_exclusive(x_38)) {
 lean_ctor_release(x_38, 0);
 x_42 = x_38;
} else {
 lean_dec_ref(x_38);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(1, 1, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_41);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_37);
return x_44;
}
}
}
else
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_45 = lean_ctor_get(x_24, 0);
x_46 = lean_ctor_get(x_24, 1);
lean_inc(x_46);
lean_inc(x_45);
lean_dec(x_24);
x_47 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_46, x_2);
lean_dec(x_2);
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_45);
lean_ctor_set(x_48, 1, x_47);
x_49 = lean_st_ref_set(x_1, x_48, x_25);
x_50 = lean_ctor_get(x_49, 1);
lean_inc(x_50);
if (lean_is_exclusive(x_49)) {
 lean_ctor_release(x_49, 0);
 lean_ctor_release(x_49, 1);
 x_51 = x_49;
} else {
 lean_dec_ref(x_49);
 x_51 = lean_box(0);
}
x_52 = lean_task_get_own(x_18);
if (lean_obj_tag(x_52) == 0)
{
lean_object* x_53; lean_object* x_54; 
x_53 = lean_ctor_get(x_52, 0);
lean_inc(x_53);
lean_dec_ref(x_52);
if (lean_is_scalar(x_51)) {
 x_54 = lean_alloc_ctor(1, 2, 0);
} else {
 x_54 = x_51;
 lean_ctor_set_tag(x_54, 1);
}
lean_ctor_set(x_54, 0, x_53);
lean_ctor_set(x_54, 1, x_50);
return x_54;
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; 
x_55 = lean_ctor_get(x_52, 0);
lean_inc(x_55);
if (lean_is_exclusive(x_52)) {
 lean_ctor_release(x_52, 0);
 x_56 = x_52;
} else {
 lean_dec_ref(x_52);
 x_56 = lean_box(0);
}
if (lean_is_scalar(x_56)) {
 x_57 = lean_alloc_ctor(1, 1, 0);
} else {
 x_57 = x_56;
}
lean_ctor_set(x_57, 0, x_55);
if (lean_is_scalar(x_51)) {
 x_58 = lean_alloc_ctor(0, 2, 0);
} else {
 x_58 = x_51;
}
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_50);
return x_58;
}
}
}
else
{
uint8_t x_59; 
lean_dec_ref(x_18);
lean_dec(x_2);
x_59 = !lean_is_exclusive(x_19);
if (x_59 == 0)
{
lean_object* x_60; lean_object* x_61; 
x_60 = lean_ctor_get(x_19, 0);
lean_dec(x_60);
x_61 = lean_box(0);
lean_ctor_set(x_19, 0, x_61);
return x_19;
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_62 = lean_ctor_get(x_19, 1);
lean_inc(x_62);
lean_dec(x_19);
x_63 = lean_box(0);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_62);
return x_64;
}
}
}
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_65 = lean_ctor_get(x_5, 0);
x_66 = lean_ctor_get(x_5, 1);
lean_inc(x_66);
lean_inc(x_65);
lean_dec(x_5);
x_67 = lean_ctor_get(x_65, 1);
lean_inc(x_67);
lean_dec(x_65);
x_68 = l_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at_____private_Lean_Meta_Tactic_Simp_Arith_Int_Basic_0__Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_67, x_2);
lean_dec(x_67);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; 
x_69 = l_ProofWidgets_checkRequest___lam__0___closed__0;
x_70 = l_Nat_reprFast(x_2);
x_71 = lean_string_append(x_69, x_70);
lean_dec_ref(x_70);
x_72 = l_ProofWidgets_checkRequest___lam__0___closed__1;
x_73 = lean_string_append(x_71, x_72);
x_74 = l_Lean_Server_RequestError_invalidParams(x_73);
x_75 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_75, 0, x_74);
lean_ctor_set(x_75, 1, x_66);
return x_75;
}
else
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; uint8_t x_80; 
x_76 = lean_ctor_get(x_68, 0);
lean_inc(x_76);
lean_dec_ref(x_68);
x_77 = lean_ctor_get(x_76, 0);
lean_inc_ref(x_77);
lean_dec(x_76);
x_78 = lean_io_get_task_state(x_77, x_66);
x_79 = lean_ctor_get(x_78, 0);
lean_inc(x_79);
x_80 = lean_unbox(x_79);
lean_dec(x_79);
if (x_80 == 2)
{
lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; 
x_81 = lean_ctor_get(x_78, 1);
lean_inc(x_81);
lean_dec_ref(x_78);
x_82 = lean_st_ref_take(x_1, x_81);
x_83 = lean_ctor_get(x_82, 0);
lean_inc(x_83);
x_84 = lean_ctor_get(x_82, 1);
lean_inc(x_84);
lean_dec_ref(x_82);
x_85 = lean_ctor_get(x_83, 0);
lean_inc(x_85);
x_86 = lean_ctor_get(x_83, 1);
lean_inc(x_86);
if (lean_is_exclusive(x_83)) {
 lean_ctor_release(x_83, 0);
 lean_ctor_release(x_83, 1);
 x_87 = x_83;
} else {
 lean_dec_ref(x_83);
 x_87 = lean_box(0);
}
x_88 = l_Std_DHashMap_Internal_Raw_u2080_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_86, x_2);
lean_dec(x_2);
if (lean_is_scalar(x_87)) {
 x_89 = lean_alloc_ctor(0, 2, 0);
} else {
 x_89 = x_87;
}
lean_ctor_set(x_89, 0, x_85);
lean_ctor_set(x_89, 1, x_88);
x_90 = lean_st_ref_set(x_1, x_89, x_84);
x_91 = lean_ctor_get(x_90, 1);
lean_inc(x_91);
if (lean_is_exclusive(x_90)) {
 lean_ctor_release(x_90, 0);
 lean_ctor_release(x_90, 1);
 x_92 = x_90;
} else {
 lean_dec_ref(x_90);
 x_92 = lean_box(0);
}
x_93 = lean_task_get_own(x_77);
if (lean_obj_tag(x_93) == 0)
{
lean_object* x_94; lean_object* x_95; 
x_94 = lean_ctor_get(x_93, 0);
lean_inc(x_94);
lean_dec_ref(x_93);
if (lean_is_scalar(x_92)) {
 x_95 = lean_alloc_ctor(1, 2, 0);
} else {
 x_95 = x_92;
 lean_ctor_set_tag(x_95, 1);
}
lean_ctor_set(x_95, 0, x_94);
lean_ctor_set(x_95, 1, x_91);
return x_95;
}
else
{
lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; 
x_96 = lean_ctor_get(x_93, 0);
lean_inc(x_96);
if (lean_is_exclusive(x_93)) {
 lean_ctor_release(x_93, 0);
 x_97 = x_93;
} else {
 lean_dec_ref(x_93);
 x_97 = lean_box(0);
}
if (lean_is_scalar(x_97)) {
 x_98 = lean_alloc_ctor(1, 1, 0);
} else {
 x_98 = x_97;
}
lean_ctor_set(x_98, 0, x_96);
if (lean_is_scalar(x_92)) {
 x_99 = lean_alloc_ctor(0, 2, 0);
} else {
 x_99 = x_92;
}
lean_ctor_set(x_99, 0, x_98);
lean_ctor_set(x_99, 1, x_91);
return x_99;
}
}
else
{
lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; 
lean_dec_ref(x_77);
lean_dec(x_2);
x_100 = lean_ctor_get(x_78, 1);
lean_inc(x_100);
if (lean_is_exclusive(x_78)) {
 lean_ctor_release(x_78, 0);
 lean_ctor_release(x_78, 1);
 x_101 = x_78;
} else {
 lean_dec_ref(x_78);
 x_101 = lean_box(0);
}
x_102 = lean_box(0);
if (lean_is_scalar(x_101)) {
 x_103 = lean_alloc_ctor(0, 2, 0);
} else {
 x_103 = x_101;
}
lean_ctor_set(x_103, 0, x_102);
lean_ctor_set(x_103, 1, x_100);
return x_103;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_checkRequest___lam__0___boxed), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_1);
x_6 = l_Lean_Server_RequestM_asTask___redArg(x_5, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_checkRequest___lam__0(x_1, x_2, x_3, x_4);
lean_dec_ref(x_3);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec_ref(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_13, 1);
x_16 = lean_ctor_get(x_13, 0);
lean_dec(x_16);
lean_inc(x_5);
x_17 = l_Lean_Json_getNat_x3f(x_5);
if (lean_obj_tag(x_17) == 0)
{
lean_object* x_18; uint8_t x_19; lean_object* x_20; uint8_t x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
lean_dec_ref(x_17);
x_19 = 3;
x_20 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2;
x_21 = 1;
x_22 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_21);
x_23 = lean_string_append(x_20, x_22);
lean_dec_ref(x_22);
x_24 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3;
x_25 = lean_string_append(x_23, x_24);
x_26 = l_Lean_Json_compress(x_5);
x_27 = lean_string_append(x_25, x_26);
lean_dec_ref(x_26);
x_28 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4;
x_29 = lean_string_append(x_27, x_28);
x_30 = lean_string_append(x_29, x_18);
lean_dec(x_18);
x_31 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set_uint8(x_31, sizeof(void*)*1, x_19);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_31);
return x_13;
}
else
{
lean_object* x_32; lean_object* x_33; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_32 = lean_ctor_get(x_17, 0);
lean_inc(x_32);
lean_dec_ref(x_17);
lean_inc_ref(x_6);
x_33 = lean_apply_3(x_2, x_32, x_6, x_15);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec_ref(x_33);
x_36 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_36, 0, x_12);
lean_closure_set(x_36, 1, x_3);
x_37 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_34, x_36, x_6, x_35);
return x_37;
}
else
{
uint8_t x_38; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_38 = !lean_is_exclusive(x_33);
if (x_38 == 0)
{
return x_33;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_39 = lean_ctor_get(x_33, 0);
x_40 = lean_ctor_get(x_33, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_33);
x_41 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
return x_41;
}
}
}
}
else
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_13, 1);
lean_inc(x_42);
lean_dec(x_13);
lean_inc(x_5);
x_43 = l_Lean_Json_getNat_x3f(x_5);
if (lean_obj_tag(x_43) == 0)
{
lean_object* x_44; uint8_t x_45; lean_object* x_46; uint8_t x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_44 = lean_ctor_get(x_43, 0);
lean_inc(x_44);
lean_dec_ref(x_43);
x_45 = 3;
x_46 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2;
x_47 = 1;
x_48 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_47);
x_49 = lean_string_append(x_46, x_48);
lean_dec_ref(x_48);
x_50 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3;
x_51 = lean_string_append(x_49, x_50);
x_52 = l_Lean_Json_compress(x_5);
x_53 = lean_string_append(x_51, x_52);
lean_dec_ref(x_52);
x_54 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4;
x_55 = lean_string_append(x_53, x_54);
x_56 = lean_string_append(x_55, x_44);
lean_dec(x_44);
x_57 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set_uint8(x_57, sizeof(void*)*1, x_45);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_42);
return x_58;
}
else
{
lean_object* x_59; lean_object* x_60; 
lean_dec(x_5);
lean_dec(x_1);
x_59 = lean_ctor_get(x_43, 0);
lean_inc(x_59);
lean_dec_ref(x_43);
lean_inc_ref(x_6);
x_60 = lean_apply_3(x_2, x_59, x_6, x_42);
if (lean_obj_tag(x_60) == 0)
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_61 = lean_ctor_get(x_60, 0);
lean_inc(x_61);
x_62 = lean_ctor_get(x_60, 1);
lean_inc(x_62);
lean_dec_ref(x_60);
x_63 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_63, 0, x_12);
lean_closure_set(x_63, 1, x_3);
x_64 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_61, x_63, x_6, x_62);
return x_64;
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_65 = lean_ctor_get(x_60, 0);
lean_inc(x_65);
x_66 = lean_ctor_get(x_60, 1);
lean_inc(x_66);
if (lean_is_exclusive(x_60)) {
 lean_ctor_release(x_60, 0);
 lean_ctor_release(x_60, 1);
 x_67 = x_60;
} else {
 lean_dec_ref(x_60);
 x_67 = lean_box(0);
}
if (lean_is_scalar(x_67)) {
 x_68 = lean_alloc_ctor(1, 2, 0);
} else {
 x_68 = x_67;
}
lean_ctor_set(x_68, 0, x_65);
lean_ctor_set(x_68, 1, x_66);
return x_68;
}
}
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0;
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("checkRequest", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__0;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_checkRequest), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__2;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_cancellable", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_cancellableSuffix___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_cancellableSuffix___closed__1;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_2);
lean_ctor_set(x_3, 2, x_2);
lean_ctor_set(x_3, 3, x_1);
lean_ctor_set(x_3, 4, x_1);
lean_ctor_set(x_3, 5, x_1);
lean_ctor_set(x_3, 6, x_1);
lean_ctor_set(x_3, 7, x_1);
lean_ctor_set(x_3, 8, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
lean_ctor_set(x_2, 2, x_1);
lean_ctor_set(x_2, 3, x_1);
lean_ctor_set(x_2, 4, x_1);
lean_ctor_set(x_2, 5, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_4 = l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
lean_ctor_set(x_2, 2, x_1);
lean_ctor_set(x_2, 3, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = lean_box(1);
x_4 = l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_5 = l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_6 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_3);
lean_ctor_set(x_6, 3, x_2);
lean_ctor_set(x_6, 4, x_1);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mkCancellable", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(1);
x_2 = l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; uint8_t x_6; lean_object* x_7; lean_object* x_8; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_box(0);
x_3 = l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_4 = l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_5 = lean_box(1);
x_6 = 0;
x_7 = l_Lean_Meta_instInhabitedConfigWithKey___private__1;
x_8 = lean_alloc_ctor(0, 7, 3);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_5);
lean_ctor_set(x_8, 2, x_4);
lean_ctor_set(x_8, 3, x_3);
lean_ctor_set(x_8, 4, x_2);
lean_ctor_set(x_8, 5, x_1);
lean_ctor_set(x_8, 6, x_2);
lean_ctor_set_uint8(x_8, sizeof(void*)*7, x_6);
lean_ctor_set_uint8(x_8, sizeof(void*)*7 + 1, x_6);
lean_ctor_set_uint8(x_8, sizeof(void*)*7 + 2, x_6);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint8_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_9 = lean_st_mk_ref(x_8, x_7);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_9, 1);
x_22 = l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_23 = l_Lean_Name_mkStr2(x_1, x_22);
x_24 = lean_box(0);
lean_inc(x_2);
x_25 = l_Lean_Expr_const___override(x_2, x_24);
x_26 = l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_27 = lean_array_push(x_26, x_25);
x_28 = l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_11);
x_29 = l_Lean_Meta_mkAppM(x_23, x_27, x_28, x_11, x_5, x_6, x_12);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_29, 0);
lean_inc(x_30);
x_31 = lean_ctor_get(x_29, 1);
lean_inc(x_31);
lean_dec_ref(x_29);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_11);
lean_inc(x_30);
x_32 = lean_infer_type(x_30, x_28, x_11, x_5, x_6, x_31);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; uint8_t x_39; lean_object* x_40; lean_object* x_41; uint8_t x_42; lean_object* x_43; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
lean_dec_ref(x_32);
x_35 = l_ProofWidgets_cancellableSuffix;
x_36 = l_Lean_Name_append(x_2, x_35);
lean_inc(x_36);
x_37 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_37, 0, x_36);
lean_ctor_set(x_37, 1, x_24);
lean_ctor_set(x_37, 2, x_33);
x_38 = lean_box(0);
x_39 = 1;
lean_inc(x_36);
lean_ctor_set_tag(x_9, 1);
lean_ctor_set(x_9, 1, x_24);
lean_ctor_set(x_9, 0, x_36);
x_40 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_40, 0, x_37);
lean_ctor_set(x_40, 1, x_30);
lean_ctor_set(x_40, 2, x_38);
lean_ctor_set(x_40, 3, x_9);
lean_ctor_set_uint8(x_40, sizeof(void*)*4, x_39);
x_41 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_41, 0, x_40);
x_42 = 1;
lean_inc(x_6);
lean_inc_ref(x_5);
x_43 = l_Lean_addAndCompile(x_41, x_42, x_5, x_6, x_34);
if (lean_obj_tag(x_43) == 0)
{
lean_object* x_44; lean_object* x_45; 
x_44 = lean_ctor_get(x_43, 1);
lean_inc(x_44);
lean_dec_ref(x_43);
x_45 = l_Lean_Server_registerRpcProcedure(x_36, x_5, x_6, x_44);
x_13 = x_45;
goto block_21;
}
else
{
lean_dec(x_36);
lean_dec(x_6);
lean_dec_ref(x_5);
x_13 = x_43;
goto block_21;
}
}
else
{
uint8_t x_46; 
lean_dec(x_30);
lean_free_object(x_9);
lean_dec(x_11);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_2);
x_46 = !lean_is_exclusive(x_32);
if (x_46 == 0)
{
return x_32;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_47 = lean_ctor_get(x_32, 0);
x_48 = lean_ctor_get(x_32, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_32);
x_49 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_49, 0, x_47);
lean_ctor_set(x_49, 1, x_48);
return x_49;
}
}
}
else
{
uint8_t x_50; 
lean_free_object(x_9);
lean_dec(x_11);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_2);
x_50 = !lean_is_exclusive(x_29);
if (x_50 == 0)
{
return x_29;
}
else
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_51 = lean_ctor_get(x_29, 0);
x_52 = lean_ctor_get(x_29, 1);
lean_inc(x_52);
lean_inc(x_51);
lean_dec(x_29);
x_53 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_53, 0, x_51);
lean_ctor_set(x_53, 1, x_52);
return x_53;
}
}
block_21:
{
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_13, 1);
lean_inc(x_15);
lean_dec_ref(x_13);
x_16 = lean_st_ref_get(x_11, x_15);
lean_dec(x_11);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; 
x_18 = lean_ctor_get(x_16, 0);
lean_dec(x_18);
lean_ctor_set(x_16, 0, x_14);
return x_16;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_16, 1);
lean_inc(x_19);
lean_dec(x_16);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_14);
lean_ctor_set(x_20, 1, x_19);
return x_20;
}
}
else
{
lean_dec(x_11);
return x_13;
}
}
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
x_54 = lean_ctor_get(x_9, 0);
x_55 = lean_ctor_get(x_9, 1);
lean_inc(x_55);
lean_inc(x_54);
lean_dec(x_9);
x_64 = l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_65 = l_Lean_Name_mkStr2(x_1, x_64);
x_66 = lean_box(0);
lean_inc(x_2);
x_67 = l_Lean_Expr_const___override(x_2, x_66);
x_68 = l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_69 = lean_array_push(x_68, x_67);
x_70 = l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_54);
x_71 = l_Lean_Meta_mkAppM(x_65, x_69, x_70, x_54, x_5, x_6, x_55);
if (lean_obj_tag(x_71) == 0)
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; 
x_72 = lean_ctor_get(x_71, 0);
lean_inc(x_72);
x_73 = lean_ctor_get(x_71, 1);
lean_inc(x_73);
lean_dec_ref(x_71);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_54);
lean_inc(x_72);
x_74 = lean_infer_type(x_72, x_70, x_54, x_5, x_6, x_73);
if (lean_obj_tag(x_74) == 0)
{
lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; uint8_t x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; uint8_t x_85; lean_object* x_86; 
x_75 = lean_ctor_get(x_74, 0);
lean_inc(x_75);
x_76 = lean_ctor_get(x_74, 1);
lean_inc(x_76);
lean_dec_ref(x_74);
x_77 = l_ProofWidgets_cancellableSuffix;
x_78 = l_Lean_Name_append(x_2, x_77);
lean_inc(x_78);
x_79 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_79, 0, x_78);
lean_ctor_set(x_79, 1, x_66);
lean_ctor_set(x_79, 2, x_75);
x_80 = lean_box(0);
x_81 = 1;
lean_inc(x_78);
x_82 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_82, 0, x_78);
lean_ctor_set(x_82, 1, x_66);
x_83 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_83, 0, x_79);
lean_ctor_set(x_83, 1, x_72);
lean_ctor_set(x_83, 2, x_80);
lean_ctor_set(x_83, 3, x_82);
lean_ctor_set_uint8(x_83, sizeof(void*)*4, x_81);
x_84 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_84, 0, x_83);
x_85 = 1;
lean_inc(x_6);
lean_inc_ref(x_5);
x_86 = l_Lean_addAndCompile(x_84, x_85, x_5, x_6, x_76);
if (lean_obj_tag(x_86) == 0)
{
lean_object* x_87; lean_object* x_88; 
x_87 = lean_ctor_get(x_86, 1);
lean_inc(x_87);
lean_dec_ref(x_86);
x_88 = l_Lean_Server_registerRpcProcedure(x_78, x_5, x_6, x_87);
x_56 = x_88;
goto block_63;
}
else
{
lean_dec(x_78);
lean_dec(x_6);
lean_dec_ref(x_5);
x_56 = x_86;
goto block_63;
}
}
else
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; 
lean_dec(x_72);
lean_dec(x_54);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_2);
x_89 = lean_ctor_get(x_74, 0);
lean_inc(x_89);
x_90 = lean_ctor_get(x_74, 1);
lean_inc(x_90);
if (lean_is_exclusive(x_74)) {
 lean_ctor_release(x_74, 0);
 lean_ctor_release(x_74, 1);
 x_91 = x_74;
} else {
 lean_dec_ref(x_74);
 x_91 = lean_box(0);
}
if (lean_is_scalar(x_91)) {
 x_92 = lean_alloc_ctor(1, 2, 0);
} else {
 x_92 = x_91;
}
lean_ctor_set(x_92, 0, x_89);
lean_ctor_set(x_92, 1, x_90);
return x_92;
}
}
else
{
lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; 
lean_dec(x_54);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_2);
x_93 = lean_ctor_get(x_71, 0);
lean_inc(x_93);
x_94 = lean_ctor_get(x_71, 1);
lean_inc(x_94);
if (lean_is_exclusive(x_71)) {
 lean_ctor_release(x_71, 0);
 lean_ctor_release(x_71, 1);
 x_95 = x_71;
} else {
 lean_dec_ref(x_71);
 x_95 = lean_box(0);
}
if (lean_is_scalar(x_95)) {
 x_96 = lean_alloc_ctor(1, 2, 0);
} else {
 x_96 = x_95;
}
lean_ctor_set(x_96, 0, x_93);
lean_ctor_set(x_96, 1, x_94);
return x_96;
}
block_63:
{
if (lean_obj_tag(x_56) == 0)
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_57 = lean_ctor_get(x_56, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_56, 1);
lean_inc(x_58);
lean_dec_ref(x_56);
x_59 = lean_st_ref_get(x_54, x_58);
lean_dec(x_54);
x_60 = lean_ctor_get(x_59, 1);
lean_inc(x_60);
if (lean_is_exclusive(x_59)) {
 lean_ctor_release(x_59, 0);
 lean_ctor_release(x_59, 1);
 x_61 = x_59;
} else {
 lean_dec_ref(x_59);
 x_61 = lean_box(0);
}
if (lean_is_scalar(x_61)) {
 x_62 = lean_alloc_ctor(0, 2, 0);
} else {
 x_62 = x_61;
}
lean_ctor_set(x_62, 0, x_57);
lean_ctor_set(x_62, 1, x_60);
return x_62;
}
else
{
lean_dec(x_54);
return x_56;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Attribute `[", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("]` cannot be erased", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_7 = l_Lean_MessageData_ofName(x_1);
x_8 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_7);
x_9 = l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_10 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_10, 0, x_8);
lean_ctor_set(x_10, 1, x_9);
x_11 = l_Lean_throwError___at___Lean_Server_registerRpcProcedure_spec__3___redArg(x_10, x_3, x_4, x_5);
return x_11;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_2 = lean_box(0);
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("initFn", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_@", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_2 = l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cancellable", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3660767248u);
x_2 = l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_num___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_hygCtx", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_hyg", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_Lean_Name_num___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("server_rpc_method_cancellable", 29, 29);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Like `server_rpc_method`, but requests for this method can be cancelled. The method should check for that using `IO.checkCanceled`. Cancellable methods are invoked differently from JavaScript: see `callCancellable` in `cancellable.ts`.", 235, 235);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 1;
x_2 = l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_3 = l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_4 = l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_5 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_3 = lean_alloc_closure((void*)(l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed), 7, 1);
lean_closure_set(x_3, 0, x_2);
x_4 = l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed), 5, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_;
x_7 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_3);
lean_ctor_set(x_7, 2, x_5);
x_8 = l_Lean_registerBuiltinAttribute(x_7, x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; lean_object* x_9; 
x_8 = lean_unbox(x_4);
x_9 = l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
return x_6;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Data_Json_FromToJson(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Server_Rpc_RequestHandling(uint8_t builtin, lean_object*);
lean_object* initialize_Std_Data_HashMap(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Cancellable(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_FromToJson(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Server_Rpc_RequestHandling(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Data_HashMap(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Compat(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_);
res = l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_2133826679____hygCtx___hyg_2_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
l_ProofWidgets_runningRequests = lean_io_result_get_value(res);
lean_mark_persistent(l_ProofWidgets_runningRequests);
lean_dec_ref(res);
l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0 = _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0);
l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1 = _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1);
l_ProofWidgets_mkCancellable___redArg___closed__0 = _init_l_ProofWidgets_mkCancellable___redArg___closed__0();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___closed__0);
l_ProofWidgets_mkCancellable___redArg___closed__1 = _init_l_ProofWidgets_mkCancellable___redArg___closed__1();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___closed__1);
l_ProofWidgets_cancelRequest___lam__0___closed__0 = _init_l_ProofWidgets_cancelRequest___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_cancelRequest___lam__0___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__2);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__3);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___closed__4);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3);
l_ProofWidgets_cancelRequest___rpc__wrapped = _init_l_ProofWidgets_cancelRequest___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__0___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__4____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___lam__1___closed__5____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_21_);
l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable_2911678472____hygCtx___hyg_40_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_ = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_ = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable_1202226121____hygCtx___hyg_1_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2);
l_ProofWidgets_instRpcEncodableCheckRequestResponse = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse);
l_ProofWidgets_checkRequest___lam__0___closed__0 = _init_l_ProofWidgets_checkRequest___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_checkRequest___lam__0___closed__0);
l_ProofWidgets_checkRequest___lam__0___closed__1 = _init_l_ProofWidgets_checkRequest___lam__0___closed__1();
lean_mark_persistent(l_ProofWidgets_checkRequest___lam__0___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__0 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__0);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__1 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__1);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__2 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__2);
l_ProofWidgets_checkRequest___rpc__wrapped = _init_l_ProofWidgets_checkRequest___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped);
l_ProofWidgets_cancellableSuffix___closed__0 = _init_l_ProofWidgets_cancellableSuffix___closed__0();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix___closed__0);
l_ProofWidgets_cancellableSuffix___closed__1 = _init_l_ProofWidgets_cancellableSuffix___closed__1();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix___closed__1);
l_ProofWidgets_cancellableSuffix = _init_l_ProofWidgets_cancellableSuffix();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix);
l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__15____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__16____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_ = _init_l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__17____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_);
res = l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable_3660767248____hygCtx___hyg_2_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
