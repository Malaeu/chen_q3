// Lean compiler output
// Module: ProofWidgets.Component.Basic
// Imports: Init Lean.Widget.InteractiveCode Lean.Widget.UserWidget ProofWidgets.Compat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson(lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_Props_ctorIdx(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5;
extern lean_object* l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10;
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_Props_ctorIdx___boxed(lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCode;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2;
static lean_object* l_ProofWidgets_InteractiveExpr___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4;
static lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0;
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(lean_object*, lean_object*);
static uint64_t l_ProofWidgets_InteractiveMessage___closed__1;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessageProps_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_(lean_object*);
lean_object* l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ProofWidgets_InteractiveExpr___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__0;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0;
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1;
static lean_object* l_ProofWidgets_InteractiveCode___closed__2;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2;
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget_138048982____hygCtx___hyg_2__spec__3___redArg(lean_object*, uint64_t);
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2;
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static uint64_t l_ProofWidgets_InteractiveCode___closed__1;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExprProps_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1;
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1;
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__3;
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessageProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1__ctorIdx(lean_object*);
lean_object* l_Lean_Widget_WidgetInstance_ofHash(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1;
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0;
static lean_object* l_ProofWidgets_ppExprTagged___lam__0___closed__0;
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__2;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0;
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
static lean_object* l_ProofWidgets_InteractiveMessage___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_(lean_object*);
static lean_object* l_ProofWidgets_InteractiveMessage___closed__2;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9;
static lean_object* l_ProofWidgets_InteractiveExpr___closed__0;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCodeProps_ctorIdx(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExprProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Component_ctorIdx(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonWidgetSource_fromJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0(lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_;
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1__ctorIdx(lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_;
static lean_object* l_ProofWidgets_InteractiveCode___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExpr;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveMessage___closed__0;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0;
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessage;
LEAN_EXPORT lean_object* l_ProofWidgets_Component_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCodeProps_ctorIdx___boxed(lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1__ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_;
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__0;
static uint64_t l_ProofWidgets_InteractiveExpr___closed__1;
extern lean_object* l_Lean_instImpl____x40_Lean_Message_4238524789____hygCtx___hyg_234_;
static uint64_t l_ProofWidgets_MarkdownDisplay___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Component_ctorIdx(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(0u);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Component_ctorIdx___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_Component_ctorIdx(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_2);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_instToModuleComponent___lam__0___boxed), 1, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instToModuleComponent___lam__0(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCodeProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCodeProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_InteractiveCodeProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fmt", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
x_7 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
x_8 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_6, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_;
x_4 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_6);
x_8 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_(x_7);
lean_ctor_set(x_4, 0, x_8);
return x_4;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_9 = lean_ctor_get(x_4, 0);
x_10 = lean_ctor_get(x_4, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_4);
x_11 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_9);
x_12 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_(x_11);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_10);
return x_13;
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode_3233133395____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_Lean_Widget_instFromJsonTaggedText_fromJson___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0(x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
lean_dec_ref(x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec_ref(x_5);
x_10 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_;
x_11 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_dec____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__3___redArg(x_10, x_9, x_2);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
return x_11;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_11, 0);
lean_inc(x_13);
lean_dec(x_11);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_11);
if (x_15 == 0)
{
return x_11;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_11, 0);
lean_inc(x_16);
lean_dec(x_11);
x_17 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { InteractiveCode } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default function(props) {\n      return React.createElement(InteractiveCode, props)\n    }", 194, 194);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveCode___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveCode___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__1;
x_2 = l_ProofWidgets_InteractiveCode___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveCode___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveCode___closed__4;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExprProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExprProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_InteractiveExprProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expr", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
x_7 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
x_8 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_6, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; 
x_7 = l_ProofWidgets_ppExprTagged___lam__0___closed__0;
x_8 = l_Lean_Widget_ppExprTagged(x_1, x_7, x_2, x_3, x_4, x_5, x_6);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg(x_1, x_2, x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
lean_inc(x_8);
lean_inc(x_7);
lean_dec(x_5);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_5);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_5, 0);
x_12 = l_Lean_Server_RequestError_ofIoError(x_11);
lean_ctor_set(x_5, 0, x_12);
return x_5;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_ctor_get(x_5, 0);
x_14 = lean_ctor_get(x_5, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_5);
x_15 = l_Lean_Server_RequestError_ofIoError(x_13);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_14);
return x_16;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec_ref(x_1);
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged___lam__0), 6, 0);
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged___lam__1___boxed), 4, 2);
lean_closure_set(x_6, 0, x_4);
lean_closure_set(x_6, 1, x_5);
x_7 = l_Lean_Server_RequestM_asTask___redArg(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_ppExprTagged___lam__1(x_1, x_2, x_3, x_4);
lean_dec_ref(x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec_ref(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_;
x_15 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__0___redArg(x_14, x_8, x_12);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_18, 0, x_13);
x_19 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_17);
lean_ctor_set(x_15, 0, x_19);
x_20 = l_Prod_map___redArg(x_2, x_18, x_15);
x_21 = lean_ctor_get(x_20, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_20, 1);
lean_inc(x_22);
lean_dec_ref(x_20);
x_23 = lean_st_ref_set(x_1, x_22, x_11);
x_24 = !lean_is_exclusive(x_23);
if (x_24 == 0)
{
lean_object* x_25; 
x_25 = lean_ctor_get(x_23, 0);
lean_dec(x_25);
lean_ctor_set(x_23, 0, x_21);
return x_23;
}
else
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_23, 1);
lean_inc(x_26);
lean_dec(x_23);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_21);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_28 = lean_ctor_get(x_15, 0);
x_29 = lean_ctor_get(x_15, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_15);
x_30 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_30, 0, x_13);
x_31 = l_Lean_Widget_instToJsonTaggedText_toJson___at___Lean_Widget_instRpcEncodableMsgEmbed_enc____x40_Lean_Widget_InteractiveDiagnostic_1765450820____hygCtx___hyg_1__spec__2(x_28);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_29);
x_33 = l_Prod_map___redArg(x_2, x_30, x_32);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec_ref(x_33);
x_36 = lean_st_ref_set(x_1, x_35, x_11);
x_37 = lean_ctor_get(x_36, 1);
lean_inc(x_37);
if (lean_is_exclusive(x_36)) {
 lean_ctor_release(x_36, 0);
 lean_ctor_release(x_36, 1);
 x_38 = x_36;
} else {
 lean_dec_ref(x_36);
 x_38 = lean_box(0);
}
if (lean_is_scalar(x_38)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_38;
}
lean_ctor_set(x_39, 0, x_34);
lean_ctor_set(x_39, 1, x_37);
return x_39;
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = 9;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget_138048982____hygCtx___hyg_2__spec__3___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
x_17 = lean_ctor_get(x_15, 0);
lean_inc_ref(x_17);
lean_dec(x_15);
lean_inc(x_5);
x_18 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(x_5, x_17);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; uint8_t x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec_ref(x_18);
x_20 = 3;
x_21 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2;
x_22 = 1;
x_23 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_22);
x_24 = lean_string_append(x_21, x_23);
lean_dec_ref(x_23);
x_25 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3;
x_26 = lean_string_append(x_24, x_25);
x_27 = l_Lean_Json_compress(x_5);
x_28 = lean_string_append(x_26, x_27);
lean_dec_ref(x_27);
x_29 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4;
x_30 = lean_string_append(x_28, x_29);
x_31 = lean_string_append(x_30, x_19);
lean_dec(x_19);
x_32 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set_uint8(x_32, sizeof(void*)*1, x_20);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_32);
return x_13;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_33 = lean_ctor_get(x_18, 0);
lean_inc(x_33);
lean_dec_ref(x_18);
lean_inc_ref(x_6);
x_34 = lean_apply_3(x_2, x_33, x_6, x_16);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec_ref(x_34);
x_37 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_37, 0, x_12);
lean_closure_set(x_37, 1, x_3);
x_38 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_35, x_37, x_6, x_36);
return x_38;
}
else
{
uint8_t x_39; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_39 = !lean_is_exclusive(x_34);
if (x_39 == 0)
{
return x_34;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_34, 0);
x_41 = lean_ctor_get(x_34, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_34);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_43 = lean_ctor_get(x_13, 0);
x_44 = lean_ctor_get(x_13, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_13);
x_45 = lean_ctor_get(x_43, 0);
lean_inc_ref(x_45);
lean_dec(x_43);
lean_inc(x_5);
x_46 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic_2987839534____hygCtx___hyg_1_(x_5, x_45);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; uint8_t x_48; lean_object* x_49; uint8_t x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec_ref(x_46);
x_48 = 3;
x_49 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2;
x_50 = 1;
x_51 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_50);
x_52 = lean_string_append(x_49, x_51);
lean_dec_ref(x_51);
x_53 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3;
x_54 = lean_string_append(x_52, x_53);
x_55 = l_Lean_Json_compress(x_5);
x_56 = lean_string_append(x_54, x_55);
lean_dec_ref(x_55);
x_57 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4;
x_58 = lean_string_append(x_56, x_57);
x_59 = lean_string_append(x_58, x_47);
lean_dec(x_47);
x_60 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set_uint8(x_60, sizeof(void*)*1, x_48);
x_61 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_44);
return x_61;
}
else
{
lean_object* x_62; lean_object* x_63; 
lean_dec(x_5);
lean_dec(x_1);
x_62 = lean_ctor_get(x_46, 0);
lean_inc(x_62);
lean_dec_ref(x_46);
lean_inc_ref(x_6);
x_63 = lean_apply_3(x_2, x_62, x_6, x_44);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_63, 1);
lean_inc(x_65);
lean_dec_ref(x_63);
x_66 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_66, 0, x_12);
lean_closure_set(x_66, 1, x_3);
x_67 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_64, x_66, x_6, x_65);
return x_67;
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_68 = lean_ctor_get(x_63, 0);
lean_inc(x_68);
x_69 = lean_ctor_get(x_63, 1);
lean_inc(x_69);
if (lean_is_exclusive(x_63)) {
 lean_ctor_release(x_63, 0);
 lean_ctor_release(x_63, 1);
 x_70 = x_63;
} else {
 lean_dec_ref(x_63);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(1, 2, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_68);
lean_ctor_set(x_71, 1, x_69);
return x_71;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ppExprTagged", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2;
x_2 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsx as e,jsxs as r,Fragment as o}from\"react/jsx-runtime\";import{useRpcSession as t,useAsyncPersistent as a,InteractiveCode as i,mapRpcError as n}from\"@leanprover/infoview\";function d({expr:d}){const p=t(),s=a((()=>p.call(\"ProofWidgets.ppExprTagged\",{expr:d})),[d]);return\"resolved\"===s.state\?e(i,{fmt:s.value}):\"rejected\"===s.state\?r(o,{children:[\"Error: $\",n(s.error).message]}):e(o,{children:\"Loading..\"})}export{d as default};", 443, 443);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveExpr___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__1;
x_2 = l_ProofWidgets_InteractiveExpr___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveExpr___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessageProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessageProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_InteractiveMessageProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_RpcEncodablePacket____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("msg", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
x_7 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
x_8 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_6, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_Lean_instImpl____x40_Lean_Message_4238524789____hygCtx___hyg_234_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_Lean_instImpl____x40_Lean_Message_4238524789____hygCtx___hyg_234_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic_2277670097____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { InteractiveMessageData } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default function(props) {\n      return React.createElement(InteractiveMessageData, props)\n    }\n  ", 211, 211);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveMessage___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__1;
x_2 = l_ProofWidgets_InteractiveMessage___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveMessage___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_Props_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_Props_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_MarkdownDisplay_Props_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("contents", 8, 8);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0;
x_3 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_3);
x_5 = lean_box(0);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_5);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
x_8 = l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_;
x_9 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("MarkdownDisplay", 15, 15);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Props", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0;
x_3 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(".", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(": ", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9;
x_2 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; 
x_2 = l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonWidgetSource_fromJson_spec__0(x_1, x_2);
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10;
x_7 = lean_string_append(x_6, x_5);
lean_dec(x_5);
lean_ctor_set(x_3, 0, x_7);
return x_3;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10;
x_10 = lean_string_append(x_9, x_8);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_3);
if (x_12 == 0)
{
lean_ctor_set_tag(x_3, 0);
return x_3;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_3, 0);
lean_inc(x_13);
lean_dec(x_3);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_3);
if (x_15 == 0)
{
return x_3;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_3, 0);
lean_inc(x_16);
lean_dec(x_3);
x_17 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { Markdown } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default (props) => React.createElement(Markdown, props)\n  ", 157, 157);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_MarkdownDisplay___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__1;
x_2 = l_ProofWidgets_MarkdownDisplay___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_MarkdownDisplay___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_1);
if (x_8 == 0)
{
lean_object* x_9; uint64_t x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_9 = lean_ctor_get(x_2, 0);
x_10 = lean_ctor_get_uint64(x_9, sizeof(void*)*1);
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_ctor_get(x_1, 1);
lean_dec(x_12);
x_13 = lean_apply_1(x_11, x_3);
x_14 = l_Lean_Widget_WidgetInstance_ofHash(x_10, x_13, x_5, x_6, x_7);
if (lean_obj_tag(x_14) == 0)
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_17, 0, x_4);
x_18 = l_Lean_MessageData_ofFormat(x_17);
lean_ctor_set_tag(x_1, 2);
lean_ctor_set(x_1, 1, x_18);
lean_ctor_set(x_1, 0, x_16);
lean_ctor_set(x_14, 0, x_1);
return x_14;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_19 = lean_ctor_get(x_14, 0);
x_20 = lean_ctor_get(x_14, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_14);
x_21 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_21, 0, x_4);
x_22 = l_Lean_MessageData_ofFormat(x_21);
lean_ctor_set_tag(x_1, 2);
lean_ctor_set(x_1, 1, x_22);
lean_ctor_set(x_1, 0, x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_1);
lean_ctor_set(x_23, 1, x_20);
return x_23;
}
}
else
{
uint8_t x_24; 
lean_free_object(x_1);
lean_dec_ref(x_4);
x_24 = !lean_is_exclusive(x_14);
if (x_24 == 0)
{
return x_14;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_25 = lean_ctor_get(x_14, 0);
x_26 = lean_ctor_get(x_14, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_14);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
}
else
{
lean_object* x_28; uint64_t x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_28 = lean_ctor_get(x_2, 0);
x_29 = lean_ctor_get_uint64(x_28, sizeof(void*)*1);
x_30 = lean_ctor_get(x_1, 0);
lean_inc(x_30);
lean_dec(x_1);
x_31 = lean_apply_1(x_30, x_3);
x_32 = l_Lean_Widget_WidgetInstance_ofHash(x_29, x_31, x_5, x_6, x_7);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 lean_ctor_release(x_32, 1);
 x_35 = x_32;
} else {
 lean_dec_ref(x_32);
 x_35 = lean_box(0);
}
x_36 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_36, 0, x_4);
x_37 = l_Lean_MessageData_ofFormat(x_36);
x_38 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_38, 0, x_33);
lean_ctor_set(x_38, 1, x_37);
if (lean_is_scalar(x_35)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_35;
}
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_34);
return x_39;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec_ref(x_4);
x_40 = lean_ctor_get(x_32, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_32, 1);
lean_inc(x_41);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 lean_ctor_release(x_32, 1);
 x_42 = x_32;
} else {
 lean_dec_ref(x_32);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(1, 2, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_40);
lean_ctor_set(x_43, 1, x_41);
return x_43;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_MessageData_ofComponent___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_MessageData_ofComponent___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec_ref(x_2);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_MessageData_ofComponent(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
return x_9;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Widget_InteractiveCode(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Widget_UserWidget(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Widget_InteractiveCode(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Widget_UserWidget(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Compat(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_17_);
l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_3681643396____hygCtx___hyg_35_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_ = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_ = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic_1956376046____hygCtx___hyg_1_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps);
l_ProofWidgets_InteractiveCode___closed__0 = _init_l_ProofWidgets_InteractiveCode___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__0);
l_ProofWidgets_InteractiveCode___closed__1 = _init_l_ProofWidgets_InteractiveCode___closed__1();
l_ProofWidgets_InteractiveCode___closed__2 = _init_l_ProofWidgets_InteractiveCode___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__2);
l_ProofWidgets_InteractiveCode___closed__3 = _init_l_ProofWidgets_InteractiveCode___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__3);
l_ProofWidgets_InteractiveCode___closed__4 = _init_l_ProofWidgets_InteractiveCode___closed__4();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__4);
l_ProofWidgets_InteractiveCode = _init_l_ProofWidgets_InteractiveCode();
lean_mark_persistent(l_ProofWidgets_InteractiveCode);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_17_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_2852768078____hygCtx___hyg_35_);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveExprProps = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps);
l_ProofWidgets_ppExprTagged___lam__0___closed__0 = _init_l_ProofWidgets_ppExprTagged___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___lam__0___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__2);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__3);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___closed__4);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3);
l_ProofWidgets_ppExprTagged___rpc__wrapped = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped);
l_ProofWidgets_InteractiveExpr___closed__0 = _init_l_ProofWidgets_InteractiveExpr___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__0);
l_ProofWidgets_InteractiveExpr___closed__1 = _init_l_ProofWidgets_InteractiveExpr___closed__1();
l_ProofWidgets_InteractiveExpr___closed__2 = _init_l_ProofWidgets_InteractiveExpr___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__2);
l_ProofWidgets_InteractiveExpr___closed__3 = _init_l_ProofWidgets_InteractiveExpr___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__3);
l_ProofWidgets_InteractiveExpr = _init_l_ProofWidgets_InteractiveExpr();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr);
l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_17_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic_4050566044____hygCtx___hyg_35_);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps);
l_ProofWidgets_InteractiveMessage___closed__0 = _init_l_ProofWidgets_InteractiveMessage___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__0);
l_ProofWidgets_InteractiveMessage___closed__1 = _init_l_ProofWidgets_InteractiveMessage___closed__1();
l_ProofWidgets_InteractiveMessage___closed__2 = _init_l_ProofWidgets_InteractiveMessage___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__2);
l_ProofWidgets_InteractiveMessage___closed__3 = _init_l_ProofWidgets_InteractiveMessage___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__3);
l_ProofWidgets_InteractiveMessage = _init_l_ProofWidgets_InteractiveMessage();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage);
l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instToJsonProps_toJson___closed__0);
l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0);
l_ProofWidgets_MarkdownDisplay_instToJsonProps = _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instToJsonProps);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__0);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__1);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__2);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__3);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__4);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__5);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__6);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__7);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__8);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__9);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps_fromJson___closed__10);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps);
l_ProofWidgets_MarkdownDisplay___closed__0 = _init_l_ProofWidgets_MarkdownDisplay___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__0);
l_ProofWidgets_MarkdownDisplay___closed__1 = _init_l_ProofWidgets_MarkdownDisplay___closed__1();
l_ProofWidgets_MarkdownDisplay___closed__2 = _init_l_ProofWidgets_MarkdownDisplay___closed__2();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__2);
l_ProofWidgets_MarkdownDisplay___closed__3 = _init_l_ProofWidgets_MarkdownDisplay___closed__3();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__3);
l_ProofWidgets_MarkdownDisplay = _init_l_ProofWidgets_MarkdownDisplay();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
