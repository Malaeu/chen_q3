// Lean compiler output
// Module: ProofWidgets.Demos.LazyComputation
// Imports: Init ProofWidgets.Component.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_;
static lean_object* l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
LEAN_EXPORT lean_object* l_makeRunnerTac;
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedFileMap_default;
LEAN_EXPORT lean_object* l_RunnerWidgetProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1__ctorIdx(lean_object*);
static lean_object* l_runnerWidget___closed__3;
static lean_object* l_makeRunnerTac___closed__1;
static lean_object* l_makeRunnerTac___closed__2;
LEAN_EXPORT lean_object* l_instTypeNameMetaMStringCont;
LEAN_EXPORT lean_object* l_runMetaMStringCont(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_makeRunner___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4;
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0;
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps;
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at_____private_Lean_Elab_Tactic_Basic_0__Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__3___redArg(lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_(lean_object*);
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_runnerWidget;
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget_138048982____hygCtx___hyg_2__spec__3___redArg(lean_object*, uint64_t);
lean_object* lean_st_ref_take(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
static lean_object* l_makeRunner___closed__0;
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1;
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_runMetaMStringCont___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l_MetaMStringCont_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_makeRunner(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_makeRunner___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1____boxed(lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_runMetaMStringCont___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static uint64_t l_runnerWidget___closed__1;
LEAN_EXPORT lean_object* l_runMetaMStringCont___rpc__wrapped;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_makeRunnerTac___closed__3;
static lean_object* l_runMetaMStringCont___rpc__wrapped___closed__1;
static lean_object* l_runnerWidget___closed__4;
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_RunnerWidgetProps_ctorIdx___boxed(lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_;
static lean_object* l_instRpcEncodableRunnerWidgetProps___closed__2;
static lean_object* l_makeRunnerTac___closed__0;
lean_object* l_Lean_Server_WithRpcRef_mk___redArg(lean_object*, lean_object*);
static lean_object* l_makeRunnerTac___closed__4;
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_(lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2;
static lean_object* l_runMetaMStringCont___rpc__wrapped___closed__2;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_runnerWidget___closed__2;
LEAN_EXPORT lean_object* l_runMetaMStringCont___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_makeRunner___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
static lean_object* l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_instRpcEncodableRunnerWidgetProps___closed__0;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_dec____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
LEAN_EXPORT lean_object* l_MetaMStringCont_ctorIdx___boxed(lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_runnerWidget___closed__0;
static lean_object* l_instRpcEncodableRunnerWidgetProps___closed__1;
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_MetaMStringCont_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_MetaMStringCont_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_MetaMStringCont_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("MetaMStringCont", 15, 15);
return x_1;
}
}
static lean_object* _init_l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_() {
_start:
{
lean_object* x_1; 
x_1 = l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
return x_1;
}
}
static lean_object* _init_l_instTypeNameMetaMStringCont() {
_start:
{
lean_object* x_1; 
x_1 = l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_RunnerWidgetProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RunnerWidgetProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RunnerWidgetProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("k", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
x_7 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_;
x_8 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_6, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
return x_9;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableRunnerWidgetProps_dec____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_instRpcEncodableRunnerWidgetProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRunnerWidgetProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableRunnerWidgetProps_dec____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableRunnerWidgetProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableRunnerWidgetProps___closed__1;
x_2 = l_instRpcEncodableRunnerWidgetProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableRunnerWidgetProps() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableRunnerWidgetProps___closed__2;
return x_1;
}
}
LEAN_EXPORT lean_object* l_runMetaMStringCont___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_4);
x_5 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_5);
x_6 = lean_ctor_get(x_1, 2);
lean_inc_ref(x_6);
lean_dec(x_1);
x_7 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_4, x_5, x_6, x_3);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = lean_ctor_get(x_7, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
return x_11;
}
}
else
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_7);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_7, 0);
x_14 = l_Lean_Server_RequestError_ofIoError(x_13);
lean_ctor_set(x_7, 0, x_14);
return x_7;
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_7, 0);
x_16 = lean_ctor_get(x_7, 1);
lean_inc(x_16);
lean_inc(x_15);
lean_dec(x_7);
x_17 = l_Lean_Server_RequestError_ofIoError(x_15);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_16);
return x_18;
}
}
}
}
LEAN_EXPORT lean_object* l_runMetaMStringCont(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec_ref(x_1);
x_5 = lean_alloc_closure((void*)(l_runMetaMStringCont___lam__0___boxed), 3, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = l_Lean_Server_RequestM_asTask___redArg(x_5, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_runMetaMStringCont___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_runMetaMStringCont___lam__0(x_1, x_2, x_3);
lean_dec_ref(x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_3);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = !lean_is_exclusive(x_10);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_13 = lean_ctor_get(x_10, 0);
x_14 = lean_ctor_get(x_10, 1);
x_15 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_15, 0, x_14);
lean_ctor_set_tag(x_3, 3);
lean_ctor_set(x_10, 1, x_13);
lean_ctor_set(x_10, 0, x_3);
x_16 = l_Prod_map___redArg(x_2, x_15, x_10);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_26, 0, x_25);
lean_ctor_set_tag(x_3, 3);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_3);
lean_ctor_set(x_27, 1, x_24);
x_28 = l_Prod_map___redArg(x_2, x_26, x_27);
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec_ref(x_28);
x_31 = lean_st_ref_set(x_1, x_30, x_11);
x_32 = lean_ctor_get(x_31, 1);
lean_inc(x_32);
if (lean_is_exclusive(x_31)) {
 lean_ctor_release(x_31, 0);
 lean_ctor_release(x_31, 1);
 x_33 = x_31;
} else {
 lean_dec_ref(x_31);
 x_33 = lean_box(0);
}
if (lean_is_scalar(x_33)) {
 x_34 = lean_alloc_ctor(0, 2, 0);
} else {
 x_34 = x_33;
}
lean_ctor_set(x_34, 0, x_29);
lean_ctor_set(x_34, 1, x_32);
return x_34;
}
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_35 = lean_ctor_get(x_3, 0);
lean_inc(x_35);
lean_dec(x_3);
x_36 = lean_st_ref_take(x_1, x_5);
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec_ref(x_36);
x_39 = lean_ctor_get(x_37, 0);
lean_inc_ref(x_39);
x_40 = lean_ctor_get(x_37, 1);
lean_inc(x_40);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 x_41 = x_37;
} else {
 lean_dec_ref(x_37);
 x_41 = lean_box(0);
}
x_42 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_42, 0, x_40);
x_43 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_43, 0, x_35);
if (lean_is_scalar(x_41)) {
 x_44 = lean_alloc_ctor(0, 2, 0);
} else {
 x_44 = x_41;
}
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_39);
x_45 = l_Prod_map___redArg(x_2, x_42, x_44);
x_46 = lean_ctor_get(x_45, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_45, 1);
lean_inc(x_47);
lean_dec_ref(x_45);
x_48 = lean_st_ref_set(x_1, x_47, x_38);
x_49 = lean_ctor_get(x_48, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_48)) {
 lean_ctor_release(x_48, 0);
 lean_ctor_release(x_48, 1);
 x_50 = x_48;
} else {
 lean_dec_ref(x_48);
 x_50 = lean_box(0);
}
if (lean_is_scalar(x_50)) {
 x_51 = lean_alloc_ctor(0, 2, 0);
} else {
 x_51 = x_50;
}
lean_ctor_set(x_51, 0, x_46);
lean_ctor_set(x_51, 1, x_49);
return x_51;
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = 9;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget_138048982____hygCtx___hyg_2__spec__3___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
x_17 = lean_ctor_get(x_15, 0);
lean_inc_ref(x_17);
lean_dec(x_15);
lean_inc(x_5);
x_18 = l_instRpcEncodableRunnerWidgetProps_dec____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(x_5, x_17);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; uint8_t x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec_ref(x_18);
x_20 = 3;
x_21 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2;
x_22 = 1;
x_23 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_22);
x_24 = lean_string_append(x_21, x_23);
lean_dec_ref(x_23);
x_25 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3;
x_26 = lean_string_append(x_24, x_25);
x_27 = l_Lean_Json_compress(x_5);
x_28 = lean_string_append(x_26, x_27);
lean_dec_ref(x_27);
x_29 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4;
x_30 = lean_string_append(x_28, x_29);
x_31 = lean_string_append(x_30, x_19);
lean_dec(x_19);
x_32 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set_uint8(x_32, sizeof(void*)*1, x_20);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_32);
return x_13;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_33 = lean_ctor_get(x_18, 0);
lean_inc(x_33);
lean_dec_ref(x_18);
lean_inc_ref(x_6);
x_34 = lean_apply_3(x_2, x_33, x_6, x_16);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec_ref(x_34);
x_37 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_37, 0, x_12);
lean_closure_set(x_37, 1, x_3);
x_38 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_35, x_37, x_6, x_36);
return x_38;
}
else
{
uint8_t x_39; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_39 = !lean_is_exclusive(x_34);
if (x_39 == 0)
{
return x_34;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_34, 0);
x_41 = lean_ctor_get(x_34, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_34);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_43 = lean_ctor_get(x_13, 0);
x_44 = lean_ctor_get(x_13, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_13);
x_45 = lean_ctor_get(x_43, 0);
lean_inc_ref(x_45);
lean_dec(x_43);
lean_inc(x_5);
x_46 = l_instRpcEncodableRunnerWidgetProps_dec____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1_(x_5, x_45);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; uint8_t x_48; lean_object* x_49; uint8_t x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec_ref(x_46);
x_48 = 3;
x_49 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2;
x_50 = 1;
x_51 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_50);
x_52 = lean_string_append(x_49, x_51);
lean_dec_ref(x_51);
x_53 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3;
x_54 = lean_string_append(x_52, x_53);
x_55 = l_Lean_Json_compress(x_5);
x_56 = lean_string_append(x_54, x_55);
lean_dec_ref(x_55);
x_57 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4;
x_58 = lean_string_append(x_56, x_57);
x_59 = lean_string_append(x_58, x_47);
lean_dec(x_47);
x_60 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set_uint8(x_60, sizeof(void*)*1, x_48);
x_61 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_44);
return x_61;
}
else
{
lean_object* x_62; lean_object* x_63; 
lean_dec(x_5);
lean_dec(x_1);
x_62 = lean_ctor_get(x_46, 0);
lean_inc(x_62);
lean_dec_ref(x_46);
lean_inc_ref(x_6);
x_63 = lean_apply_3(x_2, x_62, x_6, x_44);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_63, 1);
lean_inc(x_65);
lean_dec_ref(x_63);
x_66 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_66, 0, x_12);
lean_closure_set(x_66, 1, x_3);
x_67 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_64, x_66, x_6, x_65);
return x_67;
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_68 = lean_ctor_get(x_63, 0);
lean_inc(x_68);
x_69 = lean_ctor_get(x_63, 1);
lean_inc(x_69);
if (lean_is_exclusive(x_63)) {
 lean_ctor_release(x_63, 0);
 lean_ctor_release(x_63, 1);
 x_70 = x_63;
} else {
 lean_dec_ref(x_63);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(1, 2, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_68);
lean_ctor_set(x_71, 1, x_69);
return x_71;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_runMetaMStringCont___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("runMetaMStringCont", 18, 18);
return x_1;
}
}
static lean_object* _init_l_runMetaMStringCont___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_runMetaMStringCont___rpc__wrapped___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_runMetaMStringCont___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_runMetaMStringCont), 3, 0);
return x_1;
}
}
static lean_object* _init_l_runMetaMStringCont___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_runMetaMStringCont___rpc__wrapped___closed__1;
x_2 = l_runMetaMStringCont___rpc__wrapped___closed__2;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l_runnerWidget___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { RpcContext, mapRpcError } from '@leanprover/infoview'\n    import * as React from 'react';\n    const e = React.createElement;\n\n    export default function(props) {\n      const [contents, setContents] = React.useState('Run!')\n      const rs = React.useContext(RpcContext)\n      return e('button', { onClick: () => {\n        setContents('Running..')\n        rs.call('runMetaMStringCont', props)\n          .then(setContents)\n          .catch(e => { setContents(mapRpcError(e).message) })\n      }}, contents)\n    }\n  ", 526, 526);
return x_1;
}
}
static uint64_t _init_l_runnerWidget___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_runnerWidget___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_runnerWidget___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_runnerWidget___closed__1;
x_2 = l_runnerWidget___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_runnerWidget___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_runnerWidget___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_runnerWidget___closed__3;
x_2 = l_runnerWidget___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_runnerWidget() {
_start:
{
lean_object* x_1; 
x_1 = l_runnerWidget___closed__4;
return x_1;
}
}
static lean_object* _init_l_makeRunnerTac___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("makeRunnerTac", 13, 13);
return x_1;
}
}
static lean_object* _init_l_makeRunnerTac___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_makeRunnerTac___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_makeRunnerTac___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("make_runner", 11, 11);
return x_1;
}
}
static lean_object* _init_l_makeRunnerTac___closed__3() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 0;
x_2 = l_makeRunnerTac___closed__2;
x_3 = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_makeRunnerTac___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_makeRunnerTac___closed__3;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_makeRunnerTac___closed__1;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_makeRunnerTac() {
_start:
{
lean_object* x_1; 
x_1 = l_makeRunnerTac___closed__4;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_5 = lean_st_ref_get(x_3, x_4);
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_5, 1);
lean_inc(x_7);
lean_dec_ref(x_5);
x_8 = lean_ctor_get(x_6, 0);
lean_inc_ref(x_8);
lean_dec(x_6);
x_9 = lean_st_ref_get(x_1, x_7);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
lean_dec(x_10);
x_13 = lean_ctor_get(x_2, 2);
x_14 = lean_ctor_get(x_2, 6);
x_15 = lean_ctor_get(x_2, 7);
x_16 = lean_st_ref_get(x_3, x_11);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_18 = lean_ctor_get(x_16, 0);
x_19 = lean_ctor_get(x_18, 2);
lean_inc_ref(x_19);
lean_dec(x_18);
x_20 = l_Lean_instInhabitedFileMap_default;
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
x_21 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_21, 0, x_8);
lean_ctor_set(x_21, 1, x_20);
lean_ctor_set(x_21, 2, x_12);
lean_ctor_set(x_21, 3, x_13);
lean_ctor_set(x_21, 4, x_14);
lean_ctor_set(x_21, 5, x_15);
lean_ctor_set(x_21, 6, x_19);
lean_ctor_set(x_16, 0, x_21);
return x_16;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_22 = lean_ctor_get(x_16, 0);
x_23 = lean_ctor_get(x_16, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_16);
x_24 = lean_ctor_get(x_22, 2);
lean_inc_ref(x_24);
lean_dec(x_22);
x_25 = l_Lean_instInhabitedFileMap_default;
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
x_26 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_26, 0, x_8);
lean_ctor_set(x_26, 1, x_25);
lean_ctor_set(x_26, 2, x_12);
lean_ctor_set(x_26, 3, x_13);
lean_ctor_set(x_26, 4, x_14);
lean_ctor_set(x_26, 5, x_15);
lean_ctor_set(x_26, 6, x_24);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_23);
return x_27;
}
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg(x_6, x_7, x_8, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; uint8_t x_11; 
x_10 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg(x_6, x_7, x_8, x_9);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; uint8_t x_13; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_7, 1);
x_15 = lean_ctor_get(x_12, 1);
lean_dec(x_15);
lean_inc_ref(x_14);
lean_ctor_set(x_12, 1, x_14);
return x_10;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_16 = lean_ctor_get(x_7, 1);
x_17 = lean_ctor_get(x_12, 0);
x_18 = lean_ctor_get(x_12, 2);
x_19 = lean_ctor_get(x_12, 3);
x_20 = lean_ctor_get(x_12, 4);
x_21 = lean_ctor_get(x_12, 5);
x_22 = lean_ctor_get(x_12, 6);
lean_inc(x_22);
lean_inc(x_21);
lean_inc(x_20);
lean_inc(x_19);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_12);
lean_inc_ref(x_16);
x_23 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_16);
lean_ctor_set(x_23, 2, x_18);
lean_ctor_set(x_23, 3, x_19);
lean_ctor_set(x_23, 4, x_20);
lean_ctor_set(x_23, 5, x_21);
lean_ctor_set(x_23, 6, x_22);
lean_ctor_set(x_10, 0, x_23);
return x_10;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_ctor_get(x_7, 1);
x_27 = lean_ctor_get(x_24, 0);
lean_inc_ref(x_27);
x_28 = lean_ctor_get(x_24, 2);
lean_inc_ref(x_28);
x_29 = lean_ctor_get(x_24, 3);
lean_inc(x_29);
x_30 = lean_ctor_get(x_24, 4);
lean_inc(x_30);
x_31 = lean_ctor_get(x_24, 5);
lean_inc(x_31);
x_32 = lean_ctor_get(x_24, 6);
lean_inc_ref(x_32);
if (lean_is_exclusive(x_24)) {
 lean_ctor_release(x_24, 0);
 lean_ctor_release(x_24, 1);
 lean_ctor_release(x_24, 2);
 lean_ctor_release(x_24, 3);
 lean_ctor_release(x_24, 4);
 lean_ctor_release(x_24, 5);
 lean_ctor_release(x_24, 6);
 x_33 = x_24;
} else {
 lean_dec_ref(x_24);
 x_33 = lean_box(0);
}
lean_inc_ref(x_26);
if (lean_is_scalar(x_33)) {
 x_34 = lean_alloc_ctor(0, 7, 0);
} else {
 x_34 = x_33;
}
lean_ctor_set(x_34, 0, x_27);
lean_ctor_set(x_34, 1, x_26);
lean_ctor_set(x_34, 2, x_28);
lean_ctor_set(x_34, 3, x_29);
lean_ctor_set(x_34, 4, x_30);
lean_ctor_set(x_34, 5, x_31);
lean_ctor_set(x_34, 6, x_32);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_35, 1, x_25);
return x_35;
}
}
}
LEAN_EXPORT lean_object* l_makeRunner___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_1);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
static lean_object* _init_l_makeRunner___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Hello, world!", 13, 13);
return x_1;
}
}
LEAN_EXPORT lean_object* l_makeRunner(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; uint8_t x_12; 
x_11 = l_makeRunnerTac___closed__1;
lean_inc(x_1);
x_12 = l_Lean_Syntax_isOfKind(x_1, x_11);
if (x_12 == 0)
{
lean_object* x_13; 
lean_dec(x_1);
x_13 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at_____private_Lean_Elab_Tactic_Basic_0__Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__3___redArg(x_10);
return x_13;
}
else
{
lean_object* x_14; uint8_t x_15; 
x_14 = l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; uint64_t x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_16 = lean_ctor_get(x_14, 1);
x_17 = lean_ctor_get(x_6, 2);
x_18 = l_makeRunner___closed__0;
x_19 = lean_alloc_closure((void*)(l_makeRunner___lam__0___boxed), 6, 1);
lean_closure_set(x_19, 0, x_18);
x_20 = lean_box(0);
lean_ctor_set(x_14, 1, x_20);
lean_inc_ref(x_17);
x_21 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_21, 0, x_14);
lean_ctor_set(x_21, 1, x_17);
lean_ctor_set(x_21, 2, x_19);
x_22 = l_Lean_Server_WithRpcRef_mk___redArg(x_21, x_16);
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 1);
lean_inc(x_24);
lean_dec_ref(x_22);
x_25 = l_runnerWidget;
x_26 = lean_ctor_get(x_25, 0);
lean_inc_ref(x_26);
x_27 = lean_ctor_get_uint64(x_26, sizeof(void*)*1);
lean_dec_ref(x_26);
x_28 = lean_unsigned_to_nat(0u);
x_29 = l_Lean_Syntax_getArg(x_1, x_28);
lean_dec(x_1);
x_30 = lean_alloc_closure((void*)(l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1____boxed), 2, 1);
lean_closure_set(x_30, 0, x_23);
x_31 = l_Lean_Widget_savePanelWidgetInfo(x_27, x_30, x_29, x_8, x_9, x_24);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; uint64_t x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_32 = lean_ctor_get(x_14, 0);
x_33 = lean_ctor_get(x_14, 1);
lean_inc(x_33);
lean_inc(x_32);
lean_dec(x_14);
x_34 = lean_ctor_get(x_6, 2);
x_35 = l_makeRunner___closed__0;
x_36 = lean_alloc_closure((void*)(l_makeRunner___lam__0___boxed), 6, 1);
lean_closure_set(x_36, 0, x_35);
x_37 = lean_box(0);
x_38 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_38, 0, x_32);
lean_ctor_set(x_38, 1, x_37);
lean_inc_ref(x_34);
x_39 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_34);
lean_ctor_set(x_39, 2, x_36);
x_40 = l_Lean_Server_WithRpcRef_mk___redArg(x_39, x_33);
x_41 = lean_ctor_get(x_40, 0);
lean_inc(x_41);
x_42 = lean_ctor_get(x_40, 1);
lean_inc(x_42);
lean_dec_ref(x_40);
x_43 = l_runnerWidget;
x_44 = lean_ctor_get(x_43, 0);
lean_inc_ref(x_44);
x_45 = lean_ctor_get_uint64(x_44, sizeof(void*)*1);
lean_dec_ref(x_44);
x_46 = lean_unsigned_to_nat(0u);
x_47 = l_Lean_Syntax_getArg(x_1, x_46);
lean_dec(x_1);
x_48 = lean_alloc_closure((void*)(l_instRpcEncodableRunnerWidgetProps_enc____x40_ProofWidgets_Demos_LazyComputation_3149295279____hygCtx___hyg_1____boxed), 2, 1);
lean_closure_set(x_48, 0, x_41);
x_49 = l_Lean_Widget_savePanelWidgetInfo(x_45, x_48, x_47, x_8, x_9, x_42);
return x_49;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Elab_CommandContextInfo_save___at___makeRunner_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_makeRunner___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_makeRunner___lam__0(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_makeRunner___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_makeRunner(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec_ref(x_8);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_11;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_LazyComputation(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_ = _init_l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_();
lean_mark_persistent(l_instImpl___closed__0____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_);
l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_ = _init_l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_();
lean_mark_persistent(l_instImpl___closed__1____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_);
l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_ = _init_l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_();
lean_mark_persistent(l_instImpl____x40_ProofWidgets_Demos_LazyComputation_1602292608____hygCtx___hyg_32_);
l_instTypeNameMetaMStringCont = _init_l_instTypeNameMetaMStringCont();
lean_mark_persistent(l_instTypeNameMetaMStringCont);
l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_17_);
l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_LazyComputation_12377519____hygCtx___hyg_35_);
l_instRpcEncodableRunnerWidgetProps___closed__0 = _init_l_instRpcEncodableRunnerWidgetProps___closed__0();
lean_mark_persistent(l_instRpcEncodableRunnerWidgetProps___closed__0);
l_instRpcEncodableRunnerWidgetProps___closed__1 = _init_l_instRpcEncodableRunnerWidgetProps___closed__1();
lean_mark_persistent(l_instRpcEncodableRunnerWidgetProps___closed__1);
l_instRpcEncodableRunnerWidgetProps___closed__2 = _init_l_instRpcEncodableRunnerWidgetProps___closed__2();
lean_mark_persistent(l_instRpcEncodableRunnerWidgetProps___closed__2);
l_instRpcEncodableRunnerWidgetProps = _init_l_instRpcEncodableRunnerWidgetProps();
lean_mark_persistent(l_instRpcEncodableRunnerWidgetProps);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__2);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__3);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___runMetaMStringCont___rpc__wrapped_spec__0___lam__3___closed__4);
l_runMetaMStringCont___rpc__wrapped___closed__0 = _init_l_runMetaMStringCont___rpc__wrapped___closed__0();
lean_mark_persistent(l_runMetaMStringCont___rpc__wrapped___closed__0);
l_runMetaMStringCont___rpc__wrapped___closed__1 = _init_l_runMetaMStringCont___rpc__wrapped___closed__1();
lean_mark_persistent(l_runMetaMStringCont___rpc__wrapped___closed__1);
l_runMetaMStringCont___rpc__wrapped___closed__2 = _init_l_runMetaMStringCont___rpc__wrapped___closed__2();
lean_mark_persistent(l_runMetaMStringCont___rpc__wrapped___closed__2);
l_runMetaMStringCont___rpc__wrapped = _init_l_runMetaMStringCont___rpc__wrapped();
lean_mark_persistent(l_runMetaMStringCont___rpc__wrapped);
l_runnerWidget___closed__0 = _init_l_runnerWidget___closed__0();
lean_mark_persistent(l_runnerWidget___closed__0);
l_runnerWidget___closed__1 = _init_l_runnerWidget___closed__1();
l_runnerWidget___closed__2 = _init_l_runnerWidget___closed__2();
lean_mark_persistent(l_runnerWidget___closed__2);
l_runnerWidget___closed__3 = _init_l_runnerWidget___closed__3();
lean_mark_persistent(l_runnerWidget___closed__3);
l_runnerWidget___closed__4 = _init_l_runnerWidget___closed__4();
lean_mark_persistent(l_runnerWidget___closed__4);
l_runnerWidget = _init_l_runnerWidget();
lean_mark_persistent(l_runnerWidget);
l_makeRunnerTac___closed__0 = _init_l_makeRunnerTac___closed__0();
lean_mark_persistent(l_makeRunnerTac___closed__0);
l_makeRunnerTac___closed__1 = _init_l_makeRunnerTac___closed__1();
lean_mark_persistent(l_makeRunnerTac___closed__1);
l_makeRunnerTac___closed__2 = _init_l_makeRunnerTac___closed__2();
lean_mark_persistent(l_makeRunnerTac___closed__2);
l_makeRunnerTac___closed__3 = _init_l_makeRunnerTac___closed__3();
lean_mark_persistent(l_makeRunnerTac___closed__3);
l_makeRunnerTac___closed__4 = _init_l_makeRunnerTac___closed__4();
lean_mark_persistent(l_makeRunnerTac___closed__4);
l_makeRunnerTac = _init_l_makeRunnerTac();
lean_mark_persistent(l_makeRunnerTac);
l_makeRunner___closed__0 = _init_l_makeRunner___closed__0();
lean_mark_persistent(l_makeRunner___closed__0);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
