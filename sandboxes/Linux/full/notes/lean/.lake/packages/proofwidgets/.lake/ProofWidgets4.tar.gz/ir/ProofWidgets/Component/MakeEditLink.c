// Lean compiler output
// Module: ProofWidgets.Component.MakeEditLink
// Imports: Init Lean.Server.Utils ProofWidgets.Component.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4;
uint32_t lean_string_utf8_get(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0;
lean_object* l_Lean_Lsp_instFromJsonTextDocumentEdit_fromJson(lean_object*);
uint64_t lean_string_hash(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
static lean_object* l_ProofWidgets_MakeEditLink___closed__2;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22;
LEAN_EXPORT lean_object* l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Lsp_Position_advance(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11;
lean_object* lean_string_utf8_next(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13;
lean_object* l_Lean_Json_getObjValD(lean_object*, lean_object*);
static lean_object* l_Lean_Lsp_Position_advance___closed__0;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19;
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0;
static lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0;
lean_object* l_Lean_Json_opt___at___Lean_Lsp_instToJsonClientInfo_toJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0;
static uint64_t l_ProofWidgets_MakeEditLink___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps;
uint32_t l_Char_utf16Size(uint32_t);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8;
static lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0;
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Lsp_instFromJsonClientInfo_fromJson_spec__1(lean_object*, lean_object*);
lean_object* l_Lean_Json_opt___at___Lean_Lsp_instToJsonLeanLocationLink_toJson_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10;
lean_object* l_Lean_Lsp_instToJsonTextDocumentEdit_toJson(lean_object*);
static lean_object* l_ProofWidgets_MakeEditLink___closed__0;
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16;
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3;
uint8_t lean_uint32_dec_eq(uint32_t, uint32_t);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1;
LEAN_EXPORT lean_object* l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21;
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLink;
LEAN_EXPORT lean_object* l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0___boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20;
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps_toJson(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12;
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0;
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Lsp_instFromJsonLeanLocationLink_fromJson_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_MakeEditLink___closed__3;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15;
static lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9;
static lean_object* l_ProofWidgets_MakeEditLink___closed__4;
LEAN_EXPORT lean_object* l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_nat_dec_lt(x_3, x_2);
if (x_5 == 0)
{
lean_dec(x_3);
return x_4;
}
else
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_4);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; uint32_t x_10; uint32_t x_11; uint8_t x_12; 
x_7 = lean_ctor_get(x_4, 0);
x_8 = lean_ctor_get(x_4, 1);
x_9 = lean_string_utf8_next(x_1, x_3);
x_10 = lean_string_utf8_get(x_1, x_3);
lean_dec(x_3);
x_11 = 10;
x_12 = lean_uint32_dec_eq(x_10, x_11);
if (x_12 == 0)
{
uint32_t x_13; lean_object* x_14; lean_object* x_15; 
x_13 = l_Char_utf16Size(x_10);
x_14 = lean_uint32_to_nat(x_13);
x_15 = lean_nat_add(x_8, x_14);
lean_dec(x_14);
lean_dec(x_8);
lean_ctor_set(x_4, 1, x_15);
x_3 = x_9;
goto _start;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; 
lean_dec(x_8);
x_17 = lean_unsigned_to_nat(1u);
x_18 = lean_nat_add(x_7, x_17);
lean_dec(x_7);
x_19 = lean_unsigned_to_nat(0u);
lean_ctor_set(x_4, 1, x_19);
lean_ctor_set(x_4, 0, x_18);
x_3 = x_9;
goto _start;
}
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; uint32_t x_24; uint32_t x_25; uint8_t x_26; 
x_21 = lean_ctor_get(x_4, 0);
x_22 = lean_ctor_get(x_4, 1);
lean_inc(x_22);
lean_inc(x_21);
lean_dec(x_4);
x_23 = lean_string_utf8_next(x_1, x_3);
x_24 = lean_string_utf8_get(x_1, x_3);
lean_dec(x_3);
x_25 = 10;
x_26 = lean_uint32_dec_eq(x_24, x_25);
if (x_26 == 0)
{
uint32_t x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_27 = l_Char_utf16Size(x_24);
x_28 = lean_uint32_to_nat(x_27);
x_29 = lean_nat_add(x_22, x_28);
lean_dec(x_28);
lean_dec(x_22);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_21);
lean_ctor_set(x_30, 1, x_29);
x_3 = x_23;
x_4 = x_30;
goto _start;
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
lean_dec(x_22);
x_32 = lean_unsigned_to_nat(1u);
x_33 = lean_nat_add(x_21, x_32);
lean_dec(x_21);
x_34 = lean_unsigned_to_nat(0u);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_33);
lean_ctor_set(x_35, 1, x_34);
x_3 = x_23;
x_4 = x_35;
goto _start;
}
}
}
}
}
static lean_object* _init_l_Lean_Lsp_Position_advance___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Lsp_Position_advance(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_19; 
x_3 = lean_ctor_get(x_2, 0);
lean_inc_ref(x_3);
x_4 = lean_ctor_get(x_2, 1);
lean_inc(x_4);
x_5 = lean_ctor_get(x_2, 2);
lean_inc(x_5);
lean_dec_ref(x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = l_Lean_Lsp_Position_advance___closed__0;
x_8 = l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0(x_3, x_5, x_4, x_7);
lean_dec(x_5);
lean_dec_ref(x_3);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec_ref(x_8);
x_11 = lean_ctor_get(x_1, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_1, 1);
lean_inc(x_12);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_13 = x_1;
} else {
 lean_dec_ref(x_1);
 x_13 = lean_box(0);
}
x_14 = lean_nat_add(x_11, x_9);
lean_dec(x_11);
x_19 = lean_nat_dec_eq(x_9, x_6);
lean_dec(x_9);
if (x_19 == 0)
{
lean_dec(x_12);
x_15 = x_6;
goto block_18;
}
else
{
x_15 = x_12;
goto block_18;
}
block_18:
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_nat_add(x_15, x_10);
lean_dec(x_10);
lean_dec(x_15);
if (lean_is_scalar(x_13)) {
 x_17 = lean_alloc_ctor(0, 2, 0);
} else {
 x_17 = x_13;
}
lean_ctor_set(x_17, 0, x_14);
lean_ctor_set(x_17, 1, x_16);
return x_17;
}
}
}
LEAN_EXPORT lean_object* l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_String_foldlAux___at___Lean_Lsp_Position_advance_spec__0(x_1, x_2, x_3, x_4);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_MakeEditLinkProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_Lean_Json_getObjValD(x_1, x_2);
x_4 = l_Lean_Lsp_instFromJsonTextDocumentEdit_fromJson(x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("edit", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("MakeEditLinkProps", 17, 17);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(".", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(": ", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("newSelection", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("newSelection\?", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("title", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("title\?", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 1;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20;
x_3 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10;
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; 
x_2 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0(x_1, x_2);
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
lean_dec(x_1);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11;
x_7 = lean_string_append(x_6, x_5);
lean_dec(x_5);
lean_ctor_set(x_3, 0, x_7);
return x_3;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11;
x_10 = lean_string_append(x_9, x_8);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_12; 
lean_dec(x_1);
x_12 = !lean_is_exclusive(x_3);
if (x_12 == 0)
{
lean_ctor_set_tag(x_3, 0);
return x_3;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_3, 0);
lean_inc(x_13);
lean_dec(x_3);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_3, 0);
lean_inc(x_15);
lean_dec_ref(x_3);
x_16 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12;
lean_inc(x_1);
x_17 = l_Lean_Json_getObjValAs_x3f___at___Lean_Lsp_instFromJsonLeanLocationLink_fromJson_spec__0(x_1, x_16);
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_18; 
lean_dec(x_15);
lean_dec(x_1);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17;
x_21 = lean_string_append(x_20, x_19);
lean_dec(x_19);
lean_ctor_set(x_17, 0, x_21);
return x_17;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_22 = lean_ctor_get(x_17, 0);
lean_inc(x_22);
lean_dec(x_17);
x_23 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17;
x_24 = lean_string_append(x_23, x_22);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_26; 
lean_dec(x_15);
lean_dec(x_1);
x_26 = !lean_is_exclusive(x_17);
if (x_26 == 0)
{
lean_ctor_set_tag(x_17, 0);
return x_17;
}
else
{
lean_object* x_27; lean_object* x_28; 
x_27 = lean_ctor_get(x_17, 0);
lean_inc(x_27);
lean_dec(x_17);
x_28 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_28, 0, x_27);
return x_28;
}
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_29 = lean_ctor_get(x_17, 0);
lean_inc(x_29);
lean_dec_ref(x_17);
x_30 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18;
x_31 = l_Lean_Json_getObjValAs_x3f___at___Lean_Lsp_instFromJsonClientInfo_fromJson_spec__1(x_1, x_30);
if (lean_obj_tag(x_31) == 0)
{
uint8_t x_32; 
lean_dec(x_29);
lean_dec(x_15);
x_32 = !lean_is_exclusive(x_31);
if (x_32 == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_31, 0);
x_34 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23;
x_35 = lean_string_append(x_34, x_33);
lean_dec(x_33);
lean_ctor_set(x_31, 0, x_35);
return x_31;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_31, 0);
lean_inc(x_36);
lean_dec(x_31);
x_37 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23;
x_38 = lean_string_append(x_37, x_36);
lean_dec(x_36);
x_39 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_39, 0, x_38);
return x_39;
}
}
else
{
if (lean_obj_tag(x_31) == 0)
{
uint8_t x_40; 
lean_dec(x_29);
lean_dec(x_15);
x_40 = !lean_is_exclusive(x_31);
if (x_40 == 0)
{
lean_ctor_set_tag(x_31, 0);
return x_31;
}
else
{
lean_object* x_41; lean_object* x_42; 
x_41 = lean_ctor_get(x_31, 0);
lean_inc(x_41);
lean_dec(x_31);
x_42 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_42, 0, x_41);
return x_42;
}
}
else
{
uint8_t x_43; 
x_43 = !lean_is_exclusive(x_31);
if (x_43 == 0)
{
lean_object* x_44; lean_object* x_45; 
x_44 = lean_ctor_get(x_31, 0);
x_45 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_45, 0, x_15);
lean_ctor_set(x_45, 1, x_29);
lean_ctor_set(x_45, 2, x_44);
lean_ctor_set(x_31, 0, x_45);
return x_31;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_46 = lean_ctor_get(x_31, 0);
lean_inc(x_46);
lean_dec(x_31);
x_47 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_47, 0, x_15);
lean_ctor_set(x_47, 1, x_29);
lean_ctor_set(x_47, 2, x_46);
x_48 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_48, 0, x_47);
return x_48;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Lean_Json_getObjValAs_x3f___at___ProofWidgets_instFromJsonMakeEditLinkProps_fromJson_spec__0(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonMakeEditLinkProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps_toJson(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_2 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_2);
x_3 = lean_ctor_get(x_1, 1);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 2);
lean_inc(x_4);
lean_dec_ref(x_1);
x_5 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0;
x_6 = l_Lean_Lsp_instToJsonTextDocumentEdit_toJson(x_2);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = lean_box(0);
x_9 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12;
x_11 = l_Lean_Json_opt___at___Lean_Lsp_instToJsonLeanLocationLink_toJson_spec__0(x_10, x_3);
x_12 = l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18;
x_13 = l_Lean_Json_opt___at___Lean_Lsp_instToJsonClientInfo_toJson_spec__0(x_12, x_4);
x_14 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_8);
x_15 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_15, 0, x_11);
lean_ctor_set(x_15, 1, x_14);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_9);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0;
x_18 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Widget_instToJsonGetWidgetSourceParams_toJson_spec__0(x_16, x_17);
x_19 = l_Lean_Json_mkObj(x_18);
return x_19;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instToJsonMakeEditLinkProps_toJson), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonMakeEditLinkProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 2);
lean_inc(x_6);
x_7 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_7, 0, x_6);
lean_inc_ref(x_5);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_7);
x_9 = lean_box(0);
lean_inc_ref(x_3);
lean_inc_ref(x_2);
x_10 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_10, 0, x_2);
lean_ctor_set(x_10, 1, x_3);
lean_ctor_set(x_10, 2, x_9);
lean_ctor_set(x_10, 3, x_9);
x_11 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0;
x_12 = lean_array_push(x_11, x_10);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_8);
lean_ctor_set(x_13, 1, x_12);
if (lean_obj_tag(x_4) == 0)
{
uint8_t x_14; 
x_14 = !lean_is_exclusive(x_2);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_15 = lean_ctor_get(x_2, 0);
x_16 = lean_ctor_get(x_2, 1);
lean_dec(x_16);
x_17 = lean_unsigned_to_nat(0u);
x_18 = lean_string_utf8_byte_size(x_3);
x_19 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_19, 0, x_3);
lean_ctor_set(x_19, 1, x_17);
lean_ctor_set(x_19, 2, x_18);
x_20 = l_Lean_Lsp_Position_advance(x_15, x_19);
lean_inc_ref(x_20);
lean_ctor_set(x_2, 1, x_20);
lean_ctor_set(x_2, 0, x_20);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_2);
x_22 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_22, 0, x_13);
lean_ctor_set(x_22, 1, x_21);
lean_ctor_set(x_22, 2, x_9);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_23 = lean_ctor_get(x_2, 0);
lean_inc(x_23);
lean_dec(x_2);
x_24 = lean_unsigned_to_nat(0u);
x_25 = lean_string_utf8_byte_size(x_3);
x_26 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_26, 0, x_3);
lean_ctor_set(x_26, 1, x_24);
lean_ctor_set(x_26, 2, x_25);
x_27 = l_Lean_Lsp_Position_advance(x_23, x_26);
lean_inc_ref(x_27);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_27);
x_29 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_29, 0, x_28);
x_30 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_30, 0, x_13);
lean_ctor_set(x_30, 1, x_29);
lean_ctor_set(x_30, 2, x_9);
return x_30;
}
}
else
{
lean_object* x_31; 
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_31 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_31, 0, x_13);
lean_ctor_set(x_31, 1, x_4);
lean_ctor_set(x_31, 2, x_9);
return x_31;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27(x_1, x_2, x_3, x_4);
lean_dec_ref(x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0;
x_3 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
lean_ctor_set(x_3, 2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; 
if (lean_obj_tag(x_4) == 0)
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_box(0);
x_13 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27(x_1, x_2, x_3, x_12);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_25; lean_object* x_31; lean_object* x_36; uint8_t x_37; 
x_14 = lean_ctor_get(x_4, 0);
lean_inc(x_14);
lean_dec_ref(x_4);
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_14, 1);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_ctor_get(x_2, 0);
x_18 = lean_string_utf8_byte_size(x_3);
x_36 = lean_unsigned_to_nat(0u);
x_37 = lean_nat_dec_le(x_15, x_36);
if (x_37 == 0)
{
uint8_t x_38; 
x_38 = lean_nat_dec_le(x_18, x_36);
if (x_38 == 0)
{
x_31 = x_36;
goto block_35;
}
else
{
lean_inc(x_18);
x_31 = x_18;
goto block_35;
}
}
else
{
lean_object* x_39; 
x_39 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1;
x_25 = x_39;
goto block_30;
}
block_24:
{
uint8_t x_21; 
x_21 = lean_nat_dec_le(x_18, x_16);
if (x_21 == 0)
{
lean_object* x_22; 
lean_dec(x_18);
lean_inc_ref(x_3);
x_22 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_22, 0, x_3);
lean_ctor_set(x_22, 1, x_20);
lean_ctor_set(x_22, 2, x_16);
x_5 = x_19;
x_6 = x_22;
goto block_11;
}
else
{
lean_object* x_23; 
lean_dec(x_16);
lean_inc_ref(x_3);
x_23 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_23, 0, x_3);
lean_ctor_set(x_23, 1, x_20);
lean_ctor_set(x_23, 2, x_18);
x_5 = x_19;
x_6 = x_23;
goto block_11;
}
}
block_30:
{
lean_object* x_26; uint8_t x_27; 
lean_inc_ref(x_17);
x_26 = l_Lean_Lsp_Position_advance(x_17, x_25);
x_27 = lean_nat_dec_le(x_16, x_15);
if (x_27 == 0)
{
uint8_t x_28; 
x_28 = lean_nat_dec_le(x_18, x_15);
if (x_28 == 0)
{
x_19 = x_26;
x_20 = x_15;
goto block_24;
}
else
{
lean_dec(x_15);
lean_inc(x_18);
x_19 = x_26;
x_20 = x_18;
goto block_24;
}
}
else
{
lean_object* x_29; 
lean_dec(x_18);
lean_dec(x_16);
lean_dec(x_15);
x_29 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1;
x_5 = x_26;
x_6 = x_29;
goto block_11;
}
}
block_35:
{
uint8_t x_32; 
x_32 = lean_nat_dec_le(x_18, x_15);
if (x_32 == 0)
{
lean_object* x_33; 
lean_inc(x_15);
lean_inc_ref(x_3);
x_33 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_33, 0, x_3);
lean_ctor_set(x_33, 1, x_31);
lean_ctor_set(x_33, 2, x_15);
x_25 = x_33;
goto block_30;
}
else
{
lean_object* x_34; 
lean_inc(x_18);
lean_inc_ref(x_3);
x_34 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_34, 0, x_3);
lean_ctor_set(x_34, 1, x_31);
lean_ctor_set(x_34, 2, x_18);
x_25 = x_34;
goto block_30;
}
}
}
block_11:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
lean_inc_ref(x_5);
x_7 = l_Lean_Lsp_Position_advance(x_5, x_6);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_7);
x_9 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_9, 0, x_8);
x_10 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27(x_1, x_2, x_3, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_1, x_2, x_3, x_4);
lean_dec_ref(x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLink___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsx as e}from\"react/jsx-runtime\";import*as t from\"react\";import{EditorContext as i}from\"@leanprover/infoview\";function n(n){const o=t.useContext(i);return e(\"a\",{className:\"link pointer dim \",title:n.title\?\?\"\",onClick:async()=>{await o.api.applyEdit({documentChanges:[n.edit]}),n.newSelection&&await o.revealLocation({uri:n.edit.textDocument.uri,range:n.newSelection})},children:n.children})}export{n as default};", 427, 427);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_MakeEditLink___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_MakeEditLink___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLink___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MakeEditLink___closed__1;
x_2 = l_ProofWidgets_MakeEditLink___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLink___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLink___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MakeEditLink___closed__3;
x_2 = l_ProofWidgets_MakeEditLink___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MakeEditLink() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MakeEditLink___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Server_Utils(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_MakeEditLink(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Server_Utils(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Lean_Lsp_Position_advance___closed__0 = _init_l_Lean_Lsp_Position_advance___closed__0();
lean_mark_persistent(l_Lean_Lsp_Position_advance___closed__0);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__0);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__1);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__2);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__3);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__4);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__5);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__6);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__7);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__8);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__9);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__10);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__11);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__12);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__13);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__14);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__15);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__16);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__17);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__18);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__19);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__20);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__21);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__22);
l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps_fromJson___closed__23);
l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0 = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps___closed__0);
l_ProofWidgets_instFromJsonMakeEditLinkProps = _init_l_ProofWidgets_instFromJsonMakeEditLinkProps();
lean_mark_persistent(l_ProofWidgets_instFromJsonMakeEditLinkProps);
l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0 = _init_l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0();
lean_mark_persistent(l_ProofWidgets_instToJsonMakeEditLinkProps_toJson___closed__0);
l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0 = _init_l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instToJsonMakeEditLinkProps___closed__0);
l_ProofWidgets_instToJsonMakeEditLinkProps = _init_l_ProofWidgets_instToJsonMakeEditLinkProps();
lean_mark_persistent(l_ProofWidgets_instToJsonMakeEditLinkProps);
l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0 = _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0();
lean_mark_persistent(l_ProofWidgets_MakeEditLinkProps_ofReplaceRange_x27___closed__0);
l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0 = _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0();
lean_mark_persistent(l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__0);
l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1 = _init_l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1();
lean_mark_persistent(l_ProofWidgets_MakeEditLinkProps_ofReplaceRange___closed__1);
l_ProofWidgets_MakeEditLink___closed__0 = _init_l_ProofWidgets_MakeEditLink___closed__0();
lean_mark_persistent(l_ProofWidgets_MakeEditLink___closed__0);
l_ProofWidgets_MakeEditLink___closed__1 = _init_l_ProofWidgets_MakeEditLink___closed__1();
l_ProofWidgets_MakeEditLink___closed__2 = _init_l_ProofWidgets_MakeEditLink___closed__2();
lean_mark_persistent(l_ProofWidgets_MakeEditLink___closed__2);
l_ProofWidgets_MakeEditLink___closed__3 = _init_l_ProofWidgets_MakeEditLink___closed__3();
lean_mark_persistent(l_ProofWidgets_MakeEditLink___closed__3);
l_ProofWidgets_MakeEditLink___closed__4 = _init_l_ProofWidgets_MakeEditLink___closed__4();
lean_mark_persistent(l_ProofWidgets_MakeEditLink___closed__4);
l_ProofWidgets_MakeEditLink = _init_l_ProofWidgets_MakeEditLink();
lean_mark_persistent(l_ProofWidgets_MakeEditLink);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
