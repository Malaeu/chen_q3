// Lean compiler output
// Module: ProofWidgets.Component.OfRpcMethod
// Imports: Init Lean.Elab.ElabRules ProofWidgets.Component.Basic ProofWidgets.Data.Html ProofWidgets.Cancellable Batteries.Tactic.OpenPrivate
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__3;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13;
lean_object* l_Lean_indentD(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17;
lean_object* l_Lean_Elab_Term_elabTerm(lean_object*, lean_object*, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_builtinRpcProcedures;
lean_object* l_Lean_Meta_isExprDefEq(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__10;
lean_object* l_Lean_Elab_Term_elabTermEnsuringType(lean_object*, lean_object*, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__9;
lean_object* l_Lean_Expr_sort___override(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__7;
lean_object* l_Array_mkArray0(lean_object*);
uint8_t l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15;
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__5;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31;
lean_object* l_Lean_Elab_Term_withExpectedType(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44;
lean_object* l_Lean_SourceInfo_fromRef(lean_object*, uint8_t);
lean_object* l_Lean_Syntax_node6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_mkStrLit(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__1;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25;
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16;
lean_object* l_Lean_Meta_mkAppM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
extern lean_object* l_ProofWidgets_cancellableSuffix;
lean_object* l_Lean_Syntax_node3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_append(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27;
lean_object* l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18;
lean_object* l_Lean_addMacroScope(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37;
lean_object* l_Lean_Syntax_node2(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14;
lean_object* l___private_Lean_Meta_Basic_0__Lean_Meta_mkFreshExprMVarImpl(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33;
extern lean_object* l_Lean_Server_userRpcProcedures;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34;
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4;
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__6;
lean_object* l_String_replace(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__8;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20;
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_node1(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23;
extern lean_object* l_Lean_levelOne;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6;
lean_object* l_Lean_mkArrow(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__4;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_termMk__rpc__widget_x25__;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43;
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24;
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ofRpcMethodTemplate;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40;
uint8_t l_Lean_MapDeclarationExtension_contains___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__11;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Widget_elabWidgetInstanceSpec_spec__0___redArg(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26;
lean_object* l_String_toSubstring_x27(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47;
static lean_object* l_ProofWidgets_ofRpcMethodTemplate___closed__0;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39;
lean_object* l_Lean_instantiateMVars___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__12___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3;
static lean_object* _init_l_ProofWidgets_ofRpcMethodTemplate___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"$RPC_METHOD\",f=window.toString();var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1881, 1881);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ofRpcMethodTemplate() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("termMk_rpc_widget%_", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__1;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__3;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mk_rpc_widget%", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__5;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__7;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__8;
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__9;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__6;
x_3 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__10;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__11;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("$RPC_METHOD", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window.toString()", 17, 17);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'true'", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Parser", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInst", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("{", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("null", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = l_Array_mkArray0(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstFields", 16, 16);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstField", 15, 15);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstLVal", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("javascript", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13;
x_2 = l_String_toSubstring_x27(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstFieldDef", 18, 18);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(":=", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("optEllipsis", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("}", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'false'", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("' is not a known RPC method. Use `@[server_rpc_method]` to register it.", 71, 71);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_levelOne;
x_2 = l_Lean_Expr_sort___override(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("α", 2, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Component", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Lean", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Server", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RequestTask", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31;
x_3 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35;
x_3 = l_Lean_Expr_const___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RequestM", 8, 8);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31;
x_3 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40() {
_start:
{
lean_object* x_1; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_builtinRpcProcedures;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_Server_userRpcProcedures;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Expected the name of a constant, got a complex term", 51, 51);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected type", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\nis not of the form", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; uint8_t x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; lean_object* x_75; lean_object* x_76; uint8_t x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; uint8_t x_149; uint8_t x_150; 
x_10 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
lean_inc(x_1);
x_11 = l_Lean_Syntax_isOfKind(x_1, x_10);
if (x_11 == 0)
{
lean_object* x_165; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_165 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Widget_elabWidgetInstanceSpec_spec__0___redArg(x_9);
return x_165;
}
else
{
lean_object* x_166; uint8_t x_167; lean_object* x_168; lean_object* x_169; uint8_t x_170; 
x_166 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24;
x_167 = 0;
x_168 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26;
lean_inc_ref(x_5);
x_169 = l___private_Lean_Meta_Basic_0__Lean_Meta_mkFreshExprMVarImpl(x_166, x_167, x_168, x_5, x_6, x_7, x_8, x_9);
x_170 = !lean_is_exclusive(x_169);
if (x_170 == 0)
{
lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; 
x_171 = lean_ctor_get(x_169, 0);
x_172 = lean_ctor_get(x_169, 1);
x_173 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28;
x_174 = lean_unsigned_to_nat(1u);
x_175 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29;
lean_inc(x_171);
x_176 = lean_array_push(x_175, x_171);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
x_177 = l_Lean_Meta_mkAppM(x_173, x_176, x_5, x_6, x_7, x_8, x_172);
if (lean_obj_tag(x_177) == 0)
{
uint8_t x_178; 
x_178 = !lean_is_exclusive(x_177);
if (x_178 == 0)
{
lean_object* x_179; lean_object* x_180; lean_object* x_181; 
x_179 = lean_ctor_get(x_177, 0);
x_180 = lean_ctor_get(x_177, 1);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_179);
lean_inc_ref(x_2);
x_181 = l_Lean_Meta_isExprDefEq(x_2, x_179, x_5, x_6, x_7, x_8, x_180);
if (lean_obj_tag(x_181) == 0)
{
lean_object* x_182; lean_object* x_183; lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; lean_object* x_191; uint8_t x_251; 
x_182 = lean_ctor_get(x_181, 0);
lean_inc(x_182);
x_183 = lean_ctor_get(x_181, 1);
lean_inc(x_183);
lean_dec_ref(x_181);
x_184 = l_Lean_Syntax_getArg(x_1, x_174);
lean_dec(x_1);
x_251 = lean_unbox(x_182);
lean_dec(x_182);
if (x_251 == 0)
{
if (x_11 == 0)
{
lean_free_object(x_177);
lean_dec(x_179);
lean_free_object(x_169);
x_185 = x_3;
x_186 = x_4;
x_187 = x_5;
x_188 = x_6;
x_189 = x_7;
x_190 = x_8;
x_191 = x_183;
goto block_250;
}
else
{
lean_object* x_252; lean_object* x_253; lean_object* x_254; lean_object* x_255; lean_object* x_256; lean_object* x_257; lean_object* x_258; lean_object* x_259; uint8_t x_260; 
lean_dec(x_184);
lean_dec(x_171);
x_252 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45;
x_253 = l_Lean_MessageData_ofExpr(x_2);
x_254 = l_Lean_indentD(x_253);
lean_ctor_set_tag(x_177, 7);
lean_ctor_set(x_177, 1, x_254);
lean_ctor_set(x_177, 0, x_252);
x_255 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47;
lean_ctor_set_tag(x_169, 7);
lean_ctor_set(x_169, 1, x_255);
lean_ctor_set(x_169, 0, x_177);
x_256 = l_Lean_MessageData_ofExpr(x_179);
x_257 = l_Lean_indentD(x_256);
x_258 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_258, 0, x_169);
lean_ctor_set(x_258, 1, x_257);
x_259 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_258, x_3, x_4, x_5, x_6, x_7, x_8, x_183);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
x_260 = !lean_is_exclusive(x_259);
if (x_260 == 0)
{
return x_259;
}
else
{
lean_object* x_261; lean_object* x_262; lean_object* x_263; 
x_261 = lean_ctor_get(x_259, 0);
x_262 = lean_ctor_get(x_259, 1);
lean_inc(x_262);
lean_inc(x_261);
lean_dec(x_259);
x_263 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_263, 0, x_261);
lean_ctor_set(x_263, 1, x_262);
return x_263;
}
}
}
else
{
lean_free_object(x_177);
lean_dec(x_179);
lean_free_object(x_169);
x_185 = x_3;
x_186 = x_4;
x_187 = x_5;
x_188 = x_6;
x_189 = x_7;
x_190 = x_8;
x_191 = x_183;
goto block_250;
}
block_250:
{
lean_object* x_192; lean_object* x_193; lean_object* x_194; lean_object* x_195; 
x_192 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
x_193 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33;
x_194 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37;
lean_inc(x_190);
lean_inc_ref(x_189);
lean_inc(x_188);
lean_inc_ref(x_187);
x_195 = l_Lean_Meta_mkAppM(x_193, x_194, x_187, x_188, x_189, x_190, x_191);
if (lean_obj_tag(x_195) == 0)
{
lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; lean_object* x_200; 
x_196 = lean_ctor_get(x_195, 0);
lean_inc(x_196);
x_197 = lean_ctor_get(x_195, 1);
lean_inc(x_197);
lean_dec_ref(x_195);
x_198 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39;
x_199 = lean_array_push(x_175, x_196);
lean_inc(x_190);
lean_inc_ref(x_189);
lean_inc(x_188);
lean_inc_ref(x_187);
x_200 = l_Lean_Meta_mkAppM(x_198, x_199, x_187, x_188, x_189, x_190, x_197);
if (lean_obj_tag(x_200) == 0)
{
lean_object* x_201; lean_object* x_202; lean_object* x_203; 
x_201 = lean_ctor_get(x_200, 0);
lean_inc(x_201);
x_202 = lean_ctor_get(x_200, 1);
lean_inc(x_202);
lean_dec_ref(x_200);
lean_inc(x_190);
lean_inc_ref(x_189);
x_203 = l_Lean_mkArrow(x_171, x_201, x_189, x_190, x_202);
if (lean_obj_tag(x_203) == 0)
{
lean_object* x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; lean_object* x_208; 
x_204 = lean_ctor_get(x_203, 0);
lean_inc(x_204);
x_205 = lean_ctor_get(x_203, 1);
lean_inc(x_205);
lean_dec_ref(x_203);
x_206 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_206, 0, x_204);
x_207 = lean_box(0);
lean_inc(x_190);
lean_inc_ref(x_189);
lean_inc(x_188);
lean_inc_ref(x_187);
lean_inc(x_186);
lean_inc_ref(x_185);
x_208 = l_Lean_Elab_Term_elabTermEnsuringType(x_184, x_206, x_11, x_11, x_207, x_185, x_186, x_187, x_188, x_189, x_190, x_205);
if (lean_obj_tag(x_208) == 0)
{
lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; 
x_209 = lean_ctor_get(x_208, 0);
lean_inc(x_209);
x_210 = lean_ctor_get(x_208, 1);
lean_inc(x_210);
lean_dec_ref(x_208);
x_211 = l_Lean_instantiateMVars___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__12___redArg(x_209, x_188, x_210);
x_212 = lean_ctor_get(x_211, 0);
lean_inc(x_212);
if (lean_obj_tag(x_212) == 4)
{
lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; uint8_t x_224; 
x_213 = lean_ctor_get(x_211, 1);
lean_inc(x_213);
lean_dec_ref(x_211);
x_214 = lean_ctor_get(x_212, 0);
lean_inc(x_214);
lean_dec_ref(x_212);
x_215 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40;
x_216 = lean_st_ref_get(x_215, x_213);
x_217 = lean_ctor_get(x_216, 0);
lean_inc(x_217);
x_218 = lean_ctor_get(x_216, 1);
lean_inc(x_218);
lean_dec_ref(x_216);
x_219 = lean_st_ref_get(x_190, x_218);
x_220 = lean_ctor_get(x_219, 0);
lean_inc(x_220);
x_221 = lean_ctor_get(x_219, 1);
lean_inc(x_221);
lean_dec_ref(x_219);
x_222 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_214);
x_223 = l_Lean_Name_append(x_214, x_222);
x_224 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_217, x_223);
if (x_224 == 0)
{
lean_object* x_225; lean_object* x_226; lean_object* x_227; uint8_t x_228; 
x_225 = lean_ctor_get(x_220, 0);
lean_inc_ref(x_225);
lean_dec(x_220);
x_226 = lean_box(0);
x_227 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41;
lean_inc(x_223);
x_228 = l_Lean_MapDeclarationExtension_contains___redArg(x_226, x_227, x_225, x_223);
if (x_228 == 0)
{
lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; lean_object* x_234; lean_object* x_235; uint8_t x_236; 
lean_dec(x_223);
x_229 = lean_st_ref_get(x_215, x_221);
x_230 = lean_ctor_get(x_229, 0);
lean_inc(x_230);
x_231 = lean_ctor_get(x_229, 1);
lean_inc(x_231);
lean_dec_ref(x_229);
x_232 = lean_st_ref_get(x_190, x_231);
x_233 = lean_ctor_get(x_232, 0);
lean_inc(x_233);
x_234 = lean_ctor_get(x_232, 1);
lean_inc(x_234);
lean_dec_ref(x_232);
x_235 = lean_ctor_get(x_233, 0);
lean_inc_ref(x_235);
lean_dec(x_233);
x_236 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_230, x_214);
if (x_236 == 0)
{
x_137 = x_185;
x_138 = x_192;
x_139 = x_187;
x_140 = x_189;
x_141 = x_186;
x_142 = x_188;
x_143 = x_234;
x_144 = x_235;
x_145 = x_214;
x_146 = x_227;
x_147 = x_190;
x_148 = x_226;
x_149 = x_228;
x_150 = x_11;
goto block_164;
}
else
{
x_137 = x_185;
x_138 = x_192;
x_139 = x_187;
x_140 = x_189;
x_141 = x_186;
x_142 = x_188;
x_143 = x_234;
x_144 = x_235;
x_145 = x_214;
x_146 = x_227;
x_147 = x_190;
x_148 = x_226;
x_149 = x_228;
x_150 = x_228;
goto block_164;
}
}
else
{
lean_dec(x_214);
x_12 = x_185;
x_13 = x_192;
x_14 = x_187;
x_15 = x_223;
x_16 = x_189;
x_17 = x_186;
x_18 = x_188;
x_19 = x_190;
x_20 = x_221;
x_21 = x_228;
goto block_74;
}
}
else
{
lean_dec(x_220);
lean_dec(x_214);
x_12 = x_185;
x_13 = x_192;
x_14 = x_187;
x_15 = x_223;
x_16 = x_189;
x_17 = x_186;
x_18 = x_188;
x_19 = x_190;
x_20 = x_221;
x_21 = x_11;
goto block_74;
}
}
else
{
uint8_t x_237; 
lean_dec_ref(x_2);
x_237 = !lean_is_exclusive(x_211);
if (x_237 == 0)
{
lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; lean_object* x_242; lean_object* x_243; 
x_238 = lean_ctor_get(x_211, 1);
x_239 = lean_ctor_get(x_211, 0);
lean_dec(x_239);
x_240 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43;
x_241 = l_Lean_MessageData_ofExpr(x_212);
x_242 = l_Lean_indentD(x_241);
lean_ctor_set_tag(x_211, 7);
lean_ctor_set(x_211, 1, x_242);
lean_ctor_set(x_211, 0, x_240);
x_243 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_211, x_185, x_186, x_187, x_188, x_189, x_190, x_238);
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
return x_243;
}
else
{
lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; lean_object* x_248; lean_object* x_249; 
x_244 = lean_ctor_get(x_211, 1);
lean_inc(x_244);
lean_dec(x_211);
x_245 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43;
x_246 = l_Lean_MessageData_ofExpr(x_212);
x_247 = l_Lean_indentD(x_246);
x_248 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_248, 0, x_245);
lean_ctor_set(x_248, 1, x_247);
x_249 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_248, x_185, x_186, x_187, x_188, x_189, x_190, x_244);
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
return x_249;
}
}
}
else
{
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
lean_dec_ref(x_185);
lean_dec_ref(x_2);
return x_208;
}
}
else
{
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
lean_dec_ref(x_185);
lean_dec(x_184);
lean_dec_ref(x_2);
return x_203;
}
}
else
{
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
lean_dec_ref(x_185);
lean_dec(x_184);
lean_dec(x_171);
lean_dec_ref(x_2);
return x_200;
}
}
else
{
lean_dec(x_190);
lean_dec_ref(x_189);
lean_dec(x_188);
lean_dec_ref(x_187);
lean_dec(x_186);
lean_dec_ref(x_185);
lean_dec(x_184);
lean_dec(x_171);
lean_dec_ref(x_2);
return x_195;
}
}
}
else
{
uint8_t x_264; 
lean_free_object(x_177);
lean_dec(x_179);
lean_free_object(x_169);
lean_dec(x_171);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_264 = !lean_is_exclusive(x_181);
if (x_264 == 0)
{
return x_181;
}
else
{
lean_object* x_265; lean_object* x_266; lean_object* x_267; 
x_265 = lean_ctor_get(x_181, 0);
x_266 = lean_ctor_get(x_181, 1);
lean_inc(x_266);
lean_inc(x_265);
lean_dec(x_181);
x_267 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_267, 0, x_265);
lean_ctor_set(x_267, 1, x_266);
return x_267;
}
}
}
else
{
lean_object* x_268; lean_object* x_269; lean_object* x_270; 
x_268 = lean_ctor_get(x_177, 0);
x_269 = lean_ctor_get(x_177, 1);
lean_inc(x_269);
lean_inc(x_268);
lean_dec(x_177);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_268);
lean_inc_ref(x_2);
x_270 = l_Lean_Meta_isExprDefEq(x_2, x_268, x_5, x_6, x_7, x_8, x_269);
if (lean_obj_tag(x_270) == 0)
{
lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; lean_object* x_275; lean_object* x_276; lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; uint8_t x_334; 
x_271 = lean_ctor_get(x_270, 0);
lean_inc(x_271);
x_272 = lean_ctor_get(x_270, 1);
lean_inc(x_272);
lean_dec_ref(x_270);
x_273 = l_Lean_Syntax_getArg(x_1, x_174);
lean_dec(x_1);
x_334 = lean_unbox(x_271);
lean_dec(x_271);
if (x_334 == 0)
{
if (x_11 == 0)
{
lean_dec(x_268);
lean_free_object(x_169);
x_274 = x_3;
x_275 = x_4;
x_276 = x_5;
x_277 = x_6;
x_278 = x_7;
x_279 = x_8;
x_280 = x_272;
goto block_333;
}
else
{
lean_object* x_335; lean_object* x_336; lean_object* x_337; lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; 
lean_dec(x_273);
lean_dec(x_171);
x_335 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45;
x_336 = l_Lean_MessageData_ofExpr(x_2);
x_337 = l_Lean_indentD(x_336);
x_338 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_338, 0, x_335);
lean_ctor_set(x_338, 1, x_337);
x_339 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47;
lean_ctor_set_tag(x_169, 7);
lean_ctor_set(x_169, 1, x_339);
lean_ctor_set(x_169, 0, x_338);
x_340 = l_Lean_MessageData_ofExpr(x_268);
x_341 = l_Lean_indentD(x_340);
x_342 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_342, 0, x_169);
lean_ctor_set(x_342, 1, x_341);
x_343 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_342, x_3, x_4, x_5, x_6, x_7, x_8, x_272);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
x_344 = lean_ctor_get(x_343, 0);
lean_inc(x_344);
x_345 = lean_ctor_get(x_343, 1);
lean_inc(x_345);
if (lean_is_exclusive(x_343)) {
 lean_ctor_release(x_343, 0);
 lean_ctor_release(x_343, 1);
 x_346 = x_343;
} else {
 lean_dec_ref(x_343);
 x_346 = lean_box(0);
}
if (lean_is_scalar(x_346)) {
 x_347 = lean_alloc_ctor(1, 2, 0);
} else {
 x_347 = x_346;
}
lean_ctor_set(x_347, 0, x_344);
lean_ctor_set(x_347, 1, x_345);
return x_347;
}
}
else
{
lean_dec(x_268);
lean_free_object(x_169);
x_274 = x_3;
x_275 = x_4;
x_276 = x_5;
x_277 = x_6;
x_278 = x_7;
x_279 = x_8;
x_280 = x_272;
goto block_333;
}
block_333:
{
lean_object* x_281; lean_object* x_282; lean_object* x_283; lean_object* x_284; 
x_281 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
x_282 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33;
x_283 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37;
lean_inc(x_279);
lean_inc_ref(x_278);
lean_inc(x_277);
lean_inc_ref(x_276);
x_284 = l_Lean_Meta_mkAppM(x_282, x_283, x_276, x_277, x_278, x_279, x_280);
if (lean_obj_tag(x_284) == 0)
{
lean_object* x_285; lean_object* x_286; lean_object* x_287; lean_object* x_288; lean_object* x_289; 
x_285 = lean_ctor_get(x_284, 0);
lean_inc(x_285);
x_286 = lean_ctor_get(x_284, 1);
lean_inc(x_286);
lean_dec_ref(x_284);
x_287 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39;
x_288 = lean_array_push(x_175, x_285);
lean_inc(x_279);
lean_inc_ref(x_278);
lean_inc(x_277);
lean_inc_ref(x_276);
x_289 = l_Lean_Meta_mkAppM(x_287, x_288, x_276, x_277, x_278, x_279, x_286);
if (lean_obj_tag(x_289) == 0)
{
lean_object* x_290; lean_object* x_291; lean_object* x_292; 
x_290 = lean_ctor_get(x_289, 0);
lean_inc(x_290);
x_291 = lean_ctor_get(x_289, 1);
lean_inc(x_291);
lean_dec_ref(x_289);
lean_inc(x_279);
lean_inc_ref(x_278);
x_292 = l_Lean_mkArrow(x_171, x_290, x_278, x_279, x_291);
if (lean_obj_tag(x_292) == 0)
{
lean_object* x_293; lean_object* x_294; lean_object* x_295; lean_object* x_296; lean_object* x_297; 
x_293 = lean_ctor_get(x_292, 0);
lean_inc(x_293);
x_294 = lean_ctor_get(x_292, 1);
lean_inc(x_294);
lean_dec_ref(x_292);
x_295 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_295, 0, x_293);
x_296 = lean_box(0);
lean_inc(x_279);
lean_inc_ref(x_278);
lean_inc(x_277);
lean_inc_ref(x_276);
lean_inc(x_275);
lean_inc_ref(x_274);
x_297 = l_Lean_Elab_Term_elabTermEnsuringType(x_273, x_295, x_11, x_11, x_296, x_274, x_275, x_276, x_277, x_278, x_279, x_294);
if (lean_obj_tag(x_297) == 0)
{
lean_object* x_298; lean_object* x_299; lean_object* x_300; lean_object* x_301; 
x_298 = lean_ctor_get(x_297, 0);
lean_inc(x_298);
x_299 = lean_ctor_get(x_297, 1);
lean_inc(x_299);
lean_dec_ref(x_297);
x_300 = l_Lean_instantiateMVars___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__12___redArg(x_298, x_277, x_299);
x_301 = lean_ctor_get(x_300, 0);
lean_inc(x_301);
if (lean_obj_tag(x_301) == 4)
{
lean_object* x_302; lean_object* x_303; lean_object* x_304; lean_object* x_305; lean_object* x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; lean_object* x_311; lean_object* x_312; uint8_t x_313; 
x_302 = lean_ctor_get(x_300, 1);
lean_inc(x_302);
lean_dec_ref(x_300);
x_303 = lean_ctor_get(x_301, 0);
lean_inc(x_303);
lean_dec_ref(x_301);
x_304 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40;
x_305 = lean_st_ref_get(x_304, x_302);
x_306 = lean_ctor_get(x_305, 0);
lean_inc(x_306);
x_307 = lean_ctor_get(x_305, 1);
lean_inc(x_307);
lean_dec_ref(x_305);
x_308 = lean_st_ref_get(x_279, x_307);
x_309 = lean_ctor_get(x_308, 0);
lean_inc(x_309);
x_310 = lean_ctor_get(x_308, 1);
lean_inc(x_310);
lean_dec_ref(x_308);
x_311 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_303);
x_312 = l_Lean_Name_append(x_303, x_311);
x_313 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_306, x_312);
if (x_313 == 0)
{
lean_object* x_314; lean_object* x_315; lean_object* x_316; uint8_t x_317; 
x_314 = lean_ctor_get(x_309, 0);
lean_inc_ref(x_314);
lean_dec(x_309);
x_315 = lean_box(0);
x_316 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41;
lean_inc(x_312);
x_317 = l_Lean_MapDeclarationExtension_contains___redArg(x_315, x_316, x_314, x_312);
if (x_317 == 0)
{
lean_object* x_318; lean_object* x_319; lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; uint8_t x_325; 
lean_dec(x_312);
x_318 = lean_st_ref_get(x_304, x_310);
x_319 = lean_ctor_get(x_318, 0);
lean_inc(x_319);
x_320 = lean_ctor_get(x_318, 1);
lean_inc(x_320);
lean_dec_ref(x_318);
x_321 = lean_st_ref_get(x_279, x_320);
x_322 = lean_ctor_get(x_321, 0);
lean_inc(x_322);
x_323 = lean_ctor_get(x_321, 1);
lean_inc(x_323);
lean_dec_ref(x_321);
x_324 = lean_ctor_get(x_322, 0);
lean_inc_ref(x_324);
lean_dec(x_322);
x_325 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_319, x_303);
if (x_325 == 0)
{
x_137 = x_274;
x_138 = x_281;
x_139 = x_276;
x_140 = x_278;
x_141 = x_275;
x_142 = x_277;
x_143 = x_323;
x_144 = x_324;
x_145 = x_303;
x_146 = x_316;
x_147 = x_279;
x_148 = x_315;
x_149 = x_317;
x_150 = x_11;
goto block_164;
}
else
{
x_137 = x_274;
x_138 = x_281;
x_139 = x_276;
x_140 = x_278;
x_141 = x_275;
x_142 = x_277;
x_143 = x_323;
x_144 = x_324;
x_145 = x_303;
x_146 = x_316;
x_147 = x_279;
x_148 = x_315;
x_149 = x_317;
x_150 = x_317;
goto block_164;
}
}
else
{
lean_dec(x_303);
x_12 = x_274;
x_13 = x_281;
x_14 = x_276;
x_15 = x_312;
x_16 = x_278;
x_17 = x_275;
x_18 = x_277;
x_19 = x_279;
x_20 = x_310;
x_21 = x_317;
goto block_74;
}
}
else
{
lean_dec(x_309);
lean_dec(x_303);
x_12 = x_274;
x_13 = x_281;
x_14 = x_276;
x_15 = x_312;
x_16 = x_278;
x_17 = x_275;
x_18 = x_277;
x_19 = x_279;
x_20 = x_310;
x_21 = x_11;
goto block_74;
}
}
else
{
lean_object* x_326; lean_object* x_327; lean_object* x_328; lean_object* x_329; lean_object* x_330; lean_object* x_331; lean_object* x_332; 
lean_dec_ref(x_2);
x_326 = lean_ctor_get(x_300, 1);
lean_inc(x_326);
if (lean_is_exclusive(x_300)) {
 lean_ctor_release(x_300, 0);
 lean_ctor_release(x_300, 1);
 x_327 = x_300;
} else {
 lean_dec_ref(x_300);
 x_327 = lean_box(0);
}
x_328 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43;
x_329 = l_Lean_MessageData_ofExpr(x_301);
x_330 = l_Lean_indentD(x_329);
if (lean_is_scalar(x_327)) {
 x_331 = lean_alloc_ctor(7, 2, 0);
} else {
 x_331 = x_327;
 lean_ctor_set_tag(x_331, 7);
}
lean_ctor_set(x_331, 0, x_328);
lean_ctor_set(x_331, 1, x_330);
x_332 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_331, x_274, x_275, x_276, x_277, x_278, x_279, x_326);
lean_dec(x_279);
lean_dec_ref(x_278);
lean_dec(x_277);
lean_dec_ref(x_276);
lean_dec(x_275);
return x_332;
}
}
else
{
lean_dec(x_279);
lean_dec_ref(x_278);
lean_dec(x_277);
lean_dec_ref(x_276);
lean_dec(x_275);
lean_dec_ref(x_274);
lean_dec_ref(x_2);
return x_297;
}
}
else
{
lean_dec(x_279);
lean_dec_ref(x_278);
lean_dec(x_277);
lean_dec_ref(x_276);
lean_dec(x_275);
lean_dec_ref(x_274);
lean_dec(x_273);
lean_dec_ref(x_2);
return x_292;
}
}
else
{
lean_dec(x_279);
lean_dec_ref(x_278);
lean_dec(x_277);
lean_dec_ref(x_276);
lean_dec(x_275);
lean_dec_ref(x_274);
lean_dec(x_273);
lean_dec(x_171);
lean_dec_ref(x_2);
return x_289;
}
}
else
{
lean_dec(x_279);
lean_dec_ref(x_278);
lean_dec(x_277);
lean_dec_ref(x_276);
lean_dec(x_275);
lean_dec_ref(x_274);
lean_dec(x_273);
lean_dec(x_171);
lean_dec_ref(x_2);
return x_284;
}
}
}
else
{
lean_object* x_348; lean_object* x_349; lean_object* x_350; lean_object* x_351; 
lean_dec(x_268);
lean_free_object(x_169);
lean_dec(x_171);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_348 = lean_ctor_get(x_270, 0);
lean_inc(x_348);
x_349 = lean_ctor_get(x_270, 1);
lean_inc(x_349);
if (lean_is_exclusive(x_270)) {
 lean_ctor_release(x_270, 0);
 lean_ctor_release(x_270, 1);
 x_350 = x_270;
} else {
 lean_dec_ref(x_270);
 x_350 = lean_box(0);
}
if (lean_is_scalar(x_350)) {
 x_351 = lean_alloc_ctor(1, 2, 0);
} else {
 x_351 = x_350;
}
lean_ctor_set(x_351, 0, x_348);
lean_ctor_set(x_351, 1, x_349);
return x_351;
}
}
}
else
{
lean_free_object(x_169);
lean_dec(x_171);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_177;
}
}
else
{
lean_object* x_352; lean_object* x_353; lean_object* x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; 
x_352 = lean_ctor_get(x_169, 0);
x_353 = lean_ctor_get(x_169, 1);
lean_inc(x_353);
lean_inc(x_352);
lean_dec(x_169);
x_354 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28;
x_355 = lean_unsigned_to_nat(1u);
x_356 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29;
lean_inc(x_352);
x_357 = lean_array_push(x_356, x_352);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
x_358 = l_Lean_Meta_mkAppM(x_354, x_357, x_5, x_6, x_7, x_8, x_353);
if (lean_obj_tag(x_358) == 0)
{
lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; 
x_359 = lean_ctor_get(x_358, 0);
lean_inc(x_359);
x_360 = lean_ctor_get(x_358, 1);
lean_inc(x_360);
if (lean_is_exclusive(x_358)) {
 lean_ctor_release(x_358, 0);
 lean_ctor_release(x_358, 1);
 x_361 = x_358;
} else {
 lean_dec_ref(x_358);
 x_361 = lean_box(0);
}
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_359);
lean_inc_ref(x_2);
x_362 = l_Lean_Meta_isExprDefEq(x_2, x_359, x_5, x_6, x_7, x_8, x_360);
if (lean_obj_tag(x_362) == 0)
{
lean_object* x_363; lean_object* x_364; lean_object* x_365; lean_object* x_366; lean_object* x_367; lean_object* x_368; lean_object* x_369; lean_object* x_370; lean_object* x_371; lean_object* x_372; uint8_t x_426; 
x_363 = lean_ctor_get(x_362, 0);
lean_inc(x_363);
x_364 = lean_ctor_get(x_362, 1);
lean_inc(x_364);
lean_dec_ref(x_362);
x_365 = l_Lean_Syntax_getArg(x_1, x_355);
lean_dec(x_1);
x_426 = lean_unbox(x_363);
lean_dec(x_363);
if (x_426 == 0)
{
if (x_11 == 0)
{
lean_dec(x_361);
lean_dec(x_359);
x_366 = x_3;
x_367 = x_4;
x_368 = x_5;
x_369 = x_6;
x_370 = x_7;
x_371 = x_8;
x_372 = x_364;
goto block_425;
}
else
{
lean_object* x_427; lean_object* x_428; lean_object* x_429; lean_object* x_430; lean_object* x_431; lean_object* x_432; lean_object* x_433; lean_object* x_434; lean_object* x_435; lean_object* x_436; lean_object* x_437; lean_object* x_438; lean_object* x_439; lean_object* x_440; 
lean_dec(x_365);
lean_dec(x_352);
x_427 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45;
x_428 = l_Lean_MessageData_ofExpr(x_2);
x_429 = l_Lean_indentD(x_428);
if (lean_is_scalar(x_361)) {
 x_430 = lean_alloc_ctor(7, 2, 0);
} else {
 x_430 = x_361;
 lean_ctor_set_tag(x_430, 7);
}
lean_ctor_set(x_430, 0, x_427);
lean_ctor_set(x_430, 1, x_429);
x_431 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47;
x_432 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_432, 0, x_430);
lean_ctor_set(x_432, 1, x_431);
x_433 = l_Lean_MessageData_ofExpr(x_359);
x_434 = l_Lean_indentD(x_433);
x_435 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_435, 0, x_432);
lean_ctor_set(x_435, 1, x_434);
x_436 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_435, x_3, x_4, x_5, x_6, x_7, x_8, x_364);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
x_437 = lean_ctor_get(x_436, 0);
lean_inc(x_437);
x_438 = lean_ctor_get(x_436, 1);
lean_inc(x_438);
if (lean_is_exclusive(x_436)) {
 lean_ctor_release(x_436, 0);
 lean_ctor_release(x_436, 1);
 x_439 = x_436;
} else {
 lean_dec_ref(x_436);
 x_439 = lean_box(0);
}
if (lean_is_scalar(x_439)) {
 x_440 = lean_alloc_ctor(1, 2, 0);
} else {
 x_440 = x_439;
}
lean_ctor_set(x_440, 0, x_437);
lean_ctor_set(x_440, 1, x_438);
return x_440;
}
}
else
{
lean_dec(x_361);
lean_dec(x_359);
x_366 = x_3;
x_367 = x_4;
x_368 = x_5;
x_369 = x_6;
x_370 = x_7;
x_371 = x_8;
x_372 = x_364;
goto block_425;
}
block_425:
{
lean_object* x_373; lean_object* x_374; lean_object* x_375; lean_object* x_376; 
x_373 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30;
x_374 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33;
x_375 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37;
lean_inc(x_371);
lean_inc_ref(x_370);
lean_inc(x_369);
lean_inc_ref(x_368);
x_376 = l_Lean_Meta_mkAppM(x_374, x_375, x_368, x_369, x_370, x_371, x_372);
if (lean_obj_tag(x_376) == 0)
{
lean_object* x_377; lean_object* x_378; lean_object* x_379; lean_object* x_380; lean_object* x_381; 
x_377 = lean_ctor_get(x_376, 0);
lean_inc(x_377);
x_378 = lean_ctor_get(x_376, 1);
lean_inc(x_378);
lean_dec_ref(x_376);
x_379 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39;
x_380 = lean_array_push(x_356, x_377);
lean_inc(x_371);
lean_inc_ref(x_370);
lean_inc(x_369);
lean_inc_ref(x_368);
x_381 = l_Lean_Meta_mkAppM(x_379, x_380, x_368, x_369, x_370, x_371, x_378);
if (lean_obj_tag(x_381) == 0)
{
lean_object* x_382; lean_object* x_383; lean_object* x_384; 
x_382 = lean_ctor_get(x_381, 0);
lean_inc(x_382);
x_383 = lean_ctor_get(x_381, 1);
lean_inc(x_383);
lean_dec_ref(x_381);
lean_inc(x_371);
lean_inc_ref(x_370);
x_384 = l_Lean_mkArrow(x_352, x_382, x_370, x_371, x_383);
if (lean_obj_tag(x_384) == 0)
{
lean_object* x_385; lean_object* x_386; lean_object* x_387; lean_object* x_388; lean_object* x_389; 
x_385 = lean_ctor_get(x_384, 0);
lean_inc(x_385);
x_386 = lean_ctor_get(x_384, 1);
lean_inc(x_386);
lean_dec_ref(x_384);
x_387 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_387, 0, x_385);
x_388 = lean_box(0);
lean_inc(x_371);
lean_inc_ref(x_370);
lean_inc(x_369);
lean_inc_ref(x_368);
lean_inc(x_367);
lean_inc_ref(x_366);
x_389 = l_Lean_Elab_Term_elabTermEnsuringType(x_365, x_387, x_11, x_11, x_388, x_366, x_367, x_368, x_369, x_370, x_371, x_386);
if (lean_obj_tag(x_389) == 0)
{
lean_object* x_390; lean_object* x_391; lean_object* x_392; lean_object* x_393; 
x_390 = lean_ctor_get(x_389, 0);
lean_inc(x_390);
x_391 = lean_ctor_get(x_389, 1);
lean_inc(x_391);
lean_dec_ref(x_389);
x_392 = l_Lean_instantiateMVars___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__12___redArg(x_390, x_369, x_391);
x_393 = lean_ctor_get(x_392, 0);
lean_inc(x_393);
if (lean_obj_tag(x_393) == 4)
{
lean_object* x_394; lean_object* x_395; lean_object* x_396; lean_object* x_397; lean_object* x_398; lean_object* x_399; lean_object* x_400; lean_object* x_401; lean_object* x_402; lean_object* x_403; lean_object* x_404; uint8_t x_405; 
x_394 = lean_ctor_get(x_392, 1);
lean_inc(x_394);
lean_dec_ref(x_392);
x_395 = lean_ctor_get(x_393, 0);
lean_inc(x_395);
lean_dec_ref(x_393);
x_396 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40;
x_397 = lean_st_ref_get(x_396, x_394);
x_398 = lean_ctor_get(x_397, 0);
lean_inc(x_398);
x_399 = lean_ctor_get(x_397, 1);
lean_inc(x_399);
lean_dec_ref(x_397);
x_400 = lean_st_ref_get(x_371, x_399);
x_401 = lean_ctor_get(x_400, 0);
lean_inc(x_401);
x_402 = lean_ctor_get(x_400, 1);
lean_inc(x_402);
lean_dec_ref(x_400);
x_403 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_395);
x_404 = l_Lean_Name_append(x_395, x_403);
x_405 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_398, x_404);
if (x_405 == 0)
{
lean_object* x_406; lean_object* x_407; lean_object* x_408; uint8_t x_409; 
x_406 = lean_ctor_get(x_401, 0);
lean_inc_ref(x_406);
lean_dec(x_401);
x_407 = lean_box(0);
x_408 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41;
lean_inc(x_404);
x_409 = l_Lean_MapDeclarationExtension_contains___redArg(x_407, x_408, x_406, x_404);
if (x_409 == 0)
{
lean_object* x_410; lean_object* x_411; lean_object* x_412; lean_object* x_413; lean_object* x_414; lean_object* x_415; lean_object* x_416; uint8_t x_417; 
lean_dec(x_404);
x_410 = lean_st_ref_get(x_396, x_402);
x_411 = lean_ctor_get(x_410, 0);
lean_inc(x_411);
x_412 = lean_ctor_get(x_410, 1);
lean_inc(x_412);
lean_dec_ref(x_410);
x_413 = lean_st_ref_get(x_371, x_412);
x_414 = lean_ctor_get(x_413, 0);
lean_inc(x_414);
x_415 = lean_ctor_get(x_413, 1);
lean_inc(x_415);
lean_dec_ref(x_413);
x_416 = lean_ctor_get(x_414, 0);
lean_inc_ref(x_416);
lean_dec(x_414);
x_417 = l_Lean_PersistentHashMap_contains___at___Lean_Server_registerBuiltinRpcProcedure___at_____private_Lean_Widget_UserWidget_0__Lean_Widget_initFn____x40_Lean_Widget_UserWidget_2369312278____hygCtx___hyg_2__spec__0_spec__0___redArg(x_411, x_395);
if (x_417 == 0)
{
x_137 = x_366;
x_138 = x_373;
x_139 = x_368;
x_140 = x_370;
x_141 = x_367;
x_142 = x_369;
x_143 = x_415;
x_144 = x_416;
x_145 = x_395;
x_146 = x_408;
x_147 = x_371;
x_148 = x_407;
x_149 = x_409;
x_150 = x_11;
goto block_164;
}
else
{
x_137 = x_366;
x_138 = x_373;
x_139 = x_368;
x_140 = x_370;
x_141 = x_367;
x_142 = x_369;
x_143 = x_415;
x_144 = x_416;
x_145 = x_395;
x_146 = x_408;
x_147 = x_371;
x_148 = x_407;
x_149 = x_409;
x_150 = x_409;
goto block_164;
}
}
else
{
lean_dec(x_395);
x_12 = x_366;
x_13 = x_373;
x_14 = x_368;
x_15 = x_404;
x_16 = x_370;
x_17 = x_367;
x_18 = x_369;
x_19 = x_371;
x_20 = x_402;
x_21 = x_409;
goto block_74;
}
}
else
{
lean_dec(x_401);
lean_dec(x_395);
x_12 = x_366;
x_13 = x_373;
x_14 = x_368;
x_15 = x_404;
x_16 = x_370;
x_17 = x_367;
x_18 = x_369;
x_19 = x_371;
x_20 = x_402;
x_21 = x_11;
goto block_74;
}
}
else
{
lean_object* x_418; lean_object* x_419; lean_object* x_420; lean_object* x_421; lean_object* x_422; lean_object* x_423; lean_object* x_424; 
lean_dec_ref(x_2);
x_418 = lean_ctor_get(x_392, 1);
lean_inc(x_418);
if (lean_is_exclusive(x_392)) {
 lean_ctor_release(x_392, 0);
 lean_ctor_release(x_392, 1);
 x_419 = x_392;
} else {
 lean_dec_ref(x_392);
 x_419 = lean_box(0);
}
x_420 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43;
x_421 = l_Lean_MessageData_ofExpr(x_393);
x_422 = l_Lean_indentD(x_421);
if (lean_is_scalar(x_419)) {
 x_423 = lean_alloc_ctor(7, 2, 0);
} else {
 x_423 = x_419;
 lean_ctor_set_tag(x_423, 7);
}
lean_ctor_set(x_423, 0, x_420);
lean_ctor_set(x_423, 1, x_422);
x_424 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_423, x_366, x_367, x_368, x_369, x_370, x_371, x_418);
lean_dec(x_371);
lean_dec_ref(x_370);
lean_dec(x_369);
lean_dec_ref(x_368);
lean_dec(x_367);
return x_424;
}
}
else
{
lean_dec(x_371);
lean_dec_ref(x_370);
lean_dec(x_369);
lean_dec_ref(x_368);
lean_dec(x_367);
lean_dec_ref(x_366);
lean_dec_ref(x_2);
return x_389;
}
}
else
{
lean_dec(x_371);
lean_dec_ref(x_370);
lean_dec(x_369);
lean_dec_ref(x_368);
lean_dec(x_367);
lean_dec_ref(x_366);
lean_dec(x_365);
lean_dec_ref(x_2);
return x_384;
}
}
else
{
lean_dec(x_371);
lean_dec_ref(x_370);
lean_dec(x_369);
lean_dec_ref(x_368);
lean_dec(x_367);
lean_dec_ref(x_366);
lean_dec(x_365);
lean_dec(x_352);
lean_dec_ref(x_2);
return x_381;
}
}
else
{
lean_dec(x_371);
lean_dec_ref(x_370);
lean_dec(x_369);
lean_dec_ref(x_368);
lean_dec(x_367);
lean_dec_ref(x_366);
lean_dec(x_365);
lean_dec(x_352);
lean_dec_ref(x_2);
return x_376;
}
}
}
else
{
lean_object* x_441; lean_object* x_442; lean_object* x_443; lean_object* x_444; 
lean_dec(x_361);
lean_dec(x_359);
lean_dec(x_352);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_441 = lean_ctor_get(x_362, 0);
lean_inc(x_441);
x_442 = lean_ctor_get(x_362, 1);
lean_inc(x_442);
if (lean_is_exclusive(x_362)) {
 lean_ctor_release(x_362, 0);
 lean_ctor_release(x_362, 1);
 x_443 = x_362;
} else {
 lean_dec_ref(x_362);
 x_443 = lean_box(0);
}
if (lean_is_scalar(x_443)) {
 x_444 = lean_alloc_ctor(1, 2, 0);
} else {
 x_444 = x_443;
}
lean_ctor_set(x_444, 0, x_441);
lean_ctor_set(x_444, 1, x_442);
return x_444;
}
}
else
{
lean_dec(x_352);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_358;
}
}
}
block_74:
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
x_22 = lean_ctor_get(x_16, 5);
x_23 = lean_ctor_get(x_16, 10);
x_24 = lean_ctor_get(x_16, 11);
x_25 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_26 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0;
x_27 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_15, x_21);
x_28 = l_String_replace(x_25, x_26, x_27);
lean_dec_ref(x_27);
x_29 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1;
x_30 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2;
x_31 = l_String_replace(x_28, x_29, x_30);
lean_dec_ref(x_28);
x_32 = lean_box(2);
x_33 = l_Lean_Syntax_mkStrLit(x_31, x_32);
x_34 = 0;
x_35 = l_Lean_SourceInfo_fromRef(x_22, x_34);
x_36 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3;
x_37 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4;
x_38 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5;
lean_inc_ref(x_13);
x_39 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_38);
x_40 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6;
lean_inc(x_35);
x_41 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_41, 0, x_35);
lean_ctor_set(x_41, 1, x_40);
x_42 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8;
x_43 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9;
lean_inc(x_35);
x_44 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_44, 0, x_35);
lean_ctor_set(x_44, 1, x_42);
lean_ctor_set(x_44, 2, x_43);
x_45 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10;
lean_inc_ref(x_13);
x_46 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_45);
x_47 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11;
lean_inc_ref(x_13);
x_48 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_47);
x_49 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12;
lean_inc_ref(x_13);
x_50 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_49);
x_51 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14;
x_52 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15;
lean_inc(x_24);
lean_inc(x_23);
x_53 = l_Lean_addMacroScope(x_23, x_52, x_24);
x_54 = lean_box(0);
lean_inc(x_35);
x_55 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_55, 0, x_35);
lean_ctor_set(x_55, 1, x_51);
lean_ctor_set(x_55, 2, x_53);
lean_ctor_set(x_55, 3, x_54);
lean_inc_ref(x_44);
lean_inc(x_35);
x_56 = l_Lean_Syntax_node2(x_35, x_50, x_55, x_44);
x_57 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16;
lean_inc_ref(x_13);
x_58 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_57);
x_59 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17;
lean_inc(x_35);
x_60 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_60, 0, x_35);
lean_ctor_set(x_60, 1, x_59);
lean_inc_ref(x_44);
lean_inc(x_35);
x_61 = l_Lean_Syntax_node3(x_35, x_58, x_60, x_44, x_33);
lean_inc_ref_n(x_44, 2);
lean_inc(x_35);
x_62 = l_Lean_Syntax_node3(x_35, x_42, x_44, x_44, x_61);
lean_inc(x_35);
x_63 = l_Lean_Syntax_node2(x_35, x_48, x_56, x_62);
lean_inc(x_35);
x_64 = l_Lean_Syntax_node1(x_35, x_42, x_63);
lean_inc(x_35);
x_65 = l_Lean_Syntax_node1(x_35, x_46, x_64);
x_66 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18;
x_67 = l_Lean_Name_mkStr4(x_13, x_36, x_37, x_66);
lean_inc_ref(x_44);
lean_inc(x_35);
x_68 = l_Lean_Syntax_node1(x_35, x_67, x_44);
x_69 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19;
lean_inc(x_35);
x_70 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_70, 0, x_35);
lean_ctor_set(x_70, 1, x_69);
lean_inc_ref(x_44);
x_71 = l_Lean_Syntax_node6(x_35, x_39, x_41, x_44, x_65, x_68, x_44, x_70);
x_72 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_72, 0, x_2);
x_73 = l_Lean_Elab_Term_elabTerm(x_71, x_72, x_11, x_11, x_12, x_17, x_14, x_18, x_16, x_19, x_20);
return x_73;
}
block_136:
{
lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; 
x_85 = lean_ctor_get(x_82, 5);
x_86 = lean_ctor_get(x_82, 10);
x_87 = lean_ctor_get(x_82, 11);
x_88 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_89 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0;
x_90 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_76, x_11);
x_91 = l_String_replace(x_88, x_89, x_90);
lean_dec_ref(x_90);
x_92 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1;
x_93 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20;
x_94 = l_String_replace(x_91, x_92, x_93);
lean_dec_ref(x_91);
x_95 = lean_box(2);
x_96 = l_Lean_Syntax_mkStrLit(x_94, x_95);
x_97 = l_Lean_SourceInfo_fromRef(x_85, x_77);
x_98 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3;
x_99 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4;
x_100 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5;
lean_inc_ref(x_75);
x_101 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_100);
x_102 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6;
lean_inc(x_97);
x_103 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_103, 0, x_97);
lean_ctor_set(x_103, 1, x_102);
x_104 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8;
x_105 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9;
lean_inc(x_97);
x_106 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_106, 0, x_97);
lean_ctor_set(x_106, 1, x_104);
lean_ctor_set(x_106, 2, x_105);
x_107 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10;
lean_inc_ref(x_75);
x_108 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_107);
x_109 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11;
lean_inc_ref(x_75);
x_110 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_109);
x_111 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12;
lean_inc_ref(x_75);
x_112 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_111);
x_113 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14;
x_114 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15;
lean_inc(x_87);
lean_inc(x_86);
x_115 = l_Lean_addMacroScope(x_86, x_114, x_87);
x_116 = lean_box(0);
lean_inc(x_97);
x_117 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_117, 0, x_97);
lean_ctor_set(x_117, 1, x_113);
lean_ctor_set(x_117, 2, x_115);
lean_ctor_set(x_117, 3, x_116);
lean_inc_ref(x_106);
lean_inc(x_97);
x_118 = l_Lean_Syntax_node2(x_97, x_112, x_117, x_106);
x_119 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16;
lean_inc_ref(x_75);
x_120 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_119);
x_121 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17;
lean_inc(x_97);
x_122 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_122, 0, x_97);
lean_ctor_set(x_122, 1, x_121);
lean_inc_ref(x_106);
lean_inc(x_97);
x_123 = l_Lean_Syntax_node3(x_97, x_120, x_122, x_106, x_96);
lean_inc_ref_n(x_106, 2);
lean_inc(x_97);
x_124 = l_Lean_Syntax_node3(x_97, x_104, x_106, x_106, x_123);
lean_inc(x_97);
x_125 = l_Lean_Syntax_node2(x_97, x_110, x_118, x_124);
lean_inc(x_97);
x_126 = l_Lean_Syntax_node1(x_97, x_104, x_125);
lean_inc(x_97);
x_127 = l_Lean_Syntax_node1(x_97, x_108, x_126);
x_128 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18;
x_129 = l_Lean_Name_mkStr4(x_75, x_98, x_99, x_128);
lean_inc_ref(x_106);
lean_inc(x_97);
x_130 = l_Lean_Syntax_node1(x_97, x_129, x_106);
x_131 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19;
lean_inc(x_97);
x_132 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_132, 0, x_97);
lean_ctor_set(x_132, 1, x_131);
lean_inc_ref(x_106);
x_133 = l_Lean_Syntax_node6(x_97, x_101, x_103, x_106, x_127, x_130, x_106, x_132);
x_134 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_134, 0, x_2);
x_135 = l_Lean_Elab_Term_elabTerm(x_133, x_134, x_11, x_11, x_78, x_79, x_80, x_81, x_82, x_83, x_84);
return x_135;
}
block_164:
{
if (x_150 == 0)
{
lean_dec(x_148);
lean_dec_ref(x_146);
lean_dec_ref(x_144);
x_75 = x_138;
x_76 = x_145;
x_77 = x_149;
x_78 = x_137;
x_79 = x_141;
x_80 = x_139;
x_81 = x_142;
x_82 = x_140;
x_83 = x_147;
x_84 = x_143;
goto block_136;
}
else
{
uint8_t x_151; 
lean_inc(x_145);
x_151 = l_Lean_MapDeclarationExtension_contains___redArg(x_148, x_146, x_144, x_145);
lean_dec_ref(x_146);
if (x_151 == 0)
{
lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; uint8_t x_160; 
lean_dec_ref(x_138);
lean_dec_ref(x_2);
x_152 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21;
x_153 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_145, x_150);
x_154 = lean_string_append(x_152, x_153);
lean_dec_ref(x_153);
x_155 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22;
x_156 = lean_string_append(x_154, x_155);
x_157 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_157, 0, x_156);
x_158 = l_Lean_MessageData_ofFormat(x_157);
x_159 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_Elab_liftMacroM___at___Lean_Widget_elabShowPanelWidgetsCmd_spec__1_spec__5_spec__5___redArg(x_158, x_137, x_141, x_139, x_142, x_140, x_147, x_143);
lean_dec(x_147);
lean_dec_ref(x_140);
lean_dec(x_142);
lean_dec_ref(x_139);
lean_dec(x_141);
x_160 = !lean_is_exclusive(x_159);
if (x_160 == 0)
{
return x_159;
}
else
{
lean_object* x_161; lean_object* x_162; lean_object* x_163; 
x_161 = lean_ctor_get(x_159, 0);
x_162 = lean_ctor_get(x_159, 1);
lean_inc(x_162);
lean_inc(x_161);
lean_dec(x_159);
x_163 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_163, 0, x_161);
lean_ctor_set(x_163, 1, x_162);
return x_163;
}
}
else
{
x_75 = x_138;
x_76 = x_145;
x_77 = x_149;
x_78 = x_137;
x_79 = x_141;
x_80 = x_139;
x_81 = x_142;
x_82 = x_140;
x_83 = x_147;
x_84 = x_143;
goto block_136;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0), 9, 1);
lean_closure_set(x_10, 0, x_1);
x_11 = l_Lean_Elab_Term_withExpectedType(x_2, x_10, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_11;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_ElabRules(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Cancellable(uint8_t builtin, lean_object*);
lean_object* initialize_Batteries_Tactic_OpenPrivate(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_ElabRules(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Cancellable(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Batteries_Tactic_OpenPrivate(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_ofRpcMethodTemplate___closed__0 = _init_l_ProofWidgets_ofRpcMethodTemplate___closed__0();
lean_mark_persistent(l_ProofWidgets_ofRpcMethodTemplate___closed__0);
l_ProofWidgets_ofRpcMethodTemplate = _init_l_ProofWidgets_ofRpcMethodTemplate();
lean_mark_persistent(l_ProofWidgets_ofRpcMethodTemplate);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__0 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__0();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__0);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__1 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__1();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__1);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__2 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__2();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__2);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__3 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__3();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__3);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__4 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__4();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__4);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__5 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__5();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__5);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__6 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__6();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__6);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__7 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__7();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__7);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__8 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__8();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__8);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__9 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__9();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__9);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__10 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__10();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__10);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__11 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__11();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__11);
l_ProofWidgets_termMk__rpc__widget_x25__ = _init_l_ProofWidgets_termMk__rpc__widget_x25__();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25__);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__0);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__1);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__2);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__3);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__4);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__5);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__6);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__7);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__8);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__9);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__10);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__11);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__12);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__13);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__14);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__15);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__16);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__17);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__18);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__19);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__20);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__21);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__22);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__23);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__24);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__25);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__26);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__27);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__28);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__29);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__30);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__31);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__32);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__33);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__34);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__35);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__36);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__37);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__38);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__39);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__40);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__41);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__42);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__43);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__44);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__45);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__46);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___closed__47);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
