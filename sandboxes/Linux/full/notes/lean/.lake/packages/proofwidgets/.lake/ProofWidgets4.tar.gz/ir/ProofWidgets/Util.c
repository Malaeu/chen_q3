// Lean compiler output
// Module: ProofWidgets.Util
// Imports: Init Lean.PrettyPrinter.Delaborator.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_foldInlsM___redArg___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Expr_isApp(lean_object*);
lean_object* l_Lean_Expr_sort___override(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_cleanupAnnotations(lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__5___boxed(lean_object*, lean_object*);
lean_object* l_Array_mkArray0(lean_object*);
lean_object* l_Lean_Meta_instantiateMVarsIfMVarApp___redArg(lean_object*, lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1;
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0;
lean_object* l_Lean_SourceInfo_fromRef(lean_object*, uint8_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_foldInlsM___redArg___closed__1;
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3;
lean_object* l_Lean_Syntax_node3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3;
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5;
extern lean_object* l_Lean_instInhabitedExpr;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_annotateCurPos___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__9(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___redArg(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_SubExpr_Pos_pushNaryArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4;
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__7(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_getAppNumArgs(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1;
lean_object* l_Lean_Expr_appFnCleanup___redArg(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__3(uint8_t, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__8(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2;
uint8_t l_Lean_Expr_isConstOf(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at___Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos_spec__0___redArg(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t l_instDecidableNot___redArg(uint8_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__5(lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_failure___redArg(lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_addTermInfo___redArg(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at___Lean_PrettyPrinter_Delaborator_getExprKind_spec__0___redArg(lean_object*, lean_object*);
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term#[_,]", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("#[", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("null", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = l_Array_mkArray0(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("]", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_4 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1;
x_5 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2;
lean_inc(x_1);
x_6 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_6, 0, x_1);
lean_ctor_set(x_6, 1, x_5);
x_7 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4;
x_8 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5;
lean_inc(x_1);
x_9 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_9, 0, x_1);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_8);
x_10 = l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6;
lean_inc(x_1);
x_11 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_11, 0, x_1);
lean_ctor_set(x_11, 1, x_10);
x_12 = l_Lean_Syntax_node3(x_1, x_4, x_6, x_9, x_11);
x_13 = lean_apply_2(x_2, lean_box(0), x_12);
return x_13;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = lean_apply_4(x_1, lean_box(0), lean_box(0), x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 2);
lean_inc(x_6);
lean_dec_ref(x_1);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__0___boxed), 3, 2);
lean_closure_set(x_7, 0, x_4);
lean_closure_set(x_7, 1, x_2);
lean_inc(x_3);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__1___boxed), 4, 3);
lean_closure_set(x_8, 0, x_3);
lean_closure_set(x_8, 1, x_6);
lean_closure_set(x_8, 2, x_7);
x_9 = lean_apply_4(x_3, lean_box(0), lean_box(0), x_5, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__3(uint8_t x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = l_Lean_SourceInfo_fromRef(x_3, x_1);
x_5 = lean_apply_2(x_2, lean_box(0), x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term_++_", 8, 8);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("++", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1;
x_7 = l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2;
lean_inc(x_1);
x_8 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_8, 0, x_1);
lean_ctor_set(x_8, 1, x_7);
x_9 = l_Lean_Syntax_node3(x_1, x_6, x_2, x_8, x_3);
x_10 = lean_apply_2(x_4, lean_box(0), x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__6(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 2);
lean_inc(x_8);
lean_dec_ref(x_1);
x_9 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__4___boxed), 5, 4);
lean_closure_set(x_9, 0, x_6);
lean_closure_set(x_9, 1, x_2);
lean_closure_set(x_9, 2, x_3);
lean_closure_set(x_9, 3, x_4);
lean_inc(x_5);
x_10 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__1___boxed), 4, 3);
lean_closure_set(x_10, 0, x_5);
lean_closure_set(x_10, 1, x_8);
lean_closure_set(x_10, 2, x_9);
x_11 = lean_apply_4(x_5, lean_box(0), lean_box(0), x_7, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__5(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; lean_object* x_5; 
x_3 = 0;
x_4 = l_Lean_SourceInfo_fromRef(x_2, x_3);
x_5 = lean_apply_2(x_1, lean_box(0), x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__7(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_6 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_6);
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
lean_dec_ref(x_1);
x_8 = lean_ctor_get(x_2, 0);
lean_inc(x_8);
lean_dec_ref(x_2);
x_9 = lean_ctor_get(x_6, 1);
lean_inc(x_9);
lean_dec_ref(x_6);
lean_inc(x_7);
lean_inc(x_9);
x_10 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__6), 6, 5);
lean_closure_set(x_10, 0, x_3);
lean_closure_set(x_10, 1, x_4);
lean_closure_set(x_10, 2, x_5);
lean_closure_set(x_10, 3, x_9);
lean_closure_set(x_10, 4, x_7);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__5___boxed), 2, 1);
lean_closure_set(x_11, 0, x_9);
lean_inc(x_7);
x_12 = lean_apply_4(x_7, lean_box(0), lean_box(0), x_8, x_11);
x_13 = lean_apply_4(x_7, lean_box(0), lean_box(0), x_12, x_10);
return x_13;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_array_get_size(x_4);
x_7 = lean_nat_dec_lt(x_5, x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
lean_dec(x_6);
lean_dec_ref(x_4);
x_8 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_8);
x_9 = lean_ctor_get(x_1, 1);
lean_inc(x_9);
lean_dec_ref(x_1);
x_10 = lean_ctor_get(x_2, 0);
lean_inc(x_10);
lean_dec_ref(x_2);
x_11 = lean_ctor_get(x_8, 1);
lean_inc(x_11);
lean_dec_ref(x_8);
lean_inc(x_9);
lean_inc(x_11);
x_12 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__2), 4, 3);
lean_closure_set(x_12, 0, x_3);
lean_closure_set(x_12, 1, x_11);
lean_closure_set(x_12, 2, x_9);
x_13 = lean_box(x_7);
x_14 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__3___boxed), 3, 2);
lean_closure_set(x_14, 0, x_13);
lean_closure_set(x_14, 1, x_11);
lean_inc(x_9);
x_15 = lean_apply_4(x_9, lean_box(0), lean_box(0), x_10, x_14);
x_16 = lean_apply_4(x_9, lean_box(0), lean_box(0), x_15, x_12);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_array_fget(x_4, x_5);
x_18 = lean_unsigned_to_nat(1u);
x_19 = lean_nat_dec_lt(x_18, x_6);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
lean_dec(x_6);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_20 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_20);
lean_dec_ref(x_1);
x_21 = lean_ctor_get(x_20, 1);
lean_inc(x_21);
lean_dec_ref(x_20);
x_22 = lean_apply_2(x_21, lean_box(0), x_17);
return x_22;
}
else
{
uint8_t x_23; 
x_23 = lean_nat_dec_le(x_6, x_6);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
lean_dec(x_6);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_24 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_24);
lean_dec_ref(x_1);
x_25 = lean_ctor_get(x_24, 1);
lean_inc(x_25);
lean_dec_ref(x_24);
x_26 = lean_apply_2(x_25, lean_box(0), x_17);
return x_26;
}
else
{
lean_object* x_27; size_t x_28; size_t x_29; lean_object* x_30; 
lean_inc_ref(x_1);
x_27 = lean_alloc_closure((void*)(l_ProofWidgets_Util_joinArrays___redArg___lam__7), 5, 3);
lean_closure_set(x_27, 0, x_1);
lean_closure_set(x_27, 1, x_2);
lean_closure_set(x_27, 2, x_3);
x_28 = 1;
x_29 = lean_usize_of_nat(x_6);
lean_dec(x_6);
x_30 = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(x_1, x_27, x_4, x_28, x_29, x_17);
return x_30;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_Util_joinArrays___redArg(x_2, x_3, x_4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Util_joinArrays___redArg___lam__0(x_1, x_2, x_3);
lean_dec(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_Util_joinArrays___redArg___lam__1(x_1, x_2, x_3, x_4);
lean_dec(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; lean_object* x_5; 
x_4 = lean_unbox(x_1);
x_5 = l_ProofWidgets_Util_joinArrays___redArg___lam__3(x_4, x_2, x_3);
lean_dec(x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_Util_joinArrays___redArg___lam__4(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___redArg___lam__5___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_Util_joinArrays___redArg___lam__5(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_1);
lean_ctor_set(x_5, 1, x_2);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
x_7 = lean_apply_2(x_3, lean_box(0), x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_1);
lean_ctor_set(x_5, 1, x_2);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
x_7 = lean_apply_2(x_3, lean_box(0), x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_8 = lean_array_push(x_6, x_1);
lean_inc(x_3);
x_9 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__1), 4, 3);
lean_closure_set(x_9, 0, x_2);
lean_closure_set(x_9, 1, x_8);
lean_closure_set(x_9, 2, x_3);
x_10 = lean_box(0);
x_11 = lean_apply_2(x_3, lean_box(0), x_10);
x_12 = lean_apply_4(x_4, lean_box(0), lean_box(0), x_11, x_9);
return x_12;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = lean_apply_3(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = lean_apply_3(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_array_push(x_1, x_6);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__4), 4, 3);
lean_closure_set(x_8, 0, x_2);
lean_closure_set(x_8, 1, x_3);
lean_closure_set(x_8, 2, x_7);
x_9 = lean_box(0);
x_10 = lean_apply_2(x_4, lean_box(0), x_9);
x_11 = lean_apply_4(x_5, lean_box(0), lean_box(0), x_10, x_8);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__6(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
if (lean_obj_tag(x_6) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
lean_dec(x_5);
lean_dec_ref(x_3);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec_ref(x_8);
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec_ref(x_6);
x_12 = lean_array_push(x_9, x_11);
lean_inc(x_1);
x_13 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__0), 4, 3);
lean_closure_set(x_13, 0, x_12);
lean_closure_set(x_13, 1, x_10);
lean_closure_set(x_13, 2, x_1);
x_14 = lean_box(0);
x_15 = lean_apply_2(x_1, lean_box(0), x_14);
x_16 = lean_apply_4(x_2, lean_box(0), lean_box(0), x_15, x_13);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; uint8_t x_23; 
x_17 = lean_ctor_get(x_8, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_8, 1);
lean_inc(x_18);
lean_dec_ref(x_8);
x_19 = lean_ctor_get(x_6, 0);
lean_inc(x_19);
lean_dec_ref(x_6);
lean_inc(x_2);
lean_inc(x_1);
x_20 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__2___boxed), 7, 4);
lean_closure_set(x_20, 0, x_19);
lean_closure_set(x_20, 1, x_3);
lean_closure_set(x_20, 2, x_1);
lean_closure_set(x_20, 3, x_2);
x_21 = lean_array_get_size(x_17);
x_22 = lean_nat_dec_eq(x_21, x_4);
lean_dec(x_21);
x_23 = l_instDecidableNot___redArg(x_22);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
lean_dec(x_5);
x_24 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__3), 4, 3);
lean_closure_set(x_24, 0, x_20);
lean_closure_set(x_24, 1, x_17);
lean_closure_set(x_24, 2, x_18);
x_25 = lean_box(0);
x_26 = lean_apply_2(x_1, lean_box(0), x_25);
x_27 = lean_apply_4(x_2, lean_box(0), lean_box(0), x_26, x_24);
return x_27;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
lean_inc(x_2);
lean_inc(x_17);
x_28 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__5), 6, 5);
lean_closure_set(x_28, 0, x_18);
lean_closure_set(x_28, 1, x_20);
lean_closure_set(x_28, 2, x_17);
lean_closure_set(x_28, 3, x_1);
lean_closure_set(x_28, 4, x_2);
x_29 = lean_apply_1(x_5, x_17);
x_30 = lean_apply_4(x_2, lean_box(0), lean_box(0), x_29, x_28);
return x_30;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__7(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = lean_apply_2(x_1, lean_box(0), x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__8(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = lean_apply_2(x_1, lean_box(0), x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__9(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_array_push(x_1, x_4);
lean_inc(x_2);
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__8), 3, 2);
lean_closure_set(x_6, 0, x_2);
lean_closure_set(x_6, 1, x_5);
x_7 = lean_box(0);
x_8 = lean_apply_2(x_2, lean_box(0), x_7);
x_9 = lean_apply_4(x_3, lean_box(0), lean_box(0), x_8, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__10(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; uint8_t x_10; 
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_5, 1);
lean_inc(x_7);
lean_dec_ref(x_5);
x_8 = lean_array_get_size(x_6);
x_9 = lean_nat_dec_eq(x_8, x_1);
lean_dec(x_8);
x_10 = l_instDecidableNot___redArg(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
lean_dec(x_6);
lean_dec(x_4);
lean_inc(x_2);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__7), 3, 2);
lean_closure_set(x_11, 0, x_2);
lean_closure_set(x_11, 1, x_7);
x_12 = lean_box(0);
x_13 = lean_apply_2(x_2, lean_box(0), x_12);
x_14 = lean_apply_4(x_3, lean_box(0), lean_box(0), x_13, x_11);
return x_14;
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
lean_inc(x_3);
x_15 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__9), 4, 3);
lean_closure_set(x_15, 0, x_7);
lean_closure_set(x_15, 1, x_2);
lean_closure_set(x_15, 2, x_3);
x_16 = lean_apply_1(x_4, x_6);
x_17 = lean_apply_4(x_3, lean_box(0), lean_box(0), x_16, x_15);
return x_17;
}
}
}
static lean_object* _init_l_ProofWidgets_Util_foldInlsM___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Util_foldInlsM___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Util_foldInlsM___redArg___closed__0;
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; size_t x_12; size_t x_13; lean_object* x_14; lean_object* x_15; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
x_7 = lean_unsigned_to_nat(0u);
x_8 = l_ProofWidgets_Util_foldInlsM___redArg___closed__0;
x_9 = l_ProofWidgets_Util_foldInlsM___redArg___closed__1;
lean_inc(x_3);
lean_inc(x_5);
lean_inc(x_6);
x_10 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__6___boxed), 8, 5);
lean_closure_set(x_10, 0, x_6);
lean_closure_set(x_10, 1, x_5);
lean_closure_set(x_10, 2, x_8);
lean_closure_set(x_10, 3, x_7);
lean_closure_set(x_10, 4, x_3);
lean_inc(x_5);
lean_inc(x_6);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___redArg___lam__10___boxed), 5, 4);
lean_closure_set(x_11, 0, x_7);
lean_closure_set(x_11, 1, x_6);
lean_closure_set(x_11, 2, x_5);
lean_closure_set(x_11, 3, x_3);
x_12 = lean_array_size(x_2);
x_13 = 0;
x_14 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___redArg(x_1, x_2, x_10, x_12, x_13, x_9);
x_15 = lean_apply_4(x_5, lean_box(0), lean_box(0), x_14, x_11);
return x_15;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_ProofWidgets_Util_foldInlsM___redArg(x_4, x_5, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_ProofWidgets_Util_foldInlsM___redArg___lam__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec_ref(x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Util_foldInlsM___redArg___lam__6(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_4);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___redArg___lam__10___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_Util_foldInlsM___redArg___lam__10(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_1);
return x_6;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = l_Lean_Expr_sort___override(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
lean_inc_ref(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at___Lean_PrettyPrinter_Delaborator_getExprKind_spec__0___redArg(x_3, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec_ref(x_10);
lean_inc_ref(x_3);
x_13 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at___Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos_spec__0___redArg(x_3, x_12);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_3);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_16 = lean_ctor_get(x_13, 0);
x_17 = lean_ctor_get(x_13, 1);
x_18 = lean_ctor_get(x_3, 3);
lean_dec(x_18);
x_19 = l_Lean_instInhabitedExpr;
x_20 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0;
x_21 = l_Lean_Expr_getAppNumArgs(x_11);
lean_inc(x_21);
x_22 = lean_mk_array(x_21, x_20);
x_23 = lean_unsigned_to_nat(1u);
x_24 = lean_nat_sub(x_21, x_23);
lean_dec(x_21);
x_25 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_22, x_24);
x_26 = lean_array_get_size(x_25);
x_27 = l_Lean_SubExpr_Pos_pushNaryArg(x_26, x_1, x_16);
lean_dec(x_16);
lean_dec(x_26);
x_28 = lean_array_get(x_19, x_25, x_1);
lean_dec_ref(x_25);
lean_ctor_set(x_13, 1, x_27);
lean_ctor_set(x_13, 0, x_28);
lean_ctor_set(x_3, 3, x_13);
x_29 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_17);
return x_29;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_30 = lean_ctor_get(x_13, 0);
x_31 = lean_ctor_get(x_13, 1);
x_32 = lean_ctor_get(x_3, 0);
x_33 = lean_ctor_get(x_3, 1);
x_34 = lean_ctor_get(x_3, 2);
x_35 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_36 = lean_ctor_get(x_3, 4);
lean_inc(x_36);
lean_inc(x_34);
lean_inc(x_33);
lean_inc(x_32);
lean_dec(x_3);
x_37 = l_Lean_instInhabitedExpr;
x_38 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0;
x_39 = l_Lean_Expr_getAppNumArgs(x_11);
lean_inc(x_39);
x_40 = lean_mk_array(x_39, x_38);
x_41 = lean_unsigned_to_nat(1u);
x_42 = lean_nat_sub(x_39, x_41);
lean_dec(x_39);
x_43 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_40, x_42);
x_44 = lean_array_get_size(x_43);
x_45 = l_Lean_SubExpr_Pos_pushNaryArg(x_44, x_1, x_30);
lean_dec(x_30);
lean_dec(x_44);
x_46 = lean_array_get(x_37, x_43, x_1);
lean_dec_ref(x_43);
lean_ctor_set(x_13, 1, x_45);
lean_ctor_set(x_13, 0, x_46);
x_47 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_47, 0, x_32);
lean_ctor_set(x_47, 1, x_33);
lean_ctor_set(x_47, 2, x_34);
lean_ctor_set(x_47, 3, x_13);
lean_ctor_set(x_47, 4, x_36);
lean_ctor_set_uint8(x_47, sizeof(void*)*5, x_35);
x_48 = lean_apply_7(x_2, x_47, x_4, x_5, x_6, x_7, x_8, x_31);
return x_48;
}
}
else
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; 
x_49 = lean_ctor_get(x_13, 0);
x_50 = lean_ctor_get(x_13, 1);
lean_inc(x_50);
lean_inc(x_49);
lean_dec(x_13);
x_51 = lean_ctor_get(x_3, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_3, 1);
lean_inc(x_52);
x_53 = lean_ctor_get(x_3, 2);
lean_inc(x_53);
x_54 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_55 = lean_ctor_get(x_3, 4);
lean_inc(x_55);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 lean_ctor_release(x_3, 2);
 lean_ctor_release(x_3, 3);
 lean_ctor_release(x_3, 4);
 x_56 = x_3;
} else {
 lean_dec_ref(x_3);
 x_56 = lean_box(0);
}
x_57 = l_Lean_instInhabitedExpr;
x_58 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0;
x_59 = l_Lean_Expr_getAppNumArgs(x_11);
lean_inc(x_59);
x_60 = lean_mk_array(x_59, x_58);
x_61 = lean_unsigned_to_nat(1u);
x_62 = lean_nat_sub(x_59, x_61);
lean_dec(x_59);
x_63 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_60, x_62);
x_64 = lean_array_get_size(x_63);
x_65 = l_Lean_SubExpr_Pos_pushNaryArg(x_64, x_1, x_49);
lean_dec(x_49);
lean_dec(x_64);
x_66 = lean_array_get(x_57, x_63, x_1);
lean_dec_ref(x_63);
x_67 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_67, 0, x_66);
lean_ctor_set(x_67, 1, x_65);
if (lean_is_scalar(x_56)) {
 x_68 = lean_alloc_ctor(0, 5, 1);
} else {
 x_68 = x_56;
}
lean_ctor_set(x_68, 0, x_51);
lean_ctor_set(x_68, 1, x_52);
lean_ctor_set(x_68, 2, x_53);
lean_ctor_set(x_68, 3, x_67);
lean_ctor_set(x_68, 4, x_55);
lean_ctor_set_uint8(x_68, sizeof(void*)*5, x_54);
x_69 = lean_apply_7(x_2, x_68, x_4, x_5, x_6, x_7, x_8, x_50);
return x_69;
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("List", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("nil", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1;
x_2 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("cons", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3;
x_2 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
lean_inc_ref(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at___Lean_PrettyPrinter_Delaborator_getExprKind_spec__0___redArg(x_3, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec_ref(x_10);
x_13 = l_Lean_Meta_instantiateMVarsIfMVarApp___redArg(x_11, x_6, x_12);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
x_17 = l_Lean_Expr_cleanupAnnotations(x_15);
x_18 = l_Lean_Expr_isApp(x_17);
if (x_18 == 0)
{
lean_object* x_19; 
lean_dec_ref(x_17);
lean_free_object(x_13);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_19 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_16);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; uint8_t x_22; 
x_20 = l_Lean_Expr_appFnCleanup___redArg(x_17);
x_21 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2;
x_22 = l_Lean_Expr_isConstOf(x_20, x_21);
if (x_22 == 0)
{
uint8_t x_23; 
lean_free_object(x_13);
x_23 = l_Lean_Expr_isApp(x_20);
if (x_23 == 0)
{
lean_object* x_24; 
lean_dec_ref(x_20);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_24 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_16);
return x_24;
}
else
{
lean_object* x_25; uint8_t x_26; 
x_25 = l_Lean_Expr_appFnCleanup___redArg(x_20);
x_26 = l_Lean_Expr_isApp(x_25);
if (x_26 == 0)
{
lean_object* x_27; 
lean_dec_ref(x_25);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_27 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_16);
return x_27;
}
else
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_28 = l_Lean_Expr_appFnCleanup___redArg(x_25);
x_29 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4;
x_30 = l_Lean_Expr_isConstOf(x_28, x_29);
lean_dec_ref(x_28);
if (x_30 == 0)
{
lean_object* x_31; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_31 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_16);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; 
x_32 = lean_unsigned_to_nat(1u);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_4);
lean_inc_ref(x_3);
lean_inc_ref(x_1);
x_33 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_32, x_1, x_3, x_4, x_5, x_6, x_7, x_8, x_16);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec_ref(x_33);
x_36 = lean_unsigned_to_nat(2u);
x_37 = lean_array_push(x_2, x_34);
x_38 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg), 9, 2);
lean_closure_set(x_38, 0, x_1);
lean_closure_set(x_38, 1, x_37);
x_39 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_36, x_38, x_3, x_4, x_5, x_6, x_7, x_8, x_35);
return x_39;
}
else
{
uint8_t x_40; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_40 = !lean_is_exclusive(x_33);
if (x_40 == 0)
{
return x_33;
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
x_41 = lean_ctor_get(x_33, 0);
x_42 = lean_ctor_get(x_33, 1);
lean_inc(x_42);
lean_inc(x_41);
lean_dec(x_33);
x_43 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_43, 0, x_41);
lean_ctor_set(x_43, 1, x_42);
return x_43;
}
}
}
}
}
}
else
{
lean_dec_ref(x_20);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_1);
lean_ctor_set(x_13, 0, x_2);
return x_13;
}
}
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; uint8_t x_47; 
x_44 = lean_ctor_get(x_13, 0);
x_45 = lean_ctor_get(x_13, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_13);
x_46 = l_Lean_Expr_cleanupAnnotations(x_44);
x_47 = l_Lean_Expr_isApp(x_46);
if (x_47 == 0)
{
lean_object* x_48; 
lean_dec_ref(x_46);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_48 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_45);
return x_48;
}
else
{
lean_object* x_49; lean_object* x_50; uint8_t x_51; 
x_49 = l_Lean_Expr_appFnCleanup___redArg(x_46);
x_50 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2;
x_51 = l_Lean_Expr_isConstOf(x_49, x_50);
if (x_51 == 0)
{
uint8_t x_52; 
x_52 = l_Lean_Expr_isApp(x_49);
if (x_52 == 0)
{
lean_object* x_53; 
lean_dec_ref(x_49);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_53 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_45);
return x_53;
}
else
{
lean_object* x_54; uint8_t x_55; 
x_54 = l_Lean_Expr_appFnCleanup___redArg(x_49);
x_55 = l_Lean_Expr_isApp(x_54);
if (x_55 == 0)
{
lean_object* x_56; 
lean_dec_ref(x_54);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_56 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_45);
return x_56;
}
else
{
lean_object* x_57; lean_object* x_58; uint8_t x_59; 
x_57 = l_Lean_Expr_appFnCleanup___redArg(x_54);
x_58 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4;
x_59 = l_Lean_Expr_isConstOf(x_57, x_58);
lean_dec_ref(x_57);
if (x_59 == 0)
{
lean_object* x_60; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_60 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_45);
return x_60;
}
else
{
lean_object* x_61; lean_object* x_62; 
x_61 = lean_unsigned_to_nat(1u);
lean_inc(x_8);
lean_inc_ref(x_7);
lean_inc(x_6);
lean_inc_ref(x_5);
lean_inc(x_4);
lean_inc_ref(x_3);
lean_inc_ref(x_1);
x_62 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_61, x_1, x_3, x_4, x_5, x_6, x_7, x_8, x_45);
if (lean_obj_tag(x_62) == 0)
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_63 = lean_ctor_get(x_62, 0);
lean_inc(x_63);
x_64 = lean_ctor_get(x_62, 1);
lean_inc(x_64);
lean_dec_ref(x_62);
x_65 = lean_unsigned_to_nat(2u);
x_66 = lean_array_push(x_2, x_63);
x_67 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg), 9, 2);
lean_closure_set(x_67, 0, x_1);
lean_closure_set(x_67, 1, x_66);
x_68 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_65, x_67, x_3, x_4, x_5, x_6, x_7, x_8, x_64);
return x_68;
}
else
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_69 = lean_ctor_get(x_62, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_62, 1);
lean_inc(x_70);
if (lean_is_exclusive(x_62)) {
 lean_ctor_release(x_62, 0);
 lean_ctor_release(x_62, 1);
 x_71 = x_62;
} else {
 lean_dec_ref(x_62);
 x_71 = lean_box(0);
}
if (lean_is_scalar(x_71)) {
 x_72 = lean_alloc_ctor(1, 2, 0);
} else {
 x_72 = x_71;
}
lean_ctor_set(x_72, 0, x_69);
lean_ctor_set(x_72, 1, x_70);
return x_72;
}
}
}
}
}
else
{
lean_object* x_73; 
lean_dec_ref(x_49);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_1);
x_73 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_73, 0, x_2);
lean_ctor_set(x_73, 1, x_45);
return x_73;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_2);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = l_ProofWidgets_Util_foldInlsM___redArg___closed__0;
x_10 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg(x_1, x_9, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabListLiteral(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_10;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("toArray", 7, 7);
return x_1;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0;
x_2 = l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
lean_inc_ref(x_2);
x_9 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at___Lean_PrettyPrinter_Delaborator_getExprKind_spec__0___redArg(x_2, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = l_Lean_Meta_instantiateMVarsIfMVarApp___redArg(x_10, x_5, x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 1);
lean_inc(x_14);
lean_dec_ref(x_12);
x_15 = l_Lean_Expr_cleanupAnnotations(x_13);
x_16 = l_Lean_Expr_isApp(x_15);
if (x_16 == 0)
{
lean_object* x_17; 
lean_dec_ref(x_15);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_17 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_14);
return x_17;
}
else
{
lean_object* x_18; uint8_t x_19; 
x_18 = l_Lean_Expr_appFnCleanup___redArg(x_15);
x_19 = l_Lean_Expr_isApp(x_18);
if (x_19 == 0)
{
lean_object* x_20; 
lean_dec_ref(x_18);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_20 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_14);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_21 = l_Lean_Expr_appFnCleanup___redArg(x_18);
x_22 = l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1;
x_23 = l_Lean_Expr_isConstOf(x_21, x_22);
lean_dec_ref(x_21);
if (x_23 == 0)
{
lean_object* x_24; 
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
x_24 = l_Lean_PrettyPrinter_Delaborator_failure___redArg(x_14);
return x_24;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_25 = lean_unsigned_to_nat(1u);
x_26 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delabListLiteral), 9, 2);
lean_closure_set(x_26, 0, lean_box(0));
lean_closure_set(x_26, 1, x_1);
x_27 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg(x_25, x_26, x_2, x_3, x_4, x_5, x_6, x_7, x_14);
return x_27;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; lean_object* x_16; uint8_t x_17; 
lean_inc_ref(x_2);
x_6 = l_Lean_PrettyPrinter_Delaborator_annotateCurPos___redArg(x_1, x_2, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
x_8 = lean_ctor_get(x_6, 1);
lean_inc(x_8);
lean_dec_ref(x_6);
lean_inc_ref(x_2);
x_9 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at___Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos_spec__0___redArg(x_2, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at___Lean_PrettyPrinter_Delaborator_getExprKind_spec__0___redArg(x_2, x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 1);
lean_inc(x_14);
lean_dec_ref(x_12);
x_15 = 0;
lean_inc(x_7);
x_16 = l_Lean_PrettyPrinter_Delaborator_addTermInfo___redArg(x_10, x_7, x_13, x_15, x_3, x_4, x_14);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; 
x_18 = lean_ctor_get(x_16, 0);
lean_dec(x_18);
lean_ctor_set(x_16, 0, x_7);
return x_16;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_16, 1);
lean_inc(x_19);
lean_dec(x_16);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_7);
lean_ctor_set(x_20, 1, x_19);
return x_20;
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg(x_2, x_3, x_4, x_5, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc_ref(x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
x_9 = lean_apply_7(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___redArg(x_10, x_2, x_3, x_4, x_11);
lean_dec_ref(x_4);
lean_dec(x_3);
return x_12;
}
else
{
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_9;
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_PrettyPrinter_Delaborator_Basic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Util(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_PrettyPrinter_Delaborator_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__0);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__1);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__2);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__3);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__4);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__5);
l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__0___closed__6);
l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__0);
l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__1);
l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2 = _init_l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2();
lean_mark_persistent(l_ProofWidgets_Util_joinArrays___redArg___lam__4___closed__2);
l_ProofWidgets_Util_foldInlsM___redArg___closed__0 = _init_l_ProofWidgets_Util_foldInlsM___redArg___closed__0();
lean_mark_persistent(l_ProofWidgets_Util_foldInlsM___redArg___closed__0);
l_ProofWidgets_Util_foldInlsM___redArg___closed__1 = _init_l_ProofWidgets_Util_foldInlsM___redArg___closed__1();
lean_mark_persistent(l_ProofWidgets_Util_foldInlsM___redArg___closed__1);
l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0 = _init_l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at___Lean_PrettyPrinter_Delaborator_delabListLiteral_go_spec__0___redArg___closed__0);
l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0 = _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__0);
l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1 = _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__1);
l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2 = _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__2);
l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3 = _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__3);
l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4 = _init_l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabListLiteral_go___redArg___closed__4);
l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0 = _init_l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__0);
l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1 = _init_l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___redArg___closed__1);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
