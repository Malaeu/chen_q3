// Lean compiler output
// Module: ProofWidgets.Compat
// Imports: Init Lean.Elab.InfoTree.Main
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_ctorIdx___boxed(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_runMetaM(lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedFileMap_default;
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Meta_withLCtx___at___Lean_Meta_ppGoal_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_ctorIdx(lean_object*);
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0;
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1;
static lean_object* l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
LEAN_EXPORT lean_object* l_ProofWidgets_instTypeNameExprWithCtx;
static lean_object* l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
static lean_object* l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_save___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
lean_object* l_Lean_Meta_getLocalInstances___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5;
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_save(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_ExprWithCtx_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ExprWithCtx", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
x_2 = l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instTypeNameExprWithCtx() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2;
x_4 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(1);
x_2 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4;
x_3 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_4);
x_5 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_5);
x_6 = lean_ctor_get(x_1, 2);
lean_inc_ref(x_6);
x_7 = lean_ctor_get(x_1, 3);
lean_inc_ref(x_7);
lean_dec_ref(x_1);
x_8 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5;
x_9 = lean_apply_1(x_2, x_7);
x_10 = lean_alloc_closure((void*)(l_Lean_Meta_withLCtx___at___Lean_Meta_ppGoal_spec__6), 9, 4);
lean_closure_set(x_10, 0, lean_box(0));
lean_closure_set(x_10, 1, x_5);
lean_closure_set(x_10, 2, x_6);
lean_closure_set(x_10, 3, x_9);
x_11 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_4, x_8, x_10, x_3);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_runMetaM(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_5 = lean_st_ref_get(x_3, x_4);
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_5, 1);
lean_inc(x_7);
lean_dec_ref(x_5);
x_8 = lean_ctor_get(x_6, 0);
lean_inc_ref(x_8);
lean_dec(x_6);
x_9 = lean_st_ref_get(x_1, x_7);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
lean_dec(x_10);
x_13 = lean_ctor_get(x_2, 2);
x_14 = lean_ctor_get(x_2, 6);
x_15 = lean_ctor_get(x_2, 7);
x_16 = lean_st_ref_get(x_3, x_11);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_18 = lean_ctor_get(x_16, 0);
x_19 = lean_ctor_get(x_18, 2);
lean_inc_ref(x_19);
lean_dec(x_18);
x_20 = l_Lean_instInhabitedFileMap_default;
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
x_21 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_21, 0, x_8);
lean_ctor_set(x_21, 1, x_20);
lean_ctor_set(x_21, 2, x_12);
lean_ctor_set(x_21, 3, x_13);
lean_ctor_set(x_21, 4, x_14);
lean_ctor_set(x_21, 5, x_15);
lean_ctor_set(x_21, 6, x_19);
lean_ctor_set(x_16, 0, x_21);
return x_16;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_22 = lean_ctor_get(x_16, 0);
x_23 = lean_ctor_get(x_16, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_16);
x_24 = lean_ctor_get(x_22, 2);
lean_inc_ref(x_24);
lean_dec(x_22);
x_25 = l_Lean_instInhabitedFileMap_default;
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
x_26 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_26, 0, x_8);
lean_ctor_set(x_26, 1, x_25);
lean_ctor_set(x_26, 2, x_12);
lean_ctor_set(x_26, 3, x_13);
lean_ctor_set(x_26, 4, x_14);
lean_ctor_set(x_26, 5, x_15);
lean_ctor_set(x_26, 6, x_24);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_23);
return x_27;
}
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg(x_2, x_3, x_4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; uint8_t x_7; 
x_6 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg(x_2, x_3, x_4, x_5);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; uint8_t x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_3, 1);
x_11 = lean_ctor_get(x_8, 1);
lean_dec(x_11);
lean_inc_ref(x_10);
lean_ctor_set(x_8, 1, x_10);
return x_6;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_12 = lean_ctor_get(x_3, 1);
x_13 = lean_ctor_get(x_8, 0);
x_14 = lean_ctor_get(x_8, 2);
x_15 = lean_ctor_get(x_8, 3);
x_16 = lean_ctor_get(x_8, 4);
x_17 = lean_ctor_get(x_8, 5);
x_18 = lean_ctor_get(x_8, 6);
lean_inc(x_18);
lean_inc(x_17);
lean_inc(x_16);
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_8);
lean_inc_ref(x_12);
x_19 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_19, 0, x_13);
lean_ctor_set(x_19, 1, x_12);
lean_ctor_set(x_19, 2, x_14);
lean_ctor_set(x_19, 3, x_15);
lean_ctor_set(x_19, 4, x_16);
lean_ctor_set(x_19, 5, x_17);
lean_ctor_set(x_19, 6, x_18);
lean_ctor_set(x_6, 0, x_19);
return x_6;
}
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_20 = lean_ctor_get(x_6, 0);
x_21 = lean_ctor_get(x_6, 1);
lean_inc(x_21);
lean_inc(x_20);
lean_dec(x_6);
x_22 = lean_ctor_get(x_3, 1);
x_23 = lean_ctor_get(x_20, 0);
lean_inc_ref(x_23);
x_24 = lean_ctor_get(x_20, 2);
lean_inc_ref(x_24);
x_25 = lean_ctor_get(x_20, 3);
lean_inc(x_25);
x_26 = lean_ctor_get(x_20, 4);
lean_inc(x_26);
x_27 = lean_ctor_get(x_20, 5);
lean_inc(x_27);
x_28 = lean_ctor_get(x_20, 6);
lean_inc_ref(x_28);
if (lean_is_exclusive(x_20)) {
 lean_ctor_release(x_20, 0);
 lean_ctor_release(x_20, 1);
 lean_ctor_release(x_20, 2);
 lean_ctor_release(x_20, 3);
 lean_ctor_release(x_20, 4);
 lean_ctor_release(x_20, 5);
 lean_ctor_release(x_20, 6);
 x_29 = x_20;
} else {
 lean_dec_ref(x_20);
 x_29 = lean_box(0);
}
lean_inc_ref(x_22);
if (lean_is_scalar(x_29)) {
 x_30 = lean_alloc_ctor(0, 7, 0);
} else {
 x_30 = x_29;
}
lean_ctor_set(x_30, 0, x_23);
lean_ctor_set(x_30, 1, x_22);
lean_ctor_set(x_30, 2, x_24);
lean_ctor_set(x_30, 3, x_25);
lean_ctor_set(x_30, 4, x_26);
lean_ctor_set(x_30, 5, x_27);
lean_ctor_set(x_30, 6, x_28);
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set(x_31, 1, x_21);
return x_31;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_save(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; uint8_t x_8; 
x_7 = l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0(x_2, x_3, x_4, x_5, x_6);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_9 = lean_ctor_get(x_7, 1);
x_10 = l_Lean_Meta_getLocalInstances___redArg(x_2, x_9);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = lean_ctor_get(x_2, 2);
x_14 = lean_box(0);
lean_ctor_set(x_7, 1, x_14);
lean_inc_ref(x_13);
x_15 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_15, 0, x_7);
lean_ctor_set(x_15, 1, x_13);
lean_ctor_set(x_15, 2, x_12);
lean_ctor_set(x_15, 3, x_1);
lean_ctor_set(x_10, 0, x_15);
return x_10;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_16 = lean_ctor_get(x_10, 0);
x_17 = lean_ctor_get(x_10, 1);
lean_inc(x_17);
lean_inc(x_16);
lean_dec(x_10);
x_18 = lean_ctor_get(x_2, 2);
x_19 = lean_box(0);
lean_ctor_set(x_7, 1, x_19);
lean_inc_ref(x_18);
x_20 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_20, 0, x_7);
lean_ctor_set(x_20, 1, x_18);
lean_ctor_set(x_20, 2, x_16);
lean_ctor_set(x_20, 3, x_1);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_17);
return x_21;
}
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_22 = lean_ctor_get(x_7, 0);
x_23 = lean_ctor_get(x_7, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_7);
x_24 = l_Lean_Meta_getLocalInstances___redArg(x_2, x_23);
x_25 = lean_ctor_get(x_24, 0);
lean_inc(x_25);
x_26 = lean_ctor_get(x_24, 1);
lean_inc(x_26);
if (lean_is_exclusive(x_24)) {
 lean_ctor_release(x_24, 0);
 lean_ctor_release(x_24, 1);
 x_27 = x_24;
} else {
 lean_dec_ref(x_24);
 x_27 = lean_box(0);
}
x_28 = lean_ctor_get(x_2, 2);
x_29 = lean_box(0);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_22);
lean_ctor_set(x_30, 1, x_29);
lean_inc_ref(x_28);
x_31 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set(x_31, 1, x_28);
lean_ctor_set(x_31, 2, x_25);
lean_ctor_set(x_31, 3, x_1);
if (lean_is_scalar(x_27)) {
 x_32 = lean_alloc_ctor(0, 2, 0);
} else {
 x_32 = x_27;
}
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_26);
return x_32;
}
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Elab_CommandContextInfo_saveNoFileMap___at___Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0_spec__0(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Elab_CommandContextInfo_save___at___ProofWidgets_ExprWithCtx_save_spec__0(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_2);
lean_dec_ref(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ExprWithCtx_save___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_ProofWidgets_ExprWithCtx_save(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_7;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_InfoTree_Main(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_InfoTree_Main(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_ = _init_l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_();
lean_mark_persistent(l_ProofWidgets_instImpl___closed__0____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_);
l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_ = _init_l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_();
lean_mark_persistent(l_ProofWidgets_instImpl___closed__1____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_);
l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_ = _init_l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_();
lean_mark_persistent(l_ProofWidgets_instImpl___closed__2____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_);
l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_ = _init_l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_();
lean_mark_persistent(l_ProofWidgets_instImpl____x40_ProofWidgets_Compat_3245877353____hygCtx___hyg_39_);
l_ProofWidgets_instTypeNameExprWithCtx = _init_l_ProofWidgets_instTypeNameExprWithCtx();
lean_mark_persistent(l_ProofWidgets_instTypeNameExprWithCtx);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__0);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__1);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__2);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__3);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__4);
l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5 = _init_l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5();
lean_mark_persistent(l_ProofWidgets_ExprWithCtx_runMetaM___redArg___closed__5);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
