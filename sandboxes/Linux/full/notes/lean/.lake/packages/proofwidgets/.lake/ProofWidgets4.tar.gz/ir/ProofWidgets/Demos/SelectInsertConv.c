// Lean compiler output
// Module: ProofWidgets.Demos.SelectInsertConv
// Imports: Init Lean.Meta.ExprLens Batteries.Lean.Position ProofWidgets.Data.Html ProofWidgets.Component.OfRpcMethod ProofWidgets.Component.MakeEditLink ProofWidgets.Component.Panel.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__6;
static lean_object* l_tacticConv_x3f___closed__3;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__17;
LEAN_EXPORT lean_object* l_insertEnter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_SubExpr_Pos_tail(lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
static lean_object* l_insertEnter___closed__5;
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__36;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__13;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_Tactic_Do_mkSpecContext_spec__0___redArg(lean_object*);
uint8_t l_Array_isEmpty___redArg(lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0;
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(lean_object*, lean_object*);
uint8_t l_Lean_Expr_isApp(lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__19;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(lean_object*);
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1__ctorIdx___boxed(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__15;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1;
static lean_object* l_tacticConv_x3f___closed__2;
static lean_object* l_insertEnter___closed__3;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__SolveReturn_ctorIdx(lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
uint8_t l_String_anyAux___at_____private_Lean_Meta_Hint_0__Lean_Meta_Hint_readableDiff_mkWhitespaceDiff_spec__0(uint32_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__35;
static lean_object* l_findGoalForLocation___closed__0;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__1;
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__1;
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0(lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__0;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
uint8_t l_List_isEmpty___redArg(lean_object*);
lean_object* l_Lean_stringToMessageData(lean_object*);
lean_object* l_Lean_SubExpr_instToJsonGoalsLocation_toJson(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__29;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__30;
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1__ctorIdx(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal_1490754142____hygCtx___hyg_1__spec__0(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_readDoc___at_____private_Lean_Meta_Tactic_TryThis_0__Lean_Meta_Tactic_TryThis_tryThisProvider_spec__0(lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0;
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__27;
lean_object* l_Lean_Json_opt___at___Lean_Widget_instToJsonRpcEncodablePacket_toJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_69__spec__0(lean_object*, lean_object*);
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__37;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__3;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__16;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__SolveReturn_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__26;
lean_object* l_Lean_FileMap_rangeOfStx_x3f(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__12;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_Pos_toArray(lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanelProps_ctorIdx(lean_object*);
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__24;
lean_object* lean_array_to_list(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__4;
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__1(lean_object*, lean_object*);
lean_object* l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__14;
lean_object* l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3;
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__0___closed__0;
lean_object* l_EStateM_instInhabited___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__23;
LEAN_EXPORT lean_object* l_ConvSelectionPanel;
static lean_object* l_insertEnter___closed__2;
uint8_t lean_name_eq(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel___closed__3;
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__21;
LEAN_EXPORT lean_object* l_ConvSelectionPanelProps_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_appFn_x21(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_tacticConv_x3f___closed__4;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__28;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped;
static lean_object* l_insertEnter___closed__6;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3;
static uint64_t l_ConvSelectionPanel___closed__1;
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps;
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(lean_object*, uint8_t);
extern lean_object* l_Lean_Server_instInhabitedRequestError_default;
lean_object* l_Lean_Meta_withLCtx___at___Lean_Meta_withErasedFVars___at_____private_Lean_Meta_Tactic_FunInd_0__Lean_Tactic_FunInd_deriveInductionStructural_doRealize_spec__36_spec__36___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_fromJson_x3f___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_dec____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__0(lean_object*);
lean_object* l_Lean_SubExpr_Pos_head(lean_object*);
lean_object* l_List_head_x21___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_insertEnter___closed__0;
uint8_t l_Lean_SubExpr_Pos_isRoot(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal_1490754142____hygCtx___hyg_1__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Lsp_instToJsonPosition_toJson(lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2;
lean_object* lean_array_fget(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_tacticConv_x3f___closed__1;
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__7;
lean_object* l_List_toString___at___Lean_SubExpr_Pos_fromString_x3f_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_insertEnter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_MVarId_getDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__33;
lean_object* l_Lean_Lsp_instFromJsonPosition_fromJson(lean_object*);
uint8_t l_Lean_BinderInfo_isExplicit(uint8_t);
lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_insertEnter___closed__1;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__32;
lean_object* lean_panic_fn(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4;
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_List_tail_x21___redArg(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_(lean_object*);
static lean_object* l_ConvSelectionPanel___closed__0;
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__0;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__10;
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__18;
lean_object* l_Lean_Lsp_instToJsonRange_toJson(lean_object*);
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_MakeEditLink;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__25;
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__9;
lean_object* l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Server_instToJsonCodeActionResolveData_toJson_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_tacticConv_x3f___closed__0;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel___closed__4;
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__20;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__5;
lean_object* l_ProofWidgets_instToJsonMakeEditLinkProps_toJson(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__31;
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__22;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__8;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__11;
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
LEAN_EXPORT lean_object* l_tacticConv_x3f;
lean_object* lean_infer_type(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__34;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
static lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0;
lean_object* l_Lean_LocalContext_sanitizeNames(lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68____boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_object* l_Lean_Json_pretty(lean_object*, lean_object*);
uint8_t l_Lean_Expr_bindingInfo_x21(lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(lean_object*, lean_object*);
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__2;
lean_object* l_Lean_Lsp_instFromJsonRange_fromJson(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2;
lean_object* l_Lean_Server_RequestError_invalidParams(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__2;
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at___insertEnter_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_insertEnter___closed__4;
static lean_object* l_ConvSelectionPanel___closed__2;
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__SolveReturn_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__SolveReturn_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Demos_SelectInsertConv_0__SolveReturn_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_9 = x_1;
} else {
 lean_dec_ref(x_1);
 x_9 = lean_box(0);
}
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_12 = x_7;
} else {
 lean_dec_ref(x_7);
 x_12 = lean_box(0);
}
x_13 = l_Lean_Expr_isApp(x_10);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
if (lean_is_scalar(x_12)) {
 x_14 = lean_alloc_ctor(0, 2, 0);
} else {
 x_14 = x_12;
}
lean_ctor_set(x_14, 0, x_10);
lean_ctor_set(x_14, 1, x_11);
if (lean_is_scalar(x_9)) {
 x_15 = lean_alloc_ctor(0, 2, 0);
} else {
 x_15 = x_9;
}
lean_ctor_set(x_15, 0, x_8);
lean_ctor_set(x_15, 1, x_14);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_6);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = l_Lean_Expr_appFn_x21(x_10);
lean_inc(x_5);
lean_inc_ref(x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
x_18 = lean_infer_type(x_17, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_29; uint8_t x_30; 
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec_ref(x_18);
x_29 = l_Lean_Expr_bindingInfo_x21(x_19);
lean_dec(x_19);
x_30 = l_Lean_BinderInfo_isExplicit(x_29);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_box(x_30);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_11);
x_21 = x_8;
x_22 = x_10;
x_23 = x_32;
goto block_28;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_33 = lean_box(x_30);
x_34 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_11);
x_35 = lean_unsigned_to_nat(1u);
x_36 = lean_nat_add(x_8, x_35);
lean_dec(x_8);
x_21 = x_36;
x_22 = x_10;
x_23 = x_34;
goto block_28;
}
block_28:
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = l_Lean_Expr_appFn_x21(x_22);
lean_dec_ref(x_22);
if (lean_is_scalar(x_12)) {
 x_25 = lean_alloc_ctor(0, 2, 0);
} else {
 x_25 = x_12;
}
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_23);
if (lean_is_scalar(x_9)) {
 x_26 = lean_alloc_ctor(0, 2, 0);
} else {
 x_26 = x_9;
}
lean_ctor_set(x_26, 0, x_21);
lean_ctor_set(x_26, 1, x_25);
x_1 = x_26;
x_6 = x_20;
goto _start;
}
}
else
{
uint8_t x_37; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_37 = !lean_is_exclusive(x_18);
if (x_37 == 0)
{
return x_18;
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_38 = lean_ctor_get(x_18, 0);
x_39 = lean_ctor_get(x_18, 1);
lean_inc(x_39);
lean_inc(x_38);
lean_dec(x_18);
x_40 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
return x_40;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_25; 
x_15 = lean_ctor_get(x_3, 1);
lean_inc(x_15);
x_16 = lean_ctor_get(x_3, 0);
lean_inc(x_16);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 x_17 = x_3;
} else {
 lean_dec_ref(x_3);
 x_17 = lean_box(0);
}
x_18 = lean_ctor_get(x_15, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_15, 1);
lean_inc(x_19);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 lean_ctor_release(x_15, 1);
 x_20 = x_15;
} else {
 lean_dec_ref(x_15);
 x_20 = lean_box(0);
}
x_25 = l_List_isEmpty___redArg(x_19);
if (x_25 == 0)
{
lean_object* x_26; uint8_t x_27; 
lean_inc(x_1);
x_26 = l_List_head_x21___redArg(x_1, x_19);
x_27 = lean_nat_dec_eq(x_26, x_2);
lean_dec(x_26);
if (x_27 == 0)
{
lean_dec(x_1);
goto block_24;
}
else
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
lean_dec(x_20);
lean_dec(x_17);
x_28 = lean_box(x_25);
x_29 = l_List_head_x21___redArg(x_28, x_18);
x_30 = lean_unbox(x_29);
if (x_30 == 0)
{
x_5 = x_16;
x_6 = x_18;
x_7 = x_19;
x_8 = x_4;
goto block_14;
}
else
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_unsigned_to_nat(1u);
x_32 = lean_nat_sub(x_16, x_31);
lean_dec(x_16);
x_5 = x_32;
x_6 = x_18;
x_7 = x_19;
x_8 = x_4;
goto block_14;
}
}
}
else
{
lean_dec(x_1);
goto block_24;
}
block_14:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = l_List_tail_x21___redArg(x_6);
lean_dec(x_6);
x_10 = l_List_tail_x21___redArg(x_7);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_5);
lean_ctor_set(x_12, 1, x_11);
x_3 = x_12;
x_4 = x_8;
goto _start;
}
block_24:
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
if (lean_is_scalar(x_20)) {
 x_21 = lean_alloc_ctor(0, 2, 0);
} else {
 x_21 = x_20;
}
lean_ctor_set(x_21, 0, x_18);
lean_ctor_set(x_21, 1, x_19);
if (lean_is_scalar(x_17)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_17;
}
lean_ctor_set(x_22, 0, x_16);
lean_ctor_set(x_22, 1, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_4);
return x_23;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_1, x_2, x_3, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_2);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_5 = lean_ctor_get(x_2, 0);
x_6 = lean_ctor_get(x_2, 1);
x_7 = lean_nat_dec_lt(x_1, x_5);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_2);
lean_ctor_set(x_8, 1, x_3);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = l_Lean_Expr_appFn_x21(x_6);
lean_dec(x_6);
x_10 = lean_unsigned_to_nat(1u);
x_11 = lean_nat_sub(x_5, x_10);
lean_dec(x_5);
lean_ctor_set(x_2, 1, x_9);
lean_ctor_set(x_2, 0, x_11);
goto _start;
}
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_2, 0);
x_14 = lean_ctor_get(x_2, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_2);
x_15 = lean_nat_dec_lt(x_1, x_13);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_13);
lean_ctor_set(x_16, 1, x_14);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_3);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_18 = l_Lean_Expr_appFn_x21(x_14);
lean_dec(x_14);
x_19 = lean_unsigned_to_nat(1u);
x_20 = lean_nat_sub(x_13, x_19);
lean_dec(x_13);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_18);
x_2 = x_21;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_1, x_2, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; 
x_2 = lean_box(0);
x_3 = lean_panic_fn(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Bad coordinate ", 15, 15);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" for ", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Can't viewRaw the type of ", 26, 26);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_21; 
switch (lean_obj_tag(x_1)) {
case 5:
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_27 = lean_ctor_get(x_1, 0);
x_28 = lean_ctor_get(x_1, 1);
x_29 = lean_unsigned_to_nat(3u);
x_30 = lean_nat_dec_eq(x_2, x_29);
if (x_30 == 0)
{
lean_object* x_31; uint8_t x_32; 
x_31 = lean_unsigned_to_nat(0u);
x_32 = lean_nat_dec_eq(x_2, x_31);
if (x_32 == 0)
{
lean_object* x_33; uint8_t x_34; 
x_33 = lean_unsigned_to_nat(1u);
x_34 = lean_nat_dec_eq(x_2, x_33);
if (x_34 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_object* x_35; 
lean_inc_ref(x_28);
lean_dec(x_2);
lean_dec_ref(x_1);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_28);
lean_ctor_set(x_35, 1, x_7);
return x_35;
}
}
else
{
lean_object* x_36; 
lean_inc_ref(x_27);
lean_dec(x_2);
lean_dec_ref(x_1);
x_36 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_36, 0, x_27);
lean_ctor_set(x_36, 1, x_7);
return x_36;
}
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
case 6:
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; 
x_37 = lean_ctor_get(x_1, 1);
x_38 = lean_ctor_get(x_1, 2);
x_39 = lean_unsigned_to_nat(3u);
x_40 = lean_nat_dec_eq(x_2, x_39);
if (x_40 == 0)
{
lean_object* x_41; uint8_t x_42; 
x_41 = lean_unsigned_to_nat(0u);
x_42 = lean_nat_dec_eq(x_2, x_41);
if (x_42 == 0)
{
lean_object* x_43; uint8_t x_44; 
x_43 = lean_unsigned_to_nat(1u);
x_44 = lean_nat_dec_eq(x_2, x_43);
if (x_44 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_object* x_45; 
lean_inc_ref(x_38);
lean_dec(x_2);
lean_dec_ref(x_1);
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_38);
lean_ctor_set(x_45, 1, x_7);
return x_45;
}
}
else
{
lean_object* x_46; 
lean_inc_ref(x_37);
lean_dec(x_2);
lean_dec_ref(x_1);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_37);
lean_ctor_set(x_46, 1, x_7);
return x_46;
}
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
case 7:
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; uint8_t x_50; 
x_47 = lean_ctor_get(x_1, 1);
x_48 = lean_ctor_get(x_1, 2);
x_49 = lean_unsigned_to_nat(3u);
x_50 = lean_nat_dec_eq(x_2, x_49);
if (x_50 == 0)
{
lean_object* x_51; uint8_t x_52; 
x_51 = lean_unsigned_to_nat(0u);
x_52 = lean_nat_dec_eq(x_2, x_51);
if (x_52 == 0)
{
lean_object* x_53; uint8_t x_54; 
x_53 = lean_unsigned_to_nat(1u);
x_54 = lean_nat_dec_eq(x_2, x_53);
if (x_54 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_object* x_55; 
lean_inc_ref(x_48);
lean_dec(x_2);
lean_dec_ref(x_1);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_48);
lean_ctor_set(x_55, 1, x_7);
return x_55;
}
}
else
{
lean_object* x_56; 
lean_inc_ref(x_47);
lean_dec(x_2);
lean_dec_ref(x_1);
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_47);
lean_ctor_set(x_56, 1, x_7);
return x_56;
}
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
case 8:
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; uint8_t x_61; 
x_57 = lean_ctor_get(x_1, 1);
x_58 = lean_ctor_get(x_1, 2);
x_59 = lean_ctor_get(x_1, 3);
x_60 = lean_unsigned_to_nat(3u);
x_61 = lean_nat_dec_eq(x_2, x_60);
if (x_61 == 0)
{
lean_object* x_62; uint8_t x_63; 
x_62 = lean_unsigned_to_nat(0u);
x_63 = lean_nat_dec_eq(x_2, x_62);
if (x_63 == 0)
{
lean_object* x_64; uint8_t x_65; 
x_64 = lean_unsigned_to_nat(1u);
x_65 = lean_nat_dec_eq(x_2, x_64);
if (x_65 == 0)
{
lean_object* x_66; uint8_t x_67; 
x_66 = lean_unsigned_to_nat(2u);
x_67 = lean_nat_dec_eq(x_2, x_66);
if (x_67 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_object* x_68; 
lean_inc_ref(x_59);
lean_dec(x_2);
lean_dec_ref(x_1);
x_68 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_68, 0, x_59);
lean_ctor_set(x_68, 1, x_7);
return x_68;
}
}
else
{
lean_object* x_69; 
lean_inc_ref(x_58);
lean_dec(x_2);
lean_dec_ref(x_1);
x_69 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_69, 0, x_58);
lean_ctor_set(x_69, 1, x_7);
return x_69;
}
}
else
{
lean_object* x_70; 
lean_inc_ref(x_57);
lean_dec(x_2);
lean_dec_ref(x_1);
x_70 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_70, 0, x_57);
lean_ctor_set(x_70, 1, x_7);
return x_70;
}
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
case 10:
{
lean_object* x_71; lean_object* x_72; uint8_t x_73; 
x_71 = lean_ctor_get(x_1, 1);
x_72 = lean_unsigned_to_nat(3u);
x_73 = lean_nat_dec_eq(x_2, x_72);
if (x_73 == 0)
{
lean_inc_ref(x_71);
lean_dec_ref(x_1);
x_1 = x_71;
goto _start;
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
case 11:
{
lean_object* x_75; lean_object* x_76; uint8_t x_77; 
x_75 = lean_ctor_get(x_1, 2);
x_76 = lean_unsigned_to_nat(3u);
x_77 = lean_nat_dec_eq(x_2, x_76);
if (x_77 == 0)
{
lean_object* x_78; uint8_t x_79; 
x_78 = lean_unsigned_to_nat(0u);
x_79 = lean_nat_dec_eq(x_2, x_78);
if (x_79 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_object* x_80; 
lean_inc_ref(x_75);
lean_dec(x_2);
lean_dec_ref(x_1);
x_80 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_80, 0, x_75);
lean_ctor_set(x_80, 1, x_7);
return x_80;
}
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
default: 
{
lean_object* x_81; uint8_t x_82; 
x_81 = lean_unsigned_to_nat(3u);
x_82 = lean_nat_dec_eq(x_2, x_81);
if (x_82 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_20;
}
else
{
lean_dec(x_2);
x_21 = x_1;
goto block_26;
}
}
}
block_20:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_10 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1;
x_11 = l_Nat_reprFast(x_9);
x_12 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Lean_MessageData_ofFormat(x_12);
x_14 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_14, 0, x_10);
lean_ctor_set(x_14, 1, x_13);
x_15 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3;
x_16 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Lean_MessageData_ofExpr(x_8);
x_18 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
x_19 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_18, x_3, x_4, x_5, x_6, x_7);
return x_19;
}
block_26:
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_22 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5;
x_23 = l_Lean_MessageData_ofExpr(x_21);
x_24 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_24, 0, x_22);
lean_ctor_set(x_24, 1, x_23);
x_25 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_24, x_3, x_4, x_5, x_6, x_7);
return x_25;
}
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint8_t x_9; 
x_9 = l_Lean_SubExpr_Pos_isRoot(x_3);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = l_Lean_SubExpr_Pos_tail(x_3);
lean_inc(x_7);
lean_inc_ref(x_6);
lean_inc(x_5);
lean_inc_ref(x_4);
lean_inc_ref(x_1);
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_1, x_2, x_10, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_10);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_11, 1);
lean_inc(x_13);
lean_dec_ref(x_11);
x_14 = l_Lean_SubExpr_Pos_head(x_3);
x_15 = lean_apply_7(x_1, x_12, x_14, x_4, x_5, x_6, x_7, x_13);
return x_15;
}
else
{
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec_ref(x_1);
return x_11;
}
}
else
{
lean_object* x_16; 
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec_ref(x_1);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_2);
lean_ctor_set(x_16, 1, x_8);
return x_16;
}
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_alloc_closure((void*)(l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed), 7, 0);
x_9 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_8, x_2, x_1, x_3, x_4, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets.Demos.SelectInsertConv", 35, 35);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_private.ProofWidgets.Demos.SelectInsertConv.0.solveLevel", 57, 57);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no name found", 13, 13);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
x_2 = lean_unsigned_to_nat(13u);
x_3 = lean_unsigned_to_nat(67u);
x_4 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
x_2 = lean_unsigned_to_nat(13u);
x_3 = lean_unsigned_to_nat(73u);
x_4 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = lean_unsigned_to_nat(0u);
switch (lean_obj_tag(x_1)) {
case 5:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = lean_box(0);
lean_inc_ref(x_1);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_1);
lean_ctor_set(x_10, 1, x_9);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_8);
lean_ctor_set(x_11, 1, x_10);
x_12 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(x_11, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_12) == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_13, 1);
lean_inc(x_14);
x_15 = lean_ctor_get(x_12, 1);
lean_inc(x_15);
lean_dec_ref(x_12);
x_16 = !lean_is_exclusive(x_13);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_ctor_get(x_13, 0);
x_18 = lean_ctor_get(x_13, 1);
lean_dec(x_18);
x_19 = !lean_is_exclusive(x_14);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_20 = lean_ctor_get(x_14, 1);
x_21 = lean_ctor_get(x_14, 0);
lean_dec(x_21);
x_22 = l_List_reverse___redArg(x_20);
lean_ctor_set(x_14, 1, x_2);
lean_ctor_set(x_14, 0, x_22);
lean_inc(x_17);
x_23 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_8, x_13, x_15);
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
x_25 = lean_ctor_get(x_24, 1);
lean_inc(x_25);
x_26 = lean_ctor_get(x_23, 1);
lean_inc(x_26);
lean_dec_ref(x_23);
x_27 = lean_ctor_get(x_24, 0);
lean_inc(x_27);
lean_dec(x_24);
x_28 = !lean_is_exclusive(x_25);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; uint8_t x_43; 
x_29 = lean_ctor_get(x_25, 1);
x_30 = lean_ctor_get(x_25, 0);
lean_dec(x_30);
lean_ctor_set(x_25, 1, x_1);
lean_ctor_set(x_25, 0, x_17);
x_31 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_27, x_25, x_26);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
if (lean_is_exclusive(x_31)) {
 lean_ctor_release(x_31, 0);
 lean_ctor_release(x_31, 1);
 x_34 = x_31;
} else {
 lean_dec_ref(x_31);
 x_34 = lean_box(0);
}
x_35 = lean_ctor_get(x_32, 1);
lean_inc(x_35);
lean_dec(x_32);
x_36 = l_Lean_Expr_appArg_x21(x_35);
lean_dec(x_35);
x_43 = l_List_isEmpty___redArg(x_29);
if (x_43 == 0)
{
lean_object* x_44; 
x_44 = l_List_tail_x21___redArg(x_29);
lean_dec(x_29);
x_37 = x_44;
goto block_42;
}
else
{
lean_dec(x_29);
x_37 = x_9;
goto block_42;
}
block_42:
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = l_Nat_reprFast(x_27);
x_39 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_39, 0, x_38);
x_40 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_40, 0, x_36);
lean_ctor_set(x_40, 1, x_39);
lean_ctor_set(x_40, 2, x_37);
if (lean_is_scalar(x_34)) {
 x_41 = lean_alloc_ctor(0, 2, 0);
} else {
 x_41 = x_34;
}
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_41, 1, x_33);
return x_41;
}
}
else
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_59; 
x_45 = lean_ctor_get(x_25, 1);
lean_inc(x_45);
lean_dec(x_25);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_17);
lean_ctor_set(x_46, 1, x_1);
x_47 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_27, x_46, x_26);
x_48 = lean_ctor_get(x_47, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_47, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_47)) {
 lean_ctor_release(x_47, 0);
 lean_ctor_release(x_47, 1);
 x_50 = x_47;
} else {
 lean_dec_ref(x_47);
 x_50 = lean_box(0);
}
x_51 = lean_ctor_get(x_48, 1);
lean_inc(x_51);
lean_dec(x_48);
x_52 = l_Lean_Expr_appArg_x21(x_51);
lean_dec(x_51);
x_59 = l_List_isEmpty___redArg(x_45);
if (x_59 == 0)
{
lean_object* x_60; 
x_60 = l_List_tail_x21___redArg(x_45);
lean_dec(x_45);
x_53 = x_60;
goto block_58;
}
else
{
lean_dec(x_45);
x_53 = x_9;
goto block_58;
}
block_58:
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_54 = l_Nat_reprFast(x_27);
x_55 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_55, 0, x_54);
x_56 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_56, 0, x_52);
lean_ctor_set(x_56, 1, x_55);
lean_ctor_set(x_56, 2, x_53);
if (lean_is_scalar(x_50)) {
 x_57 = lean_alloc_ctor(0, 2, 0);
} else {
 x_57 = x_50;
}
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_49);
return x_57;
}
}
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; uint8_t x_84; 
x_61 = lean_ctor_get(x_14, 1);
lean_inc(x_61);
lean_dec(x_14);
x_62 = l_List_reverse___redArg(x_61);
x_63 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_63, 0, x_62);
lean_ctor_set(x_63, 1, x_2);
lean_inc(x_17);
lean_ctor_set(x_13, 1, x_63);
x_64 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_8, x_13, x_15);
x_65 = lean_ctor_get(x_64, 0);
lean_inc(x_65);
x_66 = lean_ctor_get(x_65, 1);
lean_inc(x_66);
x_67 = lean_ctor_get(x_64, 1);
lean_inc(x_67);
lean_dec_ref(x_64);
x_68 = lean_ctor_get(x_65, 0);
lean_inc(x_68);
lean_dec(x_65);
x_69 = lean_ctor_get(x_66, 1);
lean_inc(x_69);
if (lean_is_exclusive(x_66)) {
 lean_ctor_release(x_66, 0);
 lean_ctor_release(x_66, 1);
 x_70 = x_66;
} else {
 lean_dec_ref(x_66);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(0, 2, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_17);
lean_ctor_set(x_71, 1, x_1);
x_72 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_68, x_71, x_67);
x_73 = lean_ctor_get(x_72, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_72, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_72)) {
 lean_ctor_release(x_72, 0);
 lean_ctor_release(x_72, 1);
 x_75 = x_72;
} else {
 lean_dec_ref(x_72);
 x_75 = lean_box(0);
}
x_76 = lean_ctor_get(x_73, 1);
lean_inc(x_76);
lean_dec(x_73);
x_77 = l_Lean_Expr_appArg_x21(x_76);
lean_dec(x_76);
x_84 = l_List_isEmpty___redArg(x_69);
if (x_84 == 0)
{
lean_object* x_85; 
x_85 = l_List_tail_x21___redArg(x_69);
lean_dec(x_69);
x_78 = x_85;
goto block_83;
}
else
{
lean_dec(x_69);
x_78 = x_9;
goto block_83;
}
block_83:
{
lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; 
x_79 = l_Nat_reprFast(x_68);
x_80 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_80, 0, x_79);
x_81 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_81, 0, x_77);
lean_ctor_set(x_81, 1, x_80);
lean_ctor_set(x_81, 2, x_78);
if (lean_is_scalar(x_75)) {
 x_82 = lean_alloc_ctor(0, 2, 0);
} else {
 x_82 = x_75;
}
lean_ctor_set(x_82, 0, x_81);
lean_ctor_set(x_82, 1, x_74);
return x_82;
}
}
}
else
{
lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; uint8_t x_112; 
x_86 = lean_ctor_get(x_13, 0);
lean_inc(x_86);
lean_dec(x_13);
x_87 = lean_ctor_get(x_14, 1);
lean_inc(x_87);
if (lean_is_exclusive(x_14)) {
 lean_ctor_release(x_14, 0);
 lean_ctor_release(x_14, 1);
 x_88 = x_14;
} else {
 lean_dec_ref(x_14);
 x_88 = lean_box(0);
}
x_89 = l_List_reverse___redArg(x_87);
if (lean_is_scalar(x_88)) {
 x_90 = lean_alloc_ctor(0, 2, 0);
} else {
 x_90 = x_88;
}
lean_ctor_set(x_90, 0, x_89);
lean_ctor_set(x_90, 1, x_2);
lean_inc(x_86);
x_91 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_91, 0, x_86);
lean_ctor_set(x_91, 1, x_90);
x_92 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_8, x_91, x_15);
x_93 = lean_ctor_get(x_92, 0);
lean_inc(x_93);
x_94 = lean_ctor_get(x_93, 1);
lean_inc(x_94);
x_95 = lean_ctor_get(x_92, 1);
lean_inc(x_95);
lean_dec_ref(x_92);
x_96 = lean_ctor_get(x_93, 0);
lean_inc(x_96);
lean_dec(x_93);
x_97 = lean_ctor_get(x_94, 1);
lean_inc(x_97);
if (lean_is_exclusive(x_94)) {
 lean_ctor_release(x_94, 0);
 lean_ctor_release(x_94, 1);
 x_98 = x_94;
} else {
 lean_dec_ref(x_94);
 x_98 = lean_box(0);
}
if (lean_is_scalar(x_98)) {
 x_99 = lean_alloc_ctor(0, 2, 0);
} else {
 x_99 = x_98;
}
lean_ctor_set(x_99, 0, x_86);
lean_ctor_set(x_99, 1, x_1);
x_100 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_96, x_99, x_95);
x_101 = lean_ctor_get(x_100, 0);
lean_inc(x_101);
x_102 = lean_ctor_get(x_100, 1);
lean_inc(x_102);
if (lean_is_exclusive(x_100)) {
 lean_ctor_release(x_100, 0);
 lean_ctor_release(x_100, 1);
 x_103 = x_100;
} else {
 lean_dec_ref(x_100);
 x_103 = lean_box(0);
}
x_104 = lean_ctor_get(x_101, 1);
lean_inc(x_104);
lean_dec(x_101);
x_105 = l_Lean_Expr_appArg_x21(x_104);
lean_dec(x_104);
x_112 = l_List_isEmpty___redArg(x_97);
if (x_112 == 0)
{
lean_object* x_113; 
x_113 = l_List_tail_x21___redArg(x_97);
lean_dec(x_97);
x_106 = x_113;
goto block_111;
}
else
{
lean_dec(x_97);
x_106 = x_9;
goto block_111;
}
block_111:
{
lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; 
x_107 = l_Nat_reprFast(x_96);
x_108 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_108, 0, x_107);
x_109 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_109, 0, x_105);
lean_ctor_set(x_109, 1, x_108);
lean_ctor_set(x_109, 2, x_106);
if (lean_is_scalar(x_103)) {
 x_110 = lean_alloc_ctor(0, 2, 0);
} else {
 x_110 = x_103;
}
lean_ctor_set(x_110, 0, x_109);
lean_ctor_set(x_110, 1, x_102);
return x_110;
}
}
}
else
{
uint8_t x_114; 
lean_dec(x_2);
lean_dec_ref(x_1);
x_114 = !lean_is_exclusive(x_12);
if (x_114 == 0)
{
return x_12;
}
else
{
lean_object* x_115; lean_object* x_116; lean_object* x_117; 
x_115 = lean_ctor_get(x_12, 0);
x_116 = lean_ctor_get(x_12, 1);
lean_inc(x_116);
lean_inc(x_115);
lean_dec(x_12);
x_117 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_117, 0, x_115);
lean_ctor_set(x_117, 1, x_116);
return x_117;
}
}
}
case 6:
{
lean_object* x_118; lean_object* x_119; lean_object* x_120; 
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
x_118 = lean_ctor_get(x_1, 0);
lean_inc(x_118);
x_119 = lean_ctor_get(x_1, 2);
lean_inc_ref(x_119);
lean_dec_ref(x_1);
if (lean_obj_tag(x_118) == 1)
{
lean_object* x_125; lean_object* x_126; 
x_125 = lean_ctor_get(x_118, 1);
lean_inc_ref(x_125);
lean_dec_ref(x_118);
x_126 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_126, 0, x_125);
x_120 = x_126;
goto block_124;
}
else
{
lean_object* x_127; lean_object* x_128; 
lean_dec(x_118);
x_127 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3;
x_128 = l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(x_127);
x_120 = x_128;
goto block_124;
}
block_124:
{
lean_object* x_121; lean_object* x_122; lean_object* x_123; 
x_121 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_122 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_122, 0, x_119);
lean_ctor_set(x_122, 1, x_120);
lean_ctor_set(x_122, 2, x_121);
x_123 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_123, 0, x_122);
lean_ctor_set(x_123, 1, x_7);
return x_123;
}
}
case 7:
{
lean_object* x_129; lean_object* x_130; lean_object* x_131; 
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
x_129 = lean_ctor_get(x_1, 0);
lean_inc(x_129);
x_130 = lean_ctor_get(x_1, 2);
lean_inc_ref(x_130);
lean_dec_ref(x_1);
if (lean_obj_tag(x_129) == 1)
{
lean_object* x_136; lean_object* x_137; 
x_136 = lean_ctor_get(x_129, 1);
lean_inc_ref(x_136);
lean_dec_ref(x_129);
x_137 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_137, 0, x_136);
x_131 = x_137;
goto block_135;
}
else
{
lean_object* x_138; lean_object* x_139; 
lean_dec(x_129);
x_138 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4;
x_139 = l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(x_138);
x_131 = x_139;
goto block_135;
}
block_135:
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; 
x_132 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_133 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_133, 0, x_130);
lean_ctor_set(x_133, 1, x_131);
lean_ctor_set(x_133, 2, x_132);
x_134 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_134, 0, x_133);
lean_ctor_set(x_134, 1, x_7);
return x_134;
}
}
case 10:
{
lean_object* x_140; 
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
x_140 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_140);
lean_dec_ref(x_1);
if (lean_obj_tag(x_140) == 10)
{
lean_object* x_141; lean_object* x_142; lean_object* x_143; 
x_141 = lean_box(0);
x_142 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_142, 0, x_140);
lean_ctor_set(x_142, 1, x_141);
lean_ctor_set(x_142, 2, x_2);
x_143 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_143, 0, x_142);
lean_ctor_set(x_143, 1, x_7);
return x_143;
}
else
{
lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; 
x_144 = l_Lean_Expr_appFn_x21(x_140);
lean_dec_ref(x_140);
x_145 = l_Lean_Expr_appArg_x21(x_144);
lean_dec_ref(x_144);
x_146 = lean_box(0);
x_147 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_148 = l_List_tail_x21___redArg(x_147);
lean_dec(x_147);
x_149 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_149, 0, x_145);
lean_ctor_set(x_149, 1, x_146);
lean_ctor_set(x_149, 2, x_148);
x_150 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_150, 0, x_149);
lean_ctor_set(x_150, 1, x_7);
return x_150;
}
}
default: 
{
lean_object* x_151; lean_object* x_152; 
x_151 = l_List_head_x21___redArg(x_8, x_2);
x_152 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(x_151, x_1, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_152) == 0)
{
uint8_t x_153; 
x_153 = !lean_is_exclusive(x_152);
if (x_153 == 0)
{
lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; 
x_154 = lean_ctor_get(x_152, 0);
x_155 = lean_unsigned_to_nat(1u);
x_156 = lean_nat_add(x_151, x_155);
lean_dec(x_151);
x_157 = l_Nat_reprFast(x_156);
x_158 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_158, 0, x_157);
x_159 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_160 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_160, 0, x_154);
lean_ctor_set(x_160, 1, x_158);
lean_ctor_set(x_160, 2, x_159);
lean_ctor_set(x_152, 0, x_160);
return x_152;
}
else
{
lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; 
x_161 = lean_ctor_get(x_152, 0);
x_162 = lean_ctor_get(x_152, 1);
lean_inc(x_162);
lean_inc(x_161);
lean_dec(x_152);
x_163 = lean_unsigned_to_nat(1u);
x_164 = lean_nat_add(x_151, x_163);
lean_dec(x_151);
x_165 = l_Nat_reprFast(x_164);
x_166 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_166, 0, x_165);
x_167 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_168 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_168, 0, x_161);
lean_ctor_set(x_168, 1, x_166);
lean_ctor_set(x_168, 2, x_167);
x_169 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_169, 0, x_168);
lean_ctor_set(x_169, 1, x_162);
return x_169;
}
}
else
{
uint8_t x_170; 
lean_dec(x_151);
lean_dec(x_2);
x_170 = !lean_is_exclusive(x_152);
if (x_170 == 0)
{
return x_152;
}
else
{
lean_object* x_171; lean_object* x_172; lean_object* x_173; 
x_171 = lean_ctor_get(x_152, 0);
x_172 = lean_ctor_get(x_152, 1);
lean_inc(x_172);
lean_inc(x_171);
lean_dec(x_152);
x_173 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_173, 0, x_171);
lean_ctor_set(x_173, 1, x_172);
return x_173;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Init_While_0__Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_5);
lean_dec(x_2);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__Lean_Loop_forIn_loop___at___insertEnter_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_9 = x_1;
} else {
 lean_dec_ref(x_1);
 x_9 = lean_box(0);
}
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_12 = x_7;
} else {
 lean_dec_ref(x_7);
 x_12 = lean_box(0);
}
x_13 = l_List_isEmpty___redArg(x_10);
if (x_13 == 0)
{
lean_object* x_14; 
lean_inc(x_5);
lean_inc_ref(x_4);
lean_inc(x_3);
lean_inc_ref(x_2);
x_14 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(x_8, x_10, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_14, 1);
lean_inc(x_16);
lean_dec_ref(x_14);
x_17 = lean_ctor_get(x_15, 0);
lean_inc_ref(x_17);
x_18 = lean_ctor_get(x_15, 1);
lean_inc(x_18);
x_19 = lean_ctor_get(x_15, 2);
lean_inc(x_19);
lean_dec(x_15);
if (lean_obj_tag(x_18) == 0)
{
x_20 = x_11;
goto block_24;
}
else
{
lean_object* x_25; lean_object* x_26; 
x_25 = lean_ctor_get(x_18, 0);
lean_inc(x_25);
lean_dec_ref(x_18);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_11);
x_20 = x_26;
goto block_24;
}
block_24:
{
lean_object* x_21; lean_object* x_22; 
if (lean_is_scalar(x_12)) {
 x_21 = lean_alloc_ctor(0, 2, 0);
} else {
 x_21 = x_12;
}
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
if (lean_is_scalar(x_9)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_9;
}
lean_ctor_set(x_22, 0, x_17);
lean_ctor_set(x_22, 1, x_21);
x_1 = x_22;
x_6 = x_16;
goto _start;
}
}
else
{
uint8_t x_27; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_9);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
x_27 = !lean_is_exclusive(x_14);
if (x_27 == 0)
{
return x_14;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_14, 0);
x_29 = lean_ctor_get(x_14, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_14);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_28);
lean_ctor_set(x_30, 1, x_29);
return x_30;
}
}
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
if (lean_is_scalar(x_12)) {
 x_31 = lean_alloc_ctor(0, 2, 0);
} else {
 x_31 = x_12;
}
lean_ctor_set(x_31, 0, x_10);
lean_ctor_set(x_31, 1, x_11);
if (lean_is_scalar(x_9)) {
 x_32 = lean_alloc_ctor(0, 2, 0);
} else {
 x_32 = x_9;
}
lean_ctor_set(x_32, 0, x_8);
lean_ctor_set(x_32, 1, x_31);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_32);
lean_ctor_set(x_33, 1, x_6);
return x_33;
}
}
}
static lean_object* _init_l_insertEnter___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("You must select something.", 26, 26);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_insertEnter___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_insertEnter___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("conv => enter ", 14, 14);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Error: Not a valid conv target", 30, 30);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("You must select something in the goal.", 38, 38);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_insertEnter___closed__5;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_insertEnter(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_get_size(x_1);
x_10 = lean_nat_dec_lt(x_8, x_9);
lean_dec(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec_ref(x_2);
x_11 = l_insertEnter___closed__1;
x_12 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_11, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
return x_12;
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_array_fget(x_1, x_8);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 1);
x_16 = lean_ctor_get(x_13, 0);
lean_dec(x_16);
if (lean_obj_tag(x_15) == 3)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec_ref(x_15);
x_18 = l_Lean_SubExpr_Pos_toArray(x_17);
lean_dec(x_17);
x_19 = lean_array_to_list(x_18);
x_20 = lean_box(0);
lean_ctor_set(x_13, 1, x_20);
lean_ctor_set(x_13, 0, x_19);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_2);
lean_ctor_set(x_21, 1, x_13);
x_22 = l___private_Init_While_0__Lean_Loop_forIn_loop___at___insertEnter_spec__0(x_21, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_22) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_36; lean_object* x_37; lean_object* x_38; uint32_t x_39; lean_object* x_40; uint8_t x_41; 
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_23, 1);
lean_inc(x_24);
lean_dec(x_23);
x_25 = lean_ctor_get(x_22, 1);
lean_inc(x_25);
if (lean_is_exclusive(x_22)) {
 lean_ctor_release(x_22, 0);
 lean_ctor_release(x_22, 1);
 x_26 = x_22;
} else {
 lean_dec_ref(x_22);
 x_26 = lean_box(0);
}
x_27 = lean_ctor_get(x_24, 1);
lean_inc(x_27);
lean_dec(x_24);
x_28 = l_List_reverse___redArg(x_27);
x_36 = l_insertEnter___closed__3;
x_37 = l_List_toString___at___Lean_SubExpr_Pos_fromString_x3f_spec__0(x_28);
x_38 = lean_string_append(x_36, x_37);
lean_dec_ref(x_37);
x_39 = 48;
x_40 = lean_string_utf8_byte_size(x_38);
x_41 = l_String_anyAux___at_____private_Lean_Meta_Hint_0__Lean_Meta_Hint_readableDiff_mkWhitespaceDiff_spec__0(x_39, x_38, x_40, x_8);
lean_dec(x_40);
if (x_41 == 0)
{
x_29 = x_38;
x_30 = x_25;
goto block_35;
}
else
{
lean_object* x_42; 
lean_dec_ref(x_38);
x_42 = l_insertEnter___closed__4;
x_29 = x_42;
x_30 = x_25;
goto block_35;
}
block_35:
{
uint8_t x_31; 
x_31 = l_List_isEmpty___redArg(x_28);
lean_dec(x_28);
if (x_31 == 0)
{
lean_object* x_32; 
if (lean_is_scalar(x_26)) {
 x_32 = lean_alloc_ctor(0, 2, 0);
} else {
 x_32 = x_26;
}
lean_ctor_set(x_32, 0, x_29);
lean_ctor_set(x_32, 1, x_30);
return x_32;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_dec_ref(x_29);
x_33 = l_insertEnter___closed__2;
if (lean_is_scalar(x_26)) {
 x_34 = lean_alloc_ctor(0, 2, 0);
} else {
 x_34 = x_26;
}
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_30);
return x_34;
}
}
}
else
{
uint8_t x_43; 
x_43 = !lean_is_exclusive(x_22);
if (x_43 == 0)
{
return x_22;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_ctor_get(x_22, 0);
x_45 = lean_ctor_get(x_22, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_22);
x_46 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_46, 0, x_44);
lean_ctor_set(x_46, 1, x_45);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; 
lean_free_object(x_13);
lean_dec_ref(x_15);
lean_dec_ref(x_2);
x_47 = l_insertEnter___closed__6;
x_48 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_47, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
return x_48;
}
}
else
{
lean_object* x_49; 
x_49 = lean_ctor_get(x_13, 1);
lean_inc(x_49);
lean_dec(x_13);
if (lean_obj_tag(x_49) == 3)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec_ref(x_49);
x_51 = l_Lean_SubExpr_Pos_toArray(x_50);
lean_dec(x_50);
x_52 = lean_array_to_list(x_51);
x_53 = lean_box(0);
x_54 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_54, 0, x_52);
lean_ctor_set(x_54, 1, x_53);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_2);
lean_ctor_set(x_55, 1, x_54);
x_56 = l___private_Init_While_0__Lean_Loop_forIn_loop___at___insertEnter_spec__0(x_55, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_56) == 0)
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_70; lean_object* x_71; lean_object* x_72; uint32_t x_73; lean_object* x_74; uint8_t x_75; 
x_57 = lean_ctor_get(x_56, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_57, 1);
lean_inc(x_58);
lean_dec(x_57);
x_59 = lean_ctor_get(x_56, 1);
lean_inc(x_59);
if (lean_is_exclusive(x_56)) {
 lean_ctor_release(x_56, 0);
 lean_ctor_release(x_56, 1);
 x_60 = x_56;
} else {
 lean_dec_ref(x_56);
 x_60 = lean_box(0);
}
x_61 = lean_ctor_get(x_58, 1);
lean_inc(x_61);
lean_dec(x_58);
x_62 = l_List_reverse___redArg(x_61);
x_70 = l_insertEnter___closed__3;
x_71 = l_List_toString___at___Lean_SubExpr_Pos_fromString_x3f_spec__0(x_62);
x_72 = lean_string_append(x_70, x_71);
lean_dec_ref(x_71);
x_73 = 48;
x_74 = lean_string_utf8_byte_size(x_72);
x_75 = l_String_anyAux___at_____private_Lean_Meta_Hint_0__Lean_Meta_Hint_readableDiff_mkWhitespaceDiff_spec__0(x_73, x_72, x_74, x_8);
lean_dec(x_74);
if (x_75 == 0)
{
x_63 = x_72;
x_64 = x_59;
goto block_69;
}
else
{
lean_object* x_76; 
lean_dec_ref(x_72);
x_76 = l_insertEnter___closed__4;
x_63 = x_76;
x_64 = x_59;
goto block_69;
}
block_69:
{
uint8_t x_65; 
x_65 = l_List_isEmpty___redArg(x_62);
lean_dec(x_62);
if (x_65 == 0)
{
lean_object* x_66; 
if (lean_is_scalar(x_60)) {
 x_66 = lean_alloc_ctor(0, 2, 0);
} else {
 x_66 = x_60;
}
lean_ctor_set(x_66, 0, x_63);
lean_ctor_set(x_66, 1, x_64);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec_ref(x_63);
x_67 = l_insertEnter___closed__2;
if (lean_is_scalar(x_60)) {
 x_68 = lean_alloc_ctor(0, 2, 0);
} else {
 x_68 = x_60;
}
lean_ctor_set(x_68, 0, x_67);
lean_ctor_set(x_68, 1, x_64);
return x_68;
}
}
}
else
{
lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
x_77 = lean_ctor_get(x_56, 0);
lean_inc(x_77);
x_78 = lean_ctor_get(x_56, 1);
lean_inc(x_78);
if (lean_is_exclusive(x_56)) {
 lean_ctor_release(x_56, 0);
 lean_ctor_release(x_56, 1);
 x_79 = x_56;
} else {
 lean_dec_ref(x_56);
 x_79 = lean_box(0);
}
if (lean_is_scalar(x_79)) {
 x_80 = lean_alloc_ctor(1, 2, 0);
} else {
 x_80 = x_79;
}
lean_ctor_set(x_80, 0, x_77);
lean_ctor_set(x_80, 1, x_78);
return x_80;
}
}
else
{
lean_object* x_81; lean_object* x_82; 
lean_dec_ref(x_49);
lean_dec_ref(x_2);
x_81 = l_insertEnter___closed__6;
x_82 = l_Lean_throwError___at___Lean_Elab_Tactic_Do_ProofMode_mRevertForallN___at_____private_Lean_Elab_Tactic_Do_VCGen_0__Lean_Elab_Tactic_Do_VCGen_genVCs_onJumpSite_spec__27_spec__38___redArg(x_81, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
return x_82;
}
}
}
}
}
LEAN_EXPORT lean_object* l_insertEnter___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_insertEnter(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec_ref(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; 
x_8 = lean_usize_dec_lt(x_6, x_5);
if (x_8 == 0)
{
lean_dec_ref(x_1);
lean_inc_ref(x_7);
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_uget(x_4, x_6);
x_10 = lean_ctor_get(x_9, 3);
lean_inc(x_10);
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_name_eq(x_10, x_11);
lean_dec(x_10);
if (x_12 == 0)
{
size_t x_13; size_t x_14; 
lean_dec_ref(x_9);
x_13 = 1;
x_14 = lean_usize_add(x_6, x_13);
{
size_t _tmp_5 = x_14;
lean_object* _tmp_6 = x_2;
x_6 = _tmp_5;
x_7 = _tmp_6;
}
goto _start;
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_1);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_17 = lean_ctor_get(x_1, 1);
lean_dec(x_17);
x_18 = lean_ctor_get(x_1, 0);
lean_dec(x_18);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_9);
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_1, 1, x_3);
lean_ctor_set(x_1, 0, x_20);
return x_1;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
lean_dec(x_1);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_9);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_3);
return x_23;
}
}
}
}
}
static lean_object* _init_l_findGoalForLocation___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; size_t x_6; size_t x_7; lean_object* x_8; lean_object* x_9; 
x_3 = lean_box(0);
x_4 = lean_box(0);
x_5 = l_findGoalForLocation___closed__0;
x_6 = lean_array_size(x_1);
x_7 = 0;
x_8 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_2, x_5, x_4, x_1, x_6, x_7, x_5);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
lean_dec_ref(x_8);
if (lean_obj_tag(x_9) == 0)
{
return x_3;
}
else
{
lean_object* x_10; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec_ref(x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_9 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_10 = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_1, x_2, x_3, x_4, x_8, x_9, x_7);
lean_dec_ref(x_7);
lean_dec_ref(x_4);
lean_dec_ref(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_findGoalForLocation(x_1, x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanelProps_ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanelProps_ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ConvSelectionPanelProps_ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1__ctorIdx(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
}
LEAN_EXPORT lean_object* l_RpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1__ctorIdx___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_RpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1__ctorIdx(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("pos", 3, 3);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("goals", 5, 5);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("termGoal", 8, 8);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("selectedLocations", 17, 17);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("replaceRange", 12, 12);
return x_1;
}
}
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_2 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_1);
x_6 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec_ref(x_6);
x_8 = l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_1);
x_9 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__1(x_1, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec_ref(x_9);
x_11 = l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_1);
x_12 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
lean_dec_ref(x_12);
x_14 = l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
x_15 = l_Lean_Json_getObjValAs_x3f___at___Lean_Widget_instFromJsonRpcEncodablePacket_fromJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_51__spec__0(x_1, x_14);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_18, 0, x_4);
lean_ctor_set(x_18, 1, x_7);
lean_ctor_set(x_18, 2, x_10);
lean_ctor_set(x_18, 3, x_13);
lean_ctor_set(x_18, 4, x_17);
lean_ctor_set(x_15, 0, x_18);
return x_15;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
lean_dec(x_15);
x_20 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_20, 0, x_4);
lean_ctor_set(x_20, 1, x_7);
lean_ctor_set(x_20, 2, x_10);
lean_ctor_set(x_20, 3, x_13);
lean_ctor_set(x_20, 4, x_19);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = lean_ctor_get(x_1, 3);
x_6 = lean_ctor_get(x_1, 4);
x_7 = l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_2);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_2);
x_9 = lean_box(0);
x_10 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_10, 0, x_8);
lean_ctor_set(x_10, 1, x_9);
x_11 = l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_3);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_3);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_9);
x_14 = l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
x_15 = l_Lean_Json_opt___at___Lean_Widget_instToJsonRpcEncodablePacket_toJson____x40_Lean_Widget_UserWidget_3273022877____hygCtx___hyg_69__spec__0(x_14, x_4);
x_16 = l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_5);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_5);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_9);
x_19 = l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
lean_inc(x_6);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_6);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_9);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_9);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_18);
lean_ctor_set(x_23, 1, x_22);
x_24 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_24, 0, x_15);
lean_ctor_set(x_24, 1, x_23);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_13);
lean_ctor_set(x_25, 1, x_24);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_10);
lean_ctor_set(x_26, 1, x_25);
x_27 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
x_28 = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___Lean_Server_instToJsonCodeActionResolveData_toJson_spec__0(x_26, x_27);
x_29 = l_Lean_Json_mkObj(x_28);
return x_29;
}
}
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; size_t x_9; size_t x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_4);
lean_dec_ref(x_1);
x_5 = lean_ctor_get(x_3, 0);
lean_inc_ref(x_5);
x_6 = lean_ctor_get(x_3, 1);
lean_inc_ref(x_6);
x_7 = lean_ctor_get(x_3, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_3, 3);
lean_inc_ref(x_8);
lean_dec_ref(x_3);
x_9 = lean_array_size(x_6);
x_10 = 0;
x_11 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal_1490754142____hygCtx___hyg_1__spec__0(x_9, x_10, x_6, x_2);
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_11, 1);
lean_inc(x_13);
lean_dec_ref(x_11);
x_14 = l_Lean_Lsp_instToJsonPosition_toJson(x_5);
x_15 = l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(x_12);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_34; 
x_34 = lean_box(0);
x_16 = x_34;
x_17 = x_13;
goto block_33;
}
else
{
uint8_t x_35; 
x_35 = !lean_is_exclusive(x_7);
if (x_35 == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_7, 0);
x_37 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(x_36, x_13);
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec_ref(x_37);
lean_ctor_set(x_7, 0, x_38);
x_16 = x_7;
x_17 = x_39;
goto block_33;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_40 = lean_ctor_get(x_7, 0);
lean_inc(x_40);
lean_dec(x_7);
x_41 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(x_40, x_13);
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_41, 1);
lean_inc(x_43);
lean_dec_ref(x_41);
x_44 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_44, 0, x_42);
x_16 = x_44;
x_17 = x_43;
goto block_33;
}
}
block_33:
{
size_t x_18; lean_object* x_19; uint8_t x_20; 
x_18 = lean_array_size(x_8);
x_19 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1__spec__0(x_18, x_10, x_8, x_17);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(x_21);
x_23 = l_Lean_Lsp_instToJsonRange_toJson(x_4);
x_24 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_24, 0, x_14);
lean_ctor_set(x_24, 1, x_15);
lean_ctor_set(x_24, 2, x_16);
lean_ctor_set(x_24, 3, x_22);
lean_ctor_set(x_24, 4, x_23);
x_25 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_(x_24);
lean_dec_ref(x_24);
lean_ctor_set(x_19, 0, x_25);
return x_19;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_26 = lean_ctor_get(x_19, 0);
x_27 = lean_ctor_get(x_19, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_19);
x_28 = l_Array_toJson___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_enc____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__1(x_26);
x_29 = l_Lean_Lsp_instToJsonRange_toJson(x_4);
x_30 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_30, 0, x_14);
lean_ctor_set(x_30, 1, x_15);
lean_ctor_set(x_30, 2, x_16);
lean_ctor_set(x_30, 3, x_28);
lean_ctor_set(x_30, 4, x_29);
x_31 = l_instToJsonRpcEncodablePacket_toJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_(x_30);
lean_dec_ref(x_30);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_27);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = l_instFromJsonRpcEncodablePacket_fromJson____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec_ref(x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_4, 3);
lean_inc(x_8);
x_9 = lean_ctor_get(x_4, 4);
lean_inc(x_9);
lean_dec(x_4);
x_10 = l_Lean_Lsp_instFromJsonPosition_fromJson(x_5);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec_ref(x_2);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
return x_10;
}
else
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_10, 0);
lean_inc(x_14);
lean_dec_ref(x_10);
x_15 = l_Array_fromJson_x3f___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_dec____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__0(x_6);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec_ref(x_2);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
return x_15;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
else
{
lean_object* x_19; size_t x_20; size_t x_21; lean_object* x_22; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
lean_dec_ref(x_15);
x_20 = lean_array_size(x_19);
x_21 = 0;
lean_inc_ref(x_2);
x_22 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal_1490754142____hygCtx___hyg_1__spec__0(x_20, x_21, x_19, x_2);
if (lean_obj_tag(x_22) == 0)
{
uint8_t x_23; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec_ref(x_2);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
return x_22;
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_22, 0);
lean_inc(x_26);
lean_dec_ref(x_22);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_53; 
x_53 = lean_box(0);
x_27 = x_53;
x_28 = x_2;
goto block_52;
}
else
{
uint8_t x_54; 
x_54 = !lean_is_exclusive(x_7);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; 
x_55 = lean_ctor_get(x_7, 0);
lean_inc_ref(x_2);
x_56 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(x_55, x_2);
if (lean_obj_tag(x_56) == 0)
{
uint8_t x_57; 
lean_free_object(x_7);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec_ref(x_2);
x_57 = !lean_is_exclusive(x_56);
if (x_57 == 0)
{
return x_56;
}
else
{
lean_object* x_58; lean_object* x_59; 
x_58 = lean_ctor_get(x_56, 0);
lean_inc(x_58);
lean_dec(x_56);
x_59 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_59, 0, x_58);
return x_59;
}
}
else
{
lean_object* x_60; 
x_60 = lean_ctor_get(x_56, 0);
lean_inc(x_60);
lean_dec_ref(x_56);
lean_ctor_set(x_7, 0, x_60);
x_27 = x_7;
x_28 = x_2;
goto block_52;
}
}
else
{
lean_object* x_61; lean_object* x_62; 
x_61 = lean_ctor_get(x_7, 0);
lean_inc(x_61);
lean_dec(x_7);
lean_inc_ref(x_2);
x_62 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal_2553565095____hygCtx___hyg_1_(x_61, x_2);
if (lean_obj_tag(x_62) == 0)
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; 
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec_ref(x_2);
x_63 = lean_ctor_get(x_62, 0);
lean_inc(x_63);
if (lean_is_exclusive(x_62)) {
 lean_ctor_release(x_62, 0);
 x_64 = x_62;
} else {
 lean_dec_ref(x_62);
 x_64 = lean_box(0);
}
if (lean_is_scalar(x_64)) {
 x_65 = lean_alloc_ctor(0, 1, 0);
} else {
 x_65 = x_64;
}
lean_ctor_set(x_65, 0, x_63);
return x_65;
}
else
{
lean_object* x_66; lean_object* x_67; 
x_66 = lean_ctor_get(x_62, 0);
lean_inc(x_66);
lean_dec_ref(x_62);
x_67 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_67, 0, x_66);
x_27 = x_67;
x_28 = x_2;
goto block_52;
}
}
}
block_52:
{
lean_object* x_29; 
x_29 = l_Array_fromJson_x3f___at___Lean_Widget_instRpcEncodableGetWidgetsResponse_dec____x40_Lean_Widget_UserWidget_577854155____hygCtx___hyg_1__spec__0(x_8);
if (lean_obj_tag(x_29) == 0)
{
uint8_t x_30; 
lean_dec_ref(x_28);
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_30 = !lean_is_exclusive(x_29);
if (x_30 == 0)
{
return x_29;
}
else
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_29, 0);
lean_inc(x_31);
lean_dec(x_29);
x_32 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_32, 0, x_31);
return x_32;
}
}
else
{
lean_object* x_33; size_t x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_29, 0);
lean_inc(x_33);
lean_dec_ref(x_29);
x_34 = lean_array_size(x_33);
x_35 = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic_2840189264____hygCtx___hyg_1__spec__0(x_34, x_21, x_33, x_28);
lean_dec_ref(x_28);
if (lean_obj_tag(x_35) == 0)
{
uint8_t x_36; 
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_36 = !lean_is_exclusive(x_35);
if (x_36 == 0)
{
return x_35;
}
else
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_35, 0);
lean_inc(x_37);
lean_dec(x_35);
x_38 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_38, 0, x_37);
return x_38;
}
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_35, 0);
lean_inc(x_39);
lean_dec_ref(x_35);
x_40 = l_Lean_Lsp_instFromJsonRange_fromJson(x_9);
if (lean_obj_tag(x_40) == 0)
{
uint8_t x_41; 
lean_dec(x_39);
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
x_41 = !lean_is_exclusive(x_40);
if (x_41 == 0)
{
return x_40;
}
else
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_40, 0);
lean_inc(x_42);
lean_dec(x_40);
x_43 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_43, 0, x_42);
return x_43;
}
}
else
{
uint8_t x_44; 
x_44 = !lean_is_exclusive(x_40);
if (x_44 == 0)
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_45 = lean_ctor_get(x_40, 0);
x_46 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_46, 0, x_14);
lean_ctor_set(x_46, 1, x_26);
lean_ctor_set(x_46, 2, x_27);
lean_ctor_set(x_46, 3, x_39);
x_47 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_45);
lean_ctor_set(x_40, 0, x_47);
return x_40;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_48 = lean_ctor_get(x_40, 0);
lean_inc(x_48);
lean_dec(x_40);
x_49 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_49, 0, x_14);
lean_ctor_set(x_49, 1, x_26);
lean_ctor_set(x_49, 2, x_27);
lean_ctor_set(x_49, 3, x_39);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_49);
lean_ctor_set(x_50, 1, x_48);
x_51 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_51, 0, x_50);
return x_51;
}
}
}
}
}
}
}
}
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableConvSelectionPanelProps___closed__1;
x_2 = l_instRpcEncodableConvSelectionPanelProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableConvSelectionPanelProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_Server_instInhabitedRequestError_default;
x_2 = lean_alloc_closure((void*)(l_EStateM_instInhabited___redArg___lam__0), 2, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0;
x_5 = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = lean_panic_fn(x_5, x_1);
x_7 = lean_apply_2(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_instToJsonMakeEditLinkProps_toJson(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc_ref(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_insertEnter(x_1, x_2, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_12 = lean_ctor_get(x_3, 0);
x_13 = lean_ctor_get(x_10, 0);
x_14 = lean_ctor_get(x_12, 0);
x_15 = l_ProofWidgets_MakeEditLink;
x_16 = lean_box(0);
lean_inc(x_13);
x_17 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_14, x_4, x_13, x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_13);
x_19 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_20 = lean_array_push(x_19, x_18);
x_21 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_15, x_17, x_20);
lean_ctor_set(x_10, 0, x_21);
return x_10;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_22 = lean_ctor_get(x_3, 0);
x_23 = lean_ctor_get(x_10, 0);
x_24 = lean_ctor_get(x_10, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_10);
x_25 = lean_ctor_get(x_22, 0);
x_26 = l_ProofWidgets_MakeEditLink;
x_27 = lean_box(0);
lean_inc(x_23);
x_28 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_25, x_4, x_23, x_27);
x_29 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_29, 0, x_23);
x_30 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_31 = lean_array_push(x_30, x_29);
x_32 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_26, x_28, x_31);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_32);
lean_ctor_set(x_33, 1, x_24);
return x_33;
}
}
else
{
uint8_t x_34; 
lean_dec_ref(x_4);
x_34 = !lean_is_exclusive(x_10);
if (x_34 == 0)
{
return x_10;
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_ctor_get(x_10, 0);
x_36 = lean_ctor_get(x_10, 1);
lean_inc(x_36);
lean_inc(x_35);
lean_dec(x_10);
x_37 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_37, 0, x_35);
lean_ctor_set(x_37, 1, x_36);
return x_37;
}
}
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_MVarId_getDecl(x_1, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec_ref(x_10);
x_13 = lean_ctor_get(x_7, 2);
x_14 = lean_ctor_get(x_11, 1);
lean_inc_ref(x_14);
x_15 = lean_ctor_get(x_11, 2);
lean_inc_ref(x_15);
x_16 = lean_ctor_get(x_11, 4);
lean_inc_ref(x_16);
lean_dec(x_11);
x_17 = lean_box(1);
lean_inc(x_13);
x_18 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_18, 0, x_13);
lean_ctor_set(x_18, 1, x_17);
lean_ctor_set(x_18, 2, x_17);
x_19 = l_Lean_LocalContext_sanitizeNames(x_14, x_18);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec_ref(x_19);
x_21 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__0___boxed), 9, 4);
lean_closure_set(x_21, 0, x_2);
lean_closure_set(x_21, 1, x_15);
lean_closure_set(x_21, 2, x_3);
lean_closure_set(x_21, 3, x_4);
x_22 = l_Lean_Meta_withLCtx___at___Lean_Meta_withErasedFVars___at_____private_Lean_Meta_Tactic_FunInd_0__Lean_Tactic_FunInd_deriveInductionStructural_doRealize_spec__36_spec__36___redArg(x_20, x_16, x_21, x_5, x_6, x_7, x_8, x_12);
return x_22;
}
else
{
uint8_t x_23; 
lean_dec(x_8);
lean_dec_ref(x_7);
lean_dec(x_6);
lean_dec_ref(x_5);
lean_dec_ref(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_23 = !lean_is_exclusive(x_10);
if (x_23 == 0)
{
return x_10;
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
return x_26;
}
}
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("details", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("open", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__2() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__2;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__3;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("summary", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mv2 pointer", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__8;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__9;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__10;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Conv 🔍", 9, 6);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__12;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__13;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__14;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__11;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__6;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__17() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ml1", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__17;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__18;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__19;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__15;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__21;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ConvSelectionPanel.rpc", 22, 22);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unreachable code has been reached", 33, 33);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__24;
x_2 = lean_unsigned_to_nat(60u);
x_3 = lean_unsigned_to_nat(128u);
x_4 = l_ConvSelectionPanel_rpc___lam__2___closed__23;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__26() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("could not find goal for location ", 33, 33);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__27;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__29;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__31() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__29;
x_4 = l_ConvSelectionPanel_rpc___lam__2___closed__30;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(1);
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__31;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__28;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__33() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__34() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Use shift-click to select one sub-expression in the goal that you want to zoom on.", 82, 82);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__34;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__36() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__35;
x_2 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__36;
x_2 = l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__33;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_4 = l_Lean_Server_RequestM_readDoc___at_____private_Lean_Meta_Tactic_TryThis_0__Lean_Meta_Tactic_TryThis_tryThisProvider_spec__0(x_2, x_3);
x_5 = lean_ctor_get(x_1, 0);
lean_inc_ref(x_5);
x_6 = lean_ctor_get(x_4, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 1);
lean_inc(x_7);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_8 = x_4;
} else {
 lean_dec_ref(x_4);
 x_8 = lean_box(0);
}
x_9 = !lean_is_exclusive(x_1);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; lean_object* x_15; lean_object* x_16; 
x_10 = lean_ctor_get(x_1, 1);
x_11 = lean_ctor_get(x_1, 0);
lean_dec(x_11);
x_12 = lean_ctor_get(x_5, 1);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_5, 3);
lean_inc_ref(x_13);
lean_dec_ref(x_5);
x_14 = l_Array_isEmpty___redArg(x_13);
if (x_14 == 0)
{
lean_object* x_29; lean_object* x_30; uint8_t x_31; 
x_29 = lean_unsigned_to_nat(0u);
x_30 = lean_array_get_size(x_13);
x_31 = lean_nat_dec_lt(x_29, x_30);
lean_dec(x_30);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; 
lean_dec_ref(x_13);
lean_dec_ref(x_12);
lean_free_object(x_1);
lean_dec_ref(x_10);
lean_dec(x_6);
x_32 = l_ConvSelectionPanel_rpc___lam__2___closed__25;
x_33 = l_panic___at___ConvSelectionPanel_rpc_spec__0(x_32, x_2, x_7);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec_ref(x_33);
x_15 = x_34;
x_16 = x_35;
goto block_28;
}
else
{
lean_dec(x_8);
return x_33;
}
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_dec_ref(x_2);
x_36 = lean_array_fget_borrowed(x_13, x_29);
lean_inc_ref(x_36);
x_37 = l_findGoalForLocation(x_12, x_36);
lean_dec_ref(x_12);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_inc_ref(x_36);
lean_dec_ref(x_13);
lean_dec_ref(x_10);
lean_dec(x_8);
lean_dec(x_6);
x_38 = l_ConvSelectionPanel_rpc___lam__2___closed__26;
x_39 = l_Lean_SubExpr_instToJsonGoalsLocation_toJson(x_36);
x_40 = lean_unsigned_to_nat(80u);
x_41 = l_Lean_Json_pretty(x_39, x_40);
x_42 = lean_string_append(x_38, x_41);
lean_dec_ref(x_41);
x_43 = l_Lean_Server_RequestError_invalidParams(x_42);
lean_ctor_set_tag(x_1, 1);
lean_ctor_set(x_1, 1, x_7);
lean_ctor_set(x_1, 0, x_43);
return x_1;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
lean_free_object(x_1);
x_44 = lean_ctor_get(x_37, 0);
lean_inc(x_44);
lean_dec_ref(x_37);
x_45 = lean_ctor_get(x_44, 0);
x_46 = lean_ctor_get(x_45, 2);
lean_inc_ref(x_46);
x_47 = lean_ctor_get(x_44, 3);
lean_inc(x_47);
lean_dec(x_44);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec_ref(x_46);
x_49 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__1), 9, 4);
lean_closure_set(x_49, 0, x_47);
lean_closure_set(x_49, 1, x_13);
lean_closure_set(x_49, 2, x_6);
lean_closure_set(x_49, 3, x_10);
x_50 = l_ConvSelectionPanel_rpc___lam__2___closed__32;
x_51 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_48, x_50, x_49, x_7);
if (lean_obj_tag(x_51) == 0)
{
lean_object* x_52; lean_object* x_53; 
x_52 = lean_ctor_get(x_51, 0);
lean_inc(x_52);
x_53 = lean_ctor_get(x_51, 1);
lean_inc(x_53);
lean_dec_ref(x_51);
x_15 = x_52;
x_16 = x_53;
goto block_28;
}
else
{
uint8_t x_54; 
lean_dec(x_8);
x_54 = !lean_is_exclusive(x_51);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; 
x_55 = lean_ctor_get(x_51, 0);
x_56 = l_Lean_Server_RequestError_ofIoError(x_55);
lean_ctor_set(x_51, 0, x_56);
return x_51;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_57 = lean_ctor_get(x_51, 0);
x_58 = lean_ctor_get(x_51, 1);
lean_inc(x_58);
lean_inc(x_57);
lean_dec(x_51);
x_59 = l_Lean_Server_RequestError_ofIoError(x_57);
x_60 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_58);
return x_60;
}
}
}
}
}
else
{
lean_object* x_61; 
lean_dec_ref(x_13);
lean_dec_ref(x_12);
lean_free_object(x_1);
lean_dec_ref(x_10);
lean_dec(x_6);
lean_dec_ref(x_2);
x_61 = l_ConvSelectionPanel_rpc___lam__2___closed__37;
x_15 = x_61;
x_16 = x_7;
goto block_28;
}
block_28:
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_17 = l_ConvSelectionPanel_rpc___lam__2___closed__0;
x_18 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_19 = l_ConvSelectionPanel_rpc___lam__2___closed__5;
x_20 = l_ConvSelectionPanel_rpc___lam__2___closed__16;
x_21 = l_ConvSelectionPanel_rpc___lam__2___closed__20;
x_22 = lean_array_push(x_18, x_15);
x_23 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_23, 0, x_20);
lean_ctor_set(x_23, 1, x_21);
lean_ctor_set(x_23, 2, x_22);
x_24 = l_ConvSelectionPanel_rpc___lam__2___closed__22;
x_25 = lean_array_push(x_24, x_23);
x_26 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_26, 0, x_17);
lean_ctor_set(x_26, 1, x_19);
lean_ctor_set(x_26, 2, x_25);
if (lean_is_scalar(x_8)) {
 x_27 = lean_alloc_ctor(0, 2, 0);
} else {
 x_27 = x_8;
}
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_16);
return x_27;
}
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; lean_object* x_67; 
x_62 = lean_ctor_get(x_1, 1);
lean_inc(x_62);
lean_dec(x_1);
x_63 = lean_ctor_get(x_5, 1);
lean_inc_ref(x_63);
x_64 = lean_ctor_get(x_5, 3);
lean_inc_ref(x_64);
lean_dec_ref(x_5);
x_65 = l_Array_isEmpty___redArg(x_64);
if (x_65 == 0)
{
lean_object* x_80; lean_object* x_81; uint8_t x_82; 
x_80 = lean_unsigned_to_nat(0u);
x_81 = lean_array_get_size(x_64);
x_82 = lean_nat_dec_lt(x_80, x_81);
lean_dec(x_81);
if (x_82 == 0)
{
lean_object* x_83; lean_object* x_84; 
lean_dec_ref(x_64);
lean_dec_ref(x_63);
lean_dec_ref(x_62);
lean_dec(x_6);
x_83 = l_ConvSelectionPanel_rpc___lam__2___closed__25;
x_84 = l_panic___at___ConvSelectionPanel_rpc_spec__0(x_83, x_2, x_7);
if (lean_obj_tag(x_84) == 0)
{
lean_object* x_85; lean_object* x_86; 
x_85 = lean_ctor_get(x_84, 0);
lean_inc(x_85);
x_86 = lean_ctor_get(x_84, 1);
lean_inc(x_86);
lean_dec_ref(x_84);
x_66 = x_85;
x_67 = x_86;
goto block_79;
}
else
{
lean_dec(x_8);
return x_84;
}
}
else
{
lean_object* x_87; lean_object* x_88; 
lean_dec_ref(x_2);
x_87 = lean_array_fget_borrowed(x_64, x_80);
lean_inc_ref(x_87);
x_88 = l_findGoalForLocation(x_63, x_87);
lean_dec_ref(x_63);
if (lean_obj_tag(x_88) == 0)
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; 
lean_inc_ref(x_87);
lean_dec_ref(x_64);
lean_dec_ref(x_62);
lean_dec(x_8);
lean_dec(x_6);
x_89 = l_ConvSelectionPanel_rpc___lam__2___closed__26;
x_90 = l_Lean_SubExpr_instToJsonGoalsLocation_toJson(x_87);
x_91 = lean_unsigned_to_nat(80u);
x_92 = l_Lean_Json_pretty(x_90, x_91);
x_93 = lean_string_append(x_89, x_92);
lean_dec_ref(x_92);
x_94 = l_Lean_Server_RequestError_invalidParams(x_93);
x_95 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_95, 0, x_94);
lean_ctor_set(x_95, 1, x_7);
return x_95;
}
else
{
lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; 
x_96 = lean_ctor_get(x_88, 0);
lean_inc(x_96);
lean_dec_ref(x_88);
x_97 = lean_ctor_get(x_96, 0);
x_98 = lean_ctor_get(x_97, 2);
lean_inc_ref(x_98);
x_99 = lean_ctor_get(x_96, 3);
lean_inc(x_99);
lean_dec(x_96);
x_100 = lean_ctor_get(x_98, 0);
lean_inc(x_100);
lean_dec_ref(x_98);
x_101 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__1), 9, 4);
lean_closure_set(x_101, 0, x_99);
lean_closure_set(x_101, 1, x_64);
lean_closure_set(x_101, 2, x_6);
lean_closure_set(x_101, 3, x_62);
x_102 = l_ConvSelectionPanel_rpc___lam__2___closed__32;
x_103 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_100, x_102, x_101, x_7);
if (lean_obj_tag(x_103) == 0)
{
lean_object* x_104; lean_object* x_105; 
x_104 = lean_ctor_get(x_103, 0);
lean_inc(x_104);
x_105 = lean_ctor_get(x_103, 1);
lean_inc(x_105);
lean_dec_ref(x_103);
x_66 = x_104;
x_67 = x_105;
goto block_79;
}
else
{
lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; 
lean_dec(x_8);
x_106 = lean_ctor_get(x_103, 0);
lean_inc(x_106);
x_107 = lean_ctor_get(x_103, 1);
lean_inc(x_107);
if (lean_is_exclusive(x_103)) {
 lean_ctor_release(x_103, 0);
 lean_ctor_release(x_103, 1);
 x_108 = x_103;
} else {
 lean_dec_ref(x_103);
 x_108 = lean_box(0);
}
x_109 = l_Lean_Server_RequestError_ofIoError(x_106);
if (lean_is_scalar(x_108)) {
 x_110 = lean_alloc_ctor(1, 2, 0);
} else {
 x_110 = x_108;
}
lean_ctor_set(x_110, 0, x_109);
lean_ctor_set(x_110, 1, x_107);
return x_110;
}
}
}
}
else
{
lean_object* x_111; 
lean_dec_ref(x_64);
lean_dec_ref(x_63);
lean_dec_ref(x_62);
lean_dec(x_6);
lean_dec_ref(x_2);
x_111 = l_ConvSelectionPanel_rpc___lam__2___closed__37;
x_66 = x_111;
x_67 = x_7;
goto block_79;
}
block_79:
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; 
x_68 = l_ConvSelectionPanel_rpc___lam__2___closed__0;
x_69 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_70 = l_ConvSelectionPanel_rpc___lam__2___closed__5;
x_71 = l_ConvSelectionPanel_rpc___lam__2___closed__16;
x_72 = l_ConvSelectionPanel_rpc___lam__2___closed__20;
x_73 = lean_array_push(x_69, x_66);
x_74 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_74, 0, x_71);
lean_ctor_set(x_74, 1, x_72);
lean_ctor_set(x_74, 2, x_73);
x_75 = l_ConvSelectionPanel_rpc___lam__2___closed__22;
x_76 = lean_array_push(x_75, x_74);
x_77 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_77, 0, x_68);
lean_ctor_set(x_77, 1, x_70);
lean_ctor_set(x_77, 2, x_76);
if (lean_is_scalar(x_8)) {
 x_78 = lean_alloc_ctor(0, 2, 0);
} else {
 x_78 = x_8;
}
lean_ctor_set(x_78, 0, x_77);
lean_ctor_set(x_78, 1, x_67);
return x_78;
}
}
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__2), 3, 1);
lean_closure_set(x_4, 0, x_1);
x_5 = l_Lean_Server_RequestM_asTask___redArg(x_4, x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ConvSelectionPanel_rpc___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec_ref(x_3);
lean_dec_ref(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec_ref(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec_ref(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec_ref(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec_ref(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc_ref(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html_2686543190____hygCtx___hyg_1_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec_ref(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = 9;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint64_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Std_DTreeMap_Internal_Impl_Const_get_x3f___at_____private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_8, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; 
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
lean_dec(x_1);
x_10 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec_ref(x_9);
x_13 = lean_st_ref_get(x_12, x_7);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
x_17 = lean_ctor_get(x_15, 0);
lean_inc_ref(x_17);
lean_dec(x_15);
lean_inc(x_5);
x_18 = l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(x_5, x_17);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; uint8_t x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec_ref(x_18);
x_20 = 3;
x_21 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
x_22 = 1;
x_23 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_22);
x_24 = lean_string_append(x_21, x_23);
lean_dec_ref(x_23);
x_25 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
x_26 = lean_string_append(x_24, x_25);
x_27 = l_Lean_Json_compress(x_5);
x_28 = lean_string_append(x_26, x_27);
lean_dec_ref(x_27);
x_29 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
x_30 = lean_string_append(x_28, x_29);
x_31 = lean_string_append(x_30, x_19);
lean_dec(x_19);
x_32 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set_uint8(x_32, sizeof(void*)*1, x_20);
lean_ctor_set_tag(x_13, 1);
lean_ctor_set(x_13, 0, x_32);
return x_13;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_1);
x_33 = lean_ctor_get(x_18, 0);
lean_inc(x_33);
lean_dec_ref(x_18);
lean_inc_ref(x_6);
x_34 = lean_apply_3(x_2, x_33, x_6, x_16);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec_ref(x_34);
x_37 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_37, 0, x_12);
lean_closure_set(x_37, 1, x_3);
x_38 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_35, x_37, x_6, x_36);
return x_38;
}
else
{
uint8_t x_39; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_39 = !lean_is_exclusive(x_34);
if (x_39 == 0)
{
return x_34;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_34, 0);
x_41 = lean_ctor_get(x_34, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_34);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_43 = lean_ctor_get(x_13, 0);
x_44 = lean_ctor_get(x_13, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_13);
x_45 = lean_ctor_get(x_43, 0);
lean_inc_ref(x_45);
lean_dec(x_43);
lean_inc(x_5);
x_46 = l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv_2926008789____hygCtx___hyg_1_(x_5, x_45);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; uint8_t x_48; lean_object* x_49; uint8_t x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
lean_dec_ref(x_2);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec_ref(x_46);
x_48 = 3;
x_49 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2;
x_50 = 1;
x_51 = l_Lean_Name_toStringWithToken___at___Lean_Name_toString_spec__0(x_1, x_50);
x_52 = lean_string_append(x_49, x_51);
lean_dec_ref(x_51);
x_53 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3;
x_54 = lean_string_append(x_52, x_53);
x_55 = l_Lean_Json_compress(x_5);
x_56 = lean_string_append(x_54, x_55);
lean_dec_ref(x_55);
x_57 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4;
x_58 = lean_string_append(x_56, x_57);
x_59 = lean_string_append(x_58, x_47);
lean_dec(x_47);
x_60 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set_uint8(x_60, sizeof(void*)*1, x_48);
x_61 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_44);
return x_61;
}
else
{
lean_object* x_62; lean_object* x_63; 
lean_dec(x_5);
lean_dec(x_1);
x_62 = lean_ctor_get(x_46, 0);
lean_inc(x_62);
lean_dec_ref(x_46);
lean_inc_ref(x_6);
x_63 = lean_apply_3(x_2, x_62, x_6, x_44);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_63, 1);
lean_inc(x_65);
lean_dec_ref(x_63);
x_66 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_66, 0, x_12);
lean_closure_set(x_66, 1, x_3);
x_67 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_64, x_66, x_6, x_65);
return x_67;
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
lean_dec(x_12);
lean_dec_ref(x_6);
lean_dec_ref(x_3);
x_68 = lean_ctor_get(x_63, 0);
lean_inc(x_68);
x_69 = lean_ctor_get(x_63, 1);
lean_inc(x_69);
if (lean_is_exclusive(x_63)) {
 lean_ctor_release(x_63, 0);
 lean_ctor_release(x_63, 1);
 x_70 = x_63;
} else {
 lean_dec_ref(x_63);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(1, 2, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_68);
lean_ctor_set(x_71, 1, x_69);
return x_71;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed), 7, 3);
lean_closure_set(x_4, 0, x_1);
lean_closure_set(x_4, 1, x_2);
lean_closure_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ConvSelectionPanel", 18, 18);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rpc", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1;
x_2 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2;
x_2 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3;
x_3 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec_ref(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint64_t x_8; lean_object* x_9; 
x_8 = lean_unbox_uint64(x_4);
lean_dec(x_4);
x_9 = l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"ConvSelectionPanel.rpc\",f='false';var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1882, 1882);
return x_1;
}
}
static uint64_t _init_l_ConvSelectionPanel___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ConvSelectionPanel___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__2() {
_start:
{
uint64_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel___closed__1;
x_2 = l_ConvSelectionPanel___closed__0;
x_3 = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint64(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel___closed__3;
x_2 = l_ConvSelectionPanel___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel() {
_start:
{
lean_object* x_1; 
x_1 = l_ConvSelectionPanel___closed__4;
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticConv\?", 11, 11);
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_tacticConv_x3f___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("conv\?", 5, 5);
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__3() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; 
x_1 = 0;
x_2 = l_tacticConv_x3f___closed__2;
x_3 = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_1);
return x_3;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_tacticConv_x3f___closed__3;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_tacticConv_x3f___closed__1;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_tacticConv_x3f() {
_start:
{
lean_object* x_1; 
x_1 = l_tacticConv_x3f___closed__4;
return x_1;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_tacticConv_x3f___closed__1;
lean_inc(x_1);
x_6 = l_Lean_Syntax_isOfKind(x_1, x_5);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec_ref(x_2);
lean_dec(x_1);
x_7 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_Tactic_Do_mkSpecContext_spec__0___redArg(x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_2, 1);
x_9 = lean_unsigned_to_nat(0u);
x_10 = l_Lean_Syntax_getArg(x_1, x_9);
lean_dec(x_1);
lean_inc_ref(x_8);
x_11 = l_Lean_FileMap_rangeOfStx_x3f(x_8, x_10);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; 
lean_dec(x_10);
lean_dec_ref(x_2);
x_12 = lean_box(0);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_4);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_14 = lean_ctor_get(x_11, 0);
lean_inc(x_14);
lean_dec_ref(x_11);
x_15 = l_ConvSelectionPanel;
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; uint64_t x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_ctor_get(x_15, 1);
lean_dec(x_18);
x_19 = lean_ctor_get_uint64(x_17, sizeof(void*)*1);
lean_dec_ref(x_17);
x_20 = l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
x_21 = l_Lean_Lsp_instToJsonRange_toJson(x_14);
lean_ctor_set(x_15, 1, x_21);
lean_ctor_set(x_15, 0, x_20);
x_22 = lean_box(0);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_15);
lean_ctor_set(x_23, 1, x_22);
x_24 = l_Lean_Json_mkObj(x_23);
x_25 = lean_alloc_closure((void*)(l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0), 2, 1);
lean_closure_set(x_25, 0, x_24);
x_26 = l_Lean_Widget_savePanelWidgetInfo(x_19, x_25, x_10, x_2, x_3, x_4);
lean_dec_ref(x_2);
return x_26;
}
else
{
lean_object* x_27; uint64_t x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_27 = lean_ctor_get(x_15, 0);
lean_inc(x_27);
lean_dec(x_15);
x_28 = lean_ctor_get_uint64(x_27, sizeof(void*)*1);
lean_dec_ref(x_27);
x_29 = l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_;
x_30 = l_Lean_Lsp_instToJsonRange_toJson(x_14);
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_29);
lean_ctor_set(x_31, 1, x_30);
x_32 = lean_box(0);
x_33 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_33, 0, x_31);
lean_ctor_set(x_33, 1, x_32);
x_34 = l_Lean_Json_mkObj(x_33);
x_35 = lean_alloc_closure((void*)(l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0), 2, 1);
lean_closure_set(x_35, 0, x_34);
x_36 = l_Lean_Widget_savePanelWidgetInfo(x_28, x_35, x_10, x_2, x_3, x_4);
lean_dec_ref(x_2);
return x_36;
}
}
}
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(x_1, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec_ref(x_6);
lean_dec(x_5);
lean_dec_ref(x_4);
lean_dec(x_3);
lean_dec_ref(x_2);
return x_11;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Meta_ExprLens(uint8_t builtin, lean_object*);
lean_object* initialize_Batteries_Lean_Position(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_MakeEditLink(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_SelectInsertConv(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Meta_ExprLens(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Batteries_Lean_Position(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_OfRpcMethod(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_MakeEditLink(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4);
l_insertEnter___closed__0 = _init_l_insertEnter___closed__0();
lean_mark_persistent(l_insertEnter___closed__0);
l_insertEnter___closed__1 = _init_l_insertEnter___closed__1();
lean_mark_persistent(l_insertEnter___closed__1);
l_insertEnter___closed__2 = _init_l_insertEnter___closed__2();
lean_mark_persistent(l_insertEnter___closed__2);
l_insertEnter___closed__3 = _init_l_insertEnter___closed__3();
lean_mark_persistent(l_insertEnter___closed__3);
l_insertEnter___closed__4 = _init_l_insertEnter___closed__4();
lean_mark_persistent(l_insertEnter___closed__4);
l_insertEnter___closed__5 = _init_l_insertEnter___closed__5();
lean_mark_persistent(l_insertEnter___closed__5);
l_insertEnter___closed__6 = _init_l_insertEnter___closed__6();
lean_mark_persistent(l_insertEnter___closed__6);
l_findGoalForLocation___closed__0 = _init_l_findGoalForLocation___closed__0();
lean_mark_persistent(l_findGoalForLocation___closed__0);
l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__1____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__2____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__3____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket_fromJson___closed__4____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_50_);
l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_ = _init_l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket_toJson___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv_925219489____hygCtx___hyg_68_);
l_instRpcEncodableConvSelectionPanelProps___closed__0 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__0();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__0);
l_instRpcEncodableConvSelectionPanelProps___closed__1 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__1();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__1);
l_instRpcEncodableConvSelectionPanelProps___closed__2 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__2();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__2);
l_instRpcEncodableConvSelectionPanelProps = _init_l_instRpcEncodableConvSelectionPanelProps();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps);
l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0 = _init_l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0();
lean_mark_persistent(l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0);
l_ConvSelectionPanel_rpc___lam__0___closed__0 = _init_l_ConvSelectionPanel_rpc___lam__0___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__0___closed__0);
l_ConvSelectionPanel_rpc___lam__2___closed__0 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__0);
l_ConvSelectionPanel_rpc___lam__2___closed__1 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__1();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__1);
l_ConvSelectionPanel_rpc___lam__2___closed__2 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__2();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__2);
l_ConvSelectionPanel_rpc___lam__2___closed__3 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__3();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__3);
l_ConvSelectionPanel_rpc___lam__2___closed__4 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__4();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__4);
l_ConvSelectionPanel_rpc___lam__2___closed__5 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__5();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__5);
l_ConvSelectionPanel_rpc___lam__2___closed__6 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__6();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__6);
l_ConvSelectionPanel_rpc___lam__2___closed__7 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__7();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__7);
l_ConvSelectionPanel_rpc___lam__2___closed__8 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__8();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__8);
l_ConvSelectionPanel_rpc___lam__2___closed__9 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__9();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__9);
l_ConvSelectionPanel_rpc___lam__2___closed__10 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__10();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__10);
l_ConvSelectionPanel_rpc___lam__2___closed__11 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__11();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__11);
l_ConvSelectionPanel_rpc___lam__2___closed__12 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__12();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__12);
l_ConvSelectionPanel_rpc___lam__2___closed__13 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__13();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__13);
l_ConvSelectionPanel_rpc___lam__2___closed__14 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__14();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__14);
l_ConvSelectionPanel_rpc___lam__2___closed__15 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__15();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__15);
l_ConvSelectionPanel_rpc___lam__2___closed__16 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__16();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__16);
l_ConvSelectionPanel_rpc___lam__2___closed__17 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__17();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__17);
l_ConvSelectionPanel_rpc___lam__2___closed__18 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__18();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__18);
l_ConvSelectionPanel_rpc___lam__2___closed__19 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__19();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__19);
l_ConvSelectionPanel_rpc___lam__2___closed__20 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__20();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__20);
l_ConvSelectionPanel_rpc___lam__2___closed__21 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__21();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__21);
l_ConvSelectionPanel_rpc___lam__2___closed__22 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__22();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__22);
l_ConvSelectionPanel_rpc___lam__2___closed__23 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__23();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__23);
l_ConvSelectionPanel_rpc___lam__2___closed__24 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__24();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__24);
l_ConvSelectionPanel_rpc___lam__2___closed__25 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__25();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__25);
l_ConvSelectionPanel_rpc___lam__2___closed__26 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__26();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__26);
l_ConvSelectionPanel_rpc___lam__2___closed__27 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__27();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__27);
l_ConvSelectionPanel_rpc___lam__2___closed__28 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__28();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__28);
l_ConvSelectionPanel_rpc___lam__2___closed__29 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__29();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__29);
l_ConvSelectionPanel_rpc___lam__2___closed__30 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__30();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__30);
l_ConvSelectionPanel_rpc___lam__2___closed__31 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__31();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__31);
l_ConvSelectionPanel_rpc___lam__2___closed__32 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__32();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__32);
l_ConvSelectionPanel_rpc___lam__2___closed__33 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__33();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__33);
l_ConvSelectionPanel_rpc___lam__2___closed__34 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__34();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__34);
l_ConvSelectionPanel_rpc___lam__2___closed__35 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__35();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__35);
l_ConvSelectionPanel_rpc___lam__2___closed__36 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__36();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__36);
l_ConvSelectionPanel_rpc___lam__2___closed__37 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__37();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__37);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__0);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__1);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__2);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__3);
l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l___private_Lean_Server_Rpc_RequestHandling_0__Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___closed__4);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3);
l_ConvSelectionPanel_rpc___rpc__wrapped = _init_l_ConvSelectionPanel_rpc___rpc__wrapped();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped);
l_ConvSelectionPanel___closed__0 = _init_l_ConvSelectionPanel___closed__0();
lean_mark_persistent(l_ConvSelectionPanel___closed__0);
l_ConvSelectionPanel___closed__1 = _init_l_ConvSelectionPanel___closed__1();
l_ConvSelectionPanel___closed__2 = _init_l_ConvSelectionPanel___closed__2();
lean_mark_persistent(l_ConvSelectionPanel___closed__2);
l_ConvSelectionPanel___closed__3 = _init_l_ConvSelectionPanel___closed__3();
lean_mark_persistent(l_ConvSelectionPanel___closed__3);
l_ConvSelectionPanel___closed__4 = _init_l_ConvSelectionPanel___closed__4();
lean_mark_persistent(l_ConvSelectionPanel___closed__4);
l_ConvSelectionPanel = _init_l_ConvSelectionPanel();
lean_mark_persistent(l_ConvSelectionPanel);
l_tacticConv_x3f___closed__0 = _init_l_tacticConv_x3f___closed__0();
lean_mark_persistent(l_tacticConv_x3f___closed__0);
l_tacticConv_x3f___closed__1 = _init_l_tacticConv_x3f___closed__1();
lean_mark_persistent(l_tacticConv_x3f___closed__1);
l_tacticConv_x3f___closed__2 = _init_l_tacticConv_x3f___closed__2();
lean_mark_persistent(l_tacticConv_x3f___closed__2);
l_tacticConv_x3f___closed__3 = _init_l_tacticConv_x3f___closed__3();
lean_mark_persistent(l_tacticConv_x3f___closed__3);
l_tacticConv_x3f___closed__4 = _init_l_tacticConv_x3f___closed__4();
lean_mark_persistent(l_tacticConv_x3f___closed__4);
l_tacticConv_x3f = _init_l_tacticConv_x3f();
lean_mark_persistent(l_tacticConv_x3f);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
