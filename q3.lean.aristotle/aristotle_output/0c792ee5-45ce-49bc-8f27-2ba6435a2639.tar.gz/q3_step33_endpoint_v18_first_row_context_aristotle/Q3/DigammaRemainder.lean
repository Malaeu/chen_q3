import Mathlib
import Q3.Basic.Defs
import Q3.DigammaSeries

open scoped Real Topology ComplexOrder BigOperators
open Filter MeasureTheory Real Set

noncomputable section

namespace Q3

/-!
Stieltjes / Euler-Maclaurin remainder for digamma (N=1).
Reference: Johansson (Maple Trans. 2023), equations (21) and (23),
specialized to N=1 and differentiated to obtain the digamma identity.

Proof skeleton and the arithmetic chain to the tail bound are recorded
in `PROWKA_RESPONSE_3.md`.
-/

open scoped BigOperators

/-- Bernoulli polynomial B2(t) = t^2 - t + 1/6. -/
def bernoulli2 (t : ℝ) : ℝ := t ^ 2 - t + (6 : ℝ)⁻¹

/-- Bernoulli gap term: 1/6 - B2(fract x). -/
def bernoulli2Diff (x : ℝ) : ℝ := (6 : ℝ)⁻¹ - bernoulli2 (Int.fract x)

/-- Bernoulli polynomial B1(t) = t - 1/2. -/
def bernoulli1 (t : ℝ) : ℝ := t - (1 / 2 : ℝ)

/-- B1 applied to the fractional part. -/
def bernoulli1Fract (x : ℝ) : ℝ := bernoulli1 (Int.fract x)

@[measurability]
lemma measurable_bernoulli2 : Measurable bernoulli2 := by
  -- bernoulli2 t = t^2 - t + 1/6
  have h1 : Measurable fun t : ℝ => t ^ 2 := by
    simpa using (measurable_id.pow_const 2)
  have h2 : Measurable fun t : ℝ => t := measurable_id
  have h3 : Measurable fun t : ℝ => (1 / 6 : ℝ) := measurable_const
  have h4 : Measurable fun t : ℝ => t ^ 2 - t := h1.sub h2
  have h5 : Measurable fun t : ℝ => t ^ 2 - t + (1 / 6 : ℝ) := h4.add h3
  simpa [bernoulli2, one_div] using h5

@[measurability]
lemma measurable_bernoulli2Diff : Measurable bernoulli2Diff := by
  have hfract : Measurable (Int.fract : ℝ → ℝ) := measurable_fract
  simpa [bernoulli2Diff] using (measurable_const.sub (measurable_bernoulli2.comp hfract))

lemma bernoulli2Diff_eq_mul (x : ℝ) :
    bernoulli2Diff x = Int.fract x * (1 - Int.fract x) := by
  simp [bernoulli2Diff, bernoulli2]
  ring_nf

lemma bernoulli2Diff_bounds (x : ℝ) :
    0 ≤ bernoulli2Diff x ∧ bernoulli2Diff x ≤ (1 / 4 : ℝ) := by
  set t : ℝ := Int.fract x
  have ht0 : 0 ≤ t := Int.fract_nonneg x
  have ht1 : t ≤ 1 := (le_of_lt (Int.fract_lt_one x))
  have hquad : 0 ≤ (t - (1 / 2 : ℝ)) ^ 2 := by nlinarith
  have hupper : t * (1 - t) ≤ (1 / 4 : ℝ) := by
    -- Expand (t - 1/2)^2 >= 0
    nlinarith
  have hnonneg : 0 ≤ t * (1 - t) := by nlinarith [ht0, ht1]
  have hmul : bernoulli2Diff x = t * (1 - t) := by
    simpa [t] using (bernoulli2Diff_eq_mul x)
  refine ⟨?_, ?_⟩
  · simpa [hmul] using hnonneg
  · simpa [hmul] using hupper

lemma bernoulli2Diff_norm_le (x : ℝ) :
    ‖(bernoulli2Diff x : ℂ)‖ ≤ (1 / 4 : ℝ) := by
  have hb0 : 0 ≤ bernoulli2Diff x := (bernoulli2Diff_bounds x).1
  have hb1 : bernoulli2Diff x ≤ (1 / 4 : ℝ) := (bernoulli2Diff_bounds x).2
  have habs : |bernoulli2Diff x| = bernoulli2Diff x := by
    simp [abs_of_nonneg hb0]
  have hnorm : ‖(bernoulli2Diff x : ℂ)‖ = |bernoulli2Diff x| := by
    simp
  simpa [hnorm, habs] using hb1

lemma bernoulli2Diff_int (n : ℤ) : bernoulli2Diff (n : ℝ) = 0 := by
  simp [bernoulli2Diff, bernoulli2]

lemma fract_eq_sub_nat_on_Ioo (n : ℕ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n + 1 : ℝ)) :
    Int.fract x = x - n := by
  have hx0 : 0 ≤ x - n := by nlinarith [hx.1]
  have hx1 : x - n < 1 := by nlinarith [hx.2]
  have hfract : Int.fract (x - n) = x - n := by
    exact (Int.fract_eq_self).2 ⟨hx0, hx1⟩
  have hshift : Int.fract x = Int.fract (x - n) := by
    simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using
      (Int.fract_add_natCast (a := x - n) (m := n))
  calc
    Int.fract x = Int.fract (x - n) := hshift
    _ = x - n := hfract

lemma bernoulli1Fract_eq_on_Ioo (n : ℕ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n + 1 : ℝ)) :
    bernoulli1Fract x = x - n - (1 / 2 : ℝ) := by
  simp [bernoulli1Fract, bernoulli1, fract_eq_sub_nat_on_Ioo n hx, sub_eq_add_neg, add_assoc]

lemma bernoulli2Diff_eq_on_Ioo (n : ℕ) {x : ℝ}
    (hx : x ∈ Set.Ioo (n : ℝ) (n + 1 : ℝ)) :
    bernoulli2Diff x = (x - n) - (x - n) ^ 2 := by
  have hfract : Int.fract x = x - n := fract_eq_sub_nat_on_Ioo n hx
  simp [bernoulli2Diff, bernoulli2, hfract, pow_two, sub_eq_add_neg, add_assoc]

lemma add_ne_zero_of_re_pos {z : ℂ} (hz : 0 < z.re) {x : ℝ} (hx : 0 ≤ x) :
    (x : ℂ) + z ≠ 0 := by
  intro hzero
  have hrew : ((x : ℂ) + z).re = x + z.re := by simp
  have hzero' : x + z.re = 0 := by
    simpa [hrew] using congrArg Complex.re hzero
  have hpos : 0 < x + z.re := by nlinarith [hz, hx]
  linarith

lemma add_mem_slitPlane_of_re_pos {z : ℂ} (hz : 0 < z.re) {x : ℝ} (hx : 0 ≤ x) :
    (x : ℂ) + z ∈ Complex.slitPlane := by
  have hnot : ¬ (x : ℂ) + z ≤ 0 := by
    intro hle
    have hrew : ((x : ℂ) + z).re = x + z.re := by simp
    have hle' : x + z.re ≤ 0 := by
      simpa [hrew] using (Complex.re_le_re hle)
    have hpos : 0 < x + z.re := by nlinarith [hz, hx]
    linarith
  exact (Complex.mem_slitPlane_iff_not_le_zero).2 hnot

lemma hasDerivAt_inv_add (z : ℂ) {x : ℝ} (hx : (x : ℂ) + z ≠ 0) :
    HasDerivAt (fun x : ℝ => ((x : ℂ) + z)⁻¹) (-(1 : ℂ) / ((x : ℂ) + z) ^ 2) x := by
  have h_ofReal : HasDerivAt (fun x : ℝ => (x : ℂ)) (1 : ℂ) x := by
    simpa using (hasDerivAt_id (x : ℂ)).comp_ofReal
  have h_add : HasDerivAt (fun w : ℂ => w + z) (1 : ℂ) (x : ℂ) := by
    simpa using (hasDerivAt_id (x : ℂ)).add_const z
  have h_inv : HasDerivAt (fun w : ℂ => (w + z)⁻¹)
      (-(1 : ℂ) / ((x : ℂ) + z) ^ 2) (x : ℂ) := by
    simpa [one_div] using (h_add.inv hx)
  simpa using (h_inv.comp x h_ofReal)

lemma hasDerivAt_log_add (z : ℂ) {x : ℝ} (hx : (x : ℂ) + z ∈ Complex.slitPlane) :
    HasDerivAt (fun x : ℝ => Complex.log ((x : ℂ) + z)) (((x : ℂ) + z)⁻¹) x := by
  have h_ofReal : HasDerivAt (fun x : ℝ => (x : ℂ)) (1 : ℂ) x := by
    simpa using (hasDerivAt_id (x : ℂ)).comp_ofReal
  have h_add : HasDerivAt (fun x : ℝ => (x : ℂ) + z) (1 : ℂ) x := by
    simpa using h_ofReal.add_const z
  have h_log : HasDerivAt (fun w : ℂ => Complex.log w) (((x : ℂ) + z)⁻¹) ((x : ℂ) + z) :=
    Complex.hasDerivAt_log hx
  simpa using (h_log.comp x h_add)

lemma stieltjes_interval_identity (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹ =
      (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
        ∫ x in (n : ℝ)..(n + 1 : ℝ),
          ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (-(((x : ℂ) + z) ^ 2)⁻¹)) := by
  classical
  let u : ℝ → ℂ := fun x => (x - (n : ℝ) - (1 / 2 : ℝ) : ℂ)
  let u' : ℝ → ℂ := fun _ => (1 : ℂ)
  let v : ℝ → ℂ := fun x => ((x : ℂ) + z)⁻¹
  let v' : ℝ → ℂ := fun x => -(((x : ℂ) + z) ^ 2)⁻¹
  have hu : ∀ x ∈ Set.uIcc (n : ℝ) (n + 1 : ℝ), HasDerivAt u (u' x) x := by
    intro x hx
    have h_id : HasDerivAt (fun x : ℝ => (x : ℂ)) (1 : ℂ) x := by
      simpa using (hasDerivAt_id (x : ℂ)).comp_ofReal
    have h1 : HasDerivAt (fun x : ℝ => (x : ℂ) - (n : ℂ)) (1 : ℂ) x := by
      simpa using h_id.sub_const (n : ℂ)
    simpa [u, u', sub_eq_add_neg, add_assoc] using h1.sub_const (1 / 2 : ℂ)
  have hv : ∀ x ∈ Set.uIcc (n : ℝ) (n + 1 : ℝ), HasDerivAt v (v' x) x := by
    intro x hx
    have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
      have hle : (n : ℝ) ≤ n + 1 := by nlinarith
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := by
      have hn0 : (0 : ℝ) ≤ n := by exact_mod_cast (Nat.cast_nonneg n)
      exact le_trans hn0 hx'.1
    have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
    simpa [v, v', one_div, div_eq_mul_inv] using (hasDerivAt_inv_add z hneq)
  have hu' : IntervalIntegrable u' volume (n : ℝ) (n + 1 : ℝ) := by
    simpa [u'] using
      (intervalIntegrable_const (a := (n : ℝ)) (b := (n + 1 : ℝ)) (μ := volume) (c := (1 : ℂ)))
  have hv' : IntervalIntegrable v' volume (n : ℝ) (n + 1 : ℝ) := by
    have hcont : ContinuousOn v' (Set.uIcc (n : ℝ) (n + 1 : ℝ)) := by
      intro x hx
      have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
        have hle : (n : ℝ) ≤ n + 1 := by nlinarith
        simpa [Set.uIcc_of_le hle] using hx
      have hx0 : 0 ≤ x := by
        have hn0 : (0 : ℝ) ≤ n := by exact_mod_cast (Nat.cast_nonneg n)
        exact le_trans hn0 hx'.1
      have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
      have hcont_add :
          ContinuousAt (fun x : ℝ => (x : ℂ) + z) x := by
        simpa using (Complex.continuous_ofReal.continuousAt.add continuous_const.continuousAt)
      have hcont_pow :
          ContinuousAt (fun x : ℝ => ((x : ℂ) + z) ^ 2) x := hcont_add.pow 2
      have hne : ((x : ℂ) + z) ^ 2 ≠ 0 := by
        exact pow_ne_zero 2 hneq
      have hcont_inv :
          ContinuousAt (fun x : ℝ => (((x : ℂ) + z) ^ 2)⁻¹) x :=
        (ContinuousAt.inv₀ hcont_pow hne)
      have hcont_neg :
          ContinuousAt (fun x : ℝ => -(((x : ℂ) + z) ^ 2)⁻¹) x := hcont_inv.neg
      have hrewrite : (fun x : ℝ => -(((x : ℂ) + z) ^ 2)⁻¹) = v' := by
        rfl
      simpa [hrewrite] using hcont_neg.continuousWithinAt
    exact hcont.intervalIntegrable
  have hparts :=
    intervalIntegral.integral_mul_deriv_eq_deriv_mul (a := (n : ℝ)) (b := (n + 1 : ℝ))
      (u := u) (u' := u') (v := v) (v' := v') hu hv hu' hv'
  have hsum :
      (∫ x in (n : ℝ)..(n + 1 : ℝ), v x) +
        ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x =
        u (n + 1 : ℝ) * v (n + 1 : ℝ) - u (n : ℝ) * v (n : ℝ) := by
    have hparts' := (eq_sub_iff_add_eq).1 hparts
    simpa [u', add_comm, add_left_comm, add_assoc, mul_comm, mul_left_comm, mul_assoc] using hparts'
  have hfinal :
      ∫ x in (n : ℝ)..(n + 1 : ℝ), v x =
        u (n + 1 : ℝ) * v (n + 1 : ℝ) - u (n : ℝ) * v (n : ℝ) -
          ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x := by
    refine (eq_sub_iff_add_eq).2 ?_
    simpa [add_comm, add_left_comm, add_assoc] using hsum
  have hu_left : u (n : ℝ) = (-(2 : ℂ)⁻¹) := by
    simp [u]
  have hu_right : u (n + 1 : ℝ) = (2 : ℂ)⁻¹ := by
    simp [u]
    norm_num
  calc
    ∫ x in (n : ℝ)..(n + 1 : ℝ), v x
        = u (n + 1 : ℝ) * v (n + 1 : ℝ) - u (n : ℝ) * v (n : ℝ) -
            ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x := hfinal
    _ = (1 / 2 : ℂ) * (v (n : ℝ) + v (n + 1 : ℝ)) -
          ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x := by
      simp [hu_left, hu_right, add_comm, add_left_comm, add_assoc, mul_add, sub_eq_add_neg, one_div]
    _ = (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
          ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x := by
      simp [v, add_comm, add_left_comm, add_assoc]
    _ = (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
          ∫ x in (n : ℝ)..(n + 1 : ℝ),
            ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (-(((x : ℂ) + z) ^ 2)⁻¹)) := by
      simp [u, v']

lemma stieltjes_interval_identity_pos (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹ =
      (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) +
        ∫ x in (n : ℝ)..(n + 1 : ℝ),
          ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 2)⁻¹) := by
  have h := stieltjes_interval_identity z hz n
  -- move the negative sign inside the integral
  simpa [sub_eq_add_neg, mul_neg, neg_mul, one_div] using h

lemma stieltjes_interval_B1_to_B2 (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    ∫ x in (n : ℝ)..(n + 1 : ℝ),
        ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * ((1 : ℂ) / ((x : ℂ) + z) ^ 2)) =
      -∫ x in (n : ℝ)..(n + 1 : ℝ),
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3 := by
  classical
  let u : ℝ → ℂ := fun x =>
    (x : ℂ) + -(n : ℂ) + -(((x : ℂ) + -(n : ℂ)) ^ 2)
  let u' : ℝ → ℂ := fun x => (1 : ℂ) - (2 : ℂ) * ((x : ℂ) - (n : ℂ))
  let v : ℝ → ℂ := fun x => (1 : ℂ) / ((x : ℂ) + z) ^ 2
  let v' : ℝ → ℂ := fun x => -(2 : ℂ) * (((x : ℂ) + z) ^ 3)⁻¹
  have hu : ∀ x ∈ Set.uIcc (n : ℝ) (n + 1 : ℝ), HasDerivAt u (u' x) x := by
    intro x hx
    have h_id : HasDerivAt (fun x : ℝ => (x : ℂ)) (1 : ℂ) x := by
      simpa using (hasDerivAt_id (x : ℂ)).comp_ofReal
    have h_sub : HasDerivAt (fun x : ℝ => (x : ℂ) - (n : ℂ)) (1 : ℂ) x := by
      simpa using h_id.sub_const (n : ℂ)
    have h_sq :
        HasDerivAt (fun x : ℝ => ((x : ℂ) - (n : ℂ)) ^ 2)
          ((2 : ℂ) * ((x : ℂ) - (n : ℂ))) x := by
      simpa [pow_two, mul_comm, mul_left_comm, mul_assoc] using (h_sub.pow 2)
    have h := h_sub.sub h_sq
    -- rewrite the function and derivative to match `u` and `u'`
    convert h using 1 <;>
      simp [u, u', sub_eq_add_neg, add_assoc, add_left_comm, add_comm]
  have hv : ∀ x ∈ Set.uIcc (n : ℝ) (n + 1 : ℝ), HasDerivAt v (v' x) x := by
    intro x hx
    have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
      have hle : (n : ℝ) ≤ n + 1 := by nlinarith
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := by
      have hn0 : (0 : ℝ) ≤ n := by exact_mod_cast (Nat.cast_nonneg n)
      exact le_trans hn0 hx'.1
    have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
    have h_inv : HasDerivAt (fun x : ℝ => ((x : ℂ) + z)⁻¹)
        (-(1 : ℂ) / ((x : ℂ) + z) ^ 2) x :=
      hasDerivAt_inv_add z hneq
    have h_pow :
        HasDerivAt (fun x : ℝ => ((x : ℂ) + z)⁻¹ ^ 2)
          ((2 : ℂ) * ((x : ℂ) + z)⁻¹ * (-(1 : ℂ) / ((x : ℂ) + z) ^ 2)) x := by
      simpa [pow_two, mul_comm, mul_left_comm, mul_assoc, one_div] using (h_inv.pow 2)
    have hrewrite :
        (2 : ℂ) * ((x : ℂ) + z)⁻¹ * (-(1 : ℂ) / ((x : ℂ) + z) ^ 2) =
          -(2 : ℂ) / ((x : ℂ) + z) ^ 3 := by
      field_simp [hneq]
    have hpow' :
        HasDerivAt (fun x : ℝ => ((x : ℂ) + z)⁻¹ ^ 2) (-(2 : ℂ) / ((x : ℂ) + z) ^ 3) x := by
      simpa [hrewrite] using h_pow
    simpa [v, v', pow_two, one_div, div_eq_mul_inv] using hpow'
  have hu' : IntervalIntegrable u' volume (n : ℝ) (n + 1 : ℝ) := by
    have hcont : Continuous u' := by
      have hcont_sub : Continuous fun x : ℝ => (x : ℂ) - (n : ℂ) :=
        Complex.continuous_ofReal.sub continuous_const
      have hcont_mul : Continuous fun x : ℝ => (2 : ℂ) * ((x : ℂ) - (n : ℂ)) :=
        continuous_const.mul hcont_sub
      simpa [u', sub_eq_add_neg] using (continuous_const.sub hcont_mul)
    simpa [u'] using (hcont.intervalIntegrable (a := (n : ℝ)) (b := (n + 1 : ℝ)) (μ := volume))
  have hv' : IntervalIntegrable v' volume (n : ℝ) (n + 1 : ℝ) := by
    have hcont : ContinuousOn v' (Set.uIcc (n : ℝ) (n + 1 : ℝ)) := by
      intro x hx
      have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
        have hle : (n : ℝ) ≤ n + 1 := by nlinarith
        simpa [Set.uIcc_of_le hle] using hx
      have hx0 : 0 ≤ x := by
        have hn0 : (0 : ℝ) ≤ n := by exact_mod_cast (Nat.cast_nonneg n)
        exact le_trans hn0 hx'.1
      have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
      have hcont_add :
          ContinuousAt (fun x : ℝ => (x : ℂ) + z) x := by
        simpa using (Complex.continuous_ofReal.continuousAt.add continuous_const.continuousAt)
      have hcont_inv :
          ContinuousAt (fun x : ℝ => ((x : ℂ) + z)⁻¹) x :=
        (ContinuousAt.inv₀ hcont_add hneq)
      have hcont_pow :
          ContinuousAt (fun x : ℝ => ((x : ℂ) + z) ^ 3) x := hcont_add.pow 3
      have hne : ((x : ℂ) + z) ^ 3 ≠ 0 := by
        exact pow_ne_zero 3 hneq
      have hcont_inv :
          ContinuousAt (fun x : ℝ => (((x : ℂ) + z) ^ 3)⁻¹) x :=
        (ContinuousAt.inv₀ hcont_pow hne)
      have hcont_mul :
          ContinuousAt (fun x : ℝ => (2 : ℂ) * (((x : ℂ) + z) ^ 3)⁻¹) x := by
        simpa using hcont_inv.const_mul (2 : ℂ)
      have hcont_neg :
          ContinuousAt (fun x : ℝ => -(2 * (((x : ℂ) + z) ^ 3)⁻¹)) x := by
        simpa using hcont_mul.neg
      have hrewrite : (fun x : ℝ => -(2 * (((x : ℂ) + z) ^ 3)⁻¹)) = v' := by
        ext x
        simp [v', neg_mul, mul_comm, mul_left_comm, mul_assoc]
      simpa [hrewrite] using hcont_neg.continuousWithinAt
    exact hcont.intervalIntegrable
  have hparts :=
    intervalIntegral.integral_mul_deriv_eq_deriv_mul (a := (n : ℝ)) (b := (n + 1 : ℝ))
      (u := u) (u' := u') (v := v) (v' := v') hu hv hu' hv'
  have hu_left : u (n : ℝ) = 0 := by
    simp [u]
  have hu_right : u (n + 1 : ℝ) = 0 := by
    simp [u, pow_two, add_assoc, add_left_comm, add_comm]
  have hparts' :
      ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x =
        -∫ x in (n : ℝ)..(n + 1 : ℝ), u' x * v x := by
    simpa [hu_left, hu_right] using hparts
  have h_u' :
      ∀ x, u' x = -(2 : ℂ) * (x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) := by
    intro x
    simp [u', sub_eq_add_neg, add_assoc, add_left_comm, add_comm]
    ring_nf
  have h_u'v :
      ∫ x in (n : ℝ)..(n + 1 : ℝ), u' x * v x =
        (-(2 : ℂ)) * ∫ x in (n : ℝ)..(n + 1 : ℝ),
          ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * v x) := by
    have hfun :
        (fun x : ℝ => u' x * v x) =
          fun x : ℝ => (-(2 : ℂ)) * ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * v x) := by
      ext x
      simp [h_u' x, mul_assoc, mul_left_comm, mul_comm]
    simpa [hfun] using
      (intervalIntegral.integral_const_mul (c := (-(2 : ℂ)))
        (f := fun x : ℝ => ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * v x))
        (a := (n : ℝ)) (b := (n + 1 : ℝ)) (μ := volume))
  have h_uv' :
      ∫ x in (n : ℝ)..(n + 1 : ℝ), u x * v' x =
        (-(2 : ℂ)) * ∫ x in (n : ℝ)..(n + 1 : ℝ),
          u x / ((x : ℂ) + z) ^ 3 := by
    have hfun :
        (fun x : ℝ => u x * v' x) =
          fun x : ℝ => (-(2 : ℂ)) * (u x / ((x : ℂ) + z) ^ 3) := by
      ext x
      simp [v', div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm]
    simpa [hfun] using
      (intervalIntegral.integral_const_mul (c := (-(2 : ℂ)))
        (f := fun x : ℝ => u x / ((x : ℂ) + z) ^ 3)
        (a := (n : ℝ)) (b := (n + 1 : ℝ)) (μ := volume))
  have hrel :
      ∫ x in (n : ℝ)..(n + 1 : ℝ),
          ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * v x) =
        -∫ x in (n : ℝ)..(n + 1 : ℝ),
          u x / ((x : ℂ) + z) ^ 3 := by
    have htmp := congrArg (fun t => (-(1 / 2 : ℂ)) * t) hparts'
    simp [h_u'v, h_uv', mul_add, mul_comm, mul_left_comm, mul_assoc] at htmp
    have htmp' := congrArg (fun t => -t) htmp.symm
    simpa [mul_comm, mul_left_comm, mul_assoc] using htmp'
  calc
    ∫ x in (n : ℝ)..(n + 1 : ℝ),
        ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * v x)
        = -∫ x in (n : ℝ)..(n + 1 : ℝ),
            u x / ((x : ℂ) + z) ^ 3 := by
              simpa [v] using hrel
    _ = -∫ x in (n : ℝ)..(n + 1 : ℝ),
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3 := by
          simp [u, sub_eq_add_neg, div_eq_mul_inv, pow_succ, pow_two, add_assoc, add_left_comm,
            add_comm, mul_comm, mul_left_comm, mul_assoc]

lemma stieltjes_interval_B1_to_B2Diff (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    ∫ x in (n : ℝ)..(n + 1 : ℝ),
        ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 2)⁻¹) =
      -∫ x in (n : ℝ)..(n + 1 : ℝ),
          (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
  have h :=
    (stieltjes_interval_B1_to_B2 z hz n)
  have h' :
      ∫ x in (n : ℝ)..(n + 1 : ℝ),
          ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 2)⁻¹) =
        -∫ x in (n : ℝ)..(n + 1 : ℝ),
            (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3 := by
    simpa [one_div] using h
  have h_eq :
      EqOn
        (fun x : ℝ => (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ))
        (fun x : ℝ => (bernoulli2Diff x : ℂ))
        (Set.Icc (n : ℝ) (n + 1 : ℝ)) := by
    intro x hx
    by_cases hx0 : x = n
    · simp [hx0, bernoulli2Diff, bernoulli2]
    by_cases hx1 : x = n + 1
    · simp [hx1, bernoulli2Diff, bernoulli2]
    have hx' : x ∈ Set.Ioo (n : ℝ) (n + 1 : ℝ) := by
      refine ⟨?_, ?_⟩
      · exact lt_of_le_of_ne hx.1 (Ne.symm hx0)
      · exact lt_of_le_of_ne hx.2 hx1
    have hreal : bernoulli2Diff x = (x - n) - (x - n) ^ 2 :=
      bernoulli2Diff_eq_on_Ioo n hx'
    simpa [hreal]
  have h_int :
      ∫ x in (n : ℝ)..(n + 1 : ℝ),
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3 =
        ∫ x in (n : ℝ)..(n + 1 : ℝ),
          (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
    refine intervalIntegral.integral_congr ?_
    intro x hx
    have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
      simpa using hx
    have h' := h_eq hx'
    simpa [h'] 
  calc
    ∫ x in (n : ℝ)..(n + 1 : ℝ),
        ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 2)⁻¹)
        = -∫ x in (n : ℝ)..(n + 1 : ℝ),
            (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3 := h'
    _ = -∫ x in (n : ℝ)..(n + 1 : ℝ),
          (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
          simpa using (congrArg (fun t => -t) h_int)

lemma intervalIntegral_inv_eq_log (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹ =
      Complex.log (z + (N : ℂ)) - Complex.log z := by
  classical
  let f : ℝ → ℂ := fun x => Complex.log ((x : ℂ) + z)
  let f' : ℝ → ℂ := fun x => ((x : ℂ) + z)⁻¹
  have hdiff : ∀ x ∈ Set.uIcc (0 : ℝ) (N : ℝ), DifferentiableAt ℝ f x := by
    intro x hx
    have hle : (0 : ℝ) ≤ (N : ℝ) := by exact_mod_cast (Nat.cast_nonneg N)
    have hx' : x ∈ Set.Icc (0 : ℝ) (N : ℝ) := by
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := hx'.1
    have hslit : (x : ℂ) + z ∈ Complex.slitPlane :=
      add_mem_slitPlane_of_re_pos hz hx0
    simpa [f] using (hasDerivAt_log_add z hslit).differentiableAt
  have hderiv_eq : EqOn (fun x => deriv f x) f' (Set.uIcc (0 : ℝ) (N : ℝ)) := by
    intro x hx
    have hle : (0 : ℝ) ≤ (N : ℝ) := by exact_mod_cast (Nat.cast_nonneg N)
    have hx' : x ∈ Set.Icc (0 : ℝ) (N : ℝ) := by
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := hx'.1
    have hslit : (x : ℂ) + z ∈ Complex.slitPlane :=
      add_mem_slitPlane_of_re_pos hz hx0
    simpa [f, f'] using (hasDerivAt_log_add z hslit).deriv
  have hcont : ContinuousOn f' (Set.uIcc (0 : ℝ) (N : ℝ)) := by
    intro x hx
    have hle : (0 : ℝ) ≤ (N : ℝ) := by exact_mod_cast (Nat.cast_nonneg N)
    have hx' : x ∈ Set.Icc (0 : ℝ) (N : ℝ) := by
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := hx'.1
    have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
    have hcont_add :
        ContinuousAt (fun x : ℝ => (x : ℂ) + z) x := by
      simpa using (Complex.continuous_ofReal.continuousAt.add continuous_const.continuousAt)
    have hcont_inv :
        ContinuousAt (fun x : ℝ => ((x : ℂ) + z)⁻¹) x :=
      (ContinuousAt.inv₀ hcont_add hneq)
    simpa [f'] using hcont_inv.continuousWithinAt
  have h_int_f' : IntervalIntegrable f' volume (0 : ℝ) (N : ℝ) :=
    hcont.intervalIntegrable
  have h_eq_uIoc :
      EqOn (fun x => deriv f x) f' (Set.uIoc (0 : ℝ) (N : ℝ)) := by
    intro x hx
    have hle : (0 : ℝ) ≤ (N : ℝ) := by exact_mod_cast (Nat.cast_nonneg N)
    have hx' : x ∈ Set.uIcc (0 : ℝ) (N : ℝ) := by
      have hxIoc : x ∈ Set.Ioc (0 : ℝ) (N : ℝ) := by
        simpa [Set.uIoc_of_le hle] using hx
      have hxIcc : x ∈ Set.Icc (0 : ℝ) (N : ℝ) :=
        ⟨le_of_lt hxIoc.1, hxIoc.2⟩
      simpa [Set.uIcc_of_le hle] using hxIcc
    exact hderiv_eq hx'
  have h_int_deriv : IntervalIntegrable (deriv f) volume (0 : ℝ) (N : ℝ) := by
    have hiff := (intervalIntegrable_congr (μ := volume) (a := (0 : ℝ)) (b := (N : ℝ))
      (f := deriv f) (g := f') h_eq_uIoc)
    exact (hiff.mpr h_int_f')
  have hFTC :
      ∫ x in (0 : ℝ)..(N : ℝ), deriv f x = f (N : ℝ) - f (0 : ℝ) :=
    intervalIntegral.integral_deriv_eq_sub hdiff h_int_deriv
  have h_int_eq :
      ∫ x in (0 : ℝ)..(N : ℝ), deriv f x =
        ∫ x in (0 : ℝ)..(N : ℝ), f' x := by
    refine intervalIntegral.integral_congr ?_
    intro x hx
    exact hderiv_eq hx
  calc
    ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹
        = ∫ x in (0 : ℝ)..(N : ℝ), f' x := by rfl
    _ = ∫ x in (0 : ℝ)..(N : ℝ), deriv f x := by
          simpa using h_int_eq.symm
    _ = f (N : ℝ) - f (0 : ℝ) := hFTC
    _ = Complex.log (z + (N : ℂ)) - Complex.log z := by
          simp [f, add_comm, add_left_comm, add_assoc]

lemma intervalIntegrable_inv_add_nat (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    IntervalIntegrable (fun x : ℝ => ((x : ℂ) + z)⁻¹) volume (n : ℝ) (n + 1 : ℝ) := by
  have hcont : ContinuousOn (fun x : ℝ => ((x : ℂ) + z)⁻¹)
      (Set.uIcc (n : ℝ) (n + 1 : ℝ)) := by
    intro x hx
    have hle : (n : ℝ) ≤ (n + 1 : ℝ) := by nlinarith
    have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := by
      have hn0 : (0 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (Nat.cast_nonneg n)
      exact le_trans hn0 hx'.1
    have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
    have hcont_add :
        ContinuousAt (fun x : ℝ => (x : ℂ) + z) x := by
      simpa using (Complex.continuous_ofReal.continuousAt.add continuous_const.continuousAt)
    have hcont_inv :
        ContinuousAt (fun x : ℝ => ((x : ℂ) + z)⁻¹) x :=
      (ContinuousAt.inv₀ hcont_add hneq)
    simpa using hcont_inv.continuousWithinAt
  exact hcont.intervalIntegrable

lemma intervalIntegrable_b2diff_div_nat (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    IntervalIntegrable (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
      volume (n : ℝ) (n + 1 : ℝ) := by
  have h_eq :
      EqOn
        (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
        (fun x : ℝ =>
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3)
        (Set.uIoc (n : ℝ) (n + 1 : ℝ)) := by
    intro x hx
    have hle : (n : ℝ) ≤ (n + 1 : ℝ) := by nlinarith
    have hxIoc : x ∈ Set.Ioc (n : ℝ) (n + 1 : ℝ) := by
      simpa [Set.uIoc_of_le hle] using hx
    by_cases hx1 : x = n + 1
    · simp [hx1, bernoulli2Diff, bernoulli2]
    have hx' : x ∈ Set.Ioo (n : ℝ) (n + 1 : ℝ) := by
      refine ⟨hxIoc.1, ?_⟩
      exact lt_of_le_of_ne hxIoc.2 hx1
    have hreal : bernoulli2Diff x = (x - n) - (x - n) ^ 2 :=
      bernoulli2Diff_eq_on_Ioo n hx'
    simp [hreal]
  have hcont_poly :
      ContinuousOn
        (fun x : ℝ =>
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3)
        (Set.uIcc (n : ℝ) (n + 1 : ℝ)) := by
    intro x hx
    have hle : (n : ℝ) ≤ (n + 1 : ℝ) := by nlinarith
    have hx' : x ∈ Set.Icc (n : ℝ) (n + 1 : ℝ) := by
      simpa [Set.uIcc_of_le hle] using hx
    have hx0 : 0 ≤ x := by
      have hn0 : (0 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (Nat.cast_nonneg n)
      exact le_trans hn0 hx'.1
    have hneq : (x : ℂ) + z ≠ 0 := add_ne_zero_of_re_pos hz hx0
    have hcont_num :
        ContinuousAt
          (fun x : ℝ => (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ)) x := by
      have hcont_id : ContinuousAt (fun x : ℝ => (x : ℂ)) x := by
        simpa using (Complex.continuous_ofReal.continuousAt)
      have hcont_sub : ContinuousAt (fun x : ℝ => (x : ℂ) - (n : ℂ)) x := by
        simpa using hcont_id.sub_const (n : ℂ)
      have hcont_sq :
          ContinuousAt (fun x : ℝ => ((x : ℂ) - (n : ℂ)) ^ 2) x := by
        simpa using hcont_sub.pow 2
      have hcont_diff :
          ContinuousAt (fun x : ℝ => (x : ℂ) - (n : ℂ) - ((x : ℂ) - (n : ℂ)) ^ 2) x := by
        simpa [sub_eq_add_neg, add_assoc] using hcont_sub.sub hcont_sq
      simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using hcont_diff
    have hcont_add :
        ContinuousAt (fun x : ℝ => (x : ℂ) + z) x := by
      simpa using (Complex.continuous_ofReal.continuousAt.add continuous_const.continuousAt)
    have hcont_pow :
        ContinuousAt (fun x : ℝ => ((x : ℂ) + z) ^ 3) x := hcont_add.pow 3
    have hne : ((x : ℂ) + z) ^ 3 ≠ 0 := pow_ne_zero 3 hneq
    have hcont_inv :
        ContinuousAt (fun x : ℝ => (((x : ℂ) + z) ^ 3)⁻¹) x :=
      (ContinuousAt.inv₀ hcont_pow hne)
    have hcont_mul :
        ContinuousAt
          (fun x : ℝ =>
            (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 3)⁻¹) x :=
      hcont_num.mul hcont_inv
    simpa [div_eq_mul_inv] using hcont_mul.continuousWithinAt
  have h_int_poly :
      IntervalIntegrable
        (fun x : ℝ =>
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3)
        volume (n : ℝ) (n + 1 : ℝ) :=
    hcont_poly.intervalIntegrable
  have h_eq_uIoc :
      EqOn
        (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
        (fun x : ℝ =>
          (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3)
        (Set.uIoc (n : ℝ) (n + 1 : ℝ)) := h_eq
  have hiff := (intervalIntegrable_congr (μ := volume) (a := (n : ℝ)) (b := (n + 1 : ℝ))
    (f := fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
    (g := fun x : ℝ =>
      (((x - (n : ℝ)) - (x - (n : ℝ)) ^ 2 : ℝ) : ℂ) / ((x : ℂ) + z) ^ 3) h_eq_uIoc)
  exact hiff.mpr h_int_poly

lemma sum_trapezoid_eq_sum (z : ℂ) (N : ℕ) :
    Finset.sum (Finset.range N)
        (fun n =>
          (1 / 2 : ℂ) * (((z + (n : ℂ))⁻¹) + ((z + (n + 1 : ℂ))⁻¹))) =
      Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹) +
        (1 / 2 : ℂ) * (((z + (N : ℂ))⁻¹) - (z : ℂ)⁻¹) := by
  classical
  let a : ℕ → ℂ := fun n => (z + (n : ℂ))⁻¹
  have hshift :
      Finset.sum (Finset.range N) (fun n => a (n + 1)) =
        Finset.sum (Finset.range N) (fun n => a n) + a N - a 0 := by
    have hsum_shift :
        Finset.sum (Finset.range (N + 1)) (fun n => a n) =
          Finset.sum (Finset.range N) (fun n => a (n + 1)) + a 0 := by
      simpa using (Finset.sum_range_succ' a N)
    have hsum_range :
        Finset.sum (Finset.range (N + 1)) (fun n => a n) =
          Finset.sum (Finset.range N) (fun n => a n) + a N := by
      simpa using (Finset.sum_range_succ a N)
    calc
      Finset.sum (Finset.range N) (fun n => a (n + 1))
          = Finset.sum (Finset.range (N + 1)) (fun n => a n) - a 0 := by
              refine (eq_sub_iff_add_eq).2 ?_
              simpa [add_comm, add_left_comm, add_assoc] using hsum_shift.symm
      _ = (Finset.sum (Finset.range N) (fun n => a n) + a N) - a 0 := by
              simpa [hsum_range]
      _ = Finset.sum (Finset.range N) (fun n => a n) + a N - a 0 := by
              ring
  have hsum_pair :
      Finset.sum (Finset.range N) (fun n => a n + a (n + 1)) =
        (2 : ℂ) * (Finset.sum (Finset.range N) (fun n => a n)) + a N - a 0 := by
    calc
      Finset.sum (Finset.range N) (fun n => a n + a (n + 1))
          = Finset.sum (Finset.range N) (fun n => a n) +
              Finset.sum (Finset.range N) (fun n => a (n + 1)) := by
              simp [Finset.sum_add_distrib]
      _ = Finset.sum (Finset.range N) (fun n => a n) +
            (Finset.sum (Finset.range N) (fun n => a n) + a N - a 0) := by
              simp [hshift]
      _ = (2 : ℂ) * (Finset.sum (Finset.range N) (fun n => a n)) + a N - a 0 := by
              ring
  calc
    Finset.sum (Finset.range N)
        (fun n =>
          (1 / 2 : ℂ) * (((z + (n : ℂ))⁻¹) + ((z + (n + 1 : ℂ))⁻¹)))
        = Finset.sum (Finset.range N) (fun n => (1 / 2 : ℂ) * (a n + a (n + 1))) := by
            simp [a]
    _ = (1 / 2 : ℂ) * Finset.sum (Finset.range N) (fun n => a n + a (n + 1)) := by
          simpa [mul_comm] using
            (Finset.mul_sum (a := (1 / 2 : ℂ)) (s := Finset.range N)
              (f := fun n => a n + a (n + 1))).symm
    _ = (1 / 2 : ℂ) * ((2 : ℂ) * (Finset.sum (Finset.range N) (fun n => a n)) + a N - a 0) := by
            simp [hsum_pair]
    _ = (Finset.sum (Finset.range N) (fun n => a n)) + (1 / 2 : ℂ) * (a N - a 0) := by
            ring
  -- unfold `a` at the end
  simp [a]

lemma sum_interval_integral_inv (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    Finset.sum (Finset.range N)
        (fun n => ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹) =
      ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹ := by
  classical
  have hint :
      ∀ k < N,
        IntervalIntegrable (fun x : ℝ => ((x : ℂ) + z)⁻¹) volume (k : ℝ) ((k + 1 : ℕ) : ℝ) := by
    intro k hk
    simpa [Nat.cast_add, Nat.cast_one] using intervalIntegrable_inv_add_nat z hz k
  simpa [Nat.cast_add, Nat.cast_one] using
    (intervalIntegral.sum_integral_adjacent_intervals
      (f := fun x : ℝ => ((x : ℂ) + z)⁻¹)
      (a := fun k : ℕ => (k : ℝ)) (n := N) (μ := volume) hint)

lemma sum_interval_integral_b2diff (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    Finset.sum (Finset.range N)
        (fun n =>
          ∫ x in (n : ℝ)..(n + 1 : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) =
      ∫ x in (0 : ℝ)..(N : ℝ),
        (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
  classical
  have hint :
      ∀ k < N,
        IntervalIntegrable (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
          volume (k : ℝ) ((k + 1 : ℕ) : ℝ) := by
    intro k hk
    simpa [Nat.cast_add, Nat.cast_one] using intervalIntegrable_b2diff_div_nat z hz k
  simpa [Nat.cast_add, Nat.cast_one] using
    (intervalIntegral.sum_integral_adjacent_intervals
      (f := fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
      (a := fun k : ℕ => (k : ℝ)) (n := N) (μ := volume) hint)

lemma sum_inv_eq_log_plus_integral (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹) =
      Complex.log (z + (N : ℂ)) - Complex.log z
        + (1 / 2 : ℂ) * (z⁻¹ - (z + (N : ℂ))⁻¹)
        + ∫ x in (0 : ℝ)..(N : ℝ), (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
  classical
  have hsum_identity :
      Finset.sum (Finset.range N)
          (fun n => ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹) =
        Finset.sum (Finset.range N) (fun n =>
          (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
            ∫ x in (n : ℝ)..(n + 1 : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
    refine Finset.sum_congr rfl ?_
    intro n hn
    have hpos := stieltjes_interval_identity_pos z hz n
    have hB := stieltjes_interval_B1_to_B2Diff z hz n
    calc
      ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹
          = (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) +
              ∫ x in (n : ℝ)..(n + 1 : ℝ),
                ((x - (n : ℝ) - (1 / 2 : ℝ) : ℂ) * (((x : ℂ) + z) ^ 2)⁻¹) := hpos
      _ = (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) +
            (-∫ x in (n : ℝ)..(n + 1 : ℝ),
                (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
            simpa using
              (congrArg
                (fun t =>
                  (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) + t) hB)
      _ = (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
            ∫ x in (n : ℝ)..(n + 1 : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
            simp [sub_eq_add_neg]
  have hsum_identity' :
      ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹ =
        Finset.sum (Finset.range N) (fun n =>
            (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) -
          ∫ x in (0 : ℝ)..(N : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
    have hsum_identity'1 :
        ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹ =
          Finset.sum (Finset.range N) (fun n =>
              (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) -
            Finset.sum (Finset.range N) (fun n =>
              ∫ x in (n : ℝ)..(n + 1 : ℝ),
                (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
      calc
        ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹
            = Finset.sum (Finset.range N)
                (fun n => ∫ x in (n : ℝ)..(n + 1 : ℝ), ((x : ℂ) + z)⁻¹) := by
                  simpa using (sum_interval_integral_inv z hz N).symm
        _ = Finset.sum (Finset.range N) (fun n =>
              (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹) -
                ∫ x in (n : ℝ)..(n + 1 : ℝ),
                  (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
              simpa using hsum_identity
        _ = Finset.sum (Finset.range N) (fun n =>
              (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) -
            Finset.sum (Finset.range N) (fun n =>
              ∫ x in (n : ℝ)..(n + 1 : ℝ),
                (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
              simpa [Finset.sum_sub_distrib]
    have hsum_b2 := sum_interval_integral_b2diff z hz N
    calc
      ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹
          =
        Finset.sum (Finset.range N) (fun n =>
            (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) -
          Finset.sum (Finset.range N) (fun n =>
            ∫ x in (n : ℝ)..(n + 1 : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := hsum_identity'1
      _ =
        Finset.sum (Finset.range N) (fun n =>
            (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) -
          ∫ x in (0 : ℝ)..(N : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
            simpa using
              (congrArg
                (fun t =>
                  Finset.sum (Finset.range N) (fun n =>
                      (1 / 2 : ℂ) * (((n : ℂ) + z)⁻¹ + ((n + 1 : ℂ) + z)⁻¹)) - t)
                hsum_b2)
  have hsum_identity'' :
      ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹ =
        (Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)) +
          (1 / 2 : ℂ) * (((z + (N : ℂ))⁻¹) - (z : ℂ)⁻¹) -
          ∫ x in (0 : ℝ)..(N : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
    have hsum_trap := sum_trapezoid_eq_sum z N
    have hsum_trap' :
        Finset.sum (Finset.range N)
            (fun n =>
              (1 / 2 : ℂ) * (((z + (n : ℂ))⁻¹) + ((z + (n + 1 : ℂ))⁻¹))) -
            ∫ x in (0 : ℝ)..(N : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3
          =
        (Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)) +
            (1 / 2 : ℂ) * (((z + (N : ℂ))⁻¹) - (z : ℂ)⁻¹) -
            ∫ x in (0 : ℝ)..(N : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
      exact
        (congrArg
          (fun t =>
            t - ∫ x in (0 : ℝ)..(N : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) hsum_trap)
    calc
      ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹
          =
        Finset.sum (Finset.range N) (fun n =>
            (1 / 2 : ℂ) * (((z + (n : ℂ))⁻¹) + ((z + (n + 1 : ℂ))⁻¹))) -
          ∫ x in (0 : ℝ)..(N : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
          -- align with the `sum_trapezoid_eq_sum` shape
          simpa [add_comm, add_left_comm, add_assoc, Nat.cast_add, Nat.cast_one, one_div]
            using hsum_identity'
      _ =
        (Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)) +
          (1 / 2 : ℂ) * (((z + (N : ℂ))⁻¹) - (z : ℂ)⁻¹) -
          ∫ x in (0 : ℝ)..(N : ℝ),
            (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
          simpa using hsum_trap'
  set Iint : ℂ := ∫ x in (0 : ℝ)..(N : ℝ), ((x : ℂ) + z)⁻¹
  set Jint : ℂ := ∫ x in (0 : ℝ)..(N : ℝ),
    (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3
  have hsum_main :
      Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹) =
        Iint + Jint -
          (2⁻¹ : ℂ) * ((z + (N : ℂ))⁻¹ + -z⁻¹) := by
    have h := congrArg (fun t => t + Jint) (by simpa [Iint, Jint] using hsum_identity'')
    have h' :
        Iint + Jint =
          (2⁻¹ : ℂ) * ((z + (N : ℂ))⁻¹ + -z⁻¹) +
            (Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)) := by
      simpa [Iint, Jint, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using h
    have h'' :
        Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹) =
          Iint + Jint -
            (2⁻¹ : ℂ) * ((z + (N : ℂ))⁻¹ + -z⁻¹) := by
      refine (eq_sub_iff_add_eq).2 ?_
      simpa [add_comm, add_left_comm, add_assoc] using h'.symm
    simpa using h''
  have hsum_main' :
      Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹) =
        Iint + Jint + (1 / 2 : ℂ) * (z⁻¹ - (z + (N : ℂ))⁻¹) := by
    calc
      Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)
          = Iint + Jint -
              (2⁻¹ : ℂ) * ((z + (N : ℂ))⁻¹ + -z⁻¹) := hsum_main
      _ = Iint + Jint + (1 / 2 : ℂ) * (z⁻¹ - (z + (N : ℂ))⁻¹) := by
          ring
  have hlog := intervalIntegral_inv_eq_log z hz N
  calc
    Finset.sum (Finset.range N) (fun n => (z + (n : ℂ))⁻¹)
        = (Complex.log (z + (N : ℂ)) - Complex.log z) +
            (1 / 2 : ℂ) * (z⁻¹ - (z + (N : ℂ))⁻¹) +
            ∫ x in (0 : ℝ)..(N : ℝ),
              (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
          -- rearrange `hsum_main` into the desired shape
          simpa [Iint, Jint, hlog, add_assoc, add_left_comm, add_comm] using hsum_main'

lemma digammaSeq_eq_stieltjes (z : ℂ) (hz : 0 < z.re) (N : ℕ) :
    _root_.digammaSeq z N =
      (Real.log N : ℂ) - Complex.log (z + (N : ℂ)) + Complex.log z
        - (1 / 2 : ℂ) * z⁻¹ - (1 / 2 : ℂ) * (z + (N : ℂ))⁻¹
        - ∫ x in (0 : ℝ)..(N : ℝ), (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
  classical
  have hsum_range :
      Finset.sum (Finset.range (N + 1)) (fun k => (z + (k : ℂ))⁻¹) =
        Finset.sum (Finset.range N) (fun k => (z + (k : ℂ))⁻¹) + (z + (N : ℂ))⁻¹ := by
    simpa using
      (Finset.sum_range_succ (f := fun k => (z + (k : ℂ))⁻¹) N)
  have hsum := sum_inv_eq_log_plus_integral z hz N
  calc
    _root_.digammaSeq z N
        = (Real.log N : ℂ) -
            ((Finset.sum (Finset.range N) (fun k => (z + (k : ℂ))⁻¹)) + (z + (N : ℂ))⁻¹) := by
            simp [digammaSeq, one_div, hsum_range, sub_eq_add_neg, add_assoc]
    _ = (Real.log N : ℂ) - (Finset.sum (Finset.range N) (fun k => (z + (k : ℂ))⁻¹)) -
            (z + (N : ℂ))⁻¹ := by
            ring
    _ = (Real.log N : ℂ) -
          (Complex.log (z + (N : ℂ)) - Complex.log z
            + (1 / 2 : ℂ) * (z⁻¹ - (z + (N : ℂ))⁻¹)
            + ∫ x in (0 : ℝ)..(N : ℝ),
                (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) -
          (z + (N : ℂ))⁻¹ := by
            simpa [hsum] using rfl
    _ = (Real.log N : ℂ) - Complex.log (z + (N : ℂ)) + Complex.log z
          - (1 / 2 : ℂ) * z⁻¹ - (1 / 2 : ℂ) * (z + (N : ℂ))⁻¹
          - ∫ x in (0 : ℝ)..(N : ℝ), (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3 := by
          ring_nf
/-!
Stieltjes (N=1) swap-derivative lemma (parameter differentiation under the integral).
This is the analytic core needed to remove `digamma_stieltjes_identity`.
-/
abbrev stieltjesF (w : ℂ) (x : ℝ) : ℂ :=
  (bernoulli2Diff x : ℂ) / (2 * (x + w) ^ 2)

abbrev stieltjesF' (w : ℂ) (x : ℝ) : ℂ :=
  -((bernoulli2Diff x : ℂ) / (x + w) ^ 3)

abbrev stieltjesBound (ε : ℝ) (x : ℝ) : ℝ :=
  (4 : ℝ)⁻¹ * ((x + ε) ^ 3)⁻¹

set_option maxHeartbeats 3000000 in
lemma stieltjes_integral_hasDerivAt (z : ℂ) (hz : 0 < z.re) :
    HasDerivAt
      (fun w => ∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (2 * (x + w) ^ 2))
      (-∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3) z := by
  classical
  -- Measure restricted to (0,∞)
  let μ : Measure ℝ := volume.restrict (Set.Ioi (0 : ℝ))
  -- Normalize integral notation to match the parametric integral lemma.
  change
    HasDerivAt (fun w => ∫ x, stieltjesF w x ∂μ)
      (-∫ x, (bernoulli2Diff x : ℂ) / (x + z) ^ 3 ∂μ) z
  -- Neighborhood radius
  let ε : ℝ := z.re / 2
  have hε : 0 < ε := by
    dsimp [ε]
    nlinarith [hz]
  have hball_re : ∀ {w : ℂ}, w ∈ Metric.ball z ε → ε ≤ w.re := by
    intro w hw
    have hdist : ‖w - z‖ < ε := by
      simpa [Metric.ball, dist_eq_norm] using hw
    have hrew : |w.re - z.re| ≤ ‖w - z‖ := by
      have h := RCLike.abs_re_le_norm (z := w - z)
      simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using h
    have habs : |w.re - z.re| < ε := lt_of_le_of_lt hrew hdist
    have hlow : z.re - ε < w.re := by
      have h := (abs_lt.mp habs).1
      linarith
    dsimp [ε] at hlow ⊢
    linarith [hz, hlow]
  -- measurability for F near z
  have hF_meas : ∀ᶠ w in 𝓝 z, AEStronglyMeasurable (stieltjesF w) μ := by
    refine Filter.Eventually.of_forall ?_
    intro w
    have hmeas : Measurable (fun x => stieltjesF w x) := by
      have hcoe : Measurable (fun x : ℝ => (x : ℂ)) := Complex.measurable_ofReal
      have h_add : Measurable (fun x : ℝ => (x : ℂ) + w) := hcoe.add measurable_const
      have h_pow : Measurable (fun x : ℝ => ((x : ℂ) + w) ^ 2) := h_add.pow_const 2
      have h_den : Measurable (fun x : ℝ => (2 : ℂ) * ((x : ℂ) + w) ^ 2) :=
        measurable_const.mul h_pow
      have h_num : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ)) :=
        (Complex.measurable_ofReal.comp measurable_bernoulli2Diff)
      exact h_num.div h_den
    simpa [μ] using hmeas.aestronglyMeasurable
  -- integrability of F at z using a crude (x+ε)^{-2} bound
  have hF_int : Integrable (stieltjesF z) μ := by
    -- |F z x| ≤ (1/8) * (x+ε)^{-2}
    have hbound :
        ∀ x ∈ Set.Ioi (0 : ℝ),
      ‖stieltjesF z x‖ ≤ (1 / 8 : ℝ) * (1 / (x + ε) ^ 2) := by
      intro x hx
      have hxpos : 0 < x := by simpa using hx
      have hxεpos : 0 < x + ε := by nlinarith [hxpos, hε]
      have hb0 : 0 ≤ bernoulli2Diff x := (bernoulli2Diff_bounds x).1
      have hb1 : bernoulli2Diff x ≤ (1 / 4 : ℝ) := (bernoulli2Diff_bounds x).2
      have hnorm_b : ‖(bernoulli2Diff x : ℂ)‖ ≤ (1 / 4 : ℝ) := by
        have habs : |bernoulli2Diff x| = bernoulli2Diff x := by
          simp [abs_of_nonneg hb0]
        have hnorm : ‖(bernoulli2Diff x : ℂ)‖ = |bernoulli2Diff x| := by
          simp
        simpa [hnorm, habs] using hb1
      have hεle : ε ≤ z.re := by
        dsimp [ε]
        exact half_le_self (le_of_lt hz)
      have hre : x + ε ≤ x + z.re := by nlinarith [hεle]
      have hnorm_ge : x + ε ≤ ‖(x : ℂ) + z‖ := by
        have h' : |x + z.re| ≤ ‖(x : ℂ) + z‖ := by
          simpa using (RCLike.abs_re_le_norm ((x : ℂ) + z))
        have hpos_re : 0 ≤ x + z.re := by nlinarith [hxpos, hz]
        have habs : |x + z.re| = x + z.re := by simp [abs_of_nonneg hpos_re]
        have h'' : x + z.re ≤ ‖(x : ℂ) + z‖ := by
          simpa [abs_of_nonneg hpos_re] using h'
        exact le_trans hre h''
      have hpow : (x + ε) ^ 2 ≤ ‖(x : ℂ) + z‖ ^ 2 := by
        have hpos : 0 ≤ x + ε := by linarith [hxεpos]
        have hpos' : 0 ≤ ‖(x : ℂ) + z‖ := by positivity
        have hmul := mul_le_mul hnorm_ge hnorm_ge hpos hpos'
        simpa [pow_two] using hmul
      have hle_inv : 1 / ‖(x : ℂ) + z‖ ^ 2 ≤ 1 / (x + ε) ^ 2 := by
        have hpos : 0 < (x + ε) ^ 2 := by nlinarith [hxεpos]
        exact one_div_le_one_div_of_le hpos hpow
      calc
      ‖stieltjesF z x‖
            = ‖(bernoulli2Diff x : ℂ)‖ / ‖2 * ((x : ℂ) + z) ^ 2‖ := by
                simp [stieltjesF]
        _ ≤ (1 / 4 : ℝ) / ‖2 * ((x : ℂ) + z) ^ 2‖ := by
                exact (div_le_div_of_nonneg_right hnorm_b (by positivity))
        _ = (1 / 8 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 2) := by
                have hnorm : ‖2 * ((x : ℂ) + z) ^ 2‖ = (2:ℝ) * ‖(x : ℂ) + z‖ ^ 2 := by
                  simp [norm_pow]
                calc
                  (1 / 4 : ℝ) / ‖2 * ((x : ℂ) + z) ^ 2‖
                      = (1 / 4 : ℝ) / ((2:ℝ) * ‖(x : ℂ) + z‖ ^ 2) := by simp
                  _ = (1 / 8 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 2) := by ring_nf
        _ ≤ (1 / 8 : ℝ) * (1 / (x + ε) ^ 2) := by
                exact mul_le_mul_of_nonneg_left hle_inv (by positivity)
    -- integrability of the bound (x+ε)^(-2)
    have h_int : IntegrableOn (fun x : ℝ => (x + ε) ^ (-2 : ℝ)) (Set.Ioi (0 : ℝ)) := by
      have hlt : (-2 : ℝ) < -1 := by linarith
      have hc : -ε < (0 : ℝ) := by nlinarith [hε]
      simpa using (integrableOn_add_rpow_Ioi_of_lt hlt hc)
    have h_int' : IntegrableOn (fun x : ℝ => 1 / (x + ε) ^ 2) (Set.Ioi (0 : ℝ)) := by
      refine h_int.congr_fun ?_ measurableSet_Ioi
      intro x hx
      have hpow :
          (x + ε) ^ (-2 : ℝ) = 1 / (x + ε) ^ 2 := by
        calc
          (x + ε) ^ (-2 : ℝ) = (x + ε)⁻¹ ^ (2 : ℝ) := by
            simpa using (rpow_neg_eq_inv_rpow (x + ε) (2 : ℝ))
          _ = (x + ε)⁻¹ ^ (2 : ℕ) := by
            simp
          _ = (1 / (x + ε)) ^ 2 := by
            simp [one_div]
          _ = 1 / (x + ε) ^ 2 := by
            simp [one_div, inv_pow]
      exact hpow
    have h_int'' : Integrable (fun x : ℝ => 1 / (x + ε) ^ 2) μ := by
      simpa [IntegrableOn, μ] using h_int'
    have hF_meas_z : AEStronglyMeasurable (stieltjesF z) μ := by
      have hmeas : Measurable (fun x => stieltjesF z x) := by
        have hcoe : Measurable (fun x : ℝ => (x : ℂ)) := Complex.measurable_ofReal
        have h_add : Measurable (fun x : ℝ => (x : ℂ) + z) := hcoe.add measurable_const
        have h_pow : Measurable (fun x : ℝ => ((x : ℂ) + z) ^ 2) := h_add.pow_const 2
        have h_den : Measurable (fun x : ℝ => (2 : ℂ) * ((x : ℂ) + z) ^ 2) :=
          measurable_const.mul h_pow
        have h_num : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ)) :=
          (Complex.measurable_ofReal.comp measurable_bernoulli2Diff)
        exact h_num.div h_den
      simpa [μ] using hmeas.aestronglyMeasurable
    refine (h_int''.const_mul (1 / 8 : ℝ)).mono' hF_meas_z ?_
    refine (ae_restrict_mem measurableSet_Ioi).mono ?_
    intro x hx
    exact hbound x hx
  -- measurability of F' at z
  have hF'_meas : AEStronglyMeasurable (stieltjesF' z) μ := by
    have hmeas : Measurable (fun x => stieltjesF' z x) := by
      have hcoe : Measurable (fun x : ℝ => (x : ℂ)) := Complex.measurable_ofReal
      have h_add : Measurable (fun x : ℝ => (x : ℂ) + z) := hcoe.add measurable_const
      have h_pow : Measurable (fun x : ℝ => ((x : ℂ) + z) ^ 3) := h_add.pow_const 3
      have h_den : Measurable (fun x : ℝ => ((x : ℂ) + z) ^ 3) := h_pow
      have h_num : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ)) :=
        (Complex.measurable_ofReal.comp measurable_bernoulli2Diff)
      have h_div : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) :=
        h_num.div h_den
      have h_neg :
          Measurable (fun x : ℝ => -((bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)) :=
        h_div.neg
      simpa [stieltjesF'] using h_neg
    simpa [μ] using hmeas.aestronglyMeasurable
  -- bound on F' on half-plane s
  have h_bound :
      ∀ᵐ x ∂μ, ∀ w ∈ Metric.ball z ε, ‖stieltjesF' w x‖ ≤ stieltjesBound ε x := by
    refine (ae_restrict_mem measurableSet_Ioi).mono ?_
    intro x hx w hw
    have hεle : ε ≤ w.re := hball_re hw
    have hx0 : 0 < x := by simpa using hx
    have hxε : 0 < x + ε := by nlinarith [hx0, hε]
    have hb0 : 0 ≤ bernoulli2Diff x := (bernoulli2Diff_bounds x).1
    have hb1 : bernoulli2Diff x ≤ (1 / 4 : ℝ) := (bernoulli2Diff_bounds x).2
    have hnorm_b : ‖(bernoulli2Diff x : ℂ)‖ ≤ (1 / 4 : ℝ) := by
      have habs : |bernoulli2Diff x| = bernoulli2Diff x := by
        simp [abs_of_nonneg hb0]
      have hnorm : ‖(bernoulli2Diff x : ℂ)‖ = |bernoulli2Diff x| := by
        simp
      simpa [hnorm, habs] using hb1
    have h_re_nonneg : 0 ≤ x + w.re := by nlinarith [hx0, hεle]
    have hnorm_ge : x + w.re ≤ ‖(x : ℂ) + w‖ := by
      have habs : |((x : ℂ) + w).re| ≤ ‖(x : ℂ) + w‖ := by
        simpa using (RCLike.abs_re_le_norm ((x : ℂ) + w))
      have hrew : ((x : ℂ) + w).re = x + w.re := by simp
      simpa [hrew, abs_of_nonneg h_re_nonneg] using habs
    have hnorm_ge_eps : x + ε ≤ ‖(x : ℂ) + w‖ := by
      have : x + ε ≤ x + w.re := by nlinarith [hεle]
      exact le_trans this hnorm_ge
    have hpow2 : (x + ε) ^ 2 ≤ ‖(x : ℂ) + w‖ ^ 2 := by
      have h0 : 0 ≤ x + ε := by nlinarith [hxε]
      have h0n : 0 ≤ ‖(x : ℂ) + w‖ := by positivity
      have hmul := mul_le_mul hnorm_ge_eps hnorm_ge_eps h0 h0n
      simpa [pow_two] using hmul
    have hpow3 : (x + ε) ^ 3 ≤ ‖(x : ℂ) + w‖ ^ 3 := by
      have h0 : 0 ≤ x + ε := by nlinarith [hxε]
      have h0n2 : 0 ≤ ‖(x : ℂ) + w‖ ^ 2 := by positivity
      have hmul := mul_le_mul hpow2 hnorm_ge_eps (by nlinarith [h0]) h0n2
      simpa [pow_succ, pow_two, mul_assoc] using hmul
    have hpos' : 0 < x + ε := by nlinarith [hxε]
    have hpos : 0 < (x + ε) ^ 3 := by
      simpa using (pow_pos hpos' 3)
    have hle_inv' : 1 / ‖(x : ℂ) + w‖ ^ 3 ≤ 1 / (x + ε) ^ 3 :=
      one_div_le_one_div_of_le hpos hpow3
    calc
      ‖stieltjesF' w x‖
          = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x + w : ℂ) ^ 3‖ := by
              simp [stieltjesF']
      _ = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x : ℂ) + w‖ ^ 3 := by
              simp [norm_pow]
      _ ≤ (1 / 4 : ℝ) / ‖(x : ℂ) + w‖ ^ 3 := by
              exact (div_le_div_of_nonneg_right hnorm_b (by positivity))
      _ ≤ (1 / 4 : ℝ) / (x + ε) ^ 3 := by
              have hmul :
                  (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + w‖ ^ 3) ≤
                    (1 / 4 : ℝ) * (1 / (x + ε) ^ 3) :=
                mul_le_mul_of_nonneg_left hle_inv' (by positivity)
              calc
                (1 / 4 : ℝ) / ‖(x : ℂ) + w‖ ^ 3
                    = (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + w‖ ^ 3) := by
                        simp [div_eq_mul_inv]
                _ ≤ (1 / 4 : ℝ) * (1 / (x + ε) ^ 3) := hmul
                _ = (1 / 4 : ℝ) / (x + ε) ^ 3 := by
                        simp [div_eq_mul_inv]
      _ = stieltjesBound ε x := by
              simp [stieltjesBound, div_eq_mul_inv]
  -- integrability of bound
  have h_bound_int : Integrable (stieltjesBound ε) μ := by
    have h_int : IntegrableOn (fun x : ℝ => (x + ε) ^ (-3 : ℝ)) (Set.Ioi (0 : ℝ)) := by
      have hlt : (-3 : ℝ) < -1 := by linarith
      have hc : -ε < (0 : ℝ) := by nlinarith [hε]
      simpa using (integrableOn_add_rpow_Ioi_of_lt hlt hc)
    have h_int' : Integrable (fun x : ℝ => (x + ε) ^ (-3 : ℝ)) μ := by
      simpa [IntegrableOn, μ] using h_int
    have h_int'' : Integrable (fun x : ℝ => ((x + ε) ^ 3)⁻¹) μ := by
      simpa [rpow_neg_eq_inv_rpow, rpow_natCast, one_div] using h_int'
    change Integrable (fun x : ℝ => (4 : ℝ)⁻¹ * ((x + ε) ^ 3)⁻¹) μ
    exact h_int''.const_mul ((4 : ℝ)⁻¹)
  -- pointwise derivative in w (for ae x)
  have h_diff :
      ∀ᵐ x ∂μ, ∀ w ∈ Metric.ball z ε, HasDerivAt (fun w => stieltjesF w x) (stieltjesF' w x) w := by
    refine (ae_restrict_mem measurableSet_Ioi).mono ?_
    intro x hx w hw
    have hεle : ε ≤ w.re := hball_re hw
    have hx0 : 0 < x := by simpa using hx
    have hneq : (x : ℂ) + w ≠ 0 := by
      intro hzero
      have hxwpos : 0 < x + w.re := by nlinarith [hx0, hεle, hε]
      have hzero' : x + w.re = 0 := by
        have hrew : ((x : ℂ) + w).re = x + w.re := by simp
        simpa [hrew] using congrArg Complex.re hzero
      nlinarith [hxwpos, hzero']
    -- derivative calculation
    have h1 : HasDerivAt (fun w => (x : ℂ) + w) 1 w := by
      simpa [add_comm] using (hasDerivAt_id w).const_add (x : ℂ)
    have h2 : HasDerivAt (fun w => ((x : ℂ) + w) ^ 2) (2 * ((x : ℂ) + w)) w := by
      simpa [pow_two] using (h1.pow 2)
    have h3 :
        HasDerivAt (fun w => ((x : ℂ) + w) ^ 2) (2 * ((x : ℂ) + w)) w := h2
    have h4 :
        HasDerivAt (fun w => (((x : ℂ) + w) ^ 2)⁻¹)
          (-(2 * ((x : ℂ) + w)) / (((x : ℂ) + w) ^ 2) ^ 2) w := by
      simpa [one_div] using (h3.inv (by
        have : ((x : ℂ) + w) ^ 2 ≠ 0 := by
          exact pow_ne_zero 2 hneq
        exact this))
    have h5 :
        HasDerivAt (fun w => (1 / (2 : ℂ)) * (((x : ℂ) + w) ^ 2)⁻¹)
          ((1 / (2 : ℂ)) * (-(2 * ((x : ℂ) + w)) / (((x : ℂ) + w) ^ 2) ^ 2)) w := by
      simpa using h4.const_mul (1 / (2 : ℂ))
    have h6 :
        HasDerivAt (fun w => stieltjesF w x)
          (((1 / (2 : ℂ)) * (-(2 * ((x : ℂ) + w)) / (((x : ℂ) + w) ^ 2) ^ 2)) *
            (bernoulli2Diff x : ℂ)) w := by
      simpa [stieltjesF, div_eq_mul_inv, mul_comm, mul_left_comm, mul_assoc] using
        (h5.const_mul (bernoulli2Diff x : ℂ))
    have hcalc :
        ((1 / (2 : ℂ)) * (-(2 * ((x : ℂ) + w)) / (((x : ℂ) + w) ^ 2) ^ 2)) *
            (bernoulli2Diff x : ℂ) =
          -((bernoulli2Diff x : ℂ) / ((x : ℂ) + w) ^ 3) := by
      field_simp [hneq]
    have hcalc' :
        ((1 / (2 : ℂ)) * (-(2 * ((x : ℂ) + w)) / (((x : ℂ) + w) ^ 2) ^ 2)) *
            (bernoulli2Diff x : ℂ) = stieltjesF' w x := by
      simpa [stieltjesF'] using hcalc
    -- rewrite the derivative target using hcalc'
    have h6' : HasDerivAt (fun w => stieltjesF w x) (stieltjesF' w x) w := by
      convert h6 using 1
      exact hcalc'.symm
    exact h6'
  -- apply dominated differentiation lemma
  have hmain :=
    hasDerivAt_integral_of_dominated_loc_of_deriv_le (μ := μ) (F := stieltjesF)
      (x₀ := z) (bound := stieltjesBound ε) (Metric.ball_mem_nhds z hε)
      hF_meas hF_int hF'_meas h_bound h_bound_int h_diff
  rcases hmain with ⟨_, hmain⟩
  -- Convert ∫ stieltjesF' to the target `-∫ ...` form.
  have hneg :
      ∫ x, stieltjesF' z x ∂μ =
        -∫ x, (bernoulli2Diff x : ℂ) / (x + z) ^ 3 ∂μ := by
    change ∫ x, -((bernoulli2Diff x : ℂ) / (x + z) ^ 3) ∂μ =
      -∫ x, (bernoulli2Diff x : ℂ) / (x + z) ^ 3 ∂μ
    simpa using
      (integral_neg (μ := μ) (f := fun x : ℝ => (bernoulli2Diff x : ℂ) / (x + z) ^ 3))
  have hmain' :
      HasDerivAt (fun w => ∫ x, stieltjesF w x ∂μ)
        (-∫ x, (bernoulli2Diff x : ℂ) / (x + z) ^ 3 ∂μ) z := by
    exact hmain.congr_deriv hneg
  simpa [stieltjesF, stieltjesF', μ] using hmain'

lemma stieltjes_integral_deriv (z : ℂ) (hz : 0 < z.re) :
    deriv (fun w => ∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (2 * (x + w) ^ 2)) z =
      -∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3 := by
  simpa using (stieltjes_integral_hasDerivAt z hz).deriv

/-!
Kernel integral. The full calculus proof is being formalized; we keep the
exact evaluation as an axiom and use it for the analytic tail bounds.
-/

lemma integral_kernel_eq (σ τ : ℝ) (hσ : 0 < σ) :
    ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ) =
      1 / (Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ)) := by
  classical
  by_cases hτ : τ = 0
  · subst hτ
    have hσ' : 0 < σ := hσ
    let g : ℝ → ℝ := fun x => (-1 / 2 : ℝ) * ((x + σ) ^ 2)⁻¹
    let g' : ℝ → ℝ := fun x => 1 / ((x + σ) ^ 2) ^ (3 / 2 : ℝ)
    have hderiv : ∀ x ∈ Ici (0 : ℝ), HasDerivAt g (g' x) x := by
      intro x hx
      have hx0 : 0 ≤ x := hx
      have hxpos : 0 < x + σ := by linarith [hx0, hσ']
      have hsq : 0 ≤ (x + σ) ^ 2 := by nlinarith
      have hpow :
          ((x + σ) ^ 2) ^ (3 / 2 : ℝ) = (x + σ) ^ 3 := by
        calc
          ((x + σ) ^ 2) ^ (3 / 2 : ℝ)
              = ((x + σ) ^ 2) ^ ((1 / 2 : ℝ) * (3 : ℝ)) := by ring_nf
          _ = (((x + σ) ^ 2) ^ (1 / 2 : ℝ)) ^ (3 : ℝ) := by
            simp [Real.rpow_mul hsq]
          _ = (Real.sqrt ((x + σ) ^ 2)) ^ (3 : ℝ) := by
            simp [Real.sqrt_eq_rpow]
          _ = (x + σ) ^ (3 : ℝ) := by
            have hsqrt : Real.sqrt ((x + σ) ^ 2) = x + σ := by
              simp [Real.sqrt_sq_eq_abs, abs_of_pos hxpos]
            simp [hsqrt]
          _ = (x + σ) ^ 3 := by simp
      have hderiv0 :
          HasDerivAt g (1 / (x + σ) ^ 3) x := by
        have h1 : HasDerivAt (fun x => x + σ) 1 x := by
          simpa using (hasDerivAt_id x).add_const σ
        have h2 : HasDerivAt (fun x => (x + σ) ^ 2) (2 * (x + σ)) x := by
          simpa [pow_two] using (h1.pow 2)
        have hne : (x + σ) ^ 2 ≠ 0 := by nlinarith [hxpos]
        have h3 :
            HasDerivAt (fun x => ((x + σ) ^ 2)⁻¹)
              (-(2 * (x + σ)) / ((x + σ) ^ 2) ^ 2) x := by
          simpa [one_div] using (h2.inv hne)
        have h4 :
            HasDerivAt (fun x => (-1 / 2 : ℝ) * ((x + σ) ^ 2)⁻¹)
              ((-1 / 2 : ℝ) * (-(2 * (x + σ)) / ((x + σ) ^ 2) ^ 2)) x := by
          simpa using h3.const_mul (-1 / 2 : ℝ)
        have h5 :
            HasDerivAt g ((-1 / 2 : ℝ) * (-(2 * (x + σ)) / ((x + σ) ^ 2) ^ 2)) x := by
          simpa [g, mul_comm, mul_left_comm, mul_assoc] using h4
        have h6 :
            (-1 / 2 : ℝ) * (-(2 * (x + σ)) / ((x + σ) ^ 2) ^ 2) =
              1 / (x + σ) ^ 3 := by
          field_simp [pow_two]
        simpa [h6] using h5
      exact (by simpa [g', hpow] using hderiv0)
    have g'pos : ∀ x ∈ Ioi (0 : ℝ), 0 ≤ g' x := by
      intro x hx
      have hsq : 0 ≤ (x + σ) ^ 2 := by nlinarith
      have hpow : 0 ≤ ((x + σ) ^ 2) ^ (3 / 2 : ℝ) := by
        exact Real.rpow_nonneg hsq _
      exact one_div_nonneg.mpr hpow
    have hlim : Tendsto g atTop (𝓝 (0 : ℝ)) := by
      have hlim_add : Tendsto (fun x => x + σ) atTop atTop := by
        refine tendsto_atTop.2 ?_
        intro b
        refine (eventually_atTop.2 ?_)
        refine ⟨b - σ, ?_⟩
        intro x hx
        linarith
      have hlim_sq : Tendsto (fun x => (x + σ) ^ 2) atTop atTop := by
        have hpow : Tendsto (fun y : ℝ => y ^ 2) atTop atTop := by
          exact tendsto_pow_atTop (α := ℝ) (n := 2) (by simp)
        exact hpow.comp hlim_add
      have hlim_inv :
          Tendsto (fun x => ((x + σ) ^ 2)⁻¹) atTop (𝓝 (0 : ℝ)) := by
        exact tendsto_inv_atTop_zero.comp hlim_sq
      have hlim_inv' : Tendsto (fun x => 1 / (x + σ) ^ 2) atTop (𝓝 (0 : ℝ)) := by
        simpa [one_div] using hlim_inv
      have hlim_mul :
          Tendsto (fun x => (-1 / 2 : ℝ) * (1 / (x + σ) ^ 2)) atTop (𝓝 (0 : ℝ)) := by
        have hconst : Tendsto (fun _ : ℝ => (-1 / 2 : ℝ)) atTop (𝓝 (-1 / 2 : ℝ)) :=
          tendsto_const_nhds
        simpa [mul_comm, mul_left_comm, mul_assoc] using hconst.mul hlim_inv'
      simpa [g, mul_comm, mul_left_comm, mul_assoc] using hlim_mul
    have hmain :=
      integral_Ioi_of_hasDerivAt_of_nonneg' (a := (0 : ℝ)) hderiv g'pos hlim
    have hF0 : g 0 = (-1 / 2 : ℝ) * (σ ^ 2)⁻¹ := by
      simp [g]
    have hsqrt : Real.sqrt (σ ^ 2) = σ := by
      simp [Real.sqrt_sq_eq_abs, abs_of_pos hσ]
    calc
      ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ) ^ 2 + (0 : ℝ) ^ 2) ^ (3 / 2 : ℝ)
          = ∫ x in Set.Ioi (0 : ℝ), g' x := by simp [g']
      _ = (0 : ℝ) - g 0 := hmain
      _ = 1 / (2 * σ ^ 2) := by
        simp [hF0, div_eq_mul_inv, mul_comm]
      _ =
          1 / (Real.sqrt (σ ^ 2 + (0 : ℝ) ^ 2) *
            (Real.sqrt (σ ^ 2 + (0 : ℝ) ^ 2) + σ)) := by
        have hσne : σ ≠ 0 := by linarith [hσ]
        field_simp [hσne]
        simp [hsqrt]
        ring_nf
  ·
    have hτ2 : τ ^ 2 ≠ 0 := by
      exact pow_ne_zero 2 hτ
    let u : ℝ → ℝ := fun x => (x + σ) ^ 2 + τ ^ 2
    let s : ℝ → ℝ := fun x => Real.sqrt (u x)
    let sinv : ℝ → ℝ := s⁻¹
    let c : ℝ := (τ ^ 2)⁻¹
    let g : ℝ → ℝ := fun x => c * ((x + σ) / s x)
    let g' : ℝ → ℝ := fun x => 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ)
    have hderiv : ∀ x ∈ Ici (0 : ℝ), HasDerivAt g (g' x) x := by
      intro x hx
      have hx0 : 0 ≤ x := hx
      have hxpos : 0 < x + σ := by linarith [hσ, hx0]
      have hpos : 0 < u x := by
        have hpos' : 0 < (x + σ) ^ 2 := by nlinarith [hxpos]
        have ht : 0 ≤ τ ^ 2 := by nlinarith
        have : 0 < (x + σ) ^ 2 + τ ^ 2 := add_pos_of_pos_of_nonneg hpos' ht
        simpa [u] using this
      have hsq : 0 ≤ u x := le_of_lt hpos
      have h1 : HasDerivAt (fun x => x + σ) 1 x := by
        simpa using (hasDerivAt_id x).add_const σ
      have h2 : HasDerivAt (fun x => (x + σ) ^ 2) (2 * (x + σ)) x := by
        simpa [pow_two] using (h1.pow 2)
      have h3 : HasDerivAt u (2 * (x + σ)) x := by
        simpa [u] using h2.const_add (τ ^ 2)
      have h4 :
          HasDerivAt s ((2 * (x + σ)) / (2 * s x)) x := by
        have hne : u x ≠ 0 := by exact ne_of_gt hpos
        simpa [s] using h3.sqrt hne
      have h5 :
          HasDerivAt sinv
            (-(2 * (x + σ) / (2 * s x)) / (s x) ^ 2) x := by
        have hsne : s x ≠ 0 := by
          have hspos : 0 < s x := by
            exact Real.sqrt_pos.mpr hpos
          exact ne_of_gt hspos
        simpa [sinv] using h4.inv hsne
      have h6 :
          HasDerivAt (fun x => (x + σ) / s x)
            (sinv x + (x + σ) * (-(2 * (x + σ) / (2 * s x)) / (s x) ^ 2)) x := by
        simpa [sinv, div_eq_mul_inv] using h1.mul h5
      have h7 :
          HasDerivAt g
            (c *
              (sinv x + (x + σ) * (-(2 * (x + σ) / (2 * s x)) / (s x) ^ 2))) x := by
        simpa [g, c, sinv, mul_comm, mul_left_comm, mul_assoc] using h6.const_mul c
      have hsq' : (s x) ^ 2 = u x := by
        simpa [s] using (Real.sq_sqrt hsq)
      have hA :
          c *
              (sinv x + (x + σ) * (-(2 * (x + σ) / (2 * s x)) / (s x) ^ 2)) =
          g' x := by
        have hnum : (s x) ^ 2 - (x + σ) ^ 2 = τ ^ 2 := by
          calc
            (s x) ^ 2 - (x + σ) ^ 2 = u x - (x + σ) ^ 2 := by
              simp [hsq']
            _ = τ ^ 2 := by simp [u]
        have hA' :
            c *
                (sinv x + (x + σ) * (-(2 * (x + σ) / (2 * s x)) / (s x) ^ 2)) =
          1 / (s x) ^ 3 := by
          have hspos : 0 < s x := by
            exact Real.sqrt_pos.mpr hpos
          have hsne : s x ≠ 0 := ne_of_gt hspos
          have htwo : (2 * (x + σ)) / (2 * s x) = (x + σ) / s x := by
            field_simp [hsne]
          simp [sinv, c, div_eq_mul_inv, mul_comm, mul_assoc]
          field_simp [hτ2, hsne]
          nlinarith [hnum]
        have hg' : g' x = 1 / (s x) ^ 3 := by
          have hspos : 0 ≤ s x := by exact Real.sqrt_nonneg _
          calc
            g' x = 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ) := rfl
            _ = 1 / (u x) ^ (3 / 2 : ℝ) := by simp [u]
            _ = 1 / ((s x) ^ 2) ^ (3 / 2 : ℝ) := by simp [hsq']
            _ = 1 / (s x) ^ (2 * (3 / 2 : ℝ)) := by
              have h := (Real.rpow_mul (x := s x) hspos 2 (3 / 2 : ℝ))
              -- h : (s x)^(2*(3/2)) = ((s x)^2)^(3/2)
              simpa [mul_comm] using h.symm
            _ = 1 / (s x) ^ (3 : ℝ) := by ring_nf
            _ = 1 / (s x) ^ 3 := by simp
        simpa [hg'] using hA'
      simpa [hA] using h7
    have g'pos : ∀ x ∈ Ioi (0 : ℝ), 0 ≤ g' x := by
      intro x hx
      have hsq : 0 ≤ (x + σ) ^ 2 + τ ^ 2 := by
        have h1 : 0 ≤ (x + σ) ^ 2 := by nlinarith
        have h2 : 0 ≤ τ ^ 2 := by nlinarith
        exact add_nonneg h1 h2
      have hpow : 0 ≤ ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ) := by
        exact Real.rpow_nonneg hsq _
      exact one_div_nonneg.mpr hpow
    have hlim_add : Tendsto (fun x => x + σ) atTop atTop := by
      refine tendsto_atTop.2 ?_
      intro b
      refine (eventually_atTop.2 ?_)
      refine ⟨b - σ, ?_⟩
      intro x hx
      linarith
    have hlim_sq : Tendsto (fun x => (x + σ) ^ 2) atTop atTop := by
      have hpow : Tendsto (fun y : ℝ => y ^ 2) atTop atTop := by
        exact tendsto_pow_atTop (α := ℝ) (n := 2) (by simp)
      exact hpow.comp hlim_add
    have hlim_inv : Tendsto (fun x => 1 / (x + σ) ^ 2) atTop (𝓝 (0 : ℝ)) := by
      have hlim_inv' : Tendsto (fun x => ((x + σ) ^ 2)⁻¹) atTop (𝓝 (0 : ℝ)) :=
        tendsto_inv_atTop_zero.comp hlim_sq
      simpa [one_div] using hlim_inv'
    let term : ℝ → ℝ := fun x => (s x * (s x + (x + σ)))⁻¹
    have hlim_den : Tendsto (fun x => s x * (s x + (x + σ))) atTop atTop := by
      refine tendsto_atTop.2 ?_
      intro b
      have hlim_sq' := (tendsto_atTop.1 hlim_sq) b
      have hx0event : ∀ᶠ x in atTop, (0 : ℝ) ≤ x := by
        refine (eventually_atTop.2 ?_)
        refine ⟨0, ?_⟩
        intro x hx
        exact hx
      filter_upwards [hlim_sq', hx0event] with x hx hx0
      have hspos : 0 ≤ s x := by exact Real.sqrt_nonneg _
      have hxpos : 0 ≤ x + σ := by nlinarith [hσ, hx0]
      have hsq : 0 ≤ u x := by
        have h1 : 0 ≤ (x + σ) ^ 2 := by nlinarith
        have h2 : 0 ≤ τ ^ 2 := by nlinarith
        have : 0 ≤ (x + σ) ^ 2 + τ ^ 2 := add_nonneg h1 h2
        simpa [u] using this
      have hsq' : (s x) ^ 2 = u x := by
        simpa [s] using (Real.sq_sqrt hsq)
      have hbig :
          (x + σ) ^ 2 ≤ s x * (s x + (x + σ)) := by
        have hbig2 : u x = (x + σ) ^ 2 + τ ^ 2 := by simp [u]
        have hbig3 : (x + σ) ^ 2 ≤ u x := by
          have ht : 0 ≤ τ ^ 2 := by nlinarith
          nlinarith [hbig2, ht]
        calc
          s x * (s x + (x + σ)) = (s x) ^ 2 + s x * (x + σ) := by ring_nf
          _ ≥ (s x) ^ 2 := by nlinarith [mul_nonneg hspos hxpos]
          _ = u x := by simp [hsq']
          _ ≥ (x + σ) ^ 2 := hbig3
      exact le_trans hx hbig
    have hlim_term : Tendsto term atTop (𝓝 (0 : ℝ)) := by
      change Tendsto (fun x => (s x * (s x + (x + σ)))⁻¹) atTop (𝓝 (0 : ℝ))
      exact tendsto_inv_atTop_zero.comp hlim_den
    have hlim_ratio :
        Tendsto (fun x => (x + σ) / s x) atTop (𝓝 (1 : ℝ)) := by
      have hdec :
          ∀ x, 1 - (x + σ) / s x = τ ^ 2 * term x := by
        intro x
        have hsq : 0 ≤ u x := by
          have h1 : 0 ≤ (x + σ) ^ 2 := by nlinarith
          have h2 : 0 ≤ τ ^ 2 := by nlinarith
          have : 0 ≤ (x + σ) ^ 2 + τ ^ 2 := add_nonneg h1 h2
          simpa [u] using this
        have hsq' : (s x) ^ 2 = u x := by
          simpa [s] using (Real.sq_sqrt hsq)
        have hnum : (s x) ^ 2 - (x + σ) ^ 2 = τ ^ 2 := by
          calc
            (s x) ^ 2 - (x + σ) ^ 2 = u x - (x + σ) ^ 2 := by
              simp [hsq']
            _ = τ ^ 2 := by simp [u]
        have hspos : 0 < s x := by
          have ht' : τ ≠ 0 := hτ
          have ht : 0 < τ ^ 2 := by
            have hmul : 0 < τ * τ := by simpa using mul_self_pos.mpr ht'
            simpa [pow_two] using hmul
          have h1 : 0 ≤ (x + σ) ^ 2 := by nlinarith
          have : 0 < (x + σ) ^ 2 + τ ^ 2 := add_pos_of_nonneg_of_pos h1 ht
          have hpos' : 0 < u x := by simpa [u] using this
          exact Real.sqrt_pos.mpr hpos'
        have hsne : s x ≠ 0 := ne_of_gt hspos
        have hsumne : s x + (x + σ) ≠ 0 := by
          intro hsum
          have hs : s x = -(x + σ) := by linarith
          have hsqeq : (s x) ^ 2 = (x + σ) ^ 2 := by nlinarith [hs]
          have htz : τ ^ 2 = 0 := by nlinarith [hnum, hsqeq]
          exact hτ (by nlinarith [htz])
        calc
          1 - (x + σ) / s x = (s x - (x + σ)) / s x := by
            field_simp [hsne]
          _ = ((s x) ^ 2 - (x + σ) ^ 2) / (s x * (s x + (x + σ))) := by
            field_simp [hsne, hsumne]
            ring_nf
          _ = τ ^ 2 * term x := by
            simp [term, hnum, div_eq_mul_inv, mul_comm]
      have hlim_diff : Tendsto (fun x => 1 - (x + σ) / s x) atTop (𝓝 (0 : ℝ)) := by
        have hconst : Tendsto (fun _ : ℝ => τ ^ 2) atTop (𝓝 (τ ^ 2 : ℝ)) :=
          tendsto_const_nhds
        have hmul : Tendsto (fun x => τ ^ 2 * term x) atTop (𝓝 (0 : ℝ)) := by
          simpa using (hconst.mul hlim_term)
        simpa [hdec] using hmul
      have hlim_ratio' :
          Tendsto (fun x => (1 : ℝ) + (-(1 - (x + σ) / s x))) atTop (𝓝 (1 : ℝ)) := by
        have hconst : Tendsto (fun _ : ℝ => (1 : ℝ)) atTop (𝓝 (1 : ℝ)) :=
          tendsto_const_nhds
        simpa using (hconst.add hlim_diff.neg)
      simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using hlim_ratio'
    have hlim : Tendsto g atTop (𝓝 (1 / τ ^ 2 : ℝ)) := by
      have hconst : Tendsto (fun _ : ℝ => (1 / τ ^ 2 : ℝ)) atTop (𝓝 (1 / τ ^ 2 : ℝ)) :=
        tendsto_const_nhds
      have hmul : Tendsto (fun x => (1 / τ ^ 2 : ℝ) * ((x + σ) / s x)) atTop
          (𝓝 (1 / τ ^ 2 : ℝ)) := by
        simpa [c, one_div] using (hconst.mul hlim_ratio)
      simpa [g, c, mul_comm, mul_left_comm, mul_assoc] using hmul
    have hmain :=
      integral_Ioi_of_hasDerivAt_of_nonneg' (a := (0 : ℝ)) hderiv g'pos hlim
    have hF0 : g 0 = c * (σ / s 0) := by
      simp [g, c]
    have hsq0 : s 0 = Real.sqrt (σ ^ 2 + τ ^ 2) := by
      simp [s, u]
    have hfinal :
        (1 / τ ^ 2 : ℝ) - (1 / τ ^ 2 : ℝ) * (σ / Real.sqrt (σ ^ 2 + τ ^ 2)) =
          1 / (Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ)) := by
      have hsq : 0 ≤ σ ^ 2 + τ ^ 2 := by nlinarith
      have hsq' : (Real.sqrt (σ ^ 2 + τ ^ 2)) ^ 2 = σ ^ 2 + τ ^ 2 := by
        simpa using (Real.sq_sqrt hsq)
      have hpos : 0 < Real.sqrt (σ ^ 2 + τ ^ 2) := by
        have hpos' : 0 < σ ^ 2 + τ ^ 2 := by nlinarith [hσ]
        simpa using (Real.sqrt_pos.mpr hpos')
      have hden : Real.sqrt (σ ^ 2 + τ ^ 2) + σ ≠ 0 := by nlinarith [hpos, hσ]
      field_simp [hτ2, hden]
      nlinarith [hsq']
    calc
      ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ)
          = ∫ x in Set.Ioi (0 : ℝ), g' x := by
        rfl
      _ = (1 / τ ^ 2 : ℝ) - g 0 := hmain
      _ = (1 / τ ^ 2 : ℝ) - (1 / τ ^ 2 : ℝ) * (σ / Real.sqrt (σ ^ 2 + τ ^ 2)) := by
        simp [hF0, hsq0, c, one_div]
      _ = 1 / (Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ)) := hfinal

lemma integral_kernel_bound (σ τ : ℝ) (hσ : 0 < σ) :
    ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ) ≤
      1 / (σ ^ 2 + τ ^ 2) := by
  have h := integral_kernel_eq σ τ hσ
  have hpos : 0 < Real.sqrt (σ ^ 2 + τ ^ 2) := by
    have hsq : 0 < σ ^ 2 + τ ^ 2 := by nlinarith
    simpa using Real.sqrt_pos.mpr hsq
  have hle : 1 / (Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ)) ≤
      1 / (Real.sqrt (σ ^ 2 + τ ^ 2) ^ 2) := by
    have hsum : Real.sqrt (σ ^ 2 + τ ^ 2) ≤
        Real.sqrt (σ ^ 2 + τ ^ 2) + σ := by nlinarith [hσ.le]
    have hpos2 : 0 < Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ) := by
      nlinarith [hpos]
    have hpos3 : 0 < Real.sqrt (σ ^ 2 + τ ^ 2) ^ 2 := by
      nlinarith [hpos]
    exact one_div_le_one_div_of_le hpos3 (by
      nlinarith [hsum])
  have hsq : Real.sqrt (σ ^ 2 + τ ^ 2) ^ 2 = σ ^ 2 + τ ^ 2 := by
    have hsq : 0 ≤ σ ^ 2 + τ ^ 2 := by nlinarith
    simpa using (Real.sq_sqrt hsq)
  calc
    ∫ x in Set.Ioi (0 : ℝ), 1 / ((x + σ) ^ 2 + τ ^ 2) ^ (3 / 2 : ℝ)
        = 1 / (Real.sqrt (σ ^ 2 + τ ^ 2) * (Real.sqrt (σ ^ 2 + τ ^ 2) + σ)) := h
    _ ≤ 1 / (Real.sqrt (σ ^ 2 + τ ^ 2) ^ 2) := hle
    _ = 1 / (σ ^ 2 + τ ^ 2) := by simp [hsq]

lemma integrable_kernel_norm (z : ℂ) (hz : 0 < z.re) :
    Integrable (fun x : ℝ => (1 / ‖(x : ℂ) + z‖ ^ 3))
      (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
  have hnorm_sq :
      ∀ x : ℝ, ‖(x : ℂ) + z‖ ^ 2 = (x + z.re) ^ 2 + z.im ^ 2 := by
    intro x
    have h' : Complex.normSq ((x : ℂ) + z) =
        (x + z.re) * (x + z.re) + z.im * z.im := by
      simp [Complex.normSq_apply]
    have h'' : ‖(x : ℂ) + z‖ ^ 2 = Complex.normSq ((x : ℂ) + z) := by
      simpa using (Complex.sq_norm ((x : ℂ) + z))
    simpa [pow_two] using (h''.trans h')
  have hpow :
      ∀ x : ℝ, (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ) = ‖(x : ℂ) + z‖ ^ 3 := by
    intro x
    have hbase : 0 ≤ ‖(x : ℂ) + z‖ ^ 2 := by positivity
    calc
      (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ)
          = (‖(x : ℂ) + z‖ ^ 2) ^ ((1 / 2 : ℝ) * (3 : ℝ)) := by ring_nf
      _ = ((‖(x : ℂ) + z‖ ^ 2) ^ (1 / 2 : ℝ)) ^ (3 : ℝ) := by
            simpa using
              (Real.rpow_mul (x := ‖(x : ℂ) + z‖ ^ 2) hbase (1 / 2 : ℝ) (3 : ℝ))
      _ = (Real.sqrt (‖(x : ℂ) + z‖ ^ 2)) ^ (3 : ℝ) := by
            simp [Real.sqrt_eq_rpow]
      _ = ‖(x : ℂ) + z‖ ^ (3 : ℝ) := by
            simp
      _ = ‖(x : ℂ) + z‖ ^ 3 := by
            simp
  have hrewrite :
      ∀ x : ℝ,
        1 / ‖(x : ℂ) + z‖ ^ 3 =
          1 / ((x + z.re) ^ 2 + z.im ^ 2) ^ (3 / 2 : ℝ) := by
    intro x
    calc
      1 / ‖(x : ℂ) + z‖ ^ 3
          = 1 / (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ) := by
              simp [hpow x]
      _ = 1 / ((x + z.re) ^ 2 + z.im ^ 2) ^ (3 / 2 : ℝ) := by
            simp [hnorm_sq x]
  have hkernel_eq :
      ∫ x in Set.Ioi (0 : ℝ), (1 / ‖(x : ℂ) + z‖ ^ 3) =
        1 / (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) := by
    have hbound := integral_kernel_eq (σ := z.re) (τ := z.im) hz
    simpa [hrewrite] using hbound
  have hkernel_ne :
      (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) ≠ 0 := by
    have hpos : 0 < Real.sqrt (z.re ^ 2 + z.im ^ 2) := by
      have hsq : 0 < z.re ^ 2 + z.im ^ 2 := by nlinarith [hz]
      simpa using Real.sqrt_pos.mpr hsq
    have hpos2 : 0 < Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re := by
      nlinarith [hpos, hz]
    nlinarith [hpos, hpos2]
  set c : ℝ :=
    1 / (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re))
  have hc : c ≠ 0 := by
    have : (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) ≠ 0 :=
      hkernel_ne
    simpa [c] using (one_div_ne_zero this)
  have hscaled :
      ∫ x in Set.Ioi (0 : ℝ), (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) = (1 : ℝ) := by
    calc
      ∫ x in Set.Ioi (0 : ℝ), (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3)
          = (1 / c : ℝ) * ∫ x in Set.Ioi (0 : ℝ), (1 / ‖(x : ℂ) + z‖ ^ 3) := by
              simp [MeasureTheory.integral_const_mul]
      _ = (1 / c : ℝ) * c := by
            simpa using (congrArg (fun t => (1 / c : ℝ) * t) hkernel_eq)
      _ = (1 : ℝ) := by
            field_simp [hc]
  have hscaled_int :
      Integrable (fun x : ℝ => (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3))
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
    exact MeasureTheory.integrable_of_integral_eq_one hscaled
  have hgi :
      Integrable (fun x : ℝ => (1 / ‖(x : ℂ) + z‖ ^ 3))
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
    have hgi' := hscaled_int.smul c
    refine hgi'.congr ?_
    refine Filter.Eventually.of_forall ?_
    intro x
    have :
        c * ((1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3)) =
          (1 / ‖(x : ℂ) + z‖ ^ 3) := by
      field_simp [hc, mul_comm, mul_left_comm, mul_assoc]
    simpa [Pi.smul_apply, smul_eq_mul] using this
  exact hgi

lemma integrable_bernoulli2Diff_div (z : ℂ) (hz : 0 < z.re) :
    Integrable (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
      (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
  have hkernel :
      Integrable (fun x : ℝ => (1 / ‖(x : ℂ) + z‖ ^ 3))
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) :=
    integrable_kernel_norm z hz
  have hkernel' :
      Integrable (fun x : ℝ => (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3))
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) :=
    hkernel.const_mul (1 / 4 : ℝ)
  have hmeas :
      AEStronglyMeasurable
        (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
    have hmeas : Measurable (fun x => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) := by
      have hcoe : Measurable (fun x : ℝ => (x : ℂ)) := Complex.measurable_ofReal
      have h_add : Measurable (fun x : ℝ => (x : ℂ) + z) := hcoe.add measurable_const
      have h_pow : Measurable (fun x : ℝ => ((x : ℂ) + z) ^ 3) := h_add.pow_const 3
      have h_num : Measurable (fun x : ℝ => (bernoulli2Diff x : ℂ)) :=
        (Complex.measurable_ofReal.comp measurable_bernoulli2Diff)
      exact h_num.div h_pow
    simpa using hmeas.aestronglyMeasurable
  have hbound :
      ∀ᵐ x ∂(Measure.restrict volume (Set.Ioi (0 : ℝ))),
        ‖(bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3‖ ≤
          (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
    refine Filter.Eventually.of_forall ?_
    intro x
    have hnorm_pow : ‖(x + z : ℂ) ^ 3‖ = ‖(x + z : ℂ)‖ ^ 3 := by
      simp [norm_pow]
    have hpos : 0 ≤ ‖(x : ℂ) + z‖ ^ 3 := by positivity
    calc
      ‖(bernoulli2Diff x : ℂ) / (x + z) ^ 3‖
          = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x + z : ℂ) ^ 3‖ := by
            simp
      _ = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x : ℂ) + z‖ ^ 3 := by
            simp [hnorm_pow]
      _ ≤ (1 / 4 : ℝ) / ‖(x : ℂ) + z‖ ^ 3 := by
            exact (div_le_div_of_nonneg_right (bernoulli2Diff_norm_le x) hpos)
      _ = (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
            field_simp
  exact Integrable.mono' hkernel' hmeas hbound

/-!
Final real-part bound for the Stieltjes remainder.
The proof uses the N=1 Stieltjes identity + `integral_kernel_bound`.
-/

lemma digamma_stieltjes_identity (z : ℂ) (hz : 0 < z.re) :
    Q3.digamma z - Complex.log z + (1 / (2 : ℂ)) * z⁻¹ =
      -∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3 := by
  classical
  set Iinf : ℂ :=
    ∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3
  let A : ℕ → ℂ := fun N => (Real.log N : ℂ) - Complex.log (z + (N : ℂ))
  let B : ℂ := Complex.log z - (1 / 2 : ℂ) * z⁻¹
  let C : ℕ → ℂ := fun N => (1 / 2 : ℂ) * (z + (N : ℂ))⁻¹
  let D : ℕ → ℂ :=
    fun N => ∫ x in (0 : ℝ)..(N : ℝ),
      (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3
  let F : ℕ → ℂ := fun N => A N + B - C N - D N
  have hF_eq : ∀ N, _root_.digammaSeq z N = F N := by
    intro N
    have h := digammaSeq_eq_stieltjes z hz N
    simpa [F, A, B, C, D, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using h
  have hF_tendsto : Tendsto F atTop (𝓝 (Q3.digamma z)) := by
    have hdigamma := digammaSeq_tendsto_Q3_digamma z hz
    have hF_eq' : (fun N => _root_.digammaSeq z N) = F := by
      funext N
      exact hF_eq N
    simpa [hF_eq'] using hdigamma
  have h_inv_nat : Tendsto (fun N : ℕ => (N : ℂ)⁻¹) atTop (𝓝 (0 : ℂ)) := by
    have hreal : Tendsto (fun N : ℕ => (N : ℝ)⁻¹) atTop (𝓝 (0 : ℝ)) :=
      tendsto_inv_atTop_zero.comp
        (tendsto_natCast_atTop_atTop : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop)
    have hreal' : Tendsto (fun N : ℕ => (Complex.ofReal ((N : ℝ)⁻¹))) atTop (𝓝 (0 : ℂ)) :=
      (Complex.continuous_ofReal.tendsto _).comp hreal
    simpa using hreal'
  have h_div : Tendsto (fun N : ℕ => z / (N : ℂ)) atTop (𝓝 (0 : ℂ)) := by
    simpa [div_eq_mul_inv] using (tendsto_const_nhds.mul h_inv_nat)
  have h_one_add : Tendsto (fun N : ℕ => (1 : ℂ) + z / (N : ℂ)) atTop (𝓝 (1 : ℂ)) := by
    simpa using (tendsto_const_nhds.add h_div)
  have hslit1 : (1 : ℂ) ∈ Complex.slitPlane := by
    have hnot : ¬ (1 : ℂ) ≤ 0 := by
      intro hle
      have hle' : (1 : ℂ).re ≤ 0 := by
        simpa using (Complex.re_le_re hle)
      linarith
    exact (Complex.mem_slitPlane_iff_not_le_zero).2 hnot
  have hlog1 :
      Tendsto (fun N : ℕ => Complex.log (1 + z / (N : ℂ))) atTop (𝓝 (0 : ℂ)) := by
    simpa using (Filter.Tendsto.clog h_one_add hslit1)
  have h_event :
      ∀ᶠ N : ℕ in atTop,
        Complex.log (z + (N : ℂ)) - (Real.log N : ℂ) =
          Complex.log (1 + z / (N : ℂ)) := by
    refine Filter.eventually_atTop.2 ?_
    refine ⟨1, ?_⟩
    intro N hN
    have hNpos : (0 : ℝ) < (N : ℝ) := by
      exact_mod_cast (Nat.succ_le_iff.mp hN)
    have hNne : (N : ℂ) ≠ 0 := by
      exact_mod_cast (Nat.ne_of_gt (Nat.succ_le_iff.mp hN))
    have hmul : (z + (N : ℂ)) = ((N : ℝ) : ℂ) * (1 + z / (N : ℂ)) := by
      symm
      calc
        ((N : ℝ) : ℂ) * (1 + z / (N : ℂ))
            = (N : ℂ) * 1 + (N : ℂ) * (z / (N : ℂ)) := by
                simp [mul_add]
        _ = (N : ℂ) + (N : ℂ) * (z / (N : ℂ)) := by simp
        _ = (N : ℂ) + z := by
              simp [div_eq_mul_inv, hNne, mul_assoc, mul_left_comm, mul_comm]
        _ = z + (N : ℂ) := by ring
    have hRe_div : (z / (N : ℂ)).re = z.re / (N : ℝ) := by
      simpa using (Complex.div_ofReal_re z (N : ℝ))
    have hxpos : 0 < (1 + z / (N : ℂ)).re := by
      have hRe : (1 + z / (N : ℂ)).re = 1 + z.re / (N : ℝ) := by
        simp [Complex.add_re, hRe_div]
      have hdiv : 0 < z.re / (N : ℝ) := by
        exact div_pos hz hNpos
      have hpos : 0 < 1 + z.re / (N : ℝ) := by linarith
      simpa [hRe] using hpos
    have hx : (1 + z / (N : ℂ)) ≠ 0 := by
      intro hzero
      have hzero' : (1 + z / (N : ℂ)).re = 0 := by
        simpa using congrArg Complex.re hzero
      linarith [hxpos, hzero']
    have hlog :
        Complex.log (z + (N : ℂ)) = Real.log (N : ℝ) + Complex.log (1 + z / (N : ℂ)) := by
      calc
        Complex.log (z + (N : ℂ)) =
            Complex.log (((N : ℝ) : ℂ) * (1 + z / (N : ℂ))) := by
              simpa [hmul]
        _ = Real.log (N : ℝ) + Complex.log (1 + z / (N : ℂ)) := by
              simpa using (Complex.log_ofReal_mul hNpos hx)
    calc
      Complex.log (z + (N : ℂ)) - (Real.log N : ℂ)
          = (Real.log (N : ℝ) : ℂ) + Complex.log (1 + z / (N : ℂ)) - (Real.log N : ℂ) := by
              simpa [hlog]
      _ = Complex.log (1 + z / (N : ℂ)) := by ring
  have hlog' :
      Tendsto (fun N : ℕ => Complex.log (z + (N : ℂ)) - (Real.log N : ℂ)) atTop (𝓝 (0 : ℂ)) :=
    (tendsto_congr' h_event).2 hlog1
  have hlog :
      Tendsto (fun N : ℕ => (Real.log N : ℂ) - Complex.log (z + (N : ℂ)))
        atTop (𝓝 (0 : ℂ)) := by
    simpa [sub_eq_add_neg] using hlog'.neg
  have h_inv_one_add :
      Tendsto (fun N : ℕ => (1 + z / (N : ℂ))⁻¹) atTop (𝓝 (1 : ℂ)⁻¹) := by
    exact (tendsto_inv₀ (by norm_num : (1 : ℂ) ≠ 0)).comp h_one_add
  have hmul_inv :
      Tendsto (fun N : ℕ => (N : ℂ)⁻¹ * (1 + z / (N : ℂ))⁻¹) atTop (𝓝 (0 : ℂ)) := by
    simpa using (h_inv_nat.mul h_inv_one_add)
  have h_event_inv :
      ∀ᶠ N : ℕ in atTop,
        (z + (N : ℂ))⁻¹ = (N : ℂ)⁻¹ * (1 + z / (N : ℂ))⁻¹ := by
    refine Filter.eventually_atTop.2 ?_
    refine ⟨1, ?_⟩
    intro N hN
    have hNne : (N : ℂ) ≠ 0 := by
      exact_mod_cast (Nat.ne_of_gt (Nat.succ_le_iff.mp hN))
    have hmul : (z + (N : ℂ)) = (N : ℂ) * (1 + z / (N : ℂ)) := by
      symm
      calc
        (N : ℂ) * (1 + z / (N : ℂ))
            = (N : ℂ) * 1 + (N : ℂ) * (z / (N : ℂ)) := by
                simp [mul_add]
        _ = (N : ℂ) + (N : ℂ) * (z / (N : ℂ)) := by simp
        _ = (N : ℂ) + z := by
            simp [div_eq_mul_inv, hNne, mul_assoc, mul_left_comm, mul_comm]
        _ = z + (N : ℂ) := by ring
    calc
      (z + (N : ℂ))⁻¹
          = ((N : ℂ) * (1 + z / (N : ℂ)))⁻¹ := by simpa [hmul]
      _ = (1 + z / (N : ℂ))⁻¹ * (N : ℂ)⁻¹ := by
            simpa using (mul_inv_rev (N : ℂ) (1 + z / (N : ℂ)))
      _ = (N : ℂ)⁻¹ * (1 + z / (N : ℂ))⁻¹ := by
            ring
  have h_inv_add :
      Tendsto (fun N : ℕ => (z + (N : ℂ))⁻¹) atTop (𝓝 (0 : ℂ)) :=
    (tendsto_congr' h_event_inv).2 hmul_inv
  have h_inv_add_half :
      Tendsto (fun N : ℕ => (1 / 2 : ℂ) * (z + (N : ℂ))⁻¹) atTop (𝓝 (0 : ℂ)) := by
    simpa using (tendsto_const_nhds.mul h_inv_add)
  have hI :
      Tendsto (fun N : ℕ => ∫ x in (0 : ℝ)..(N : ℝ),
          (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3) atTop (𝓝 Iinf) := by
    have h_int :
        IntegrableOn (fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
          (Set.Ioi (0 : ℝ)) volume := by
      simpa [IntegrableOn] using (integrable_bernoulli2Diff_div z hz)
    simpa [Iinf] using
      (intervalIntegral_tendsto_integral_Ioi (a := (0 : ℝ))
        (f := fun x : ℝ => (bernoulli2Diff x : ℂ) / ((x : ℂ) + z) ^ 3)
        (μ := volume) (b := fun N : ℕ => (N : ℝ)) (l := atTop)
        h_int (tendsto_natCast_atTop_atTop))
  have hF_lim :
      Tendsto F atTop (𝓝 (B - Iinf)) := by
    have hAB : Tendsto (fun N => A N + B) atTop (𝓝 (0 + B)) :=
      hlog.add tendsto_const_nhds
    have hABC : Tendsto (fun N => A N + B - C N) atTop (𝓝 (B - 0)) :=
      by
        simpa [C] using (hAB.sub h_inv_add_half)
    have hABCD : Tendsto (fun N => A N + B - C N - D N) atTop (𝓝 (B - 0 - Iinf)) :=
      hABC.sub hI
    simpa [F, A, B, C, D, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using hABCD
  have hlim : Q3.digamma z = B - Iinf := tendsto_nhds_unique hF_tendsto hF_lim
  have hlim' :
      Q3.digamma z - (Complex.log z - (1 / 2 : ℂ) * z⁻¹) = -Iinf := by
    have h := congrArg (fun t => t - (Complex.log z - (1 / 2 : ℂ) * z⁻¹)) hlim
    simpa [B, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using h
  calc
    Q3.digamma z - Complex.log z + (1 / 2 : ℂ) * z⁻¹
        = Q3.digamma z - (Complex.log z - (1 / 2 : ℂ) * z⁻¹) := by
            ring
    _ = -Iinf := hlim'

lemma re_digamma_remainder_bound_stieltjes (z : ℂ) (hz : 0 < z.re) :
    |(Q3.digamma z).re - Real.log ‖z‖ + z.re / (2 * ‖z‖^2)| ≤
      1 / (4 * ‖z‖^2) := by
  classical
  set E : ℂ := Q3.digamma z - Complex.log z + (1 / (2 : ℂ)) * z⁻¹
  have hE : E = -∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3 := by
    simpa [E] using (digamma_stieltjes_identity z hz)
  have hB : ∀ x : ℝ, ‖(bernoulli2Diff x : ℂ)‖ ≤ (1 / 4 : ℝ) := by
    intro x
    have hb0 : 0 ≤ bernoulli2Diff x := (bernoulli2Diff_bounds x).1
    have hb1 : bernoulli2Diff x ≤ (1 / 4 : ℝ) := (bernoulli2Diff_bounds x).2
    have habs : |bernoulli2Diff x| = bernoulli2Diff x := by simp [abs_of_nonneg hb0]
    have hnorm : ‖(bernoulli2Diff x : ℂ)‖ = |bernoulli2Diff x| := by
      simp
    simpa [hnorm, habs] using hb1
  have hF_bound :
      ∀ x : ℝ,
        ‖(bernoulli2Diff x : ℂ) / (x + z) ^ 3‖
          ≤ (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
    intro x
    have hnorm_pow : ‖(x + z : ℂ) ^ 3‖ = ‖(x + z : ℂ)‖ ^ 3 := by
      simp [norm_pow]
    have hpos : 0 ≤ ‖(x : ℂ) + z‖ ^ 3 := by positivity
    calc
      ‖(bernoulli2Diff x : ℂ) / (x + z) ^ 3‖
          = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x + z : ℂ) ^ 3‖ := by
            simp
      _ = ‖(bernoulli2Diff x : ℂ)‖ / ‖(x : ℂ) + z‖ ^ 3 := by
            simp [hnorm_pow]
      _ ≤ (1 / 4 : ℝ) / ‖(x : ℂ) + z‖ ^ 3 := by
            exact (div_le_div_of_nonneg_right (hB x) hpos)
      _ = (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
            field_simp
  -- Build integrability for the kernel via scaling of the exact integral value.
  have hnorm_sq :
      ∀ x : ℝ, ‖(x : ℂ) + z‖ ^ 2 = (x + z.re) ^ 2 + z.im ^ 2 := by
    intro x
    have h' : Complex.normSq ((x : ℂ) + z) =
        (x + z.re) * (x + z.re) + z.im * z.im := by
      simp [Complex.normSq_apply]
    have h'' : ‖(x : ℂ) + z‖ ^ 2 = Complex.normSq ((x : ℂ) + z) := by
      simpa using (Complex.sq_norm ((x : ℂ) + z))
    simpa [pow_two] using (h''.trans h')
  have hpow :
      ∀ x : ℝ, (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ) = ‖(x : ℂ) + z‖ ^ 3 := by
    intro x
    have hbase : 0 ≤ ‖(x : ℂ) + z‖ ^ 2 := by positivity
    have hpos : 0 ≤ ‖(x : ℂ) + z‖ := by positivity
    calc
      (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ)
          = (‖(x : ℂ) + z‖ ^ 2) ^ ((1 / 2 : ℝ) * (3 : ℝ)) := by ring_nf
      _ = ((‖(x : ℂ) + z‖ ^ 2) ^ (1 / 2 : ℝ)) ^ (3 : ℝ) := by
            simpa using
              (Real.rpow_mul (x := ‖(x : ℂ) + z‖ ^ 2) hbase (1 / 2 : ℝ) (3 : ℝ))
      _ = (Real.sqrt (‖(x : ℂ) + z‖ ^ 2)) ^ (3 : ℝ) := by
            simp [Real.sqrt_eq_rpow]
      _ = ‖(x : ℂ) + z‖ ^ (3 : ℝ) := by
            simp
      _ = ‖(x : ℂ) + z‖ ^ 3 := by
            simp
  have hrewrite :
      ∀ x : ℝ,
        1 / ‖(x : ℂ) + z‖ ^ 3 =
          1 / ((x + z.re) ^ 2 + z.im ^ 2) ^ (3 / 2 : ℝ) := by
    intro x
    calc
      1 / ‖(x : ℂ) + z‖ ^ 3
          = 1 / (‖(x : ℂ) + z‖ ^ 2) ^ (3 / 2 : ℝ) := by
              simp [hpow x]
      _ = 1 / ((x + z.re) ^ 2 + z.im ^ 2) ^ (3 / 2 : ℝ) := by
            simp [hnorm_sq x]
  have hkernel_eq :
      ∫ x in Set.Ioi (0 : ℝ), (1 / ‖(x : ℂ) + z‖ ^ 3) =
        1 / (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) := by
    have hbound := integral_kernel_eq (σ := z.re) (τ := z.im) hz
    simpa [hrewrite] using hbound
  have hkernel_ne :
      (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) ≠ 0 := by
    have hpos : 0 < Real.sqrt (z.re ^ 2 + z.im ^ 2) := by
      have hsq : 0 < z.re ^ 2 + z.im ^ 2 := by nlinarith [hz]
      simpa using Real.sqrt_pos.mpr hsq
    have hpos2 : 0 < Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re := by
      nlinarith [hpos, hz]
    nlinarith [hpos, hpos2]
  have hkernel_integrable :
      Integrable (fun x : ℝ => (1 / ‖(x : ℂ) + z‖ ^ 3))
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
    set c : ℝ :=
      1 / (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re))
    have hc : c ≠ 0 := by
      have : (Real.sqrt (z.re ^ 2 + z.im ^ 2) * (Real.sqrt (z.re ^ 2 + z.im ^ 2) + z.re)) ≠ 0 :=
        hkernel_ne
      simpa [c] using (one_div_ne_zero this)
    have hscaled :
        ∫ x in Set.Ioi (0 : ℝ), (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) = (1 : ℝ) := by
      calc
        ∫ x in Set.Ioi (0 : ℝ), (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3)
            = (1 / c : ℝ) * ∫ x in Set.Ioi (0 : ℝ), (1 / ‖(x : ℂ) + z‖ ^ 3) := by
                simp [MeasureTheory.integral_const_mul]
        _ = (1 / c : ℝ) * c := by
              simpa using (congrArg (fun t => (1 / c : ℝ) * t) hkernel_eq)
        _ = (1 : ℝ) := by
              field_simp [hc]
    have hscaled_int :
        Integrable (fun x : ℝ => (1 / c : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3))
          (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
      exact MeasureTheory.integrable_of_integral_eq_one hscaled
    have hgi :
        Integrable (fun x : ℝ => (1 / ‖(x : ℂ) + z‖ ^ 3))
          (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
      have hgi' := hscaled_int.smul c
      refine hgi'.congr ?_
      refine Filter.Eventually.of_forall ?_
      intro x
      have :
          c * (c⁻¹ * (‖(x : ℂ) + z‖ ^ 3)⁻¹) =
            (‖(x : ℂ) + z‖ ^ 3)⁻¹ := by
        field_simp [hc, mul_comm, mul_left_comm, mul_assoc]
      simpa [Pi.smul_apply, smul_eq_mul] using this
    exact hgi
  have hE_norm' :
      ‖E‖ ≤ ∫ x in Set.Ioi (0 : ℝ), (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
    have hle :
        ∀ᵐ x ∂(Measure.restrict volume (Set.Ioi (0 : ℝ))),
          ‖(bernoulli2Diff x : ℂ) / (x + z) ^ 3‖
            ≤ (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3) := by
      exact Filter.Eventually.of_forall hF_bound
    have hgi :
        Integrable (fun x : ℝ => (1 / 4 : ℝ) * (1 / ‖(x : ℂ) + z‖ ^ 3))
          (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) := by
      simpa using hkernel_integrable.smul (1 / 4 : ℝ)
    have hnorm :
        ‖E‖ = ‖∫ x in Set.Ioi (0 : ℝ), (bernoulli2Diff x : ℂ) / (x + z) ^ 3‖ := by
      simp [hE, norm_neg]
    have h' :=
      (MeasureTheory.norm_integral_le_of_norm_le
        (μ := Measure.restrict volume (Set.Ioi (0 : ℝ))) hgi hle)
    simpa [hnorm] using h'
  have hkernel :
      ∫ x in Set.Ioi (0 : ℝ), (1 / ‖(x : ℂ) + z‖ ^ 3)
        ≤ 1 / ‖z‖ ^ 2 := by
    have hnormsq : (z.re ^ 2 + z.im ^ 2) = ‖z‖ ^ 2 := by
      have h1 : (z.re ^ 2 + z.im ^ 2) = Complex.normSq z := by
        simp [Complex.normSq_apply, pow_two]
      have h2 : Complex.normSq z = ‖z‖ ^ 2 := by
        simpa using (Complex.normSq_eq_norm_sq z)
      exact h1.trans h2
    have hbound := integral_kernel_bound (σ := z.re) (τ := z.im) hz
    simpa [hrewrite, hnormsq] using hbound
  have hE_final :
      ‖E‖ ≤ 1 / (4 * ‖z‖ ^ 2) := by
    have hE_norm'' :
        ‖E‖ ≤ ∫ x in Set.Ioi (0 : ℝ), (4⁻¹ : ℝ) * (‖(x : ℂ) + z‖ ^ 3)⁻¹ := by
      simpa [one_div] using hE_norm'
    have hkernel' :
        ∫ x in Set.Ioi (0 : ℝ), (‖(x : ℂ) + z‖ ^ 3)⁻¹ ≤ (‖z‖ ^ 2)⁻¹ := by
      simpa [one_div] using hkernel
    have h' :
        (4⁻¹ : ℝ) * ∫ x in Set.Ioi (0 : ℝ), (‖(x : ℂ) + z‖ ^ 3)⁻¹
          ≤ (4⁻¹ : ℝ) * (‖z‖ ^ 2)⁻¹ := by
      exact mul_le_mul_of_nonneg_left hkernel' (by norm_num : (0 : ℝ) ≤ (4⁻¹ : ℝ))
    refine le_trans hE_norm'' ?_
    calc
      ∫ x in Set.Ioi (0 : ℝ), (4⁻¹ : ℝ) * (‖(x : ℂ) + z‖ ^ 3)⁻¹
          = (4⁻¹ : ℝ) * ∫ x in Set.Ioi (0 : ℝ), (‖(x : ℂ) + z‖ ^ 3)⁻¹ := by
              simp [MeasureTheory.integral_const_mul]
      _ ≤ (4⁻¹ : ℝ) * (‖z‖ ^ 2)⁻¹ := h'
      _ = 1 / (4 * ‖z‖ ^ 2) := by
            field_simp
  have hlog : (Complex.log z).re = Real.log ‖z‖ := by
    simp [Complex.log_re]
  have hinv : (z⁻¹).re = z.re / Complex.normSq z := by
    simp [Complex.inv_re]
  have hnormsq : Complex.normSq z = ‖z‖ ^ 2 := by
    simp [Complex.normSq_eq_norm_sq]
  have hRe :
      E.re = (Q3.digamma z).re - Real.log ‖z‖ + z.re / (2 * ‖z‖ ^ 2) := by
    have hhalf : ((1 / (2 : ℂ)) * z⁻¹).re = (1 / 2 : ℝ) * (z⁻¹).re := by
      simp
    have hdiv : (1 / (2 : ℂ)) * z⁻¹ = (1 / (2 * z) : ℂ) := by
      field_simp [mul_comm, mul_left_comm, mul_assoc]
    calc
      E.re
          = (Q3.digamma z).re - (Complex.log z).re + ((1 / (2 : ℂ)) * z⁻¹).re := by
            simp [E, add_comm, add_left_comm, add_assoc, sub_eq_add_neg]
      _ = (Q3.digamma z).re - Real.log ‖z‖ + (1 / 2 : ℝ) * (z⁻¹).re := by
            simp [hlog, add_comm, add_assoc, sub_eq_add_neg]
      _ = (Q3.digamma z).re - Real.log ‖z‖ + z.re / (2 * ‖z‖ ^ 2) := by
            simp [hinv, hnormsq, mul_comm, mul_assoc, div_eq_mul_inv]
  have hRe_abs :
      |(Q3.digamma z).re - Real.log ‖z‖ + z.re / (2 * ‖z‖ ^ 2)| ≤ ‖E‖ := by
    simpa [hRe] using (RCLike.abs_re_le_norm E)
  exact le_trans hRe_abs hE_final

end Q3
