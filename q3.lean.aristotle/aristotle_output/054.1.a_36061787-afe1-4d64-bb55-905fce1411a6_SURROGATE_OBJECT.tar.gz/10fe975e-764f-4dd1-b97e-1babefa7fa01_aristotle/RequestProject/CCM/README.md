# CCM cell (13, 2) — WR enclosures

This directory contains a complete, `sorry`-free Lean 4 / Mathlib development of the
two-sided rational enclosures for the archimedean remainder (`WR`) entries of the CCM
cell `(13, 2)`.

## Important note on the definitions

The submitted task referred to an upstream module supplying `ccmL`, `CCMModeFinite`,
`ccmModeFinite`, `ccmQKernel`, `ccmWREntry`, `ccmW02Entry`, `ccmPrimeEntryN1`, …, and to
an external document supplying the numerical `τ⁻ / τ⁺` tables.  Neither was present in
the project that was provided, so **all of these objects were reconstructed here from
the specification**, in `Defs.lean`, and the rational bound tables were computed from
those definitions.  If the original sources become available, `Defs.lean` can be
replaced by them and the rest of the development re-run against the real definitions.

## Contents

* `Defs.lean` — the reconstructed CCM finite Weil-source objects at cut-off
  `L = log N`:
  * mode index type `CCMModeFinite N = Fin (2N+1)` with modes `-N, …, N`;
  * mode function `x ↦ cosh (n x)` and pair test function
    `ccmQKernel n m x = cosh (n x) cosh (m x)`;
  * `ccmW02Entry L n m = ∫_{-L}^{L} g (2 cosh (x/2))` — the polar term
    `ĝ(i/2) + ĝ(-i/2)`;
  * `ccmPrimeEntryN1 M n m = ∑_{q ≤ M} Λ(q) q^{-1/2} (g (log q) + g (-log q))`;
  * `ccmWREntry L n m = ∫_0^L (g(x) - g(0)) ∑_{j ≤ 2} e^{-(2j+1)x/2} dx` — the
    archimedean remainder against the level-`2` truncation of `1/(2 sinh (x/2))`.

* `Constants.lean` — rational enclosures, of width `< 10⁻⁹⁷`, for `√p`, `log p` and
  `log p · √p` (`p ∈ {2,3,5,7,11,13}`).  The logarithms come from the Mercator series
  with explicit remainder (`Real.abs_log_sub_add_sum_range_le`) at
  `1 - 1/k`, `k ∈ {9,16,25,49,121,169}`, combined through the exact linear relations
  `log 2 = -3 log(8/9) - 2 log(24/25) - 4 log(15/16)`, etc.

* `ClosedForm.lean` — exact closed forms.  Every `W02` and `WR` entry is an integral of
  a finite combination of exponentials `e^{u x/2}` (`u` an odd integer), hence lies in
  `ℚ + ℚ√13`; every prime term is a rational combination of `log p` and `log p · √p`.
  No quadrature and no numerical evaluation of `exp`/`log` is used anywhere.

* `Cell13N2.lean` — the rational tables `tauLower512`, `tauUpper512` (centrosymmetric,
  reduced to the six distinct `(|n|,|m|)` classes), the main theorem
  `ccmCell13N2_wr_enclosures`, and `tau512_width`, which states that every ball has
  width exactly `10⁻⁸⁸`.

## Guarantees

* No `sorry`, no `axiom`, no `native_decide`, no `Float`, no quadrature or sampling.
* `#print axioms ccmCell13N2_wr_enclosures` returns exactly
  `[propext, Classical.choice, Quot.sound]`.
