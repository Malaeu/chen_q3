import RequestProject.CCM.Defs

/-!
# Closed forms for the entries of the CCM cell `(13, 2)`

At the cut-off `L = log 13` all three families of terms are elementary:

* `ccmW02Entry` and `ccmWREntry` are integrals of finite combinations of real
  exponentials `exp (u x / 2)` with `u` an odd integer, hence lie in `ℚ + ℚ √13`;
* `ccmPrimeEntryN1 13` is a rational combination of `log p` and `log p * √p`.

This file computes these exact values.
-/

open scoped BigOperators
open ArithmeticFunction MeasureTheory

set_option maxHeartbeats 1000000

/-! ### Elementary integrals -/

/-- `∫₀^b exp (c x) dx = (exp (c b) - 1)/c`. -/
lemma ccm_integral_exp_mul (c b : ℝ) (hc : c ≠ 0) :
    (∫ x in (0:ℝ)..b, Real.exp (c * x)) = (Real.exp (c * b) - 1) / c := by
  rw [intervalIntegral.integral_comp_mul_left (fun x => Real.exp x) hc]
  simp [integral_exp]
  ring

/-- Expansion of a product of two hyperbolic cosines against an exponential. -/
lemma ccm_cosh_cosh_exp (a b c x : ℝ) :
    Real.cosh (a * x) * Real.cosh (b * x) * Real.exp (c * x)
      = (Real.exp ((a + b + c) * x) + Real.exp ((-a - b + c) * x)
          + Real.exp ((a - b + c) * x) + Real.exp ((-a + b + c) * x)) / 4 := by
  simp [Real.cosh_eq, add_mul, sub_mul, neg_mul, Real.exp_add, Real.exp_sub, Real.exp_neg]
  field_simp
  ring

/-- Exact value of `∫₀^L cosh (a x) cosh (b x) exp (c x) dx`. -/
lemma ccm_integral_cosh_cosh_exp (a b c Lv : ℝ)
    (h1 : a + b + c ≠ 0) (h2 : -a - b + c ≠ 0) (h3 : a - b + c ≠ 0) (h4 : -a + b + c ≠ 0) :
    (∫ x in (0:ℝ)..Lv, Real.cosh (a * x) * Real.cosh (b * x) * Real.exp (c * x))
      = ((Real.exp ((a + b + c) * Lv) - 1) / (a + b + c)
          + (Real.exp ((-a - b + c) * Lv) - 1) / (-a - b + c)
          + (Real.exp ((a - b + c) * Lv) - 1) / (a - b + c)
          + (Real.exp ((-a + b + c) * Lv) - 1) / (-a + b + c)) / 4 := by
  have hint : ∀ t : ℝ, IntervalIntegrable (fun x => Real.exp (t * x)) volume 0 Lv :=
    fun t => (by fun_prop : Continuous fun x : ℝ => Real.exp (t * x)).intervalIntegrable _ _
  simp_rw [ccm_cosh_cosh_exp]
  rw [intervalIntegral.integral_div,
      intervalIntegral.integral_add (((hint _).add (hint _)).add (hint _)) (hint _),
      intervalIntegral.integral_add ((hint _).add (hint _)) (hint _),
      intervalIntegral.integral_add (hint _) (hint _),
      ccm_integral_exp_mul _ _ h1, ccm_integral_exp_mul _ _ h2, ccm_integral_exp_mul _ _ h3,
      ccm_integral_exp_mul _ _ h4]

/-! ### Powers of `√13` -/

lemma ccm_exp_zpow (t : ℝ) (u : ℤ) : Real.exp t ^ u = Real.exp ((u : ℝ) * t) := by
  induction u using Int.induction_on with
  | zero => simp
  | succ k ih =>
      push_cast
      rw [zpow_add_one₀ (Real.exp_ne_zero t), ih, ← Real.exp_add]
      push_cast; ring_nf
  | pred k ih =>
      push_cast
      rw [zpow_sub_one₀ (Real.exp_ne_zero t), ih, ← Real.exp_neg, ← Real.exp_add]
      push_cast; ring_nf

/-- Half-integral powers of `13` in terms of `√13`. -/
lemma ccm_exp_half_log13 (u : ℤ) :
    Real.exp ((u : ℝ) / 2 * Real.log 13) = Real.sqrt 13 ^ u := by
  have h : Real.sqrt 13 = Real.exp (Real.log 13 / 2) := by
    rw [Real.sqrt_eq_rpow, Real.rpow_def_of_pos (by norm_num)]
    ring_nf
  rw [h, ccm_exp_zpow]
  ring_nf

lemma ccm_sqrt13_sq : Real.sqrt 13 ^ 2 = 13 := Real.sq_sqrt (by norm_num)

lemma ccm_sqrt13_pow (k : ℕ) : Real.sqrt 13 ^ (2*k+1) = 13^k * Real.sqrt 13 := by
  rw [pow_succ, pow_mul, ccm_sqrt13_sq]

lemma ccm_exp13_pos (k : ℕ) :
    Real.exp (((2*(k:ℝ)+1)/2) * Real.log 13) = 13^k * Real.sqrt 13 := by
  have h := ccm_exp_half_log13 (2*(k:ℤ)+1)
  push_cast at h
  rw [h, show (2*(k:ℤ)+1) = ((2*k+1 : ℕ) : ℤ) by push_cast; ring, zpow_natCast, ccm_sqrt13_pow]

lemma ccm_exp13_neg (k : ℕ) :
    Real.exp (-((2*(k:ℝ)+1)/2 * Real.log 13)) = Real.sqrt 13 / 13^(k+1) := by
  have h := ccm_exp_half_log13 (-(2*(k:ℤ)+1))
  push_cast at h
  rw [show -((2*(k:ℝ)+1)/2 * Real.log 13) = (-(2*(k:ℝ)+1))/2 * Real.log 13 by ring] at *
  rw [h, show (-(2*(k:ℤ)+1)) = -((2*k+1 : ℕ) : ℤ) by push_cast; ring, zpow_neg, zpow_natCast,
    ccm_sqrt13_pow, eq_div_iff (by positivity), inv_mul_eq_div, div_eq_iff (by positivity),
    show Real.sqrt 13 * (13^k * Real.sqrt 13) = 13^k * (Real.sqrt 13 * Real.sqrt 13) by ring,
    Real.mul_self_sqrt (by norm_num)]
  ring

lemma ccm_e13_p1 : Real.exp (1 / 2 * Real.log 13) = Real.sqrt 13 := by
  have h := ccm_exp13_pos 0; norm_num at h; exact h

lemma ccm_e13_p3 : Real.exp (3 / 2 * Real.log 13) = 13 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 1; norm_num at h; exact h

lemma ccm_e13_p5 : Real.exp (5 / 2 * Real.log 13) = 169 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 2; norm_num at h; exact h

lemma ccm_e13_p7 : Real.exp (7 / 2 * Real.log 13) = 2197 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 3; norm_num at h; exact h

lemma ccm_e13_p9 : Real.exp (9 / 2 * Real.log 13) = 28561 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 4; norm_num at h; exact h

lemma ccm_e13_p11 : Real.exp (11 / 2 * Real.log 13) = 371293 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 5; norm_num at h; exact h

lemma ccm_e13_p13 : Real.exp (13 / 2 * Real.log 13) = 4826809 * Real.sqrt 13 := by
  have h := ccm_exp13_pos 6; norm_num at h; exact h

lemma ccm_e13_n1 : Real.exp (-(1 / 2 * Real.log 13)) = Real.sqrt 13 / 13 := by
  have h := ccm_exp13_neg 0; norm_num at h; exact h

lemma ccm_e13_n3 : Real.exp (-(3 / 2 * Real.log 13)) = Real.sqrt 13 / 169 := by
  have h := ccm_exp13_neg 1; norm_num at h; exact h

lemma ccm_e13_n5 : Real.exp (-(5 / 2 * Real.log 13)) = Real.sqrt 13 / 2197 := by
  have h := ccm_exp13_neg 2; norm_num at h; exact h

lemma ccm_e13_n7 : Real.exp (-(7 / 2 * Real.log 13)) = Real.sqrt 13 / 28561 := by
  have h := ccm_exp13_neg 3; norm_num at h; exact h

lemma ccm_e13_n9 : Real.exp (-(9 / 2 * Real.log 13)) = Real.sqrt 13 / 371293 := by
  have h := ccm_exp13_neg 4; norm_num at h; exact h

lemma ccm_e13_n11 : Real.exp (-(11 / 2 * Real.log 13)) = Real.sqrt 13 / 4826809 := by
  have h := ccm_exp13_neg 5; norm_num at h; exact h

lemma ccm_e13_n13 : Real.exp (-(13 / 2 * Real.log 13)) = Real.sqrt 13 / 62748517 := by
  have h := ccm_exp13_neg 6; norm_num at h; exact h


/-! ### Reduction of the entries to elementary integrals -/

/-- The `WR` entry as a combination of elementary integrals. -/
lemma ccm_wr_entry_eq (Lv : ℝ) (n m : ℤ) :
    ccmWREntry Lv n m
      = ((∫ x in (0:ℝ)..Lv,
            Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(1/2 : ℝ) * x))
          - ∫ x in (0:ℝ)..Lv, Real.exp (-(1/2 : ℝ) * x))
        + ((∫ x in (0:ℝ)..Lv,
            Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(3/2 : ℝ) * x))
          - ∫ x in (0:ℝ)..Lv, Real.exp (-(3/2 : ℝ) * x))
        + ((∫ x in (0:ℝ)..Lv,
            Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(5/2 : ℝ) * x))
          - ∫ x in (0:ℝ)..Lv, Real.exp (-(5/2 : ℝ) * x)) := by
  have hE : ∀ t : ℝ, IntervalIntegrable (fun x => Real.exp (t * x)) volume 0 Lv :=
    fun t => (by fun_prop : Continuous fun x : ℝ => Real.exp (t * x)).intervalIntegrable _ _
  have hC : ∀ t : ℝ, IntervalIntegrable
      (fun x => Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (t * x)) volume 0 Lv :=
    fun t => (by fun_prop : Continuous fun x : ℝ =>
      Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (t * x)).intervalIntegrable _ _
  have hrw : ∀ x : ℝ, ccmWRFiniteExtendedIntegrand 2 n m x
      = (Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(1/2 : ℝ) * x)
          - Real.exp (-(1/2 : ℝ) * x))
        + (Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(3/2 : ℝ) * x)
          - Real.exp (-(3/2 : ℝ) * x))
        + (Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(5/2 : ℝ) * x)
          - Real.exp (-(5/2 : ℝ) * x)) := by
    intro x
    unfold ccmWRFiniteExtendedIntegrand ccmArchKernelFinite ccmQKernel ccmModeFun
    simp only [Finset.sum_range_succ, Finset.sum_range_zero]
    norm_num
    ring
  unfold ccmWREntry
  simp_rw [hrw]
  rw [intervalIntegral.integral_add (((hC _).sub (hE _)).add ((hC _).sub (hE _)))
        ((hC _).sub (hE _)),
      intervalIntegral.integral_add ((hC _).sub (hE _)) ((hC _).sub (hE _)),
      intervalIntegral.integral_sub (hC _) (hE _),
      intervalIntegral.integral_sub (hC _) (hE _),
      intervalIntegral.integral_sub (hC _) (hE _)]

/-- The `W02` entry as a combination of elementary integrals. -/
lemma ccm_w02_entry_eq (Lv : ℝ) (n m : ℤ) :
    ccmW02Entry Lv n m
      = 2 * ((∫ x in (0:ℝ)..Lv,
              Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp ((1/2 : ℝ) * x))
            + ∫ x in (0:ℝ)..Lv,
              Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(1/2 : ℝ) * x)) := by
  set f : ℝ → ℝ := fun x => ccmQKernel n m x * (2 * Real.cosh (x/2)) with hf
  have hcont : Continuous f := by
    simp only [hf, ccmQKernel, ccmModeFun]; fun_prop
  have heven : ∀ x : ℝ, f (-x) = f x := by
    intro x; simp only [hf, ccmQKernel, ccmModeFun]
    simp [Real.cosh_neg, mul_neg, neg_div]
  have hsplit : (∫ x in (-Lv)..Lv, f x) = (∫ x in (-Lv)..(0:ℝ), f x) + ∫ x in (0:ℝ)..Lv, f x :=
    (intervalIntegral.integral_add_adjacent_intervals
      (hcont.intervalIntegrable _ _) (hcont.intervalIntegrable _ _)).symm
  have hneg : (∫ x in (-Lv)..(0:ℝ), f x) = ∫ x in (0:ℝ)..Lv, f x := by
    have key := intervalIntegral.integral_comp_neg (a := (0:ℝ)) (b := Lv) f
    simp only [heven, neg_zero] at key
    exact key.symm
  have hC : ∀ t : ℝ, IntervalIntegrable
      (fun x => Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (t * x)) volume 0 Lv :=
    fun t => (by fun_prop : Continuous fun x : ℝ =>
      Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (t * x)).intervalIntegrable _ _
  have hrw : ∀ x : ℝ, f x
      = Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp ((1/2 : ℝ) * x)
        + Real.cosh ((n:ℝ) * x) * Real.cosh ((m:ℝ) * x) * Real.exp (-(1/2 : ℝ) * x) := by
    intro x
    simp only [hf, ccmQKernel, ccmModeFun]
    rw [show Real.cosh (x/2) = (Real.exp (x/2) + Real.exp (-(x/2)))/2 from Real.cosh_eq _]
    rw [show x/2 = (1/2 : ℝ) * x by ring, show -((1/2 : ℝ) * x) = -(1/2 : ℝ) * x by ring]
    ring
  have hW : ccmW02Entry Lv n m = ∫ x in (-Lv)..Lv, f x := rfl
  rw [hW, hsplit, hneg]
  simp_rw [hrw]
  rw [intervalIntegral.integral_add (hC _) (hC _)]
  ring


/-! ### The prime-power term -/

/-- A single prime-power term of `ccmPrimeEntryN1`. -/
noncomputable def ccmPrimeTerm (q : ℕ) (n m : ℤ) : ℝ :=
  (ArithmeticFunction.vonMangoldt q / Real.sqrt q) *
    (ccmQKernel n m (Real.log q) + ccmQKernel n m (-Real.log q))

/-- Only the nine prime powers `≤ 13` contribute to `ccmPrimeEntryN1 13`. -/
lemma ccm_prime_entry_13_eq (n m : ℤ) :
    ccmPrimeEntryN1 13 n m
      = ccmPrimeTerm 2 n m + ccmPrimeTerm 3 n m + ccmPrimeTerm 4 n m + ccmPrimeTerm 5 n m
        + ccmPrimeTerm 7 n m + ccmPrimeTerm 8 n m + ccmPrimeTerm 9 n m + ccmPrimeTerm 11 n m
        + ccmPrimeTerm 13 n m := by
  have h6 : (vonMangoldt 6 : ℝ) = 0 := by
    rw [vonMangoldt_eq_zero_iff, isPrimePow_nat_iff_bounded]; decide
  have h10 : (vonMangoldt 10 : ℝ) = 0 := by
    rw [vonMangoldt_eq_zero_iff, isPrimePow_nat_iff_bounded]; decide
  have h12 : (vonMangoldt 12 : ℝ) = 0 := by
    rw [vonMangoldt_eq_zero_iff, isPrimePow_nat_iff_bounded]; decide
  have hsum : ccmPrimeEntryN1 13 n m = ∑ q ∈ Finset.Icc 2 13, ccmPrimeTerm q n m := rfl
  rw [hsum, show Finset.Icc 2 13 = ({2,3,4,5,6,7,8,9,10,11,12,13} : Finset ℕ) by decide]
  rw [Finset.sum_insert (by decide), Finset.sum_insert (by decide), Finset.sum_insert (by decide),
      Finset.sum_insert (by decide), Finset.sum_insert (by decide), Finset.sum_insert (by decide),
      Finset.sum_insert (by decide), Finset.sum_insert (by decide), Finset.sum_insert (by decide),
      Finset.sum_insert (by decide), Finset.sum_insert (by decide), Finset.sum_singleton]
  simp only [ccmPrimeTerm, h6, h10, h12, zero_div, zero_mul]
  ring

/-- `cosh (k log q) = (q^k + q^{-k})/2`. -/
lemma ccm_cosh_log (k : ℤ) (q : ℕ) (hq : 0 < q) :
    Real.cosh ((k : ℝ) * Real.log q) = ((q : ℝ) ^ k + (q : ℝ) ^ (-k)) / 2 := by
  have hq' : (0:ℝ) < (q:ℝ) := by exact_mod_cast hq
  have e : ∀ j : ℤ, Real.exp ((j:ℝ) * Real.log q) = (q:ℝ)^j := by
    intro j; rw [← ccm_exp_zpow, Real.exp_log hq']
  rw [Real.cosh_eq, show -((k:ℝ) * Real.log q) = ((-k : ℤ):ℝ) * Real.log q by push_cast; ring,
    e k, e (-k)]

lemma ccm_prime_term_gen (q : ℕ) (hq : 0 < q) (n m : ℤ) :
    ccmPrimeTerm q n m
      = ((vonMangoldt q : ℝ) / Real.sqrt q) *
          (((q:ℝ) ^ n + (q:ℝ) ^ (-n)) * ((q:ℝ) ^ m + (q:ℝ) ^ (-m)) / 2) := by
  simp only [ccmPrimeTerm, ccmQKernel, ccmModeFun, mul_neg, Real.cosh_neg]
  rw [ccm_cosh_log n q hq, ccm_cosh_log m q hq]
  ring

lemma ccm_vonMangoldt_prime (p : ℕ) (hp : p.Prime) : (vonMangoldt p : ℝ) = Real.log p := by
  norm_num [vonMangoldt_apply, hp.isPrimePow, hp.minFac_eq]

lemma ccm_vonMangoldt_four : (vonMangoldt 4 : ℝ) = Real.log 2 := by
  have h : IsPrimePow 4 := ⟨2, 2, Nat.prime_two.prime, by norm_num, by norm_num⟩
  norm_num [vonMangoldt_apply, h]

lemma ccm_vonMangoldt_eight : (vonMangoldt 8 : ℝ) = Real.log 2 := by
  have h : IsPrimePow 8 := ⟨2, 3, Nat.prime_two.prime, by norm_num, by norm_num⟩
  norm_num [vonMangoldt_apply, h]

lemma ccm_vonMangoldt_nine : (vonMangoldt 9 : ℝ) = Real.log 3 := by
  have h : IsPrimePow 9 := ⟨3, 2, Nat.prime_three.prime, by norm_num, by norm_num⟩
  norm_num [vonMangoldt_apply, h]

lemma ccm_coef_2 : ((vonMangoldt 2 : ℝ)) / Real.sqrt 2 = Real.log 2 * Real.sqrt 2 / 2 := by
  rw [ccm_vonMangoldt_prime 2 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_3 : ((vonMangoldt 3 : ℝ)) / Real.sqrt 3 = Real.log 3 * Real.sqrt 3 / 3 := by
  rw [ccm_vonMangoldt_prime 3 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_5 : ((vonMangoldt 5 : ℝ)) / Real.sqrt 5 = Real.log 5 * Real.sqrt 5 / 5 := by
  rw [ccm_vonMangoldt_prime 5 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_7 : ((vonMangoldt 7 : ℝ)) / Real.sqrt 7 = Real.log 7 * Real.sqrt 7 / 7 := by
  rw [ccm_vonMangoldt_prime 7 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_11 : ((vonMangoldt 11 : ℝ)) / Real.sqrt 11 = Real.log 11 * Real.sqrt 11 / 11 := by
  rw [ccm_vonMangoldt_prime 11 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_13 : ((vonMangoldt 13 : ℝ)) / Real.sqrt 13 = Real.log 13 * Real.sqrt 13 / 13 := by
  rw [ccm_vonMangoldt_prime 13 (by norm_num),
    div_eq_div_iff (Real.sqrt_pos.mpr (by norm_num)).ne' (by norm_num), mul_assoc,
    Real.mul_self_sqrt (by norm_num)]
  norm_num

lemma ccm_coef_8 : ((vonMangoldt 8 : ℝ)) / Real.sqrt 8 = Real.log 2 * Real.sqrt 2 / 4 := by
  have hs : Real.sqrt 8 = 2 * Real.sqrt 2 := by
    rw [show (8:ℝ) = 2^2*2 by norm_num, Real.sqrt_mul (by positivity), Real.sqrt_sq (by norm_num)]
  rw [ccm_vonMangoldt_eight, hs, div_eq_div_iff (by positivity) (by norm_num), mul_assoc,
    mul_comm (Real.sqrt 2) (2 * Real.sqrt 2), mul_assoc, Real.mul_self_sqrt (by norm_num)]
  ring

lemma ccm_prime_term_2 (n m : ℤ) :
    ccmPrimeTerm 2 n m
      = (Real.log 2 * Real.sqrt 2) * (((2:ℝ) ^ n + (2:ℝ) ^ (-n)) * ((2:ℝ) ^ m + (2:ℝ) ^ (-m)) / 4) := by
  rw [ccm_prime_term_gen 2 (by norm_num)]
  norm_num [ccm_coef_2]
  ring

lemma ccm_prime_term_3 (n m : ℤ) :
    ccmPrimeTerm 3 n m
      = (Real.log 3 * Real.sqrt 3) * (((3:ℝ) ^ n + (3:ℝ) ^ (-n)) * ((3:ℝ) ^ m + (3:ℝ) ^ (-m)) / 6) := by
  rw [ccm_prime_term_gen 3 (by norm_num)]
  norm_num [ccm_coef_3]
  ring

lemma ccm_prime_term_4 (n m : ℤ) :
    ccmPrimeTerm 4 n m
      = (Real.log 2) * (((4:ℝ) ^ n + (4:ℝ) ^ (-n)) * ((4:ℝ) ^ m + (4:ℝ) ^ (-m)) / 4) := by
  rw [ccm_prime_term_gen 4 (by norm_num)]
  norm_num [ccm_vonMangoldt_four]
  ring

lemma ccm_prime_term_5 (n m : ℤ) :
    ccmPrimeTerm 5 n m
      = (Real.log 5 * Real.sqrt 5) * (((5:ℝ) ^ n + (5:ℝ) ^ (-n)) * ((5:ℝ) ^ m + (5:ℝ) ^ (-m)) / 10) := by
  rw [ccm_prime_term_gen 5 (by norm_num)]
  norm_num [ccm_coef_5]
  ring

lemma ccm_prime_term_7 (n m : ℤ) :
    ccmPrimeTerm 7 n m
      = (Real.log 7 * Real.sqrt 7) * (((7:ℝ) ^ n + (7:ℝ) ^ (-n)) * ((7:ℝ) ^ m + (7:ℝ) ^ (-m)) / 14) := by
  rw [ccm_prime_term_gen 7 (by norm_num)]
  norm_num [ccm_coef_7]
  ring

lemma ccm_prime_term_8 (n m : ℤ) :
    ccmPrimeTerm 8 n m
      = (Real.log 2 * Real.sqrt 2) * (((8:ℝ) ^ n + (8:ℝ) ^ (-n)) * ((8:ℝ) ^ m + (8:ℝ) ^ (-m)) / 8) := by
  rw [ccm_prime_term_gen 8 (by norm_num)]
  norm_num [ccm_coef_8]
  ring

lemma ccm_prime_term_9 (n m : ℤ) :
    ccmPrimeTerm 9 n m
      = (Real.log 3) * (((9:ℝ) ^ n + (9:ℝ) ^ (-n)) * ((9:ℝ) ^ m + (9:ℝ) ^ (-m)) / 6) := by
  rw [ccm_prime_term_gen 9 (by norm_num)]
  norm_num [ccm_vonMangoldt_nine]
  ring

lemma ccm_prime_term_11 (n m : ℤ) :
    ccmPrimeTerm 11 n m
      = (Real.log 11 * Real.sqrt 11) * (((11:ℝ) ^ n + (11:ℝ) ^ (-n)) * ((11:ℝ) ^ m + (11:ℝ) ^ (-m)) / 22) := by
  rw [ccm_prime_term_gen 11 (by norm_num)]
  norm_num [ccm_coef_11]
  ring

lemma ccm_prime_term_13 (n m : ℤ) :
    ccmPrimeTerm 13 n m
      = (Real.log 13 * Real.sqrt 13) * (((13:ℝ) ^ n + (13:ℝ) ^ (-n)) * ((13:ℝ) ^ m + (13:ℝ) ^ (-m)) / 26) := by
  rw [ccm_prime_term_gen 13 (by norm_num)]
  norm_num [ccm_coef_13]
  ring


/-! ### The entry values -/

lemma ccm_w02_value_0_0 :
    ccmW02Entry (ccmL 13) 0 0 = (48/13 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((0:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((0:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_n1]
  ring

lemma ccm_wr_value_0_0 :
    ccmWREntry (ccmL 13) 0 0 = 0 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((0:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((0:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((0:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_n1, ccm_e13_n3, ccm_e13_n5]
  ring

lemma ccm_prime_value_0_0 :
    ccmPrimeEntryN1 13 0 0 =
        (1 : ℝ) * Real.log 2
        + (2/3 : ℝ) * Real.log 3
        + (3/2 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (2/3 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (2/5 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (2/7 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (2/11 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (2/13 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring

lemma ccm_w02_value_0_1 :
    ccmW02Entry (ccmL 13) 0 1 = (1776/169 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((1:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((1:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_n1, ccm_e13_n3]
  ring

lemma ccm_wr_value_0_1 :
    ccmWREntry (ccmL 13) 0 1 = (-72/35 : ℝ) + (1076616/999635 : ℝ) * Real.sqrt 13 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((1:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((1:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((1:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n7]
  ring

lemma ccm_prime_value_0_1 :
    ccmPrimeEntryN1 13 0 1 =
        (17/8 : ℝ) * Real.log 2
        + (82/27 : ℝ) * Real.log 3
        + (105/32 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (10/9 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (26/25 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (50/49 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (122/121 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (170/169 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring

lemma ccm_w02_value_0_2 :
    ccmW02Entry (ccmL 13) 0 2 = (837744/10985 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((2:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p3, ccm_e13_p5, ccm_e13_n3, ccm_e13_n5]
  ring

lemma ccm_wr_value_0_2 :
    ccmWREntry (ccmL 13) 0 2 = (-928/315 : ℝ) + (633240352/116957295 : ℝ) * Real.sqrt 13 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((2:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((0:ℤ):ℝ) ((2:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n7, ccm_e13_n9]
  ring

lemma ccm_prime_value_0_2 :
    ccmPrimeEntryN1 13 0 2 =
        (257/32 : ℝ) * Real.log 2
        + (6562/243 : ℝ) * Real.log 3
        + (4641/256 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (82/27 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (626/125 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (2402/343 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (14642/1331 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (28562/2197 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring

lemma ccm_w02_value_1_1 :
    ccmW02Entry (ccmL 13) 1 1 = (439152/10985 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((1:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((1:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_p5, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5]
  ring

lemma ccm_wr_value_1_1 :
    ccmWREntry (ccmL 13) 1 1 = (-464/315 : ℝ) + (316620176/116957295 : ℝ) * Real.sqrt 13 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((1:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((1:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((1:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n7, ccm_e13_n9]
  ring

lemma ccm_prime_value_1_1 :
    ccmPrimeEntryN1 13 1 1 =
        (289/64 : ℝ) * Real.log 2
        + (3362/243 : ℝ) * Real.log 3
        + (5025/512 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (50/27 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (338/125 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (1250/343 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (7442/1331 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (14450/2197 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring

lemma ccm_w02_value_1_2 :
    ccmW02Entry (ccmL 13) 1 2 = (352782672/999635 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((2:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_p5, ccm_e13_p7, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n7]
  ring

lemma ccm_wr_value_1_2 :
    ccmWREntry (ccmL 13) 1 2 = (-10936/3465 : ℝ) + (337577837368/16724893185 : ℝ) * Real.sqrt 13 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((2:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((1:ℤ):ℝ) ((2:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p3, ccm_e13_p5, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n7, ccm_e13_n9, ccm_e13_n11]
  ring

lemma ccm_prime_value_1_2 :
    ccmPrimeEntryN1 13 1 2 =
        (4369/256 : ℝ) * Real.log 2
        + (269042/2187 : ℝ) * Real.log 3
        + (277185/4096 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (410/81 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (8138/625 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (60050/2401 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (893162/14641 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (2427770/28561 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring

lemma ccm_w02_value_2_2 :
    ccmW02Entry (ccmL 13) 2 2 = (9068472912/2599051 : ℝ) * Real.sqrt 13 := by
  rw [ccm_w02_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((2:ℤ):ℝ) ((2:ℤ):ℝ) (1/2) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((2:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  norm_num [ccmL]
  simp only [ccm_e13_p1, ccm_e13_p7, ccm_e13_p9, ccm_e13_n1, ccm_e13_n7, ccm_e13_n9]
  ring

lemma ccm_wr_value_2_2 :
    ccmWREntry (ccmL 13) 2 2 = (-78016/45045 : ℝ) + (99535003753664/565301389653 : ℝ) * Real.sqrt 13 := by
  rw [ccm_wr_entry_eq]
  rw [ccm_integral_cosh_cosh_exp ((2:ℤ):ℝ) ((2:ℤ):ℝ) (-(1/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((2:ℤ):ℝ) ((2:ℤ):ℝ) (-(3/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_cosh_cosh_exp ((2:ℤ):ℝ) ((2:ℤ):ℝ) (-(5/2)) (ccmL 13) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
      ccm_integral_exp_mul _ _ (by norm_num : (-(1/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(3/2):ℝ) ≠ 0),
      ccm_integral_exp_mul _ _ (by norm_num : (-(5/2):ℝ) ≠ 0)]
  norm_num [ccmL]
  simp only [ccm_e13_p3, ccm_e13_p5, ccm_e13_p7, ccm_e13_n1, ccm_e13_n3, ccm_e13_n5, ccm_e13_n9, ccm_e13_n11, ccm_e13_n13]
  ring

lemma ccm_prime_value_2_2 :
    ccmPrimeEntryN1 13 2 2 =
        (66049/1024 : ℝ) * Real.log 2
        + (21529922/19683 : ℝ) * Real.log 3
        + (16933377/32768 : ℝ) * (Real.log 2 * Real.sqrt 2)
        + (3362/243 : ℝ) * (Real.log 3 * Real.sqrt 3)
        + (195938/3125 : ℝ) * (Real.log 5 * Real.sqrt 5)
        + (2884802/16807 : ℝ) * (Real.log 7 * Real.sqrt 7)
        + (107194082/161051 : ℝ) * (Real.log 11 * Real.sqrt 11)
        + (407893922/371293 : ℝ) * (Real.log 13 * Real.sqrt 13) := by
  rw [ccm_prime_entry_13_eq, ccm_prime_term_2, ccm_prime_term_3, ccm_prime_term_4,
    ccm_prime_term_5, ccm_prime_term_7, ccm_prime_term_8, ccm_prime_term_9, ccm_prime_term_11,
    ccm_prime_term_13]
  norm_num
  ring
