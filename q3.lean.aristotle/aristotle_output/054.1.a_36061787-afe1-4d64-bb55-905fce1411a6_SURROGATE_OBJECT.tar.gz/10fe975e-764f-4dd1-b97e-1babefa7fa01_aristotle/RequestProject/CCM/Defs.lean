import Mathlib

/-!
# CCM finite Weil-source matrix: definitions

This file reconstructs the definitions of the CCM finite Weil source matrix
(`ccmL`, `CCMModeFinite`, `ccmModeFinite`, `ccmQKernel`,
`ccmWRFiniteExtendedIntegrand`, `ccmWREntry`, `ccmW02Entry`, `ccmPrimeEntryN1`).

The setup is the Weil explicit-formula bilinear form evaluated on a finite family of
even test functions.  Fix a cut-off `L = log N` (here `N = 13`).  For an integer mode
`n` the mode function is `x ↦ cosh (n x)`, and the test function attached to a pair of
modes `(n, m)` is the product `ccmQKernel n m x = cosh (n x) * cosh (m x)`.

Three groups of terms are recorded separately:

* `ccmW02Entry L n m` : the polar ("`W₀`") term `ĝ(i/2) + ĝ(-i/2)`, i.e. the integral of
  the test function against `2 cosh (x/2)` over `[-L, L]`;
* `ccmPrimeEntryN1 M n m` : the prime-power term
  `∑_{q ≤ M} Λ(q) q^{-1/2} (g (log q) + g (-log q))`;
* `ccmWREntry L n m` : the archimedean remainder, the integral over `[0, L]` of the
  regularised test function `g(x) - g(0)` against the level-`2` truncation
  `∑_{j ≤ 2} e^{-(2j+1)x/2}` of the archimedean kernel `1/(2 sinh (x/2))`.

The quantity enclosed by the main theorem of this development is the resulting
matrix entry `ccmW02Entry - ccmPrimeEntryN1 - ccmWREntry`.
-/

open scoped BigOperators

/-- The mode index type at level `N`: the `2N+1` integer modes `-N, …, N`. -/
abbrev CCMModeFinite (N : ℕ) := Fin (2 * N + 1)

/-- The integer mode attached to an index of `CCMModeFinite N`. -/
def ccmModeFinite (N : ℕ) (i : CCMModeFinite N) : ℤ := (i.val : ℤ) - (N : ℤ)

/-- The cut-off `L = log N`. -/
noncomputable def ccmL (N : ℕ) : ℝ := Real.log N

/-- The mode function of the integer mode `n`. -/
noncomputable def ccmModeFun (n : ℤ) (x : ℝ) : ℝ := Real.cosh ((n : ℝ) * x)

/-- The test function attached to the pair of modes `(n, m)`. -/
noncomputable def ccmQKernel (n m : ℤ) (x : ℝ) : ℝ := ccmModeFun n x * ccmModeFun m x

/-- The level-`N` truncation `∑_{j ≤ N} e^{-(2j+1)x/2}` of the archimedean kernel
`1 / (2 sinh (x/2))`. -/
noncomputable def ccmArchKernelFinite (N : ℕ) (x : ℝ) : ℝ :=
  ∑ j ∈ Finset.range (N + 1), Real.exp (-((2 * (j : ℝ) + 1) / 2) * x)

/-- The (regularised) integrand of the archimedean remainder term. -/
noncomputable def ccmWRFiniteExtendedIntegrand (N : ℕ) (n m : ℤ) (x : ℝ) : ℝ :=
  (ccmQKernel n m x - 1) * ccmArchKernelFinite N x

/-- The archimedean remainder entry: the integral of the regularised test function
against the level-`2` archimedean kernel over `[0, L]`. -/
noncomputable def ccmWREntry (Lv : ℝ) (n m : ℤ) : ℝ :=
  ∫ x in (0 : ℝ)..Lv, ccmWRFiniteExtendedIntegrand 2 n m x

/-- The polar term `ĝ(i/2) + ĝ(-i/2)` of the explicit formula. -/
noncomputable def ccmW02Entry (Lv : ℝ) (n m : ℤ) : ℝ :=
  ∫ x in (-Lv)..Lv, ccmQKernel n m x * (2 * Real.cosh (x / 2))

/-- The prime-power term `∑_{q ≤ M} Λ(q) q^{-1/2} (g (log q) + g (-log q))`. -/
noncomputable def ccmPrimeEntryN1 (M : ℕ) (n m : ℤ) : ℝ :=
  ∑ q ∈ Finset.Icc 2 M,
    (ArithmeticFunction.vonMangoldt q / Real.sqrt q) *
      (ccmQKernel n m (Real.log q) + ccmQKernel n m (-Real.log q))

lemma ccmArchKernelFinite_continuous (N : ℕ) : Continuous (ccmArchKernelFinite N) := by
  unfold ccmArchKernelFinite
  exact continuous_finset_sum _ fun j _ => Real.continuous_exp.comp (by fun_prop)

lemma ccmQKernel_continuous (n m : ℤ) : Continuous (ccmQKernel n m) := by
  unfold ccmQKernel ccmModeFun
  fun_prop

lemma ccmWRFiniteExtendedIntegrand_continuous (N : ℕ) (n m : ℤ) :
    Continuous (ccmWRFiniteExtendedIntegrand N n m) :=
  ((ccmQKernel_continuous n m).sub continuous_const).mul (ccmArchKernelFinite_continuous N)

/-- The `WR` integrand is integrable on every interval. -/
lemma ccmWRIntegrandFinite_integrableOn (N : ℕ) (n m : ℤ) (a b : ℝ) :
    IntervalIntegrable (ccmWRFiniteExtendedIntegrand N n m) MeasureTheory.volume a b :=
  (ccmWRFiniteExtendedIntegrand_continuous N n m).intervalIntegrable a b
