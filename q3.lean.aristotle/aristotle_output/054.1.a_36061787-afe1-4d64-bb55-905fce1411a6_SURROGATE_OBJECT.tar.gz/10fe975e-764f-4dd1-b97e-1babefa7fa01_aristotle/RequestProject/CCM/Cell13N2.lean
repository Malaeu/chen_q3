import RequestProject.CCM.Constants
import RequestProject.CCM.ClosedForm

/-!
# The CCM cell `(13, 2)`: rational enclosures of the `WR` entries

`tauLower512` and `tauUpper512` are exact rational matrices of width `10⁻⁸⁸`
enclosing the entries `W02 - Prime - WR` of the cell.  The main theorem
`ccmCell13N2_wr_enclosures` states the resulting two-sided bounds on the
archimedean remainder entries `ccmWREntry`.

Since the mode functions are even and the pairing is symmetric in the two modes, an
entry depends only on `(|n|, |m|)`; the reduced data is recorded in
`tauLowerCore`/`tauUpperCore`, and the resulting matrices are centrosymmetric.
-/

open scoped BigOperators

set_option maxHeartbeats 1000000

/-- The entry of the cell attached to the pair of modes `(n, m)`. -/
noncomputable def ccmCellEntry (n m : ℤ) : ℝ :=
  ccmW02Entry (ccmL 13) n m - ccmPrimeEntryN1 13 n m - ccmWREntry (ccmL 13) n m

/-! ### Symmetries -/

lemma ccmQKernel_comm (n m : ℤ) (x : ℝ) : ccmQKernel n m x = ccmQKernel m n x := mul_comm _ _

lemma ccmQKernel_neg_left (n m : ℤ) (x : ℝ) : ccmQKernel (-n) m x = ccmQKernel n m x := by
  simp [ccmQKernel, ccmModeFun, Real.cosh_neg]

lemma ccmCellEntry_comm (n m : ℤ) : ccmCellEntry n m = ccmCellEntry m n := by
  unfold ccmCellEntry ccmW02Entry ccmPrimeEntryN1 ccmWREntry ccmWRFiniteExtendedIntegrand
  simp_rw [ccmQKernel_comm n m]

lemma ccmCellEntry_neg_left (n m : ℤ) : ccmCellEntry (-n) m = ccmCellEntry n m := by
  unfold ccmCellEntry ccmW02Entry ccmPrimeEntryN1 ccmWREntry ccmWRFiniteExtendedIntegrand
  simp_rw [ccmQKernel_neg_left n m]

lemma ccmCellEntry_neg_right (n m : ℤ) : ccmCellEntry n (-m) = ccmCellEntry n m := by
  rw [ccmCellEntry_comm, ccmCellEntry_neg_left, ccmCellEntry_comm]

lemma ccmCellEntry_natAbs (n m : ℤ) :
    ccmCellEntry n m = ccmCellEntry (n.natAbs : ℤ) (m.natAbs : ℤ) := by
  rcases Int.natAbs_eq n with hn | hn <;> rcases Int.natAbs_eq m with hm | hm
  · rw [← hn, ← hm]
  · rw [← hn]; conv_lhs => rw [hm]
    rw [ccmCellEntry_neg_right]
  · rw [← hm]; conv_lhs => rw [hn]
    rw [ccmCellEntry_neg_left]
  · conv_lhs => rw [hn, hm]
    rw [ccmCellEntry_neg_left, ccmCellEntry_neg_right]

/-! ### The rational bound tables -/

/-- Reduced table (indexed by `(|n|, |m|)`) of the lower rational bounds. -/
def tauLowerCore : ℕ → ℕ → ℚ
  | 0, 0 => (4211294891581388815978562741836404410220880930869682843338693999508393252569738952047549/1250000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 0, 1 => (-3936475621992303216903121774368127027382726449766320369145743455466799631076070022216037/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 0, 2 => (-621845412865677057569250449731711371478846285332687104010080762249494071783657717210176261/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 0 => (-3936475621992303216903121774368127027382726449766320369145743455466799631076070022216037/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 1 => (-147038763433256486760355486949255034049269809471432410315842802563356731440774951398448967/5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 2 => (-2335110584665348959939648679492053609981387341205766005841276416786098108260662353131989973/5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 0 => (-621845412865677057569250449731711371478846285332687104010080762249494071783657717210176261/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 1 => (-2335110584665348959939648679492053609981387341205766005841276416786098108260662353131989973/5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 2 => (-3197266415851306888022646932208138348968048118166770401244365565261221948884225050258640997/500000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | _, _ => 0

/-- Reduced table (indexed by `(|n|, |m|)`) of the upper rational bounds. -/
def tauUpperCore : ℕ → ℕ → ℚ
  | 0, 0 => (33690359132651110527828501934691235281767047446957462746709551996067146020557911616380393/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 0, 1 => (-984118905498075804225780443592031756845681612441580092286435863866699907769017505554009/2500000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 0, 2 => (-31092270643283852878462522486585568573942314266634355200504038112474703589182885860508813/500000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 0 => (-984118905498075804225780443592031756845681612441580092286435863866699907769017505554009/2500000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 1 => (-294077526866512973520710973898510068098539618942864820631685605126713462881549902796897933/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 1, 2 => (-934044233866139583975859471796821443992554936482306402336510566714439243304264941252795989/2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 0 => (-31092270643283852878462522486585568573942314266634355200504038112474703589182885860508813/500000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 1 => (-934044233866139583975859471796821443992554936482306402336510566714439243304264941252795989/2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | 2, 2 => (-63945328317026137760452938644162766979360962363335408024887311305224438977684501005172819939/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℚ)
  | _, _ => 0

/-- Lower rational bounds for the entries of the cell `(13, 2)`. -/
def tauLower512 : Matrix (CCMModeFinite 2) (CCMModeFinite 2) ℚ :=
  fun i j => tauLowerCore (ccmModeFinite 2 i).natAbs (ccmModeFinite 2 j).natAbs

/-- Upper rational bounds for the entries of the cell `(13, 2)`. -/
def tauUpper512 : Matrix (CCMModeFinite 2) (CCMModeFinite 2) ℚ :=
  fun i j => tauUpperCore (ccmModeFinite 2 i).natAbs (ccmModeFinite 2 j).natAbs

/-! ### Enclosure of the six distinct entries -/

lemma ccm_cell_enclosure_0_0 :
    (4211294891581388815978562741836404410220880930869682843338693999508393252569738952047549/1250000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℝ) ≤ ccmCellEntry 0 0 ∧ ccmCellEntry 0 0 ≤ (33690359132651110527828501934691235281767047446957462746709551996067146020557911616380393/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_0_0, ccm_prime_value_0_0, ccm_wr_value_0_0]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

lemma ccm_cell_enclosure_0_1 :
    (-(3936475621992303216903121774368127027382726449766320369145743455466799631076070022216037/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) ≤ ccmCellEntry 0 1 ∧ ccmCellEntry 0 1 ≤ (-(984118905498075804225780443592031756845681612441580092286435863866699907769017505554009/2500000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_0_1, ccm_prime_value_0_1, ccm_wr_value_0_1]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

lemma ccm_cell_enclosure_0_2 :
    (-(621845412865677057569250449731711371478846285332687104010080762249494071783657717210176261/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) ≤ ccmCellEntry 0 2 ∧ ccmCellEntry 0 2 ≤ (-(31092270643283852878462522486585568573942314266634355200504038112474703589182885860508813/500000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_0_2, ccm_prime_value_0_2, ccm_wr_value_0_2]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

lemma ccm_cell_enclosure_1_1 :
    (-(147038763433256486760355486949255034049269809471432410315842802563356731440774951398448967/5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) ≤ ccmCellEntry 1 1 ∧ ccmCellEntry 1 1 ≤ (-(294077526866512973520710973898510068098539618942864820631685605126713462881549902796897933/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_1_1, ccm_prime_value_1_1, ccm_wr_value_1_1]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

lemma ccm_cell_enclosure_1_2 :
    (-(2335110584665348959939648679492053609981387341205766005841276416786098108260662353131989973/5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) ≤ ccmCellEntry 1 2 ∧ ccmCellEntry 1 2 ≤ (-(934044233866139583975859471796821443992554936482306402336510566714439243304264941252795989/2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_1_2, ccm_prime_value_1_2, ccm_wr_value_1_2]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

lemma ccm_cell_enclosure_2_2 :
    (-(3197266415851306888022646932208138348968048118166770401244365565261221948884225050258640997/500000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) ≤ ccmCellEntry 2 2 ∧ ccmCellEntry 2 2 ≤ (-(63945328317026137760452938644162766979360962363335408024887311305224438977684501005172819939/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) : ℝ) := by
  rw [ccmCellEntry, ccm_w02_value_2_2, ccm_prime_value_2_2, ccm_wr_value_2_2]
  obtain ⟨s13a, s13b⟩ := ccm_sqrt_bounds_13
  obtain ⟨l2a, l2b⟩ := ccm_log_bounds_2
  obtain ⟨l3a, l3b⟩ := ccm_log_bounds_3
  obtain ⟨p2a, p2b⟩ := ccm_log_sqrt_bounds_2
  obtain ⟨p3a, p3b⟩ := ccm_log_sqrt_bounds_3
  obtain ⟨p5a, p5b⟩ := ccm_log_sqrt_bounds_5
  obtain ⟨p7a, p7b⟩ := ccm_log_sqrt_bounds_7
  obtain ⟨p11a, p11b⟩ := ccm_log_sqrt_bounds_11
  obtain ⟨p13a, p13b⟩ := ccm_log_sqrt_bounds_13
  constructor <;> linarith

/-! ### The general enclosure and the main theorem -/

lemma ccm_cell_enclosure_nat (a b : ℕ) (ha : a ≤ 2) (hb : b ≤ 2) :
    (tauLowerCore a b : ℝ) ≤ ccmCellEntry (a : ℤ) (b : ℤ) ∧
      ccmCellEntry (a : ℤ) (b : ℤ) ≤ (tauUpperCore a b : ℝ) := by
  interval_cases a <;> interval_cases b <;>
    simp only [tauLowerCore, tauUpperCore, Nat.cast_zero, Nat.cast_one, Nat.cast_ofNat,
      Rat.cast_div, Rat.cast_neg, Rat.cast_ofNat] <;>
    norm_num <;>
    first
      | exact ccm_cell_enclosure_0_0
      | exact ccm_cell_enclosure_0_1
      | exact ccm_cell_enclosure_0_2
      | exact ccm_cell_enclosure_1_1
      | exact ccm_cell_enclosure_1_2
      | exact ccm_cell_enclosure_2_2
      | (rw [ccmCellEntry_comm]; exact ccm_cell_enclosure_0_1)
      | (rw [ccmCellEntry_comm]; exact ccm_cell_enclosure_0_2)
      | (rw [ccmCellEntry_comm]; exact ccm_cell_enclosure_1_2)

/-- Every entry of the cell is enclosed by the reduced rational tables. -/
lemma ccm_cell_enclosure (n m : ℤ) (hn : n.natAbs ≤ 2) (hm : m.natAbs ≤ 2) :
    (tauLowerCore n.natAbs m.natAbs : ℝ) ≤ ccmCellEntry n m ∧
      ccmCellEntry n m ≤ (tauUpperCore n.natAbs m.natAbs : ℝ) := by
  rw [ccmCellEntry_natAbs]
  exact ccm_cell_enclosure_nat _ _ hn hm

lemma ccmModeFinite_natAbs_le (i : CCMModeFinite 2) : (ccmModeFinite 2 i).natAbs ≤ 2 := by
  have := i.isLt
  simp only [ccmModeFinite]
  omega

/-- **Main theorem.**  Two-sided rational enclosures, of width `10⁻⁸⁸`, for the
archimedean remainder entries of the CCM cell `(13, 2)`. -/
theorem ccmCell13N2_wr_enclosures :
    ∀ i j : CCMModeFinite 2,
      ccmW02Entry (ccmL 13) (ccmModeFinite 2 i) (ccmModeFinite 2 j) -
          ccmPrimeEntryN1 13 (ccmModeFinite 2 i) (ccmModeFinite 2 j) -
          (tauUpper512 i j : ℝ) ≤
        ccmWREntry (ccmL 13) (ccmModeFinite 2 i) (ccmModeFinite 2 j) ∧
      ccmWREntry (ccmL 13) (ccmModeFinite 2 i) (ccmModeFinite 2 j) ≤
        ccmW02Entry (ccmL 13) (ccmModeFinite 2 i) (ccmModeFinite 2 j) -
          ccmPrimeEntryN1 13 (ccmModeFinite 2 i) (ccmModeFinite 2 j) -
          (tauLower512 i j : ℝ) := by
  intro i j
  obtain ⟨h1, h2⟩ := ccm_cell_enclosure (ccmModeFinite 2 i) (ccmModeFinite 2 j)
    (ccmModeFinite_natAbs_le i) (ccmModeFinite_natAbs_le j)
  rw [ccmCellEntry] at h1 h2
  constructor
  · show _ - _ - ((tauUpperCore _ _ : ℚ) : ℝ) ≤ _
    linarith
  · show _ ≤ _ - _ - ((tauLowerCore _ _ : ℚ) : ℝ)
    linarith

set_option maxRecDepth 10000 in
/-- Every ball of the enclosure has width exactly `10⁻⁸⁸`. -/
lemma tau512_width (i j : CCMModeFinite 2) :
    tauUpper512 i j - tauLower512 i j = 1/10^88 := by
  fin_cases i <;> fin_cases j <;>
    simp only [tauLower512, tauUpper512, ccmModeFinite] <;> norm_num [tauLowerCore, tauUpperCore]
